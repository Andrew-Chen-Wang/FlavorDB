# Review batch names-025

## DISH Q140654822
- name: Picurinu: tuma PAT
- other names: {"zh": "Picurinu: tuma PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140654832
- name: Lattime di tonno salato PAT
- other names: {"zh": "Lattime di tonno salato PAT"}
- description: traditional Italian fish, mollusc or crustacean product (PAT)
- countries: IT
- kinds: seafood

## DISH Q140654837
- name: Sardina salata PAT
- other names: {"zh": "Sardina salata PAT"}
- description: traditional Italian fish, mollusc or crustacean product (PAT)
- countries: IT
- kinds: seafood

## DISH Q140654840
- name: Lombo senese PAT
- other names: {"zh": "Lombo senese PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654845
- name: Soppressata toscana PAT
- other names: {"zh": "Soppressata toscana PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654858
- name: Anacino PAT
- other names: {"zh": "Anacino PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654860
- name: Biscotto salato di Roccalbegna PAT
- other names: {"zh": "Biscotto salato di Roccalbegna PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654862
- name: Cecina PAT
- other names: {"zh": "Cecina PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654864
- name: Cucchiaroli PAT
- other names: {"zh": "Cucchiaroli PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654866
- name: Neccio toscano PAT
- other names: {"zh": "Neccio toscano PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654868
- name: Schiacce grossetane PAT
- other names: {"zh": "Schiacce grossetane PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654931
- name: Saraghina PAT
- other names: {"zh": "Saraghina PAT"}
- description: traditional Italian fish, mollusc or crustacean product (PAT)
- countries: IT
- kinds: seafood

## DISH Q140654933
- name: Salsiccia di fegato di suino PAT
- other names: {"zh": "Salsiccia di fegato di suino PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654936
- name: Sughetti PAT
- other names: {"zh": "Sughetti PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655121
- name: Giglietto PAT
- other names: {"zh": "Giglietto PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655127
- name: Sugo col tonno e alici PAT
- other names: {"zh": "Sugo col tonno e alici PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140655129
- name: Nostrano PAT
- other names: {"zh": "Nostrano PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140655165
- name: Ciccioli (o cicciolata) PAT
- other names: {"zh": "Ciccioli (o cicciolata) PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140655167
- name: Crescioni PAT
- other names: {"zh": "Crescioni PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655169
- name: Maltagliati PAT
- other names: {"zh": "Maltagliati PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655170
- name: Formaggetta della Val Graveglia PAT
- other names: {"zh": "Formaggetta della Val Graveglia PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140655175
- name: Cuddhura PAT
- other names: {"zh": "Cuddhura PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655177
- name: Cìciri e trya PAT
- other names: {"zh": "Cìciri e trya PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140655178
- name: Fave bianche e  cicorie PAT
- other names: {"zh": "Fave bianche e  cicorie PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140655184
- name: Monacelle PAT
- other names: {"zh": "Monacelle PAT"}
- description: traditional Italian fish, mollusc or crustacean product (PAT)
- countries: IT
- kinds: seafood

## DISH Q140655185
- name: Mistocchine PAT
- other names: {"zh": "Mistocchine PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655186
- name: Riso con la tritura o tradura PAT
- other names: {"zh": "Riso con la tritura o tradura PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655187
- name: Spianata PAT
- other names: {"zh": "Spianata PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655189
- name: Sanguinaccio PAT
- other names: {"zh": "Sanguinaccio PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140655190
- name: Marmellata di mirtilli PAT
- other names: {"zh": "Marmellata di mirtilli PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655192
- name: Pasta di Antrodoco PAT
- other names: {"zh": "Pasta di Antrodoco PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655193
- name: Casu frazigu PAT
- other names: {"zh": "Casu frazigu PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140655197
- name: Bianchittos PAT
- other names: {"zh": "Bianchittos PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655200
- name: Agnello con piselli e uova PAT
- other names: {"zh": "Agnello con piselli e uova PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140655239
- name: Fusilli lucani PAT
- other names: {"zh": "Fusilli lucani PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655251
- name: Castagnaccio toscano PAT
- other names: {"zh": "Castagnaccio toscano PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140655273
- name: Calzagatti PAT
- other names: {"zh": "Calzagatti PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140655292
- name: Zafferano PAT
- other names: {"zh": "Zafferano PAT"}
- description: traditional Italian condiment (PAT)
- countries: IT
- kinds: condiment

## DISH Q140655384
- name: Casu axedu PAT
- other names: {"zh": "Casu axedu PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140693125
- name: Katsu
- countries: JP
- kinds: breaded cutlet, Agemono

## DISH Q140695130
- name: Zoodle
- countries: (none)
- kinds: spaghetti
- ingredients: zucchini

## DISH Q140697760
- name: Karumeyaki
- countries: JP
- kinds: honeycomb toffee, dagashi

## DISH Q140698473
- name: Sanzokuyaki
- countries: (none)
- kinds: sannzoku-yaki, Agemono, yakimono

## DISH Q140700947
- name: Keiran sōmen
- countries: (none)
- kinds: fios de ovos, Nanbangashi

## DISH Q140700995
- name: Foi thong
- countries: TH
- kinds: fios de ovos
- has Wikipedia article: en

## DISH Q14071553
- name: Colocasia with lamb
- description: Turkish and Greek dish common to the Aegean made with colocasia and lamb, also on the island of Cyprus
- countries: (none)
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q140724932
- name: Hawaii cookery
- countries: (none)
- kinds: national dish

## DISH Q1408045
- name: Gatsby
- description: South African sandwich
- countries: ZA
- kinds: sandwich
- ingredients: bologna, ketchup, fries, Lactuca sativa, bread roll
- has Wikipedia article: en

## DISH Q140810022
- name: Walkman
- other names: {"pl": "Walkman"}
- countries: PH
- kinds: dish

## DISH Q1408240
- name: Fertigsuppe
- other names: {"de": "Fertigsuppe"}
- countries: (none)
- kinds: dish, food preserve

## DISH Q140827695
- name: Kue tumpi
- other names: {"id": "Kue tumpi"}
- description: food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food
- ingredients: glutinous rice flour, palm sugar, rice flour

## DISH Q140907498
- name: Pull-apart doughnut
- description: doughnut
- countries: (none)
- kinds: dessert, doughnut, fried dough

## DISH Q140911335
- name: Харківський торт
- other names: {"uk": "Харківський торт"}
- countries: UA
- kinds: torte

## DISH Q140925974
- name: Bocado de dama
- description: Chilean bread
- countries: CL
- kinds: white bread
- ingredients: wheat flour, baker's yeast, butter, table salt, water

## DISH Q140936615
- name: Sambal kacang
- other names: {"id": "sambal kacang"}
- countries: (none)
- kinds: dish, sambal, Indonesian peanut sauces
- ingredients: roasted peanut, chili powder, Indonesian peanut sauces, sambal

## DISH Q14094083
- name: Ducat buns
- description: Czecho-Slovak dessert
- countries: CZ
- kinds: dessert

## DISH Q140946891
- name: Dobladita
- description: Chilean bread
- countries: (none)
- kinds: white bread

## DISH Q140959034
- name: Kürbiskraut
- other names: {"de": "Kürbiskraut"}
- countries: (none)
- kinds: stew

## DISH Q14096039
- name: Rishta Khatayi
- countries: (none)
- kinds: pastry

## DISH Q140995939
- name: Huangtang lamian
- other names: {"zh": "黄汤拉面"}
- description: beef noodle soup with curry powder
- countries: (none)
- kinds: beef noodle soup
- has Wikipedia article: zh

## DISH Q141003804
- name: Double-Yolk Ice Cream Bar
- other names: {"zh": "奥雪双黄蛋雪糕"}
- description: Chinese ice cream bar
- countries: CN
- kinds: ice cream bar

## DISH Q141012691
- name: Telur Pindang
- description: hard-boiled egg cooked in the pindang process
- countries: MY
- cuisines: Malay cuisine
- kinds: egg dish
- ingredients: hard-boiled egg

## DISH Q141015353
- name: 叭噗
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: frozen dessert, human food
- ingredients: potato starch, sugar, water
- has Wikipedia article: zh

## DISH Q141030654
- name: Chicken Changezi
- other names: {"zh": "成吉思鸡"}
- countries: IN
- kinds: chicken dish
- has Wikipedia article: zh

## DISH Q141070354
- name: 麻薬卵
- other names: {"ja": "麻薬卵"}
- countries: KR
- kinds: soy egg, egg dish
- ingredients: soft-boiled egg, soy sauce, chili pepper, Welsh onion, sugar

## DISH Q1410920
- name: Salty licorice
- other names: {"zh": "咸甘草糖"}
- description: Northern European confectionery
- countries: FI
- kinds: licorice candy, candy
- ingredients: liquorice, ammonium chloride
- has Wikipedia article: en, zh

## DISH Q141099658
- name: Madagascar vanilla
- description: vanilla derived from the cured pods of Vanilla planifolia grown primarily in Madagascar but sometimes Réunion, the Comoros, and Mauritius
- countries: KM, MG, MU, RE
- kinds: vanilla, spice

## DISH Q141103037
- name: Krichim-style drob sarma
- description: dish
- countries: BG
- kinds: dish, drob sarma

## DISH Q141111492
- name: Laubfrösche
- other names: {"de": "Laubfrösche"}
- countries: (none)
- kinds: dish
- ingredients: spinach

## DISH Q141114585
- name: Gulai batang pisang
- description: Malaysian dish associated with Kedah
- countries: MY
- kinds: gulai

## DISH Q141114587
- name: Asam pedas Melaka
- description: Malaysian asam pedas dish associated with Malacca
- countries: MY
- kinds: asam pedas

## DISH Q141114590
- name: Rendang tok
- description: Malaysian rendang dish associated with Perak
- countries: MY
- kinds: rendang

## DISH Q141114591
- name: Laksa Kuala Kangsar
- description: Malaysian laksa dish associated with Kuala Kangsar, Perak
- countries: MY
- kinds: laksa

## DISH Q141114595
- name: Pulut Harum Manis
- description: Malaysian glutinous rice dish associated with Perlis
- countries: MY
- kinds: rice dish

## DISH Q141114598
- name: Manok pansoh
- description: Malaysian traditional chicken dish associated with Sarawak
- countries: MY
- kinds: chicken dish

## DISH Q141114599
- name: Midin belacan
- description: Malaysian vegetable dish associated with Sarawak
- countries: MY
- kinds: vegetable dish

## DISH Q141114600
- name: Nasi minyak Terengganu
- description: Malaysian rice dish associated with Terengganu
- countries: MY
- kinds: nasi minyak

## DISH Q141130608
- name: Einbrennsuppe
- other names: {"de": "Einbrennsuppe"}
- countries: (none)
- kinds: soup, gruel

## DISH Q141163288
- name: Spagettigratäng
- other names: {"sv": "Spagettigratäng"}
- countries: (none)
- kinds: pasta dish

## DISH Q141175905
- name: Ungkrung
- countries: ID
- kinds: traditional food

## DISH Q141182209
- name: Enchilada potosina
- description: type of enchilada
- countries: MX
- kinds: enchilada, dish, stuffed flatbread
- ingredients: lettuce, corn tortilla, Guajillo chili, onion, fresh cheese

## DISH Q1412112
- name: Prosciutto di San Daniele PDO
- other names: {"zh": "Prosciutto di San Daniele DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: prosciutto, meat product
- has Wikipedia article: en

## DISH Q1412378
- name: Gofio
- description: Food of Canarian origin made up of unsifted flour of toasted cereals
- countries: ES
- kinds: flour, dish, meal
- ingredients: cereal
- has Wikipedia article: en

## DISH Q141245285
- name: Rosquete punateño
- other names: {"es": "Rosquete punateño"}
- countries: BO
- kinds: pastry

## DISH Q141247327
- name: Lemon ice cream
- description: Flavor of ice cream
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q141248130
- name: Souttert
- description: South African baked dish
- countries: ZA
- kinds: dish

## DISH Q1412561
- name: Kulen
- description: type of sausage
- countries: HR, RS
- kinds: sausage
- has Wikipedia article: en

## DISH Q141266545
- name: Karan
- description: traditional savory chickpea flan street food from eastern Morocco
- countries: MA
- kinds: street food, food, dish, snack

## DISH Q1412680
- name: Beef Wellington
- other names: {"zh": "威靈頓牛柳"}
- description: filet steak with pâté and duxelles in puff pastry
- countries: (none)
- kinds: beef dish
- ingredients: puff pastry, beef tenderloin
- has Wikipedia article: en, zh

## DISH Q141278083
- name: Asado
- other names: {"es": "Asado"}
- countries: PE
- kinds: dish

## DISH Q1412833
- name: Gratin
- other names: {"zh": "法國奶油焗薯仔"}
- description: cooking technique
- countries: FR
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q14128832
- name: Sì
- other names: {"zh": "𥻵"}
- description: traditional spherical dessert eaten for celebration for the "Winter Solstice" festival in Fuzhou, China
- countries: (none)
- kinds: dessert
- has Wikipedia article: en, zh

## DISH Q141293
- name: Dondurma
- other names: {"zh": "土耳其冰淇淋"}
- description: Turkish variety of ice cream
- countries: TR
- kinds: food, ice cream, dish
- ingredients: salep, mastic, sugar, milk
- has Wikipedia article: en, zh

## DISH Q141293713
- name: Timbale de pèlerin de Lourdes
- other names: {"fr": "Timbale de pèlerin de Lourdes"}
- countries: (none)
- kinds: Timbale
- ingredients: aluminium

## DISH Q141332469
- name: 불고기버거
- other names: {"ko": "불고기버거"}
- countries: (none)
- kinds: hamburger

## DISH Q141334066
- name: Burbacek
- other names: {"id": "burbacek"}
- countries: ID
- kinds: dish, food
- ingredients: cow's trotters, porridge, cowhide, mung bean sprout, peanut, coconut, water spinach, chili pepper

## DISH Q141334629
- name: Pindang gombyang
- other names: {"id": "pindang gombyang"}
- countries: ID
- kinds: Pindang, dish

## DISH Q141369422
- name: Mergpijpje
- description: Dutch pastry
- countries: (none)
- kinds: cookie, pastry
- ingredients: marzipan, cream, chocolate
- has Wikipedia article: en

## DISH Q141369742
- name: Vetebröd
- other names: {"sv": "vetebröd"}
- countries: (none)
- kinds: bread
- ingredients: wheat flour

## DISH Q141379382
- name: Geblog
- other names: {"id": "geblog"}
- countries: ID
- kinds: food, dish
- ingredients: cassava root, flax, coconut, palm sugar, Pandanus amaryllifolius, glutinous rice, table salt

## DISH Q141379737
- name: Gemblep
- other names: {"id": "gemblep"}
- countries: ID
- kinds: jajan pasar, food, dish
- ingredients: granulated sugar, Sweet potato, table salt

## DISH Q141385046
- name: Krakeling
- description: Dutch sweet, brittle biscuit
- countries: (none)
- kinds: pastry
- ingredients: wheat flour

## DISH Q141385059
- name: Combinado siete colores
- other names: {"es": "Combinado siete colores"}
- countries: PE
- kinds: dish

## DISH Q141385805
- name: Scandinavian beetroot salad
- description: Scandinavian-style salad spread with pickled beetroot and mayonnaise
- countries: (none)
- kinds: spread, beetroot salad

## DISH Q141407702
- name: Lolaz dürümü
- other names: {"tr": "lolaz dürümü"}
- description: cowpea wrap from Şanlıurfa, Turkey
- countries: TR
- cuisines: Şanlıurfa cuisine
- kinds: street food, dürüm, type of food or dish
- ingredients: cowpea, Urfa biber

## DISH Q141434444
- name: Urfa tray kebab
- description: eggplant and lamb kebab from Şanlıurfa, Turkey
- countries: TR
- cuisines: Şanlıurfa cuisine
- kinds: kebab, type of food or dish
- ingredients: Birecik eggplant, tail fat, lamb meat

## DISH Q141436297
- name: Death muffin
- countries: (none)
- kinds: food product, muffin

## DISH Q141438921
- name: Haşhaş kebap
- description: kebab from Şanlıurfa, Turkey
- countries: TR
- cuisines: Şanlıurfa cuisine
- kinds: kebab, food

## DISH Q141451226
- name: Šurlice
- description: Cuisine of Croatia
- countries: HR
- cuisines: Croatian cuisine
- kinds: pasta, noodle, human food

## DISH Q141460495
- name: Sultana de coco
- countries: ES
- kinds: dessert
- ingredients: coconut, egg white, sugar

## DISH Q141467374
- name: Smetanová zmrzlina
- other names: {"cs": "Smetanová zmrzlina"}
- countries: (none)
- kinds: ice cream

## DISH Q141483840
- name: Candied ginger
- description: fresh ginger root sliced, boiled until tender, and cooked in a sugar syrup before being coated in coarse sugar
- countries: (none)
- kinds: snack, confectionery
- ingredients: ginger, sugar

## DISH Q1414887
- name: Lahmacun
- other names: {"zh": "浪马军"}
- description: Middle Eastern food
- countries: (none)
- kinds: dish, flatbread dish
- ingredients: minced meat, herb, dough, vegetable
- has Wikipedia article: en, zh

## DISH Q141489694
- name: Cheese Tsukimi
- countries: (none)
- kinds: product, cheeseburger

## DISH Q141489865
- name: Dirty The One Pounder
- countries: (none)
- kinds: product, cheeseburger
- ingredients: onion, pickle, Cheddar cheese, beef, mayonnaise, black pepper, Allium sativum, table salt, bread

## DISH Q141502128
- name: Urfa içli köftesi
- other names: {"tr": "Urfa içli köftesi"}
- countries: (none)
- cuisines: Şanlıurfa cuisine
- kinds: kibbeh

## DISH Q141532251
- name: St. Sava's Day pretzel
- description: Pastry traditionally prepared for the celebration of Saint Sava, the school patron saint, in Serbia
- countries: (none)
- kinds: pretzel

## DISH Q141556520
- name: Orange chips
- description: deep-fried potato dish
- countries: (none)
- kinds: fries
- has Wikipedia article: en

## DISH Q141560036
- name: サンディーのバイオレットショコラチュロス
- other names: {"ja": "サンディーのバイオレットショコラチュロス"}
- countries: (none)
- kinds: product, churro
- ingredients: churro, chocolate

## DISH Q141560063
- name: サンディーダンクドーナツ ～甘さを豪快にダンク！～
- other names: {"ja": "サンディーダンクドーナツ ～甘さを豪快にダンク！～"}
- countries: (none)
- kinds: product, doughnut
- ingredients: marshmallow, doughnut

## DISH Q141563145
- name: Hörnli / Cornettes / Cornetti  (macaroni)
- description: Macaroni from Switzerland
- countries: (none)
- kinds: Swiss cuisine, macaroni

## DISH Q141576475
- name: Catemak jagung
- other names: {"id": "catemak jagung"}
- countries: ID
- kinds: soup, food, dish, human food, type of food or dish
- ingredients: kidney bean, moringa, pumpkin, peanut, maize

## DISH Q141576482
- name: Yondog Binangoan
- other names: {"id": "Yondog Binangoan"}
- countries: ID
- cuisines: Indonesian cuisine, traditional food
- kinds: fish dish, vegetable dish, food, dish, human food, type of food or dish
- ingredients: bamboo shoots, coconut milk, scallion, Allium ascalonicum, chili pepper, table salt, fish

## DISH Q141576629
- name: Sinole
- other names: {"id": "Sinole"}
- countries: (none)
- kinds: food, dish, traditional food, Indonesian cuisine
- ingredients: grated coconut, sago, table salt

## DISH Q141576662
- name: Sagu sèp
- other names: {"bew": "Sagu sèp"}
- countries: ID
- kinds: Indonesian cuisine, food, dish, traditional food
- ingredients: banana leaf, sago, bark, Cocos nucifera, meat, rock

## DISH Q141576747
- name: Sambal lu'at
- other names: {"id": "sambal lu'at"}
- countries: ID
- kinds: sambal
- ingredients: bird's eye chili, Citrus × aurantiifolia

## DISH Q141577035
- name: Sagu tumbuk
- other names: {"id": "Sagu tumbuk"}
- countries: ID
- kinds: Indonesian cuisine, food, cuisine, human food
- ingredients: sago

## DISH Q141577085
- name: Bikandoang
- other names: {"id": "Bikandoang"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fritter, snack, dish, human food, type of food or dish
- ingredients: shallot, turmeric rhizome, garlic, cabbage, peppercorn, wheat flour, seedling, scallion, table salt, water, carrot

## DISH Q141577142
- name: Kolo
- other names: {"id": "kolo"}
- countries: (none)
- kinds: food, dish, cooked rice
- ingredients: bamboo, banana leaf, coconut milk, cooking oil, Pandanus amaryllifolius, table salt, rice

## DISH Q141577620
- name: Ikan komu asar
- description: Indonesian traditional dish
- countries: ID
- kinds: Indonesian cuisine, food, cuisine, human food
- ingredients: banana leaf, Thunnus tonggol, Allium ascalonicum, Citrus × aurantiifolia, chili pepper, tomato, table salt

## DISH Q141577727
- name: Karmanaci
- other names: {"id": "karmanaci"}
- countries: (none)
- kinds: food, dish
- ingredients: goat meat, beef

## DISH Q141577768
- name: Ares
- other names: {"id": "ares"}
- countries: (none)
- kinds: food, dish

## DISH Q141580164
- name: Ikan Pare-Pare
- other names: {"id": "Ikan Pare-Pare"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: side dish, fish dish, food, dish, human food, traditional food, type of food or dish
- ingredients: granulated sugar, Indonesian bay leaf, shallot, Kaffir Lime Leaf, garlic, tomato, ginger, Thunnini, Thunnus tonggol, Pangasiidae, bird's eye chili, cooking oil, Scomberomorus, Citrus × aurantiifolia, chili pepper, Cymbopogon citratus, table salt, water

## DISH Q141580167
- name: Pallumara Ikan Sunu
- description: a type of fish soup from Makassar
- countries: ID
- cuisines: Indonesian cuisine
- kinds: side dish, fish dish, soup, food, dish, human food, type of food or dish
- ingredients: shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, coriander seed, peppercorn, palm sugar, Holy Basil, Chanos chanos, cooking oil, chili pepper, Tamarindus indica, Cymbopogon citratus, tomato, water

## DISH Q141580181
- name: Sour Fish Soup
- description: A traditional Indonesian fish soup with a refreshing sour taste
- countries: ID
- cuisines: Indonesian cuisine
- kinds: side dish, fish dish, food, dish, human food, type of food or dish
- ingredients: shallot, turmeric rhizome, garlic, ginger, indigo, Lutjanidae, scallion, Scomberomorus, chili pepper, Tamarindus indica, Cymbopogon citratus, Atlantic mackerel, tomato

## DISH Q141584250
- name: Pongek Lapuak
- other names: {"id": "Pongek Lapuak"}
- countries: ID
- cuisines: Indonesian cuisine, Padang cuisine
- kinds: side dish, fish dish, food, dish, human food, traditional food, type of food or dish
- ingredients: Garcinia xanthochymus fruit, turmeric leaf, shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, coriander seed, ginger, Schleichera oleosa, Osphronemus goramy, Oreochromis mossambicus, Aleurites moluccanus, freshwater fish, coconut milk, Alpinia galanga, Oreochromis niloticus, chili pepper, goldfish, Cymbopogon citratus, table salt

## DISH Q141597922
- name: Pâté de Houdan
- other names: {"fr": "Pâté de Houdan"}
- countries: FR
- kinds: culinary speciality

## DISH Q141599161
- name: Kamonegi burger
- countries: (none)
- kinds: product, hamburger
- ingredients: bun, duck meat, beef

## DISH Q141622397
- name: Narchvi
- countries: GE
- kinds: cheese

## DISH Q141632031
- name: Parrot pie
- description: historical Australian dish
- countries: AU
- cuisines: Australian cuisine
- kinds: meat pie, dish
- ingredients: bird meat, parrot
- has Wikipedia article: en

## DISH Q141642341
- name: Arroz con menestra
- description: Ecuadorian traditional dish
- countries: EC
- kinds: dish

## DISH Q141657659
- name: Zephir
- other names: {"de": "Zephir"}
- countries: (none)
- kinds: meat dish

## DISH Q141663891
- name: Four spoon soup
- description: type of soup
- countries: (none)
- kinds: type of food or dish, soup
- ingredients: brown lentil, red lentil, bulgur, egg yolk, flour, yogurt, rice

## DISH Q141665896
- name: Feet tripe soup
- description: Turkish soup
- countries: (none)
- kinds: type of food or dish, soup

## DISH Q141666592
- name: Sinop mantı
- description: mantı type
- countries: (none)
- kinds: type of food or dish, manti
- ingredients: walnut

## DISH Q141677390
- name: Λαδένια
- other names: {"el": "Λαδένια"}
- description: Greek tomato flatbread
- countries: GR
- cuisines: Greek cuisine
- kinds: flatbread dish

## DISH Q14169302
- name: Chocolate chip cookie
- other names: {"zh": "巧克力豆餅乾"}
- description: cookie including pieces of chocolate
- countries: US
- kinds: cookie
- ingredients: chocolate chip, flour
- has Wikipedia article: en, zh

## DISH Q141698603
- name: Stuffed chicken
- description: chicken dish
- countries: (none)
- kinds: chicken dish

## DISH Q141734732
- name: Migas de Almería
- other names: {"es": "Migas de Almería"}
- countries: ES
- cuisines: Spanish cuisine
- kinds: food
- ingredients: semolina

## DISH Q141735302
- name: Rahmgemüse
- other names: {"de": "Rahmgemüse"}
- description: dish made from vegetables and cream
- countries: (none)
- kinds: dish
- ingredients: cream, vegetable

## DISH Q141735873
- name: Bayramiç Beyazı
- other names: {"mul": "Bayramiç Beyazı"}
- description: local nectarine variety grown in Bayramiç, Turkey
- countries: TR
- kinds: nectarine

## DISH Q141739748
- name: Čaraka
- other names: {"cs": "čaraka"}
- countries: CZ
- kinds: spice mix
- ingredients: cilantro, black pepper, caraway seeds, onion, peppercorn, Trigonella foenum-graecum, root vegetable, table salt, sugar, fungi

## DISH Q141740590
- name: Tomato soup cake
- description: spice cake made with canned tomato soup
- countries: US
- kinds: spice cake
- ingredients: canned soup, nut, tomato soup, cream cheese
- has Wikipedia article: en

## DISH Q141743358
- name: Rabbit with mustard
- description: traditional French dish
- countries: (none)
- kinds: dish, rabbit dish

## DISH Q141749912
- name: Borrego
- description: sweet pastry from Cardedeu
- countries: ES
- kinds: biscuit

## DISH Q141754097
- name: Twice baked potato
- countries: (none)
- kinds: dish, baked potato
- ingredients: potato

## DISH Q141758893
- name: Kangaroo tail soup
- description: Australian dish
- countries: AU
- kinds: dish
- has Wikipedia article: en

## DISH Q141761848
- name: So-oribe square serving containers (five pieces)
- description: Mukōzuke by Rosanjin
- countries: (none)
- kinds: tableware, Mukōzuke
- ingredients: kaolin, ceramic glaze

## DISH Q141762852
- name: Krosseier
- description: eggshells emptied and refilled with a spiced mixture of egg, herbs and sometimes bread, then roasted on a spit or fried in fat, a dish of late medieval German cookery; not a deviled egg
- countries: (none)
- kinds: type of food or dish, egg dish
- ingredients: egg as food

## DISH Q141762854
- name: Egg cheese
- description: sweetened preparation of eggs and milk curdled and set in a mould, in early modern Austrian and German cookery; not the Swedish äggost
- countries: (none)
- kinds: type of food or dish, egg dish
- ingredients: egg as food

## DISH Q141762856
- name: Gescherb
- description: sauce-like dish of finely cut fruit or vegetables, typically apples or almonds, fried and stewed in wine and broth with spices and raisins, in which other foods are served, in early modern German cookery
- countries: (none)
- kinds: type of food or dish, sauce, dish

## DISH Q141762857
- name: Hollow roast
- description: spit-roasted roll of minced veal or fish formed around a thick spit, hollow once drawn off it and then filled, in late medieval German cookery; not a meatloaf
- countries: (none)
- kinds: type of food or dish, roast
- ingredients: forcemeat

## DISH Q141762859
- name: Mock game
- description: dish of domestic meat, eggs or fish prepared and sauced so as to pass for game, usually served in a pepper sauce, in late medieval German cookery; not game meat itself
- countries: (none)
- kinds: type of food or dish, dish, imitation food

## DISH Q141776651
- name: Snail porridge
- description: food
- countries: (none)
- kinds: dish, porridge, snail
- has Wikipedia article: en

## DISH Q1417997
- name: Taguella
- description: Tuareg flatbread
- countries: DZ, LY, ML, TN
- kinds: flatbread
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q141804111
- name: Пиріжки з горохом
- other names: {"uk": "Пиріжки з горохом"}
- countries: UA
- kinds: pirozhki
- ingredients: Pisum sativum

## DISH Q141814171
- name: Quaking pudding
- description: English pudding
- countries: (none)
- kinds: pudding
- has Wikipedia article: en

## DISH Q141871453
- name: Nkumu andza
- other names: {"fr": "Nkumu andza"}
- countries: (none)
- kinds: dish

## DISH Q141871473
- name: Into
- other names: {"fr": "Into"}
- countries: (none)
- kinds: dish

## DISH Q141872447
- name: Reblochonnade
- other names: {"fr": "Reblochonnade"}
- countries: (none)
- kinds: dish

## DISH Q141875164
- name: Couscous el hamoum
- other names: {"fr": "Couscous el hamoum"}
- countries: (none)
- kinds: dish

## DISH Q141875190
- name: Couscous el halhal
- other names: {"fr": "Couscous el halhal"}
- countries: (none)
- kinds: dish

## DISH Q141880058
- name: واویشکا
- other names: {"fa": "واویشکا"}
- countries: IR
- kinds: dish

## DISH Q141880665
- name: Mashed swede
- description: dish of cooked mashed rutabaga, commonly served as a side dish
- countries: (none)
- kinds: purée, dish
- ingredients: broth, Piper, Brassica napus subsp. rapifera, butter, table salt

## DISH Q141881541
- name: Венгерский хот-дог
- other names: {"ru": "Венгерский хот-дог"}
- countries: US
- cuisines: cuisine of the United States
- kinds: hot dog, dish

## DISH Q141883651
- name: 鳩ヶ谷ソース焼きうどん
- other names: {"ja": "鳩ヶ谷ソース焼きうどん"}
- countries: (none)
- kinds: yaki udon

## DISH Q141883681
- name: 伊勢崎もんじゃ
- other names: {"ja": "伊勢崎もんじゃ"}
- countries: (none)
- kinds: monjayaki

## DISH Q141885842
- name: びっくり饅頭
- other names: {"ja": "びっくり饅頭"}
- countries: (none)
- kinds: imagawayaki

## DISH Q141889766
- name: 備中高梁インディアントマト焼そば
- other names: {"ja": "備中高梁インディアントマト焼そば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q141906877
- name: Small dishes with bamboo grass under snow design
- description: Mukōzuke by Rosanjin
- countries: (none)
- kinds: tableware, Mukōzuke
- ingredients: kaolin, ceramic glaze

## DISH Q141913755
- name: Oribe square food containers
- description: Mukōzuke by Rosanjin
- countries: (none)
- kinds: tableware, Mukōzuke
- ingredients: kaolin, ceramic glaze

## DISH Q141917269
- name: Fermented fish paste
- countries: (none)
- kinds: fermented fish, fish paste

## DISH Q141917436
- name: Hasenik pekmezi
- description: grape molasses from Hilvan, Turkey
- countries: TR
- kinds: pekmez, food

## DISH Q141917494
- name: Hasenik pestili
- description: grape fruit leather from Hilvan, Turkey
- countries: TR
- kinds: food, pestil
- ingredients: wheat flour, starch

## DISH Q141919184
- name: Oribe covered bowl
- description: Mukōzuke by Rosanjin
- countries: (none)
- kinds: tableware, Mukōzuke
- ingredients: kaolin, ceramic glaze

## DISH Q141944500
- name: 直方焼きスパ
- other names: {"ja": "直方焼きスパ"}
- countries: (none)
- kinds: fried noodle

## DISH Q141946472
- name: とまこまいカレーラーメン
- other names: {"ja": "とまこまいカレーラーメン"}
- countries: (none)
- kinds: curry ramen

## DISH Q141950064
- name: Kefalonian meat pie
- description: Greek meat pie from Kefalonia
- countries: (none)
- kinds: meat pie
- ingredients: rice, meat

## DISH Q141951160
- name: 名取り雑煮
- other names: {"ja": "名取り雑煮"}
- countries: (none)
- kinds: zōni

## DISH Q141953048
- name: 納豆雑煮
- other names: {"ja": "納豆雑煮"}
- countries: (none)
- kinds: zōni

## DISH Q141954296
- name: 蒸し雑煮
- other names: {"ja": "蒸し雑煮"}
- countries: (none)
- kinds: zōni

## DISH Q141954861
- name: ねぎ雑煮
- other names: {"ja": "ねぎ雑煮"}
- countries: (none)
- kinds: zōni

## DISH Q141955060
- name: 名古屋雑煮
- other names: {"ja": "名古屋雑煮"}
- countries: (none)
- kinds: zōni

## DISH Q141957123
- name: 元祖 八潮焼きそば
- other names: {"ja": "元祖 八潮焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q141957124
- name: ところざわ醤油焼きそば
- other names: {"ja": "ところざわ醤油焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q141957127
- name: 深谷ねぎカレーやきそば
- other names: {"ja": "深谷ねぎカレーやきそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q141957133
- name: 浦安べか焼きそば
- other names: {"ja": "浦安べか焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q141957136
- name: レッド焼きそば
- other names: {"ja": "レッド焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q141957871
- name: ホワイト焼きそば
- other names: {"ja": "ホワイト焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q141958218
- name: くさりずし
- other names: {"ja": "くさりずし"}
- countries: (none)
- kinds: narezushi

## DISH Q141965322
- name: 仙台あおば餃子
- other names: {"ja": "仙台あおば餃子"}
- countries: (none)
- kinds: jiaozi

## DISH Q141966127
- name: Oribe covered bowl 2
- description: Mukōzuke by Rosanjin
- countries: (none)
- kinds: tableware, Mukōzuke
- ingredients: kaolin, ceramic glaze

## DISH Q141967638
- name: Nienburger Bärentatzen
- other names: {"de": "Nienburger Bärentatzen"}
- countries: (none)
- kinds: viennoiserie

## DISH Q141968512
- name: Holubtsi
- description: half-meat dish of cabbage leaves with a filling of Ukraine
- countries: (none)
- kinds: Ukrainian cuisine, cabbage roll

## DISH Q141970603
- name: Cariton
- other names: {"it": "Cariton"}
- countries: (none)
- kinds: dessert

## DISH Q141971438
- name: アンパンマンのあんぱん
- other names: {"ja": "アンパンマンのあんぱん"}
- countries: (none)
- kinds: anpan

## DISH Q141985384
- name: Venetian pastitsio
- description: Variety of pastitsio from Kythira
- countries: (none)
- kinds: Pastitsio

## DISH Q142018433
- name: Chicken Pickleball Burger
- countries: (none)
- kinds: product, chicken burger
- ingredients: Lactuca sativa var. capitata, onion, pickle, lemon, chicken as food, Anethum graveolens

## DISH Q1420371
- name: Goxua
- description: dessert
- countries: ES, FR
- cuisines: Basque cuisine
- kinds: dish, custard
- ingredients: pastry cream, sponge cake, caramel, cream
- has Wikipedia article: en

## DISH Q1420441
- name: Fish finger
- description: food product consisting of breaded and fried fish
- countries: GB
- kinds: deep-fried food, convenience food, fish dish
- ingredients: whitefish
- has Wikipedia article: en

## DISH Q1420442
- name: Lohikeitto
- other names: {"zh": "芬兰鲑鱼汤"}
- description: fish soup
- countries: FI
- cuisines: Finnish cuisine, Karelian cuisine
- kinds: dish, fish soup, fish dish
- ingredients: salmon, flour, milk
- has Wikipedia article: en, zh

## DISH Q1420553
- name: Nasi lemak
- other names: {"zh": "椰浆饭"}
- description: Malaysian rice dish cooked in coconut milk, served with sambal and side dishes.
- countries: MY
- kinds: rice dish
- ingredients: shallot, garlic, chicken egg, peanut, coconut milk, Pandanus amaryllifolius, Engraulidae, chili pepper, Cymbopogon citratus, rice
- has Wikipedia article: en, zh

## DISH Q1420904
- name: Diplomat pudding
- other names: {"zh": "外交官蛋糕"}
- description: classic dessert
- countries: HU
- kinds: pudding, dessert, pastry
- ingredients: Savoiarde PAT
- has Wikipedia article: en, zh

## DISH Q1421521
- name: Fluffernutter
- description: sandwich made with peanut butter and marshmallow fluff
- countries: US
- kinds: sandwich
- ingredients: marshmallow creme, peanut butter, bread
- has Wikipedia article: en

## DISH Q1422437
- name: Unagi
- other names: {"zh": "鰻・うなぎ"}
- description: the Japanese word for freshwater eel, a culinary ingredient
- countries: JP
- kinds: eel as food, fish dish
- ingredients: eel, Anguilla japonica
- has Wikipedia article: en

## DISH Q1423008
- name: Fliegenpilztomate
- other names: {"de": "Fliegenpilztomate"}
- countries: (none)
- kinds: dish

## DISH Q1423571
- name: Restaurationsbrot
- countries: (none)
- kinds: dish

## DISH Q1423725
- name: Cucumber salad
- description: simple salad of sliced cucumber
- countries: (none)
- kinds: salad, dish
- ingredients: cucumber
- has Wikipedia article: en

## DISH Q1426038
- name: Tyropatinam
- other names: {"de": "Tyropatinam"}
- countries: (none)
- kinds: dish

## DISH Q1426070
- name: Mlinci
- description: dish
- countries: HR
- kinds: food, bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q1426283
- name: Flachswickel
- other names: {"de": "Flachswickel"}
- countries: (none)
- kinds: viennoiserie

## DISH Q1427307
- name: Flatkaka
- description: Icelandic rye flatbread
- countries: IS
- kinds: food, flatbread
- ingredients: rye flour
- has Wikipedia article: en

## DISH Q1428452
- name: Flying Jacob
- other names: {"zh": "飞翔的雅各布"}
- description: Swedish casserole dish with chicken and banana
- countries: SE
- cuisines: Swedish cuisine
- kinds: casserole, chicken dish
- ingredients: peanut, chicken as food, whipped cream, hot sauce, cream, bacon, chicken, banana
- has Wikipedia article: en

## DISH Q1428477
- name: Мухомор
- other names: {"ru": "мухомор"}
- countries: (none)
- kinds: egg dish

## DISH Q14289397
- name: Rozijnenbrood
- other names: {"nl": "rozijnenbrood"}
- countries: (none)
- kinds: bread

## DISH Q1429469
- name: Florentine biscuit
- description: Italian pastry of nuts and fruit
- countries: (none)
- kinds: biscuit
- ingredients: honey
- has Wikipedia article: en

## DISH Q14320029
- name: Hoppelpoppel
- description: potato and egg casserole
- countries: (none)
- kinds: dish, potato dish
- ingredients: onion, scrambled eggs, potato, meat
- has Wikipedia article: en

## DISH Q1432109
- name: Kagemand
- description: Danish celebration cake
- countries: DK
- kinds: cake, birthday cake
- has Wikipedia article: en

## DISH Q1432535
- name: Chicken soup
- other names: {"zh": "鸡汤"}
- description: soup made from chicken
- countries: (none)
- kinds: food, soup, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q1432724
- name: Sujuk
- description: dry, spicy, fermented sausage of several Anatolian, Balkan, Middle Eastern and Central Asian cuisines
- countries: TR
- kinds: dish, dry sausage
- ingredients: minced meat, offal, spice
- has Wikipedia article: en

## DISH Q1432826
- name: Tartufo
- description: Italian ice cream
- countries: IT
- kinds: ice cream
- has Wikipedia article: en

## DISH Q1432988
- name: Kagami mochi
- other names: {"zh": "镜饼"}
- description: Japanese dessert consisting of 2 round mochi, the smaller placed atop the larger, and a daidai with an attached leaf on top, with a sheet of konbu and a skewer of dried persimmons under the mochi
- countries: JP
- kinds: mochi, New Year's decoration, New Year's food
- has Wikipedia article: en, zh

## DISH Q1433274
- name: Hexenkuss
- other names: {"de": "Hexenkuss"}
- countries: (none)
- kinds: dish

## DISH Q14333256
- name: Sesame roll
- description: sesame bread
- countries: (none)
- kinds: bread, baked good

## DISH Q1433558
- name: Cholent
- other names: {"zh": "乔伦特"}
- description: kosher stew
- countries: FR
- kinds: stew
- ingredients: Fabaceae, potato, meat
- has Wikipedia article: en

## DISH Q1435311
- name: Folar
- description: Portuguese bread
- countries: PT
- kinds: Easter bread
- has Wikipedia article: en

## DISH Q1435874
- name: Ugali
- other names: {"zh": "乌咖喱"}
- description: type of maize flour porridge made in Africa
- countries: KE
- kinds: dish, swallow
- ingredients: Mielie-meal, cornmeal
- has Wikipedia article: en, zh

## DISH Q14363592
- name: Bread soup
- other names: {"zh": "面包汤"}
- description: bread dish; type of soup
- countries: (none)
- kinds: soup, bread dish
- ingredients: staling
- has Wikipedia article: en

## DISH Q143771
- name: Zahnpflegekaugummi
- other names: {"de": "Zahnpflegekaugummi"}
- description: chewing gum made for dental care
- countries: (none)
- kinds: chewing gum

## DISH Q1444936
- name: Frankfurter Brenten
- description: tea biscuit specialty from Frankfurt
- countries: (none)
- kinds: cookie
- ingredients: marzipan

## DISH Q14468365
- name: Kuih
- other names: {"zh": "粿"}
- description: Bite-sized snack or dessert foods originating from Southeast Asia
- countries: ID, MY, SG, TW
- kinds: type of food or dish, pastry
- ingredients: rice flour, tapioca, egg as food, sugar, margarine, Pengkang, Hún-kué, Káu-chan-kóe, Gan Guê To, că̤, Red peach cake, Brown Sugar Steamed Cake, Bŏ̤-bŏ̤-guōi, kuih moho, Ō͘-kóe, mī-hún-kóe-á, chhiâng-pán, Savory rice pudding, sin den ban, Chháu-á-kóe, âng-ku-kóe, apam balik, Qingtuan, fun guo, imagawayaki, Chwee kueh, nian gao, youtiao, turnip cake
- has Wikipedia article: en, zh

## DISH Q1448660
- name: Pantāga
- countries: (none)
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q1450611
- name: Half sour pickle
- description: cucumber that has been pickled in brine for a short time
- countries: RU, PL, UA, BY
- cuisines: Russian cuisine, Polish cuisine, Ukrainian cuisine, Belarusian cuisine
- kinds: dish, pickle
- ingredients: cucumber

## DISH Q1451438
- name: Fratzen
- other names: {"de": "Fratzen"}
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q14517051
- name: Vruchtenbrood
- other names: {"nl": "vruchtenbrood"}
- countries: (none)
- kinds: bread

## DISH Q1451832
- name: Schlotfeger
- other names: {"de": "Schlotfeger"}
- countries: (none)
- kinds: viennoiserie

## DISH Q14523339
- name: Krapfen
- description: German sweet bread
- countries: (none)
- kinds: pastry

## DISH Q14524937
- name: Cronut
- other names: {"zh": "可颂甜甜圈"}
- description: a croissant-doughnut pastry invented by New York City pastry chef Dominique Ansel of Dominique Ansel Bakery
- countries: US
- kinds: doughnut, croissant, pastry
- has Wikipedia article: en, zh

## DISH Q1452513
- name: Pincho
- description: small snack, typically eaten in bars in Northern Spain
- countries: ES, FR
- cuisines: Basque cuisine, Spanish cuisine
- kinds: dish, skewer
- has Wikipedia article: en

## DISH Q14528540
- name: Zonnebloempittenbrood
- other names: {"nl": "zonnebloempittenbrood"}
- countries: (none)
- kinds: bread

## DISH Q14528707
- name: Zuidlaarderbol
- other names: {"nl": "Zuidlaarderbol"}
- countries: (none)
- kinds: food, bread

## DISH Q14543923
- name: Шылаплаві
- other names: {"be-tarask": "шылаплаві"}
- countries: GE
- kinds: rice dish
- ingredients: sheep meat, edible mushroom, rice

## DISH Q1455040
- name: Chebureki
- other names: {"zh": "切布雷克"}
- description: Crimean Tatar deep-fried turnover
- countries: (none)
- cuisines: Crimean Tatar cuisine
- kinds: fast food, stuffed pasta
- ingredients: vegetable oil, onion, animal fats and oils, lamb meat, flour, meat, mutton, egg as food, spice
- has Wikipedia article: en, zh

## DISH Q14552200
- name: Kadayif
- other names: {"zh": "Kadaif"}
- description: Turkish/Levantine/Balkanic pastry
- countries: (none)
- kinds: food, dessert, noodle
- ingredients: flour, drinking water
- has Wikipedia article: en, zh

## DISH Q14552548
- name: Mince pie
- other names: {"zh": "英式肉餡餅"}
- description: British sweet pie, filled with a mixture of dried fruits and spices, traditionally served during the Christmas season
- countries: GB
- cuisines: cuisine of the United States, British cuisine
- kinds: pie
- ingredients: shortcrust pastry
- has Wikipedia article: en, zh

## DISH Q1456217
- name: Honig-Salz-Brot
- countries: (none)
- kinds: bread

## DISH Q14594791
- name: Pinjaram cake
- description: Traditional Malay and Bajau snack originating from Malaysia
- countries: MY
- kinds: Kuih
- ingredients: corn starch, rice flour, coconut milk, sugar
- has Wikipedia article: en

## DISH Q14595838
- name: Amplang
- description: Indonesian fish cracker snack
- countries: ID
- kinds: snack, fish dish
- ingredients: garlic, Spanish mackerel, tapioca, Acanthocybium solandri, fish as food, broth, starch, baking powder, table salt
- has Wikipedia article: en

## DISH Q1459788
- name: Goiabada
- description: popular dessert throughout the Portuguese-speaking countries, made from guavas
- countries: BR
- kinds: fruit preparation, marmelade
- ingredients: guava, sugar
- has Wikipedia article: en

## DISH Q14601067
- name: Gypsy sauce
- description: sauce or demi-glace sauce used as an ingredient in dishes and as a condiment
- countries: DE
- kinds: condiment, à la zingara
- ingredients: onion, paprika, bell pepper, tomato paste
- has Wikipedia article: en

## DISH Q14609179
- name: Kelupis
- description: glutinous rice rolls
- countries: BN, MY
- kinds: glutinous rice
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q14624874
- name: Flantse
- other names: {"fr": "flantse"}
- countries: IT
- kinds: dessert

## DISH Q14635923
- name: Ampo snack
- description: Indonesian snack made of soil
- countries: (none)
- kinds: food, geophagy, dish
- ingredients: soil
- has Wikipedia article: en

## DISH Q1464898
- name: Frikandel
- description: fried meat product
- countries: (none)
- kinds: dish, sausage, minced meat
- ingredients: minced meat
- has Wikipedia article: en

## DISH Q14650718
- name: Whole wheat bread
- other names: {"zh": "全穀面包"}
- description: bread containing flour that is milled from wheat grains
- countries: (none)
- ingredients: whole-wheat flour
- has Wikipedia article: en, zh

## DISH Q1465158
- name: Fritada
- description: traditional Ecuadorian dish
- countries: EC
- kinds: meal, pork dish
- has Wikipedia article: en

## DISH Q1465330
- name: Fried ice cream
- other names: {"zh": "炸冰淇淋"}
- description: Coated, deep-fried dessert
- countries: US
- kinds: dessert, ice cream, deep-fried food
- ingredients: ice cream
- has Wikipedia article: en, zh

## DISH Q14675879
- name: Fafda
- description: Indian snack
- countries: IN
- cuisines: Indian cuisine
- kinds: snack
- has Wikipedia article: en

## DISH Q14675912
- name: Bok caang
- other names: {"zh": "煎薄鐺"}
- description: Cantonese food
- countries: CN
- cuisines: Cantonese cuisine
- kinds: pancake
- ingredients: chicken egg, wheat flour, Welsh onion
- has Wikipedia article: zh

## DISH Q1468150
- name: Gingerbread for sauce
- description: baked good used for making sauces
- countries: AT, CZ, DE
- kinds: viennoiserie
- ingredients: dough

## DISH Q14700806
- name: Scooped ice cream
- countries: (none)
- kinds: ice cream

## DISH Q1470812
- name: Fruit soup
- description: soup prepared using fruit as a primary ingredient
- countries: (none)
- kinds: soup
- ingredients: fruit
- has Wikipedia article: en

## DISH Q1471040
- name: Frutti di Martorana PAT
- other names: {"zh": "Frutti di Martorana PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, dessert, baked good
- ingredients: marzipan
- has Wikipedia article: en

## DISH Q1471200
- name: Fränkische Mehlklöße
- other names: {"de": "Fränkische Mehlklöße"}
- countries: (none)
- kinds: dish

## DISH Q1472342
- name: Fasnetsküchle
- description: pastry
- countries: (none)
- kinds: pastry

## DISH Q1472771
- name: Újházi
- description: Hungarian chicken soup
- countries: HU
- kinds: soup

## DISH Q1473422
- name: Ful medames
- other names: {"zh": "富爾"}
- description: Egyptian dish (salad of fava beans, chopped tomatoes, onion, parsley, lemon juice, olive oil, pepper and salt)
- countries: EG
- kinds: dish
- ingredients: broad bean, olive oil
- has Wikipedia article: en, zh

## DISH Q147372
- name: Zapiekanka
- other names: {"zh": "波蘭披薩"}
- description: Polish open-face sandwich made of half of a baguette or other long roll of bread
- countries: PL
- cuisines: Polish cuisine
- kinds: sandwich, street food
- ingredients: Agaricus bisporus, ketchup, cheese, fungi
- has Wikipedia article: en

## DISH Q1474369
- name: Funkenküchlein
- other names: {"de": "Funkenküchlein"}
- countries: (none)
- kinds: viennoiserie

## DISH Q14758321
- name: Bitterkoekje
- description: Dutch almond cookie
- countries: (none)
- kinds: food, cookie
- has Wikipedia article: en

## DISH Q147651
- name: Peanut butter
- other names: {"zh": "花生酱"}
- description: spread made primarily from ground dry roasted peanuts
- countries: CA, US
- kinds: food, dish, food paste, nut butter
- ingredients: peanut
- has Wikipedia article: en, zh

## DISH Q1476953
- name: Möpkenbrot
- other names: {"zh": "Möpkenbrot"}
- description: German pork and grain sausage
- countries: DE
- kinds: dish
- ingredients: rye flour, wheat flour, blood as food, pork
- has Wikipedia article: en, zh

## DISH Q14770547
- name: Glucose syrup
- other names: {"zh": "葡萄糖糖浆"}
- description: syrup made from the hydrolysis of starch
- countries: (none)
- kinds: Type of sugar, food ingredient, syrup
- ingredients: glucan 1,4-a-glucosidase, starch, amylase
- has Wikipedia article: en, zh

## DISH Q1477592
- name: Churchkhela
- other names: {"zh": "丘爾奇赫拉"}
- description: candle-shaped nut candy
- countries: GE
- cuisines: Georgian cuisine
- kinds: sweetmeat
- ingredients: grape juice, flour, nut
- has Wikipedia article: en, zh

## DISH Q14782277
- name: Carne de vinha d'alhos
- description: Portuguese dish, of meat marinated with garlic and wine
- countries: PT
- kinds: pork dish
- ingredients: garlic, thyme, paprika, bay leaf, white pepper, table salt, cayenne pepper, wine
- has Wikipedia article: en

## DISH Q14783691
- name: Waakye
- other names: {"zh": "瓦切"}
- description: Ghanaian food
- countries: GH
- cuisines: African cuisine
- kinds: food
- ingredients: bean, peanut oil, spaghetti, table salt, drinking water, rice, Capsicum annuum, Sorghum
- has Wikipedia article: en, zh

## DISH Q1479596
- name: Fërgesë
- description: Albanian egg dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q14798260
- name: Yeolmu-kimchi
- other names: {"zh": "韩国菜小萝卜泡菜"}
- description: Korean pickle of summer radish leaves
- countries: KR
- kinds: radish kimchi
- ingredients: yeolmu
- has Wikipedia article: en

## DISH Q14832965
- name: Western fried rice
- other names: {"zh": "西炒飯"}
- countries: HK
- kinds: fried rice
- has Wikipedia article: zh

## DISH Q1485640
- name: Tonno del Chianti
- description: Italian pork dish
- countries: IT
- kinds: dish
- ingredients: pork

## DISH Q148588
- name: Zaunerstollen
- description: sweet dish and dessert
- countries: (none)
- kinds: dessert
- ingredients: wafer cookie, nougat, chocolate

## DISH Q1488189
- name: Gabelbissen
- other names: {"de": "Gabelbissen"}
- countries: (none)
- kinds: fish dish

## DISH Q14906720
- name: Potato gnocchi
- description: Italian potato dumplings
- countries: IT
- kinds: gnocchi, potato-dough dumpling
- ingredients: potato, flour

## DISH Q14907198
- name: Roulade
- description: rolled meat dish
- countries: (none)
- kinds: meat dish, roll
- ingredients: roulades meat
- has Wikipedia article: en

## DISH Q14911969
- name: Pimentón de Mallorca
- description: Paprika of controlled origin produced in the region of Mallorca in the Balearic Islands, an autonomous region of Spain
- countries: (none)
- kinds: spice, paprika
- has Wikipedia article: en

## DISH Q14914664
- name: Cold sweet soup
- description: cold dish mostly in summer times
- countries: (none)
- kinds: dessert, dish, type of food or dish, soup, cold dishes
- has Wikipedia article: en

## DISH Q14916156
- name: Strapačky
- other names: {"zh": "斯特拉帕奇基"}
- description: dish of dumplings with cheese or sauerkraut
- countries: SK
- kinds: dish
- ingredients: halušky
- has Wikipedia article: en

## DISH Q14917347
- name: Jenang kudus
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, Dodol
- ingredients: glutinous rice flour, vegetable fat, Vanilla planifolia, flavoring, palm sugar, coconut milk, sugar

## DISH Q14917459
- name: Nasi becek
- other names: {"id": "nasi becek"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish
- ingredients: coconut milk, lamb meat, sate kambing, cooked rice

## DISH Q1491753
- name: Topset
- other names: {"de": "Topset"}
- countries: (none)
- kinds: chocolate bar
