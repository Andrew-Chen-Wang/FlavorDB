# Review batch names-036

## DISH Q26996564
- name: Bread and bakery products, others
- description: category of food
- countries: (none)
- kinds: baked good, bakery products, pastry, cakes and long-term cakes

## DISH Q26996677
- name: Pizzas, casseroles
- description: class of food
- countries: (none)
- kinds: Bread and bakery products, others

## DISH Q2700187
- name: Cup-a-Soup
- other names: {"zh": "Cup-a-Soup"}
- description: Instant soup product
- countries: (none)
- kinds: food product, food, soup
- has Wikipedia article: en, zh

## DISH Q2700600
- name: Amanattō
- other names: {"zh": "甘纳豆"}
- description: Japanese traditional confectionery
- countries: JP
- kinds: wagashi
- ingredients: Vigna angularis, sugar
- has Wikipedia article: en, zh

## DISH Q27031365
- name: Melton Mowbray pork pie
- description: pork pie made around Melton Mowbray
- countries: (none)
- kinds: pork pie
- ingredients: hot water crust pastry, pork

## DISH Q2706994
- name: Shortcake
- other names: {"zh": "水果酥饼"}
- description: type of dessert
- countries: GB
- kinds: food, cake
- ingredients: flour, butter
- has Wikipedia article: en, zh

## DISH Q2709619
- name: Lo mai gai
- other names: {"zh": "糯米鸡"}
- description: Cantonese leaf-wrapped dim sum
- countries: CN
- kinds: rice dish
- has Wikipedia article: en, zh

## DISH Q270997
- name: Rum ball
- description: truffle-like confection of cookie butter flavored with chocolate and rum
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q27103
- name: Hangwa
- other names: {"zh": "韩菓"}
- description: traditional Korean confectionery
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en, zh

## DISH Q2712621
- name: Hōtō
- other names: {"zh": "馎饦"}
- description: Japanese soup
- countries: JP
- kinds: type of food or dish, soup, nabemono, nikomi udon
- ingredients: miso soup, pumpkin
- has Wikipedia article: en, zh

## DISH Q2713498
- name: Choripán
- other names: {"zh": "阿根廷香腸三明治"}
- description: type of South American sandwich
- countries: AR
- kinds: sandwich
- ingredients: chorizo
- has Wikipedia article: en

## DISH Q2714248
- name: Brugse mokken
- other names: {"nl": "Brugse mokken"}
- countries: (none)
- kinds: food, cookie

## DISH Q27149881
- name: Erundopel
- other names: {"az": "Erundopel"}
- countries: RU
- kinds: salad
- ingredients: table salt, potato, onion, cucumber, fish as food, Clupea, olive oil, Cucumis sativus

## DISH Q2717981
- name: Hopjesvla
- other names: {"nl": "hopjesvla"}
- countries: (none)

## DISH Q2718618
- name: Kamameshi
- other names: {"zh": "釜飯"}
- description: one-pot Japanese rice dish
- countries: JP
- kinds: takikomi gohan
- has Wikipedia article: en, zh

## DISH Q2718625
- name: Tong sui
- other names: {"zh": "糖水"}
- description: sweet, warm soup or custard served as a dessert at the end of a meal in Cantonese cuisine
- countries: CN
- kinds: type of food or dish, soup, dish
- has Wikipedia article: en, zh

## DISH Q2720163
- name: Pan de muerto
- description: type of sweet roll traditionally baked in Mexico during the weeks leading up to the Día de Muertos
- countries: MX
- kinds: baked good, Mexican bread, sweet bread
- has Wikipedia article: en

## DISH Q2720330
- name: Korban Pesach
- other names: {"zh": "献祭"}
- description: the sacrifice that the Torah mandates the Israelites to ritually slaughter and eat on the first night of Pesach
- countries: DK
- kinds: religious concept, sacrifice, lamb, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q2721562
- name: Bhelpuri
- description: Indian snack
- countries: IN
- kinds: chaat, snack
- ingredients: puffed rice
- has Wikipedia article: en

## DISH Q2721752
- name: Murukku
- description: traditional snack of South India
- countries: IN
- kinds: dish, food
- ingredients: rice flour
- has Wikipedia article: en, zh

## DISH Q2721957
- name: Khaja
- description: Indian pastry
- countries: IN
- kinds: confectionery
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q272198
- name: Marshmallow
- other names: {"zh": "棉花糖"}
- description: sugar-based confection
- countries: US
- kinds: candy, confectionery
- ingredients: flavoring, corn syrup, gelatin, glucose, water
- has Wikipedia article: en, zh

## DISH Q2722122
- name: Panipuri
- other names: {"zh": "巴尼布里"}
- description: Indian snack
- countries: IN
- cuisines: Indian cuisine
- kinds: potato dish, chaat, snack
- ingredients: flour, chickpea, potato, onion, Chaat masala
- has Wikipedia article: en, zh

## DISH Q2722375
- name: Basundi
- description: Indian sweet
- countries: IN
- kinds: dessert, sweet dish
- ingredients: milk
- has Wikipedia article: en

## DISH Q2722559
- name: Blueberry pie
- other names: {"zh": "蓝莓派"}
- description: baked pastry with fruit filling
- countries: US
- kinds: sweet pie
- ingredients: blueberry
- has Wikipedia article: en, zh

## DISH Q27230949
- name: Flour confectionery products
- countries: (none)
- kinds: confectionery, Production of food industry by OKP

## DISH Q27230988
- name: Dry biscuits
- description: biscuits and crackers
- countries: (none)
- kinds: Bread and bakery products, others, flour confectionery products, cookies, biscuits, crackers

## DISH Q2723131
- name: Vada
- other names: {"zh": "瓦达"}
- description: category of savoury fried snacks from India
- countries: (none)
- kinds: snack, fritter, dish
- has Wikipedia article: en, zh

## DISH Q2723206
- name: Dal baati
- description: Indian dish of lentils and unleavened bread
- countries: (none)
- kinds: dish
- ingredients: dal
- has Wikipedia article: en

## DISH Q2723706
- name: Pongal
- description: popular rice dish
- countries: IN
- kinds: food, rice dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q27238206
- name: Cookies, biscuits, crackers
- other names: {"zh": "餅乾"}
- description: grouping of types of products in OKP (91 3031)
- countries: (none)
- kinds: flour confectionery products

## DISH Q2723949
- name: Dahi puri
- description: Indian food
- countries: IN
- kinds: chaat
- ingredients: sev
- has Wikipedia article: en

## DISH Q2723965
- name: Dhansak
- description: Indian dish
- countries: IN
- cuisines: Parsi cuisine
- kinds: dish, lamb dish, Indian curry, goat meat dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q2724847
- name: Idada
- description: steamed snack made from Rice and Urad
- countries: IN
- cuisines: Gujarati cuisine
- kinds: dish
- ingredients: curd, Vigna mungo, table salt, rice

## DISH Q272502
- name: Bagel
- other names: {"zh": "贝果"}
- description: torus-shaped bread product
- countries: PL
- cuisines: Jewish cuisine, Polish cuisine
- kinds: food, yeast bread, baranki
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q2725826
- name: Undhiyu
- description: Gujarati vegetable cuisine from India
- countries: IN
- cuisines: Gujarati cuisine
- kinds: dish
- ingredients: coconut, Sweet potato, vegetable, banana
- has Wikipedia article: en

## DISH Q2728614
- name: Kuler
- description: Sweet made from millet flour, Ghee and Jaggery
- countries: IN
- cuisines: Gujarati cuisine
- kinds: confectionery
- ingredients: jaggery, Pennisetum glaucum, ghee

## DISH Q2729581
- name: Mokkataart
- other names: {"nl": "mokkataart"}
- countries: (none)
- kinds: cake

## DISH Q272964
- name: Çäkçäk
- other names: {"zh": "恰克恰克"}
- description: deep-fried sweet dough
- countries: (none)
- kinds: food, candy
- ingredients: honey
- has Wikipedia article: en, zh

## DISH Q2730578
- name: Khichu
- description: snack made from rice flour
- countries: IN
- kinds: snack, food
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q2734043
- name: Vanila vlao
- other names: {"eo": "vanila vlao"}
- description: yellow viscous Dutch dairy product, sweet dessert
- countries: (none)

## DISH Q2734068
- name: Cheese sandwich
- other names: {"zh": "奶酪三明治"}
- description: sandwich including cheese
- countries: (none)
- kinds: dish, sandwich
- ingredients: cheese, bread
- has Wikipedia article: en

## DISH Q2738560
- name: Uierboord
- other names: {"nl": "uierboord"}
- countries: (none)
- kinds: dish

## DISH Q2739119
- name: Colomba di Pasqua
- other names: {"zh": "復活節鴿子蛋糕"}
- description: Italian traditional Easter cake
- countries: IT
- cuisines: Italian cuisine
- kinds: cake, Easter bread, sweet bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q2739210
- name: Thirteen desserts
- description: traditional Christmas of Provence.
- countries: (none)
- kinds: dessert, Christmas dessert
- ingredients: nougat
- has Wikipedia article: en

## DISH Q2740161
- name: Zwolse balletjes
- other names: {"nl": "Zwolse balletjes"}
- countries: (none)
- kinds: sweetmeat

## DISH Q274151
- name: Fried egg
- other names: {"zh": "煎蛋"}
- description: fresh eggs fried whole with minimal accompaniment
- countries: (none)
- kinds: food, dish
- ingredients: chicken egg, duck egg, egg as food
- has Wikipedia article: en, zh

## DISH Q2742493
- name: Bonda
- description: Indian Food
- countries: IN
- kinds: potato dish
- ingredients: besan
- has Wikipedia article: en

## DISH Q2743088
- name: Chocolate coins
- other names: {"zh": "巧克力金币"}
- description: gold foil covered chocolates in the shape of coins
- countries: (none)
- kinds: chocolate
- has Wikipedia article: en, zh

## DISH Q27442274
- name: Countess (shortbread)
- description: Guianan shortbread cake
- countries: FR
- kinds: shortbread
- ingredients: flour
- has Wikipedia article: en

## DISH Q2744577
- name: Koliva
- description: ritual food in the Eastern Orthodox Church
- countries: (none)
- kinds: porridge, dish, bread
- ingredients: walnut, almond, cinnamon, sugar, wheat, sesame seed, cornmeal, hazelnut
- has Wikipedia article: en

## DISH Q2746056
- name: Krabsalade
- other names: {"nl": "Krabsalade"}
- countries: (none)
- kinds: salad

## DISH Q2746070
- name: Canelé
- other names: {"zh": "可麗露"}
- description: small French pastry
- countries: FR
- kinds: pastry
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q2746599
- name: Tumpeng
- other names: {"zh": "印尼薑黃飯"}
- description: Indonesian rice dish molded into a mountain shape and served with various side dishes originating from Java island
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, rice dish
- ingredients: cooked rice, Tempeh, egg as food, rice, chicken
- has Wikipedia article: en

## DISH Q2746948
- name: Oreilles de crisse
- description: quebec dish (food)
- countries: (none)
- kinds: pork dish
- ingredients: bacon
- has Wikipedia article: en

## DISH Q2748359
- name: Saag
- other names: {"zh": "印度菠菜薯仔咖喱"}
- description: Indian Food
- countries: (none)
- kinds: Indian curry
- has Wikipedia article: en

## DISH Q2748641
- name: Nikumaki onigiri
- description: rice ball wrapped with meat
- countries: JP
- kinds: onigiri

## DISH Q2749146
- name: Karintō
- other names: {"zh": "花林糖"}
- description: traditional Japanese snack food
- countries: JP
- kinds: snack, wagashi
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q27493928
- name: Winter ice cream
- description: Hungarian confectionary
- countries: HU
- kinds: snack, confectionery
- ingredients: compound chocolate, buttercream, ganache, wafer cookie, dark chocolate
- has Wikipedia article: en

## DISH Q27500854
- name: Peruvian ceviche
- description: traditional dish widely eaten in Peru
- countries: PE
- cuisines: Peruvian cuisine
- kinds: raw fish dish, fish dish
- ingredients: lemon juice, fish as food, chili pepper, onion
- has Wikipedia article: en

## DISH Q2750311
- name: Brokmop
- other names: {"nl": "brokmop"}
- countries: (none)
- kinds: pastry

## DISH Q2750595
- name: Napoleon Sweets
- description: type of candy mostly from the Benelux
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q27526227
- name: Opzetkaakje
- other names: {"nl": "opzetkaakje"}
- countries: (none)
- kinds: food, biscuit

## DISH Q275273
- name: Loimukala
- description: Finnish fish dish
- countries: FI
- kinds: fish dish

## DISH Q275540
- name: Rich tea
- other names: {"zh": "Rich tea"}
- description: type of sweet biscuit
- countries: GB
- cuisines: British cuisine
- kinds: biscuit
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q27554718
- name: Макароны
- other names: {"ru": "макароны"}
- countries: (none)
- kinds: macaroni and analogous flour products, tube-shaped macaroni products

## DISH Q27554838
- name: Вермишель короткая
- other names: {"ru": "вермишель короткая"}
- countries: (none)
- kinds: vermicelli, macaroni and analogous flour products, short macaroni products

## DISH Q27554882
- name: Long macaroni products
- description: type of pasta
- countries: (none)
- kinds: pasta, type of pasta

## DISH Q27554971
- name: Short macaroni products
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta

## DISH Q27555202
- name: Вермишель длинная
- other names: {"ru": "вермишель длинная"}
- countries: (none)
- kinds: vermicelli, macaroni and analogous flour products, long macaroni products

## DISH Q27555277
- name: Tube-shaped macaroni products
- countries: (none)
- kinds: pasta, type of pasta

## DISH Q27555297
- name: String-like macaroni products
- countries: (none)
- kinds: pasta

## DISH Q27555355
- name: Ленточные макаронные изделия
- other names: {"ru": "ленточные макаронные изделия"}
- countries: (none)
- kinds: pasta

## DISH Q27555639
- name: Рожки
- other names: {"ru": "рожки"}
- description: subtype of tube-shaped macaroni products
- countries: (none)
- kinds: pasta, macaroni and analogous flour products, tube-shaped macaroni products

## DISH Q27555874
- name: Перья
- other names: {"ru": "перья"}
- countries: (none)
- kinds: pasta, macaroni and analogous flour products, tube-shaped macaroni products

## DISH Q275621
- name: Smørrebrød
- other names: {"zh": "开放式三明治"}
- description: Danish/Norwegian open sandwich
- countries: DK
- cuisines: Danish cuisine
- kinds: food, open sandwich
- ingredients: rugbrød, butter, spread, fish as food, side dish, meat, cheese, cold cut
- has Wikipedia article: en

## DISH Q27565875
- name: Изделия макаронные фигурные
- other names: {"ru": "изделия макаронные фигурные"}
- countries: (none)
- kinds: pasta, macaroni and analogous flour products

## DISH Q27566245
- name: Лапша короткая
- other names: {"ru": "лапша короткая"}
- countries: (none)
- kinds: macaroni and analogous flour products, short macaroni products

## DISH Q27566359
- name: Лапша длинная
- other names: {"ru": "лапша длинная"}
- countries: (none)
- kinds: macaroni and analogous flour products, long macaroni products

## DISH Q27566431
- name: Лапша
- other names: {"ru": "лапша"}
- countries: (none)
- kinds: noodle, macaroni and analogous flour products

## DISH Q27566972
- name: Narrow lapsha
- countries: (none)
- kinds: noodle, dish

## DISH Q27567101
- name: Wide lapsha
- description: Russian noodle
- countries: (none)
- kinds: noodle, dish

## DISH Q27567859
- name: Вермишель-паутинка
- other names: {"ru": "вермишель-паутинка"}
- countries: (none)
- kinds: vermicelli

## DISH Q27567947
- name: Вермишель обыкновенная
- other names: {"ru": "вермишель обыкновенная"}
- countries: (none)
- kinds: vermicelli

## DISH Q27568316
- name: Вермишель любительская
- other names: {"ru": "вермишель любительская"}
- countries: (none)
- kinds: vermicelli

## DISH Q27569213
- name: Соломка
- other names: {"ru": "соломка"}
- countries: (none)
- kinds: tube-shaped macaroni products

## DISH Q27569218
- name: Обыкновенные трубчатые макаронные изделия
- other names: {"ru": "обыкновенные трубчатые макаронные изделия"}
- countries: (none)
- kinds: tube-shaped macaroni products

## DISH Q27569223
- name: Любительские трубчатые макаронные изделия
- other names: {"ru": "любительские трубчатые макаронные изделия"}
- countries: (none)
- kinds: tube-shaped macaroni products

## DISH Q27569293
- name: Мелкий формат макаронных изделий
- other names: {"ru": "мелкий формат макаронных изделий"}
- countries: (none)
- kinds: pasta

## DISH Q2756985
- name: Agedashi dōfu
- other names: {"zh": "揚出豆腐"}
- description: Japanese tofu dish
- countries: JP
- kinds: dish, Agemono
- ingredients: Japanese radish, tentsuyu, potato starch, tofu
- has Wikipedia article: en, zh

## DISH Q27572221
- name: Durum wheat pasta
- countries: (none)
- kinds: pasta
- ingredients: durum wheat

## DISH Q2757253
- name: Cream soup
- other names: {"zh": "奶油濃湯"}
- description: soup made with cream
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en, zh

## DISH Q27574079
- name: Изделия макаронные короткие из пшеничной муки прочие
- other names: {"ru": "Изделия макаронные короткие из пшеничной муки прочие"}
- countries: (none)
- kinds: macaroni and analogous flour products, short macaroni products

## DISH Q27574098
- name: Макаронные изделия группы Б
- other names: {"ru": "макаронные изделия группы Б"}
- countries: (none)
- kinds: pasta

## DISH Q27576302
- name: Gesztenyepüré
- description: chestnut dessert
- countries: AT
- kinds: sweet dish
- ingredients: chestnut, whipped cream

## DISH Q2757730
- name: Namasu
- description: Japanese dish
- countries: JP
- kinds: seafood dish, vegetable dish
- has Wikipedia article: en

## DISH Q27612968
- name: Putra
- description: Latvian dish
- countries: LV
- kinds: porridge, dish

## DISH Q27613048
- name: Макаронные изделия группы В
- other names: {"ru": "макаронные изделия группы В"}
- countries: (none)
- kinds: pasta

## DISH Q27642822
- name: Chocolate and sugar confectionery
- countries: (none)
- kinds: confectionery, cocoa, chocolate and sugar confectionery, as well as services

## DISH Q27643555
- name: Fruit preserved by sugar
- countries: (none)

## DISH Q27643676
- name: Nuts preserved by sugar
- countries: (none)

## DISH Q27643978
- name: Фрукты и орехи тропические засахаренные
- other names: {"ru": "Фрукты и орехи тропические засахаренные"}
- countries: (none)

## DISH Q27643999
- name: Вишня и черешня засахаренные
- other names: {"ru": "Вишня и черешня засахаренные"}
- countries: (none)
- kinds: fruit preserved by sugar

## DISH Q27645375
- name: Sliced bread
- other names: {"zh": "吐司"}
- description: loaf of bread that has been pre-sliced with a machine
- countries: (none)
- kinds: bread
- ingredients: slice of bread
- has Wikipedia article: en, zh

## DISH Q2769472
- name: Caldeirada
- other names: {"zh": "卡尔德拉达"}
- description: fish stew
- countries: PT
- kinds: fish dish
- ingredients: fish as food
- has Wikipedia article: en

## DISH Q2771664
- name: Locho
- description: snack food from Gujarat, India
- countries: IN
- kinds: snack
- ingredients: besan
- has Wikipedia article: en

## DISH Q27755435
- name: Bilo-bilo
- description: Filipino dessert of small rice balls in coconut milk
- countries: PH
- kinds: dessert
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q2775735
- name: Sukhdi
- description: Indian Food
- countries: IN
- kinds: confectionery
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q277628
- name: Dark chocolate
- other names: {"zh": "黑巧克力"}
- description: chocolate with high cocoa percentages
- countries: (none)
- kinds: types of chocolate, chocolate
- has Wikipedia article: en, zh

## DISH Q2777639
- name: Mofletta
- description: Maghrebi Jewish pancake
- countries: (none)
- kinds: food, crêpe
- ingredients: oil, flour, water
- has Wikipedia article: en

## DISH Q2778090
- name: Koulourakia
- description: Greek Easter cookie
- countries: GR
- kinds: pastry
- ingredients: flour, butter
- has Wikipedia article: en

## DISH Q2778490
- name: Brabants worstenbroodje
- description: Dutch snack
- countries: (none)
- kinds: snack, worstenbrood
- has Wikipedia article: en

## DISH Q2778993
- name: Ocopa
- description: Peruvian food dish
- countries: PE
- kinds: meal, entrée
- ingredients: aji amarillo, evaporated milk, fresh cheese, Tagetes minuta
- has Wikipedia article: en

## DISH Q2782605
- name: Pistolet
- description: Belgian round bun
- countries: BE
- kinds: bread roll
- has Wikipedia article: en

## DISH Q2785975
- name: Dagobert
- description: sandwich from Belgium
- countries: BE
- kinds: dish, submarine sandwich
- ingredients: crudités, ham, mayonnaise, cheese
- has Wikipedia article: en

## DISH Q27862345
- name: Chicken and rice
- other names: {"zh": "雞肉飯"}
- countries: (none)
- kinds: rice dish, chicken dish
- ingredients: chicken as food, rice
- has Wikipedia article: en, zh

## DISH Q27864045
- name: Kilwiküchle
- other names: {"de": "Kilwiküchle"}
- countries: (none)
- kinds: Fasnetsküchle

## DISH Q27884833
- name: Gingerbread confectionary
- description: food like Russian pryaniki and kovrizhki
- countries: (none)
- kinds: flour confectionery products, Gingerbread and the like; sweet biscuits; waffles and wafers

## DISH Q27885036
- name: Пряники сырцовые
- other names: {"ru": "пряники сырцовые"}
- countries: (none)
- kinds: pryanik, gingerbread confectionary

## DISH Q27885038
- name: Пряники заварные
- other names: {"ru": "пряники заварные"}
- countries: (none)
- kinds: pryanik, gingerbread confectionary

## DISH Q27885043
- name: Виды пряников и коврижек другие
- other names: {"ru": "Виды пряников и коврижек другие"}
- countries: (none)
- kinds: gingerbread confectionary

## DISH Q27885051
- name: Пряники из обрезков от пирожных
- other names: {"ru": "Пряники из обрезков от пирожных"}
- countries: (none)

## DISH Q27885369
- name: Коржики
- other names: {"ru": "Коржики"}
- countries: (none)

## DISH Q27889343
- name: Black bread
- other names: {"zh": "黑面包"}
- description: type of rye bread
- countries: (none)
- kinds: rye bread

## DISH Q27891575
- name: 渥美沢庵
- other names: {"ja": "渥美沢庵"}
- countries: JP
- kinds: takuan

## DISH Q27909648
- name: Hủ tiếu
- description: Vietnamese soup dish
- countries: VN
- kinds: dish
- has Wikipedia article: en

## DISH Q27926579
- name: Hackfleischgericht
- other names: {"de": "Hackfleischgericht"}
- countries: (none)
- kinds: dish

## DISH Q27940458
- name: Idukki Gold
- description: cannabis strain
- countries: IN
- kinds: strain of cannabis
- has Wikipedia article: en

## DISH Q279575
- name: Khachapuri
- other names: {"zh": "起司麵包"}
- description: traditional Georgian dish of cheese-filled bread
- countries: GE
- cuisines: Georgian cuisine
- kinds: food, pie
- ingredients: chicken egg, flour, cheese, bread
- has Wikipedia article: en, zh

## DISH Q27958662
- name: Prdelačka
- description: Czech pork blood soup made during the pig slaughter season
- countries: CZ
- kinds: pork blood soup
- has Wikipedia article: en

## DISH Q27960436
- name: Eucalyptus honey
- description: type of honey
- countries: (none)
- kinds: honey
- has Wikipedia article: en

## DISH Q27961089
- name: Pasticcio di maccheroni
- description: Italian macaroni pie
- countries: IT
- kinds: pasta dish

## DISH Q27962923
- name: Taktouka
- other names: {"zh": "Taktouka"}
- description: a dish similar to Shakshuka, without the eggs
- countries: MA
- cuisines: Moroccan cuisine
- kinds: dish, salad
- ingredients: garlic, paprika, bell pepper, olive oil, tomato
- has Wikipedia article: en, zh

## DISH Q27963899
- name: Pecel Pitik
- description: chicken rice dish from Indonesian
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, chicken dish
- ingredients: siling labuyo, grated coconut, chicken as food
- has Wikipedia article: en

## DISH Q2796648
- name: Borsthoning
- other names: {"nl": "Borsthoning"}
- countries: (none)
- kinds: candy
- ingredients: potato syrup

## DISH Q27969748
- name: Olla Ferroviaria
- other names: {"es": "Olla Ferroviaria"}
- description: bean stew from North Spain
- countries: (none)
- kinds: dish
- ingredients: kidney bean

## DISH Q27972320
- name: Kuai tiao
- description: Thai noodle dish
- countries: (none)
- kinds: kóe-tiâu

## DISH Q27972389
- name: Ramen in Niigata Prefecture
- countries: (none)
- kinds: ramen

## DISH Q27972934
- name: Buchimgae
- other names: {"zh": "韓國煎餅"}
- description: Korean pancake category
- countries: (none)
- kinds: pancake
- ingredients: fish
- has Wikipedia article: en, zh

## DISH Q2798667
- name: Claypot rice
- other names: {"zh": "锅饭"}
- description: Asian rice dish
- countries: CN
- kinds: type of food or dish, rice dish
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q27994933
- name: 血液料理
- other names: {"ja": "血液料理"}
- description: dish made from blood
- countries: (none)
- kinds: dish
- ingredients: blood as food

## DISH Q27998933
- name: Alani
- description: traditional Armenian sweet
- countries: AM
- cuisines: Armenian cuisine
- kinds: dessert
- ingredients: cinnamon, sugar, peach, walnut
- has Wikipedia article: en

## DISH Q28000941
- name: Eiernockerl
- description: simple and popular Austrian culinary dish
- countries: AT
- kinds: dish
- ingredients: peppercorn, egg as food, nutmeg, Allium schoenoprasum, yeast, butter, table salt, milk
- has Wikipedia article: en

## DISH Q28006932
- name: Пестил
- other names: {"bg": "Пестил"}
- countries: (none)
- kinds: dessert

## DISH Q28015549
- name: Sohari
- description: mithila deep-fried flat bread, unleavened wheat flatbread
- countries: IN, NP
- cuisines: Nepalese cuisine, North Indian cuisine
- kinds: Prasad, dish
- ingredients: atta
- has Wikipedia article: en

## DISH Q28017924
- name: Myeongnan-jeot
- other names: {"zh": "明卵酱"}
- countries: (none)
- kinds: jeotgal
- ingredients: pollock roe

## DISH Q28026148
- name: Petit Jésus
- other names: {"fr": "Petit Jésus"}
- countries: (none)
- kinds: candy

## DISH Q280354
- name: Semmelknödel
- description: food
- countries: AT, IT
- kinds: knödel, bread dish
- ingredients: chicken egg, onion, bread roll
- has Wikipedia article: en

## DISH Q28043781
- name: Jumbo slice
- description: Variety of pizza made popular in Washington, D.C. and New York City
- countries: (none)
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q2804868
- name: Faraoa 'ipo
- description: ball bread from Tuamotu, French Polynesia
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q28054406
- name: Ham chim peng
- other names: {"zh": "鹹煎餅"}
- description: Chinese fried snack
- countries: CN
- kinds: doughnut
- has Wikipedia article: en, zh

## DISH Q28057383
- name: Cardinal slice
- description: layered meringue cake
- countries: AT
- kinds: sweet dish
- ingredients: meringue
- has Wikipedia article: en

## DISH Q2806580
- name: Gangmaker
- description: cookie
- countries: (none)
- kinds: cookie

## DISH Q28067714
- name: 八千代おこし
- other names: {"ja": "八千代おこし"}
- countries: (none)
- kinds: okoshi

## DISH Q28068311
- name: Funamori
- description: sashimi on a boat-like platform
- countries: JP
- kinds: sashimi, food presentation

## DISH Q28099834
- name: Indian curry
- countries: IN
- cuisines: Indian cuisine
- kinds: curry

## DISH Q281278
- name: Olivier salad
- other names: {"zh": "俄国沙拉"}
- description: salad dish
- countries: RU
- cuisines: Russian cuisine, Soviet cuisine
- kinds: dish, salad, zakuski
- ingredients: potato, hard-boiled egg, preserved peas, cucumber, Salzgurke, mayonnaise, egg as food, onion, meat, carrot
- has Wikipedia article: en, zh

## DISH Q28130016
- name: Bamia
- description: regional stew prepared using lamb, okra and tomatoes
- countries: (none)
- kinds: dish
- ingredients: okra, lamb meat
- has Wikipedia article: en

## DISH Q28130462
- name: Mixmole de pescado
- description: dish in Mexican cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q28132082
- name: Gyeongdan
- description: boiled rice cake balls
- countries: (none)
- kinds: rice ball
- has Wikipedia article: en

## DISH Q28134486
- name: Baranki
- description: class of products including bubliki, baranki and sushki breads
- countries: RU
- kinds: food, baked good, production of sugar and bakery industry
- ingredients: wheat flour

## DISH Q28134524
- name: Trancapecho
- description: Bolivian Sandwich
- countries: (none)
- kinds: sandwich, meal
- has Wikipedia article: en

## DISH Q28136385
- name: Kawlata
- description: Maltese soup
- countries: (none)
- kinds: type of food or dish, soup
- has Wikipedia article: en

## DISH Q28148567
- name: Miel de Liébana
- description: honey from the region of Liébana
- countries: ES
- kinds: honey

## DISH Q28152405
- name: Kračun
- other names: {"cs": "Kračun"}
- countries: SK
- kinds: pastry

## DISH Q28154305
- name: Mangalorean Chicken Sukka
- description: Indian Chicken dish native to Mangalore and Udupi region in Karnataka
- countries: IN
- kinds: chicken dish
- ingredients: spice, chicken
- has Wikipedia article: en

## DISH Q28154814
- name: Pundi
- description: Indian rice dumpling
- countries: IN
- cuisines: Keralan cuisine, Karnataka cuisine
- kinds: rice dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q28155445
- name: Albaloo polo
- description: Iranian rice dish
- countries: IR
- kinds: rice dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q28155493
- name: Lime soup
- description: Mexican soup
- countries: MX
- cuisines: Mexican cuisine
- kinds: soup
- ingredients: broth, lime, tortilla, tomato, chicken as food
- has Wikipedia article: en

## DISH Q281558
- name: Hot chicken
- other names: {"zh": "納什維爾辣炸雞"}
- description: chicken dish from Nashville, Tennessee, US; bone-in chicken pieces, marinated in a water-based blend of seasoning, floured, fried, sauced using a paste with cayenne pepper, served on slices of white bread with pickle chips
- countries: US
- kinds: fried chicken, chicken dish
- ingredients: chicken as food, cayenne pepper
- has Wikipedia article: en, zh

## DISH Q28163307
- name: Curly fries
- description: French fries that are curly
- countries: (none)
- kinds: fries
- has Wikipedia article: en

## DISH Q28163585
- name: Bombay potato
- description: potato dish
- countries: IN
- cuisines: Indian cuisine
- kinds: potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q28163731
- name: Ayam masak kicap
- description: Indonesian dish
- countries: ID
- kinds: dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q28163754
- name: Babi kecap
- description: Indonesian dish
- countries: ID
- kinds: dish
- ingredients: garlic, ginger, Illicium verum, kecap manis, oyster sauce, scallion, sesame oil, pork
- has Wikipedia article: en

## DISH Q28163759
- name: Sekba
- other names: {"zh": "塞克巴"}
- description: Indonesian braised pork dish
- countries: ID
- kinds: dish
- has Wikipedia article: en

## DISH Q28169338
- name: Sai bhaji
- description: Sindhi curry dish
- countries: (none)
- kinds: curry
- ingredients: dal
- has Wikipedia article: en

## DISH Q28169436
- name: Chapli kebab
- description: Pashtun-style minced kebab
- countries: PK
- kinds: kebab, meat dish
- ingredients: minced meat
- has Wikipedia article: en

## DISH Q28170057
- name: Kabiraji
- description: Indian dish
- countries: (none)
- kinds: type of food or dish, cutlet
- has Wikipedia article: en

## DISH Q28172393
- name: Paneer makhani
- description: dish of paneer, butter and masala
- countries: IN
- kinds: curry, paneer
- ingredients: paneer, masala, butter
- has Wikipedia article: en

## DISH Q28173633
- name: Bread pakora
- description: Indian fried snack
- countries: (none)
- kinds: street food
- ingredients: besan, spice, bread
- has Wikipedia article: en

## DISH Q281751
- name: Spanish omelette
- other names: {"zh": "馬鈴薯蛋餅"}
- description: egg, potato and onion dish .
- countries: ES
- cuisines: Spanish cuisine
- kinds: appetizer, potato dish, egg dish
- ingredients: onion, olive oil, table salt, potato, chicken egg
- has Wikipedia article: en, zh

## DISH Q28187073
- name: Lok-lok
- description: Malaysian street food
- countries: MY
- kinds: street food
- has Wikipedia article: en

## DISH Q28190668
- name: Khingalsh
- description: chechen traditional pie
- countries: RU
- cuisines: Chechen cuisine
- kinds: food
- has Wikipedia article: en

## DISH Q28195205
- name: Ladera
- other names: {"zh": "拉德拉"}
- description: vegetables cooked in olive oil
- countries: GR
- cuisines: Greek cuisine
- kinds: vegetable dish
- ingredients: olive oil, spice, vegetable
- has Wikipedia article: en

## DISH Q28197096
- name: Daing
- description: fish preserved by drying, as a staple of Philippine cuisine
- countries: PH
- kinds: fish dish
- has Wikipedia article: en

## DISH Q28197100
- name: Jijimi
- description: Korean stew category
- countries: KR
- cuisines: Korean cuisine
- kinds: dish, stew
- has Wikipedia article: en

## DISH Q28197119
- name: Sinangag
- description: Filipino fried rice dish
- countries: PH
- kinds: rice dish
- has Wikipedia article: en

## DISH Q28197217
- name: Usipa
- description: dried fish eaten in Malawi and Mozambique
- countries: MW, MZ
- kinds: dried fish, food
- has Wikipedia article: en

## DISH Q28197390
- name: Bánh tráng nướng
- description: Rice flour dish
- countries: (none)
- kinds: street food
- has Wikipedia article: en

## DISH Q2820735
- name: Abbaye de Tamié
- description: cheese
- countries: FR
- kinds: pressed uncooked cheese, French cheese, cow's-milk cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q28208795
- name: Eru
- description: Cameroonian eru–based soup
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q28208892
- name: Everything bagel
- other names: {"zh": "什锦百吉饼"}
- description: baked circular bread roll with multiple seed toppings
- countries: US
- kinds: bagel
- has Wikipedia article: en

## DISH Q28209622
- name: Candy Raisins
- description: American soft jujube candy
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q2821672
- name: Ablo
- description: traditional white cake in West Africa
- countries: BJ, CI, TG
- kinds: dish

## DISH Q28219522
- name: Satti
- description: southeast Asian satay
- countries: (none)
- kinds: satay, meat dish
- ingredients: ketupat, chicken as food, coconut milk, annatto, chili pepper, peanut butter
- has Wikipedia article: en

## DISH Q28220060
- name: Sausage and peppers
- other names: {"zh": "香腸和辣椒"}
- description: sausage dish
- countries: (none)
- kinds: dish
- ingredients: Italian sausage, bell pepper
- has Wikipedia article: en, zh

## DISH Q28223173
- name: Ostrich stew
- description: South African stew made with ostrich meat
- countries: (none)
- kinds: stew
- ingredients: ostrich meat
- has Wikipedia article: en

## DISH Q28223958
- name: Da jiu-jia
- other names: {"zh": "大救驾"}
- description: Chinese dish
- countries: (none)
- kinds: dish
- ingredients: erkuai
- has Wikipedia article: en, zh

## DISH Q28224295
- name: Wenzhou pig powder
- description: Chinese snack
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q28224410
- name: 籺(hé)
- other names: {"zh": "籺"}
- description: wheat or rice pastry
- countries: CN
- kinds: pastry
- has Wikipedia article: en, zh

## DISH Q28224428
- name: Tao kuish
- description: Chinese food
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q28224446
- name: Osmanthus cake
- other names: {"zh": "桂花糕"}
- description: Chinese pastry
- countries: CN
- cuisines: Chinese cuisine
- kinds: cake, dessert, dish, gelatin dessert
- ingredients: glutinous rice flour, goji, Osmanthus fragrans, rock candy
- has Wikipedia article: en, zh

## DISH Q28228815
- name: Troccoli
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: durum wheat semolina
- has Wikipedia article: en

## DISH Q2826164
- name: Africain
- description: pastry
- countries: FR
- kinds: pastry, Iced bun

## DISH Q282620
- name: Vetkoek
- description: food
- countries: ZA
- kinds: food, fried dough
- ingredients: dough
- has Wikipedia article: en

## DISH Q2826923
- name: Lamb in Chilindrón
- description: lamb stew from Spanish cuisine
- countries: (none)
- kinds: lamb dish
- ingredients: sheep meat, tomato sauce, vegetable
- has Wikipedia article: en

## DISH Q2827137
- name: Agriade saint-gilloise
- other names: {"fr": "Agriade saint-gilloise"}
- countries: (none)
- kinds: meat dish
- ingredients: chuck steak

## DISH Q2827721
- name: Ahriche
- description: Moroccan dish
- countries: MA
- kinds: dish
- has Wikipedia article: en

## DISH Q2827931
- name: Black garlic
- other names: {"zh": "黑蒜"}
- description: aged garlic
- countries: (none)
- kinds: dish, garlic
- ingredients: garlic
- has Wikipedia article: en, zh

## DISH Q2828870
- name: Ajo Morado de Las Pedroñeras
- countries: ES
- kinds: garlic

## DISH Q2829131
- name: Akpeteshie
- description: national spirit of Ghana
- countries: GH
- kinds: liquor
- ingredients: palm wine
- has Wikipedia article: en

## DISH Q2829733
- name: Andalouse sauce
- description: Belgian sauce
- countries: BE
- kinds: condiment, sauce
- ingredients: tomato paste, Pimiento, mayonnaise
- has Wikipedia article: en

## DISH Q2831860
- name: KleinsteSoepFabriek
- other names: {"nl": "KleinsteSoepFabriek"}
- countries: (none)
- kinds: food, soup

## DISH Q283231
- name: Aioli
- description: Provençal sauce made of garlic, olive oil, usually egg yolks, and seasonings
- countries: FR
- kinds: condiment, emulsion, garlic sauce
- ingredients: olive oil, garlic
- has Wikipedia article: en

## DISH Q2834371
- name: Tequeño
- description: Latin American snack.
- countries: VE
- cuisines: Venezuelan cuisine
- kinds: meal, type of food or dish, food, bread
- ingredients: dough, flour, table salt, cheese
- has Wikipedia article: en

## DISH Q2835232
- name: Pasembur
- other names: {"zh": "鮮魚印式沙拉"}
- description: Malaysian cuisine
- countries: IN
- kinds: food, salad, human food
- ingredients: boiled potatoes, hard-boiled egg, turnip, cucumber, tofu
- has Wikipedia article: en

## DISH Q2835652
- name: Judías de El Barco de Ávila
- description: Beans with designation of origin, province of Ávila, Spain
- countries: ES
- kinds: dish, food
- ingredients: bean
- has Wikipedia article: en

## DISH Q2837252
- name: Alivenci
- description: traditional Moldavian custart tart
- countries: MD
- kinds: pastry
- ingredients: milk
- has Wikipedia article: en

## DISH Q2838783
- name: Jamón de Trevélez
- description: Spanish cured ham
- countries: (none)
- kinds: jamón

## DISH Q2839025
- name: Alléluia
- description: French pastry
- countries: FR
- kinds: pastry

## DISH Q2839137
- name: Almojábana
- description: bread
- countries: CO
- kinds: bread, fritter, baked good
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q2839295
- name: Alu chat
- description: Indian snack
- countries: IN
- kinds: chaat, snack, potato salad, street food
- ingredients: potato
- has Wikipedia article: en

## DISH Q2839297
- name: Aloo gosht
- description: Curry with meat and potatoes
- countries: PK
- kinds: potato dish, lamb dish, chicken dish, Indian curry
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q2839298
- name: Aloo paratha
- description: a type of bread, consist of unleavened dough stuffed with a spiced mixture of mashed potato
- countries: IN
- cuisines: Indian cuisine
- kinds: bread, potato dish
- ingredients: ghee, paratha, flour, butter, potato
- has Wikipedia article: en

## DISH Q2839299
- name: Aloo mutter
- description: North Indian dish
- countries: IN
- kinds: potato dish
- ingredients: pea, potato
- has Wikipedia article: en

## DISH Q2839301
- name: Aloo pie
- description: Trinidadian fast food dish
- countries: TT
- cuisines: Caribbean cuisine
- kinds: potato dish, pie
- ingredients: pastry
- has Wikipedia article: en

## DISH Q2839342
- name: Alouettes sans tête
- countries: (none)
- kinds: dish

## DISH Q28401536
- name: Chicago-style relish
- description: condiment
- countries: US
- cuisines: cuisine of the Midwestern United States
- kinds: pickle relish
- has Wikipedia article: en

## DISH Q28402504
- name: New England-style hot dog bun
- other names: {"zh": "新英格蘭式熱狗麵包"}
- description: regional bread roll
- countries: US
- kinds: hot dog bun
- has Wikipedia article: en

## DISH Q28402897
- name: Edikang Ikong
- description: soup native to the Efik people in Nigeria
- countries: NG
- cuisines: Nigerian cuisine
- kinds: substance, dish, human food
- ingredients: onion, peppercorn, crayfish, palm oil, beef, Catharanthus roseus, table salt, waterleaf, pumpkin, fish
- has Wikipedia article: en

## DISH Q28403180
- name: Nutribun
- description: bread product
- countries: US
- kinds: bread
- has Wikipedia article: en

## DISH Q28405077
- name: Table cream
- description: dessert, similar to blancmange
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q28407625
- name: Blackout cake
- other names: {"zh": "停电蛋糕"}
- description: chocolate cake filled with chocolate pudding and topped with chocolate cake crumbs; invented during World War II by a Brooklyn bakery chain named Ebinger's and named in recognition of the mandatory blackouts to protect the Brooklyn Navy Yard
- countries: US
- kinds: cake, recipe
- ingredients: chocolate pudding
- has Wikipedia article: en, zh

## DISH Q28408000
- name: Keema Matar
- description: Minced meat dish from India and Pakistan.
- countries: IN, PK
- kinds: food
- ingredients: minced meat, shortening, Pisum sativum
- has Wikipedia article: en

## DISH Q2840947
- name: Albanian stew
- countries: AL
- kinds: dish, stew
- ingredients: onion, head, red wine

## DISH Q2841128
- name: Water chestnut cake
- other names: {"zh": "馬蹄糕"}
- description: type of cake
- countries: (none)
- kinds: cake
- has Wikipedia article: en, zh

## DISH Q2841189
- name: Banana leaf rice
- other names: {"zh": "手抓蕉叶饭"}
- description: a traditional method of serving rice dishes in South Indian cuisine
- countries: IN
- kinds: rice dish
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q28414546
- name: Pidong
- other names: {"zh": "皮冻"}
- description: food
- countries: CN
- cuisines: Chinese cuisine
- kinds: aspic, type of food or dish
- has Wikipedia article: zh

## DISH Q28415856
- name: Korean mochi breads
- other names: {"zh": "韓國麻糬麵包"}
- countries: (none)
- kinds: bread
- has Wikipedia article: zh

## DISH Q28416788
- name: Lotus seed paste cake
- other names: {"zh": "槽子糕"}
- countries: CN
- kinds: pastry, marry girl cake
- ingredients: lotus seed paste
- has Wikipedia article: zh

## DISH Q28417699
- name: 甘梅薯條
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q28419057
- name: Guazi
- other names: {"zh": "瓜子"}
- description: roasted plant seed snack
- countries: CN
- kinds: snack
- ingredients: pumpkin seed, watermelon seed, sunflower seed
- has Wikipedia article: en, zh

## DISH Q2843384
- name: Goguera
- other names: {"es": "Goguera"}
- countries: ES
- kinds: pie

## DISH Q284344
- name: Tokáň
- other names: {"cs": "Tokáň"}
- countries: (none)
- kinds: dish

## DISH Q2843608
- name: Amlu
- description: Moroccan spread of almonds, oil, honey
- countries: (none)
- kinds: Asida
- ingredients: almond, argan oil, honey
- has Wikipedia article: en

## DISH Q2843641
- name: Yod kerc'h
- other names: {"br": "Yod kerc'h"}
- countries: (none)
- kinds: oatmeal

## DISH Q28438155
- name: Ungesäuertes Brot
- other names: {"de": "ungesäuertes Brot"}
- countries: (none)
- kinds: bread
- ingredients: flour, water

## DISH Q28438379
- name: Leavened bread
- description: bread made with the aid of leavening agents
- countries: (none)
- kinds: bread
- ingredients: baker's yeast, raising agent, sourdough, flour, table salt, water

## DISH Q2845330
- name: Lotus seed bun
- other names: {"zh": "蓮茸包"}
- description: Chinese sweet bun
- countries: CN
- kinds: food, sweet roll
- ingredients: yeast
- has Wikipedia article: en, zh

## DISH Q28454364
- name: Khanom babin
- description: dessert in Thailand Cuisine
- countries: TH
- cuisines: Thai cuisine
- kinds: dessert
- has Wikipedia article: en

## DISH Q28455447
- name: Watercress soup
- description: soup
- countries: (none)
- kinds: soup
- ingredients: Nasturtium officinale
- has Wikipedia article: en

## DISH Q28455614
- name: Korean black goat stew
- description: Korean goat stew dish
- countries: (none)
- kinds: soup
- ingredients: goat meat
- has Wikipedia article: en

## DISH Q28455660
- name: Hergma
- description: Maghrebi trotter strew
- countries: (none)
- cuisines: Maghrebi cuisine
- kinds: offal dish
- ingredients: feet as food, chickpea, Wheatberry
- has Wikipedia article: en

## DISH Q28456037
- name: Khao phat tom yam
- description: type of fried rice
- countries: (none)
- kinds: nasi goreng
- has Wikipedia article: en

## DISH Q28456118
- name: Egg in beer
- description: English idiom
- countries: (none)
- kinds: dish
- ingredients: egg, beer
- has Wikipedia article: en

## DISH Q28456209
- name: Yam khanom chin
- countries: (none)
- kinds: yam
- has Wikipedia article: en

## DISH Q28456645
- name: Soup and sandwich
- description: combo meal
- countries: (none)
- kinds: combination meal
- has Wikipedia article: en

## DISH Q28456896
- name: Mofo gasy
- description: Malagasy traditional recipe
- countries: MG
- cuisines: Malagasy cuisine
- kinds: food, dish, type of food or dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q28456924
- name: Rabbit stew
- description: rabbit meat dish
- countries: (none)
- kinds: stew, rabbit dish
- ingredients: rabbit meat
- has Wikipedia article: en

## DISH Q2845744
- name: Anchois de Collioure
- countries: FR
- kinds: food product

## DISH Q28457520
- name: Rolex
- other names: {"zh": "劳力士"}
- description: Ugandan street food made by rolling eggs and vegetables In chapatti
- countries: UG
- kinds: street food, type of food or dish
- ingredients: onion, chapati, cooking oil, tomato, omelette, vegetable
- has Wikipedia article: en

## DISH Q28458377
- name: Thai fish organs sour soup
- countries: (none)
- kinds: fish dish, sour soup
- has Wikipedia article: en

## DISH Q284738
- name: Spritzgebäck
- description: German biscuit
- countries: DE
- kinds: biscuit
- ingredients: fat, flour
- has Wikipedia article: en

## DISH Q28493422
- name: Rambol
- description: type of French cheese
- countries: FR
- kinds: cheese, type of cheese

## DISH Q28493547
- name: Fries-omelet sandwich
- description: Sandwiches
- countries: DZ
- kinds: sandwich
- ingredients: fries, omelette, bread

## DISH Q2849577
- name: Angels on horseback
- other names: {"zh": "馬背天使"}
- description: bacon-wrapped oysters
- countries: GB
- cuisines: English cuisine
- kinds: oyster dish, bacon-wrapped food
- ingredients: oyster, bacon
- has Wikipedia article: en, zh

## DISH Q28496219
- name: حريرة قارصة
- other names: {"ar": "حريرة قارصة"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: lemon, puff pastry

## DISH Q2849806
- name: Angulas a la bilbaína
- other names: {"es": "Angulas a la bilbaína"}
- countries: ES
- cuisines: Basque cuisine, cuisine of Biscay
- kinds: dish, fish dish
- ingredients: garlic, glass eel, chili pepper, olive oil

## DISH Q284983
- name: Mandu
- other names: {"zh": "韩式饺子"}
- description: Korean dumplings
- countries: (none)
- kinds: dish, stuffed pasta
- ingredients: dough
- has Wikipedia article: en, zh

## DISH Q2849855
- name: Angélique
- description: confection
- countries: FR
- kinds: confectionery
- ingredients: Angelica archangelica, sugar

## DISH Q28498813
- name: Bobolo
- other names: {"fr": "Bobolo"}
- countries: (none)
- kinds: dish

## DISH Q28498839
- name: Mintoumba
- other names: {"fr": "Mintoumba"}
- countries: (none)
- kinds: dish

## DISH Q28498840
- name: Mbongo
- description: Cameroonian spicy black stew
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q28498842
- name: Ikok
- description: a meal from Cameroon
- countries: CM
- kinds: dish
- ingredients: Gnetum africanum

## DISH Q28498848
- name: Nkôno ngond
- description: cameroonian dish
- countries: (none)
- kinds: dish

## DISH Q28498849
- name: Nkôno ôndè
- other names: {"fr": "Nkôno ôndè"}
- countries: (none)
- kinds: dish

## DISH Q28501338
- name: Bizcocho Chancay
- description: typical sweet roll from Chancay, Peru
- countries: PE
- kinds: Bizcocho (Uruguay), meal

## DISH Q28503254
- name: Escuma d'oli
- other names: {"ca": "escuma d'oli"}
- countries: (none)
- kinds: mousse

## DISH Q2850350
- name: Ankimo
- other names: {"zh": "鮟肝"}
- description: Japanese monkfish liver dish
- countries: JP
- kinds: liver as food, liver, fish dish
- ingredients: Lophius
- has Wikipedia article: en, zh

## DISH Q28504005
- name: Malarrabia
- countries: PE
- kinds: dish
- ingredients: aji amarillo, garlic, white rice, Aderezo peruano, Epinephelus, Bixa orellana, Musa balbisiana, onion

## DISH Q28517237
- name: Pijama
- description: Catalan dessert
- countries: ES
- kinds: dessert
- ingredients: crème caramel, ice cream, cream

## DISH Q28517700
- name: Ajiaco
- description: a Latin American stew
- countries: (none)
- kinds: dish

## DISH Q2857837
- name: Anxovada
- other names: {"ca": "anxovada"}
- countries: (none)
- kinds: sauce

## DISH Q286189
- name: Kosereva
- description: type of traditional Paraguayan jam
- countries: PY
- kinds: candy
- has Wikipedia article: en

## DISH Q2864214
- name: Arrop i talladetes
- description: Valencian dessert
- countries: ES
- kinds: dessert
- ingredients: must, Cucurbita maxima, water

## DISH Q28645639
- name: Yugwa
- other names: {"zh": "油果"}
- description: Korean dessert
- countries: (none)
- kinds: hangwa
- has Wikipedia article: en, zh

## DISH Q28650565
- name: Crackling
- description: crisp food product produced by melting fat tissue
- countries: (none)
- kinds: pork dish

## DISH Q28658490
- name: Kruidbroodje
- other names: {"nl": "Kruidbroodje"}
- countries: (none)
- kinds: bread

## DISH Q28666315
- name: Гваймакхш
- other names: {"ru": "Гваймакхш"}
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish

## DISH Q28666320
- name: Սիսկալ
- other names: {"hy": "սիսկալ"}
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish

## DISH Q28666322
- name: Chepalgash
- description: dish of Chechnya and Ingushetia
- countries: (none)
- kinds: national dish
- has Wikipedia article: en

## DISH Q28666328
- name: Гарзни-ховла
- other names: {"ru": "Гарзни-ховла"}
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish

## DISH Q28666335
- name: Жижиг-чорпа
- other names: {"ru": "Жижиг-чорпа"}
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish

## DISH Q28666336
- name: Դալնաշ
- other names: {"hy": "դալնաշ"}
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish

## DISH Q28666344
- name: Ахар-ховла
- other names: {"ru": "ахар-ховла"}
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish

## DISH Q28666346
- name: Кхерзан-дулх
- other names: {"ru": "Кхерзан-дулх"}
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish

## DISH Q28666360
- name: Mzhaveuli
- countries: GE
- cuisines: Georgian cuisine
- kinds: vegetable dish

## DISH Q28667562
- name: Баар
- other names: {"ru": "Баар"}
- countries: RU
- kinds: dish

## DISH Q28667982
- name: Miele ibleo
- other names: {"it": "Miele ibleo"}
- countries: IT
- kinds: dessert

## DISH Q28668214
- name: Fritto misto alla milanese
- other names: {"it": "Fritto misto alla milanese"}
- countries: (none)
- kinds: fritto misto
