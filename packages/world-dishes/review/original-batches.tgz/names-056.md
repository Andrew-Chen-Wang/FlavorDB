# Review batch names-056

## DISH Q890105
- name: Kateh
- description: Iranian rice dish
- countries: IR
- kinds: rice dish
- has Wikipedia article: en

## DISH Q890193
- name: Yule log
- other names: {"zh": "圣诞树干蛋糕"}
- description: traditional dessert sponge cake, made to resemble a miniature Yule log and traditionally served near Christmas
- countries: FR
- kinds: Swiss roll, Christmas dessert
- ingredients: butter
- has Wikipedia article: en, zh

## DISH Q890197
- name: Lutefisk
- other names: {"zh": "鹼漬魚"}
- description: traditional fish dish of some Nordic countries
- countries: NO
- cuisines: Swedish cuisine, Norwegian cuisine
- kinds: food product, fish dish
- ingredients: Gadus morhua, sodium hydroxide
- has Wikipedia article: en, zh

## DISH Q890278
- name: Boerewors
- description: type of sausage originated in South Africa
- countries: ZA
- kinds: sausage, fresh sausage
- ingredients: minced meat, Capsicum, pork, nutmeg, sugar, red wine
- has Wikipedia article: en

## DISH Q890360
- name: Fårikål
- other names: {"zh": "羊肉燉白菜"}
- description: lamb dish
- countries: NO
- kinds: stew, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q89042729
- name: Bremer Kluten
- other names: {"de": "Bremer Kluten"}
- countries: DE
- kinds: confectionery
- ingredients: sugar, chocolate

## DISH Q89096394
- name: Cauche
- other names: {"es": "cauche"}
- countries: PE
- kinds: meal, Chupe, guiso

## DISH Q89133629
- name: Floor-baked bread
- description: bread that is directly baked on the floor of an oven instead of a pan or mold
- countries: (none)
- kinds: bread

## DISH Q891358
- name: Pastéis de Bacalhau
- other names: {"zh": "马介休球"}
- description: potato dish
- countries: FR, PT, IT, ES
- cuisines: French cuisine, Portuguese cuisine, Italian cuisine, Spanish cuisine
- kinds: deep-fried food, potato dish, fish dish
- ingredients: onion, dried and salted cod, egg as food, olive oil, parsley, potato
- has Wikipedia article: en

## DISH Q891437
- name: Bollenfleisch
- other names: {"de": "Bollenfleisch"}
- countries: (none)
- kinds: meat dish, dish
- ingredients: sheep meat

## DISH Q89189433
- name: Escribano
- other names: {"es": "escribano"}
- countries: PE
- kinds: meal, salad

## DISH Q89194144
- name: Confiture de goyavier
- other names: {"fr": "confiture de goyavier"}
- countries: (none)
- kinds: jam
- ingredients: Psidium cattleyanum

## DISH Q89214317
- name: Polpetta
- description: Italian meat, fish, or vegetable balls
- countries: (none)
- kinds: minced food ball

## DISH Q892249
- name: Macairekartoffeln
- other names: {"de": "Macairekartoffeln"}
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q892899
- name: Bonus Jack
- description: Hamburger on menu of Jack in the Box
- countries: (none)
- kinds: hamburger
- has Wikipedia article: en

## DISH Q892952
- name: Boodog
- description: traditional Mongolian roast of goat or marmot
- countries: MN
- kinds: meat dish
- has Wikipedia article: en

## DISH Q893306
- name: Boraki
- description: Armenian cuisine
- countries: AM
- kinds: stuffed pasta
- has Wikipedia article: en

## DISH Q893318
- name: Borani
- description: Persian appetizer
- countries: IR
- kinds: dish, appetizer
- has Wikipedia article: en

## DISH Q89366273
- name: Dereń kiszony
- other names: {"pl": "Dereń kiszony"}
- countries: (none)
- kinds: dish

## DISH Q89370832
- name: Qassami tawa
- description: fried dough popular in Saudi Arabia
- countries: SA
- kinds: confectionery, fried dough
- ingredients: whole-wheat flour, flour, table salt, sugar, water

## DISH Q89402220
- name: Huevos a la rabona
- other names: {"es": "huevos a la rabona"}
- countries: PE
- kinds: meal, sandwich
- ingredients: salsa criolla, fried egg, bread

## DISH Q894045
- name: Borodinsky bread
- description: dark brown sourdough rye bread of Russian origin
- countries: RU
- kinds: food, sourdough bread
- has Wikipedia article: en

## DISH Q89406934
- name: Inchicapi
- countries: PE
- kinds: meal, soup

## DISH Q894347
- name: Bosnian pot
- other names: {"zh": "波斯尼亚炖锅菜"}
- description: Bosnian dish
- countries: BA
- kinds: food, stew
- ingredients: mutton, beef, Allium sativum, potato, meat, carrot
- has Wikipedia article: en

## DISH Q894562
- name: Boston cream pie
- other names: {"zh": "波士頓奶油派"}
- description: cake made with custard and chocolate
- countries: US
- kinds: sponge cake
- ingredients: sponge cake
- has Wikipedia article: en

## DISH Q895009
- name: Bougatsa
- description: Greek breakfast pastry
- countries: GR
- kinds: pastry
- ingredients: phyllo, custard
- has Wikipedia article: en

## DISH Q895255
- name: Bourride
- other names: {"zh": "Bourride"}
- description: meal based on fish and seafood, variant of bouillabaisse
- countries: FR
- cuisines: French cuisine
- kinds: fish soup
- has Wikipedia article: en

## DISH Q895678
- name: Kottenbutter
- description: German sandwich
- countries: DE
- kinds: sandwich, open sandwich
- ingredients: brown bread, onion ring, pork, butter
- has Wikipedia article: en

## DISH Q895789
- name: Butterkuchen
- description: German butter cake
- countries: DE
- kinds: sheet cake
- ingredients: flour, butter, sugar
- has Wikipedia article: en

## DISH Q896074
- name: Frankfurter Rippchen
- description: traditional hessian dish, Germany
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q8961756
- name: Flaki
- description: traditional Polish meat stew
- countries: PL
- kinds: tripe soup, offal dish
- has Wikipedia article: en

## DISH Q8961917
- name: Fogaça
- other names: {"es": "Fogaça"}
- countries: PT
- kinds: cake, pastry

## DISH Q8962869
- name: Frit mallorquí
- description: typical dish from Mallorca
- countries: (none)
- kinds: dish

## DISH Q8962920
- name: Frutas de Aragón
- description: traditional Aragonese candy
- countries: ES
- kinds: dessert, food
- ingredients: candied fruit, chocolate

## DISH Q8963686
- name: Jellied veal
- description: Swedish cold cut dish
- countries: (none)
- kinds: veal dish
- has Wikipedia article: en

## DISH Q896508
- name: Gaisburger Marsch
- other names: {"zh": "盖斯堡行军菜"}
- description: German food
- countries: DE
- kinds: stew, beef dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q89677726
- name: Raspberry tart
- description: type of tart filled with raspberries
- countries: (none)
- kinds: dessert, tart
- ingredients: raspberry

## DISH Q897096
- name: Saure Kutteln
- description: swabian dish
- countries: (none)
- kinds: meat dish
- ingredients: tripe
- has Wikipedia article: en

## DISH Q89741283
- name: Rabbit with chocolate
- description: rabbit in wine and chocolate sauce dish from Spain
- countries: ES
- cuisines: Catalan cuisine
- kinds: dish
- ingredients: garlic, Vi ranci, rabbit meat, onion, fried bread, fines herbes, almond, olive oil, spice, white wine

## DISH Q898835
- name: Dutch-process cocoa
- description: Dutch process removing cocoa butter and treating the cocoa mass with an alkalizing agent to remove bitterness
- countries: (none)
- kinds: chocolate, cocoa powder
- has Wikipedia article: en

## DISH Q89889766
- name: Džiugas cheese
- description: type of cheese
- countries: LT
- kinds: type of cheese, pasteurized milk cheese

## DISH Q899218
- name: Kyiv cake
- other names: {"zh": "基輔蛋糕"}
- description: Ukrainian brand of dessert cake
- countries: UA
- kinds: cake
- ingredients: wheat flour, meringue, Vanilla, egg as food, nut, sugar, chocolate
- has Wikipedia article: en, zh

## DISH Q899561
- name: Roast
- description: roasted meat
- countries: (none)
- kinds: meat, dish, type of food or dish, food ingredient
- ingredients: meat

## DISH Q8998667
- name: Kintarō-ame
- other names: {"zh": "金太郎糖"}
- countries: (none)
- kinds: ame
- has Wikipedia article: zh

## DISH Q899882
- name: Bratwurst
- other names: {"zh": "德國油煎香腸"}
- description: type of sausage
- countries: AT, DE
- kinds: sausage, veal dish
- ingredients: veal, beef, pork
- has Wikipedia article: en, zh

## DISH Q89998432
- name: Christmas sweet
- description: Christmas themed confections
- countries: (none)
- kinds: Christmas food, confectionery

## DISH Q89999446
- name: Fruit jam
- description: type of jam made with fruit
- countries: (none)
- kinds: jam
- ingredients: fruit, pectin, sugar

## DISH Q89999451
- name: Vegetable jam
- description: type of jam
- countries: (none)
- kinds: jam
- ingredients: vegetable

## DISH Q89999455
- name: Apricot jam
- description: jam made from apricots
- countries: (none)
- kinds: fruit jam
- has Wikipedia article: en

## DISH Q89999458
- name: Bilberry jam
- description: jam made from bilberries
- countries: (none)
- kinds: berry jam
- ingredients: bilberry

## DISH Q89999656
- name: Lychee jam
- description: jam made from lychees
- countries: (none)
- kinds: fruit jam
- ingredients: litchi

## DISH Q89999678
- name: Mango jam
- description: jam made from mangos
- countries: (none)
- kinds: fruit jam
- ingredients: mango

## DISH Q89999771
- name: Melon jam
- description: jam made from melons
- countries: (none)
- kinds: fruit jam

## DISH Q89999776
- name: Mirabelle plum jam
- description: Mirabelle plum jams
- countries: (none)
- kinds: fruit jam
- ingredients: Prunus domestica subsp. syriaca

## DISH Q89999795
- name: Mixed berry jam
- description: type of fruit jam
- countries: (none)
- kinds: berry jam

## DISH Q89999799
- name: Mixed fruit jam
- description: type of fruit jam
- countries: (none)
- kinds: fruit jam

## DISH Q89999884
- name: Pumpkin jam
- description: type of vegetable jam
- countries: (none)
- kinds: vegetable jam
- ingredients: pumpkin

## DISH Q89999895
- name: Rhubarb jam
- description: Rhubarb jams
- countries: (none)
- kinds: vegetable jam

## DISH Q90000103
- name: Tropical fruit jam
- description: type of fruit jam
- countries: (none)
- kinds: fruit jam
- ingredients: tropical fruit

## DISH Q90000772
- name: Grape jam
- description: jam made from grapes
- countries: (none)
- kinds: fruit jam

## DISH Q90000932
- name: Berry jam
- description: jam made from berries
- countries: (none)
- kinds: fruit jam
- ingredients: pectin, berry, sugar

## DISH Q90001011
- name: Clementine jam
- description: Clementine jams
- countries: (none)
- kinds: marmalade

## DISH Q9002202
- name: Hasma
- other names: {"zh": "雪蛤膏"}
- description: also known as Hashima, frog glands popular in Asia
- countries: CN
- kinds: pastry
- has Wikipedia article: en, zh

## DISH Q900440
- name: Butadon
- other names: {"zh": "豬肉蓋飯"}
- description: Japanese dish
- countries: JP
- kinds: dish, donburi, pork dish
- ingredients: Japanese rice, takuan, pork, rice
- has Wikipedia article: en, zh

## DISH Q9012336
- name: Jocoque
- description: Mexican dairy product
- countries: MX
- kinds: fermented milk, dairy product
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q9017170
- name: Alkaline noodles
- other names: {"zh": "碱水"}
- description: liquid alkaline used in making Chinese noodles
- countries: CN
- kinds: Chinese noodles, staple food
- ingredients: potassium carbonate, sodium carbonate
- has Wikipedia article: en, zh

## DISH Q9017323
- name: Katiki Domokou
- description: Greek cheese
- countries: GR
- kinds: Greek cheese
- has Wikipedia article: en

## DISH Q9019810
- name: Lacón con grelos
- description: Spanish meat dish
- countries: (none)
- cuisines: Galician cuisine
- kinds: cocido, pork dish, dish
- ingredients: potato, Lacón Gallego, chorizo

## DISH Q9026659
- name: Macun şekeri
- other names: {"zh": "奧斯曼棒棒糖"}
- description: traditional Turkish confectionery that comes in varios colours
- countries: TR
- kinds: candy, dish
- has Wikipedia article: en

## DISH Q9027344
- name: Mandazi
- description: a form of fried bread that originated on the Swahili Coast.
- countries: TZ
- kinds: dish, human food, food
- ingredients: water
- has Wikipedia article: en

## DISH Q9028419
- name: Mar i muntanya
- countries: (none)
- kinds: dish

## DISH Q9028481
- name: Marañuela
- description: Spanish pastry
- countries: ES
- kinds: pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q9032613
- name: Migas alentejanas
- countries: PT
- kinds: dish
- ingredients: pork ribs, pork, Allium sativum, bacon, bread

## DISH Q90331615
- name: A1 Bread
- description: bread made in Ghana
- countries: GH
- kinds: bread

## DISH Q9033787
- name: Mixiote
- description: Mixiote is a traditional pit-barbecued meat dish in central Mexico
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q9034677
- name: Montadito
- description: Spanish open-faced sandwich
- countries: ES
- kinds: dish, open sandwich

## DISH Q903997
- name: Simit
- other names: {"zh": "土耳其芝麻麵包"}
- description: ring-shaped bread roll originating in Turkey, typically encrusted with sesame seeds
- countries: EG
- kinds: bread, food
- ingredients: sesame seed, wheat flour, baker's yeast, flour, table salt, drinking water
- has Wikipedia article: en

## DISH Q904018
- name: Frumenty
- description: porridge of boiled grain in medieval Europe
- countries: (none)
- kinds: pudding
- ingredients: wheat
- has Wikipedia article: en

## DISH Q90410085
- name: Gluten-free bread
- description: Gluten-free breads
- countries: (none)
- kinds: bread

## DISH Q90410092
- name: Gluten-free sliced bread
- description: Gluten-free sliced breads
- countries: (none)
- kinds: sliced bread, Gluten-free bread

## DISH Q90410134
- name: Pre-baked bread
- description: Pre-baked breads
- countries: (none)
- kinds: bread

## DISH Q904155
- name: Dongchimi
- other names: {"zh": "冬沈"}
- description: food
- countries: (none)
- kinds: radish kimchi
- ingredients: Korean radish, ginger
- has Wikipedia article: en

## DISH Q90416374
- name: Befanini PAT
- other names: {"zh": "Befanini PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good, biscuit
- ingredients: anisette, zest, egg as food, rum, yeast, flour, butter, table salt, sugar, milk

## DISH Q904625
- name: Bungeoppang
- other names: {"zh": "鲤鱼饼"}
- description: Korean fish-shaped pastry
- countries: (none)
- kinds: pulppang
- ingredients: batter
- has Wikipedia article: en

## DISH Q9046749
- name: Murta con membrillo
- description: sweet from southern Chile
- countries: CL
- kinds: dessert, fruit preserves, meal
- ingredients: Ugni molinae, quince, sugar
- has Wikipedia article: en

## DISH Q9049129
- name: Negalho
- other names: {"es": "Negalho"}
- countries: (none)
- kinds: dish

## DISH Q905135
- name: Hongeohoe
- other names: {"zh": "洪鱼脍"}
- description: type of fermented fish dish from Korea's Jeolla province
- countries: (none)
- kinds: hoe, fish dish
- ingredients: Ocellate spot skate
- has Wikipedia article: en, zh

## DISH Q9052023
- name: Oliaigu
- other names: {"ca": "Oliaigu"}
- countries: (none)
- kinds: dish

## DISH Q905204
- name: Kakigōri
- other names: {"zh": "日式刨冰"}
- description: Japanese shaved ice dessert
- countries: JP
- kinds: shaved ice, frozen dessert
- ingredients: ice
- has Wikipedia article: en

## DISH Q9052149
- name: Olla de trigo
- countries: (none)
- cuisines: cuisine of the province of Almería
- kinds: guiso, type of food or dish

## DISH Q9053
- name: Pudding
- other names: {"ca": "Pudding", "zh": "布丁"}
- description: dessert or savory dish
- countries: (none)
- kinds: type of food or dish, dessert, dish
- has Wikipedia article: en, zh

## DISH Q9054806
- name: Paleta
- other names: {"cs": "paleta"}
- countries: ES
- kinds: ham

## DISH Q9054907
- name: Pamirdin
- countries: CN
- kinds: pie
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q9054939
- name: Pa de pagès
- description: traditional food of Catalonia
- countries: ES
- cuisines: Catalan cuisine
- kinds: bread
- ingredients: baker's yeast, flour, drinking water
- has Wikipedia article: en

## DISH Q9055080
- name: Tonya
- description: Valencian pastry
- countries: (none)
- kinds: pastry

## DISH Q9055174
- name: Papas de sarrabulho
- other names: {"zh": "血糊"}
- description: Portuguese meat stew
- countries: (none)
- kinds: meat dish, stew
- has Wikipedia article: en

## DISH Q905527
- name: Takoyaki
- other names: {"zh": "章鱼烧"}
- description: ball-shaped Japanese snack with octopus
- countries: JP
- cuisines: Japanese cuisine
- kinds: yakimono, octopus dish, konamono, dish
- ingredients: octopus as food, wheat flour, green laver, beni shōga, mayonnaise, katsuobushi, Octopoda, flour, Welsh onion, egg
- has Wikipedia article: en, zh

## DISH Q9056687
- name: Pasta marquesa
- description: Christmas almond and marzipan pastries
- countries: ES
- kinds: dessert, pastry

## DISH Q9056689
- name: Alphabet pasta
- description: Pasta shaped like alphabet letters
- countries: (none)
- kinds: pasta, food
- has Wikipedia article: en

## DISH Q9056693
- name: Pastafrola
- description: type of sweet tart
- countries: AR, UY
- kinds: Crostata, dessert
- ingredients: chicken egg, wheat flour, quince cheese, lemon zest, butter, baking powder, sugar
- has Wikipedia article: en

## DISH Q9056699
- name: Pastel de Chaves
- description: Portuguese savory pastry
- countries: PT
- kinds: pastry
- ingredients: onion, veal, puff pastry, bread

## DISH Q9058863
- name: Pets de monja
- other names: {"ast": "pets de monja"}
- countries: ES
- kinds: dessert
- ingredients: lemon, egg as food, flour, butter, sugar

## DISH Q9061039
- name: Plecing kangkung
- description: plant based food from Lombok
- countries: ID
- cuisines: Indonesian cuisine, Balinese cuisine
- kinds: salad, cuisine, human food, type of food or dish
- ingredients: tomato, mung bean sprout, Kangkung, peanut, shrimp paste, water spinach, chili pepper
- has Wikipedia article: en

## DISH Q9065202
- name: Paraguay cheese
- description: cows' milk cheese from Paraguay
- countries: PY
- cuisines: Paraguayan cuisine
- kinds: cow's-milk cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q9065233
- name: Transmontano goat cheese
- description: Portuguese cheese
- countries: PT
- kinds: cheese
- has Wikipedia article: en

## DISH Q9070819
- name: Rosquillas tontas y listas
- other names: {"es": "rosquillas tontas y listas"}
- countries: ES
- kinds: dessert, rosquilla

## DISH Q9075389
- name: Dry of goat
- countries: EC
- kinds: dish

## DISH Q907560
- name: Kimchijeon
- description: Korean dish
- countries: (none)
- kinds: jeon
- ingredients: Kimchi
- has Wikipedia article: en

## DISH Q907723
- name: Bremer Kükenragout
- other names: {"de": "Bremer Kükenragout"}
- countries: (none)
- kinds: meat dish

## DISH Q9077681
- name: Sincronizada
- description: Mexican tortilla
- countries: MX
- kinds: food, sandwich
- ingredients: ham, tortilla, vegetable, cheese
- has Wikipedia article: en

## DISH Q907849
- name: Kongbap
- description: cooked rice with (soy)beans
- countries: (none)
- kinds: dish
- ingredients: soybean, rice
- has Wikipedia article: en

## DISH Q9078985
- name: Sopa boba
- other names: {"eo": "sopa boba"}
- countries: (none)
- kinds: soup, dish by ingredient
- ingredients: leftovers, drinking water

## DISH Q9078988
- name: Almond soup
- description: Spanish dessert
- countries: ES
- kinds: dessert
- ingredients: almond, cinnamon, vanilla, cream, milk

## DISH Q9078990
- name: Majorcan dry soup
- description: Majorcan soup
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q9079488
- name: Srabi solo
- other names: {"es": "Srabi solo"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, confectionery, traditional food, dish, human food, type of food or dish
- ingredients: wheat flour, rice flour, baker's yeast, coconut milk, sodium bicarbonate, table salt, sugar

## DISH Q9081965
- name: Tarta de Mondoñedo
- other names: {"es": "Tarta de Mondoñedo"}
- countries: ES
- cuisines: Galician cuisine
- kinds: dessert

## DISH Q9082318
- name: Tejas y Cigarrillos de Tolosa
- other names: {"es": "Tejas y Cigarrillos de Tolosa"}
- countries: ES
- kinds: dessert

## DISH Q908311
- name: Ssam
- other names: {"zh": "菜包肉"}
- description: Korean wraps
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q9089148
- name: Tortas fritas
- description: fried flat breads from Argentina, Paraguay and Uruguay
- countries: (none)
- kinds: torta, bread dish
- ingredients: wheat flour, animal fats and oils, table salt, water

## DISH Q908963
- name: Mofongo
- other names: {"zh": "磨豐果"}
- description: Puerto Rican dish.
- countries: PR
- kinds: dish
- ingredients: garlic, broth, pork, cooking banana, olive oil
- has Wikipedia article: en, zh

## DISH Q9090624
- name: Turrón de doña pepa
- description: Peruvian dessert
- countries: PE
- kinds: cake

## DISH Q9090648
- name: Tutu de feijão
- description: Brazilian dish of puréed beans thickened with cassava or corn flour
- countries: BR
- kinds: dish, bean-based food

## DISH Q909385
- name: Almond tofu
- other names: {"zh": "杏仁豆腐"}
- description: Chinese dessert also popular in Hong Kong, Hong Kong, Taiwan, Japan, Malaysia and Singapore
- countries: (none)
- kinds: pudding, dessert
- ingredients: apricot kernel
- has Wikipedia article: en, zh

## DISH Q909438
- name: Lavash
- other names: {"zh": "亞美尼亞脆餅"}
- description: thin flatbread usually leavened, traditionally baked in a tonir
- countries: AM
- cuisines: Armenian cuisine
- kinds: flatbread, finger food
- ingredients: dough
- has Wikipedia article: en, zh

## DISH Q909643
- name: Guk
- description: class of soup-like dishes in Korean cuisine
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q909649
- name: Sundubu-jjigae
- other names: {"zh": "纯豆腐汤"}
- description: Korean soft tofu stew
- countries: (none)
- kinds: food, soup, jjigae, seafood dish
- ingredients: sun-dubu
- has Wikipedia article: en, zh

## DISH Q909700
- name: Jorim
- description: Korean simmered dish category
- countries: (none)
- kinds: dish, food preparation technique
- has Wikipedia article: en

## DISH Q910095
- name: Bresaola
- other names: {"zh": "布雷绍拉风干肉"}
- description: air dried and salted beef
- countries: IT
- kinds: salt-cured meat, salume, raw whole-muscle cut, charcuterie
- ingredients: beef, table salt
- has Wikipedia article: en, zh

## DISH Q91019397
- name: Печень по-строгановски
- other names: {"ru": "Печень по-строгановски"}
- countries: RU
- cuisines: Russian cuisine
- kinds: dish
- ingredients: tomato paste, liver as food, smetana, onion

## DISH Q910515
- name: Galinha à Portuguesa
- other names: {"zh": "葡国鸡"}
- description: Macanese dish of chicken and potatoes and rice
- countries: (none)
- kinds: chicken dish
- ingredients: potato, Portuguese sauce, chicken as food, rice
- has Wikipedia article: en, zh

## DISH Q910996
- name: Bossam
- description: Korean dish of boiled pork wraps
- countries: (none)
- kinds: pork dish
- ingredients: Boston butt
- has Wikipedia article: en

## DISH Q911117
- name: Gopchang
- other names: {"zh": "韩式烤肠"}
- description: Korean dish of beef small intestines
- countries: KR
- cuisines: Korean cuisine
- kinds: dish
- ingredients: small intestine
- has Wikipedia article: en, zh

## DISH Q91159287
- name: Pancake layer cake
- countries: (none)
- kinds: cake
- ingredients: pancake

## DISH Q91227121
- name: Marlenka
- description: Armenian honey cake
- countries: AM
- cuisines: Armenian cuisine
- kinds: torte
- ingredients: caramel, honey

## DISH Q91294657
- name: Satkara beef
- description: beef curry from Sylhet, Bangladesh
- countries: BD
- kinds: Sylheti cuisine, food, beef curry
- has Wikipedia article: en

## DISH Q913411
- name: Svele
- description: Norwegian food similar to pancake
- countries: (none)
- kinds: dish
- ingredients: ammonium hydrogen carbonate, kefir, sodium bicarbonate, egg as food, flour, sugar
- has Wikipedia article: en

## DISH Q9151394
- name: Andruty kaliskie
- description: sweet, flat wafers of Polish origin
- countries: (none)
- kinds: waffle
- has Wikipedia article: en

## DISH Q91545570
- name: Hutki Shira
- description: fermented fish curry famous in Sylhet region
- countries: (none)
- kinds: fish curry
- has Wikipedia article: en

## DISH Q9166037
- name: Barszcz biały z kiszonej kapusty
- other names: {"pl": "Barszcz biały z kiszonej kapusty"}
- countries: (none)
- kinds: soup, dish

## DISH Q9166039
- name: Ukrainian Borscht
- countries: UA
- kinds: potato dish

## DISH Q917043
- name: Soy pulp
- other names: {"zh": "豆渣"}
- description: byproduct of tofu production
- countries: JP
- kinds: pomace, soy food
- ingredients: soy bean
- has Wikipedia article: en, zh

## DISH Q9174337
- name: Bliny żmudzkie
- other names: {"pl": "bliny żmudzkie"}
- countries: (none)
- kinds: blini, potato dish

## DISH Q917646
- name: Rigatoni con la pajata
- description: traditional Italian pasta dish
- countries: IT
- kinds: dish
- ingredients: rigatoni
- has Wikipedia article: en

## DISH Q9180753
- name: Bryjka
- description: Polish dish
- countries: PL
- kinds: porridge

## DISH Q918148
- name: Papad
- other names: {"zh": "印度炸薄饼"}
- description: snack food from Indian subcontinent
- countries: IN
- kinds: flatbread, bread, appetizer, fried dough, type of food or dish
- ingredients: Vigna mungo
- has Wikipedia article: en, zh

## DISH Q918216
- name: Zeppole
- description: Italian pastry
- countries: IT
- kinds: pastry
- ingredients: dough
- has Wikipedia article: en

## DISH Q9182865
- name: Byśki
- description: Bread for New Year in Poland
- countries: PL
- kinds: bread

## DISH Q9185291
- name: Cazabe
- description: cassava bread
- countries: (none)
- kinds: bread, flatbread, baked good
- ingredients: cassava root, cassava
- has Wikipedia article: en

## DISH Q9189882
- name: Prądnik bread
- description: Polish rye bread
- countries: PL
- kinds: bread
- has Wikipedia article: en

## DISH Q91903691
- name: Barzón (postre)
- description: dessert from Autol
- countries: ES
- kinds: dessert

## DISH Q91908928
- name: Pizza quattro formaggi
- other names: {"zh": "四季披薩"}
- description: kind of pizza
- countries: IT
- kinds: dish, type of pizza
- ingredients: Fontina PDO, Gorgonzola, Parmesan, mozzarella
- has Wikipedia article: en

## DISH Q919627
- name: Steckrübeneintopf
- other names: {"zh": "萝卜炖菜"}
- description: food
- countries: DE
- kinds: food, soup
- ingredients: Brassica napus subsp. rapifera
- has Wikipedia article: en

## DISH Q92054361
- name: Salade fécampoise
- countries: (none)
- kinds: dish

## DISH Q920940
- name: Dosa
- other names: {"zh": "多薩"}
- description: thin pancakes originating from South India
- countries: IN
- kinds: pancake, food
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q921706
- name: Bhakri
- description: unleavened bread used in the cuisine of western and central India
- countries: IN
- kinds: food, flatbread, Indian bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q92180702
- name: Fyddžyn
- description: Ossetian meat pie
- countries: (none)
- cuisines: Ossetian cuisine
- kinds: Ossetian pies, meat pie

## DISH Q922429
- name: Jambonette
- description: form of charcuterie
- countries: FR
- kinds: pork dish
- has Wikipedia article: en

## DISH Q922721
- name: Tiger bread
- description: bread loaf of Dutch origin with a mottled crust made by painting rice paste onto the surface before baking
- countries: (none)
- kinds: bread
- ingredients: wheat flour, flour treatment agent, yeast, flour, butter, table salt, sugar, milk
- has Wikipedia article: en

## DISH Q92298243
- name: Caramanduca
- description: a Peruvian biscuit
- countries: PE
- kinds: bread, cookie

## DISH Q923440
- name: Schwedeneisbecher
- other names: {"de": "Schwedeneisbecher"}
- countries: DD
- cuisines: cuisine of the German Democratic Republic
- kinds: dish
- ingredients: vanilla ice cream, whipped cream, apple sauce, Advocaat

## DISH Q923490
- name: Boule
- description: traditional round bread shape
- countries: FR
- kinds: yeast bread
- has Wikipedia article: en

## DISH Q923729
- name: Galantine
- description: stuffed meat dish from French cuisine
- countries: FR
- kinds: dish
- has Wikipedia article: en

## DISH Q924689
- name: Soto ayam
- other names: {"zh": "印尼雞湯"}
- description: Indonesian spicy chicken soup
- countries: ID
- cuisines: Indonesian cuisine
- kinds: soto, dish, human food, type of food or dish
- ingredients: Tilia leaf, garlic, turmeric, ginger, Cymbopogon, onion, chicken as food
- has Wikipedia article: en, zh

## DISH Q9249339
- name: Dębniak (miód)
- other names: {"pl": "Dębniak (miód)"}
- countries: (none)
- kinds: dish

## DISH Q925359
- name: Soy egg
- other names: {"zh": "滷水蛋"}
- description: egg dish
- countries: (none)
- kinds: lou mei, egg dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q925398
- name: Sardo o Quesardo
- description: grating cow's milk cheese
- countries: AR
- kinds: cow's-milk cheese
- has Wikipedia article: en

## DISH Q92570320
- name: Dandelion honey
- description: monofloral honey from dandelion flowers
- countries: (none)
- kinds: honey

## DISH Q9260110
- name: Fitka kazimierska
- other names: {"pl": "Fitka kazimierska"}
- countries: (none)
- kinds: potato dish

## DISH Q926500
- name: Sesame seed candy
- other names: {"zh": "黑芝麻糖"}
- description: food
- countries: (none)
- kinds: food, confectionery, sesame seed
- ingredients: sesame seed, honey
- has Wikipedia article: en

## DISH Q926532
- name: Piadina
- description: type of italian thin flatbread
- countries: IT
- cuisines: Italian cuisine
- kinds: food, flatbread
- ingredients: olive oil, flour, water
- has Wikipedia article: en

## DISH Q9266
- name: Salad
- other names: {"zh": "沙拉"}
- description: dish consisting of a mixture of small pieces of food, usually vegetables or fruit
- countries: (none)
- kinds: type of food or dish, dish
- ingredients: vegetable
- has Wikipedia article: en, zh

## DISH Q92743758
- name: Nirasenbei
- countries: (none)
- kinds: senbei
- ingredients: Allium tuberosum

## DISH Q927451
- name: Nabulsi cheese
- other names: {"zh": "納布盧斯乳酪"}
- description: Palestinian white brined sheep and goat's milk cheese
- countries: PS
- kinds: goat cheese, sheep milk cheese
- ingredients: milk
- has Wikipedia article: en

## DISH Q927904
- name: Toffee
- other names: {"zh": "太妃糖"}
- description: caramel confections
- countries: (none)
- kinds: candy, confectionery, Sugar confectionery (including white chocolate), not containing cocoa, Sweet confectionery products (ОКП 91 2000)
- ingredients: rubber, molasses, butter, sugar
- has Wikipedia article: en, zh

## DISH Q927982
- name: Cocido Montañés
- description: Cantabrian bean stew
- countries: ES
- cuisines: Cantabrian cuisine
- kinds: food, stew
- has Wikipedia article: en

## DISH Q9282304
- name: Pickled mushrooms
- description: mushrooms preserved using vinegar
- countries: (none)
- kinds: vegetable, pickle, preserved food, mushroom dish
- ingredients: mushroom
- has Wikipedia article: en

## DISH Q9284035
- name: Gęsi pipek
- other names: {"pl": "Gęsi pipek"}
- countries: (none)
- kinds: potato dish

## DISH Q9287233
- name: Rauchkäse
- description: German variety of smoked cheese, known for being semi-soft with a smoky brown rind
- countries: DE
- kinds: smoked cheese, cheese, type of cheese
- has Wikipedia article: en

## DISH Q929364
- name: Dal bhat
- other names: {"zh": "達八"}
- description: Lentil and rice dish
- countries: NP
- kinds: dal, rice dish
- ingredients: lentil soup, rice
- has Wikipedia article: en, zh

## DISH Q9294302
- name: Hořické roll
- description: Czech dessert
- countries: CZ
- kinds: dessert
- ingredients: wafer cookie, honey, chocolate

## DISH Q929487
- name: Schlachteplatte
- description: German meat dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q930514
- name: Coca cristina
- other names: {"ca": "Coca cristina"}
- countries: ES
- kinds: dessert

## DISH Q930630
- name: Monkey bread
- other names: {"zh": "猴面包"}
- description: U.S. soft, sweet, sticky pastry, consisting of pieces of soft baked dough sprinkled with cinnamon
- countries: US
- kinds: bread, cake
- has Wikipedia article: en

## DISH Q93126485
- name: German bread roll
- countries: DE
- kinds: bread roll

## DISH Q931367
- name: Fruit butter
- description: type of spread
- countries: (none)
- kinds: spread, mash, fruit preserves
- ingredients: fruit
- has Wikipedia article: en

## DISH Q93145436
- name: Panino
- other names: {"fr": "Panino"}
- countries: (none)
- kinds: bread

## DISH Q93149118
- name: Dinner roll
- description: type of food
- countries: (none)
- kinds: type of food or dish, bread roll

## DISH Q9324242
- name: Greek-style fish
- description: Polish Christmas dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q93258309
- name: Yomogi mochi
- description: Japanese mugwort rice cake
- countries: JP
- kinds: Kusa mochi
- ingredients: Artemisia princeps

## DISH Q933433
- name: Kokoretsi
- other names: {"zh": "希臘烤羊腸"}
- description: grilled lamb or goat intestines
- countries: (none)
- kinds: lamb dish, goat meat dish, offal dish
- ingredients: offal
- has Wikipedia article: en

## DISH Q9335353
- name: Apple cheese
- other names: {"zh": "蘋果起司"}
- description: traditional Lithuanian dessert
- countries: LT, PL
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q9339115
- name: Soczewiaki
- other names: {"pl": "Soczewiaki"}
- countries: (none)
- kinds: dish

## DISH Q9340263
- name: Spighe
- description: Polish name of pasta
- countries: PL
- kinds: pasta, term

## DISH Q934095
- name: Laksa
- other names: {"zh": "叻沙"}
- description: Southeast Asian noodle soup origin from Malacca, originally introduced by Persian trader
- countries: IR
- cuisines: Indonesian cuisine
- kinds: noodle soup, dish, human food, type of food or dish, food
- ingredients: Indonesian bay leaf, shallot, turmeric rhizome, garlic, coriander seed, chicken egg, ginger, seedling, Kaempferia galanga, Holy Basil, chicken as food, coconut milk, rice vermicelli, Alpinia galanga, chili pepper, Cymbopogon citratus, sugar
- has Wikipedia article: en, zh

## DISH Q934171
- name: Green tea ice cream
- other names: {"zh": "抹茶冰淇淋"}
- description: Dessert
- countries: JP
- kinds: ice cream
- ingredients: matcha
- has Wikipedia article: en

## DISH Q93454336
- name: Bledi krémes
- other names: {"hu": "bledi krémes"}
- countries: (none)
- kinds: dessert, cake

## DISH Q9350843
- name: Szare kluski
- other names: {"pl": "Szare kluski"}
- countries: (none)
- kinds: potato dish

## DISH Q93521114
- name: Черничево
- other names: {"bg": "Черничево"}
- countries: BG
- kinds: cheese
- ingredients: milk

## DISH Q9356605
- name: Temakizushi
- description: kind of hand-rolled sushi
- countries: (none)
- kinds: makizushi

## DISH Q935807
- name: Injera
- other names: {"zh": "英杰拉"}
- description: sourdough flatbread
- countries: ET
- kinds: flatbread, sourdough bread
- ingredients: teff flour, water
- has Wikipedia article: en, zh

## DISH Q935937
- name: Miguelitos
- other names: {"zh": "米糕莱托"}
- description: food
- countries: ES
- kinds: cake, dessert, pastry
- ingredients: pastry cream
- has Wikipedia article: en, zh

## DISH Q9361623
- name: Tripolini
- description: type of pasta
- countries: (none)
- kinds: pasta

## DISH Q9362605
- name: Tuffoli
- description: type of pasta
- countries: IT
- kinds: pasta

## DISH Q936620
- name: Suprême sauce
- description: classic French sauce
- countries: FR
- kinds: white sauce, sauce
- ingredients: velouté sauce
- has Wikipedia article: en

## DISH Q9366979
- name: Uramakizushi
- description: kind of rolled sushi with nori on the inside and rice on the outside
- countries: (none)
- kinds: makizushi

## DISH Q937013
- name: Bouillon cube
- other names: {"zh": "湯塊"}
- description: dehydrated broth or stock formed into a small cube
- countries: (none)
- kinds: instant stock
- has Wikipedia article: en

## DISH Q93718042
- name: Stuffed Breast of Duck
- countries: AT
- cuisines: Austrian cuisine
- kinds: dish
- ingredients: duck breast, salt and pepper, butter, marjoram, apple

## DISH Q93725616
- name: Austrian Meatloaf
- description: traditional Austrian dish of ground beef and pork
- countries: (none)
- kinds: dish, meatloaf
- ingredients: ground pork, garlic, salt and pepper, ground beef, onion, Consommé, bread crumbs, egg as food, marjoram, milk

## DISH Q9373906
- name: Red borscht with mini pierogies
- description: Polish Christmas Eve soup
- countries: (none)
- kinds: dish, Christmas food, vegetarian food
- ingredients: beet kvass, dried mushrooms, bouillon, uszka, beet

## DISH Q937960
- name: Tamago kake gohan
- other names: {"zh": "生蛋拌飯"}
- description: Japanese breakfast dish of rice and egg
- countries: JP
- kinds: Japanese rice dish, egg dish, type of food or dish
- ingredients: chicken egg, gohan, soy sauce
- has Wikipedia article: en, zh

## DISH Q938300
- name: Pumpkin-coconut custard
- description: a coconut custard steam-baked in a pumpkin or kabocha
- countries: TH
- kinds: dessert
- ingredients: coconut, custard, pumpkin
- has Wikipedia article: en

## DISH Q938386
- name: Fricasse
- description: Tunisian savory stuffed fried pastry
- countries: TN
- kinds: potato dish, type of food or dish, entrée
- has Wikipedia article: en

## DISH Q9384666
- name: Minced food ball
- other names: {"zh": "丸子"}
- description: meat, fish, or vegetable balls
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q9384742
- name: Braised intestines in brown sauce
- other names: {"zh": "九转大肠"}
- description: Traditional Chinese dish
- countries: CN
- kinds: offal dish
- ingredients: pork large intestine
- has Wikipedia article: en, zh

## DISH Q938506
- name: Valle del Belice PDO
- other names: {"zh": "Valle del Belice DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q9386405
- name: Zalewajka
- description: soup made of potatoes and sour rye
- countries: (none)
- kinds: potato dish
- has Wikipedia article: en

## DISH Q938682
- name: Alfajor
- other names: {"zh": "西班牙夹心饼"}
- description: Hispanic American sweet dessert
- countries: (none)
- kinds: confectionery
- ingredients: dulce de leche, flour
- has Wikipedia article: en

## DISH Q9391156
- name: Ziemniaki po cabańsku
- other names: {"pl": "Ziemniaki po cabańsku"}
- countries: (none)
- kinds: potato dish

## DISH Q9392144
- name: Zupa solferino
- other names: {"pl": "Zupa solferino"}
- countries: (none)
- kinds: potato dish

## DISH Q9392148
- name: Shirumono
- other names: {"zh": "汁物"}
- countries: JP
- cuisines: Japanese cuisine
- kinds: soup, type of food or dish
- has Wikipedia article: zh

## DISH Q9394546
- name: Beef uterus
- description: offal
- countries: (none)
- kinds: uterus, beef dish, offal dish

## DISH Q9394846
- name: Łuplanyki
- other names: {"pl": "Łuplanyki"}
- countries: (none)
- kinds: potato dish

## DISH Q9396921
- name: Świńska kasza
- other names: {"pl": "Świńska kasza"}
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q939735
- name: Pupazza frascatana
- other names: {"es": "pupazza frascatana"}
- countries: IT
- kinds: dessert

## DISH Q940757
- name: Petit four
- other names: {"zh": "花色小蛋糕"}
- description: small confectionery or savoury appetizer
- countries: FR
- kinds: small pastry, confectionery
- has Wikipedia article: en, zh

## DISH Q940999
- name: Brown bread
- other names: {"zh": "棕面包"}
- description: food
- countries: IE
- kinds: bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q941004
- name: Fufu
- other names: {"zh": "富富"}
- description: dough-like food in African cuisine
- countries: GH
- kinds: food, dish, swallow
- ingredients: cassava root, water
- has Wikipedia article: en, zh

## DISH Q941068
- name: Mozzarella di Bufala Campana PDO
- other names: {"zh": "Mozzarella di Bufala Campana DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, mozzarella, buffalo's milk-cheese
- has Wikipedia article: en

## DISH Q941101
- name: Funche
- description: Puerto Rican porridge
- countries: PR
- kinds: porridge
- ingredients: maize, milk

## DISH Q941518
- name: Comfit
- description: confectionery consisting of dried fruits, nuts, seeds or spices coated with sugar candy
- countries: (none)
- kinds: candy
- ingredients: dried fruit, spice, nut
- has Wikipedia article: en

## DISH Q94199292
- name: Royal Street Bananas Foster Crepe
- description: dish
- countries: US
- kinds: dessert
- ingredients: whipped cream, caramel, rum, crêpe, banana

## DISH Q94199914
- name: Bananas Foster French toast
- description: dish
- countries: US
- kinds: dish
- ingredients: bananas Foster, French toast, banana

## DISH Q94200211
- name: Bananas Foster ice cream
- description: dessert
- countries: US
- kinds: dessert, dish, ice cream
- ingredients: ice cream, banana

## DISH Q94200404
- name: Bananas Foster bread pudding
- description: dessert
- countries: US
- kinds: dessert, bread pudding
- ingredients: bread, banana

## DISH Q94202532
- name: 'Ohana Bread Pudding
- description: dessert
- countries: US
- kinds: dessert, bread pudding
- ingredients: bread pudding, banana

## DISH Q94203673
- name: Bananas Foster cheesecake
- description: dessert
- countries: US
- kinds: dessert, cheesecake
- ingredients: cheesecake, banana

## DISH Q94205988
- name: Shrimp étouffée
- description: dish
- countries: US
- kinds: dish, étouffée
- ingredients: green bell pepper, garlic, onion, peppercorn, shrimp, roux, Apium graveolens, cayenne pepper

## DISH Q94207661
- name: Crawfish étouffée
- description: American dish
- countries: US
- kinds: dish
- ingredients: étouffée, crayfish

## DISH Q94208532
- name: Shrimp po' boy
- description: American sandwich
- countries: US
- kinds: sandwich, po' boy
- ingredients: tomato, shrimp and prawn as food, pickle, mayonnaise, Lactuca sativa

## DISH Q94218682
- name: Vegan gumbo
- countries: (none)
- kinds: vegan food, gumbo

## DISH Q94263420
- name: Straw bread
- description: famine food
- countries: (none)
- kinds: bread, famine food

## DISH Q94279818
- name: Barte
- other names: {"eu": "Barte"}
- countries: ES
- kinds: bread, tradition, party

## DISH Q94328264
- name: Sweet potato shōchū
- other names: {"zh": "芋燒酎"}
- description: liquor made from sweet potato
- countries: JP
- kinds: liquor, shōchū
- has Wikipedia article: en

## DISH Q94342530
- name: Vegan jambalaya
- description: dish
- countries: US
- kinds: dish
- ingredients: jambalaya

## DISH Q94347107
- name: Oblietjie
- description: traditional South African food
- countries: (none)
- kinds: traditional food, cookie

## DISH Q943696
- name: Thenthuk
- description: food
- countries: (none)
- kinds: food, noodle soup
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q94449001
- name: Caldo de hongos de cazahuate
- other names: {"es": "Caldo de hongos de cazahuate"}
- countries: MX
- kinds: dish

## DISH Q945096
- name: Ćevapi
- other names: {"zh": "切瓦皮"}
- description: dish from Southeast Europe
- countries: (none)
- kinds: meat dish
- ingredients: savory, minced meat, peppercorn, paprika, lamb meat, beef, pork, sodium bicarbonate, Trigonella foenum-graecum, Allium sativum
- has Wikipedia article: en, zh

## DISH Q94524005
- name: Tubaani
- description: staple food in Northern Ghana
- countries: GH
- kinds: food
- ingredients: Bambara groundnut, cassava flour, black-eyed pea, water
- has Wikipedia article: en

## DISH Q94531971
- name: Chacualole
- other names: {"es": "Chacualole"}
- countries: MX
- kinds: dessert

## DISH Q945475
- name: Coleslaw
- other names: {"zh": "凉拌卷心菜"}
- description: salad consisting primarily of finely-shredded raw cabbage
- countries: (none)
- kinds: cabbage salad
- ingredients: Brassica oleracea var. capitata
- has Wikipedia article: en, zh

## DISH Q945669
- name: Pettole
- other names: {"fr": "pettole"}
- countries: IT
- cuisines: Arbëreshë cuisine
- kinds: antipasto, deep-fried food

## DISH Q94642761
- name: Corn salad
- description: dish made using corn
- countries: (none)
- kinds: salad, dish
- ingredients: maize

## DISH Q94642789
- name: Jerk chicken
- description: dish
- countries: JM
- kinds: dish, jerk, chicken dish
- ingredients: jerk spice, chicken

## DISH Q94702029
- name: Queso herreño
- description: Spanish cheese
- countries: ES
- kinds: cheese
- ingredients: cow's milk, sheep milk, goat milk

## DISH Q94719064
- name: Alligator po' boy
- description: dish
- countries: US
- kinds: sandwich, dish, po' boy
- ingredients: tomato, pickle, Alligator, mayonnaise, Lactuca sativa, bread

## DISH Q94835
- name: Coconut jam
- other names: {"zh": "咖央酱"}
- description: jam made from a base of coconut milk, eggs and sugar
- countries: (none)
- kinds: jam
- ingredients: coconut
- has Wikipedia article: en, zh

## DISH Q948460
- name: Morzeddhu
- other names: {"scn": "Morzeddhu"}
- countries: IT
- kinds: meat dish

## DISH Q948994
- name: Musakhan
- description: Palestinian Arab dish
- countries: JO, PS
- cuisines: Palestinian cuisine
- kinds: dish, chicken dish
- ingredients: sumac, onion, allspice, taboon bread, chicken as food, pine nut, olive oil, saffron
- has Wikipedia article: en

## DISH Q94928110
- name: Roast beef po' boys
- description: sandwich
- countries: US
- kinds: dish
- ingredients: roast beef, bread

## DISH Q94968509
- name: Red bread
- description: Bread famous form Al Ahsa
- countries: SA
- kinds: food, flatbread, Mischbrot
- ingredients: whole-wheat flour, date, Nigella sativa, sugar

## DISH Q94970885
- name: دبيازة
- other names: {"ar": "دبيازة"}
- countries: (none)
- kinds: dessert

## DISH Q95000248
- name: Mazapán de la Rosa
- description: Mexican peanut candy
- countries: MX
- kinds: dessert
- has Wikipedia article: en

## DISH Q950470
- name: Garum
- other names: {"zh": "魚醬"}
- description: fermented fish sauce used as a condiment
- countries: (none)
- kinds: fish sauce
- has Wikipedia article: en, zh

## DISH Q951187
- name: Mekitsa
- description: food
- countries: BG
- kinds: food, flatbread
- ingredients: yogurt
- has Wikipedia article: en

## DISH Q951361
- name: Vatrushka
- description: type of pastry
- countries: RU
- cuisines: Russian cuisine, Ukrainian cuisine
- kinds: pastry, pirozhki, pirog
- ingredients: tvorog, yeast dough, egg as food, sugar
- has Wikipedia article: en

## DISH Q951525
- name: Avial
- description: dish originating from Kerala, India
- countries: IN
- kinds: side dish, dish
- has Wikipedia article: en

## DISH Q95160847
- name: Crawfish bread
- description: dish
- countries: US
- kinds: dish
- ingredients: crayfish, bread

## DISH Q952111
- name: Podpłomyk
- description: food
- countries: PL
- kinds: food, flatbread
- ingredients: flour
- has Wikipedia article: en

## DISH Q95216296
- name: Lumberjacks’ dumplings
- description: traditional Austrian dish
- countries: AT
- cuisines: Austrian cuisine
- kinds: dish

## DISH Q952366
- name: Bocconotto
- description: type of pastry in Italia
- countries: IT
- kinds: dish, pastry, confectionery
- has Wikipedia article: en

## DISH Q953065
- name: Nam khao
- other names: {"zh": "辣米沙拉"}
- description: lao appetizer salad
- countries: LA
- kinds: salad, yam
- ingredients: rice
- has Wikipedia article: en

## DISH Q953395
- name: Mānuka honey
- other names: {"zh": "manuka pharm"}
- description: type of honey
- countries: NZ
- kinds: food, monofloral honey
- has Wikipedia article: en, zh

## DISH Q9534887
- name: 卜鴨肉
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q954266
- name: Mujigae-tteok
- description: rainbow rice cake
- countries: (none)
- kinds: tteok
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q95433527
- name: Rice pudding cake
- description: Rice pudding in Slovak and Czech cuisine
- countries: (none)
- kinds: dessert
- ingredients: milk, rice
- has Wikipedia article: en

## DISH Q954627
- name: Pannenkoek
- description: Dutch, Indonesian and South African pancake
- countries: (none)
- kinds: pancake, type of food or dish
- ingredients: bread
- has Wikipedia article: en

## DISH Q955779
- name: Krapfen
- description: German dessert food
- countries: (none)
- kinds: doughnut
- has Wikipedia article: en

## DISH Q956024
- name: Allgäuer Emmentaler
- description: type of cheese
- countries: DE
- kinds: Emmental, German cheese, cheese
- ingredients: cow's milk

## DISH Q9560748
- name: Aberém
- other names: {"pt": "aberém"}
- countries: (none)
- kinds: dish

## DISH Q956379
- name: Quibebé
- description: semi-sweet winter squash stew
- countries: BR
- kinds: purée, dish
- ingredients: Cucurbita
- has Wikipedia article: en

## DISH Q95639929
- name: Qizha
- description: semolina cake
- countries: PS, SY
- kinds: cake
- ingredients: qizha, semolina, seed
- has Wikipedia article: en

## DISH Q956595
- name: Idli
- other names: {"zh": "蒸米漿糕"}
- description: breakfast in South India
- countries: IN
- cuisines: Indian cuisine
- kinds: rice dish, breakfast, dinner
- ingredients: black lentil, Vigna mungo, rice
- has Wikipedia article: en, zh

## DISH Q95682948
- name: Hrstková polévka
- other names: {"cs": "hrstková polévka"}
- countries: (none)
- kinds: soup

## DISH Q95692894
- name: Jawzia Mousse
- description: Algerian Dessert
- countries: DZ
- kinds: mousse

## DISH Q9576217
- name: Acaçá
- description: maize dish in Brazil
- countries: BR
- kinds: dish
- has Wikipedia article: en

## DISH Q95799197
- name: Queen Anne’s Pocket Melon
- description: small variety of melon
- countries: (none)
- kinds: fruit, Cucumis melo

## DISH Q9580084
- name: Achar
- description: Indo-Portuguese dish
- countries: (none)
- kinds: dish

## DISH Q958759
- name: Bamiyeh
- countries: IR
- kinds: doughnut, pastry, confectionery
- ingredients: yogurt
- has Wikipedia article: en

## DISH Q959390
- name: Fermentum
- other names: {"zh": "聖餅運送"}
- description: Christian practice of distributing consecrated host between bishops to affirm fellowship
- countries: (none)
- kinds: sacramental bread, ritual
- has Wikipedia article: en

## DISH Q95950155
- name: Ishiyakiimo
- countries: (none)
- kinds: dish, roasted sweet potatoes

## DISH Q959599
- name: Arnadí
- description: dessert typical of the region of Valencia in Spain, made of pumpkin and sugar
- countries: ES
- cuisines: Valencian cuisine
- kinds: dessert
- ingredients: almond, Cucurbita maxima, sugar

## DISH Q95974446
- name: Balsamic Roasted Turkey Salad
- description: salad
- countries: US
- kinds: dish, salad
- ingredients: basil, turkey meat, Romaine lettuce, tomato

## DISH Q95974685
- name: Mar-a-Lago Turkey Burger
- description: dish
- countries: US
- kinds: dish, hamburger

## DISH Q95974737
- name: Turkey burgers
- description: hamburger made with turkey
- countries: US
- kinds: hamburger
- ingredients: turkey meat

## DISH Q95974747
- name: Turkey soup
- description: type of soup
- countries: (none)
- kinds: dish, soup
- ingredients: turkey meat, onion, stock, Apium graveolens, carrot

## DISH Q95980535
- name: Muakis
- other names: {"ca": "Muakis"}
- countries: (none)
- kinds: food, fartons
- ingredients: fartons, chocolate

## DISH Q95985516
- name: Frijoles quebrados
- other names: {"es": "Frijoles quebrados"}
- countries: MX
- kinds: dish

## DISH Q95990169
- name: Cuca
- countries: BR
- kinds: cake

## DISH Q95994107
- name: Nut cake
- countries: (none)
- kinds: torte
