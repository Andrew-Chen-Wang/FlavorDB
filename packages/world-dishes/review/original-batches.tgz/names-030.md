# Review batch names-030

## DISH Q181195
- name: Taiyaki
- other names: {"zh": "鯛魚燒"}
- description: Japanese fish-shaped cake
- countries: JP
- kinds: wagashi
- ingredients: waffle, Vigna angularis, batter
- has Wikipedia article: en, zh

## DISH Q1812421
- name: White Rabbit Creamy Candy
- other names: {"zh": "大白兔奶糖"}
- description: Chinese brand of milk candy
- countries: (none)
- kinds: caramel
- has Wikipedia article: en, zh

## DISH Q18124795
- name: Festy cock
- description: Scottish alternative to the pancake
- countries: (none)
- kinds: pudding
- has Wikipedia article: en

## DISH Q18127051
- name: Kwati
- description: Nepali bean soup
- countries: (none)
- kinds: food, soup
- ingredients: Vigna mungo
- has Wikipedia article: en

## DISH Q18128673
- name: Nevzine dessert
- description: Turkish dessert
- countries: TR
- cuisines: Turkish cuisine
- kinds: type of food or dish, dessert
- ingredients: Sesame paste, pekmez, walnut
- has Wikipedia article: en

## DISH Q1813527
- name: Biff à la Lindström
- description: Swedish meat and vegetable dish
- countries: SE
- cuisines: Swedish cuisine
- kinds: beef dish
- ingredients: minced meat, beef, Beta vulgaris, Capparis, egg as food, onion, potato
- has Wikipedia article: en

## DISH Q181418
- name: Buchteln
- description: sweet rolls made of yeast dough
- countries: CZ
- cuisines: German cuisine, Czech cuisine
- kinds: viennoiserie, sweet pastry
- ingredients: baker's yeast, peel, egg as food, flour, butter, table salt, sugar, milk, jam
- has Wikipedia article: en

## DISH Q18145066
- name: Cream of asparagus soup
- other names: {"zh": "奶油芦笋汤"}
- description: food
- countries: (none)
- kinds: vegetable soup, cream soup
- ingredients: asparagus, stock, cream
- has Wikipedia article: en, zh

## DISH Q18149982
- name: Ciceri e Tria
- description: pasta dish in the Italian cuisine that originated in Apulia
- countries: IT
- kinds: pasta dish
- ingredients: chickpea, pasta
- has Wikipedia article: en

## DISH Q18150258
- name: Crocetta of Caltanissetta
- other names: {"zh": "卡爾塔尼塞塔十字架"}
- description: Italian sweet pastry
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q1815545
- name: Leipziger Lerche
- description: Dish made from skylarks in Leipzig
- countries: (none)
- kinds: dish

## DISH Q1815579
- name: Leipziger Räbchen
- other names: {"de": "Leipziger Räbchen"}
- countries: (none)
- kinds: dish

## DISH Q181572
- name: Peperoncino
- description: Italian name for hot chili pepper
- countries: IT
- kinds: food ingredient, organisms known by a particular common name, chili pepper
- has Wikipedia article: en

## DISH Q1815839
- name: Pissaladière
- other names: {"zh": "尼斯洋葱塔"}
- description: Provençal-Ligurian dish
- countries: FR, IT
- kinds: dish
- ingredients: Pissalat, Olive de Nice, onion, bread
- has Wikipedia article: en, zh

## DISH Q18164838
- name: French onion dip
- other names: {"zh": "法式洋蔥蘸醬"}
- description: American dip flavored with onion
- countries: US
- kinds: culinary speciality, dip
- ingredients: onion
- has Wikipedia article: en

## DISH Q18169525
- name: Polonaise
- other names: {"nl": "Polonaise"}
- description: pastry
- countries: (none)
- kinds: meringue, pastry

## DISH Q1817903
- name: Runeberg's torte
- description: Finnish pastry flavored with almonds and arrack or rum
- countries: FI
- kinds: tart
- ingredients: arrack, rum, Prunus dulcis
- has Wikipedia article: en

## DISH Q18187839
- name: Nougat chinois
- countries: (none)
- kinds: pastry

## DISH Q1819455
- name: Locro
- other names: {"zh": "洛克罗"}
- description: South American stew
- countries: PE, BO, EC
- cuisines: Peruvian cuisine, Bolivian cuisine, Ecuadorian cuisine
- kinds: meal, stew
- ingredients: meat
- has Wikipedia article: en

## DISH Q18201801
- name: Maccheroni alla molinara
- description: type of pasta
- countries: IT
- kinds: type of pasta, pasta, durum wheat pasta
- has Wikipedia article: en

## DISH Q18202791
- name: Farinata di cavolo nero
- other names: {"fr": "Farinata di cavolo nero"}
- countries: IT
- kinds: soup

## DISH Q1820454
- name: Panko
- description: flaky bread crumbs used in Japanese cuisine
- countries: JP
- kinds: Japanese cuisine, bread crumbs
- ingredients: bread
- has Wikipedia article: en

## DISH Q18219998
- name: Pork chop rice
- other names: {"zh": "豬排飯"}
- description: Hong Kong and Taiwanese dish
- countries: (none)
- kinds: pork dish
- ingredients: cooked rice
- has Wikipedia article: zh

## DISH Q1823666
- name: Groninger cake
- description: spicy gingerbread-like cake from the province of Groningen, Netherlands
- countries: (none)
- kinds: food, cookie

## DISH Q1827035
- name: Lentil soup
- other names: {"zh": "小扁豆汤"}
- description: type of soup
- countries: (none)
- kinds: soup, dish
- ingredients: lentil, spice, water
- has Wikipedia article: en, zh

## DISH Q1827530
- name: Lippische Strohsemmel
- countries: (none)
- kinds: pastry

## DISH Q18276594
- name: Krachel
- description: Moroccan bread roll
- countries: MA
- kinds: bread roll, brioche
- ingredients: anise seed, sesame seed, baker's yeast, egg as food, flour, butter, sugar, milk
- has Wikipedia article: en

## DISH Q18285591
- name: Alambre
- description: Mexican food
- countries: MX
- kinds: food, beef dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q18288329
- name: Fregolotta
- other names: {"it": "Fregolotta"}
- countries: IT
- kinds: dessert

## DISH Q18288877
- name: Piparelle PAT
- other names: {"zh": "Piparelle PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, dessert, baked good

## DISH Q18289122
- name: Sgriesolona
- other names: {"it": "Sgriesolona"}
- countries: IT
- kinds: dessert

## DISH Q18289855
- name: Flötgröt
- other names: {"sv": "Flötgröt"}
- countries: (none)
- kinds: porridge

## DISH Q18290156
- name: Glödhoppa
- other names: {"sv": "Glödhoppa"}
- countries: SE
- kinds: bread
- ingredients: rye flour, golden syrup, wheat flour

## DISH Q18291301
- name: Kolbulle
- description: thick pancake with pork made directly in a frying pan, often over open fire
- countries: (none)
- kinds: dish, fläskpannkaka
- ingredients: pork, lard, flour, table salt, water

## DISH Q182940
- name: Dessert
- other names: {"zh": "甜點"}
- description: course that concludes a meal, usually sweet
- countries: (none)
- kinds: food, dish, sweet dish, course, type of food or dish
- has Wikipedia article: en, zh

## DISH Q1833211
- name: Haagse bluf
- description: Dutch dessert
- countries: (none)
- kinds: dessert, recipe
- ingredients: egg white, powdered sugar, juice

## DISH Q18332174
- name: Restriktionsrätt
- other names: {"sv": "Restriktionsrätt"}
- countries: (none)
- kinds: dish

## DISH Q18335617
- name: Ankodama
- countries: JP
- kinds: dagashi
- ingredients: red bean paste

## DISH Q18336577
- name: あんずボー
- other names: {"ja": "あんずボー"}
- countries: (none)
- kinds: dagashi

## DISH Q18337173
- name: 醬汁仙貝
- countries: JP
- kinds: type of food or dish, dagashi

## DISH Q18338265
- name: Steak burger
- description: type of sandwich
- countries: (none)
- kinds: hamburger
- has Wikipedia article: en

## DISH Q18339078
- name: Pu phat phong kari
- description: Thai dish consisting of stir-fried crab meat with curry powder
- countries: TH
- kinds: dish, crab dish
- ingredients: crab meat, curry powder

## DISH Q18343466
- name: Garmugia
- description: Italian soup
- countries: IT
- kinds: food, soup
- has Wikipedia article: en

## DISH Q18343677
- name: Pork blood soup
- description: soup made with pork blood
- countries: (none)
- kinds: blood soup, pork dish
- ingredients: blood as food
- has Wikipedia article: en

## DISH Q18343984
- name: Kuaitiao khua kai
- other names: {"zh": "泰式鸡肉炒粿条"}
- description: Thai dish with noodles and chicken
- countries: TH
- kinds: kóe-tiâu
- has Wikipedia article: en

## DISH Q18344221
- name: Prawn cocktail, steak and Black Forest gateau
- description: British cuisine
- countries: GB
- cuisines: British cuisine
- kinds: beef dish
- has Wikipedia article: en

## DISH Q18344267
- name: Mexican bread
- description: baked food made of flour, water or milk and other ingredients
- countries: MX
- kinds: bread
- has Wikipedia article: en

## DISH Q18344618
- name: Ginestrata
- description: Italian egg-based soup
- countries: IT
- kinds: food, soup
- has Wikipedia article: en

## DISH Q18349210
- name: Cream of broccoli soup
- description: soup prepared with broccoli, stock, and milk or cream
- countries: (none)
- kinds: cream soup, broccoli soup
- ingredients: broccoli
- has Wikipedia article: en

## DISH Q18354045
- name: Samlar kako
- description: Cambodian soup
- countries: KH
- kinds: soup
- ingredients: fruit, kroeung, prahok, herb, vegetable
- has Wikipedia article: en

## DISH Q18355112
- name: Turkey Devonshire
- description: open sandwich
- countries: US
- kinds: open sandwich
- ingredients: cheese sauce, tomato, turkey meat, bacon, bread
- has Wikipedia article: en

## DISH Q18355332
- name: Sarsiado
- description: Filipino fish dish with tomatoes and eggs
- countries: PH
- kinds: food, beef dish
- ingredients: fish
- has Wikipedia article: en

## DISH Q18358623
- name: Meatball pizza
- description: pizza with meatballs
- countries: US
- has Wikipedia article: en

## DISH Q183599
- name: Halva
- other names: {"zh": "哈尔瓦甜食"}
- description: confections often made from nut butters or flours
- countries: (none)
- kinds: pastry, confectionery, Sugar confectionery (including white chocolate), not containing cocoa, Sweet confectionery products (ОКП 91 2000)
- ingredients: sesame seed, corn starch, sunflower seed, semolina, oil, flour, sugar
- has Wikipedia article: en, zh

## DISH Q18384393
- name: Hashed beef
- description: Japanese dish of sliced beef cooked in demi-glace sauce
- countries: (none)
- kinds: meat dish

## DISH Q18386680
- name: Sutarfeni
- description: Indian sweet
- countries: IN
- kinds: food, confectionery
- ingredients: rice
- has Wikipedia article: en

## DISH Q18388431
- name: Piaya
- description: Negrese flatbread
- countries: PH
- kinds: food, pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q18388465
- name: Pickle soup
- description: soup prepared with pickled vegetables
- countries: (none)
- kinds: vegetable soup
- ingredients: pickle, pickled cucumber
- has Wikipedia article: en

## DISH Q18388530
- name: Pig wing
- description: pork dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q18388803
- name: Pizza capricciosa
- description: pizza prepared with mozzarella cheese, Italian baked ham, mushroom, artichoke and tomato
- countries: IT
- ingredients: fiambre, globe artichoke, olive, edible mushroom, mozzarella
- has Wikipedia article: en

## DISH Q18388807
- name: Pizza pugliese
- description: style of pizza, named after the Apulia region
- countries: IT
- cuisines: Italian cuisine
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q18389634
- name: Pukala
- description: traditional Nepalese dish of boiled and fried variety meats of the water buffalo
- countries: NP
- kinds: dish
- ingredients: water buffalo
- has Wikipedia article: en

## DISH Q18391184
- name: Rosquillo
- description: Filipino cookies
- countries: PH
- kinds: cookie
- ingredients: shortening, egg as food, flour, baking powder
- has Wikipedia article: en

## DISH Q18392315
- name: German fries
- other names: {"zh": "德国煎土豆"}
- description: preparation of fries
- countries: (none)
- kinds: fried potatoes, potato dish
- has Wikipedia article: en, zh

## DISH Q18392504
- name: Persian doughnut
- description: type of doughnut
- countries: (none)
- kinds: doughnut
- has Wikipedia article: en

## DISH Q18392972
- name: Steak and eggs
- description: breakfast dish consisting of beefsteak and fried eggs
- countries: AU
- cuisines: Australian cuisine
- kinds: egg dish, beef dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q18393991
- name: Rellenitos de Plátano
- description: Guatemalan dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q18400196
- name: Petit épeautre de Haute-Provence
- countries: FR
- kinds: cereal

## DISH Q18404521
- name: Ashlan-fu
- other names: {"zh": "回民凉粉"}
- description: Dungan dish
- countries: (none)
- kinds: dish
- ingredients: noodle, omelette
- has Wikipedia article: zh

## DISH Q18409302
- name: Talkan
- description: food ingredient
- countries: (none)
- cuisines: Turkic сuisine
- kinds: food ingredient, kama

## DISH Q18412283
- name: Pintxos de Donostia
- other names: {"de": "Pintxos de Donostia"}
- countries: (none)
- kinds: dish

## DISH Q18412855
- name: Sour meat
- description: German dish made from pork
- countries: (none)
- kinds: German cuisine, dish

## DISH Q18415236
- name: Russe
- description: French pastry
- countries: (none)
- kinds: pastry

## DISH Q18416565
- name: Bulgarian rose oil
- description: essential oil
- countries: BG
- kinds: essential oil

## DISH Q18417726
- name: Gazpacho pastor
- countries: (none)
- kinds: dish

## DISH Q18424481
- name: Pluj-zupka
- other names: {"pl": "Pluj-zupka"}
- countries: (none)
- kinds: dish

## DISH Q18425077
- name: Marinated mushrooms with a cone
- countries: (none)
- kinds: dish
- ingredients: pine cone, marinade, edible mushroom

## DISH Q18426199
- name: Swedish potato sausage
- countries: (none)
- kinds: dish

## DISH Q1842635
- name: Vanilla wafer
- countries: (none)
- kinds: pastry, wafer

## DISH Q184291
- name: Zedernbrot
- description: kind of Christmas cake
- countries: (none)
- kinds: Christmas cookies

## DISH Q18432211
- name: Irish breakfast
- description: Irish meal
- countries: (none)
- kinds: full breakfast
- has Wikipedia article: en

## DISH Q18433958
- name: Ruchańce drożdżowe
- other names: {"pl": "ruchańce drożdżowe"}
- countries: PL
- kinds: dish

## DISH Q18435013
- name: Suska sechlońska
- description: Polish smoked prune
- countries: PL
- kinds: traditional food, prune
- ingredients: plum

## DISH Q18450657
- name: Glassdrink
- other names: {"sv": "Glassdrink"}
- countries: (none)
- kinds: dessert

## DISH Q18450786
- name: Hammelsadel
- other names: {"sv": "Hammelsadel"}
- countries: (none)
- kinds: dish
- ingredients: lamb meat, meat chop

## DISH Q18452355
- name: Oxhare
- other names: {"sv": "Oxhare"}
- countries: (none)
- kinds: meat dish

## DISH Q18454935
- name: Plätt
- other names: {"da": "Plätt"}
- countries: (none)
- kinds: dish, pancake

## DISH Q18455759
- name: Ikadabae
- countries: JP
- kinds: food, Tsukudani
- ingredients: Zacco platypus

## DISH Q18456023
- name: Saikoro caramel
- countries: (none)
- kinds: caramel

## DISH Q18456279
- name: Terasi
- other names: {"id": "Terasi"}
- countries: ID
- kinds: shrimp paste

## DISH Q18456374
- name: Nước mắm
- description: fish sauce in Vietnamese cuisine
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: condiment, fish sauce

## DISH Q18456540
- name: Big Katsu
- description: Japanese snack
- countries: JP
- kinds: snack, dagashi, food
- has Wikipedia article: en

## DISH Q18459433
- name: Kōchi yokanpan
- countries: (none)
- kinds: pastry
- ingredients: Yōkan

## DISH Q18459801
- name: 무오이 똠
- other names: {"ko": "무오이 똠"}
- countries: VN
- kinds: spice
- ingredients: Cymbopogon, dried shrimp, monosodium L-glutamate, chili pepper, Allium sativum, table salt, carrot

## DISH Q18464502
- name: Choereg
- description: Armenian sweet bread
- countries: AM
- kinds: sweet bread
- ingredients: mahleb

## DISH Q18464582
- name: Goan sausage
- description: Goan Sausage - Indo-Portuguese cuisine
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q18464639
- name: Ishlykly
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q18465111
- name: Chuvisco
- other names: {"pt": "chuvisco"}
- countries: (none)
- kinds: confectionery

## DISH Q18465171
- name: Presunto de Barroso
- description: Portuguese ham
- countries: (none)
- kinds: ham

## DISH Q18465188
- name: Presunto de Santana da Serra
- description: Portuguese ham
- countries: (none)
- kinds: ham

## DISH Q18465195
- name: Presunto de Vinhais
- description: Portuguese ham
- countries: (none)
- kinds: ham

## DISH Q18465204
- name: Alentejo ham
- description: Portuguese ham
- countries: (none)
- kinds: ham

## DISH Q18466245
- name: Cabrito da Beira
- description: Portuguese goat meat
- countries: PT
- kinds: goat meat

## DISH Q18466254
- name: Cabrito das Terras Altas do Minho
- description: Portuguese goat meat
- countries: PT
- kinds: goat meat

## DISH Q18466279
- name: Cabrito de Barroso
- description: Portuguese goat meat
- countries: PT
- kinds: goat meat

## DISH Q18466285
- name: Cabrito do Alentejo
- description: Portuguese goat meat
- countries: PT
- kinds: goat meat

## DISH Q18467298
- name: Cajuada
- other names: {"pt": "cajuada"}
- countries: (none)
- kinds: confectionery

## DISH Q18469720
- name: Laħam taż-żiemel
- description: horse meat stew
- countries: MT
- kinds: meat dish, stew
- ingredients: horse meat

## DISH Q18470462
- name: Requeixo
- description: traditional dairy product from Galicia, Spain
- countries: ES
- kinds: dairy product, cheese

## DISH Q18471291
- name: Viúvas
- description: Portuguese pastry
- countries: PT
- kinds: pastry

## DISH Q18472743
- name: Breaded mushrooms
- description: Irish dish
- countries: IE
- kinds: dish

## DISH Q18474800
- name: Mel da Serra de Monchique
- description: Portuguese honey
- countries: (none)
- kinds: honey

## DISH Q18474808
- name: Mel da Terra Quente
- description: Portuguese honey
- countries: (none)
- kinds: honey

## DISH Q18474824
- name: Mel do Parque de Montezinho
- description: Portuguese honey
- countries: (none)
- kinds: honey

## DISH Q18479498
- name: Fritada de bacalhau
- other names: {"pt": "fritada de bacalhau"}
- countries: (none)
- kinds: fish dish

## DISH Q18483622
- name: Salmão assado na chapa
- other names: {"pt": "Salmão assado na chapa"}
- countries: (none)
- kinds: fish dish

## DISH Q18485223
- name: Widow's soup
- countries: (none)
- kinds: soup

## DISH Q18499418
- name: Azeite de Trás-os-Montes PDO
- description: Portuguese PDO olive oil
- countries: PT
- kinds: olive oil

## DISH Q18499420
- name: Azeite do Alentejo Interior
- other names: {"pt": "Azeite do Alentejo Interior"}
- countries: PT
- kinds: olive oil

## DISH Q18499424
- name: Azeites da Beira Interior
- other names: {"pt": "Azeites da Beira Interior"}
- countries: PT
- kinds: olive oil

## DISH Q18499426
- name: Azeites do Norte Alentejano
- other names: {"pt": "Azeites do Norte Alentejano"}
- countries: PT
- kinds: olive oil

## DISH Q18499428
- name: Azeites do Ribatejo
- other names: {"pt": "Azeites do Ribatejo"}
- countries: PT
- kinds: olive oil

## DISH Q18499429
- name: Azeitona de conserva Negrinha de Freixo
- other names: {"pt": "Azeitona de conserva Negrinha de Freixo"}
- countries: PT
- kinds: olive

## DISH Q18499432
- name: Azeitonas de Conserva de Elvas e Campo Maior
- other names: {"pt": "Azeitonas de Conserva de Elvas e Campo Maior"}
- countries: PT
- kinds: olive

## DISH Q18499554
- name: Baby beef
- countries: (none)
- kinds: beef dish

## DISH Q18499683
- name: Bananada
- description: sweet made from banana and sugar
- countries: (none)
- kinds: confectionery

## DISH Q18500460
- name: Bica de azeite
- description: Portuguese traditional bread
- countries: PT
- kinds: bread

## DISH Q18500743
- name: Bolinho de frango
- other names: {"pt": "bolinho de frango"}
- countries: (none)
- kinds: dish

## DISH Q1850311
- name: Sunday roast
- other names: {"zh": "週日烤肉"}
- description: traditional meal associated with Great Britain
- countries: (none)
- kinds: potato dish
- ingredients: potato, Yorkshire pudding, gravy, roast beef, stuffing
- has Wikipedia article: en, zh

## DISH Q1853883
- name: Ostkaka
- other names: {"zh": "瑞典起司蛋糕"}
- description: traditional Swedish oven-baked dessert based on milk, flour, and rennet, particularly in Hälsingland and Småland
- countries: SE
- cuisines: Swedish cuisine
- kinds: dish, New York-style cheesecake
- ingredients: rennet
- has Wikipedia article: en

## DISH Q18542598
- name: Pizza quattro stagioni
- other names: {"zh": "四季披薩"}
- description: pizza variety
- countries: IT
- kinds: dish
- ingredients: fiambre, globe artichoke, tomato, edible mushroom, mozzarella
- has Wikipedia article: en, zh

## DISH Q185457
- name: Meat salad
- countries: (none)
- kinds: salad

## DISH Q18547489
- name: Thasian sauce
- description: fish sauce from Thasos, used as a condiment in the cuisines of ancient Greece
- countries: (none)
- kinds: fish sauce, condiment

## DISH Q1855212
- name: Brussels waffle
- description: light, crispy, rectangular waffle with large pockets made with an egg-white-leavened or yeast-leavened batter
- countries: BE
- kinds: dish, waffle
- ingredients: egg white, yeast, flour, butter, table salt, milk, drinking water
- has Wikipedia article: en

## DISH Q185583
- name: Candy
- other names: {"zh": "糖果"}
- description: confection made with sugar
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: confectionery
- ingredients: sweetener, sugar
- has Wikipedia article: en, zh

## DISH Q18558342
- name: Malsouka
- description: North African dough sheets
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1856158
- name: Viaticum
- description: Holy Communion received near death
- countries: (none)
- kinds: sacramental bread
- has Wikipedia article: en

## DISH Q18562875
- name: Craquelins
- description: Wikimedia disambiguation page
- countries: (none)
- kinds: Wikimedia disambiguation page, biscuit

## DISH Q1858518
- name: Lobio
- other names: {"zh": "羅比奧"}
- description: traditional Georgian stew
- countries: GE
- kinds: stew
- ingredients: pomegranate, bean, Phaseolus
- has Wikipedia article: en, zh

## DISH Q1858875
- name: Opera cake
- other names: {"zh": "歌剧蛋糕"}
- description: chocolated pastry of France
- countries: FR
- kinds: cake
- ingredients: sponge cake
- has Wikipedia article: en, zh

## DISH Q18589142
- name: Arroz junto
- description: Puerto Rican rice dish
- countries: PR
- kinds: dish
- ingredients: bean, meat, rice
- has Wikipedia article: en

## DISH Q18590759
- name: Valladolid bread
- description: a typically Castilian bread called candeal bread, sobao or bregado
- countries: (none)
- kinds: bread, food

## DISH Q18595468
- name: Merveilleux
- description: Belgian meringue dessert
- countries: BE
- kinds: dessert, cake
- ingredients: whipped cream, meringue
- has Wikipedia article: en

## DISH Q1860324
- name: Apenkots
- other names: {"nl": "apenkots"}
- countries: (none)
- kinds: dessert, type of food or dish
- ingredients: whipped cream, quark, sugar, banana

## DISH Q18606556
- name: Jianbing
- other names: {"zh": "煎饼"}
- description: crêpe-like Chinese breakfast street food made from wheat and grain flour batter with egg
- countries: CN
- kinds: bing, pancake
- ingredients: scallion, hoisin sauce, egg as food, flour
- has Wikipedia article: en, zh

## DISH Q18611338
- name: Octopus salad
- description: Turkish entree dish, salad or meze of octopus
- countries: (none)
- kinds: salad
- ingredients: octopus as food

## DISH Q18613289
- name: Gâteau magique
- description: French triple-layered cake
- countries: (none)
- kinds: pie
- has Wikipedia article: en

## DISH Q18618696
- name: Boat noodles
- other names: {"zh": "泰國船麵"}
- description: Thai noodle dish
- countries: TH
- cuisines: Thai cuisine
- kinds: noodle dish
- ingredients: dark soy sauce, fermented bean curd, rice noodle
- has Wikipedia article: en, zh

## DISH Q18623828
- name: Onsdagssnegl
- other names: {"da": "onsdagssnegl"}
- countries: (none)
- kinds: cinnamon roll

## DISH Q1862619
- name: Khubz
- description: round leavened Middle-Eastern flatbread
- countries: (none)
- kinds: food, bread

## DISH Q18630622
- name: Schwedenbombe
- description: Austrian brand of chocolate-coated marshmallow treat
- countries: (none)
- kinds: sweetmeat, chocolate-coated marshmallow treats

## DISH Q1863568
- name: Avgolemono
- description: Greek egg-lemon sauce or soup
- countries: GR
- cuisines: Greek cuisine
- kinds: soup, egg-lemon sauce
- ingredients: lemon juice, broth, egg as food
- has Wikipedia article: en

## DISH Q1863704
- name: Gentse paardenlookworst
- countries: BE
- kinds: sausage

## DISH Q186385
- name: Caviar
- other names: {"zh": "鱼子酱"}
- description: salt-cured fish-eggs of the Acipenseridae family
- countries: (none)
- kinds: roe, fish dish
- ingredients: roe, sodium chloride
- has Wikipedia article: en, zh

## DISH Q18638792
- name: Campanile
- description: Easter cake typical of the island of Corsica
- countries: FR
- cuisines: cuisine of Corsica
- kinds: confectionery
- has Wikipedia article: en

## DISH Q18651894
- name: Chitose-ame
- other names: {"zh": "千岁饴"}
- countries: (none)
- kinds: wagashi
- has Wikipedia article: zh

## DISH Q18653699
- name: Moon shrimp cake
- other names: {"zh": "月亮蝦餅"}
- description: Taiwanese dish
- countries: TW
- kinds: dish, prawn cake
- has Wikipedia article: en, zh

## DISH Q18655600
- name: Schuimpje
- other names: {"nl": "schuimpje"}
- description: candy made of maringue
- countries: (none)
- kinds: Strooigoed, sugar candy, Sinterklaas candy

## DISH Q18657398
- name: Caldo de piedra
- other names: {"zh": "瓦哈卡石頭湯"}
- description: Mexican fish broth from Oaxaca
- countries: MX
- kinds: fish broth
- ingredients: fish as food, stone
- has Wikipedia article: zh

## DISH Q18657822
- name: Oshizushi
- other names: {"zh": "箱押壽司"}
- countries: (none)
- kinds: sushi
- has Wikipedia article: en, zh

## DISH Q18659653
- name: Qiaojiao Beef
- other names: {"zh": "跷脚牛肉"}
- description: beef dish originated from Leshan, Sichuan, China
- countries: (none)
- kinds: beef dish
- ingredients: beef
- has Wikipedia article: zh

## DISH Q1866826
- name: Ljutenica
- description: dish
- countries: BG, MK, RS
- cuisines: Bulgarian cuisine
- kinds: condiment
- ingredients: vegetable oil, paprika, tomato, Allium sativum, carrot
- has Wikipedia article: en

## DISH Q18671599
- name: Tas kebab
- description: Turkish veal or mutton stew
- countries: TR
- kinds: food, stew
- has Wikipedia article: en

## DISH Q186817
- name: Porridge
- other names: {"zh": "餬"}
- description: food commonly eaten as a breakfast cereal dish, made by boiling ground, crushed or chopped starchy plants, typically grain, in water or milk
- countries: (none)
- kinds: type of food or dish, dish, food product, kasha
- ingredients: cereal
- has Wikipedia article: en, zh

## DISH Q1868800
- name: Lomo embuchado
- countries: ES
- kinds: sausage
- ingredients: pork

## DISH Q18691420
- name: Silakkalaatikko
- other names: {"fi": "silakkalaatikko"}
- countries: (none)
- kinds: casserole

## DISH Q18692770
- name: Kuzu paça
- description: lamb offal dish from Turkey
- countries: TR
- kinds: food

## DISH Q18693798
- name: Fazer Liqueur Fills
- other names: {"fi": "Fazer Liqueur Fills"}
- countries: (none)
- kinds: candy

## DISH Q18693799
- name: Finlandia (candy)
- description: marmalade candy brand
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q18693805
- name: Hopeatoffee
- description: Finnish brand of candy bar
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q18693843
- name: Pax
- other names: {"sv": "Pax"}
- countries: (none)
- kinds: candy

## DISH Q18693848
- name: Puikula
- other names: {"fi": "Puikula"}
- countries: (none)
- kinds: bread

## DISH Q18693861
- name: Susu
- other names: {"fi": "Susu"}
- countries: (none)
- kinds: chocolate bar

## DISH Q18693973
- name: Kakko
- description: Finnish bread
- countries: FI

## DISH Q18693976
- name: Kaltiainen
- other names: {"fi": "Kaltiainen"}
- countries: (none)
- kinds: bread

## DISH Q18693987
- name: Clot soup
- description: traditional Finnish dish
- countries: FI
- kinds: dish, traditional food

## DISH Q18693991
- name: Kovaohranen
- other names: {"fi": "Kovaohranen"}
- countries: (none)
- kinds: bread

## DISH Q18694007
- name: Kylvöleipä
- other names: {"fi": "Kylvöleipä"}
- countries: (none)
- kinds: bread

## DISH Q18694027
- name: Läskisoosi
- description: traditional pork sauce in Finland
- countries: FI
- kinds: dish
- has Wikipedia article: en

## DISH Q18694046
- name: Ohrakryynivelli
- other names: {"fi": "Ohrakryynivelli"}
- countries: (none)
- kinds: dish

## DISH Q18694062
- name: Posso
- other names: {"fi": "Posso"}
- countries: FI
- kinds: pastry

## DISH Q18694083
- name: Rasvarieska
- other names: {"fi": "Rasvarieska"}
- countries: (none)
- kinds: bread

## DISH Q18694086
- name: Rievä
- description: Finnish bread
- countries: FI
- kinds: bread

## DISH Q18694089
- name: Rusupiirakka
- other names: {"fi": "Rusupiirakka"}
- countries: (none)
- kinds: pie

## DISH Q18697025
- name: Windbeutel
- description: German choux pastry ball
- countries: (none)
- kinds: profiterole

## DISH Q18701170
- name: 真っ赤な誘惑北本トマトカレー
- other names: {"ja": "真っ赤な誘惑北本トマトカレー"}
- countries: JP
- kinds: Japanese curry rice
- ingredients: tomato

## DISH Q1872856
- name: Blood tongue
- other names: {"zh": "血舌餚肉"}
- description: German head cheese with tongue
- countries: DE
- kinds: sausage, head cheese
- ingredients: tongue, blood
- has Wikipedia article: en

## DISH Q1873129
- name: Lucca-Augen (Gebäck)
- other names: {"de": "Lucca-Augen (Gebäck)"}
- countries: (none)
- kinds: viennoiserie

## DISH Q1873131
- name: Lucca-Augen
- other names: {"de": "Lucca-Augen"}
- countries: (none)
- kinds: dish

## DISH Q18747677
- name: Xoriço de León
- other names: {"ca": "xoriço de León"}
- countries: (none)
- kinds: chorizo, embutido

## DISH Q18752052
- name: Tejesmálé
- other names: {"hu": "Tejesmálé"}
- countries: HU, RO
- kinds: cake

## DISH Q18755741
- name: Çoban kavurma
- description: not be confused with "korma"
- countries: TR
- kinds: dish

## DISH Q1875794
- name: Air chocolate
- description: chocolate with tiny gas bubbles inside
- countries: (none)
- kinds: chocolate
- ingredients: gas, chocolate
- has Wikipedia article: en

## DISH Q18758781
- name: Chimaek
- other names: {"zh": "韩式炸鸡和啤酒"}
- description: Korean fried chicken and beer
- countries: KR
- cuisines: South Korean cuisine
- kinds: chicken dish
- has Wikipedia article: en, zh

## DISH Q18785184
- name: Carrozza
- description: Italian fried cheese sandwich
- countries: IT
- kinds: sandwich
- has Wikipedia article: en

## DISH Q1879648
- name: Löffelerbsen
- other names: {"de": "Löffelerbsen"}
- countries: (none)
- kinds: soup, pea soup

## DISH Q1883153
- name: Toast waffle
- countries: (none)
- kinds: waffle, type of food or dish

## DISH Q188420
- name: Sambar
- other names: {"zh": "桑巴湯"}
- description: Indian food
- countries: IN
- kinds: stew
- ingredients: lentil, Tamarindus indica
- has Wikipedia article: en, zh

## DISH Q1884243
- name: Paling in 't groen
- description: Belgian dish
- countries: BE
- cuisines: cuisine of Belgium
- kinds: fish dish
- has Wikipedia article: en

## DISH Q1884503
- name: Veggie burger
- other names: {"zh": "素食漢堡"}
- description: hamburger-like sandwich made from vegetables
- countries: (none)
- kinds: plant-based meat analogue, burger, imitation food, type of food or dish
- ingredients: halloumi, tofu, Lens culinaris, soybean, bun, condiment
- has Wikipedia article: en, zh

## DISH Q1885418
- name: Cockchafer soup
- other names: {"zh": "欧洲鳃金龟汤"}
- description: dish
- countries: (none)
- kinds: food, soup
- ingredients: Melolontha melolontha
- has Wikipedia article: en

## DISH Q1885478
- name: Mailänderli
- description: type of Swiss Christmas cookie
- countries: CH
- kinds: Christmas cookies
- ingredients: flour, butter, sugar

## DISH Q1885539
- name: Arnhemse meisjes
- description: Dutch cookies
- countries: (none)
- kinds: cookie

## DISH Q1885761
- name: Mainzer Schinken
- other names: {"de": "Mainzer Schinken"}
- countries: (none)
- kinds: raw ham

## DISH Q1886310
- name: Mee siam
- other names: {"zh": "馬來滷米粉"}
- description: Thai noodle dish
- countries: (none)
- kinds: dish, rice noodle
- ingredients: rice noodle
- has Wikipedia article: en, zh

## DISH Q1886359
- name: Makiełki
- other names: {"de": "Makiełki"}
- countries: (none)
- kinds: dish

## DISH Q1886522
- name: Makroudh
- other names: {"zh": "馬克魯德"}
- description: Maghrebi pastry made with wheat semolina and date paste
- countries: (none)
- kinds: cookie, pastry
- ingredients: date, semolina
- has Wikipedia article: en, zh

## DISH Q1886687
- name: Malakoff
- description: Swiss fried cheese balls
- countries: CH
- kinds: dish, beignet
- ingredients: cheese
- has Wikipedia article: en

## DISH Q1887892
- name: Maluns
- description: traditional potato dish in Switzerland and Austria
- countries: AT, CH
- kinds: potato dish
- ingredients: potato, flour, butter
- has Wikipedia article: en

## DISH Q18883046
- name: Mala hot pot
- other names: {"zh": "麻辣火鍋"}
- description: Chinese dish
- countries: CN
- kinds: dish, hot pot
- has Wikipedia article: en, zh

## DISH Q1890619
- name: Mannheimer Dreck
- description: macaroon pastry
- countries: DE
- kinds: pastry, macaroon

## DISH Q1891043
- name: Arrabbiata sauce
- other names: {"zh": "香辣茄酱直通粉"}
- description: spicy Italian pasta sauce
- countries: IT
- kinds: tomato sauce, pasta dish
- ingredients: garlic, tomato, chili pepper
- has Wikipedia article: en, zh

## DISH Q18913689
- name: Sarımsaklı yoğurt
- description: Turkish cuisine sauce consisting of yoghurt and garlic
- countries: (none)
- kinds: dish
- ingredients: garlic, yogurt

## DISH Q18914789
- name: Turkish breads
- description: Wikimedia list article
- countries: (none)
- kinds: bread, Wikimedia list article
- has Wikipedia article: en

## DISH Q18914831
- name: Quark mit Leinöl
- countries: (none)
- kinds: dish
- ingredients: linseed oil, quark

## DISH Q18915938
- name: Šinga
- other names: {"cs": "Šinga"}
- countries: (none)
- kinds: confectionery

## DISH Q18917789
- name: Pampushka
- other names: {"zh": "潘普什基"}
- description: pastry
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: pastry
- ingredients: wheat flour, baker's yeast, oil, table salt
- has Wikipedia article: en, zh

## DISH Q189221
- name: Roquefort cheese
- other names: {"zh": "罗克福奶酪"}
- description: French cheese
- countries: FR
- kinds: cheese, French cheese, blue cheese, sheep milk cheese, raw-milk cheese, industrial cheese, dairy cheese
- ingredients: sheep milk, raw milk
- has Wikipedia article: en, zh

## DISH Q18922477
- name: Bundevara
- description: sweet pie filled with pumpkin
- countries: RS
- kinds: food, pie
- ingredients: phyllo, pumpkin
- has Wikipedia article: en

## DISH Q1892832
- name: Koetjesreep
- countries: (none)
- kinds: candy bar

## DISH Q18943775
- name: Trileçe
- description: Albanian and Turkish version of "tres leches cake"
- countries: (none)
- kinds: tres leches cake, dish
- has Wikipedia article: en

## DISH Q18948079
- name: Bakskuld
- other names: {"da": "Bakskuld"}
- countries: (none)
- kinds: dish

## DISH Q1897149
- name: Parotta
- description: South Indian variant of paratha
- countries: IN
- cuisines: Keralan cuisine
- kinds: paratha
- ingredients: wheat flour, maida flour
- has Wikipedia article: en

## DISH Q18991273
- name: Otaru Ankake Yakisoba
- other names: {"zh": "小樽燴炒麵"}
- description: Japanese dish
- countries: JP
- kinds: Yakisoba
- has Wikipedia article: en, zh

## DISH Q1903137
- name: Zuurbal
- other names: {"nl": "zuurbal"}
- countries: (none)
- kinds: candy

## DISH Q1906552
- name: Marzipan potato
- description: Marzipan confection colored and shaped to look like a potato
- countries: (none)
- kinds: marzipan
- ingredients: cocoa powder, marzipan

## DISH Q1907985
- name: Peanut soup
- description: soup made from peanuts
- countries: (none)
- kinds: food, soup
- ingredients: rosemary, tomato, ginger, West African Pepper, peanut, onion, bay leaf
- has Wikipedia article: en

## DISH Q190921
- name: Panpepato
- description: Italian round, sweet cake
- countries: IT
- kinds: panforte
- ingredients: Prunus dulcis
- has Wikipedia article: en

## DISH Q1911937
- name: Kletskop
- description: Dutch cookie
- countries: (none)
- kinds: food, cookie
- has Wikipedia article: en

## DISH Q1915495
- name: Meat pie
- other names: {"zh": "It is considered iconic in Australia and New Zealand.[1] It was described by former New South Wales Premier Bob Carr in 2003 as Australia's \"national dish\"."}
- description: hand-sized diced or minced meat and gravy pie often consumed as a snack in Australia and New Zealand
- countries: AU, NZ
- kinds: meat pie
- has Wikipedia article: en

## DISH Q1915612
- name: Méchoui
- description: Spit-roasted whole lamb or sheep
- countries: (none)
- kinds: lamb dish
- has Wikipedia article: en

## DISH Q1915701
- name: Mecklenburger Rippenbraten
- other names: {"de": "Mecklenburger Rippenbraten"}
- countries: (none)
- kinds: dish

## DISH Q1916756
- name: Meefischli
- other names: {"de": "Meefischli"}
- countries: DE
- kinds: deep-fried food, fish dish

## DISH Q1916808
- name: Seafood pralines
- description: Belgian chocolate pralines shaped like seafood
- countries: (none)
- kinds: Belgian praline
- has Wikipedia article: en

## DISH Q1919688
- name: Melonpan
- other names: {"zh": "蜜瓜包"}
- description: sweet bread from Japan
- countries: JP
- kinds: bun
- ingredients: dough
- has Wikipedia article: en, zh

## DISH Q1920415
- name: Menemen
- description: Turkish tomato, fresh pepper and optional onion with egg.
- countries: TR
- kinds: dish, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q1921170
- name: Sajoer
- description: Indonesian dish
- countries: ID
- kinds: dish
- ingredients: onion, vegetable

## DISH Q1922854
- name: Pane carasau
- description: Thin, crisp, twice-baked flatbread from Sardinia
- countries: IT
- kinds: flatbread
- ingredients: durum wheat semolina
- has Wikipedia article: en

## DISH Q1923394
- name: Jujeh kabab
- description: Iranian chicken kebab
- countries: IR
- cuisines: Iranian cuisine
- kinds: kebab, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q1925991
- name: Mettigel
- description: mince hedgehog
- countries: DE
- kinds: dish
- ingredients: Mett

## DISH Q1926063
- name: Metzgete
- other names: {"de": "Metzgete"}
- countries: (none)
- kinds: dish

## DISH Q192783
- name: Doughnut
- other names: {"zh": "甜甜圈"}
- description: dessert food
- countries: (none)
- kinds: dessert, fritter, dish, snack, viennoiserie, bánh, fried dough
- ingredients: potato, wheat flour, flavor enhancer, egg as food, baking powder, sugar, milk
- has Wikipedia article: en, zh

## DISH Q19285580
- name: Hildesheimer Pumpernickel
- countries: (none)
- kinds: viennoiserie

## DISH Q1928643
- name: Sauce Choron
- other names: {"de": "Sauce Choron"}
- countries: FR
- cuisines: French cuisine
- kinds: sauce, béarnaise sauce

## DISH Q192874
- name: Noodle
- other names: {"zh": "面条"}
- description: type of staple food made from some type of unleavened dough
- countries: CN
- kinds: food, type of pasta, pasta and noodles
- ingredients: egg as food, flour, table salt, water
- has Wikipedia article: en, zh

## DISH Q19288105
- name: Kochklops
- other names: {"de": "Kochklops"}
- countries: (none)
- kinds: dish

## DISH Q1929741
- name: Persipan
- other names: {"zh": "桃仁糖膏"}
- description: material used in confectionery, similar to marzipan but made with apricot or peach kernels instead of almonds
- countries: DE
- kinds: food ingredient
- ingredients: apricot
- has Wikipedia article: en

## DISH Q1934427
- name: Milchkohl
- other names: {"de": "Milchkohl"}
- countries: (none)
- kinds: dish

## DISH Q1934450
- name: Milchnudeln
- other names: {"de": "Milchnudeln"}
- countries: (none)
- kinds: dish

## DISH Q1934489
- name: Milk soup
- countries: (none)
- kinds: soup
- ingredients: milk

## DISH Q1934690
- name: Sea cucumber as food
- other names: {"zh": "海参"}
- description: flesh from sea cucumbers
- countries: (none)
- kinds: echinoderm as food, dish
- has Wikipedia article: en

## DISH Q19358405
- name: Coconut bun
- description: bun
- countries: (none)
- kinds: bun
- ingredients: coconut

## DISH Q19360381
- name: Sweeten lotus root
- description: Chinese snack
- countries: (none)
- kinds: dish
- ingredients: Lotus rhizome

## DISH Q19360382
- name: Deep fried taro ball
- description: Chinese snack
- countries: (none)
- kinds: deep-fried food, taro ball

## DISH Q19365769
- name: Sfincia
- other names: {"it": "Sfincia"}
- countries: IT
- kinds: dessert

## DISH Q19366122
- name: Morcilla de arroz
- other names: {"es": "Morcilla de arroz"}
- countries: (none)
- kinds: rice dish

## DISH Q1936949
- name: Sarsuela
- countries: ES
- cuisines: Catalan cuisine
- kinds: fish dish
- ingredients: clam, fish as food

## DISH Q19374689
- name: Dalyan köfte
- countries: TR
- kinds: meatball

## DISH Q19376103
- name: Soufflé-style cheesecake
- countries: (none)
- kinds: cheesecake
- ingredients: cream cheese, egg as food

## DISH Q1937652
- name: Rouille
- description: provençal sauce
- countries: FR
- kinds: human food, sauce
- ingredients: garlic, bread crumbs, olive oil, cayenne pepper
- has Wikipedia article: en

## DISH Q19378476
- name: Dinner roll
- countries: (none)
- kinds: pastry, dish

## DISH Q19380302
- name: Lungemos
- other names: {"nb": "Lungemos"}
- countries: (none)
- kinds: dish

## DISH Q19380788
- name: M
- other names: {"nb": "M"}
- countries: (none)
- kinds: candy

## DISH Q19380983
- name: Mandelstang
- other names: {"nb": "Mandelstang"}
- countries: (none)
- kinds: chocolate bar

## DISH Q19381114
- name: Marsipankake
- description: Norwegian marzipan cake
- countries: (none)
- kinds: food, layered cream cake
- ingredients: sponge cake, marzipan
- has Wikipedia article: en

## DISH Q19385369
- name: Pipe rigate
- description: type of pasta
- countries: (none)
- kinds: pasta, type of pasta

## DISH Q1938644
- name: Mischbrot
- description: German wheat and rye bread
- countries: (none)
- kinds: bread
- ingredients: rye flour, wheat flour, drinking water
- has Wikipedia article: en

## DISH Q19390528
- name: Gooseberry jam
- description: jam made from gooseberrys
- countries: (none)
- kinds: berry jam
- ingredients: gooseberry

## DISH Q1940968
- name: Mizeria
- description: a salad from Poland
- countries: PL
- kinds: cucumber salad
- ingredients: cucumber, smetana
- has Wikipedia article: en

## DISH Q1947038
- name: Moppelkotze
- other names: {"de": "Moppelkotze"}
- description: Northern German dishes
- countries: (none)
- kinds: Eintopf, dish

## DISH Q195
- name: Chocolate
- other names: {"zh": "巧克力"}
- description: nutritionally dense or sweet food product from the seed of Theobroma cacao - cocoa bean
- countries: (none)
- kinds: candy, functional food, stimulant foodstuff, condiment, confectionery, food ingredient
- ingredients: cocoa, vegetable oil, chocolate liquor, cocoa butter, cocoa bean, sugar
- has Wikipedia article: en, zh

## DISH Q19515766
- name: Kaz tiridi
- description: dish from the Turkish cuisine consisting mainly of domestic goose meat, bulgur and "yufka"
- countries: TR
- kinds: dish
- ingredients: yufka bread, bulgur

## DISH Q1953925
- name: Mash
- description: Mash of cooked fruit or vegetables
- countries: (none)
- kinds: sauce, porridge, dish

## DISH Q1954072
- name: Muscheln rheinische Art
- other names: {"de": "Muscheln rheinische Art"}
- countries: (none)
- kinds: dish

## DISH Q19544049
- name: Caramelo de mantequilla salada
- other names: {"es": "Caramelo de mantequilla salada"}
- countries: (none)
- kinds: caramel
- ingredients: salted butter

## DISH Q19545058
- name: Lucullus de Valenciennes
- other names: {"fr": "Lucullus de Valenciennes"}
- description: northern French culinary specialty made with smoked beef tongue and foie gras
- countries: FR
- kinds: meat dish
- ingredients: beef tongue, foie gras

## DISH Q19562553
- name: Surrib
- other names: {"da": "Surrib"}
- countries: (none)
- kinds: dish

## DISH Q1957030
- name: Malaga ice cream
- countries: (none)
- kinds: ice cream

## DISH Q19570968
- name: Banana custard
- description: pudding made with sliced bananas
- countries: (none)
- kinds: custard, banana dish
- ingredients: banana
- has Wikipedia article: en

## DISH Q19571164
- name: Caldo Xóchitl
- description: Mexican traditional dish
- countries: MX
- kinds: food, chicken dish
- has Wikipedia article: en

## DISH Q19572039
- name: Halva ice cream
- description: dessert of sesame halva, tahini, eggs, cream, and sugar, topped with pistachios and silan, originating from Tel Aviv
- countries: IL
- kinds: ice cream
- has Wikipedia article: en

## DISH Q19572482
- name: Kluai buat chi
- description: Thai dessert
- countries: (none)
- kinds: food, dessert, banana dish
- ingredients: coconut milk, banana
- has Wikipedia article: en

## DISH Q19572606
- name: Lechon kawali
- description: filipino-style deep-fried pork belly
- countries: PH
- kinds: pork dish
- has Wikipedia article: en

## DISH Q19573003
- name: Kale noodles
- description: Indonesian dish
- countries: ID
- kinds: food, dish, type of food or dish, noodle, Sōtō, jajan pasar, soup
- ingredients: kecap manis, bakso, noodle, Allium sativum
- has Wikipedia article: en

## DISH Q19573431
- name: Okra soup
- description: soup made from the green seed pods of the okra plant
- countries: (none)
- kinds: dish, soup, okra soup
- ingredients: okra, seasoning, Abelmoschus esculentus
- has Wikipedia article: en

## DISH Q1959504
- name: Chivito
- other names: {"zh": "烏拉圭牛排漢堡"}
- description: national dish of Uruguay
- countries: UY
- kinds: sandwich
- has Wikipedia article: en, zh

## DISH Q1959865
- name: Malooga
- description: Yemeni flatbread
- countries: YE
- kinds: food, flatbread
- ingredients: flour
- has Wikipedia article: en

## DISH Q1959979
- name: Jibneh Arabieh
- description: middle Eastern cheese
- countries: LB, PS, SY
- cuisines: Levantine cuisine, Lebanese cuisine, Palestinian cuisine, Syrian cuisine
- kinds: food, type of cheese
- ingredients: cow's milk, sheep milk, goat milk
- has Wikipedia article: en

## DISH Q19602320
- name: Flower honey
- countries: (none)
- kinds: honey

## DISH Q19602338
- name: Forest honey
- countries: (none)
- kinds: honey

## DISH Q1960279
- name: Jachnun
- other names: {"zh": "扎克纳"}
- description: Yemenite Jewish pastry
- countries: YE
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q19604552
- name: Köpoğlu mancası
- description: a vegetable-based meze from the Turkish cuisine
- countries: (none)
- kinds: dish

## DISH Q19605683
- name: Osmania Biscuit
- description: snack in Hyderabad, Telangana
- countries: IN
- cuisines: Indian cuisine
- kinds: biscuit
- ingredients: milk
- has Wikipedia article: en

## DISH Q1960572
- name: Escavèche
- other names: {"fr": "escavèche"}
- countries: BE
- kinds: dish

## DISH Q19606287
- name: آغوغلو
- other names: {"ar": "آغوغلو"}
- countries: DZ
- kinds: cheese

## DISH Q19606890
- name: Fine et marc du Bugey
- countries: FR
- kinds: Fine, marc

## DISH Q19607520
- name: Elvas plum
- description: plum fruit from Portugal
- countries: PT
- kinds: food, Prunus domestica
- ingredients: plum

## DISH Q19607995
- name: Bolinho de estudante
- other names: {"pt": "bolinho de estudante"}
- countries: (none)
- kinds: confectionery

## DISH Q19608120
- name: Cabrito da Gralheira
- description: Portuguese goat meat
- countries: PT
- kinds: goat meat

## DISH Q19608121
- name: Cabrito Transmontano
- description: Portuguese goat meat
- countries: PT
- kinds: goat meat
