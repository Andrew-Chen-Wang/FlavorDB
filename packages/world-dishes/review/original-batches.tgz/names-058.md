# Review batch names-058

## DISH Q99171384
- name: Cheese curries
- countries: (none)
- kinds: dish

## DISH Q99198023
- name: Cheese dakgalbi
- description: Dakgalbi with cheese
- countries: (none)
- cuisines: South Korean cuisine
- kinds: chicken dish, dak-galbi
- ingredients: cheese

## DISH Q992098
- name: Bruckfleisch
- description: Austrian offal dish
- countries: AT
- kinds: meat dish
- ingredients: offal

## DISH Q99337777
- name: Tahinopita
- description: Cypriot cake
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q994169
- name: Brunswick stew
- other names: {"zh": "不倫瑞克燉肉"}
- description: stew from the southern US, containing tomatoes, beans, corn, okra, and game meat (squirrel, rabbit, possum, or substituted with chicken)
- countries: US
- cuisines: cuisine of the United States
- kinds: stew
- ingredients: okra, lima bean, tomato, maize, vegetable, meat, game meat, bean
- has Wikipedia article: en

## DISH Q99424726
- name: Kohaku-namasu
- countries: (none)
- kinds: namasu

## DISH Q99432318
- name: Niku soba
- countries: (none)
- kinds: dish

## DISH Q9944730
- name: Saba misoni
- countries: JP
- kinds: nizakana
- ingredients: mackerel, miso

## DISH Q995299
- name: Bryndzové halušky
- other names: {"zh": "羊起司麵疙瘩"}
- description: traditional Slovak dish
- countries: SK
- cuisines: Slovak cuisine
- kinds: national dish, potato-dough dumpling
- ingredients: potato, corned beef, Bryndza, flour, table salt
- has Wikipedia article: en, zh

## DISH Q99532347
- name: Oret
- description: Authentic Indonesian food from Bali
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish

## DISH Q99532546
- name: Semuuk
- description: Balinese cousine
- countries: ID
- kinds: food, dish, traditional food, human food

## DISH Q99539198
- name: Kue bolu
- description: Indonesian cake
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q99546130
- name: Fersk suppe
- other names: {"nb": "Fersk suppe"}
- countries: (none)
- kinds: soup

## DISH Q9955294
- name: Крышаны
- other names: {"be-tarask": "крышаны"}
- countries: (none)
- kinds: soup

## DISH Q99554129
- name: Gong Fei Cake
- other names: {"zh": "共匪餅"}
- description: Taiwanese pastry named after an anti-communist epithet
- countries: (none)
- kinds: food, type of food or dish, dish
- has Wikipedia article: en, zh

## DISH Q995567
- name: Brätspätzlesuppe
- other names: {"de": "Brätspätzlesuppe"}
- countries: (none)
- kinds: soup

## DISH Q995571
- name: Brätstrudel
- other names: {"de": "Brätstrudel"}
- description: dish
- countries: (none)
- kinds: dish

## DISH Q995997
- name: Haw flakes
- other names: {"zh": "山楂饼"}
- description: Confectionery
- countries: CN
- kinds: confectionery
- ingredients: Crataegus pinnatifida
- has Wikipedia article: en, zh

## DISH Q99629221
- name: Diablottino
- other names: {"it": "Diablottino"}
- countries: (none)
- kinds: bonbon
- ingredients: cocoa powder, vanilla, sugar

## DISH Q99654352
- name: Åland pancake
- description: variant of oven-baked pancake
- countries: (none)
- kinds: pancake
- has Wikipedia article: en

## DISH Q99658926
- name: Analı kızlı soup
- description: Turkish cuisine soup
- countries: TR
- kinds: food, soup
- ingredients: meatball, bulgur
- has Wikipedia article: en

## DISH Q99693722
- name: Soft Bröd
- description: Flatbread
- countries: SE
- kinds: flatbread

## DISH Q9969675
- name: 大馬站煲
- countries: CN
- kinds: culinary speciality, Yangzhou fried rice
- has Wikipedia article: zh

## DISH Q9970683
- name: Tua-mi-kinn
- other names: {"zh": "大麵焿"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish
- has Wikipedia article: zh

## DISH Q997361
- name: Chwee kueh
- other names: {"zh": "水粿"}
- description: Chinese steamed rice cake
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q997557
- name: Mehlbeutel
- other names: {"de": "Mehlbeutel"}
- countries: (none)
- kinds: dish

## DISH Q997633
- name: Amatriciana sauce
- other names: {"zh": "酸辣番茄烟肉酱"}
- description: Italian sauce
- countries: IT
- kinds: tomato sauce, pork dish, dish
- ingredients: table salt, white wine, tomato sauce, pecorino, guanciale, chili pepper, oil, tomato
- has Wikipedia article: en

## DISH Q997642
- name: Buccellato PAT
- other names: {"zh": "Buccellato PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good, cake
- ingredients: candied fruit
- has Wikipedia article: en

## DISH Q999186
- name: Buckwheat dumplings
- countries: DE
- kinds: dish, dumpling
- ingredients: potato, buckwheat flour

## DISH Q99951345
- name: Hälsingland curd cake
- description: curd cake from Hälsingland
- countries: SE
- kinds: ostkaka
- ingredients: cow's milk, wheat flour, rennet

## DISH wikibooks-de:afrikanisches-huhn
- name: Afrikanisches Huhn
- other names: {"de": "Afrikanisches Huhn"}
- countries: (none)
- ingredients: Hühnerfleisch, Öl, Kochsalz, Curry, Zwiebel, Gemüsepaprika, Tomate, Reis, Erdnussbutter, Wasser

## DISH wikibooks-de:all-arrabbiata
- name: All’arrabbiata
- other names: {"de": "All’arrabbiata"}
- countries: (none)

## DISH wikibooks-de:amerikaner-mit-hirschhornsalz
- name: Amerikaner mit Hirschhornsalz
- other names: {"de": "Amerikaner mit Hirschhornsalz"}
- countries: (none)
- ingredients: Getreidemehl, Milch, Zucker, Butter, Hirschhornsalz, Kochsalz, Ei, Künstliches Aroma

## DISH wikibooks-de:apfel-chili-chutney
- name: Apfel-Chili-Chutney
- other names: {"de": "Apfel-Chili-Chutney"}
- countries: (none)

## DISH wikibooks-de:apfelkuchen
- name: Apfelkuchen
- other names: {"de": "Apfelkuchen"}
- countries: (none)
- ingredients: Getreidemehl, Zucker, Ei, Milch, Butter, Kochsalz, Äpfel

## DISH wikibooks-de:apfelmüsli
- name: Apfelmüsli
- other names: {"de": "Apfelmüsli"}
- countries: (none)
- ingredients: Apfel, Butter, Wein, Zimt, Zucker

## DISH wikibooks-de:apfelpfannkuchen
- name: Apfelpfannkuchen
- other names: {"de": "Apfelpfannkuchen"}
- countries: (none)
- ingredients: Getreidemehl, Butter, Apfel, Ei, Milch, Backpulver, Kochsalz, Puderzucker

## DISH wikibooks-de:artischocken-und-spargel-in-apfelwein
- name: Artischocken und Spargel in Apfelwein
- other names: {"de": "Artischocken und Spargel in Apfelwein"}
- countries: (none)
- ingredients: Artischocke

## DISH wikibooks-de:bananenkuchen
- name: Bananenkuchen
- other names: {"de": "Bananenkuchen"}
- countries: (none)

## DISH wikibooks-de:bandnudeln-mit-sahnesauce
- name: Bandnudeln mit Sahnesauce
- other names: {"de": "Bandnudeln mit Sahnesauce"}
- countries: (none)

## DISH wikibooks-de:bärlauch-pesto
- name: Bärlauch Pesto
- other names: {"de": "Bärlauch Pesto"}
- countries: (none)

## DISH wikibooks-de:basler-herzen
- name: Basler Herzen
- other names: {"de": "Basler Herzen"}
- countries: (none)

## DISH wikibooks-de:belgische-zwiebelsuppe
- name: Belgische Zwiebelsuppe
- other names: {"de": "Belgische Zwiebelsuppe"}
- countries: (none)

## DISH wikibooks-de:benachin
- name: Benachin
- other names: {"de": "Benachin"}
- countries: (none)

## DISH wikibooks-de:bierbrot
- name: Bierbrot
- other names: {"de": "Bierbrot"}
- countries: (none)

## DISH wikibooks-de:blätterteig-mit-spinat
- name: Blätterteig mit Spinat
- other names: {"de": "Blätterteig mit Spinat"}
- countries: (none)

## DISH wikibooks-de:böhmische-knoblauchsuppe
- name: Böhmische Knoblauchsuppe
- other names: {"de": "Böhmische Knoblauchsuppe"}
- countries: (none)

## DISH wikibooks-de:bohnenmus-mit-mais
- name: Bohnenmus mit Mais
- other names: {"de": "Bohnenmus mit Mais"}
- countries: (none)

## DISH wikibooks-de:bräntis
- name: Bräntis
- other names: {"de": "Bräntis"}
- countries: (none)

## DISH wikibooks-de:bratdog
- name: Bratdog
- other names: {"de": "Bratdog"}
- countries: (none)

## DISH wikibooks-de:bremer-bunte-finken
- name: Bremer bunte Finken
- other names: {"de": "Bremer bunte Finken"}
- countries: (none)

## DISH wikibooks-de:brik-mit-thunfisch
- name: Brik mit Thunfisch
- other names: {"de": "Brik mit Thunfisch"}
- countries: (none)

## DISH wikibooks-de:brokkoli-kartoffel-käse-suppe
- name: Brokkoli-Kartoffel-Käse-Suppe
- other names: {"de": "Brokkoli-Kartoffel-Käse-Suppe"}
- countries: (none)

## DISH wikibooks-de:brokkoligratin-mit-dreierlei-käse
- name: Brokkoligratin mit dreierlei Käse
- other names: {"de": "Brokkoligratin mit dreierlei Käse"}
- countries: (none)

## DISH wikibooks-de:brokkolisuppe
- name: Brokkolisuppe
- other names: {"de": "Brokkolisuppe"}
- countries: (none)

## DISH wikibooks-de:brot-mit-käse-überbacken
- name: Brot mit Käse überbacken
- other names: {"de": "Brot mit Käse überbacken"}
- countries: (none)

## DISH wikibooks-de:bulgurauflauf
- name: Bulgurauflauf
- other names: {"de": "Bulgurauflauf"}
- countries: (none)

## DISH wikibooks-de:buttermais
- name: Buttermais
- other names: {"de": "Buttermais"}
- countries: (none)

## DISH wikibooks-de:cellischer-kuchen
- name: Cellischer Kuchen
- other names: {"de": "Cellischer Kuchen"}
- countries: (none)

## DISH wikibooks-de:creamed-broccoli-soup
- name: Creamed Broccoli Soup
- other names: {"de": "Creamed Broccoli Soup"}
- countries: (none)

## DISH wikibooks-de:dill-senf-soße
- name: Dill-Senf-Soße
- other names: {"de": "Dill-Senf-Soße"}
- countries: (none)

## DISH wikibooks-de:eierlikörkuchen
- name: Eierlikörkuchen
- other names: {"de": "Eierlikörkuchen"}
- countries: (none)
- ingredients: Vanillinzucker, Rum

## DISH wikibooks-de:eierpfannkuchen
- name: Eierpfannkuchen
- other names: {"de": "Eierpfannkuchen"}
- countries: (none)

## DISH wikibooks-de:entenbrust-mit-orangensauce
- name: Entenbrust mit Orangensauce
- other names: {"de": "Entenbrust mit Orangensauce"}
- countries: (none)

## DISH wikibooks-de:erdbeer-bananen-mousse
- name: Erdbeer-Bananen-Mousse
- other names: {"de": "Erdbeer-Bananen-Mousse"}
- countries: (none)
- ingredients: Erdbeere

## DISH wikibooks-de:erdbeertorte
- name: Erdbeertorte
- other names: {"de": "Erdbeertorte"}
- countries: (none)
- ingredients: Erdbeere

## DISH wikibooks-de:estragonhuhn
- name: Estragonhuhn
- other names: {"de": "Estragonhuhn"}
- countries: (none)

## DISH wikibooks-de:frucht-reis-auflauf
- name: Frucht-Reis-Auflauf
- other names: {"de": "Frucht-Reis-Auflauf"}
- countries: (none)

## DISH wikibooks-de:frühlingssalat-mit-löwenzahnblüten
- name: Frühlingssalat mit Löwenzahnblüten
- other names: {"de": "Frühlingssalat mit Löwenzahnblüten"}
- countries: (none)

## DISH wikibooks-de:gorgonzolasoße
- name: Gorgonzolasoße
- other names: {"de": "Gorgonzolasoße"}
- countries: (none)

## DISH wikibooks-de:gratinierte-schollenfilets
- name: Gratinierte Schollenfilets
- other names: {"de": "Gratinierte Schollenfilets"}
- countries: (none)

## DISH wikibooks-de:griechischer-salat
- name: Griechischer Salat
- other names: {"de": "Griechischer Salat"}
- countries: (none)

## DISH wikibooks-de:grüne-bohnen
- name: Grüne Bohnen
- other names: {"de": "Grüne Bohnen"}
- countries: (none)

## DISH wikibooks-de:grünkohlcurry-mit-kokosmilch
- name: Grünkohlcurry mit Kokosmilch
- other names: {"de": "Grünkohlcurry mit Kokosmilch"}
- countries: (none)

## DISH wikibooks-de:haferbrei
- name: Haferbrei
- other names: {"de": "Haferbrei"}
- countries: (none)

## DISH wikibooks-de:haferpfannkuchen
- name: Haferpfannkuchen
- other names: {"de": "Haferpfannkuchen"}
- countries: (none)

## DISH wikibooks-de:hähnchen-aprikosen-mandel-reis
- name: Hähnchen-Aprikosen-Mandel-Reis
- other names: {"de": "Hähnchen-Aprikosen-Mandel-Reis"}
- countries: (none)

## DISH wikibooks-de:hähnchenroulade-aus-der-mikrowelle
- name: Hähnchenroulade aus der Mikrowelle
- other names: {"de": "Hähnchenroulade aus der Mikrowelle"}
- countries: (none)

## DISH wikibooks-de:hefezopf
- name: Hefezopf
- other names: {"de": "Hefezopf"}
- countries: (none)

## DISH wikibooks-de:herrencreme
- name: Herrencreme
- other names: {"de": "Herrencreme"}
- countries: (none)

## DISH wikibooks-de:kartoffelgratin
- name: Kartoffelgratin
- other names: {"de": "Kartoffelgratin"}
- countries: (none)

## DISH wikibooks-de:kekse-boston
- name: Kekse Boston
- other names: {"de": "Kekse Boston"}
- countries: (none)

## DISH wikibooks-de:kokosnuss-chutney
- name: Kokosnuss-Chutney
- other names: {"de": "Kokosnuss-Chutney"}
- countries: (none)

## DISH wikibooks-de:kürbis-ravioli-mit-salbei
- name: Kürbis-Ravioli mit Salbei
- other names: {"de": "Kürbis-Ravioli mit Salbei"}
- countries: (none)

## DISH wikibooks-de:lachs-spinat-auflauf
- name: Lachs-Spinat-Auflauf
- other names: {"de": "Lachs-Spinat-Auflauf"}
- countries: (none)

## DISH wikibooks-de:leckere-brötchen
- name: Leckere Brötchen
- other names: {"de": "Leckere Brötchen"}
- countries: (none)

## DISH wikibooks-de:maispuffer
- name: Maispuffer
- other names: {"de": "Maispuffer"}
- countries: (none)

## DISH wikibooks-de:mispel-parfait
- name: Mispel-Parfait
- other names: {"de": "Mispel-Parfait"}
- countries: (none)

## DISH wikibooks-de:mohntorte
- name: Mohntorte
- other names: {"de": "Mohntorte"}
- countries: (none)

## DISH wikibooks-de:möhrenkuchen
- name: Möhrenkuchen
- other names: {"de": "Möhrenkuchen"}
- countries: (none)

## DISH wikibooks-de:muffins
- name: Muffins
- other names: {"de": "Muffins"}
- countries: (none)

## DISH wikibooks-de:müsli-ohne-zucker
- name: Müsli-ohne-Zucker
- other names: {"de": "Müsli-ohne-Zucker"}
- countries: (none)

## DISH wikibooks-de:neuenburger-weissweinsuppe
- name: Neuenburger Weissweinsuppe
- other names: {"de": "Neuenburger Weissweinsuppe"}
- countries: (none)

## DISH wikibooks-de:obstsalat
- name: Obstsalat
- other names: {"de": "Obstsalat"}
- countries: (none)

## DISH wikibooks-de:okras-mit-pfeffer
- name: Okras mit Pfeffer
- other names: {"de": "Okras mit Pfeffer"}
- countries: (none)

## DISH wikibooks-de:oma-irenes-christstollen
- name: Oma Irenes Christstollen
- other names: {"de": "Oma Irenes Christstollen"}
- countries: (none)

## DISH wikibooks-de:orientalische-karottensuppe-mit-orangenfilets
- name: Orientalische Karottensuppe mit Orangenfilets
- other names: {"de": "Orientalische Karottensuppe mit Orangenfilets"}
- countries: (none)

## DISH wikibooks-de:paprikagemüse
- name: Paprikagemüse
- other names: {"de": "Paprikagemüse"}
- countries: (none)

## DISH wikibooks-de:pizzateig
- name: Pizzateig
- other names: {"de": "Pizzateig"}
- countries: (none)

## DISH wikibooks-de:quarkauflauf-mit-aprikosen
- name: Quarkauflauf mit Aprikosen
- other names: {"de": "Quarkauflauf mit Aprikosen"}
- countries: (none)

## DISH wikibooks-de:quarkbällchen
- name: Quarkbällchen
- other names: {"de": "Quarkbällchen"}
- countries: (none)

## DISH wikibooks-de:rosinenbrötchen
- name: Rosinenbrötchen
- other names: {"de": "Rosinenbrötchen"}
- countries: (none)

## DISH wikibooks-de:rostige-ritter
- name: Rostige Ritter
- other names: {"de": "Rostige Ritter"}
- countries: (none)

## DISH wikibooks-de:rührei-in-der-mikrowelle
- name: Rührei in der Mikrowelle
- other names: {"de": "Rührei in der Mikrowelle"}
- countries: (none)

## DISH wikibooks-de:salsa-mexicana
- name: Salsa mexicana
- other names: {"de": "Salsa mexicana"}
- countries: (none)

## DISH wikibooks-de:saurer-linseneintopf
- name: saurer Linseneintopf
- other names: {"de": "saurer Linseneintopf"}
- countries: (none)

## DISH wikibooks-de:scharfe-kokos-hühnersuppe
- name: Scharfe Kokos-Hühnersuppe
- other names: {"de": "Scharfe Kokos-Hühnersuppe"}
- countries: (none)

## DISH wikibooks-de:schokokuss-torte
- name: Schokokuss-Torte
- other names: {"de": "Schokokuss-Torte"}
- countries: (none)

## DISH wikibooks-de:schuettelkuchen
- name: Schuettelkuchen
- other names: {"de": "Schuettelkuchen"}
- countries: (none)

## DISH wikibooks-de:schwämmchen
- name: Schwämmchen
- other names: {"de": "Schwämmchen"}
- countries: (none)

## DISH wikibooks-de:scottish-crumpets
- name: Scottish Crumpets
- other names: {"de": "Scottish Crumpets"}
- countries: (none)

## DISH wikibooks-de:senfgurken
- name: Senfgurken
- other names: {"de": "Senfgurken"}
- countries: (none)

## DISH wikibooks-de:spagetti-bolognese
- name: Spagetti Bolognese
- other names: {"de": "Spagetti Bolognese"}
- countries: (none)

## DISH wikibooks-de:tomaten-mozzarella-brot
- name: Tomaten-Mozzarella-Brot
- other names: {"de": "Tomaten-Mozzarella-Brot"}
- countries: (none)

## DISH wikibooks-de:türkische-linsensuppe
- name: Türkische Linsensuppe
- other names: {"de": "Türkische Linsensuppe"}
- countries: (none)

## DISH wikibooks-de:türkischer-kaffee
- name: Türkischer Kaffee
- other names: {"de": "Türkischer Kaffee"}
- countries: (none)

## DISH wikibooks-de:überbackene-sommerbeeren
- name: Überbackene Sommerbeeren
- other names: {"de": "Überbackene Sommerbeeren"}
- countries: (none)

## DISH wikibooks-de:überbackene-veggi-maultaschen
- name: Überbackene Veggi Maultaschen
- other names: {"de": "Überbackene Veggi Maultaschen"}
- countries: (none)

## DISH wikibooks-de:vanillepudding
- name: Vanillepudding
- other names: {"de": "Vanillepudding"}
- countries: (none)

## DISH wikibooks-de:vogel-sternmieren-salat
- name: Vogel-Sternmieren-Salat
- other names: {"de": "Vogel-Sternmieren-Salat"}
- countries: (none)

## DISH wikibooks-de:wildkohl-mit-speck-und-kartoffeln
- name: Wildkohl mit Speck und Kartoffeln
- other names: {"de": "Wildkohl mit Speck und Kartoffeln"}
- countries: (none)

## DISH wikibooks-de:wolkenkuchen
- name: Wolkenkuchen
- other names: {"de": "Wolkenkuchen"}
- countries: (none)

## DISH wikibooks-de:wurst-käse-salat-nach-emmentaler-art
- name: Wurst-Käse Salat nach Emmentaler Art
- other names: {"de": "Wurst-Käse Salat nach Emmentaler Art"}
- countries: (none)

## DISH wikibooks-de:würstchen-im-schlafrock
- name: Würstchen im Schlafrock
- other names: {"de": "Würstchen im Schlafrock"}
- countries: (none)

## DISH wikibooks-de:xaucuti
- name: Xaucuti
- other names: {"de": "Xaucuti"}
- countries: (none)

## DISH wikibooks-de:zucchinikuchen
- name: Zucchinikuchen
- other names: {"de": "Zucchinikuchen"}
- countries: (none)

## DISH wikibooks-fr:diots
- name: Diots
- other names: {"fr": "Diots"}
- countries: (none)
- ingredients: diot, échalotes, oignons, vin blanc, farine

## DISH wikibooks-fr:gâteau-roulé
- name: Gâteau roulé
- other names: {"fr": "Gâteau roulé"}
- countries: (none)
- ingredients: sucre, farine, beurre, levure, chocolat

## DISH wikibooks-fr:pâtes-au-saumon-fumé
- name: Pâtes au saumon fumé
- other names: {"fr": "Pâtes au saumon fumé"}
- countries: (none)
- ingredients: saumon

## DISH wikibooks-fr:tarte-fine-aux-pralines-roses
- name: Tarte fine aux pralines roses
- other names: {"fr": "Tarte fine aux pralines roses"}
- countries: (none)
- ingredients: Pâte brisée, pralines roses
