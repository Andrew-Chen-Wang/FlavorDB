# Review batch names-057

## DISH Q96000127
- name: The Wonder Burger
- description: burger sold by Aldi
- countries: (none)
- kinds: vegan burger patty product

## DISH Q96000144
- name: Vegan burger patty product
- countries: (none)
- kinds: patty

## DISH Q96006110
- name: Pão na chapa
- description: Brazilian breakfast food
- countries: BR
- cuisines: Brazilian cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q9601457
- name: Aletria
- description: Portuguese dessert
- countries: PT
- kinds: dessert
- ingredients: vermicelli
- has Wikipedia article: en

## DISH Q9602705
- name: アルフェニン
- other names: {"ja": "アルフェニン"}
- countries: (none)
- kinds: confectionery

## DISH Q96031363
- name: Atápakua
- other names: {"es": "Atápakua"}
- countries: MX
- kinds: dish

## DISH Q96039977
- name: Huatape
- description: soup
- countries: MX
- kinds: pozole, soup
- ingredients: yellow onion, masa, Physalis philadelphica, jalapeño, seafood, water

## DISH Q9604183
- name: Aljotta
- description: Maltese fish soup
- countries: MT
- cuisines: Maltese cuisine
- kinds: fish soup
- ingredients: garlic, tomato, fish as food

## DISH Q96045946
- name: Hot roll
- description: deep-fried sushi rolls
- countries: BR
- cuisines: Japanese cuisine
- kinds: type of food or dish, makizushi

## DISH Q96048330
- name: Grilled Kurobuta Pork Belly at Other Mama
- description: dish
- countries: US
- kinds: dish
- ingredients: pork belly

## DISH Q96048649
- name: Jukkumisamgyeopsal
- description: Korean dish
- countries: (none)
- kinds: dish

## DISH Q96048720
- name: Osambulgogi
- description: Korean dish
- countries: (none)
- kinds: dish

## DISH Q96050496
- name: Pizza funghi
- description: pizza with mushrooms
- countries: IT
- kinds: dish
- ingredients: tomato sauce, baker's yeast, edible mushroom, olive oil, flour, mozzarella, table salt

## DISH Q96063444
- name: Pollo en cuñete
- other names: {"es": "Pollo en cuñete"}
- countries: MX
- kinds: dish

## DISH Q960635
- name: Cat tongues
- other names: {"zh": "貓舌餅"}
- description: tongue-shaped biscuits
- countries: FR
- kinds: cookie, biscuit
- has Wikipedia article: en, zh

## DISH Q96064581
- name: Jaibas rellenas
- countries: MX
- kinds: dish

## DISH Q96067581
- name: Zalabiyeh
- description: deep-fried pastry common to the Near East and Indian subcontinent
- countries: PS
- cuisines: Levantine cuisine, Palestinian cuisine
- kinds: cookie, pastry, deep-fried food
- ingredients: wheat flour, lemon juice, rose water, cooking oil, yeast, starch, yogurt, table salt, sugar, drinking water
- has Wikipedia article: en

## DISH Q96096909
- name: Cherry Bakewell
- description: a cake
- countries: (none)
- kinds: cake, Bakewell tart
- ingredients: shortcrust pastry, frangipane, icing, cherry

## DISH Q9611817
- name: Amêijoas à Bulhão Pato
- description: Portuguese clam dish
- countries: PT
- cuisines: Portuguese cuisine
- kinds: clam dish
- ingredients: cilantro, garlic, peppercorn, clam, lemon, olive oil, table salt
- has Wikipedia article: en

## DISH Q96128235
- name: Koppe pan
- description: type of bread roll of Japan
- countries: JP
- kinds: bread

## DISH Q961463
- name: Gomolya
- other names: {"hu": "gomolya"}
- countries: HU
- kinds: cheese
- ingredients: sheep milk, table salt

## DISH Q96146836
- name: Gallina en nogada
- other names: {"es": "Gallina en nogada"}
- countries: MX
- kinds: dish

## DISH Q96179816
- name: Rice of Yuli
- other names: {"zh": "玉里米"}
- description: Rice of Taiwan
- countries: TW
- kinds: rice

## DISH Q96187267
- name: Nasi kari
- description: Indonesian curry rice
- countries: (none)
- kinds: rice dish
- has Wikipedia article: en

## DISH Q96207588
- name: Cheese tteokbokki
- description: Korean snack food
- countries: KR
- cuisines: South Korean cuisine
- kinds: dish, tteokbokki
- ingredients: tteok, cheese

## DISH Q962330
- name: Pig jaw
- description: part of a pig head
- countries: (none)
- kinds: dish, food ingredient

## DISH Q96244418
- name: Melchermuas
- description: is a classic, very simple, high-energy rural dish from the Alpine region
- countries: AT
- kinds: dish

## DISH Q96246664
- name: Hokkien char mee
- other names: {"zh": "福建炒面"}
- description: stir-fried noodles of Kuala Lumpur
- countries: (none)
- kinds: Hokkien mee, fried noodle
- has Wikipedia article: zh

## DISH Q96249487
- name: Nalisniki
- countries: RU, PL, UA, BY
- cuisines: Russian cuisine, Polish cuisine, Ukrainian cuisine, Belarusian cuisine
- kinds: dish, blini

## DISH Q96274126
- name: Mustard soup
- countries: (none)
- kinds: soup
- ingredients: mustard seed

## DISH Q96276764
- name: Kube Cake
- description: Ghanaian snack
- countries: GH
- kinds: food
- ingredients: coconut, lemon juice, sugar, water
- has Wikipedia article: en

## DISH Q9628921
- name: Arjamolho
- description: cold raw soups from Portugal
- countries: (none)
- kinds: soup, cold sweet soup
- ingredients: tomato, cucumber, olive oil, vinegar, bread, sodium chloride

## DISH Q962957
- name: Tulumba
- other names: {"zh": "宫殿酥条"}
- description: dessert common to Egypt and other countries
- countries: EG
- kinds: dessert, confectionery
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q9630815
- name: Arroz gordo
- other names: {"zh": "肥仔炒飯"}
- description: Macanese rice dish
- countries: MO
- kinds: dish
- has Wikipedia article: en

## DISH Q9630820
- name: Piemontese rice
- description: Brazilian dish made with rice, cream and mushrooms
- countries: (none)
- kinds: dish

## DISH Q96314848
- name: Texmole
- other names: {"es": "Texmole"}
- countries: MX
- kinds: dish

## DISH Q96315918
- name: Nkati Cake
- description: snack
- countries: GH
- kinds: food
- ingredients: peanut, sugar
- has Wikipedia article: en

## DISH Q96317965
- name: Poloo
- description: Ghanaian snack
- countries: GH
- kinds: food, snack
- ingredients: grated coconut, flour, baking powder, sugar
- has Wikipedia article: en

## DISH Q96332958
- name: Fried tempeh
- description: Indonesian fried tempeh
- countries: ID
- kinds: Tempeh
- ingredients: Tempeh, table salt

## DISH Q96364093
- name: Chichinga
- description: kebab rubbed with suya
- countries: (none)
- kinds: kebab
- ingredients: suya

## DISH Q96371762
- name: Aligue fried rice
- description: Filipino fried rice dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q96372980
- name: Bagoong fried rice
- description: Filipino fried rice dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q96373297
- name: Beach pizza
- description: style of pizza local to coastal northern New England
- countries: US
- cuisines: cuisine of New England
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q96373860
- name: Boulou
- description: Libyan Jewish sweet bread
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q96374874
- name: Chha kh'nhei
- description: Cambodian stir fry dish
- countries: KH
- cuisines: Cambodian cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q96385320
- name: Kanji
- description: Indian dish
- countries: IN
- kinds: dish, rice dish
- has Wikipedia article: en

## DISH Q96386264
- name: Koose
- description: West African beans dish
- countries: (none)
- kinds: dish, snack
- ingredients: ginger, vegetable oil, onion, table salt
- has Wikipedia article: en

## DISH Q96397067
- name: Oatfield Emerald
- description: type of chocolate toffee sweet
- countries: (none)
- kinds: toffee
- has Wikipedia article: en

## DISH Q96398796
- name: Pepper and egg sandwich
- description: type of sandwich
- countries: US
- kinds: submarine sandwich
- has Wikipedia article: en

## DISH Q96402831
- name: Roti bolen
- description: Indonesian bread
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, bread
- has Wikipedia article: en

## DISH Q96404818
- name: Saj bread
- description: unleavened bread baked on a griddle
- countries: (none)
- kinds: flatbread
- has Wikipedia article: en

## DISH Q96407845
- name: Tarua
- description: food dish of the Indian subcontinent
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q96416082
- name: Zom
- description: Traditional Yemenite soup
- countries: YE
- kinds: food, recipe, plate
- ingredients: skhug, flour, butter, milk
- has Wikipedia article: en

## DISH Q96418530
- name: Frittelle
- description: Venetian doughnuts served during Carnival
- countries: IT
- cuisines: Venetian cuisine
- kinds: Italian cuisine, Croatian cuisine, Slovenian cuisine, food, dessert, doughnut, frittelle
- ingredients: dough, batter
- has Wikipedia article: en

## DISH Q964296
- name: Kulcha
- description: food
- countries: IN, PK
- kinds: food, flatbread
- ingredients: maida flour
- has Wikipedia article: en

## DISH Q9643274
- name: Bafa
- description: Capeverdean cuisine
- countries: (none)
- kinds: stew
- has Wikipedia article: en

## DISH Q96440087
- name: Kóe-tiâu
- other names: {"zh": "粿条"}
- description: dish with rice noodle as main ingredient
- countries: (none)
- kinds: noodle dish
- ingredients: rice noodle
- has Wikipedia article: en, zh

## DISH Q9644374
- name: Balas Chico Fumaça
- other names: {"pt": "Balas Chico Fumaça"}
- countries: (none)
- kinds: confectionery

## DISH Q9644388
- name: Balas Zequinha
- other names: {"pt": "Balas Zequinha"}
- countries: (none)
- kinds: confectionery

## DISH Q964469
- name: Krotekake
- description: food
- countries: NO
- kinds: food, flatbread
- ingredients: flour
- has Wikipedia article: en

## DISH Q96472986
- name: Chukuchuk
- description: dish from cuisine of the Marshall Islands
- countries: MH
- kinds: rice dish
- ingredients: Calrose rice, coconut
- has Wikipedia article: en

## DISH Q96473865
- name: Caballero pobre
- other names: {"es": "Caballero pobre"}
- countries: MX
- kinds: dessert

## DISH Q96475732
- name: Popiah
- other names: {"zh": "润饼"}
- description: Tionghoa traditional spring roll
- countries: (none)
- kinds: food, spring roll
- has Wikipedia article: en, zh

## DISH Q9651365
- name: Batatas a murro
- description: Portuguese potato dish
- countries: PT
- cuisines: Portuguese cuisine
- kinds: potato dish
- ingredients: olive oil, salt, potato
- has Wikipedia article: en

## DISH Q9653835
- name: Bem-casado
- countries: (none)
- kinds: confectionery

## DISH Q965589
- name: Pumpkin tortelli
- countries: IT
- kinds: Tortelli, type of pasta
- has Wikipedia article: en

## DISH Q9657134
- name: Bifana
- description: Portuguese pork sandwich
- countries: PT
- kinds: sandwich
- ingredients: garlic, pork, bread roll
- has Wikipedia article: en

## DISH Q9657329
- name: Bijajica
- description: Brazilian cassava cookies
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q96577178
- name: Pavé chocolate
- countries: (none)
- kinds: chocolate

## DISH Q9658011
- name: Avoador
- description: cassava biscuits
- countries: BR
- kinds: cookie
- ingredients: tapioca
- has Wikipedia article: en

## DISH Q965981
- name: Pélardon
- description: French cheese
- countries: FR
- kinds: goat cheese, raw-milk cheese, French cheese, farmstead cheese, industrial cheese, natural-rind soft cheese, dairy cheese
- ingredients: goat milk
- has Wikipedia article: en

## DISH Q9660281
- name: 喜蜜
- description: Type of honey jar
- countries: (none)
- kinds: product, honey
- has Wikipedia article: zh

## DISH Q9660636
- name: Bolo Souza Leão
- description: Brazilian cake from Pernambuco
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q96626805
- name: Pancha
- other names: {"es": "pancha"}
- countries: (none)
- kinds: bread

## DISH Q966327
- name: 哈里薩辣醬
- description: Tunisian hot chili pepper paste
- countries: TN
- kinds: sauce, hot sauce, tradition, cookbook, spread
- ingredients: chili pepper
- has Wikipedia article: en, zh

## DISH Q96728754
- name: Mammoth sauce
- description: Belgian condiment
- countries: BE
- kinds: condiment, sauce
- ingredients: onion, tomato purée, mayonnaise

## DISH Q96741549
- name: Peynirli pide
- description: Turkish pide type
- countries: TR
- kinds: food, pide
- has Wikipedia article: en

## DISH Q96741829
- name: Pide
- description: Turkish flatbread dish
- countries: TR
- cuisines: Turkish cuisine, Crimean Tatar cuisine
- kinds: food, dish, pide, traditional food, flatbread, Turkish breads
- has Wikipedia article: en

## DISH Q96742694
- name: Matapa
- description: Mozambican dish
- countries: MZ
- kinds: dish, sauce
- ingredients: garlic, peanut, coconut milk, cassava
- has Wikipedia article: en

## DISH Q96742825
- name: Makaroni schotel
- description: Indonesian casserole dish
- countries: ID
- kinds: dish, casserole
- ingredients: smoked meat, sausage, egg as food, mushroom, butter, onion, potato, cheese, milk, pasta
- has Wikipedia article: en

## DISH Q96749544
- name: Hors-d'œuvre
- other names: {"zh": "法式前菜"}
- description: appetizer in French cuisine
- countries: (none)
- kinds: human food, appetizer
- has Wikipedia article: en, zh

## DISH Q9675082
- name: Camarão na moranga
- other names: {"pt": "camarão na moranga"}
- countries: BR
- kinds: dish

## DISH Q96755419
- name: Goat gulai
- description: Indonesian curry-like dish originating from Sumatra island with goat meat as main ingredient
- countries: ID
- kinds: gulai
- ingredients: shallot, garlic, coriander seed, tomato, ginger, palm sugar, Aleurites moluccanus, coconut milk, goat meat, chili pepper, Cymbopogon citratus
- has Wikipedia article: en

## DISH Q96756392
- name: Deer liver
- description: liver of deer used for food
- countries: (none)
- kinds: dish, food ingredient, liver as food

## DISH Q96756415
- name: Honigseim
- other names: {"de": "Honigseim"}
- countries: (none)
- kinds: honey

## DISH Q96761025
- name: Prosciutto cotto
- description: Italian cooked ham
- countries: (none)
- kinds: cooked ham

## DISH Q96761401
- name: Saag paneer
- countries: IN
- kinds: dish
- ingredients: paneer, leaf vegetable

## DISH Q96835669
- name: Schömberger 12-Apostel-Bomben
- countries: (none)
- kinds: viennoiserie

## DISH Q9694384
- name: Canja de Goa
- description: Indo-Portuguese soup
- countries: (none)
- kinds: soup, dish
- has Wikipedia article: en

## DISH Q96959923
- name: Bauernschmaus
- countries: (none)
- kinds: dish

## DISH Q9696642
- name: Caribeu
- other names: {"pt": "caribeu"}
- countries: (none)
- kinds: dish

## DISH Q9696651
- name: Caril de frango
- other names: {"pt": "Caril de frango"}
- countries: (none)
- kinds: food

## DISH Q9697606
- name: Carneiro ao molho de vinho
- other names: {"pt": "carneiro ao molho de vinho"}
- countries: (none)
- kinds: dish

## DISH Q9697608
- name: Carneiro no buraco
- other names: {"pt": "carneiro no buraco"}
- countries: (none)
- kinds: dish

## DISH Q9697885
- name: Cartola
- other names: {"pt": "cartola"}
- countries: (none)
- kinds: confectionery

## DISH Q970055
- name: Gachamiga
- countries: ES
- kinds: type of food or dish, porridge, Migas

## DISH Q97011029
- name: Polenta dolce
- other names: {"it": "polenta dolce"}
- countries: IT
- kinds: confectionery
- ingredients: cornmeal

## DISH Q97016668
- name: Lettuce sandwich
- description: type of sandwich wrap
- countries: (none)
- kinds: sandwich, wrap
- ingredients: lettuce, bread
- has Wikipedia article: en

## DISH Q9706614
- name: Beaver stew
- description: Lithuanian dish
- countries: LT
- kinds: dish
- ingredients: beaver
- has Wikipedia article: en

## DISH Q97101726
- name: Meatball noodles
- description: Indonesian noodle soup
- countries: ID
- kinds: food, dish, ethnic food
- ingredients: bakso
- has Wikipedia article: en

## DISH Q97101918
- name: Hadler Hochzeitssuppe
- countries: (none)
- kinds: Hochzeitssuppe

## DISH Q971054
- name: Fruit fool
- other names: {"zh": "奶油伴水果"}
- description: English dessert
- countries: GB
- kinds: dessert
- ingredients: fruit, purée
- has Wikipedia article: en, zh

## DISH Q97162486
- name: Torta pazientina
- other names: {"it": "Torta pazientina"}
- countries: IT
- kinds: dessert

## DISH Q97164216
- name: Polenta del Marengo
- other names: {"it": "Polenta del Marengo"}
- countries: IT
- kinds: dessert

## DISH Q97164284
- name: Risotto al barolo
- other names: {"it": "Risotto al barolo"}
- countries: IT
- kinds: risotto
- ingredients: Barolo DOCG, rice

## DISH Q97164903
- name: Bazzoffia
- countries: IT
- kinds: soup, recipe, dish

## DISH Q97166855
- name: U Pan de Natale
- description: French bread
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q97167544
- name: Salòt
- other names: {"it": "Salòt"}
- countries: IT
- kinds: dessert

## DISH Q97170764
- name: Risotto con le rane
- other names: {"it": "Risotto con le rane"}
- countries: (none)
- kinds: risotto

## DISH Q97171917
- name: Frijol con puerco
- other names: {"es": "Frijol con puerco"}
- countries: MX
- kinds: dish

## DISH Q97171945
- name: Shio pan
- description: Japanese bread
- countries: (none)
- kinds: bread, food
- has Wikipedia article: en

## DISH Q97172601
- name: Testun
- description: cheese from Piedmont
- countries: IT
- kinds: cheese
- ingredients: goat milk

## DISH Q97173818
- name: Mohnmingilan
- description: Italian sweet pancake
- countries: IT
- kinds: dessert

## DISH Q97177611
- name: Itchāshī
- countries: (none)
- kinds: yasai itame

## DISH Q97178289
- name: Kue putu mayang
- description: Indonesian rice dish
- countries: ID
- kinds: dish, kolak, jajan pasar, street food
- ingredients: palm sugar, rice flour, tapioca, coconut milk, vanilla, table salt
- has Wikipedia article: en

## DISH Q97179225
- name: Zuccherini bolognesi
- other names: {"it": "Zuccherini bolognesi"}
- countries: (none)
- kinds: biscuit

## DISH Q97179718
- name: Telera
- description: bread from Cordoba, Spain
- countries: (none)
- kinds: bread, baked good
- ingredients: Andalusian cuisine
- has Wikipedia article: en

## DISH Q97181661
- name: Budino di riso
- other names: {"it": "budino di riso"}
- countries: IT
- kinds: sweet pie

## DISH Q97185505
- name: Squiccia
- description: Italian dessert
- countries: IT
- kinds: dessert

## DISH Q97189553
- name: Bubur gunting Singkawang
- other names: {"id": "Bubur gunting Singkawang"}
- countries: (none)
- kinds: food, porridge, congee

## DISH Q971928
- name: Monaka
- other names: {"zh": "最中"}
- description: Japanese confection
- countries: JP
- kinds: wagashi
- ingredients: red bean paste, mochi
- has Wikipedia article: en, zh

## DISH Q97196240
- name: Terasi bawang
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, side dish
- ingredients: onion, shrimp paste, bird's eye chili, table salt

## DISH Q97198504
- name: Lauantaipussi
- other names: {"fi": "Lauantaipussi"}
- countries: (none)
- kinds: candy

## DISH Q97198572
- name: Lihamuki
- other names: {"fi": "Lihamuki"}
- countries: (none)
- kinds: dish

## DISH Q97202137
- name: Janda berenang
- description: Indonesia traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, kue
- ingredients: granulated sugar, coconut milk, Vigna radiata, Pandanus amaryllifolius, vanilla, table salt, margarine

## DISH Q97202156
- name: Jawada
- description: Indonesian traditional food
- countries: ID
- kinds: human food
- ingredients: granulated sugar, Vanilla planifolia, rice flour, tapioca, cooking oil, table salt, water

## DISH Q97202291
- name: Kahangga
- description: Indonesian traditional cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, frying, snack
- ingredients: wheat flour, cooking oil, egg as food, sugar

## DISH Q97203028
- name: Putri mandi
- description: Malaysian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, kue
- ingredients: glutinous rice flour, grated coconut, corn starch, palm sugar, rice flour, coconut milk, Pandanus amaryllifolius, table salt, water

## DISH Q97204574
- name: 동태찌개
- other names: {"ko": "동태찌개"}
- description: Korean fish soup
- countries: KR
- cuisines: Korean cuisine
- kinds: jjigae, fish soup
- ingredients: Theragra chalcogramma

## DISH Q97206077
- name: Sucuklu yumurta
- other names: {"tr": "Sucuklu yumurta"}
- countries: (none)
- kinds: fried egg

## DISH Q97207091
- name: Wadi
- other names: {"id": "Wadi"}
- countries: ID
- kinds: side dish
- ingredients: table salt, rice, fish

## DISH Q97207900
- name: Haşıl
- description: Turkish dish
- countries: TR
- kinds: food, Turkish soups
- ingredients: butter, yogurt, Wheat mote

## DISH Q97207975
- name: Kuih limas
- countries: MY
- kinds: Kuih

## DISH Q97208149
- name: Ленивые блюда
- other names: {"ru": "Ленивые блюда"}
- countries: (none)
- kinds: dish

## DISH Q97208796
- name: Havregrynskage
- other names: {"da": "Havregrynskage"}
- countries: (none)
- kinds: cookie

## DISH Q97208861
- name: Прасковена торта
- other names: {"bg": "Прасковена торта"}
- countries: (none)
- kinds: upside-down cake

## DISH Q97209095
- name: Katerisallang
- description: Indonesian food
- countries: (none)
- kinds: dish

## DISH Q97210319
- name: Sikaporo
- other names: {"id": "Sikaporo"}
- countries: (none)
- kinds: dish

## DISH Q97213015
- name: Batiah
- other names: {"min": "batiah"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack
- ingredients: palm sugar, cooking oil, glutinous rice, table salt, water

## DISH Q97213219
- name: Lompong Sagu
- description: traditional regional food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack
- ingredients: sago flour, grated coconut, Saba banana, table salt, sugar

## DISH Q97213416
- name: Ikan peda
- other names: {"min": "Ikan peda"}
- countries: ID
- kinds: human food, traditional food

## DISH Q97213627
- name: Karak kaliang
- description: a savory snack made from tapioca flour
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack
- ingredients: cassava root, tapioca, black pepper, Sweet potato, table salt

## DISH Q97213639
- name: Karupuak jangek
- description: Indonesia cuisine
- countries: ID
- cuisines: Indonesian cuisine, Padang cuisine
- kinds: dish, human food, type of food or dish, krupuk
- ingredients: cowhide

## DISH Q97213843
- name: Lepat pisang
- countries: (none)
- kinds: Kuih
- ingredients: banana

## DISH Q97214217
- name: Asam padeh ikan
- description: Indonesian traditional food
- countries: ID
- cuisines: Padang cuisine
- kinds: food, fish dish
- ingredients: garlic, Holy Basil, Allium ascalonicum, chili pepper, ginger, water, fish

## DISH Q97216847
- name: Larpeira
- other names: {"es": "Larpeira"}
- countries: ES
- cuisines: Galician cuisine
- kinds: torte

## DISH Q97219066
- name: Sate Ulat Sagu Khas Papua
- other names: {"id": "Sate Ulat Sagu Khas Papua"}
- countries: (none)
- kinds: food, dish, type of food or dish

## DISH Q97223031
- name: Vanilla cake
- countries: (none)
- kinds: dish, cake

## DISH Q97226669
- name: Kuai tiao pak mo
- description: Thai noodle dish with fillings
- countries: TH
- kinds: dish

## DISH Q972267
- name: Porilainen
- description: sandwich and street food dish in Finnish cuisine
- countries: FI
- kinds: sandwich
- ingredients: onion, white bread, pickled cucumber, ketchup, mustard, sausage
- has Wikipedia article: en

## DISH Q97227974
- name: Egg roll
- description: Indonesian snacks
- countries: ID
- kinds: snack, traditional food, fried food
- ingredients: rice vermicelli, egg as food
- has Wikipedia article: en

## DISH Q97230633
- name: Gohu ikan
- description: Indonesian traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: type of food or dish, food, dish, human food, meal
- ingredients: chili pepper, table salt, Thunnini, Holy Basil, skipjack tuna

## DISH Q97231328
- name: Kohu-kohu
- description: traditional food from Indonesia
- countries: ID
- kinds: dish, human food
- ingredients: shallot, spinach, Ocimum × africanum, grated coconut, Kangkung, seedling, Asparagus bean, shrimp paste, Kaempferia galanga, chili pepper, Cucumis sativus, table salt

## DISH Q97231600
- name: Nasi lapola
- description: Maluku rice dish
- countries: ID
- kinds: food, dish, human food, traditional food, Indonesian cuisine
- ingredients: Indonesian bay leaf, shallot, turmeric rhizome, garlic, prawn cracker, boiled egg, coconut milk, Alpinia galanga, chili pepper, ginger, Cymbopogon citratus, tomato, Cucumis sativus, table salt, rice, water

## DISH Q97236883
- name: Sambal ganja
- description: kind of sambal from Aceh, Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, sambal
- ingredients: shallot, Kaffir Lime Leaf, bird's eye chili, cooking oil, Averrhoa bilimbi, Cymbopogon citratus, table salt

## DISH Q97238325
- name: Rikwato
- other names: {"tr": "Rikwato"}
- countries: (none)
- kinds: dessert

## DISH Q97241030
- name: Mie kuah
- countries: ID
- kinds: noodle soup
- has Wikipedia article: en

## DISH Q97246919
- name: Tulshimala rice
- description: geographical Indications in Bangladesh
- countries: BD
- kinds: rice
- has Wikipedia article: en

## DISH Q97247039
- name: Pera Sandesh
- countries: (none)
- kinds: dessert

## DISH Q97250077
- name: Wælibæx
- description: Ossetian traditional pie
- countries: (none)
- cuisines: Ossetian cuisine
- kinds: Ossetian pies

## DISH Q97258567
- name: Madhubhat
- countries: BD
- kinds: dessert

## DISH Q97258831
- name: Kypmantsje
- other names: {"fy": "kypmantsje"}
- countries: (none)
- kinds: type of food or dish, cookie

## DISH Q97265687
- name: Davondžyn
- countries: (none)
- cuisines: Ossetian cuisine
- kinds: Ossetian pies

## DISH Q97270696
- name: Qiyma kömech
- countries: (none)
- kinds: kömech

## DISH Q97270821
- name: Kömech
- other names: {"zh": "库麦其"}
- description: Ugyhur traditional bread
- countries: CN
- cuisines: Xinjiang cuisine, Uyghur cuisine
- kinds: type of food or dish, flatbread
- ingredients: mutton, wheat flour
- has Wikipedia article: zh

## DISH Q97271547
- name: Getas
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack, kue
- ingredients: glutinous rice flour, coconut, palm sugar, table salt

## DISH Q97271670
- name: Kakicak
- description: traditional Indonesian steamed cake from the Banjar people of South Kalimantan
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, kue
- ingredients: glutinous rice flour, coconut, palm sugar, table salt

## DISH Q97273883
- name: Lose golose
- other names: {"it": "Lose golose"}
- countries: IT
- kinds: dessert

## DISH Q97273925
- name: Pesche ripiene
- other names: {"it": "Pesche ripiene"}
- countries: IT
- kinds: dessert

## DISH Q97274205
- name: Bonbon aleewa
- other names: {"fr": "Bonbon aleewa"}
- countries: (none)
- kinds: dish

## DISH Q97274349
- name: Torta Zurigo
- other names: {"it": "Torta Zurigo"}
- countries: IT
- kinds: dessert, cake
- ingredients: chantilly cream, sweetcrust pastry, cherry, chocolate

## DISH Q97274510
- name: Caciotta di Brugnato
- other names: {"it": "Caciotta di Brugnato"}
- countries: IT
- kinds: cheese

## DISH Q97278426
- name: Whistle candy
- other names: {"zh": "口哨糖"}
- countries: JP
- kinds: candy
- has Wikipedia article: zh

## DISH Q97278843
- name: Chaoshan beef hot pot
- other names: {"zh": "潮汕牛肉火锅"}
- description: beef hot pot originated from Chaoshan, Guangdong, China
- countries: CN
- kinds: hot pot
- has Wikipedia article: en, zh

## DISH Q97279239
- name: Muccellato
- other names: {"it": "Muccellato"}
- countries: IT
- kinds: dessert

## DISH Q97279333
- name: Скумбрыя ў кажушку
- other names: {"be-tarask": "Скумбрыя ў кажушку"}
- countries: (none)
- kinds: dish

## DISH Q97292941
- name: Miondo
- other names: {"fr": "Miondo"}
- countries: (none)
- kinds: dish

## DISH Q97293020
- name: Chapon du Périgord
- other names: {"fr": "chapon du Périgord"}
- countries: FR
- kinds: meat, capon

## DISH Q97307614
- name: Mendut cake
- description: Javanese traditional cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, kue, type of food or dish, snack

## DISH Q97307754
- name: Babungku
- description: traditional steamed cake originating from the Banjar people of South Kalimantan, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, street food
- ingredients: banana leaf, palm sugar, rice flour, coconut milk, table salt, sugar

## DISH Q97307766
- name: Baayak Porridge
- description: variations of typical Indonesian food
- countries: ID
- kinds: food, dish, type of food or dish, porridge, traditional food
- ingredients: wheat flour, palm sugar, rice flour, coconut milk, Pandanus amaryllifolius, betel, calcium carbonate, limestone, table salt, sugar, water

## DISH Q97307775
- name: Cincin
- description: regional specialties food
- countries: (none)
- kinds: food, dish, traditional food, snack
- ingredients: wheat flour, palm sugar, table salt

## DISH Q97307872
- name: Pupudak baras
- description: Indonesian food
- countries: ID
- kinds: dish, street food
- ingredients: banana leaf, palm sugar, rice flour, tapioca, coconut milk, Pandanus amaryllifolius, table salt

## DISH Q97308080
- name: Ne porridge
- description: traditional sweet porridge from Maluku, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, kolak
- ingredients: sago

## DISH Q97308081
- name: Bubur sagu Ambon
- other names: {"id": "bubur sagu Ambon"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, congee
- ingredients: sago

## DISH Q97308883
- name: Ale ale
- other names: {"id": "Ale ale"}
- countries: (none)
- kinds: dish, type of food or dish

## DISH Q97311294
- name: Kontrabáš
- other names: {"cs": "Kontrabáš"}
- countries: (none)
- kinds: dish, food

## DISH Q97311516
- name: Sensara
- countries: (none)
- kinds: dish, fish dish
- ingredients: shark as food

## DISH Q97312126
- name: 国分にんじん
- other names: {"ja": "国分にんじん"}
- countries: (none)
- kinds: carrot

## DISH Q97312305
- name: Ostraváček
- other names: {"cs": "Ostraváček"}
- countries: (none)
- kinds: dessert

## DISH Q973125
- name: Flódni
- description: layered cake
- countries: (none)
- kinds: torte, layer cake
- has Wikipedia article: en

## DISH Q97314684
- name: Sharots
- description: traditional Armenian confection
- countries: AM
- cuisines: Armenian cuisine
- kinds: dessert
- ingredients: cardamom, Cinnamomum verum, Dianthus, flour, sugar

## DISH Q97315123
- name: Klouschterhäip
- other names: {"lb": "Klouschterhäip"}
- countries: RU
- cuisines: Russian cuisine
- kinds: cake
- ingredients: Cream, prune, buttercream, icing, chocolate, Prunus subg. Cerasus

## DISH Q97320386
- name: Kurdish pastry
- description: type of pastry
- countries: (none)
- kinds: börek
- has Wikipedia article: en

## DISH Q97324305
- name: Булетте
- other names: {"ru": "Булетте"}
- countries: DE
- kinds: meat dish
- ingredients: beef, pork

## DISH Q97325303
- name: 剑南春
- countries: (none)
- kinds: baijiu
- has Wikipedia article: zh

## DISH Q97339873
- name: Jjapaguri
- description: Korean dish
- countries: KR
- kinds: noodle
- ingredients: Neoguri, Chapagetti
- has Wikipedia article: en

## DISH Q97340896
- name: Vierreleipä
- other names: {"fi": "Vierreleipä"}
- countries: (none)
- kinds: bread

## DISH Q97341024
- name: Silakkapihvi
- other names: {"fi": "Silakkapihvi"}
- countries: (none)
- kinds: fish dish

## DISH Q97341031
- name: Särvin
- other names: {"fi": "Särvin"}
- countries: (none)
- kinds: fish dish

## DISH Q97341340
- name: Fazerin Parhain
- other names: {"fi": "Fazerin Parhain"}
- countries: (none)
- kinds: candy

## DISH Q97341479
- name: Rusinamakkara
- other names: {"fi": "Rusinamakkara"}
- description: Finnish sausage
- countries: FI
- kinds: sausage

## DISH Q97341957
- name: 8の字
- other names: {"ja": "8の字"}
- countries: JP
- kinds: Miyagegashi

## DISH Q973455
- name: Parmigiana
- other names: {"zh": "焗烤千層茄子"}
- description: Italian dish
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish
- ingredients: basil, eggplant, tomato sauce, onion, peppercorn, fior di latte, Parmesan, oil, table salt
- has Wikipedia article: en, zh

## DISH Q97347057
- name: 太陽公生及九豬十六羊祭品
- countries: (none)
- kinds: dish, Sacred food as offering
- has Wikipedia article: zh

## DISH Q973523
- name: Pantteri
- description: Finnish candy brand
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q97358694
- name: Achira
- description: Colombian crackers
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q97360429
- name: Bolu kukus
- description: Indonesian cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, kue, type of food or dish, snack
- ingredients: wheat, sodium bicarbonate, egg as food, sugar, milk
- has Wikipedia article: en

## DISH Q97369897
- name: Scarpedd
- other names: {"it": "Scarpedd"}
- countries: IT
- kinds: dessert

## DISH Q97371416
- name: Sprinkles
- other names: {"zh": "巧克力米"}
- description: tiny multi-colored candy topping
- countries: (none)
- kinds: candy, dessert topping
- has Wikipedia article: en, zh

## DISH Q97372577
- name: Ampiang dadiah
- other names: {"id": "ampiang dadiah"}
- countries: ID
- kinds: dessert, snack

## DISH Q97374636
- name: Sagu bakar
- description: roasted sago dish from Indonesia
- countries: ID
- kinds: staple food, food
- ingredients: sago

## DISH Q97375296
- name: Kæmpe Eskimo
- other names: {"da": "Kæmpe Eskimo"}
- countries: (none)
- kinds: popsicle stick, ice cream

## DISH Q97376215
- name: Bean-to-bar
- description: term created by the craft chocolate movement to describe the manufacturing process from cocoa bean to chocolate bar
- countries: (none)
- kinds: production process, technique, industry classification scheme, chocolate, culinary art
- has Wikipedia article: en

## DISH Q97380255
- name: Zungenragout
- other names: {"de": "Zungenragout"}
- countries: (none)
- kinds: ragout

## DISH Q97382673
- name: Затяжное печенье
- other names: {"ru": "Затяжное печенье"}
- countries: (none)
- kinds: cookie

## DISH Q9744810
- name: Cheque cheque
- description: type of Indo-Portuguese food
- countries: (none)
- kinds: dish

## DISH Q97455427
- name: Gangan
- other names: {"id": "gangan"}
- countries: ID
- kinds: soup

## DISH Q97477650
- name: Claypot chicken rice
- countries: (none)
- kinds: claypot rice

## DISH Q9748820
- name: Chipa
- description: traditional food from Paraguay and northeastern Argentina
- countries: PY
- kinds: snack, bread
- has Wikipedia article: en

## DISH Q9750565
- name: Chocolate meio-amargo
- other names: {"pt": "Chocolate meio-amargo"}
- countries: (none)
- kinds: types of chocolate, chocolate
- ingredients: cocoa powder, sugar

## DISH Q9751480
- name: Chouriço doce
- description: Portuguese blood sausage
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q97576867
- name: Pinepan
- other names: {"es": "Pinepan"}
- countries: (none)
- kinds: sweet bread

## DISH Q97578990
- name: Portokalopita
- description: Greek orange cake
- countries: GR
- kinds: food, cake
- has Wikipedia article: en

## DISH Q97591276
- name: Kaakje
- other names: {"nl": "kaakje"}
- countries: (none)
- kinds: type of food or dish, biscuit

## DISH Q97599035
- name: Antakya sürkü
- other names: {"tr": "Antakya sürkü"}
- countries: TR
- kinds: cheese, cottage cheese

## DISH Q976073
- name: Givré
- description: dessert
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q97609970
- name: Herculaneum loaf
- description: sourdough bread loaf baked 24 August 79 AD
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q97610633
- name: Korean egg drop soup
- other names: {"zh": "韩式蛋花汤"}
- countries: (none)
- kinds: soup, egg dish

## DISH Q97625311
- name: Fatit
- countries: SA
- kinds: type of food or dish, cookie
- ingredients: wheat flour, spice

## DISH Q976284
- name: Violet candy
- description: confectionary made with essences of violet
- countries: (none)
- kinds: candy, confectionery

## DISH Q97649599
- name: Pecorino del Monte Poro
- description: PDO cheese from Italy
- countries: IT
- kinds: cheese, pecorino

## DISH Q97656573
- name: Chonggak-kimchi
- other names: {"zh": "總角辛奇"}
- countries: (none)
- kinds: radish kimchi

## DISH Q97656653
- name: Doce de buriti
- other names: {"pt": "doce de buriti"}
- countries: (none)
- kinds: dessert

## DISH Q97657701
- name: Kochreis
- other names: {"de": "Kochreis"}
- countries: (none)
- kinds: rice dish

## DISH Q97658126
- name: Saka no Taiyaki
- other names: {"zh": "佐賀鯛魚燒"}
- countries: (none)
- kinds: taiyaki

## DISH Q97660964
- name: Камди-ча
- other names: {"ru": "Камди-ча"}
- countries: (none)
- kinds: dish

## DISH Q97663518
- name: Свекольник
- other names: {"ru": "Свекольник"}
- countries: RU
- cuisines: Russian cuisine
- kinds: dish, cold sweet soup, beetroot soup
- ingredients: kvass, beet

## DISH Q97663788
- name: Соломка
- other names: {"ru": "Соломка"}
- countries: (none)
- kinds: baked good

## DISH Q97670959
- name: Doce de mamão
- other names: {"pt": "doce de mamão"}
- countries: (none)
- kinds: dessert

## DISH Q97703763
- name: Bolo de carimã
- other names: {"pt": "bolo de carimã"}
- countries: (none)
- kinds: cake

## DISH Q97704878
- name: Gelderse gekookte worst
- other names: {"nl": "Gelderse gekookte worst"}
- countries: NL
- kinds: sausage

## DISH Q97749998
- name: Mostillo de mel
- countries: ES
- kinds: dessert
- ingredients: honey

## DISH Q977539
- name: Mochi ice cream
- other names: {"zh": "雪米糍"}
- description: Japanese food mochi adapted to a dessert
- countries: JP
- kinds: ice cream, mochi
- ingredients: mochi, powdered sugar, ice cream
- has Wikipedia article: en, zh

## DISH Q97796066
- name: Doce de abacaxi
- other names: {"pt": "doce de abacaxi"}
- countries: (none)
- kinds: dessert

## DISH Q978397
- name: Tuna fish sandwich
- description: type of sandwich
- countries: US
- kinds: tuna dish, fish sandwich
- ingredients: tuna salad, bread
- has Wikipedia article: en

## DISH Q978399
- name: Sun-dried tomato
- other names: {"zh": "晒干的番茄"}
- description: tomatoes which have been dried in the sun
- countries: (none)
- kinds: dried vegetable, tomato dish
- ingredients: tomato
- has Wikipedia article: en, zh

## DISH Q978405
- name: Aziminu
- description: Corsican fish soup
- countries: FR
- cuisines: cuisine of Corsica
- kinds: fish soup

## DISH Q97860445
- name: Doce de castanha de caju
- other names: {"pt": "doce de castanha de caju"}
- countries: (none)
- kinds: dessert

## DISH Q978758
- name: Sildesalat
- description: mixed salad featuring salted herring
- countries: NO
- kinds: salad, fish dish
- has Wikipedia article: en

## DISH Q97958890
- name: محشوش
- other names: {"ar": "محشوش"}
- countries: SA, YE
- kinds: dish

## DISH Q980288
- name: Pecorino Toscano PDO
- other names: {"zh": "Pecorino Toscano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, pecorino
- ingredients: sheep milk
- has Wikipedia article: en

## DISH Q980300
- name: Joulutorttu
- description: Finnish christmas baked dessert
- countries: FI
- cuisines: Finnish cuisine
- kinds: bakelse, pastry
- has Wikipedia article: en

## DISH Q98074437
- name: Stuffed lotus root with sticky rice
- other names: {"zh": "糖藕"}
- countries: (none)
- kinds: dish
- ingredients: Lotus rhizome
- has Wikipedia article: zh

## DISH Q98077124
- name: Mangada
- other names: {"pt": "mangada"}
- countries: (none)
- kinds: dessert

## DISH Q98078539
- name: Dried fruit bread
- description: Sweet fruit and nut bread
- countries: (none)
- kinds: dried fruit, fruit bread
- has Wikipedia article: en

## DISH Q980840
- name: Gudeg
- other names: {"zh": "古德"}
- description: Indonesian traditional dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, main course, traditional food
- ingredients: Tilia leaf, garlic, jackfruit, Nangka, bay leaf, Aleurites moluccanus, coconut milk, red onion, Gnetum gnemon, table salt, sugar
- has Wikipedia article: en

## DISH Q98098680
- name: Cocada de babaçu
- other names: {"pt": "cocada de babaçu"}
- countries: (none)
- kinds: dessert

## DISH Q98108393
- name: Carne al toro
- description: beef stew
- countries: (none)
- kinds: dish

## DISH Q98110000
- name: 宋嫂鱼羹
- countries: (none)
- kinds: Hangzhou cuisine, fish dish
- ingredients: Jinhua ham, bamboo shoots, mandarin fish, Lentinula edodes
- has Wikipedia article: zh

## DISH Q98141422
- name: Cheese Kamaboko
- description: Mixed product of cheese and surimi
- countries: JP
- kinds: kamaboko
- ingredients: fish surimi, cheese

## DISH Q98210440
- name: Sopa a la minuta
- other names: {"es": "sopa a la minuta"}
- countries: PE
- kinds: meal, soup

## DISH Q98271319
- name: אכילת מצה
- other names: {"he": "אכילת מצה"}
- countries: (none)
- kinds: mitzvah, Passover, matzah

## DISH Q98275799
- name: Salade scandinave
- countries: (none)
- kinds: composed salad

## DISH Q982758
- name: Marraqueta
- description: rolled type of bread
- countries: BO, CL
- kinds: bread, leavened bread
- has Wikipedia article: en

## DISH Q98279051
- name: Renteng satay
- description: Balinese pork satay
- countries: ID
- cuisines: Indonesian cuisine
- kinds: folklore, dish, Indonesian cuisine, human food, Sacred food as offering, type of food or dish, satay, meal
- ingredients: pork

## DISH Q98297274
- name: Jeljlania
- description: Tunisian confection
- countries: (none)
- kinds: confectionery

## DISH Q983032
- name: Ovos moles
- other names: {"zh": "阿威罗软蛋"}
- description: local delicacy from Aveiro District, Portugal
- countries: PT
- kinds: egg dish
- ingredients: doce de ovos, egg yolk, sugar
- has Wikipedia article: en, zh

## DISH Q98304693
- name: Garroticos
- other names: {"es": "Garroticos"}
- countries: ES
- kinds: food, confectionery
- ingredients: Cabell d'àngel, puff pastry, chocolate, apple

## DISH Q983160
- name: Bak kut teh
- other names: {"zh": "肉骨茶"}
- description: Fujian Chinese dish
- countries: MY
- kinds: type of food or dish, pork dish, food
- ingredients: spare ribs, pork ribs
- has Wikipedia article: en, zh

## DISH Q98320311
- name: Suiton
- other names: {"zh": "水團 (食品)"}
- description: dumpling soup
- countries: JP
- kinds: type of food or dish, soup
- has Wikipedia article: en, zh

## DISH Q985580
- name: Dapanji
- other names: {"zh": "大盘鸡"}
- description: Chinese and Dungan food with chicken, soy sauce and other Chinese ingredients
- countries: CN
- cuisines: Chinese cuisine
- kinds: type of food or dish, chicken dish
- has Wikipedia article: en, zh

## DISH Q985812
- name: Orange cuttlefish
- other names: {"zh": "滷水墨鱼"}
- description: Cantonese cuttlefish dish
- countries: CN
- cuisines: Chinese cuisine
- kinds: seafood dish
- ingredients: Sepiida
- has Wikipedia article: en, zh

## DISH Q985814
- name: Banana roll
- other names: {"zh": "香蕉糕"}
- description: common Chinese or Hongkonger pastry
- countries: CN
- cuisines: Chinese cuisine
- kinds: pastry
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q98594037
- name: Indio viejo
- description: type of stew
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q98598236
- name: Badem şekeri
- description: sugar coated almond candy, typical of Turkey
- countries: (none)
- kinds: food, candy
- ingredients: almond, sugar

## DISH Q98662788
- name: Galette des rois
- countries: (none)
- kinds: cake, king cake

## DISH Q986726
- name: Ox-tongue pastry
- other names: {"zh": "牛脷酥"}
- description: Chinese fried pastry
- countries: (none)
- kinds: doughnut
- ingredients: fried dough
- has Wikipedia article: en, zh

## DISH Q98716450
- name: Chilpachole
- description: Mexican seafood stew
- countries: MX
- kinds: dish

## DISH Q98768411
- name: Calabash noodle soup
- other names: {"zh": "葫蘆麵"}
- countries: (none)
- kinds: dish, noodle soup

## DISH Q987686
- name: Moo shu pork
- other names: {"zh": "木樨肉"}
- description: American Chinese dish
- countries: CN
- kinds: pork dish, egg dish
- has Wikipedia article: en, zh

## DISH Q98834440
- name: Απάκι
- other names: {"el": "Απάκι"}
- countries: GR
- kinds: cold cut

## DISH Q98842973
- name: Hussar's Buns
- description: Austrian Christmas cookies
- countries: (none)
- kinds: viennoiserie

## DISH Q98869070
- name: Pink sausage
- description: fish sausage of Korea
- countries: (none)
- kinds: fish sausage

## DISH Q98915545
- name: Wet candied mangoes
- description: candied fruit made of mangoes
- countries: (none)
- kinds: candied fruit
- ingredients: sugar, mango

## DISH Q98915546
- name: Kolmbeng
- description: a type of bread from Yogyakarta, Indonesia
- countries: ID
- kinds: bread
- ingredients: fermentation starter, tapioca, egg as food, sugar

## DISH Q98915547
- name: Coconut candy
- description: Indonesian sweets
- countries: ID
- kinds: confectionery
- ingredients: coconut, tapioca, sugar

## DISH Q98915549
- name: Deep-fried grashopper
- description: deep-fried food made from grasshopper
- countries: ID
- cuisines: Indonesian cuisine, Javanese cuisine
- kinds: food, human food, traditional food, snack, deep-fried food, insect as food
- ingredients: Allium ascalonicum, Caelifera, table salt, garlic

## DISH Q98915554
- name: Arum manis
- description: a type of Indonesian cotton candy
- countries: ID
- kinds: cotton candy
- ingredients: wheat flour, sugar

## DISH Q98915607
- name: Fish head gulai
- description: Indonesian curry-like dish originating from West Sumatra made using the head of a fish, usually snapper fish
- countries: ID
- kinds: gulai
- ingredients: Indonesian bay leaf, Garcinia xanthochymus fruit, shallot, turmeric rhizome, garlic, caraway seeds, coriander seed, ginger, coconut, coconut milk, Pandanus amaryllifolius, Averrhoa bilimbi, chili pepper, Barramundi, Cymbopogon citratus, table salt

## DISH Q98915632
- name: Grubi
- description: Indonesian sweets
- countries: ID
- kinds: confectionery
- ingredients: Sweet potato, sugar

## DISH Q98915653
- name: Sempe
- description: Indonesian sweets
- countries: ID
- kinds: confectionery
- ingredients: tapioca, sugar

## DISH Q98915664
- name: Dendeng baracik
- description: a type of Indonesian dendeng
- countries: ID
- kinds: beef dish
- ingredients: shallot, garlic, tomato, coconut water, cooking oil, beef, chili pepper, table salt

## DISH Q98915667
- name: Lontong pical
- countries: ID
- kinds: fast food, street food, lontong, jajan pasar, noodle dish
- ingredients: lontong, noodle, Brassica oleracea var. capitata

## DISH Q98915671
- name: Klengkam
- other names: {"id": "klengkam"}
- countries: ID
- kinds: fries
- ingredients: Allium ascalonicum, chili pepper, Allium sativum, potato

## DISH Q98915675
- name: Wet candied nutmeg
- description: wet candied fruit made from the fruit of nutmeg
- countries: ID
- kinds: candied fruit
- ingredients: nutmeg, sugar

## DISH Q98915728
- name: Gulai Kapau
- description: Authentic Indonesian food from West Sumatra
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, gulai
- ingredients: garlic, jackfruit, onion, Asparagus bean, coconut milk, palm oil, table salt

## DISH Q98966083
- name: Pipes and potatoes
- description: Gujarati potato dish
- countries: IN
- cuisines: Gujarati cuisine
- kinds: food, potato dish
- ingredients: potato

## DISH Q989780
- name: St. Galler brot
- description: Swiss bread
- countries: (none)
- kinds: bread

## DISH Q990859
- name: Bread crust
- other names: {"zh": "麪包皮"}
- description: outer layer of bread
- countries: (none)
- kinds: baked good, part
- has Wikipedia article: en
