# Review batch names-004

## DISH Q106981206
- name: Roshur sorshe diye rui machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q106981239
- name: Dudh bori diye jhinge beguner jhol
- description: Bengali cuisine
- countries: (none)
- kinds: Jhol

## DISH Q106981280
- name: Chingri diye kolai dal
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q106981334
- name: Koraishuntir dhokar dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna, vegetable dish

## DISH Q106981386
- name: Aam begun
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106981419
- name: Chingri machher bati chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q106981489
- name: Mouri paneer
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106981790
- name: Sheem pur
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106981799
- name: Chhana koraishuntir chop
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106981809
- name: Kumro patay chingrir bora
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q106981848
- name: Tangra posto
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106981872
- name: Khoi er bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q106981884
- name: Lebu patay katla
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106981894
- name: Alu potol bori-bati chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q10698666
- name: Tisdagssoppa
- other names: {"sv": "Tisdagssoppa"}
- countries: (none)

## DISH Q106986849
- name: Peyajkoli diye tengra machh er jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q10698918
- name: Tjockbullar
- other names: {"sv": "Tjockbullar"}
- countries: (none)
- kinds: pastry

## DISH Q10698992
- name: Tjälknöl
- description: Swedish dish
- countries: SE
- kinds: dish
- ingredients: moose
- has Wikipedia article: en

## DISH Q10699143
- name: Toast skagen
- description: Swedish toast dish
- countries: SE
- kinds: open sandwich
- ingredients: skagenröra, toast
- has Wikipedia article: en

## DISH Q10699144
- name: Toast Pelle Janzon
- description: sandwich
- countries: (none)
- kinds: open sandwich
- ingredients: red onion, Kalix Löjrom, beef tenderloin, egg yolk, toast

## DISH Q107007191
- name: Dambu
- description: food from Niger
- countries: NE, NG
- kinds: dish
- ingredients: maize, onion, cooking oil, moringa, couscous, table salt
- has Wikipedia article: en

## DISH Q107008224
- name: Nân-e panjere
- description: Middle Eastern and Middle Eastern-influenced rosette-like fried dough food
- countries: IR
- cuisines: Spanish cuisine
- kinds: type of food or dish, dessert, fritter
- ingredients: flour

## DISH Q107014807
- name: Gyoza
- other names: {"zh": "日式饺子"}
- description: Japanese-Chinese dumplings
- countries: (none)
- kinds: jiaozi
- has Wikipedia article: en, zh

## DISH Q107020680
- name: Abon
- description: Indonesian dish originating from Java island
- countries: ID
- kinds: dish

## DISH Q107027754
- name: Natun alur dum
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107027762
- name: Alur khosa bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107027782
- name: Gondhoraj pomfret fry
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q107027794
- name: Palang shak diye chingri vapa
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q107027805
- name: Chal potol
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107027822
- name: Gondhoraj Bhetki
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107027921
- name: Gondhoraj chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q107028159
- name: Dim er chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q107047575
- name: Gilgeori toast
- description: South Korean food
- countries: KR
- cuisines: South Korean cuisine
- kinds: sandwich, street food
- ingredients: chicken egg, onion, scallion, ketchup, pan loaf, Brassica oleracea var. capitata, butter, sugar, carrot
- has Wikipedia article: en

## DISH Q107061450
- name: Peyajkoli diye rui machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107061453
- name: Peyajkoli diye katla machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107061461
- name: Lebu lonka murgi
- description: Bengali cuisine
- countries: (none)
- kinds: chicken dish

## DISH Q107061465
- name: Tangra machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q107061469
- name: Badhakopir paturi
- description: Bengali cuisine
- countries: (none)
- kinds: cabbage dish, paturi

## DISH Q107061478
- name: Kosha chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q107061486
- name: Peyajkoli ar alu diye tyangra machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107061509
- name: Katla posto
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107061516
- name: Tomato diye chingrir patla jhol
- description: bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q107061524
- name: Begun diye kolai dal
- description: Bengali cuisine
- countries: (none)
- kinds: eggplant dish, lentil soup

## DISH Q107061527
- name: Hing chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q107061534
- name: Alu panch phoron
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107061540
- name: Dim sorshe
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q107061544
- name: Sheem paturi
- description: Bengali cuisine
- countries: (none)
- kinds: paturi

## DISH Q107061547
- name: Dom chitor
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107061553
- name: Boal machher dom
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107061556
- name: Komola pulao
- description: Bengali cuisine
- countries: (none)
- kinds: rice dish, pilaf

## DISH Q107061568
- name: Chhana phulkopi
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107061605
- name: Kumro phuler pur
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107061641
- name: Keemar labra
- description: Bengali cuisine
- countries: (none)
- kinds: chicken dish

## DISH Q107063111
- name: Pudingový koláč
- description: Slovak dessert
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q107063815
- name: French burnt peanuts
- description: Candy
- countries: (none)
- kinds: candy, peanut

## DISH Q107064408
- name: Javanais
- description: Belgian dessert
- countries: BE
- kinds: dessert
- ingredients: buttercream, ganache, sponge cake

## DISH Q10706493
- name: Turban
- other names: {"sv": "turban"}
- countries: (none)
- kinds: pastry

## DISH Q107064986
- name: Speculoos biscuit
- description: Belgian caramel biscuit, with a different recipe than traditional speculaas
- countries: BE
- cuisines: cuisine of Belgium
- kinds: speculaas biscuit, biscuit
- ingredients: speculoos
- has Wikipedia article: en

## DISH Q10706679
- name: Tuttul
- description: dish on flatbread
- countries: (none)
- kinds: dish

## DISH Q107071683
- name: Chirer pulao
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, pilaf

## DISH Q107071712
- name: Peyajkoli posto
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107071820
- name: Doi korola
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107071869
- name: Aam sorse pomfret
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107071920
- name: Dudh paneer
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107071978
- name: Kacha aamer chutney
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, chutney

## DISH Q107072060
- name: Kanthal bij er vorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q107072113
- name: Peper plastic chutney
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, chutney

## DISH Q107072144
- name: Alu kachkola diye katla machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107092059
- name: Choesels
- description: dish from Brussels, Belgium
- countries: BE
- kinds: dish, carbonade flamande
- ingredients: gueuze, testicle

## DISH Q107093014
- name: Antep Baklava
- description: baklava from the City of Gaziantep, Turkey, as recognized by the EU
- countries: TR
- kinds: food, baklava

## DISH Q107094509
- name: Lemon bar
- description: lemon flavored dessert bar
- countries: (none)
- kinds: dessert bar
- ingredients: shortcrust pastry, lemon
- has Wikipedia article: en

## DISH Q10709601
- name: Ungui
- description: Type of a tamale
- countries: MX
- kinds: dish, tamale

## DISH Q10710162
- name: Upplandskubb
- description: Swedish traditional bread
- countries: SE
- kinds: bread, food
- has Wikipedia article: en

## DISH Q107111834
- name: Quark roll
- description: type of roll
- countries: (none)
- kinds: bread roll
- ingredients: chocolate chip, quark, raisin

## DISH Q10711327
- name: Huitlacoche
- other names: {"zh": "食用玉米黑粉菌"}
- description: Mexican delicacy
- countries: MX
- kinds: cultivated mushroom, edible mushroom, smut

## DISH Q107123836
- name: Beitzah
- other names: {"de": "Beitzah"}
- countries: (none)
- kinds: dish

## DISH Q107123837
- name: Chaseret
- other names: {"de": "Chaseret"}
- countries: (none)
- kinds: dish

## DISH Q1071353
- name: Chevrotin
- description: French cheese
- countries: FR
- kinds: French cheese, goat cheese, raw-milk cheese, pressed uncooked cheese, farmstead cheese
- ingredients: goat milk, raw milk
- has Wikipedia article: en

## DISH Q107144689
- name: Kokis
- description: Sri Lankan food
- countries: (none)
- kinds: Achappam
- has Wikipedia article: en

## DISH Q107148053
- name: Aam kasundi murgi
- description: Bengali cuisine
- countries: (none)
- kinds: chicken dish

## DISH Q107148175
- name: Ilish machher kumro diye jhol
- description: Bengali cuisine
- countries: (none)
- kinds: ilish dish, Jhol

## DISH Q107148885
- name: Shutki chingri bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish, Bhurta

## DISH Q107149162
- name: Magur machher rosha
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107149312
- name: Chingri mathar kalia
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q107149468
- name: Omelette er torkari
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q107149596
- name: Pui shaak diye masoor dal
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, lentil soup

## DISH Q107149604
- name: Mulo diye motor dal
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, lentil soup

## DISH Q107149615
- name: Ilish machher dim bhuna
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107149626
- name: Mete chorchori
- description: bengali cuisine
- countries: (none)
- kinds: charchari, chicken dish

## DISH Q10715213
- name: Vikabröd
- other names: {"nn": "Vikabröd"}
- countries: (none)
- kinds: crispbread

## DISH Q107158482
- name: Chips and salsa
- description: appetizer
- countries: (none)
- kinds: dish
- ingredients: salsa (food), tortilla chip

## DISH Q1071614
- name: Cheonggukjang
- other names: {"zh": "淸麴醬"}
- description: Korean seasoning
- countries: KR
- cuisines: Korean cuisine
- kinds: fermented bean paste
- ingredients: soy bean
- has Wikipedia article: en

## DISH Q10716336
- name: Hvitløkssild
- other names: {"nb": "Hvitløkssild"}
- countries: (none)
- kinds: pickled herring

## DISH Q1071699
- name: Jeongol
- other names: {"zh": "韓式火鍋"}
- description: Korean hot pot
- countries: (none)
- kinds: food, soup
- ingredients: condiment, edible mushroom, broth, seafood, beef, vegetable
- has Wikipedia article: en, zh

## DISH Q107174355
- name: Gregada
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q107175849
- name: Altoona-style pizza
- description: pizza style from Altoona, Pennsylvania, US, consisting of a Sicilian-style dough topped wtih tomato sauce, green bell pepper, salami and American cheese that is cut into squares
- countries: US
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q1071808
- name: Chicago-style pizza
- other names: {"zh": "芝加哥披薩"}
- description: styles of pizza developed in Chicago, including deep-dish pizza
- countries: US
- cuisines: cuisine of the United States
- kinds: type of pizza
- ingredients: tomato sauce, dough, cheese
- has Wikipedia article: en, zh

## DISH Q107203498
- name: Capoun
- description: green cabbage stuffed culinary specialty of Nice, France
- countries: FR
- kinds: dish, cabbage roll
- ingredients: Petit Salé, ham, Parmesan, Brassica oleracea, egg as food, parsley, rice

## DISH Q107203521
- name: Trouchia
- other names: {"fr": "trouchia"}
- countries: FR
- cuisines: cuisine niçoise
- kinds: omelette
- ingredients: chicken egg, chard

## DISH Q107204227
- name: Suomimakkara
- other names: {"fi": "suomimakkara"}
- countries: (none)
- kinds: dish

## DISH Q1072093
- name: Military chocolate
- other names: {"zh": "美国军用巧克力"}
- description: part of standard the United States military ration
- countries: US
- kinds: food, chocolate, emergency ration
- has Wikipedia article: en, zh

## DISH Q107213541
- name: Vollkornbrötchen
- other names: {"de": "Vollkornbrötchen"}
- countries: (none)
- kinds: bread roll

## DISH Q1072190
- name: Chicken nugget
- other names: {"zh": "雞塊"}
- description: chicken product made from chicken meat that is breaded or battered, then deep-fried or baked
- countries: US
- cuisines: cuisine of the United States
- kinds: chicken dish
- ingredients: chicken as food, bread crumbs, batter
- has Wikipedia article: en, zh

## DISH Q10722961
- name: Xohol
- description: Mexican dessert
- countries: MX
- kinds: dessert
- ingredients: cornmeal, coconut, cinnamon

## DISH Q10723494
- name: Yemas de San Cristóbal
- other names: {"sv": "Yemas de San Cristóbal"}
- countries: (none)
- kinds: dessert

## DISH Q107246621
- name: Goat's trotters
- description: feet of goat
- countries: (none)
- kinds: foot, goat meat, food ingredient, offal

## DISH Q107246736
- name: Roe pancake
- description: pancake made from roe
- countries: (none)
- kinds: food ingredient, pancake

## DISH Q10725547
- name: Äggakaka
- description: Traditional south-Swedish pancake dish with pork
- countries: SE
- kinds: dish
- ingredients: wheat flour, apple sauce, pork, Vaccinium vitis-idaea, egg as food, milk, apple
- has Wikipedia article: en

## DISH Q10725554
- name: Äggost
- description: type of cheese based on milk and eggs that is eaten on festive occasions in Sweden
- countries: SE
- cuisines: Swedish cuisine
- kinds: dish, dessert, egg dish

## DISH Q107262039
- name: Pepper bread
- description: historical sauce ingredient: hard-baked, ground bread or spiced cake (gingerbread precursor) used to thicken pepper sauces; not bread seasoned with pepper
- countries: (none)
- kinds: food ingredient, Western confection

## DISH Q107262073
- name: Rye bread crust
- description: crust of rye bread
- countries: (none)
- kinds: food ingredient, rye bread

## DISH Q10726534
- name: Ångbåtsbiff
- other names: {"sv": "ångbåtsbiff"}
- countries: (none)
- kinds: dish

## DISH Q107285110
- name: Natorer luchir payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107285115
- name: Lau diye tetor dal
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, lentil soup

## DISH Q107285128
- name: Sorshe potol
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286601
- name: Murgi monohora
- description: Bengali cuisine
- countries: (none)
- kinds: chicken dish

## DISH Q107286602
- name: Lonka bhapa murgi
- description: Bengali cuisine
- countries: (none)
- kinds: chicken dish

## DISH Q107286603
- name: Pepe dolma
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286605
- name: Kakrar jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q107286606
- name: Mourala machher peyaji
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286607
- name: Aam potol
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286608
- name: Shapla chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q107286609
- name: Sheem bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q107286610
- name: Kancha tomator jhal
- description: Bengali cuisine
- countries: (none)
- kinds: Jhal

## DISH Q107286611
- name: Lonka pora katla
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286615
- name: Rui machher bhuna
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286616
- name: Doi begun
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286617
- name: Posto bhapa
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286618
- name: Sorshe narkel murgi
- description: Bengali cuisine
- countries: (none)
- kinds: chicken dish

## DISH Q107286619
- name: Fulkopir dantar chorchori
- description: bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q107286620
- name: Ilish machher tok
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286621
- name: Machher tel er chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q107286622
- name: Bhetki begum bahar
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286623
- name: Pangas machher alu tomato diye jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107286624
- name: Hing pabda
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286625
- name: Doi tomato bhetki
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286626
- name: Kajoli machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q107286627
- name: Sheem alu diye rui machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107286628
- name: Bhindi sorshe
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286629
- name: Thakurbarir dudh katla
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286631
- name: Chapor ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q107286632
- name: Machher pur vora potoler dolma
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286633
- name: Boal machh bhapa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q107286634
- name: Ol chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q107286635
- name: Kadaknath murgir jhol
- description: Bengali cuisine
- countries: (none)
- kinds: chicken dish

## DISH Q107286636
- name: Aam shole machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286638
- name: Doi shol machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286639
- name: Tetul pata makha
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286640
- name: Kancha lau pata bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286641
- name: Aam diye mourala machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286642
- name: Korolar dolma
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286643
- name: Ritha machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286644
- name: Shol machher matha diye enchor er torkari
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286645
- name: Dhonepata bata diye mulo sheem alu chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q107286646
- name: Kasundi ilish
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286648
- name: Ilish machh kancha kolar jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107286649
- name: Roshun sorshe rui machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107286650
- name: Lau patay koi machh bhapa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhapa

## DISH Q107286651
- name: Kancha kola diye magur machher jhol
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107286652
- name: Deshi kakrar tok
- description: Bengali cuisine
- countries: (none)
- kinds: crab dish, Ambal

## DISH Q107286653
- name: Lau patar bora
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286654
- name: Begun diye kajoli machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107286655
- name: Lau patay musoor dal bhapa
- description: Bengali cuisine
- countries: (none)
- kinds: Bhapa

## DISH Q107286663
- name: Ol pora bata
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286664
- name: Chal kumro patar bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q107286665
- name: Beguner malaikari
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286666
- name: Maan kochu diye shol machher jhol
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107286667
- name: Achari tel ilish
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286668
- name: Puti machher tok
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286669
- name: Mulo fuler bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q107286670
- name: Fulkopi diye magur machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286672
- name: Pepe diye shol machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107286673
- name: Laytha machh diye palong shaak
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107286675
- name: Amra makha
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107286677
- name: Hanser dim begun diye jhol
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q107286678
- name: Laytha machh bhapa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q107286679
- name: Koi machh bhapa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q107287406
- name: Bele machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q107287437
- name: Bele machher patla jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107287449
- name: Bele machher sorshe jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q107287463
- name: Chhoto bele machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q107289424
- name: Soup
- description: western-style soup
- countries: (none)
- kinds: soup

## DISH Q107290304
- name: Hot bar
- countries: (none)
- kinds: street food

## DISH Q107292775
- name: Yaroa
- description: cuisine of Dominican Republic
- countries: (none)
- cuisines: Dominican Republic cuisine
- kinds: dish
- ingredients: condiment, root vegetable, meat, cheese
- has Wikipedia article: en

## DISH Q1073041
- name: Coconut bar
- other names: {"zh": "椰汁糕"}
- description: white, chilled, gelatinous southern Chinese dessert
- countries: CN
- kinds: dessert, pastry
- ingredients: coconut
- has Wikipedia article: en, zh

## DISH Q107304125
- name: Stuffed cucumber
- description: Ingredient and dish
- countries: (none)
- kinds: stuffed vegetable
- has Wikipedia article: en

## DISH Q107304811
- name: Soup and bouilli
- description: English dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q107308168
- name: Vepřo knedlo zelo
- description: Czech national dish
- countries: CZ
- kinds: dish
- has Wikipedia article: en

## DISH Q1073115
- name: Dasik
- description: Korean dessert
- countries: (none)
- kinds: hangwa
- ingredients: starch
- has Wikipedia article: en

## DISH Q1073156
- name: Baekkimchi
- other names: {"zh": "白泡菜"}
- description: kimchi made without the chili pepper powder
- countries: (none)
- kinds: Kimchi
- ingredients: Brassica rapa subsp. chinensis
- has Wikipedia article: en

## DISH Q1073174
- name: Jeotgal
- description: Korean salted seafood category
- countries: (none)
- kinds: seafood dish, fermented seafood
- ingredients: seafood
- has Wikipedia article: en

## DISH Q107323860
- name: Party submarine sandwich
- description: extremely long sandwich for catering purposes
- countries: (none)
- kinds: submarine sandwich
- has Wikipedia article: en

## DISH Q107328806
- name: Fried whitefish
- countries: (none)
- kinds: food, fried fish
- ingredients: whitefish
- has Wikipedia article: en

## DISH Q107330963
- name: Brizza
- countries: (none)
- kinds: pretzel

## DISH Q107337960
- name: Kıvratma
- description: Turkish dessert, common to the Central Black Sea Region
- countries: TR
- kinds: dessert, traditional food
- ingredients: white sugar, wheat flour, cooking oil, egg as food, yogurt

## DISH Q107345998
- name: Umm Rgaigah
- description: Sudanese food
- countries: SD
- kinds: dish

## DISH Q107354109
- name: Firecake
- description: Bread Type
- countries: (none)
- kinds: quick bread
- has Wikipedia article: en

## DISH Q107356806
- name: Breadfruit Porridge
- description: Breadfruit Porridge(Ukwa) is the meal used to identify VIP at functions
- countries: NG
- kinds: dish, human food
- ingredients: breadfruit, palm oil

## DISH Q107356825
- name: Bambara nut pudding
- description: traditional Nigerian food made with bambara nut
- countries: NG
- kinds: dish, human food

## DISH Q107356970
- name: Spicy cow foot
- description: native finger food made with cow foot, palm oil and spices
- countries: NG
- kinds: dish, meat dish, human food, meat and bone meal
- ingredients: Monodora myristica, onion, crayfish, palm oil, Capsicum, beef, Allium, salt, Capsicum annuum

## DISH Q107357035
- name: Abak atama soup
- description: special palm nut soup native to the Efiks/Ibibio people of Southern Nigeria
- countries: NG
- kinds: dish, human food

## DISH Q107357073
- name: Bambara groundnut
- description: Okpa is a delicious delicacy popular in the Eastern part of Nigeria, especially in Enugu state. Okpa has equally won the hearts of people in different parts of Nigeria and is now classified as a traditional Nigerian delicacy.
- countries: NG
- kinds: dish, human food, substance
- ingredients: peppercorn, hot water, cube, bean, palm oil

## DISH Q107357102
- name: Bole
- description: popular plantain delicacy peculiar to south south Nigerians
- countries: NG
- kinds: food

## DISH Q107357114
- name: Peeled Beans Porridge
- description: Nigerian delicacy made from bean seeds. It also serves as an alternative to Ukwa (Breadfruit), a delicacy from Eastern Nigeria.
- countries: NG
- kinds: dish, human food
- ingredients: onion, peppercorn, crayfish, bean, palm oil, table salt

## DISH Q107357232
- name: Gizdodo
- description: special Nigeria deliciacy which consists of peppered gizzard and plantain combination
- countries: NG
- kinds: dish, human food
- ingredients: Gizzard, cooking banana, onion, meat, Capsicum annuum, carrot
- has Wikipedia article: en

## DISH Q107357284
- name: Agidi
- description: Nigerian Agidi or Eko is a Nigeria food made with corn flour.
- countries: NG
- kinds: dish, human food
- ingredients: cornmeal, banana leaf, water
- has Wikipedia article: en

## DISH Q107357988
- name: Ofe Oha
- description: popular delicacy native to the Igbo people of eastern Nigeria and made from the African Rosewood plant
- countries: NG
- kinds: dish, food, soup
- ingredients: Pterocarpus mildbraedii, onion, cocoyam, Maggi, palm oil, stockfish, Capsicum, beef, chili pepper, salt, water
- has Wikipedia article: en

## DISH Q107358419
- name: Bobozee
- description: this is one Nigerian Snack that has so many names. Call it Bobozee, Abacha Mmiri, akpu mmiri, yucca/cassava chips, ...
- countries: NG
- kinds: dish, human food
- ingredients: cassava root, peanut, coconut

## DISH Q107358452
- name: Achicha Ede
- description: Achicha Ede is a traditional dish of cocoyam potage which originates from the Igbo region of Nigeria particularly Enugu.
- countries: NG
- kinds: dish, human food

## DISH Q107358460
- name: Abacha Ugba
- description: cassava-based dish mostly eaten by the Igbo tribe of Eastern Nigeria
- countries: NG
- kinds: dish, human food
- ingredients: cassava root, palm oil, table salt

## DISH Q107358554
- name: Ekpang Nkwukwo
- description: traditional delicacies of the Efiks and Ibibios culture of Nigeria
- countries: CM, NG
- kinds: dish, human food
- ingredients: water yam, onion, crayfish, palm oil, Catharanthus roseus, table salt, vegetable
- has Wikipedia article: en

## DISH Q107358567
- name: Ukpo Ogede
- description: Nigerian recipe prepared with over ripe plantains
- countries: NG
- kinds: dish, human food
- ingredients: cooking banana

## DISH Q107358598
- name: Oil Bean Soup
- description: Nigerian food from the Eastern region, specifically Owerri
- countries: NG
- kinds: dish, human food
- ingredients: seasoning, snail, stockfish, beef

## DISH Q107358723
- name: Okro soup
- description: African soup made with Okra vegetables cooked in a mixture of palm oil, shrimps, goat meat, fish and African spices
- countries: NG
- kinds: dish, human food, draw soup, substance, okra soup, sauce

## DISH Q107358749
- name: Egusi soup
- description: Nigerian soup made of grounded egusi and other ingredients.
- countries: NG
- kinds: dish, human food, soup
- ingredients: onion, peppercorn, Citrullus colocynthis, palm oil, beef, spice, table salt, vegetable, fish

## DISH Q107358770
- name: Achi Soup
- description: soup peculiar to Eastern Nigerians
- countries: NG
- kinds: dish, human food

## DISH Q107358782
- name: Urhobo Owho Soup
- description: yellowish delicacy mostly eaten by the Urhobos, Isoko, and Itsekiri people of Delta State in Nigeria
- countries: NG
- kinds: dish, human food

## DISH Q107358883
- name: African Salad
- description: West African dish made from boiled, shredded and dried cassava. It can be taken as a snack or as a main meal
- countries: NG
- kinds: food, dish, human food, substance
- ingredients: garden egg sauce, Oil Bean Soup, Ogiri, onion, peppercorn, crayfish as food, palm oil, table salt, vegetable
- has Wikipedia article: en

## DISH Q107358893
- name: Garri
- description: creamy-white, granular flour with a slightly fermented flavour and sour taste made from fermented cassava tubers
- countries: NG
- kinds: dish, human food
- ingredients: cassava root

## DISH Q107359030
- name: African breadfruit
- countries: NG
- kinds: food, substance
- ingredients: potash, peppercorn, cube, palm oil, salt, maize, fish

## DISH Q107364240
- name: African Rosewood plant
- description: Ora (Oha) soup is native to the South Eastern Nigeria. It is a very traditional soup similar to the bitterleaf soup but cooked with Ora leaves.
- countries: NG
- kinds: dish, human food

## DISH Q107365430
- name: Ofe achi
- description: Nigerian soup commonly prepared with a variety of vegetables
- countries: NG
- kinds: soup

## DISH Q107368588
- name: Unripe Plantain Porridge
- description: Unripe plantains are recommended by nutritionists as they contain less sugar and are healthier compared with ripe Plantains
- countries: NG
- kinds: dish, human food

## DISH Q107369606
- name: Köje
- other names: {"zh": "克缺"}
- description: Uyghur/Kyrgyz/Kazakh congee
- countries: KG, KZ, RU
- kinds: congee, dish

## DISH Q107370151
- name: Rosquilleta
- description: traditional Valencian food
- countries: (none)
- kinds: snack, breadstick, baked good
- ingredients: olive oil, flour, Pimpinella anisum, table salt, water

## DISH Q107387599
- name: Longganisa
- description: Philippine sausage
- countries: PH
- kinds: human food

## DISH Q107387621
- name: Longanisse
- description: French-Algerian sausage
- countries: FR
- cuisines: Pied-noir cuisine
- kinds: sausage

## DISH Q1073888
- name: Dried shredded squid
- other names: {"zh": "鱿鱼丝"}
- description: seafood product
- countries: (none)
- kinds: squid dish
- ingredients: dried squid
- has Wikipedia article: en, zh

## DISH Q107389580
- name: Polenta concia
- description: Italian polenta dish
- countries: IT
- kinds: dish
- ingredients: cheese

## DISH Q10740107
- name: Bim bim
- description: Snack made from flour and spices or nuts
- countries: VN
- kinds: snack
- ingredients: spice, flour, nut

## DISH Q107405732
- name: Sanga (Meal)
- description: a traditional meal from Cameroon made with fresh corn and vegetable
- countries: CM
- kinds: dish
- ingredients: palm oil, maize

## DISH Q1074136
- name: Lemon chicken
- other names: {"zh": "西柠鸡"}
- description: chicken dish
- countries: CN
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q107413898
- name: Brascada
- other names: {"ca": "Brascada"}
- countries: (none)
- kinds: bocadillo
- ingredients: onion, beef, ham

## DISH Q107414071
- name: Xivito
- countries: ES
- kinds: bocadillo
- ingredients: pork loin, Lactuca, mayonnaise, omelette, cheese

## DISH Q107414102
- name: المنصف (طبق)
- other names: {"ar": "المنصف (طبق)"}
- countries: (none)
- kinds: bocadillo
- ingredients: Sobrassada, onion, cheese

## DISH Q107414117
- name: Cowpea
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q107414363
- name: Ximet
- other names: {"ca": "Ximet"}
- countries: (none)
- kinds: bocadillo

## DISH Q107416756
- name: Beans and corn porridge
- description: popular Nigeria dish which is a combination of beans and corn
- countries: NG
- kinds: dish, human food
- ingredients: Pepper, onion, bean, palm oil, cooking banana, maize, table salt, water, fish
- has Wikipedia article: en

## DISH Q10742195
- name: Bánh bao, bánh vạc
- other names: {"zh": "白玫瑰饼"}
- description: Vietnamese dumpling
- countries: VN
- kinds: dumpling
- has Wikipedia article: en

## DISH Q10742199
- name: Bánh căn
- description: savory Vietnamese pancake
- countries: (none)
- kinds: pancake
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q10742203
- name: Bánh gai
- description: Vietnamese cake
- countries: (none)
- kinds: dessert, bánh

## DISH Q10742207
- name: Bánh giày
- description: Vietnamese snack
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: dish, bánh
- has Wikipedia article: en

## DISH Q10742208
- name: Bánh khúc
- other names: {"vi": "bánh khúc"}
- countries: VN
- cuisines: Northern Vietnamese cuisine
- kinds: xôi, bánh

## DISH Q10742209
- name: Bánh khảo
- countries: (none)
- kinds: dish, bánh

## DISH Q10742210
- name: Banh khot
- description: Vietnamese savory mini pancakes
- countries: (none)
- kinds: rice cake

## DISH Q10742230
- name: Bánh tôm
- description: Vietnamese seafood dish
- countries: (none)
- kinds: bánh, shrimp dish
- ingredients: sweet potato, shrimp and prawn as food

## DISH Q10742234
- name: Bánh đa cua
- description: Vietnamese noodle soup
- countries: VN
- kinds: noodle soup

## DISH Q10742235
- name: 餅𥹠𧹼
- countries: VN
- cuisines: Hải Phòng cuisine
- kinds: food ingredient, bánh

## DISH Q107424501
- name: Boli
- description: roasted plantain dish in Nigeria
- countries: (none)
- kinds: dish, human food
- ingredients: peanut, cooking banana, fish

## DISH Q10742887
- name: Bún bung
- other names: {"vi": "Bún bung"}
- description: dish from Hanoi and Thai Binh consisting of noodles and pork, onion, banana or bamboo broth
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: dish, soup
- ingredients: pork broth, banana flower, onion, noodle

## DISH Q10742893
- name: ブンモック
- other names: {"ja": "ブンモック"}
- countries: VN
- cuisines: Northern Vietnamese cuisine
- kinds: soup

## DISH Q10742896
- name: بون نوك لاو
- other names: {"ar": "بون نوك لاو"}
- countries: VN
- cuisines: Southern Vietnamese cuisine
- kinds: soup
- ingredients: rice vermicelli

## DISH Q10742901
- name: Bún đậu mắm tôm
- description: Vietnamese dish
- countries: VN
- cuisines: Northern Vietnamese cuisine
- kinds: dish
- ingredients: shrimp paste, rice vermicelli, tofu

## DISH Q107434730
- name: Rohkostsalat
- other names: {"de": "Rohkostsalat"}
- countries: (none)
- kinds: salad

## DISH Q107449555
- name: Tuwon dawa
- description: ground guinea-corn made thick and solid, eaten with soups like kuka and okra
- countries: NG
- kinds: dish, human food

## DISH Q107449597
- name: Miyan zogale
- description: soup made with moringa
- countries: NG
- kinds: soup
- ingredients: moringa

## DISH Q107449672
- name: Finger millet pap
- description: Tamba is a traditional Hausa name for Finger millet, also known as Eleusine corocana.It is a whole grain that is gluten-free and a good source.
- countries: NG
- kinds: human food, food, cup

## DISH Q107470450
- name: Sesame soup
- description: nutritional soup prepared mostly in the northern part of Nigeria
- countries: NG
- kinds: dish, human food

## DISH Q1074750
- name: Chiromeri
- other names: {"de": "Chiromeri"}
- countries: CY
- kinds: raw ham
- ingredients: pork thigh

## DISH Q107478431
- name: Dulce de frijol
- other names: {"es": "Dulce de frijol"}
- countries: MX
- kinds: food, dessert
- ingredients: panela, Phaseolus vulgaris, cinnamon, milk

## DISH Q107478595
- name: Poison beans
- description: traditional dish from Nuevo León
- countries: MX
- kinds: food, meal
- ingredients: garlic, chicharrón, onion, Phaseolus vulgaris

## DISH Q107478826
- name: Tostada Siberia
- description: regional Mexican dish
- countries: MX
- kinds: food
- has Wikipedia article: en

## DISH Q107478965
- name: Glorias de Linares
- description: typical Mexican sweet
- countries: MX
- kinds: food, confectionery
- ingredients: bicarbonate ion, Carya illinoinensis, cinnamon, sugar, milk

## DISH Q107479043
- name: Carne zaraza
- other names: {"es": "Carne zaraza"}
- countries: MX
- kinds: food

## DISH Q10748135
- name: Kelewele
- description: Ghanaian fried plantain dish with roasted groundnut
- countries: GH
- kinds: fried plantain, vegetable dish
- ingredients: cooking banana

## DISH Q10748166
- name: Cháo lòng
- description: Vietnamese porridge
- countries: VN
- kinds: congee
- ingredients: pork, rice
- has Wikipedia article: en

## DISH Q107486136
- name: Fura da nono (millet and milk)
- description: popular food in the Northern states especially in Sokoto state
- countries: NG
- kinds: dish, human food

## DISH Q107486466
- name: Yam porridge
- description: Nigerian yam dish cooked in a well-seasoned oil and pepper mix until soft and fluffy with some yam chunks. Sometimes fish and vegetable is added
- countries: NG
- kinds: dish, human food, food
- ingredients: Dioscorea
- has Wikipedia article: en

## DISH Q10748896
- name: Khorkhog
- other names: {"zh": "奶桶烤肉"}
- description: Mongolian dish
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en, zh

## DISH Q10748919
- name: Nanbanzuke
- description: Japanese fish dish
- countries: JP
- kinds: fish dish
- ingredients: karaage
- has Wikipedia article: en

## DISH Q107489664
- name: Amiwô
- description: Beninese porridge
- countries: BJ
- kinds: dish
- ingredients: maize flour, garlic, onion, tomato paste, palm oil
- has Wikipedia article: en

## DISH Q10749145
- name: Smulpaj
- description: Swedish dessert
- countries: SE
- kinds: dish, pie
- ingredients: butter
- has Wikipedia article: en

## DISH Q107498785
- name: Ossa di morto PAT
- other names: {"zh": "Ossa di morto PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: biscuit, baked good
- has Wikipedia article: en

## DISH Q10749957
- name: Sole meunière
- description: French fish dish
- countries: FR
- kinds: fish dish
- ingredients: common sole, potato
- has Wikipedia article: en

## DISH Q10751546
- name: Cà chấm mắm tôm
- other names: {"vi": "cà chấm mắm tôm"}
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: dish
- ingredients: Solanum macrocarpon, shrimp paste

## DISH Q10751991
- name: Sope
- description: Mexican street food
- countries: MX
- kinds: antojito
- has Wikipedia article: en

## DISH Q10752179
- name: Cơm bình dân
- other names: {"zh": "平民飯"}
- description: Vietnamese cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q10752219
- name: Suikerboon
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q10752894
- name: Elote
- description: ear of corn, as food, in Mexico and Central America
- countries: MX
- kinds: food, corn on the cob
- ingredients: maize, chili powder, butter, lime
- has Wikipedia article: en

## DISH Q107529419
- name: 乱歩せんべい「二銭銅貨」
- other names: {"ja": "乱歩せんべい「二銭銅貨」"}
- countries: (none)
- kinds: senbei

## DISH Q10753530
- name: Lechazo
- description: Spanish lamb dish
- countries: ES
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q1075430
- name: Gomguk
- other names: {"zh": "精熬牛骨汤"}
- description: Korean soup
- countries: (none)
- kinds: food, guk
- ingredients: beef
- has Wikipedia article: en

## DISH Q1075614
- name: Choco pie
- other names: {"zh": "巧克力派"}
- description: snack cake
- countries: (none)
- kinds: snack cake
- has Wikipedia article: en, zh

## DISH Q107569320
- name: Gulai udang kacang panjang
- other names: {"id": "gulai udang kacang panjang"}
- countries: (none)
- kinds: food, gulai
- ingredients: Garcinia xanthochymus fruit, turmeric leaf, asparagus bean, shallot, turmeric rhizome, garlic, ginger, coconut milk, chili pepper

## DISH Q107586753
- name: Kalojeera diye pabda machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107586963
- name: Dim Kosha
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q107587005
- name: Dim er mamlet dalna
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q107598863
- name: Meal deal
- description: main, drink and snack, often sold in UK supermarkets
- countries: (none)
- kinds: sales promotion, combination meal
- has Wikipedia article: en

## DISH Q107610602
- name: Oeuf mayonnaise
- description: French egg dish
- countries: (none)
- kinds: dish, hors-d'œuvre
- has Wikipedia article: en

## DISH Q107612492
- name: Miyabiya
- countries: (none)
- kinds: dish, yōshoku
- ingredients: shrimp and prawn as food, chicken as food, demi-glace, Lentinula edodes, onion

## DISH Q107625293
- name: Gefüllte Kohlrabi
- other names: {"de": "Gefüllte Kohlrabi"}
- countries: (none)
- kinds: dish

## DISH Q107636161
- name: Burrito bowl
- description: dish
- countries: US
- kinds: dish
- ingredients: burrito

## DISH Q107638016
- name: Lobster macaroni and cheese
- description: dish
- countries: (none)
- kinds: dish
- ingredients: lobster, macaroni and cheese

## DISH Q107639054
- name: Chicken burrito
- description: dish
- countries: MX
- kinds: dish
- ingredients: burrito, chicken

## DISH Q107645851
- name: Dombolo
- description: traditional South African steamed bread
- countries: ZA
- kinds: steamed bread
- has Wikipedia article: en

## DISH Q107657017
- name: Ol dantar ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q107657041
- name: Sorshe diye ol danta
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107657123
- name: Ol Saag Bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107657148
- name: Oler dantar chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q107657183
- name: Ol danta o kathal bij diye sorse bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
