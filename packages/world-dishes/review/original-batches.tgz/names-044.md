# Review batch names-044

## DISH Q4876267
- name: Bean salad
- description: salad
- countries: (none)
- kinds: salad, type of food or dish
- ingredients: bean
- has Wikipedia article: en

## DISH Q48763011
- name: 煮転がし
- other names: {"ja": "煮転がし"}
- countries: JP
- kinds: nimono

## DISH Q48767364
- name: Stuffed crust pizza
- other names: {"zh": "芝心披薩"}
- description: pizza with cheese or other toppings added into the crust
- countries: US
- kinds: type of pizza
- has Wikipedia article: en, zh

## DISH Q48767392
- name: Pain de mie
- other names: {"zh": "龐多米麵包"}
- description: sandwich bread
- countries: FR
- kinds: sandwich bread
- has Wikipedia article: en, zh

## DISH Q48767667
- name: Pan pizza
- description: pizza baked in a pan
- countries: US
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q48767872
- name: Onion cake
- description: savory or sweet cake prepared using onion as a primary ingredient
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q4877036
- name: Beaten biscuit
- description: type of biscuit
- countries: US
- kinds: food, biscuit
- ingredients: flour
- has Wikipedia article: en

## DISH Q48774226
- name: Pheasant under glass
- description: poultry dish consisting of the breast of pheasant with shallots in a reduced wine sauce
- countries: (none)
- kinds: dish, poultry dish
- has Wikipedia article: en

## DISH Q48780108
- name: Cipera
- description: Indonesian traditional dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: gulai, dish, human food, type of food or dish
- ingredients: chicken

## DISH Q48780422
- name: Féroce
- description: avocado dish with chillis etc
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q48781104
- name: Koe'sister
- description: traditional Cape Malay pastry
- countries: ZA
- kinds: doughnut
- ingredients: dough
- has Wikipedia article: en

## DISH Q48781446
- name: Otana
- other names: {"es": "Otana"}
- countries: ES
- kinds: bread
- ingredients: rye flour, wheat flour, sourdough, dough, salt

## DISH Q48781818
- name: Yemas de San Leandro
- countries: (none)
- kinds: confectionery

## DISH Q48792394
- name: Tartlet
- description: small pastry
- countries: FR
- kinds: tart, small pastry, finger food
- has Wikipedia article: en

## DISH Q4879252
- name: Bedfordshire clanger
- description: suet pastry
- countries: GB
- kinds: food, pie
- ingredients: suet
- has Wikipedia article: en

## DISH Q4879746
- name: Beef Manhattan
- description: Dish consisting of roast beef and gravy
- countries: US
- kinds: food, beef dish
- ingredients: beef, roast beef, gravy, mashed potato, bread
- has Wikipedia article: en

## DISH Q4879755
- name: Beef bun
- other names: {"zh": "牛肉包"}
- description: bun with beef filling
- countries: HK
- kinds: food, beef dish
- ingredients: ground beef, bread
- has Wikipedia article: en, zh

## DISH Q4879758
- name: Beef on weck
- other names: {"zh": "Weck三明治"}
- description: roast beef sandwich on a kummelweck roll
- countries: US
- kinds: sandwich
- ingredients: roast beef, bread roll, au jus, Armoracia rusticana
- has Wikipedia article: en

## DISH Q48801273
- name: Mustazzoleddus
- other names: {"it": "Mustazzoleddus"}
- countries: IT
- kinds: dessert

## DISH Q48804095
- name: Cevrin
- description: Goat's chees of Italy
- countries: IT
- kinds: cheese
- ingredients: goat milk

## DISH Q48804157
- name: Novellino
- other names: {"it": "Novellino"}
- countries: IT
- kinds: dessert

## DISH Q48804597
- name: Treccia mochena
- other names: {"it": "Treccia mochena"}
- countries: IT
- kinds: dessert

## DISH Q48804758
- name: Pasticcio caggianese PAT
- other names: {"zh": "Pasticcio caggianese PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- cuisines: campanian cuisine
- kinds: baked good, savoury pie

## DISH Q48806470
- name: Tortello fior di verza
- other names: {"it": "tortello fior di verza"}
- countries: (none)
- kinds: pasta dish

## DISH Q48807708
- name: Pan della Marchesa
- countries: IT
- kinds: dessert

## DISH Q48808067
- name: Pamparito
- other names: {"it": "Pamparito"}
- countries: (none)
- kinds: bread

## DISH Q48808634
- name: Bignolata mantovana
- other names: {"it": "Bignolata mantovana"}
- countries: IT
- kinds: dessert

## DISH Q48808777
- name: Vissinello
- other names: {"it": "Vissinello"}
- countries: IT
- kinds: dessert

## DISH Q48808894
- name: Fegatelli
- description: Italian dish of liver
- countries: (none)
- kinds: dish

## DISH Q48808905
- name: Pane coi santi
- description: Traditional Italian fruit bread
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q48808953
- name: Tortelli di zucca di Villanova de Bellis
- other names: {"it": "tortelli di zucca di Villanova de Bellis"}
- countries: (none)
- kinds: pasta dish
- ingredients: pumpkin tortelli

## DISH Q48809078
- name: Pizzichinu
- other names: {"it": "Pizzichinu"}
- countries: IT
- kinds: dessert

## DISH Q48809160
- name: Confetto riccio di Agnone
- other names: {"it": "Confetto riccio di Agnone"}
- countries: IT
- kinds: dessert

## DISH Q48811491
- name: Pane di Montecalvo PAT
- other names: {"zh": "Pane di Montecalvo PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: bread, baked good

## DISH Q4881235
- name: Beika
- other names: {"zh": "米果"}
- description: dry confectionery made out of rice
- countries: JP
- kinds: higashi
- ingredients: rice
- has Wikipedia article: en

## DISH Q48812916
- name: Caciocavallo di Castelfranco PAT
- other names: {"zh": "Caciocavallo di Castelfranco PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: caciocavallo, cow's-milk cheese, cheese
- ingredients: cow's milk, rennet, table salt

## DISH Q48813642
- name: Prosciutto di Faeto PAT
- other names: {"zh": "Prosciutto di Faeto PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product, raw ham

## DISH Q48814046
- name: Tortellino dolce di Marianna
- other names: {"it": "tortellino dolce di Marianna"}
- countries: (none)
- kinds: confectionery

## DISH Q48816551
- name: Pizza by the slice
- other names: {"zh": "切片披薩"}
- description: prepared slice of pizza
- countries: (none)
- kinds: street food
- has Wikipedia article: en, zh

## DISH Q4882157
- name: Belekoy
- description: Filipino delicacy
- countries: PH
- kinds: food, pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q4882503
- name: Belgian bun
- description: Sweet bun with sultanas and icing
- countries: (none)
- kinds: food, sweet roll
- ingredients: sultana
- has Wikipedia article: en

## DISH Q48832937
- name: Mantecados de Estepa
- description: Spanish cake
- countries: ES
- kinds: mantecado

## DISH Q48841040
- name: Katsu ika odori-don
- description: Japanese dish
- countries: (none)
- kinds: Kaisen-don
- has Wikipedia article: en

## DISH Q48852218
- name: Busiate
- description: type of pasta
- countries: IT
- cuisines: Sicilian cuisine
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q48852221
- name: Sedani
- description: type of pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q48853185
- name: Fileja
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: durum wheat semolina
- has Wikipedia article: en

## DISH Q48855094
- name: Brote
- other names: {"pt": "brote"}
- countries: BR
- kinds: food, bread

## DISH Q48865290
- name: Coal-fired pizza
- description: pizza cooked in a coal-fired pizza ovens reacing up to 482 °C, cooked for only 2–5 minutes
- countries: (none)
- has Wikipedia article: en

## DISH Q4886748
- name: Lobster stew
- description: Menorcan dish of lobster, sofrito, onions, tomatoes, garlic and parsley
- countries: ES
- kinds: food, soup
- ingredients: lobster
- has Wikipedia article: en

## DISH Q48876884
- name: Filé a JK
- other names: {"pt": "filé a JK"}
- countries: (none)
- kinds: dish

## DISH Q48877725
- name: Cuzcuz Paulista
- description: Brazilian dish
- countries: BR
- cuisines: Brazilian cuisine, Caipira cuisine
- kinds: dish

## DISH Q4887922
- name: Pepes
- other names: {"zh": "皮皮斯"}
- description: Indonesia dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish
- ingredients: turmeric, ginger, fish as food, Alpinia galanga
- has Wikipedia article: en

## DISH Q48880901
- name: Bánh đậu xanh
- other names: {"zh": "綠豆糕"}
- description: Vietnamese and Chinese pastry
- countries: VN
- kinds: finger food, bánh, dish
- has Wikipedia article: en, zh

## DISH Q4891611
- name: Berger Cookies
- description: german-American cookie
- countries: (none)
- kinds: cookie, food product
- has Wikipedia article: en

## DISH Q48916161
- name: Tshài-bué-thng
- other names: {"zh": "菜尾湯"}
- description: Traditional Taiwanese stew made with leftover banquet dishes
- countries: MY, TW
- cuisines: Chinese cuisine
- kinds: soup, stew
- ingredients: dried chili pepper, Garcinia atroviridis, leftovers, Brassica juncea
- has Wikipedia article: en, zh

## DISH Q4891863
- name: Sancoche
- description: traditional soup in several Latin American cuisines
- countries: (none)
- kinds: food, soup, meat dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q4892695
- name: Bermuda fish chowder
- description: Bermuda chowder soup
- countries: BM
- kinds: fish soup, fish dish
- ingredients: fish as food
- has Wikipedia article: en

## DISH Q48927763
- name: Shrimp rice
- other names: {"zh": "蝦仁飯"}
- description: Taiwanese shrimp rice dish
- countries: (none)
- kinds: rice dish
- has Wikipedia article: zh

## DISH Q4892972
- name: Gyūtan
- other names: {"zh": "仙台牛舌"}
- description: Japanese dish made from beef tongue
- countries: JP
- kinds: beef dish, type of food or dish
- ingredients: beef tongue
- has Wikipedia article: en

## DISH Q48935221
- name: Red peach cake
- other names: {"zh": "红桃粿"}
- description: Chinese pastry usually eaten during significant occasions
- countries: (none)
- kinds: food
- has Wikipedia article: en, zh

## DISH Q48941010
- name: Лапшевник
- other names: {"ru": "Лапшевник"}
- countries: RU
- cuisines: Russian cuisine
- kinds: casserole
- ingredients: flour, water

## DISH Q4894109
- name: Berner Honiglebkuchen
- description: Culinary specialty of Bern, Switzerland
- countries: CH
- kinds: lebkuchen
- ingredients: flour
- has Wikipedia article: en

## DISH Q48965290
- name: Swabian Spätzle
- description: swabian or Alemannic pasta
- countries: DE
- kinds: spätzle
- has Wikipedia article: en

## DISH Q489703
- name: Red beans and rice
- other names: {"zh": "紅豆飯"}
- description: dish characteristic of Louisiana Creole cuisine
- countries: US
- cuisines: soul food, Louisiana Creole cuisine, Cuisine of New Orleans
- kinds: rice and beans, dish
- ingredients: kidney bean, Pickled meat snack, rice
- has Wikipedia article: en

## DISH Q4897051
- name: Croquants
- description: sweet pastry with almonds
- countries: (none)
- kinds: biscuit

## DISH Q4897474
- name: Pa amb oli
- other names: {"ca": "pa amb oli"}
- countries: (none)
- kinds: dish
- ingredients: oil, bread

## DISH Q48976623
- name: Cube toast
- description: dessert dish
- countries: (none)
- kinds: dish

## DISH Q48988376
- name: Cheese cracker
- description: type of cracker
- countries: (none)
- kinds: cracker
- has Wikipedia article: en

## DISH Q4899060
- name: Betutu
- description: Balinese roasted chicken and duck made with betutu spice mix
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish
- ingredients: garlic, onion, chicken as food, oil, lime, table salt
- has Wikipedia article: en

## DISH Q48998769
- name: Stuffed bitter melon soup
- description: Vietnamese soup
- countries: VN
- kinds: soup
- ingredients: Momordica charantia
- has Wikipedia article: en

## DISH Q49001494
- name: Dragon's Breath
- description: Cereal frozen in liquid nitrogen
- countries: (none)
- kinds: dessert
- ingredients: liquid nitrogen, breakfast cereal
- has Wikipedia article: en

## DISH Q4900263
- name: Beyti
- description: Turkish meat dish
- countries: (none)
- kinds: lamb dish, bread dish, beef dish
- ingredients: yufka bread, lamb meat
- has Wikipedia article: en

## DISH Q4902207
- name: Bhurta
- description: fried mixture of mashed vegetables
- countries: (none)
- kinds: vegetable dish
- has Wikipedia article: en

## DISH Q4903057
- name: Bibingka
- other names: {"zh": "比賓卡"}
- description: baked rice cake from Indonesia and Philippines
- countries: ID
- kinds: Binalot
- ingredients: rice flour
- has Wikipedia article: en, zh

## DISH Q49046686
- name: Goroke
- description: Korean style Croquette
- countries: KR
- kinds: potato dish

## DISH Q4904727
- name: Bife a cavalo
- description: traditional dish in Portugal and Brazil, consisting of a grilled, sometimes deep fried steak, with fried eggs on top
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q49053694
- name: Mắm ruốc
- other names: {"vi": "mắm ruốc"}
- countries: (none)
- kinds: shrimp paste, condiment
- ingredients: Acetes

## DISH Q4907305
- name: Bika Ambon
- other names: {"zh": "黃金糕"}
- description: traditional Indonesian cake originating from Medan made from tapioca flour
- countries: ID
- cuisines: Indonesian cuisine
- kinds: sweetmeat, human food, type of food or dish, dish, cake, dessert, snack
- ingredients: coconut, fermentation starter, hot water, coconut milk, cooking oil, Pandanus amaryllifolius, egg as food, flour, table salt, sugar, margarine, Kaffir Lime Leaf, sago flour, turmeric rhizome
- has Wikipedia article: en, zh

## DISH Q490759
- name: Beondegi
- other names: {"zh": "蠶蛹"}
- description: cooked silkworm pupae
- countries: (none)
- kinds: snack, street food
- ingredients: Bombyx mori
- has Wikipedia article: en, zh

## DISH Q49077107
- name: Futomaki
- countries: (none)
- kinds: makizushi

## DISH Q49095039
- name: Pono
- other names: {"sv": "Pono"}
- countries: FI
- cuisines: Finnish cuisine
- ingredients: filmjölk, sodium bicarbonate

## DISH Q491222
- name: Tucupi
- description: sauce used in Brazilian cuisine, extracted from the Cassava root
- countries: BR
- kinds: sauce
- ingredients: cassava root
- has Wikipedia article: en

## DISH Q4913849
- name: Binalot
- description: technique in Filipino cuisine
- countries: PH
- kinds: rice dish
- has Wikipedia article: en

## DISH Q4914153
- name: Bing guo
- description: Dessert in Beijing cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q4914380
- name: Binignit
- description: Visayan dessert soup
- countries: PH
- kinds: food, soup
- ingredients: coconut milk
- has Wikipedia article: en

## DISH Q4916959
- name: Birria
- other names: {"zh": "墨西哥炖肉"}
- description: dish
- countries: MX
- kinds: food, goat meat dish
- has Wikipedia article: en, zh

## DISH Q4917270
- name: Biscuit Tortoni
- description: Italian frozen dairy dessert
- countries: IT
- kinds: food, ice cream
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q4917272
- name: Biscuit
- other names: {"zh": "比司吉麵包"}
- description: North American quick bread (not the same as a cookie)
- countries: US
- kinds: quick bread
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q4918187
- name: Biskotso
- description: type of Filipino twice-baked bread
- countries: PH
- kinds: food, bread
- has Wikipedia article: en

## DISH Q4918497
- name: Bistec de Palomilla
- description: Cuban dish
- countries: CU
- kinds: beef dish
- ingredients: beefsteak
- has Wikipedia article: en

## DISH Q4918498
- name: Bistek
- description: Spanish dish
- countries: PH
- kinds: food, beef dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q4918871
- name: Budu
- other names: {"zh": "吉兰丹鱼酱"}
- description: Fish sauce originating from Kelantan
- countries: MY
- kinds: fish sauce, condiment
- ingredients: Engraulidae
- has Wikipedia article: en

## DISH Q4919380
- name: Bizcocho (Uruguay)
- description: pastry, cake or cookie.
- countries: (none)
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q4920036
- name: Blachindla
- countries: RO
- kinds: food, turnover
- has Wikipedia article: en

## DISH Q4920451
- name: Black Bullets
- description: confectionery
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q4920553
- name: Nasi ulam
- other names: {"zh": "乌蓝饭"}
- description: Indonesian and Malaysian rice dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, rice dish
- ingredients: Holy Basil, cooked rice, Centella asiatica
- has Wikipedia article: en

## DISH Q4921064
- name: Black Jack
- description: confectionery
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q4921072
- name: Âng-ku-kóe
- other names: {"zh": "红龟粿"}
- description: Chinese pastry usually eaten during significant occasions
- countries: (none)
- kinds: food
- ingredients: peanut, Vigna radiata, glutinous rice, Sweet potato, sugar
- has Wikipedia article: en, zh

## DISH Q4922265
- name: Black bean paste
- other names: {"zh": "黑豆沙"}
- description: type of sweet bean paste
- countries: (none)
- kinds: sweet bean paste
- has Wikipedia article: en, zh

## DISH Q4922403
- name: Black noodles
- description: type of Polish potato dumplings
- countries: (none)
- kinds: noodle, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q4922421
- name: Black pepper crab
- other names: {"zh": "黑胡椒蟹"}
- description: Singaporean dish consisting of crab fried with black pepper
- countries: SG
- kinds: seafood dish, crab dish
- has Wikipedia article: en, zh

## DISH Q4922468
- name: Black sesame rice cake
- description: Chinese traditional cake
- countries: CN
- kinds: pudding
- ingredients: white rice
- has Wikipedia article: en

## DISH Q4922489
- name: Khao phat
- other names: {"zh": "泰式炒饭"}
- description: Thai fried rice
- countries: TH
- cuisines: Thai cuisine
- kinds: fried rice
- ingredients: cooked rice
- has Wikipedia article: en, zh

## DISH Q4922798
- name: Blackening
- description: cooking technique
- countries: (none)
- kinds: fish dish, food preparation technique
- has Wikipedia article: en

## DISH Q4922950
- name: Khao soi
- other names: {"zh": "金面"}
- description: Thai noodle soup
- countries: TH, MM, LA
- cuisines: Thai cuisine, Burmese cuisine, Lao cuisine
- kinds: noodle soup
- has Wikipedia article: en, zh

## DISH Q4923638
- name: Nam tok
- other names: {"zh": "泰式辣血湯"}
- description: Southeast Asian soup or meat salad
- countries: TH, LA
- cuisines: Thai cuisine, Lao cuisine
- kinds: salad
- has Wikipedia article: en

## DISH Q4923744
- name: Nasi goreng pattaya
- description: Thailand rice dish
- countries: MY
- kinds: fried rice, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q4924455
- name: Dodol
- other names: {"zh": "dodol"}
- description: Indonesian sweet toffee
- countries: ID
- kinds: confectionery
- ingredients: brown sugar, coconut milk, Pandanus amaryllifolius, glutinous rice, table salt, sugar
- has Wikipedia article: en

## DISH Q4925764
- name: Chuối chiên
- description: Vietnamese fried banana
- countries: VN
- kinds: banana dish
- ingredients: banana

## DISH Q4926371
- name: Khao poon
- other names: {"zh": "考蓬"}
- description: southeast Asian noodle dish originating from Laos
- countries: LA
- kinds: food, soup
- ingredients: rice vermicelli
- has Wikipedia article: en

## DISH Q4926393
- name: Bleu Bénédictin
- description: Canadian blue cheese
- countries: (none)
- kinds: blue cheese, cheese from Quebec
- ingredients: milk
- has Wikipedia article: en

## DISH Q492642
- name: Kai yang
- other names: {"zh": "泰式烤雞"}
- description: grilled chicken
- countries: LA
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q4927055
- name: Bloater
- description: whole herring, lightly salted and briefly smoked
- countries: (none)
- kinds: smoked fish, fish dish
- has Wikipedia article: en

## DISH Q4927898
- name: Blood soup
- description: soup that uses blood as a principal ingredient
- countries: (none)
- kinds: food, soup
- ingredients: blood as food, blood
- has Wikipedia article: en

## DISH Q4929458
- name: Blue moon
- description: ice cream flavor
- countries: (none)
- kinds: ice cream, ice cream flavor
- has Wikipedia article: en

## DISH Q4931669
- name: Bob Andy pie
- countries: US
- kinds: food, pie
- ingredients: egg as food

## DISH Q493749
- name: Rødgrød
- description: Danish/German dessert
- countries: DK
- cuisines: Swedish cuisine, German cuisine, Danish cuisine
- kinds: frugtgrød, food
- ingredients: berry, vanilla sauce, potato starch
- has Wikipedia article: en

## DISH Q493784
- name: Bingsu
- other names: {"zh": "冰酥"}
- description: Korean shaved ice dessert with sweet toppings
- countries: (none)
- kinds: shaved ice, sweet dish
- ingredients: Vigna angularis
- has Wikipedia article: en

## DISH Q4938317
- name: Bile up
- description: cultural dish of the Kriols of Belize
- countries: (none)
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q4938329
- name: Boiled beef
- description: traditional English dish
- countries: GB
- kinds: beef, dish, beef dish
- has Wikipedia article: en

## DISH Q4938791
- name: Bokkoms
- description: whole, salted and dried mullet
- countries: ZA
- kinds: cured fish
- has Wikipedia article: en

## DISH Q4938933
- name: Bolani
- other names: {"zh": "波拉尼"}
- description: flat-bread from Afghanistan
- countries: AF
- kinds: food, flatbread
- has Wikipedia article: en, zh

## DISH Q4939431
- name: Boliche
- description: Stuffed pot roast from Cuban cuisine
- countries: CU
- kinds: meat dish
- has Wikipedia article: en

## DISH Q4939444
- name: Bolillo
- description: small baguette-like bread from Mexico
- countries: MX
- kinds: French roll, Mexican bread
- has Wikipedia article: en

## DISH Q4939470
- name: Bolinhos de mandioca com mel
- description: traditional Cape Verdean dish
- countries: CV
- kinds: food
- ingredients: molasses, egg as food, water
- has Wikipedia article: en

## DISH Q4939975
- name: Bologna sandwich
- other names: {"zh": "博洛尼亚三明治"}
- description: North American sandwich variety
- countries: US
- kinds: sandwich, type of food or dish
- ingredients: white bread, bologna
- has Wikipedia article: en

## DISH Q4940616
- name: Bombe glacée
- description: type of French ice cream dessert
- countries: FR
- kinds: ice cream-based dessert, dessert
- ingredients: ice cream
- has Wikipedia article: en

## DISH Q4940768
- name: Bombolone
- description: Italian filled doughnut
- countries: IT
- cuisines: Italian cuisine
- kinds: food, doughnut
- has Wikipedia article: en

## DISH Q4941719
- name: Boneless Fish
- description: fish that has been scaled, gutted and deboned before being reassembled to look like a dressed fish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q4943588
- name: Boondi
- description: Sweets
- countries: IN
- kinds: confectionery
- ingredients: besan, sugar, water
- has Wikipedia article: en

## DISH Q4944137
- name: Booza
- description: ice cream, commonly found in the Levant, known for its elastic texture and resistance to melting, made with orchid tuber flour (salep/sahlab)
- countries: SY
- kinds: ice cream
- ingredients: salep, milk
- has Wikipedia article: en

## DISH Q4944190
- name: Bopis
- description: Filipino dish
- countries: PH
- kinds: offal dish
- has Wikipedia article: en

## DISH Q4944265
- name: Bora saul
- description: type of sticky rice
- countries: IN
- kinds: rice
- has Wikipedia article: en

## DISH Q4947090
- name: Borş de burechiuşe
- description: Romanian and Moldovan dish
- countries: RO
- kinds: food, soup
- has Wikipedia article: en

## DISH Q4948232
- name: Boston bun
- description: Sweet roll woth spices and thick icing
- countries: AU
- kinds: food, spiced bun
- has Wikipedia article: en

## DISH Q4948235
- name: Boston cream doughnut
- other names: {"zh": "波士頓奶油甜甜圈"}
- description: Doughnut dessert
- countries: US
- kinds: doughnut
- has Wikipedia article: en, zh

## DISH Q4950113
- name: Bourbon chicken
- description: dish made with bourbon whiskey
- countries: US
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q4950130
- name: Bourdeto
- description: fish dish from Corfu
- countries: GR
- kinds: fish dish
- has Wikipedia article: en

## DISH Q4959183
- name: Bread and butter pudding
- description: Traditional sweet British pudding
- countries: GB
- kinds: pudding
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q4959186
- name: Bread bowl
- other names: {"zh": "棺材板"}
- description: filled bread dish
- countries: (none)
- kinds: dish, loaf, edible tableware
- ingredients: bread
- has Wikipedia article: en

## DISH Q4959488
- name: Breakfast roll
- other names: {"zh": "早餐麵包捲"}
- description: Irish sandwich
- countries: IE
- kinds: food, sandwich
- ingredients: Irish breakfast, bread roll
- has Wikipedia article: en, zh

## DISH Q4959490
- name: Breakfast sandwich
- other names: {"zh": "早餐三明治"}
- description: type of sandwich
- countries: US
- kinds: sandwich
- ingredients: bread
- has Wikipedia article: en

## DISH Q4966940
- name: Bridie
- description: Scottish meat pastry
- countries: (none)
- kinds: food, meat pie
- has Wikipedia article: en

## DISH Q4968516
- name: Briouat
- description: Moroccan traditional pastry
- countries: MA
- kinds: pastry, food
- has Wikipedia article: en

## DISH Q496999
- name: Hotteok
- other names: {"zh": "韩式糖饼"}
- description: Korean snack food
- countries: (none)
- cuisines: Korean Chinese cuisine
- kinds: pancake, dish
- has Wikipedia article: en

## DISH Q4971792
- name: Broa de Avintes
- description: bread of Avintes
- countries: PT
- kinds: bread, baked good
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q49737
- name: Cotton candy
- other names: {"zh": "棉花糖"}
- description: confectionery
- countries: (none)
- kinds: sugar candy
- ingredients: sugar
- has Wikipedia article: en, zh

## DISH Q4975393
- name: Brose
- description: type of porridge
- countries: (none)
- kinds: food
- has Wikipedia article: en

## DISH Q4976066
- name: Brown Betty
- description: dessert typically made with apples
- countries: US
- cuisines: cuisine of the United States
- kinds: pudding, crumble
- ingredients: bread crumbs, zest, sugar, apple
- has Wikipedia article: en

## DISH Q4976072
- name: Brown Bobby
- description: type of donut
- countries: US
- kinds: doughnut
- has Wikipedia article: en

## DISH Q4976354
- name: Brown Windsor soup
- description: British soup
- countries: GB
- cuisines: English cuisine
- kinds: soup, dish
- ingredients: Oryza, lamb meat, broth, noodle, carrot
- has Wikipedia article: en

## DISH Q4979804
- name: Brussels cookies
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q4982700
- name: Bucheron
- description: type of cheese
- countries: FR
- kinds: French cheese
- ingredients: goat milk
- has Wikipedia article: en

## DISH Q4983108
- name: Buckeye candy
- description: chocolate-covered peanut butter candy
- countries: US
- kinds: confectionery
- ingredients: peanut, butter, chocolate
- has Wikipedia article: en

## DISH Q4983569
- name: Buckwheat gateau
- description: German dessert
- countries: DE
- kinds: torte
- ingredients: buckwheat seed
- has Wikipedia article: en

## DISH Q4985915
- name: Buffalo burger
- description: hamburgers made with meat from the American bison
- countries: (none)
- kinds: hamburger
- ingredients: bison meat, American bison
- has Wikipedia article: en

## DISH Q4986123
- name: Bugak
- description: deep fried vegetables and seaweeds
- countries: (none)
- kinds: fritter
- has Wikipedia article: en

## DISH Q4986776
- name: Bujta repa
- description: Slovenian pork dish
- countries: (none)
- kinds: pork dish, Slovenian cuisine
- has Wikipedia article: en

## DISH Q4986986
- name: Bukkumi
- other names: {"zh": "煎豆包"}
- description: korean-cuisine pan-fried rice cake
- countries: (none)
- kinds: tteok
- has Wikipedia article: en

## DISH Q4987202
- name: Bulalo
- description: beef dish from the Philippines
- countries: PH
- kinds: food, beef dish
- ingredients: beef
- has Wikipedia article: en

## DISH Q4992035
- name: Pålægschokolade
- description: thin sheets of chocolate to put on bread
- countries: DK
- kinds: confectionery, chocolate dish
- ingredients: chocolate
- has Wikipedia article: en

## DISH Q4992511
- name: Galinha à Africana
- other names: {"zh": "非洲鸡"}
- description: Macanese chicken dish
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q4994057
- name: Lasagnette
- description: type of ribbon pasta, narrower than lasagna
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q4995419
- name: Dagashi
- other names: {"zh": "粗点心"}
- description: cheap Japanese candies
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en, zh

## DISH Q4996483
- name: Bulk confectionery
- description: confection sold in small units
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q4996510
- name: Bulkie roll
- description: American sandwich originating from New England
- countries: US
- kinds: bread, T
- has Wikipedia article: en

## DISH Q4996659
- name: Bulla cake
- description: Jamaican bread
- countries: JM
- kinds: food, cake
- ingredients: molasses
- has Wikipedia article: en

## DISH Q4997256
- name: Bumbleberry pie
- description: Canadian mixed berry pie
- countries: CA
- kinds: food, pie
- ingredients: berry
- has Wikipedia article: en

## DISH Q4997397
- name: Bun kebab
- description: sandwich originating in Pakistan
- countries: PK
- kinds: food, hamburger, sandwich
- ingredients: lentil, Shami kebab, egg as food, vegetable, bread
- has Wikipedia article: en

## DISH Q4997403
- name: Bun rieu
- other names: {"zh": "番茄米粉"}
- description: traditional Vietnamese soup
- countries: VN
- kinds: food, soup, seafood dish, crab dish
- ingredients: tomato
- has Wikipedia article: en

## DISH Q4997935
- name: Buntil
- description: Javanese dish
- countries: ID
- cuisines: Indonesian cuisine, Javanese cuisine
- kinds: food, dish, human food, type of food or dish
- ingredients: dried fish, coconut milk, Engraulis, Colocasia esculenta, cassava, Cocos nucifera, Carica papaya
- has Wikipedia article: en

## DISH Q4998037
- name: Bupyeon
- description: variety of tteok
- countries: (none)
- kinds: tteok
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q5002831
- name: Butter Brickle
- description: chocolate-coated toffee
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q5002838
- name: Butter Pecan
- other names: {"zh": "奶油山核桃"}
- description: a flavor popularly used in cakes, cookies and ice cream
- countries: US
- kinds: ice cream
- ingredients: Carya illinoinensis
- has Wikipedia article: en

## DISH Q5003018
- name: Buttermilk pie
- description: type of desperation pie
- countries: (none)
- kinds: pie
- ingredients: syrup, pastry, egg as food, butter, sugar
- has Wikipedia article: en

## DISH Q5003051
- name: Buttery
- description: savoury bread roll originating from Aberdeen, Scotland
- countries: (none)
- kinds: food, bread roll
- ingredients: lard, yeast, flour, butter
- has Wikipedia article: en

## DISH Q500445
- name: Neapolitan pizza
- other names: {"zh": "拿坡里披薩"}
- description: style of pizza made with tomatoes and Mozzarella cheese
- countries: IT
- kinds: type of pizza
- ingredients: tomato, mozzarella
- has Wikipedia article: en, zh

## DISH Q5004793
- name: Bánh chuối
- other names: {"zh": "越南香蕉饼"}
- description: sweet banana cake
- countries: VN
- kinds: pudding, bánh, banana dish
- ingredients: vanilla extract, condensed milk, white bread, coconut milk, egg as food, butter, sugar, banana
- has Wikipedia article: en, zh

## DISH Q5004794
- name: Bánh bèo
- other names: {"zh": "米粿"}
- description: Vietnamese delicacy
- countries: VN
- kinds: dish, bánh
- ingredients: tapioca flour, rice flour
- has Wikipedia article: en

## DISH Q5004795
- name: Bánh bò
- other names: {"zh": "𩟢糕"}
- description: Vietnamese sponge cake made of yeasted rice flour
- countries: VN
- kinds: sponge cake, bánh
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q5004796
- name: Bánh bó
- description: pressed fruit cake from Quảng Ngãi province, Vietnam
- countries: VN
- cuisines: cuisine of Quảng Ngãi
- kinds: fruitcake, bánh
- has Wikipedia article: en

## DISH Q5004800
- name: Bánh cáy
- countries: VN
- kinds: dish, bánh
- has Wikipedia article: en

## DISH Q5004807
- name: Bánh pía
- description: Vietnamese pastry
- countries: VN
- kinds: pastry, bánh
- has Wikipedia article: en

## DISH Q5004809
- name: Bánh rán
- description: deep-fried glutinous rice ball Vietnamese dish
- countries: VN
- kinds: doughnut
- has Wikipedia article: en

## DISH Q5004810
- name: Bánh rế
- description: Vietnamese sweet potato pancake
- countries: VN
- kinds: dish, bánh
- has Wikipedia article: en

## DISH Q5004813
- name: Bánh tét
- other names: {"zh": "餅截"}
- description: Vietnamese dish
- countries: VN
- kinds: dish, bánh
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q5005249
- name: Bún thịt nướng
- other names: {"zh": "燒肉粉"}
- description: Vietnamese cold rice vermicelli noodle dish
- countries: VN
- kinds: food, pasta dish
- ingredients: rice vermicelli
- has Wikipedia article: en

## DISH Q5005250
- name: Bún mắm
- description: Vietnamese vermicelli soup
- countries: VN
- cuisines: Southern Vietnamese cuisine
- kinds: food, soup, seafood dish, shrimp dish
- ingredients: snakehead paste, shrimp, shrimp paste, rice vermicelli
- has Wikipedia article: en

## DISH Q5005251
- name: Bún ốc
- description: Vietnamese soup
- countries: VN
- kinds: soup
- has Wikipedia article: en

## DISH Q5006522
- name: C. Howard's Violet candies
- description: violet-flavored candies
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q500708
- name: Pizza marinara
- other names: {"zh": "玛丽亚娜披薩"}
- description: typical Neapolitan pizza topped with tomato, garlic, oregano and olive oil
- countries: IT
- ingredients: oregano, garlic, tomato, olive oil
- has Wikipedia article: en

## DISH Q5015278
- name: Cabbage casserole
- description: traditional Finnish dish
- countries: FI
- kinds: dish, casserole
- ingredients: cabbage, minced meat, rice
- has Wikipedia article: en

## DISH Q5015296
- name: Cabbie claw
- description: Fish dish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q5015370
- name: Kelle
- description: Turkish dish made of head meat (generally sheep)
- countries: TR
- kinds: food, dish

## DISH Q5015379
- name: Cabeça de galo
- description: Brazilian dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5015592
- name: Cabinet pudding
- description: pudding with ladyfingers
- countries: GB
- cuisines: English cuisine
- kinds: pudding
- has Wikipedia article: en

## DISH Q5016033
- name: Cacio e pepe
- description: Italian pasta dish
- countries: IT
- cuisines: Roman cuisine, cuisine of Lazio
- kinds: dish, pasta dish
- ingredients: pasta, peppercorn, Pecorino Romano PDO
- has Wikipedia article: en

## DISH Q5016036
- name: Caciotta
- description: Italian cheese
- countries: IT
- kinds: cheese
- has Wikipedia article: en

## DISH Q5016731
- name: Kaapse raasdonders
- other names: {"nl": "Kaapse raasdonders"}
- countries: (none)
- kinds: dish
- ingredients: onion, Field pea, bacon

## DISH Q5017201
- name: Cafreal
- description: spicy chicken dish popular in the Indian state of Goa
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q5017984
- name: Cajeta
- description: confection of thickened syrup
- countries: (none)
- kinds: dulce de leche
- ingredients: goat milk
- has Wikipedia article: en

## DISH Q5018040
- name: Cakalang fufu
- description: Indonesian traditional food
- countries: ID
- kinds: smoked fish, main course, human food, food ingredient, tuna dish
- ingredients: smoking
- has Wikipedia article: en

## DISH Q5019102
- name: Caldillo de congrio
- other names: {"zh": "唐吉鰻魚湯"}
- description: Chilean fish soup
- countries: CL
- kinds: stock, fish soup, fish dish
- ingredients: pink cusk-eel, Genypterus chilensis, potato, fish
- has Wikipedia article: en

## DISH Q5019109
- name: Caldo de pollo
- description: Latin American soup dish
- countries: MX
- kinds: food, soup
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q5019110
- name: Caldo de costilla
- description: Colombian broth dish
- countries: CO
- kinds: food, soup
- ingredients: beef
- has Wikipedia article: en

## DISH Q5019112
- name: Caldo de siete mares
- description: Mexican fish stew
- countries: MX
- kinds: food, soup, seafood dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q5019561
- name: Calf's liver and bacon
- description: dish containing calf liver and bacon
- countries: (none)
- kinds: food, veal dish
- ingredients: calf liver, bacon
- has Wikipedia article: en

## DISH Q5020186
- name: California-style pizza
- description: style of pizza
- countries: US
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q50218623
- name: Бајадера (колач)
- other names: {"mk": "Бајадера (колач)"}
- countries: (none)
- kinds: dessert

## DISH Q502405
- name: Amish Friendship Bread
- description: type of bread or cake made from a sourdough starter
- countries: US
- kinds: food, bread, cake
- ingredients: sourdough
- has Wikipedia article: en

## DISH Q50301470
- name: Kkochi
- description: Korean foods cooked on skewers
- countries: KR
- kinds: skewer, dish
- has Wikipedia article: en

## DISH Q5030681
- name: Canadian white bread
- description: Type of commercially prepared bread
- countries: CA
- kinds: food, bread
- has Wikipedia article: en

## DISH Q503129
- name: Chocolate brownie
- other names: {"zh": "巧克力布朗尼"}
- description: baked chocolate confection
- countries: GB
- kinds: confectionery, dessert bar
- ingredients: cocoa bean, egg as food, flour, butter, sugar
- has Wikipedia article: en, zh

## DISH Q5031953
- name: Candle salad
- description: US fruit salad dish composed of lettuce, pineapple, banana, cherry, and mayonnaise or cottage cheese
- countries: US
- kinds: fruit salad
- ingredients: Lactuca sativa, banana
- has Wikipedia article: en

## DISH Q5032499
- name: Canja de galinha
- description: popular chicken soup of Portuguese and Brazilian cuisine
- countries: PT, BR
- cuisines: Portuguese cuisine, Brazilian cuisine
- kinds: food, chicken soup
- ingredients: chicken as food, Oryza, rice, pasta
- has Wikipedia article: en

## DISH Q5033997
- name: Cantonese seafood soup
- description: cantonese cuisine dish
- countries: CN
- kinds: soup, dish, fish soup
- ingredients: seafood
- has Wikipedia article: en

## DISH Q5034353
- name: Cao lầu
- other names: {"zh": "高樓麵"}
- description: Vietnamese noodle dish
- countries: VN
- kinds: pasta dish, pork dish
- ingredients: noodle
- has Wikipedia article: en, zh

## DISH Q5034394
- name: Chháu-á-kóe
- other names: {"zh": "草仔粿"}
- description: glutinous rice dumplings colored green with herbs
- countries: CN, TW
- kinds: food
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q5034525
- name: Caparrones
- description: caparrón stew
- countries: ES
- kinds: food, soup
- has Wikipedia article: en

## DISH Q50349154
- name: Pannfisch
- countries: (none)
- kinds: dish

## DISH Q503494
- name: Cobbler
- other names: {"zh": "水果餡餅"}
- description: baked dish resembling a pie
- countries: US
- cuisines: cuisine of the United States, British cuisine
- kinds: dessert
- ingredients: fruit, batter
- has Wikipedia article: en

## DISH Q50352830
- name: Caciocchiato
- description: Italian cheese
- countries: IT
- kinds: pasta filata, cow's-milk cheese, Italian cheese

## DISH Q5038482
- name: Cawl
- other names: {"zh": "威尔士肉汤"}
- description: traditional Welsh soup
- countries: (none)
- kinds: broth, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q5043851
- name: Carne de chango
- description: Mexican pork dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q5043855
- name: Carne pinchada
- description: Nicaraguan meat dish
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q5044066
- name: Carnitas
- description: Mexican dish
- countries: MX
- kinds: pork dish
- ingredients: pork, offal, lard
- has Wikipedia article: en

## DISH Q5046165
- name: Morioka reimen
- other names: {"zh": "盛岡冷麵"}
- description: Japanese dish of cold noodles from Morioka, Japan, originating from Korean naengmyeon
- countries: JP
- kinds: naengmyeon
- has Wikipedia article: en

## DISH Q5047987
- name: Casado
- description: traditional Costa Rican meal
- countries: CR
- kinds: dish
- ingredients: tortilla, Phaseolus vulgaris, meat, salad
- has Wikipedia article: en

## DISH Q5048739
- name: Cashew chicken
- other names: {"zh": "腰果雞丁"}
- description: fried chicken with cashews
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q5050945
- name: Casunziei
- description: type of stuffed pasta
- countries: IT
- kinds: dish, stuffed pasta
- has Wikipedia article: en

## DISH Q505115
- name: Plätzchen
- description: German biscuit
- countries: (none)
- kinds: viennoiserie

## DISH Q5051989
- name: Catfish stew
- description: Fish stew from the American South
- countries: US
- kinds: fish dish
- ingredients: Siluriformes
- has Wikipedia article: en

## DISH Q5055515
- name: Cazelle de Saint Affrique
- description: French cheese
- countries: FR
- kinds: cheese
- has Wikipedia article: en

## DISH Q5055611
- name: Cağ kebabı
- description: Turkish meal
- countries: TR
- kinds: dish, food, kebab, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q5055615
- name: Caş
- other names: {"zh": "羊凝乳"}
- description: type of semi-soft white fresh cheese made from sheep or cow milk, produced in Romania
- countries: RO
- kinds: cheese
- ingredients: milk
- has Wikipedia article: en

## DISH Q5056486
- name: Montreal-style smoked meat
- other names: {"zh": "煙肉三明治"}
- description: style of smoked meat corned beef created by Jewish immigrants in Montreal, Quebec
- countries: CA
- kinds: sandwich, food
- ingredients: rye bread, smoked meat, mustard
- has Wikipedia article: en, zh

## DISH Q5057026
- name: Montreal-style bagel
- other names: {"zh": "蒙特利爾風格貝果"}
- description: variety of bagel created by Jewish immigrants in Montreal, Quebec
- countries: CA
- kinds: bagel
- ingredients: malt
- has Wikipedia article: en

## DISH Q505711
- name: Nattō
- other names: {"zh": "纳豆"}
- description: traditional Japanese food made from fermented soybeans
- countries: JP
- kinds: type of food or dish, fermented food, soy food
- ingredients: soy bean
- has Wikipedia article: en, zh

## DISH Q5057827
- name: Celery Victor
- description: marinated celery salad dish
- countries: US
- cuisines: cuisine of California
- kinds: dish, salad
- ingredients: Apium graveolens
- has Wikipedia article: en

## DISH Q5058734
- name: Cemita
- description: bread from the Hispanic bakery tradition
- countries: ES
- kinds: food, bread

## DISH Q5062050
- name: Marianne
- description: Finnish candy brand
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q50622
- name: Bánh cuốn
- other names: {"zh": "越南粉卷"}
- description: Vietnamese dish
- countries: VN
- kinds: rice noodle roll, bánh, pork dish
- has Wikipedia article: en, zh

## DISH Q50627362
- name: Mote pata
- other names: {"es": "Mote pata"}
- countries: EC
- kinds: food, soup
- ingredients: mote, Cucurbita ficifolia, pork

## DISH Q50633
- name: Bánh xèo
- other names: {"zh": "越南煎餅"}
- description: Vietnamese thin pancakes
- countries: VN
- kinds: bánh, pancake
- ingredients: turmeric, shrimp, rice flour, pork
- has Wikipedia article: en, zh

## DISH Q50634
- name: Bun cha
- other names: {"zh": "烤肉米粉"}
- description: Vietnamese dish
- countries: VN
- kinds: dish, noodle
- ingredients: nước chấm, rice vermicelli, fish sauce, pork, vegetable
- has Wikipedia article: en, zh

## DISH Q5065778
- name: Ceylon
- description: family of curry recipes with the key ingredients of coconut, lime, Ceylon curry powder
- countries: LK
- kinds: curry
- ingredients: coconut milk
- has Wikipedia article: en

## DISH Q5065917
- name: ChaSan
- description: traditional Chinese pastry dish
- countries: CN
- kinds: food, pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q5066056
- name: Chacarero
- description: Chilean sandwich
- countries: CL
- kinds: food, sandwich
- ingredients: aji amarillo, Tomate, green bean, veal, mayonnaise, bread
- has Wikipedia article: en

## DISH Q50663373
- name: Trevico prosciutto
- description: Italian dry-cured ham
- countries: IT
- kinds: raw ham

## DISH Q5066400
- name: Charchari
- description: type of dish in Bengali cuisine
- countries: (none)
- kinds: dish, type of food or dish
- has Wikipedia article: en

## DISH Q5067730
- name: Chahuis
- description: common name of edible beetles in the order Coleoptera, traditionally eaten in Mexico
- countries: MX
- kinds: organisms known by a particular common name, dish
- ingredients: beetle
- has Wikipedia article: en

## DISH Q5068113
- name: Chaira
- description: soup of Andean origin, traditional in countries that comprise the Andean region
- countries: (none)
- kinds: Chupe, beef dish, meal
- ingredients: chuño
- has Wikipedia article: en

## DISH Q5068362
- name: Chakkoli
- countries: (none)
- kinds: shrimp dish
- has Wikipedia article: en

## DISH Q5068377
- name: Chakna
- description: Indian spicy stew
- countries: IN
- kinds: food, soup, goat meat dish
- has Wikipedia article: en

## DISH Q5068592
- name: Chalbori-ppang
- description: Korean confection, consisting of two small pancakes made with glutinous barley flour wrapped around a filling of red bean paste
- countries: KR
- cuisines: South Korean cuisine
- kinds: food, pancake
- ingredients: barley
- has Wikipedia article: en

## DISH Q5071356
- name: Chandrakala
- description: Indian sweet named after Moon
- countries: IN
- kinds: dessert
- has Wikipedia article: en

## DISH Q5072565
- name: Chanochi
- description: Korean fried rice cake dish
- countries: (none)
- kinds: dish
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q5072677
- name: Chantilly cake
- other names: {"zh": "尚蒂伊蛋糕"}
- description: one of two types of cake
- countries: US
- kinds: cake
- ingredients: chantilly cream, German chocolate cake
- has Wikipedia article: en, zh

## DISH Q5072752
- name: Chao hong guo
- description: traditional dish in Beijing cuisine
- countries: CN
- kinds: pastry, dish
- ingredients: Crataegus pinnatifida
- has Wikipedia article: en

## DISH Q5072761
- name: Chaogan
- other names: {"zh": "炒肝"}
- description: liver-based food of China
- countries: CN
- kinds: snack, offal dish
- ingredients: pork large intestine, pork liver
- has Wikipedia article: en, zh

## DISH Q5072910
- name: Chapalele
- description: dough made from boiled potatoes and wheat flour
- countries: CL
- kinds: potato-dough dumpling
- ingredients: potato
- has Wikipedia article: en

## DISH Q5073431
- name: Chapssal-tteok
- other names: {"zh": "糯米糕"}
- description: Korean glutinous rice cake
- countries: (none)
- kinds: tteok, glutinous rice cake
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q507591
- name: Drabbelkoek
- description: Dutch cookie
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q50825931
- name: Mustard sauce
- description: sauce with mustard
- countries: DE
- kinds: sauce
- ingredients: mustard

## DISH Q50835686
- name: Dragon-fruit noodle
- description: noodle
- countries: VN
- kinds: noodle

## DISH Q5084201
- name: Charleston red rice
- description: dish in the American states of South Carolina and Georgia
- countries: (none)
- kinds: dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q50862300
- name: Rendang Itiak
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, rendang
- ingredients: coconut milk, duck meat, Allium ascalonicum, chili pepper, Curcuma longa, Allium sativum

## DISH Q5089395
- name: Cheese and pickle sandwich
- description: As its name suggests, it consists of sliced or grated cheese (typically Cheddar) and pickle (a sweet, vinegary chutney, the most popular brand being Branston), sandwiched between two slices of bread.
- countries: GB
- kinds: type of food or dish, sandwich
- ingredients: bread, chutney, cheese
- has Wikipedia article: en

## DISH Q5089399
- name: Cheese dog
- other names: {"zh": "乳酪熱狗"}
- description: type of hot dog
- countries: US
- kinds: hot dog
- ingredients: hot dog
- has Wikipedia article: en, zh

## DISH Q5089400
- name: Cheese fries
- description: fast food dish
- countries: US
- kinds: fast food
- ingredients: fries, cheese
- has Wikipedia article: en

## DISH Q5089402
- name: Cheese dream
- other names: {"zh": "夢幻乳酪三明治"}
- description: grilled cheese sandwich
- countries: US
- kinds: open sandwich
- ingredients: bread
- has Wikipedia article: en, zh

## DISH Q5089403
- name: Cheese pudding
- description: Pudding dish made with cheese
- countries: (none)
- kinds: pudding
- ingredients: cheese
- has Wikipedia article: en

## DISH Q5089446
- name: Cheesymite scroll
- description: Australian baked food
- countries: AU
- kinds: food, bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q5089539
- name: Chegdermeh
- description: Turkmen plate
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q5090157
- name: Chelsea bun
- description: English type of sweet bun
- countries: GB
- cuisines: British cuisine
- kinds: currant bun
- ingredients: currant, baker's yeast, zest, flour
- has Wikipedia article: en

## DISH Q50914259
- name: Barkis
- other names: {"sv": "barkis"}
- countries: SE
- kinds: bread, food
- ingredients: wheat flour, Papaver, yeast, table salt, sugar, water

## DISH Q5092519
- name: Cherry pie
- other names: {"zh": "樱桃饼"}
- description: pie baked with a cherry filling
- countries: (none)
- kinds: sweet pie, dish, pie
- ingredients: pastry, cherry
- has Wikipedia article: en, zh

## DISH Q5094872
- name: Chhena jalebi
- description: Indian dessert
- countries: (none)
- kinds: confectionery
- ingredients: chhena
- has Wikipedia article: en

## DISH Q5094874
- name: Chhencheda
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q5094956
- name: Chhota haazri
- description: A traditional early‑morning light meal served in British‑era India.
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5096240
- name: Chicken French
- description: italian-American dish
- countries: (none)
- cuisines: Italian-American cuisine
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q5096259
- name: Chicken Maryland
- description: fried chicken dish with cream sauce
- countries: (none)
- cuisines: cuisine of the Southern United States
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q5096277
- name: Chicken Vesuvio
- description: Italian-American dish popular in Chicago
- countries: US
- kinds: chicken dish
- ingredients: chicken as food, oregano, garlic, potato, olive oil, wine
- has Wikipedia article: en

## DISH Q5096283
- name: Chicken and chips
- other names: {"zh": "鸡肉配薯条"}
- description: hot dish of fried chicken and French fries
- countries: (none)
- kinds: hot dish
- has Wikipedia article: zh

## DISH Q5096287
- name: Chicken and waffles
- other names: {"zh": "炸鸡华夫饼"}
- description: U.S. dish combining fried chicken with waffles
- countries: US
- kinds: food, chicken dish
- ingredients: fried chicken, waffle
- has Wikipedia article: en, zh

## DISH Q5096288
- name: Chicken bog
- description: Lowcountry chicken pilaf
- countries: (none)
- cuisines: Lowcountry cuisine
- kinds: pilaf, chicken and rice
- ingredients: chicken as food, onion, sausage, spice, rice
- has Wikipedia article: en

## DISH Q5096289
- name: Chicken and mushroom pie
- other names: {"zh": "雞肉派"}
- description: common British pie
- countries: GB
- kinds: food, pie
- has Wikipedia article: en, zh

## DISH Q5096293
- name: Chicken balls
- other names: {"zh": "软炸鸡肉球"}
- description: chicken meat shaped into a sphere
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q5096299
- name: Chicken fingers
- other names: {"zh": "炸雞條"}
- description: U.S. dish of breaded and fried chicken meat from the pectoralis minor or similarly sized cut of chicken
- countries: US
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q5096323
- name: Chicken salad
- other names: {"zh": "鸡肉沙拉"}
- description: Salad made with chicken
- countries: (none)
- kinds: salad, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q5097538
- name: Chikuzenni
- other names: {"zh": "筑前煮"}
- description: Japanese dish
- countries: JP
- kinds: nimono, chicken dish
- ingredients: dashi
- has Wikipedia article: en, zh

## DISH Q509835
- name: Sushki
- description: food
- countries: RU
- kinds: food, baranki
- ingredients: flour
- has Wikipedia article: en

## DISH Q5098719
- name: Chile relleno
- other names: {"zh": "辣血腸"}
- description: Mexican dish
- countries: MX
- kinds: stuffed peppers
- ingredients: chili pepper, cheese
- has Wikipedia article: en

## DISH Q5098835
- name: Chilean salad
- description: Chilean mixed vegetable dish
- countries: CL
- kinds: salad
- ingredients: cilantro, parsley, tomato, chili pepper, onion
- has Wikipedia article: en

## DISH Q5098938
- name: Chili burger
- description: hamburger, with the patty topped with chili con carne
- countries: US
- kinds: food, hamburger
- ingredients: chili
- has Wikipedia article: en

## DISH Q5098941
- name: Chili dog
- other names: {"zh": "辣味热狗"}
- description: hot dog with chili sauce
- countries: US
- kinds: food, hot dog
- ingredients: hot dog bun
- has Wikipedia article: en

## DISH Q5099038
- name: Chilli chicken
- description: indo-Chinese dish
- countries: IN
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q5099176
- name: Chilorio
- description: Mexican pork dish from state of Sinaloa
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q5099374
- name: Chimichurri burger
- description: traditional snack dish (sandwich) served in the Dominican Republic
- countries: DO
- kinds: hamburger
- ingredients: ground pork, Salsa golf
- has Wikipedia article: en

## DISH Q5099514
- name: Chin chin
- other names: {"zh": "欽欽（食物）"}
- description: snack in Nigeria made from basic combination of flour, milk and sugar
- countries: NG
- kinds: snack, dish
- ingredients: vegetable oil, milk powder, egg as food, flour, butter, baking powder, sugar
- has Wikipedia article: en, zh
