# Review batch names-052

## DISH Q6909359
- name: Moravian spice cookies
- description: Traditional kind of cookie
- countries: US
- kinds: food, cookie
- ingredients: spice
- has Wikipedia article: en

## DISH Q690994
- name: Fritto misto alla piemontese
- description: Italian deep-fried dish
- countries: IT
- kinds: meat dish

## DISH Q69102980
- name: Pandan waffle
- description: Vietnamese waffle made of batter flavored by pandan and coconut milk
- countries: (none)
- kinds: waffle, street food
- ingredients: coconut milk, Pandanus amaryllifolius, batter

## DISH Q6914349
- name: Mortadella sandwich
- description: Brazilian sandwich
- countries: IT
- kinds: sandwich
- ingredients: pão francês, mortadella
- has Wikipedia article: en

## DISH Q691755
- name: Steamed curry
- other names: {"zh": "魚荷"}
- description: Southeast Asian type of curry steam-cooked in banana leaves
- countries: TH
- kinds: curry
- ingredients: curry paste, coconut cream
- has Wikipedia article: en

## DISH Q69214
- name: Caragols a la llauna
- description: Grilled or baked land snails from Catalonia, Spain
- countries: (none)
- kinds: snail as food, dish
- has Wikipedia article: en

## DISH Q6923643
- name: Rice with spinach
- countries: (none)
- kinds: dish

## DISH Q692613
- name: Tirggel
- description: Swiss traditional Christmas biscuit
- countries: CH
- kinds: biscuit
- ingredients: flour, honey
- has Wikipedia article: en

## DISH Q6926273
- name: Moustalevria
- description: Traditional Greek dessert
- countries: GR
- kinds: food, dessert
- ingredients: mastic, must, walnut, Prunus dulcis, flour, vanilla
- has Wikipedia article: en

## DISH Q6926685
- name: Bêdirav
- description: Kurdish bean salad
- countries: (none)
- kinds: bean salad, salad
- ingredients: garlic, onion, olive, bean, olive oil, vinegar, Capsicum annuum

## DISH Q6927204
- name: Bêran
- description: Kurdish dish
- countries: (none)
- kinds: dish
- ingredients: meat, rice

## DISH Q6928578
- name: Bîstan
- description: Kurdish salad
- countries: (none)
- kinds: dish
- ingredients: onion, chili pepper, Portulaca oleracea

## DISH Q6928855
- name: Bûmbar
- description: Kurdish food
- countries: (none)
- kinds: snack
- ingredients: lumbar spine

## DISH Q6929071
- name: Bûş
- description: dish of Kurdish cuisine
- countries: TR
- kinds: dish

## DISH Q6930013
- name: Cehzêr
- description: Kurdish cuisine salad
- countries: (none)
- kinds: salad
- ingredients: cucumber, Salzgurke, cheese

## DISH Q69321010
- name: Genovese
- other names: {"it": "Genovese"}
- countries: IT
- kinds: dessert

## DISH Q6934262
- name: Julekake
- description: Norwegian Christmas cake
- countries: (none)
- kinds: pastry
- ingredients: succade, yeast, flour, butter, Elettaria cardamomum, raisin, table salt, sugar, milk
- has Wikipedia article: en

## DISH Q6935684
- name: Munchy box
- description: fast food product
- countries: (none)
- kinds: fast food
- has Wikipedia article: en

## DISH Q6935968
- name: Derf
- description: Kurdish meal
- countries: (none)
- kinds: dish
- ingredients: goat meat

## DISH Q6936640
- name: Munini-imo
- description: Pancake made with fermented potato flour
- countries: JP
- cuisines: Ainu cuisine
- kinds: pancake, preserved food, potato dish
- ingredients: potato starch
- has Wikipedia article: en

## DISH Q6936882
- name: Dewliser
- description: Kurdish dish
- countries: (none)
- kinds: dish
- ingredients: Lamb chops, onion, rice

## DISH Q69393237
- name: Stuffed flatbread
- other names: {"zh": "中东夹饃"}
- description: flat bread traditionally filled with e.g. lettuce, tomato, onion and meat, popular in the Middle East and the Mediterranean
- countries: (none)
- kinds: sandwich, finger food, flatbread dish
- ingredients: flatbread, vegetable, meat

## DISH Q6939379
- name: Doxave
- description: Kurdish food
- countries: (none)
- kinds: dish
- ingredients: cicer arietinum, meat

## DISH Q69394023
- name: Biscuits of Saint Martin
- description: typical Sicilian biscuit
- countries: IT
- kinds: biscuit, dessert
- has Wikipedia article: en

## DISH Q694022
- name: Krumkake
- other names: {"zh": "克魯姆克"}
- description: Norwegian waffle wrapped into a conical shape after baking
- countries: NL, NO
- kinds: waffle
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q6941325
- name: Mushroom gravy
- description: type of sauce
- countries: (none)
- kinds: sauce, gravy, mushroom dish
- ingredients: stock, roux, edible mushroom
- has Wikipedia article: en

## DISH Q6944116
- name: Mutton pulao
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q694444
- name: Cheese fondue
- other names: {"zh": "奶酪火锅"}
- description: dish of melted cheese into which cubes of bread are dipped
- countries: CH
- kinds: national dish, cheese dish, fondue
- ingredients: corn starch, cheese, white wine, bread

## DISH Q6944521
- name: Mućkalica
- description: Serbian dish
- countries: RS
- kinds: dish
- has Wikipedia article: en

## DISH Q69475095
- name: Pupi di zucchero PAT
- other names: {"zh": "Pupi di zucchero PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good, sweetmeat
- ingredients: lemon juice, sugar

## DISH Q6949924
- name: Fetîr
- description: Kurdish meal
- countries: TR
- kinds: dish
- ingredients: baker's yeast, egg as food, milk

## DISH Q6949994
- name: Mässmogge
- description: Swiss type of candy
- countries: CH
- kinds: sugar candy
- ingredients: hazelnut
- has Wikipedia article: en

## DISH Q6950186
- name: Mì Quảng
- other names: {"zh": "廣南麵"}
- description: Vietnamese noodle dish
- countries: VN
- cuisines: Central Vietnamese cuisine
- kinds: food, pasta dish
- ingredients: rice noodle
- has Wikipedia article: en, zh

## DISH Q6953102
- name: Agristada
- countries: (none)
- kinds: egg-lemon sauce

## DISH Q6955858
- name: Imitation crab
- other names: {"zh": "赛螃蟹"}
- description: Chinese egg dish
- countries: CN
- kinds: egg dish
- has Wikipedia article: zh

## DISH Q6956585
- name: Naan qalia
- countries: IN
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q6956882
- name: Gulûl
- description: Kurdish dish
- countries: (none)
- kinds: dish
- ingredients: bulgur, ayran, yogurt, maize, rice

## DISH Q6960349
- name: Harşo
- description: Kurdish food
- countries: (none)
- kinds: dish
- ingredients: cooking oil, egg as food, onion, cheese

## DISH Q6960656
- name: Nakji bokkeum
- other names: {"zh": "韓式辣炒章魚"}
- description: Korean stir-fried octopus dish
- countries: (none)
- kinds: octopus dish
- ingredients: Octopus minor
- has Wikipedia article: en

## DISH Q6960802
- name: Hebnîsk
- description: Lentil dish
- countries: (none)
- kinds: dish
- ingredients: lentil

## DISH Q6961401
- name: Heftbirrî
- description: Type of bread
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: Kilor, type of food or dish

## DISH Q6962244
- name: Nan gyi thohk
- description: Burmese chicken chilli noodle salad
- countries: MM
- kinds: Mont di, Burmese salad
- ingredients: rice noodle, chili oil, chicken as food
- has Wikipedia article: en

## DISH Q6963832
- name: Hevrîşk
- description: Food made from bread and oil
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: dish
- ingredients: bread, oil

## DISH Q6964346
- name: Nantong Xiting Cracker
- description: Chinese biscuit
- countries: (none)
- kinds: food, cracker
- ingredients: Sesamum, flour, sugar
- has Wikipedia article: en

## DISH Q6964951
- name: Hirçkî
- description: Kurdish dish
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: dish
- ingredients: onion, cucumber

## DISH Q69650224
- name: Completada
- description: social event involving a Chilean variant of hot dogs
- countries: CL
- kinds: gastronomy
- ingredients: completo

## DISH Q6966108
- name: Hêkerûn
- description: Type of omelette
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: egg dish, dish

## DISH Q6966528
- name: Naryn
- other names: {"zh": "那仁"}
- description: Central Asian noodle dish
- countries: KG, UZ
- cuisines: Kazakh cuisine, Cuisine of Uzbekistan, Kyrgyz cuisine
- kinds: pasta dish
- ingredients: noodle, onion, meat
- has Wikipedia article: en, zh

## DISH Q6967043
- name: Nasi bakar
- description: Indonesian traditional steamed rice
- countries: ID
- cuisines: Indonesian cuisine, traditional food
- kinds: cooked rice, dish, human food, type of food or dish, food, rice dish
- has Wikipedia article: en

## DISH Q6967046
- name: Nasi bogana
- description: Indonesia rice dish originating from Java island
- countries: ID
- cuisines: main course, Indonesian cuisine
- kinds: dish, human food, type of food or dish, rice dish
- ingredients: Indonesian bay leaf, onion, coconut milk, Alpinia galanga, Pandanus amaryllifolius, Oryza molida, Cymbopogon citratus, table salt, chicken
- has Wikipedia article: en

## DISH Q6967048
- name: Nasi liwet
- description: Indonesian rice dish originating from Java island
- countries: ID
- cuisines: Indonesian cuisine, cooked grain
- kinds: dish, human food, type of food or dish, cooked rice, Indonesian cuisine, rice dish
- ingredients: coconut milk, Cymbopogon citratus, table salt, rice, water, bay leaf
- has Wikipedia article: en

## DISH Q6967051
- name: Nasi paprik
- description: Thai dish of fried rice flavoured with sauteed chilli paste
- countries: (none)
- kinds: fried rice, food, dish
- has Wikipedia article: en

## DISH Q6967056
- name: Nasi tim
- description: Indonesian rice dish
- countries: ID
- kinds: rice dish, chicken dish, dish
- ingredients: chicken as food, rice
- has Wikipedia article: en

## DISH Q6967935
- name: Nataing
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q6968166
- name: Kalbûnî
- description: Kurdish dish
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: dish
- ingredients: Lamb chops, almond, rice

## DISH Q6968581
- name: Natchitoches meat pie
- description: meat pie from Louisiana, United States
- countries: US
- kinds: food, meat pie, pie
- has Wikipedia article: en

## DISH Q69698150
- name: Omo Tuwe
- countries: GH
- kinds: rice dish

## DISH Q697016
- name: Tung-ting tea
- other names: {"zh": "冻顶乌龙茶"}
- description: oolong from Taiwan
- countries: TW
- kinds: oolong
- has Wikipedia article: en, zh

## DISH Q697230
- name: Bumbu
- description: Indonesian blend of spices or spicy paste
- countries: ID
- kinds: spice mix, condiment
- has Wikipedia article: en

## DISH Q6973180
- name: Kesmaşî
- description: Kurdish dish
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: dish

## DISH Q6974635
- name: Kirdo
- description: Kurdish food
- countries: (none)
- kinds: dish

## DISH Q697498
- name: Beef noodle soup
- other names: {"zh": "牛肉面"}
- description: noodle soup with beef
- countries: (none)
- kinds: type of food or dish, noodle soup
- ingredients: beef
- has Wikipedia article: en, zh

## DISH Q6978616
- name: Kuftesîr
- description: Kurdish dish
- countries: (none)
- kinds: dish, kofta
- ingredients: bulb, flour, yogurt

## DISH Q6978633
- name: Kuftetirş
- description: Meatball from Kurdish cuisine
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: meat dish, frikadeller
- ingredients: minced meat, onion, peppercorn, lemon juice, cooking oil, table salt, rice

## DISH Q6979159
- name: Kumspî
- description: Kurdish food
- countries: (none)
- kinds: dish
- ingredients: cheese

## DISH Q6979199
- name: Kun
- description: Kurdish food
- countries: TR
- kinds: dish
- ingredients: goat meat

## DISH Q697951
- name: Oyster vermicelli
- other names: {"zh": "蚵仔面线"}
- description: Taiwanese noodle soup
- countries: TW
- kinds: oyster dish
- ingredients: Misua, oyster, flour
- has Wikipedia article: en, zh

## DISH Q6979626
- name: National loaf
- description: British bread made from wholemeal flour introduced during the Second World War
- countries: GB
- kinds: bread, brown bread
- ingredients: whole grain
- has Wikipedia article: en

## DISH Q6980923
- name: Kêpayî
- description: Kurdish dish
- countries: (none)
- kinds: dish
- ingredients: rice

## DISH Q6981917
- name: Pölsa
- description: traditional Swedish dish made from finely ground meat, traditionally leftover meat
- countries: SE
- kinds: dish
- ingredients: Allium, liver, heart
- has Wikipedia article: en

## DISH Q6982616
- name: Liklikî
- description: type of kofte
- countries: (none)
- kinds: type of food or dish, kofta
- ingredients: minced meat, peel, table salt

## DISH Q6983246
- name: Lêvenî
- description: Kurdish soup
- countries: (none)
- kinds: soup
- ingredients: black pepper, minced meat, onion, sunflower oil

## DISH Q6986243
- name: Nederwiet
- countries: (none)
- kinds: strain of cannabis, Cannabis sativa

## DISH Q6986919
- name: Neer dosa
- description: unique dish of Tulu Nadu, India
- countries: IN
- kinds: dosa
- ingredients: rice
- has Wikipedia article: en

## DISH Q6987250
- name: Maşik
- description: Kurdish dish
- countries: (none)
- kinds: dish
- ingredients: butter, rice

## DISH Q6987533
- name: Meftune
- description: Kurdish food
- countries: (none)
- kinds: dish
- ingredients: garlic, Lycopersicon, meat

## DISH Q699637
- name: Gochujang
- other names: {"zh": "苦椒酱"}
- description: Korean red chilli paste
- countries: KR
- cuisines: Korean cuisine
- kinds: condiment, sauce, Jang
- ingredients: chili powder, meju, malt, glutinous rice
- has Wikipedia article: en, zh

## DISH Q700026
- name: Black Forest ham
- other names: {"zh": "黑森林火腿"}
- description: German meat preparation
- countries: DE
- kinds: smoked ham
- ingredients: pork
- has Wikipedia article: en, zh

## DISH Q7000528
- name: Nettle soup
- other names: {"zh": "荨麻汤"}
- description: traditional soup prepared from stinging nettles
- countries: TR
- kinds: dish, soup
- ingredients: nettle leaf
- has Wikipedia article: en, zh

## DISH Q7000669
- name: Navoşk
- description: Kurdish food
- countries: (none)
- kinds: dish
- ingredients: garlic clove, minced meat, onion

## DISH Q700643
- name: Shiruko
- other names: {"zh": "汁粉"}
- description: Japanese dessert
- countries: JP
- kinds: wagashi, bean soup, shirumono, azuki bean based food
- ingredients: Vigna angularis
- has Wikipedia article: en, zh

## DISH Q7007443
- name: Clam bake
- other names: {"zh": "新英格兰烧蛤"}
- description: dish of lobster, mussels, crabs, soft-shell clams, and/or quahogs, cooked by steaming the ingredients over seaweed; sometimes supplemented with vegetables, e.g. onions, carrots, and corn on the cob; eaten on festive occasions in New England
- countries: US
- kinds: clam dish
- ingredients: shellfish
- has Wikipedia article: en, zh

## DISH Q7009815
- name: Patîle
- description: Kurdish name for a type of bread
- countries: (none)
- kinds: baked good, bread

## DISH Q70125
- name: Croquette
- other names: {"zh": "可樂餅"}
- description: deep-fried roll dish
- countries: (none)
- kinds: snack, convenience food, food, fritter, kue, type of food or dish
- ingredients: bread crumbs, egg as food, béchamel
- has Wikipedia article: en, zh

## DISH Q7013362
- name: Pilor
- description: Kurdish candy
- countries: (none)
- kinds: confectionery

## DISH Q7014585
- name: Pirtik
- description: Kurdish food
- countries: (none)
- kinds: fare
- ingredients: onion, rice, sodium chloride

## DISH Q701519
- name: Ló͘-bah-pn̄g
- other names: {"zh": "肉臊飯"}
- description: rice dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: rice dish, pork dish, type of food or dish
- ingredients: lurou, Bah-sò, rice wine, soy sauce, pork, sugar, rice
- has Wikipedia article: en, zh

## DISH Q7015481
- name: Piyazmaş
- description: Kurdish cuisine appetizer
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: appetizer
- ingredients: garlic clove, lemon juice, onion

## DISH Q7015856
- name: Pişorik
- other names: {"ku": "Pişorik"}
- countries: TR
- kinds: dish

## DISH Q701628
- name: Stinky tofu
- other names: {"zh": "臭豆腐"}
- description: Chinese fermented tofu with a strong odor; usually sold at night markets or roadside stands as a snack, or in lunch bars as a side dish, rather than in restaurants
- countries: CN, TW
- kinds: type of food or dish, fermented bean curd
- ingredients: tofu
- has Wikipedia article: en, zh

## DISH Q701756
- name: Kimchi-jjigae
- other names: {"zh": "泡菜锅"}
- description: stew made with kimchi
- countries: (none)
- kinds: food, jjigae
- ingredients: Kimchi
- has Wikipedia article: en, zh

## DISH Q701767
- name: Hoe
- other names: {"zh": "膾"}
- description: raw food dishes in Korean cuisine
- countries: (none)
- kinds: seafood dish, raw fish dish, raw meat dish
- ingredients: raw fish
- has Wikipedia article: en, zh

## DISH Q701797
- name: Takuan
- other names: {"zh": "沢庵"}
- description: pickled daikon radish
- countries: CN
- kinds: nukazuke, vegetable dish
- ingredients: Japanese radish
- has Wikipedia article: en, zh

## DISH Q701870
- name: Japanese curry
- other names: {"zh": "日式咖喱"}
- description: Japanese cuisine
- countries: JP
- kinds: curry
- has Wikipedia article: en, zh

## DISH Q702028
- name: Katsudon
- other names: {"zh": "猪排饭"}
- description: Japanese rice dish
- countries: JP
- kinds: donburi, pork chop rice, rice dish
- ingredients: tonkatsu, rice, tonkatsu sauce, Japanese rice, bread crumbs, egg as food
- has Wikipedia article: en, zh

## DISH Q7020912
- name: Pîçik
- description: Kurdish food
- countries: (none)
- kinds: dish

## DISH Q7022462
- name: Ngo hiang
- other names: {"zh": "五香滷肉"}
- description: Hokkien and Teochew dish
- countries: CN
- kinds: food, dish
- ingredients: tofu skin, five-spice powder
- has Wikipedia article: en, zh

## DISH Q7022523
- name: Ngome
- description: flatbread
- countries: ML
- kinds: food, flatbread
- ingredients: millet
- has Wikipedia article: en

## DISH Q70241
- name: Cold borscht
- description: traditional Ukrainian, Latvian, or Polish chilled soup made from beets and kefir
- countries: BY, LT, LV, PL, RU, UA
- cuisines: Polish cuisine, Latvian cuisine, Ukrainian cuisine, Belarusian cuisine, Lithuanian cuisine, Russian cuisine
- kinds: dish, cold sweet soup, beetroot soup
- ingredients: beet, cucumber, boiled egg, kefir
- has Wikipedia article: en

## DISH Q702662
- name: Xiaolongbao
- other names: {"zh": "小笼包"}
- description: steamed bun
- countries: CN
- cuisines: Taiwanese cuisine, Chinese cuisine
- kinds: baozi
- ingredients: Auricularia heimuer, Napa cabbage, Lentinula edodes, pork, dough
- has Wikipedia article: en, zh

## DISH Q702692
- name: Gujeolpan
- other names: {"zh": "九节坂"}
- description: Korean dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q7027594
- name: Qereş
- description: Kurdish candy
- countries: (none)
- kinds: confectionery
- ingredients: buttermilk, Prunus armeniaca, sugar

## DISH Q703015
- name: Doenjang-jjigae
- other names: {"zh": "大酱汤"}
- description: Korean dish of soybean paste stew
- countries: (none)
- kinds: jjigae
- ingredients: doenjang
- has Wikipedia article: en, zh

## DISH Q7030277
- name: Qirîs
- description: Kurdish dish
- countries: (none)
- kinds: dish
- ingredients: fruit, nut, meat

## DISH Q703147
- name: Hwajeon
- other names: {"zh": "花煎"}
- description: flower cakes
- countries: KR
- cuisines: Korean cuisine
- kinds: jeon, dish
- ingredients: jeon
- has Wikipedia article: en, zh

## DISH Q7031701
- name: Qopo
- description: Kurdish food
- countries: (none)
- kinds: dish
- ingredients: garlic, minced meat

## DISH Q703286
- name: Champon
- other names: {"zh": "什锦面"}
- description: Japanese noodle dish
- countries: JP
- kinds: dish, Japanese noodles
- ingredients: pork
- has Wikipedia article: en, zh

## DISH Q703313
- name: Sour rye soup
- other names: {"zh": "茹爾湯"}
- description: traditional West Slavic soup
- countries: PL
- kinds: dish, soup
- ingredients: oatmeal, sourdough, flour, water
- has Wikipedia article: en

## DISH Q703413
- name: Tteok
- other names: {"zh": "糍粑"}
- description: rice cakes in Korean cuisine
- countries: (none)
- kinds: mochi, rice cake
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q7034226
- name: Nihari
- description: South Asian meat stew
- countries: (none)
- kinds: food, soup
- ingredients: beef shank
- has Wikipedia article: en

## DISH Q7037735
- name: Nimono
- other names: {"zh": "日式煮物"}
- description: Japanese simmered dish
- countries: JP
- cuisines: Japanese cuisine
- kinds: food preparation technique, type of food or dish, food, soup
- has Wikipedia article: en

## DISH Q703832
- name: Arroz de marisco
- description: Portuguese seafood rice dish
- countries: PT
- cuisines: Portuguese cuisine
- kinds: seafood dish, rice dish
- ingredients: cockle as food, oyster as food, mussel as food, shrimp and prawn as food, cooked rice
- has Wikipedia article: en

## DISH Q704006
- name: Budae-jjigae
- other names: {"zh": "部队锅"}
- description: jjigae (Korean stew) made with ham, sausage, Spam, baked beans, kimchi and gochujang, invented shortly after the Korean War from scrounged or smuggled surplus foods from the U. S. army bases, after which the dish is named
- countries: KR
- kinds: food, soup, jjigae
- ingredients: baked beans, gochujang, Spam, ham, Kimchi, sausage
- has Wikipedia article: en, zh

## DISH Q7042787
- name: No-knead bread
- description: bread prepared with dough that is not kneaded
- countries: (none)
- kinds: bread, food preparation technique
- has Wikipedia article: en

## DISH Q704315
- name: Menma
- other names: {"zh": "笋干"}
- description: Japanese condiment made from fermented bamboo shoots
- countries: CN, JP
- kinds: fermented food
- ingredients: bamboo shoots
- has Wikipedia article: en, zh

## DISH Q7049396
- name: Sembîsek
- description: Dish from Kurdish cuisine
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: dish
- ingredients: minced meat, egg as food, onion

## DISH Q7049965
- name: Nopalito
- description: Mexican dish made with cactus
- countries: MX
- kinds: dish
- ingredients: tomato, nopal, Opuntia, Welsh onion
- has Wikipedia article: en

## DISH Q7050341
- name: Serbizêr
- description: Kurdish dish
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: dish
- ingredients: bulgur, rice

## DISH Q705123
- name: Yaksik
- other names: {"zh": "药食"}
- description: Korean dessert of glutinous rice, chestnuts, jujubes, and pine nuts
- countries: (none)
- kinds: dish
- ingredients: jujube, glutinous rice
- has Wikipedia article: en, zh

## DISH Q705369
- name: Fish ball
- other names: {"zh": "鱼丸"}
- description: balls made from fish paste which are then boiled or deep-fried
- countries: (none)
- kinds: minced food ball, fish dish
- has Wikipedia article: en, zh

## DISH Q705375
- name: Haejang-guk
- other names: {"zh": "解酲汤"}
- description: Korean soup
- countries: (none)
- kinds: guk, hangover food
- ingredients: Napa cabbage
- has Wikipedia article: en, zh

## DISH Q705381
- name: Wolgwa-chae
- other names: {"zh": "越瓜菜"}
- description: Korean food
- countries: (none)
- kinds: dish
- ingredients: muskmelon
- has Wikipedia article: en, zh

## DISH Q7055491
- name: Singûsîr
- description: dish of Kurdish cuisine
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: dish, lamb dish

## DISH Q7057222
- name: Soneberî
- description: Dish of Kurdish cuisine
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: dish
- ingredients: Capsicum, onion, meat

## DISH Q7057891
- name: Sovanî
- description: Kurdish dish
- countries: (none)
- kinds: dish
- ingredients: minced meat, onion, cooking oil

## DISH Q7060247
- name: Sînor
- description: Kurdish dish
- countries: (none)
- kinds: dish
- ingredients: quark, cheese

## DISH Q7060305
- name: Sîrmastok
- description: Garlic and yogurt sauce
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: food additive, sauce
- ingredients: garlic clove, cow's milk, peppercorn, yogurt, table salt

## DISH Q70608
- name: Smoked fish
- other names: {"zh": "薰魚"}
- description: fish preserved by smoking
- countries: (none)
- kinds: dish, cured fish, smoked food
- has Wikipedia article: en, zh

## DISH Q70612
- name: Granita PAT
- other names: {"zh": "Granita PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good, sorbet
- ingredients: shaved ice, sugar
- has Wikipedia article: en, zh

## DISH Q7061284
- name: Pariserbøf
- description: Danish dish
- countries: (none)
- kinds: beef dish

## DISH Q7062059
- name: Taweşeht
- description: Kurdish dish
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: dish
- ingredients: Lamb chops, cooking oil, onion, table salt

## DISH Q7063526
- name: Tepetep
- description: Köfte Type
- countries: (none)
- kinds: kofta, concoction
- ingredients: minced meat, chicken breast, oil, sodium chloride

## DISH Q70700789
- name: Kalsonnes b'rishta
- description: Stuffed pasta dish
- countries: (none)
- cuisines: Sephardic Jewish cuisine
- kinds: stuffed pasta

## DISH Q707636
- name: Weisswurst
- other names: {"zh": "巴伐利亚白香肠"}
- description: traditional Bavarian sausage
- countries: PL
- cuisines: Bavarian cuisine, Silesian cuisine, cuisine of Hamburg
- kinds: sausage, Brühwurst, veal dish
- ingredients: veal, pork
- has Wikipedia article: en, zh

## DISH Q707640
- name: Tangpyeongchae
- other names: {"zh": "荡平菜"}
- description: Korean salad dish
- countries: (none)
- kinds: salad
- ingredients: nokdu-muk
- has Wikipedia article: en, zh

## DISH Q707788
- name: Small sausage in large sausage
- other names: {"zh": "大肠包小肠"}
- description: Taiwanese snack sandwich
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q7079882
- name: Ogbono soup
- description: soup made with dry, ground Irvingia gabonensis (ogbono) seeds
- countries: NG
- kinds: soup
- ingredients: dika nut, spinach, onion, seasoning, palm oil, stockfish, beef, pumpkin, salt, water
- has Wikipedia article: en

## DISH Q7080021
- name: Ogi
- description: fermented cereal pudding from Nigeria, typically made from maize, sorghum, or millet
- countries: NG
- kinds: pap, dish, human food
- ingredients: cornmeal, millet
- has Wikipedia article: en

## DISH Q7080639
- name: Ohaw
- description: a savory soup of the Ainu people of northern Japan
- countries: JP
- cuisines: Ainu cuisine
- kinds: soup, hot pot
- ingredients: stock
- has Wikipedia article: en

## DISH Q7081432
- name: Oil noodles
- other names: {"zh": "油麵"}
- description: type of Chinese noodles
- countries: CN
- kinds: dish, Chinese noodles
- ingredients: wheat flour, noodle
- has Wikipedia article: en, zh

## DISH Q7081495
- name: Oille
- description: French soup
- countries: FR
- kinds: food, soup
- has Wikipedia article: en

## DISH Q7086753
- name: Olho-de-sogra
- description: Brazilian candy
- countries: BR
- kinds: food
- ingredients: Cocos nucifera
- has Wikipedia article: en

## DISH Q7087232
- name: Olive loaf
- description: type of meatloaf stuffed with olives
- countries: (none)
- kinds: cold cut, meatloaf, dish
- has Wikipedia article: en

## DISH Q7087234
- name: Olive salad
- description: Type of salad
- countries: (none)
- kinds: salad
- has Wikipedia article: en

## DISH Q708823
- name: Brittle
- other names: {"zh": "花生糖"}
- description: candy typically made with seeds or nuts
- countries: CN, FR, IT
- kinds: confectionery
- ingredients: caramel, nut
- has Wikipedia article: en, zh

## DISH Q7088254
- name: Ollada
- description: French stew
- countries: ES
- kinds: food, soup
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q708908
- name: Lo mai chi
- other names: {"zh": "糯米糍"}
- description: glutinous rice pastry with coconut powder and mungo cream
- countries: CN
- cuisines: Chinese cuisine
- kinds: pastry, dish
- ingredients: coconut
- has Wikipedia article: en, zh

## DISH Q708972
- name: Sanbeiji
- other names: {"zh": "三杯鸡"}
- description: Chinese and Taiwanese dish of chicken in soy sauce, sesame oil, and rice wine
- countries: CN
- kinds: chicken dish
- ingredients: rice wine, chicken as food, soy sauce, sesame oil
- has Wikipedia article: en, zh

## DISH Q70940386
- name: Liver mousse
- description: Spreadable mousse made wıth poultry liver
- countries: FR
- cuisines: French cuisine
- kinds: dish

## DISH Q7095366
- name: Oondees
- description: breakfast Delicacy of Mangalore
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q709554
- name: Bindae-tteok
- other names: {"zh": "朝鲜绿豆饼"}
- description: mung bean pancake
- countries: (none)
- kinds: buchimgae
- ingredients: Vigna radiata
- has Wikipedia article: en, zh

## DISH Q709812
- name: Ci fan tuan
- other names: {"zh": "粢饭团"}
- description: Chinese glutinous rice dish
- countries: CN
- kinds: type of food or dish, rice dish
- ingredients: youtiao
- has Wikipedia article: en, zh

## DISH Q7098418
- name: Opor ayam
- description: Indonesian dish
- countries: ID
- kinds: food, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q7099775
- name: Orange jelly candy
- other names: {"zh": "史蜜夫糖果廠"}
- description: type of confectionery
- countries: CN
- kinds: confectionery
- has Wikipedia article: en, zh

## DISH Q7105403
- name: Barley rice
- other names: {"zh": "麦饭"}
- countries: (none)
- kinds: rice dish

## DISH Q710618
- name: Oyster omelette
- other names: {"zh": "蚵仔煎"}
- description: dish
- countries: CN, TW
- kinds: egg dish, oyster dish
- ingredients: oyster, omelette
- has Wikipedia article: en, zh

## DISH Q7106559
- name: Osh
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q7107438
- name: Ossetra
- other names: {"zh": "奧斯特拉魚子醬"}
- description: eggs from Acipenser gueldenstaedtii used as food
- countries: (none)
- kinds: caviar
- has Wikipedia article: en, zh

## DISH Q7107766
- name: Ostropel
- countries: RO
- cuisines: Romanian cuisine, Moldovan cuisine
- kinds: food, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q711053
- name: Roasted sweet potatoes
- other names: {"zh": "烤白薯"}
- description: popular street food in East Asia
- countries: CN
- kinds: potato dish
- ingredients: sweet potato
- has Wikipedia article: en, zh

## DISH Q71129654
- name: Veggie patty
- description: vegetarian patty for burger
- countries: (none)
- kinds: patty, plant-based meat analogue

## DISH Q7116377
- name: Oysters Kirkpatrick
- description: oyster dish
- countries: (none)
- cuisines: cuisine of California
- kinds: oyster dish
- ingredients: scallion, oyster, bacon, cheese, Capsicum annuum
- has Wikipedia article: en

## DISH Q7116378
- name: Oysters Rockefeller
- other names: {"zh": "菠菜芝士焗蠔"}
- description: Type of oyster dish
- countries: US
- cuisines: Louisiana Creole cuisine
- kinds: oyster dish
- ingredients: oyster
- has Wikipedia article: en

## DISH Q7116380
- name: Oysters en brochette
- description: New Orleans Creole dish of skewered oysters and bacon
- countries: US
- kinds: food, oyster dish
- ingredients: oyster
- has Wikipedia article: en

## DISH Q71183889
- name: Petite marmite
- description: French soup cooked in earthenware pot
- countries: FR
- cuisines: French cuisine
- kinds: soup

## DISH Q711953
- name: Bibim guksu
- other names: {"zh": "骨董面"}
- description: Korean cold, spicy dish made with thin wheat flour noodles
- countries: KR
- cuisines: Korean cuisine
- kinds: Korean noodles, fried noodle
- ingredients: sōmen
- has Wikipedia article: en, zh

## DISH Q712031
- name: Ta-a noodles
- other names: {"zh": "担仔面"}
- description: Taiwanese noodle dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: pasta dish
- ingredients: Bah-sò, Metapenaeopsis barbata, noodle
- has Wikipedia article: en, zh

## DISH Q7124365
- name: Pagit-pagit
- description: North Sumatran dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q7124372
- name: Pagliata
- description: Italian dish from Rome
- countries: IT
- kinds: dish
- has Wikipedia article: en

## DISH Q7124456
- name: Pagpag
- other names: {"zh": "帕格帕格"}
- description: leftover food from restaurants scavenged from garbage sites/dumps; can also be expired frozen meat, fish, or vegetables discarded by supermarkets & scavenged in garbage trucks where this expired food is collected
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q7125094
- name: Chả rươi
- description: Vietnamese dish containing sandworms (Tylorrhynchus heterochaetus)
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: chả trứng, egg dish
- ingredients: Tylorrhynchus heterochaetus
- has Wikipedia article: en

## DISH Q712554
- name: Kimchi fried rice
- other names: {"zh": "泡菜炒饭"}
- countries: (none)
- kinds: bokkeum-bap
- ingredients: Kimchi
- has Wikipedia article: en, zh

## DISH Q7127448
- name: Paleta
- description: ice-cream treat made from fresh fruit
- countries: (none)
- kinds: ice pop

## DISH Q7127953
- name: Pallubasa
- description: a traditional spicy meat soup or stew from Makassar in South Sulawesi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: meal, dish, human food, type of food or dish
- ingredients: grated coconut, beef, offal, water
- has Wikipedia article: en

## DISH Q7129440
- name: Pamplona
- description: dish
- countries: UY
- kinds: dish
- has Wikipedia article: en

## DISH Q7129710
- name: Pan bati
- description: aruban bread
- countries: AN
- kinds: food, pancake
- ingredients: Sorghum
- has Wikipedia article: en

## DISH Q7129715
- name: Pan de coco
- description: Philippine sweet bread
- countries: PH
- kinds: food, sweet roll
- ingredients: Cocos nucifera
- has Wikipedia article: en

## DISH Q7129763
- name: Panaculty
- other names: {"zh": "英國燉鍋"}
- description: Beef casserole dish from North England
- countries: (none)
- kinds: beef dish, dish
- has Wikipedia article: en

## DISH Q7130182
- name: Panbrioche
- description: Italian style of bread
- countries: IT
- kinds: food, bread
- has Wikipedia article: en

## DISH Q7130487
- name: Pandan cake
- other names: {"zh": "斑蘭蛋糕"}
- description: Malaysian traditional cake originating from South East Asia
- countries: ID
- kinds: sponge cake
- ingredients: Pandanus amaryllifolius
- has Wikipedia article: en, zh

## DISH Q7130544
- name: Pandebono
- description: Colombian bread
- countries: CO
- cuisines: Colombian cuisine
- kinds: food, bread
- ingredients: corn starch
- has Wikipedia article: en

## DISH Q7130870
- name: Panfocaccia
- description: A type of bread that's very similar to Pocacha, one of the Italian dishes.
- countries: IT
- kinds: food, bread
- has Wikipedia article: en

## DISH Q7131157
- name: Paniki
- description: Indonesian traditional bat meat dish
- countries: ID
- kinds: food, main course

## DISH Q713125
- name: Ba-wan
- other names: {"zh": "肉圆"}
- description: Taiwanese street food
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: stuffed pasta
- has Wikipedia article: en, zh

## DISH Q7131930
- name: Pantua
- description: Bengali sweet
- countries: (none)
- kinds: confectionery
- ingredients: khoa, semolina, ghee, sugar, milk
- has Wikipedia article: en

## DISH Q7132009
- name: Panzerotti PAT
- other names: {"zh": "Panzerotti PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: turnover, food, baked good
- has Wikipedia article: en

## DISH Q7132274
- name: Paomo
- other names: {"zh": "泡馍"}
- description: Chinese traditional dish from Xi'an
- countries: CN
- kinds: stew, lamb dish, beef dish
- ingredients: Laobing, lamb meat, beef
- has Wikipedia article: en, zh

## DISH Q7132729
- name: Paper wrapped cake
- other names: {"zh": "紙包蛋糕"}
- description: type of Chinese cake
- countries: HK
- kinds: sponge cake
- ingredients: chiffon cake
- has Wikipedia article: en, zh

## DISH Q7133047
- name: Papo-de-anjo
- other names: {"zh": "Papo-de-anjo"}
- description: Portuguese dessert
- countries: PT
- kinds: food, egg dish, conventual sweets
- ingredients: egg yolk
- has Wikipedia article: en

## DISH Q713466
- name: Zongzi
- other names: {"zh": "粽"}
- description: traditional Chinese food
- countries: CN
- kinds: bánh, rice dish, dish, dumpling
- ingredients: Sasa, Juncus effusus, glutinous rice
- has Wikipedia article: en, zh

## DISH Q7136846
- name: Pares
- description: Filipino braised beef stew
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q7138331
- name: Parker House roll
- other names: {"zh": "派克賓館麵包卷"}
- description: Type of bread roll
- countries: US
- cuisines: cuisine of New England
- kinds: bread roll
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q713879
- name: Youtiao
- other names: {"zh": "油条"}
- description: churro-like cruller of Chinese origin
- countries: CN
- cuisines: Chinese cuisine
- kinds: food, dessert
- ingredients: dough
- has Wikipedia article: en, zh

## DISH Q713892
- name: Yong tau foo
- other names: {"zh": "客家酿豆腐"}
- description: Hakka dish of tofu filled with ground meat or fish
- countries: CN
- kinds: food, soup
- ingredients: tofu
- has Wikipedia article: en, zh

## DISH Q7139220
- name: Parmo
- description: English take-away dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q7140169
- name: Partan bree
- description: Scottish soup dish
- countries: (none)
- kinds: food, soup
- ingredients: Brachyura
- has Wikipedia article: en

## DISH Q7141239
- name: Parva
- description: bread
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q7141600
- name: Pasanda
- description: spicy meat dish originating from the Indian subcontinent
- countries: (none)
- kinds: food, lamb dish, Indian curry
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q7142035
- name: Pashti
- description: Indian flatbread
- countries: IN
- kinds: food, flatbread
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q7142949
- name: Pasta al pomodoro
- other names: {"zh": "蕃茄義大利麵"}
- description: typical Italian dish
- countries: IT
- kinds: dish, first course, pasta dish, tomato dish
- ingredients: basil, tomato sauce, pasta
- has Wikipedia article: en, zh

## DISH Q7142950
- name: Pasta primavera
- description: American dish consisting of pasta and fresh vegetables
- countries: CA
- kinds: pasta dish
- ingredients: pasta
- has Wikipedia article: en

## DISH Q7142958
- name: Paste
- description: Mexican pastry
- countries: MX
- kinds: food, pie
- has Wikipedia article: en

## DISH Q7143007
- name: Pastie
- other names: {"zh": "愛爾蘭炸魚薯條"}
- description: pork dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q7143016
- name: Pastitsada
- description: Greek pasta dish
- countries: (none)
- kinds: dish, traditional food
- has Wikipedia article: en

## DISH Q7143097
- name: Pastry heart
- description: Heart-shaped puff pastry dessert
- countries: US
- kinds: food, pastry
- ingredients: puff pastry
- has Wikipedia article: en

## DISH Q7145091
- name: Eggplant kebab
- description: Turkish kebab made with eggplant and meat
- countries: TR
- cuisines: Şanlıurfa cuisine
- kinds: food, kebab
- ingredients: eggplant, meat
- has Wikipedia article: en

## DISH Q7145144
- name: Pato no tucupi
- description: Brazilian duck dish
- countries: BR
- kinds: dish
- ingredients: duck meat, tucupi
- has Wikipedia article: en

## DISH Q7145207
- name: Patra ni machhi
- description: Parsi dish made from steamed fish topped with chutney and wrapped in a banana leaf
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q7148573
- name: Patties pie
- description: Australian food manufacturing company
- countries: AU
- kinds: pie
- has Wikipedia article: en

## DISH Q7148741
- name: Patty melt
- description: type of sandwich
- countries: US
- kinds: hamburger, food
- ingredients: cheese, rye bread, Onion, ground beef
- has Wikipedia article: en

## DISH Q715040
- name: Japchae
- other names: {"zh": "什锦炒菜"}
- description: Korean dish of stir-fried glass noodles and vegetables
- countries: (none)
- kinds: dish, Korean noodles, pasta dish
- ingredients: cellophane noodles
- has Wikipedia article: en, zh

## DISH Q715084
- name: Naengmyeon
- other names: {"zh": "朝鲜冷面"}
- description: Korean dish of cold noodles
- countries: KP
- kinds: tradition, type of food or dish, Korean noodles, dish, cold noodle
- ingredients: noodle
- has Wikipedia article: en, zh

## DISH Q71538197
- name: Käsesahnetorte
- other names: {"de": "Käsesahnetorte"}
- countries: (none)
- kinds: torte
- ingredients: cream

## DISH Q715525
- name: Spring roll
- other names: {"zh": "春卷"}
- description: type of dim sum
- countries: CN
- kinds: meal, dim sum
- has Wikipedia article: en, zh

## DISH Q715544
- name: Nian gao
- other names: {"zh": "年糕"}
- description: Chinese food
- countries: CN
- kinds: rice cake, rice dish
- has Wikipedia article: en, zh

## DISH Q715546
- name: Douhua
- other names: {"zh": "豆花"}
- description: Chinese dessert
- countries: CN
- kinds: dessert
- ingredients: tofu
- has Wikipedia article: en, zh

## DISH Q7157123
- name: Paški baškotin
- description: Croatian zwieback rusk bread
- countries: HR
- kinds: food, rusk
- has Wikipedia article: en

## DISH Q7157930
- name: Peanut butter cookie
- description: food
- countries: US
- kinds: cookie
- ingredients: peanut butter
- has Wikipedia article: en

## DISH Q7157931
- name: Peanut butter cup
- description: candy
- countries: US
- kinds: candy, confectionery
- ingredients: peanut butter, chocolate
- has Wikipedia article: en

## DISH Q7157935
- name: Peanut butter bun
- description: food, baked goods
- countries: HK
- kinds: food, bun
- ingredients: peanut butter
- has Wikipedia article: en

## DISH Q7158585
- name: Pebete
- description: South American bun
- countries: AR
- kinds: food, sandwich
- ingredients: bun, tomato, mayonnaise, meat, cheese
- has Wikipedia article: en

## DISH Q7160523
- name: Peg bread
- description: Jamaican and West Indian bread
- countries: JM
- kinds: food, bread
- has Wikipedia article: en

## DISH Q7161062
- name: Peking pork
- other names: {"zh": "京都排骨"}
- description: meat dish
- countries: (none)
- kinds: pork dish
- ingredients: pork ribs
- has Wikipedia article: en, zh

## DISH Q7162838
- name: Penia
- description: type of sweet Italian bread
- countries: IT
- kinds: Easter bread, Easter cake, sweet bread
- ingredients: sugar
- has Wikipedia article: en

## DISH Q7163401
- name: Penne alla vodka
- other names: {"zh": "伏特加直通粉"}
- description: italian-American pasta dish
- countries: IT, US
- kinds: food, pasta dish
- ingredients: penne, tomato, cream, vodka
- has Wikipedia article: en, zh

## DISH Q716464
- name: Pajeon
- other names: {"zh": "朝鲜葱饼"}
- description: Korean scallion pancake
- countries: (none)
- kinds: jeon
- ingredients: scallion, batter
- has Wikipedia article: en, zh

## DISH Q716622
- name: Anju
- other names: {"zh": "下酒小吃"}
- description: food accompanying alcohol
- countries: (none)
- kinds: food, cuisine
- has Wikipedia article: en, zh

## DISH Q7166384
- name: Pepper jack cheese
- description: type of cheese
- countries: US
- kinds: cheese, cow's-milk cheese
- has Wikipedia article: en

## DISH Q71667321
- name: Sochnik
- description: food
- countries: RU
- cuisines: Russian cuisine
- kinds: pastry, pirog
- ingredients: tvorog, smetana, flour, butter

## DISH Q7167670
- name: Perdeli pilav
- description: Turkish "pilav" dish in "yufka"
- countries: TR
- kinds: food, rice dish, chicken dish, bread dish
- ingredients: yufka bread, chicken as food, almond, rice
- has Wikipedia article: en

## DISH Q716797
- name: Songpyeon
- other names: {"zh": "松片"}
- description: Korean pastry
- countries: (none)
- kinds: stuffed pasta
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q716820
- name: Hiyashi chūka
- other names: {"zh": "凉面"}
- description: chilled ramen noodles with various toppings
- countries: JP
- kinds: ramen, cold noodle
- has Wikipedia article: en, zh

## DISH Q7168413
- name: Perico
- description: dish
- countries: CO, VE
- kinds: egg dish
- has Wikipedia article: en

## DISH Q716842
- name: Miyeok-guk
- other names: {"zh": "海带汤"}
- description: Korean soup made from wakame
- countries: (none)
- kinds: food, soup, guk
- ingredients: wakame
- has Wikipedia article: en, zh

## DISH Q7169555
- name: Perpetual stew
- other names: {"zh": "永久浓汤"}
- description: pot into which diverse foodstuff is placed and cooked and rarely emptied, with ingredients and liquid replenished as necessary
- countries: (none)
- kinds: food, stew
- ingredients: vegetable, meat, fish
- has Wikipedia article: en, zh

## DISH Q7170197
- name: Persian
- description: sweet roll
- countries: CA
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q7170363
- name: Persimmon pudding
- description: traditional American dessert
- countries: US
- kinds: dessert, pudding
- ingredients: persimmon
- has Wikipedia article: en

## DISH Q717113
- name: Yukhoe
- other names: {"zh": "肉脍"}
- description: raw meat dish in Korean cuisine that resembles a steak tartare
- countries: (none)
- kinds: raw beef dish
- has Wikipedia article: en, zh

## DISH Q7171328
- name: Pesarattu
- description: type of Indian bread
- countries: (none)
- kinds: dish, dosa
- ingredients: Vigna radiata
- has Wikipedia article: en

## DISH Q717136
- name: Seolleongtang
- other names: {"zh": "先农汤"}
- description: Korean broth tang of ox bones, brisket, and other meat cuts
- countries: (none)
- cuisines: Seoul cuisine
- kinds: soup, guk
- ingredients: beef
- has Wikipedia article: en, zh

## DISH Q717435
- name: Mantecado
- countries: ES
- kinds: dessert

## DISH Q717628
- name: Pork ball
- other names: {"zh": "贡丸"}
- description: traditional Taiwanese pork dish
- countries: CN
- cuisines: Taiwanese cuisine
- kinds: food, meatball, pork dish
- has Wikipedia article: en, zh

## DISH Q7178377
- name: Petit Salé
- description: salted pork
- countries: FR
- cuisines: French cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q718010
- name: Suncake
- other names: {"zh": "太阳饼"}
- description: food
- countries: TW
- kinds: food, pancake
- ingredients: maltose
- has Wikipedia article: en, zh

## DISH Q7180306
- name: Phall
- description: British Asian curry Indian dish
- countries: GB
- cuisines: British cuisine
- kinds: food, curry in the United Kingdom
- ingredients: tomato, chili pepper
- has Wikipedia article: en

## DISH Q7181083
- name: Phat phrik khing
- description: Thai curry, fried in oil without coconut milk
- countries: TH
- kinds: Thai curry
- ingredients: Cymbopogon citratus leaf, garlic, galangal, chili pepper
- has Wikipedia article: en

## DISH Q71819512
- name: Fried cauliflower
- description: widespread dish in Europe, Middle East, and Asia
- countries: (none)
- kinds: salad, vegetable dish
- ingredients: cauliflower
- has Wikipedia article: en

## DISH Q7182763
- name: Philadelphia pepper pot
- other names: {"zh": "费城胡椒羹"}
- description: type of tripe soup
- countries: US
- kinds: food, soup
- has Wikipedia article: en, zh

## DISH Q7185336
- name: Char siu egg rice
- other names: {"zh": "黯然销魂饭"}
- description: fictional rice dish from film ''God of Cookery'' made into reality
- countries: (none)
- kinds: rice dish
- has Wikipedia article: en, zh

## DISH Q7186598
- name: Pho Ta
- description: Restaurant located in Ho Chi Minh City
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q71870736
- name: Bramata
- countries: (none)
- kinds: dish
- ingredients: maize

## DISH Q7188272
- name: Phú Quốc fish sauce
- other names: {"zh": "富國魚露"}
- description: Vietnamese fish sauce
- countries: (none)
- cuisines: An Giang cuisine
- kinds: designation of origin, nước mắm
- has Wikipedia article: en, zh

## DISH Q7188391
- name: Phutu
- description: South African dish prepared from cornmeal
- countries: (none)
- kinds: porridge
- ingredients: cornmeal

## DISH Q7190902
- name: Pickled beet egg
- description: hard boiled eggs cured in a brine of beets, beet juice, vinegar, sugar and spices
- countries: (none)
- kinds: egg dish
- has Wikipedia article: en

## DISH Q7190909
- name: Pickled pepper
- other names: {"zh": "泡椒"}
- description: Capsicum pepper preserved by pickling
- countries: (none)
- kinds: vegetable, antipasto, pickling, preserved food
- has Wikipedia article: en, zh

## DISH Q7191330
- name: Pie à la Mode
- description: pie served with ice cream or cream
- countries: US
- kinds: pie
- has Wikipedia article: en

## DISH Q7193190
- name: Pig's organ soup
- other names: {"zh": "豬雜湯"}
- description: wikimedia template
- countries: CN
- kinds: soup, pork dish
- has Wikipedia article: en

## DISH Q7193343
- name: Pigeon pie
- description: French cuisine game dish
- countries: FR
- kinds: game pie, poultry dish
- ingredients: pigeon meat, Columbidae
- has Wikipedia article: en

## DISH Q7193679
- name: Piki
- description: hopi cornmeal bread
- countries: US
- kinds: food, bread
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q7193747
- name: Pilaki
- description: Turkish cuisine cold dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q7193919
- name: Thanksgiving sandwich
- description: American sandwich
- countries: US
- cuisines: cuisine of New England
- kinds: sandwich, leftovers
- ingredients: turkey meat
- has Wikipedia article: en

## DISH Q7194233
- name: Pillus
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q71947461
- name: Palabirabrot
- description: Traditional bread of the Venosta Valley in Italy
- countries: IT
- kinds: bread

## DISH Q7194877
- name: Pinca
- description: variety of Easter bread
- countries: HR
- kinds: Easter bread, Easter cake
- ingredients: flour
- has Wikipedia article: en

## DISH Q7194962
- name: Pinconning cheese
- description: type of semi-hard cheese
- countries: US
- kinds: American cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q7195419
- name: Pine honey
- description: type of Honeydew honey
- countries: (none)
- kinds: honeydew honey
- ingredients: honeydew
- has Wikipedia article: en

## DISH Q7195431
- name: Pineapple lumps
- description: confection
- countries: NZ
- kinds: confectionery
- ingredients: chocolate
- has Wikipedia article: en

## DISH Q7195443
- name: Pineapple tart
- other names: {"zh": "黃梨餅"}
- description: asian small pastries filled with pineapple jam
- countries: ID
- kinds: pie, Kuih, food
- ingredients: pineapple jam
- has Wikipedia article: en, zh

## DISH Q7195901
- name: Pinikpikan
- description: Traditional dish in Philippines
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q7196129
- name: Pink wafer
- countries: GB
- kinds: food, biscuit
- ingredients: wafer, cream
- has Wikipedia article: en

## DISH Q7196890
- name: Pionono
- description: Spanish pastry
- countries: ES
- kinds: food, pastry, meal
- has Wikipedia article: en

## DISH Q7197643
- name: Piracaldo
- description: fish soup typical of Paraguay
- countries: PY
- cuisines: Paraguayan cuisine
- kinds: fish soup, soup, dish, fish dish
- has Wikipedia article: en

## DISH Q7197677
- name: Piragua
- description: Puerto Rican dessert
- countries: PR
- kinds: food, shaved ice
- has Wikipedia article: en

## DISH Q7198220
- name: Pisca Andina
- description: Venezuelan soup
- countries: VE
- kinds: food, soup
- ingredients: parsley, broth
- has Wikipedia article: en

## DISH Q7198451
- name: Pistachio pudding
- description: pudding made with pistachio nuts
- countries: (none)
- kinds: pudding, dessert
- ingredients: pistachio nut
- has Wikipedia article: en

## DISH Q7198502
- name: Pistolette
- description: cuisine in Louisiana, US
- countries: US
- kinds: food, sandwich
- ingredients: bread roll
- has Wikipedia article: en

## DISH Q71988103
- name: Plombières
- description: Frozen custard
- countries: FR
- cuisines: French cuisine
- kinds: dessert, frozen custard

## DISH Q7198960
- name: Piti
- other names: {"zh": "Piti"}
- description: Armenian dish with meat and chickpeas
- countries: AZ
- kinds: food, stew
- ingredients: chickpea, lamb meat
- has Wikipedia article: en, zh

## DISH Q7199459
- name: Pittsburgh rare
- description: steak cooking method
- countries: (none)
- kinds: raw beef dish
- has Wikipedia article: en

## DISH Q7199982
- name: Pizza bagel
- other names: {"zh": "百吉餅披薩"}
- description: bagel with pizza toppings
- countries: IT
- kinds: type of pizza, bagel
- has Wikipedia article: en

## DISH Q7199983
- name: Pizza al taglio
- other names: {"zh": "Pizza al taglio"}
- description: Pizza baked in large rectangular trays, sold by the slice
- countries: (none)
- kinds: type of pizza
- has Wikipedia article: en, zh

## DISH Q7199987
- name: Pizza in the United States
- other names: {"zh": "美国的披萨"}
- countries: US
- cuisines: cuisine of the United States
- has Wikipedia article: en

## DISH Q7199990
- name: Pizza strips
- countries: US
- ingredients: tomato sauce, Origanum vulgare
- has Wikipedia article: en

## DISH Q7200291
- name: Placenta cake
- other names: {"zh": "胎盘蛋糕"}
- description: cheesecake recipe from ancient Greece
- countries: (none)
- kinds: dish, food, cheesecake
- has Wikipedia article: en, zh

## DISH Q7200650
- name: Plain loaf
- description: traditional style of loaf
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q7202208
- name: Plate steak
- description: cut of beef
- countries: (none)
- kinds: beefsteak
- has Wikipedia article: en

## DISH Q720230
- name: Rojak
- other names: {"zh": "囉喏"}
- description: Indonesian traditional fruit and vegetable dish originating from Java island
- countries: ID
- cuisines: Indonesian cuisine
- kinds: rujak cingur, rujak soto, jajan pasar, salad, street food, dish, human food, type of food or dish
- ingredients: table salt, vegetable, sugar, fruit, petis, Menjes, Indonesian peanut sauces, tofu, Tempeh
- has Wikipedia article: en, zh

## DISH Q7202517
- name: Potsticker
- other names: {"zh": "锅贴"}
- countries: CN, TW
- kinds: dish
- has Wikipedia article: zh

## DISH Q720254
- name: Asado
- other names: {"zh": "阿根廷烤肉"}
- description: Latin-American dish of beef, sausages, and sometimes other meats, cooked on a grill (parrilla) or an open fire
- countries: AR
- cuisines: Argentine cuisine
- kinds: meat dish
- ingredients: lamb meat, beef, pork, blood sausage, llama, chorizo
- has Wikipedia article: en, zh

## DISH Q7202578
- name: Gabacai
- other names: {"zh": "锅巴菜"}
- description: snack in Tianjin
- countries: CN
- kinds: stew
- has Wikipedia article: en, zh

## DISH Q7204354
- name: Plecing ayam
- description: traditional food from Indonesia
- countries: ID
- kinds: meal, chicken dish
- has Wikipedia article: en

## DISH Q7204728
- name: Pletzel
- description: type of Jewish flatbread
- countries: (none)
- kinds: food, cracker
- has Wikipedia article: en

## DISH Q7205916
- name: Plátanos rellenos
- description: Caribbean dish
- countries: MX
- kinds: dish
- has Wikipedia article: en

## DISH Q7206451
- name: Pocket sandwich
- description: bread-based foodstuff
- countries: (none)
- kinds: food, sandwich
- ingredients: bread
- has Wikipedia article: en

## DISH Q7207180
- name: Poduthol
- description: South Indian side dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q7208574
- name: Poke
- other names: {"zh": "夏威夷盖饭"}
- description: Hawaiian raw fish dish
- countries: US
- kinds: dish, salad, tuna dish, raw fish dish
- ingredients: yellowfin tuna, sashimi, rice
- has Wikipedia article: en, zh

## DISH Q7208575
- name: Poke salad
- description: Wikimedia disambiguation page
- countries: (none)
- kinds: Wikimedia disambiguation page, salad
- has Wikipedia article: en

## DISH Q7210540
- name: Pork knuckles and ginger stew
- other names: {"zh": "猪脚姜"}
- description: traditional Cantonese dish made of pork trotters, ginger, sweet vinegar and eggs
- countries: CN
- kinds: dish
- ingredients: pig's trotters, ginger
- has Wikipedia article: en, zh

## DISH Q7211324
- name: Egg shrimp cracker
- other names: {"zh": "蛋散"}
- countries: (none)
- kinds: cracker
- ingredients: shrimp and prawn as food, egg as food
- has Wikipedia article: zh

## DISH Q7211348
- name: Fried oysters
- other names: {"zh": "蚵嗲"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: oyster dish, dish
- ingredients: chicken egg, mung bean sprout, wheat flour, pork, oyster, Brassica oleracea var. capitata, Welsh onion
- has Wikipedia article: zh
