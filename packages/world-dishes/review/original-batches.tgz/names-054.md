# Review batch names-054

## DISH Q7605452
- name: Steamed bread
- description: Bread made by steaming, not baking
- countries: (none)
- kinds: food, bread
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q7605458
- name: Steamed clams
- description: Seafood dish consisting of clams
- countries: (none)
- kinds: clam dish
- has Wikipedia article: en

## DISH Q7605615
- name: Steel-cut oats
- other names: {"zh": "燕麥碎粒"}
- description: groats of whole oats cut into pieces
- countries: (none)
- kinds: food, intermediate product, groat, oatmeal
- ingredients: oats
- has Wikipedia article: en

## DISH Q7608917
- name: Stephen Colbert's AmeriCone Dream
- description: ben & Jerry's ice cream flavor
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q761524
- name: Brocciu
- description: Corsican cheese
- countries: (none)
- kinds: cheese, sheep milk cheese, whey cheese, French cheese, farmstead cheese, industrial cheese, dairy cheese
- ingredients: whey, sheep milk, goat milk
- has Wikipedia article: en

## DISH Q76160299
- name: Semolina soup
- description: soup with semolina
- countries: (none)
- kinds: soup

## DISH Q7616232
- name: Stick candy
- description: long, cylindrical hard candy with different colors and flavors swirled together
- countries: US
- kinds: hard candy
- ingredients: sugar
- has Wikipedia article: en

## DISH Q7616330
- name: Sticky bun
- description: Type of dessert or breakfast sweet roll
- countries: (none)
- kinds: food, sweet roll
- has Wikipedia article: en

## DISH Q7616334
- name: Sticky toffee pudding
- other names: {"zh": "黏太妃糖蛋糕"}
- description: dessert
- countries: GB
- kinds: pudding
- ingredients: date, sponge cake
- has Wikipedia article: en

## DISH Q7619467
- name: Stonner kebab
- description: pork sausage wrapped in strips of döner meat, coated in two layers of batter, and then deep fried, served on a bed of chips
- countries: GB
- kinds: kebab, dish
- has Wikipedia article: en

## DISH Q7620532
- name: Stottie cake
- other names: {"zh": "奶油扁麵包"}
- description: type of bread that originated in North East England
- countries: (none)
- kinds: food, bread
- has Wikipedia article: en

## DISH Q7622416
- name: Strawberry Delight
- other names: {"zh": "草莓喜悦"}
- description: desert salad
- countries: US
- cuisines: cuisine of the United States
- kinds: dessert salad, Strawberry salad
- ingredients: strawberry, gelatin dessert, cracker, whipped cream, cream cheese
- has Wikipedia article: en, zh

## DISH Q762285
- name: Dakos
- description: Greek cuisine starter
- countries: GR
- kinds: meze, salad, bread salad
- has Wikipedia article: en

## DISH Q7628544
- name: Stuffed chine
- description: traditional dish of Lincolnshire
- countries: GB
- kinds: pork dish
- has Wikipedia article: en

## DISH Q7628546
- name: Stuffed clam
- description: American seafood dish
- countries: (none)
- kinds: clam dish
- has Wikipedia article: en

## DISH Q7628547
- name: Stuffed ham
- description: Ham dish from Maryland, United States
- countries: (none)
- kinds: pork dish
- ingredients: ham
- has Wikipedia article: en

## DISH Q7629815
- name: Styrian sour soup
- description: Austrian sour soup
- countries: SI
- kinds: food, sour soup
- ingredients: pork
- has Wikipedia article: en

## DISH Q7630441
- name: Suadero
- description: Mexican cuisine
- countries: MX
- kinds: beef dish
- ingredients: beef
- has Wikipedia article: en

## DISH Q7630465
- name: Suama
- other names: {"zh": "壽甘"}
- description: Japanese sweet
- countries: JP
- kinds: saogashi
- ingredients: jōshinko
- has Wikipedia article: en

## DISH Q7630489
- name: Chaoshou
- description: spicy sauce over steamed, meat-filled dumplings
- countries: CN
- kinds: stuffed pasta
- has Wikipedia article: en

## DISH Q7634410
- name: Suet pudding
- other names: {"zh": "板油布丁"}
- description: pudding made with wheat flour and suet
- countries: GB
- kinds: food, pudding
- ingredients: suet
- has Wikipedia article: en, zh

## DISH Q7634940
- name: Sugar cake
- description: confectionery made from sugar
- countries: (none)
- kinds: confectionery
- ingredients: coconut
- has Wikipedia article: en

## DISH Q7634947
- name: Sugar mice
- other names: {"zh": "糖鼠"}
- description: traditional sugar candy popular in the United Kingdom
- countries: GB
- kinds: confectionery
- ingredients: powdered sugar
- has Wikipedia article: en

## DISH Q7634957
- name: Sugar plum
- other names: {"zh": "糖梅"}
- description: hard candy
- countries: (none)
- kinds: dragée
- has Wikipedia article: en

## DISH Q7636918
- name: Sumaghiyyeh
- description: Palestinian dish
- countries: TR
- kinds: food, stew
- ingredients: chard, chickpea, lamb meat, tehina, beef, Rhus
- has Wikipedia article: en

## DISH Q7640203
- name: Sungeoguk
- description: North Korean soup dish
- countries: (none)
- cuisines: North Korean cuisine
- kinds: food, soup, fish dish
- ingredients: trout
- has Wikipedia article: en

## DISH Q7641870
- name: Sup kambing
- other names: {"zh": "馬來羊肉湯"}
- description: Indonesian dish
- countries: ID
- kinds: food, soup
- ingredients: lamb meat
- has Wikipedia article: en, zh

## DISH Q7643870
- name: Superman
- description: ice cream that comes as a swirl of three colors: blue, red, and yellow (the colors of Superman)
- countries: US
- kinds: ice cream
- has Wikipedia article: en

## DISH Q7648934
- name: Sushi pizza
- description: variant of Japanese sushi served in Canada
- countries: CA
- kinds: sushi, dish
- ingredients: Oryza molida, sushi
- has Wikipedia article: en

## DISH Q7649469
- name: Sussex Pond Pudding
- other names: {"zh": "索賽克斯池塘布丁"}
- description: English pudding
- countries: GB
- kinds: pudding
- ingredients: lemon, tallow, pastry
- has Wikipedia article: en, zh

## DISH Q7649699
- name: Sustainable sushi
- description: sushi made from fished or farmed sources that can be maintained or whose future production does not significantly jeopardize the ecosystems from which it is acquired
- countries: (none)
- kinds: sushi, sustainable food
- has Wikipedia article: en

## DISH Q7650627
- name: Suya
- other names: {"zh": "苏亚"}
- description: snack of skewered meat popular in Nigeria and Cameroon originating from the Hausa people
- countries: NG
- cuisines: Nigerian cuisine
- kinds: meat dish, meat, dish
- ingredients: Skewered Goose Liver, ram, tripe, goat meat, beef, meat, cayenne pepper, chicken
- has Wikipedia article: en, zh

## DISH Q765257
- name: Graham bread
- other names: {"zh": "格雷厄姆面包"}
- description: type of bread inspired by Sylvester Graham in 1829
- countries: US
- kinds: bread
- ingredients: whole-wheat flour
- has Wikipedia article: en

## DISH Q7654273
- name: Swede casserole
- description: Finnish Christmas casserole dish
- countries: FI
- cuisines: Finnish cuisine
- kinds: dish
- ingredients: turnip
- has Wikipedia article: en

## DISH Q7654664
- name: Swedish Fish
- description: fish-shaped chewy candy
- countries: SE
- kinds: candy
- has Wikipedia article: en

## DISH Q7654910
- name: Swedish berries
- description: Canadian Candy
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q765540
- name: Munster
- other names: {"zh": "芒斯特芝士"}
- description: type of French cheese
- countries: FR
- kinds: French cheese, cow's-milk cheese, farmstead cheese, washed-rind cheese, dairy cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q7655635
- name: Sweet roll
- other names: {"zh": "甜捲"}
- description: baked yeast-leavened dessert or breakfast
- countries: (none)
- kinds: pastry, sweet bread
- has Wikipedia article: en

## DISH Q7655664
- name: Sweetened potato casserole
- description: Finnish dish
- countries: FI
- kinds: potato casserole, Christmas food
- ingredients: potato, wheat flour
- has Wikipedia article: en

## DISH Q7656154
- name: Swikee
- description: Chinese-Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish
- ingredients: frog legs
- has Wikipedia article: en

## DISH Q7659027
- name: Swiss steak
- description: braised meat dish
- countries: CH
- kinds: meat dish
- ingredients: beef
- has Wikipedia article: en

## DISH Q7666782
- name: Sütlü Nuriye
- description: Turkish dessert
- countries: TR
- kinds: dessert, dish
- ingredients: dough
- has Wikipedia article: en

## DISH Q766777
- name: Relish
- other names: {"zh": "开味小菜"}
- description: cooked, pickled, or chopped vegetable or fruit food item typically used as a condiment
- countries: (none)
- kinds: salad, sauce, condiment
- ingredients: cucumber
- has Wikipedia article: en

## DISH Q766999
- name: Moretum
- description: herb cheese spread
- countries: (none)
- kinds: spread
- ingredients: herb, olive oil, vinegar, Allium sativum, cheese
- has Wikipedia article: en

## DISH Q7673579
- name: Tabrizi Lovuz
- description: diamond-shape almond dish
- countries: (none)
- kinds: pastry, shortbread
- ingredients: almond meal
- has Wikipedia article: en

## DISH Q7675057
- name: Taftan
- other names: {"zh": "塔夫坦"}
- description: Asian bread
- countries: IR
- kinds: food, bread
- ingredients: egg as food, flour, yogurt, milk
- has Wikipedia article: en

## DISH Q7675482
- name: Tahinli pide
- description: pide sort (sweet)
- countries: TR
- kinds: pide, food
- ingredients: tehina
- has Wikipedia article: en

## DISH Q7675683
- name: Tahu goreng
- description: Southeast Asian fried tofu
- countries: MY
- cuisines: Malay cuisine
- kinds: fried tofu
- ingredients: tofu
- has Wikipedia article: en

## DISH Q767952
- name: Bleu du Vercors-Sassenage
- other names: {"zh": "韦科尔-萨瑟纳日蓝纹奶酪"}
- description: French cheese
- countries: FR
- kinds: French cheese, blue cheese, raw-milk cheese, cow's-milk cheese, farmstead cheese, dairy cheese, pasteurized milk cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q767956
- name: Bò 7 món
- description: set selection of beef dishes in Vietnamese cuisine
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q7680375
- name: Talunan
- description: Filipino food
- countries: PH
- kinds: food, soup
- ingredients: meat
- has Wikipedia article: en

## DISH Q7684416
- name: Tapalapa
- description: traditional African bread
- countries: SN
- kinds: food, bread
- has Wikipedia article: en

## DISH Q76846839
- name: Panino con porchetta
- description: sandwich
- countries: IT
- kinds: sandwich

## DISH Q768596
- name: Michetta
- description: Italian white bread
- countries: IT
- kinds: bread
- has Wikipedia article: en

## DISH Q7686514
- name: Taro ball
- other names: {"zh": "芋圆"}
- description: traditional Taiwanese cuisine dessert made of taro
- countries: TW
- kinds: food, dessert
- has Wikipedia article: en, zh

## DISH Q7687656
- name: Tasso ham
- description: smoked, spiced, and cured meat made from hog's shoulder
- countries: (none)
- kinds: ham
- has Wikipedia article: en

## DISH Q76883719
- name: Tempura udon
- description: Japanese dish
- countries: JP
- kinds: dish, udon
- ingredients: udon, tempura, soup

## DISH Q7688659
- name: Tauco
- other names: {"zh": "豆醬"}
- description: Indonesian fermented bean paste
- countries: CN
- kinds: fermented bean paste
- ingredients: soy bean, bean
- has Wikipedia article: en

## DISH Q7689067
- name: Tavern sandwich
- description: sandwich
- countries: US
- kinds: food, beef dish
- ingredients: bun, ground beef, onion
- has Wikipedia article: en

## DISH Q7691132
- name: Tea loaf
- description: English cake
- countries: GB
- kinds: food, cake
- ingredients: fruit
- has Wikipedia article: en

## DISH Q7691137
- name: Tea sandwich
- other names: {"zh": "茶點三明治"}
- description: small prepared sandwich meant to be eaten at afternoon teatime to stave off hunger until the main meal
- countries: GB
- cuisines: British cuisine
- kinds: sandwich
- has Wikipedia article: en

## DISH Q76928331
- name: Gosht
- description: class of South Asian meat dishes typically constituent of goat meat
- countries: (none)
- cuisines: South Asian cuisine
- kinds: type of food or dish, meat dish, goat meat dish
- has Wikipedia article: en

## DISH Q7694913
- name: Tehri
- description: Food
- countries: IN
- kinds: rice dish
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q7694989
- name: Teiglach
- description: small, knotted pastries boiled in a honeyed syrup
- countries: IL
- cuisines: Jewish cuisine
- kinds: pastry
- ingredients: honey
- has Wikipedia article: en

## DISH Q7695520
- name: Tekwan
- description: Indonesian's traditional food
- countries: ID
- cuisines: Indonesian cuisine, Palembang cuisine
- kinds: fish dish, soup, dish, human food, type of food or dish
- ingredients: fishcake, sago, shrimp and prawn as food, egg white, fish as food
- has Wikipedia article: en

## DISH Q769635
- name: Biscotti
- other names: {"zh": "義式脆餅"}
- description: twice-baked cookies or biscuits originating in the Italian city of Prato
- countries: IT
- cuisines: Italian cuisine
- kinds: biscuit
- ingredients: egg as food, flour, sugar
- has Wikipedia article: en, zh

## DISH Q7705355
- name: Terva Leijona
- description: Finnish liquorice candy
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q7706778
- name: Tetrazzini
- description: dish made with diced poultry or seafood and mushroom in a butter/cream and cheese sauce
- countries: US
- cuisines: Italian-American cuisine
- kinds: dish
- ingredients: poultry meat, Parmesan, cream, pasta
- has Wikipedia article: en

## DISH Q7709195
- name: Thai salads
- other names: {"zh": "泰式沙拉"}
- description: Thai cuisine
- countries: TH
- kinds: salad
- has Wikipedia article: en

## DISH Q7709199
- name: Thai suki
- other names: {"zh": "泰式壽喜燒"}
- description: Thai hot pot
- countries: TH
- kinds: hot pot
- has Wikipedia article: en, zh

## DISH Q770977
- name: Caldo verde
- other names: {"zh": "葡式甘蓝汤"}
- description: Portuguese soup
- countries: CN, PT
- kinds: soup
- ingredients: potato
- has Wikipedia article: en, zh

## DISH Q771079
- name: Freekeh
- other names: {"zh": "翡麦"}
- description: cereal food made from green durum wheat
- countries: PS
- kinds: food, type of food or dish
- ingredients: Triticum durum, broth
- has Wikipedia article: en, zh

## DISH Q77119653
- name: Velouté d'asperges
- other names: {"fr": "velouté d'asperges"}
- countries: (none)
- kinds: cream soup

## DISH Q771456
- name: Chikuwa
- other names: {"zh": "竹輪"}
- description: Japanese fishcake
- countries: JP
- cuisines: Japanese cuisine
- kinds: food product, kamaboko
- has Wikipedia article: en, zh

## DISH Q772326
- name: Banon cheese
- other names: {"zh": "巴农奶酪"}
- description: French cheese
- countries: FR
- kinds: French cheese, goat cheese, raw-milk cheese, natural-rind soft cheese, fresh cheese
- ingredients: milk, goat milk
- has Wikipedia article: en, zh

## DISH Q772542
- name: Antojito
- other names: {"zh": "墨西哥小吃"}
- description: Mexican street food
- countries: (none)
- kinds: street food
- has Wikipedia article: en, zh

## DISH Q772630
- name: Main course
- other names: {"zh": "主菜"}
- description: the primary and most substantial dish in a meal
- countries: (none)
- kinds: dish, course
- has Wikipedia article: en, zh

## DISH Q77301399
- name: Spezzatino
- description: Italian meat-based stew
- countries: IT
- kinds: meat dish, stew
- has Wikipedia article: en

## DISH Q773255
- name: Ngapi
- description: fish paste from Myanmar
- countries: (none)
- kinds: fish sauce
- has Wikipedia article: en

## DISH Q773895
- name: Cuccìa PAT
- other names: {"zh": "Cuccìa PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, dish, baked good, agricultural product, porridge
- ingredients: wheat
- has Wikipedia article: en

## DISH Q77469893
- name: Apple jam
- description: jam made from apples
- countries: (none)
- kinds: fruit jam

## DISH Q77501769
- name: Marquesita
- description: Yucatec dessert
- countries: (none)
- kinds: dessert
- ingredients: marmalade, condensed milk, dulce de leche, Edam, chocolate
- has Wikipedia article: en

## DISH Q775835
- name: Taleggio PDO
- other names: {"zh": "Taleggio DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, cow's-milk cheese, washed-rind cheese, Italian cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q775943
- name: Robiola di Roccaverano PDO
- other names: {"zh": "Robiola di Roccaverano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, washed-rind cheese, Italian cheese

## DISH Q776025
- name: Limburger
- other names: {"zh": "林堡芝士"}
- description: West European cheese
- countries: BE
- kinds: cheese, cow's-milk cheese
- ingredients: milk
- has Wikipedia article: en, zh

## DISH Q77626634
- name: Chef Cookie's Deep Dish
- description: dessert at Disneyland
- countries: US
- kinds: dessert
- ingredients: cookie, ice cream

## DISH Q77626986
- name: S'mores Bake
- description: dessert at Disneyland
- countries: US
- kinds: dessert
- ingredients: graham cracker, chocolate brownie, fudge, marshmallow

## DISH Q776904
- name: Submarine sandwich
- other names: {"zh": "潛艇三明治"}
- description: sandwich originating from the U.S.; consists of a length of bread or roll split lengthwise and filled with a variety of meats, cheeses, vegetables, and condiments; named after its appearance similar to a submarine
- countries: US
- cuisines: cuisine of the United States
- kinds: sandwich
- has Wikipedia article: en, zh

## DISH Q777487
- name: Mixed pickle
- description: pickles made from a variety of vegetables mixed in the same pickling process
- countries: (none)
- kinds: dish, pickle
- has Wikipedia article: en

## DISH Q7777747
- name: Theeyal
- description: South Indian roasted coconut stew
- countries: IN
- kinds: food, soup
- has Wikipedia article: en

## DISH Q7780958
- name: Dali ni Horbo
- description: Batak traditional cheese
- countries: ID
- cuisines: main course, Batak cuisine
- kinds: cheese, traditional food, food ingredient, dish, human food, Batak cuisine, type of food or dish
- ingredients: bromelain, papain, Ananas comosus
- has Wikipedia article: en

## DISH Q778396
- name: Surströmming
- other names: {"zh": "瑞典鹽醃鯡魚"}
- description: fermented herring with a strong connection to northern Sweden
- countries: SE
- cuisines: Swedish cuisine
- kinds: fish dish, food
- ingredients: Clupea, table salt, Clupea harengus
- has Wikipedia article: en, zh

## DISH Q7784272
- name: Thin Mints
- description: Girl Scout cookie flavor
- countries: US
- kinds: cookie, Girl Scout Cookies
- ingredients: chocolate
- has Wikipedia article: en

## DISH Q7796150
- name: Thoran
- description: Indian vegetable dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q77965820
- name: Skaldjurslasagne
- other names: {"sv": "Skaldjurslasagne"}
- countries: (none)
- kinds: dish

## DISH Q7799573
- name: Gỏi cuốn
- other names: {"zh": "脍卷"}
- description: Vietnamese dish
- countries: VN
- kinds: dish
- ingredients: Thai basil, shrimp, rice paper, rice vermicelli, pork, Lactuca sativa
- has Wikipedia article: en, zh

## DISH Q7799954
- name: Bò nướng lá lốt
- description: Vietnamese beef in lolot leaves
- countries: VN
- kinds: beef dish
- has Wikipedia article: en

## DISH Q7800152
- name: Tian mo
- other names: {"zh": "甜沫"}
- description: A Traditional Breakfast Soup
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en, zh

## DISH Q7801277
- name: Tiffin
- description: cake-like confection
- countries: (none)
- kinds: confectionery
- ingredients: golden syrup, cocoa powder, butter, biscuit, raisin, chocolate
- has Wikipedia article: en

## DISH Q7801531
- name: Tiger meat
- description: raw beef dish, made fromraw beef, raw egg, onion, salt, pepper, and other seasonings
- countries: (none)
- kinds: raw beef dish
- has Wikipedia article: en

## DISH Q7802
- name: Bread
- other names: {"zh": "面包"}
- description: baked food made of flour, water and other ingredients
- countries: (none)
- kinds: staple food, baked good, type of food or dish
- ingredients: water, baker's yeast, oil, flour, table salt, sugar, chicken egg, condiment, Saccharomyces cerevisiae, milk
- has Wikipedia article: en, zh

## DISH Q7804593
- name: Timbale
- description: type of cooking pan, and the foods cooked with it
- countries: (none)
- kinds: sweet pie
- has Wikipedia article: en

## DISH Q7808000
- name: Tinapa
- description: Filipino smoked fish
- countries: (none)
- kinds: food product, fish dish
- has Wikipedia article: en

## DISH Q7808550
- name: Tinutuan porridge
- description: Indonesian dish with rice and squash
- countries: ID
- cuisines: Indonesian cuisine
- kinds: congee, vegan food, food, dish, human food, traditional food, type of food or dish
- ingredients: granulated sugar, Cucurbita, corncob, Holy Basil, tapioca, Oryza, salt-cured meat, water spinach, Sweet potato, table salt, water
- has Wikipedia article: en

## DISH Q7808813
- name: Tipatipa
- description: Batak food item
- countries: ID
- cuisines: Indonesian cuisine
- kinds: rice dish, dish, human food, type of food or dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q7808983
- name: Tipsy cake
- description: cake soaked in alcohol
- countries: (none)
- kinds: cake
- ingredients: sponge cake
- has Wikipedia article: en

## DISH Q7809258
- name: Tirokafteri
- description: Greek cuisine starter
- countries: GR
- kinds: salad, spread, dish
- ingredients: bell pepper, lemon juice, Capsicum, feta, olive oil, Capsicum annuum
- has Wikipedia article: en

## DISH Q7810735
- name: Tlayuda
- description: Oaxacan dish of a large, thin, crunchy, partially fried or toasted filled tortilla
- countries: MX
- kinds: antojito
- ingredients: wheat tortilla
- has Wikipedia article: en

## DISH Q7811421
- name: Toasted ravioli
- description: Italian-American dish from St Louis, Missouri
- countries: (none)
- kinds: pasta, dish, type of food or dish, ravioli, pasta dish, fried food
- has Wikipedia article: en

## DISH Q7811427
- name: Toaster pastry
- description: Type of pastry, typically but optionally toasted and normally store-bought
- countries: (none)
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q781150
- name: Beaufort
- other names: {"zh": "博福尔奶酪"}
- description: type of cheese
- countries: FR
- kinds: French cheese, raw-milk cheese, cow's-milk cheese, farmstead cheese, pressed cooked cheese, dairy cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q7813015
- name: Tofu skin roll
- other names: {"zh": "腐皮卷"}
- countries: CN
- kinds: dim sum
- ingredients: tofu
- has Wikipedia article: en, zh

## DISH Q7813645
- name: Tokneneng
- description: Filipino street food
- countries: PH
- kinds: egg dish
- has Wikipedia article: en

## DISH Q7813783
- name: Tokwa’t baboy
- description: Filipino dish
- countries: PH
- kinds: food, pork dish
- ingredients: tahu goreng, pork
- has Wikipedia article: en

## DISH Q78183893
- name: Carthay Signature Fried Biscuits
- description: dish
- countries: US
- kinds: dish
- ingredients: biscuit, jalapeño, Cheddar cheese, bacon

## DISH Q7818540
- name: Tomate frito
- description: basic preparation of Spanish cuisine
- countries: ES
- kinds: sauce, tomato sauce
- ingredients: tomato
- has Wikipedia article: en

## DISH Q7818554
- name: Tomato and egg soup
- other names: {"zh": "番茄蛋湯"}
- description: Chinese soup dish
- countries: CN
- kinds: soup, egg dish, tomato dish
- ingredients: tomato, egg as food
- has Wikipedia article: en, zh

## DISH Q7818561
- name: Tomato compote
- description: side dish made from cooked tomatoes
- countries: (none)
- kinds: food, tomato dish
- ingredients: tomato
- has Wikipedia article: en

## DISH Q7818563
- name: Tomato omelette
- description: Indian breakfast dish prepared mostly in Maharashtra
- countries: IN
- kinds: food, pancake, tomato dish
- ingredients: tomato, green chili, onion, besan, water
- has Wikipedia article: en

## DISH Q7818565
- name: Italian tomato pie
- description: Italian-American baked good
- countries: IT, US
- cuisines: Italian-American cuisine
- kinds: pie, tomato dish
- ingredients: tomato
- has Wikipedia article: en

## DISH Q7820827
- name: Tonis puri
- other names: {"zh": "托尼斯普里"}
- description: type of Georgian bread
- countries: GE
- kinds: food, flatbread
- has Wikipedia article: en, zh

## DISH Q78210944
- name: Västerbottensostpaj
- countries: SE
- kinds: dish
- has Wikipedia article: en

## DISH Q7824331
- name: Tootsie Pops
- description: American candy
- countries: (none)
- kinds: candy, lollipop
- has Wikipedia article: en

## DISH Q7824729
- name: Top sirloin
- description: cut of meat from the primal loin, subprimal sirloin, of a beef carcass
- countries: (none)
- kinds: beef, cut of beef, sirloin steak
- has Wikipedia article: en

## DISH Q7824875
- name: Topik
- description: chickpea-based meze dish belonging to the cuisine of Istanbul, contribution of Turkish Armenians
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q7825094
- name: Topote
- description: local dish of Veracruz, Mexico
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q7825801
- name: Torikatsu
- other names: {"zh": "吉列雞"}
- description: Japanese fried chicken dish
- countries: JP
- cuisines: yōshoku
- kinds: fried chicken, katsu, dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q782709
- name: Valtellina Casera PDO
- other names: {"zh": "Valtellina Casera DOP"}
- description: Italian PDO cheese
- countries: IT
- cuisines: cuisine of Valtellina
- kinds: cheese, cow's-milk cheese, pressed half-cooked cheese, Italian cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q7827283
- name: Torta Ahogada
- description: pork birote bread sandwich in chile de árbol sauce
- countries: MX
- kinds: food, sandwich
- has Wikipedia article: en

## DISH Q7827300
- name: Tortilla de rescoldo
- description: type of flatbread
- countries: CL
- kinds: bread, flatbread, food
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q7827307
- name: Tortita negra
- description: Argentinian pastry
- countries: ES
- kinds: food, pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q782794
- name: Fortune cookie
- other names: {"zh": "幸运饼干"}
- description: crispy cookie with printed paper fortune inside
- countries: US
- kinds: cookie
- ingredients: flour, vanilla, sugar
- has Wikipedia article: en, zh

## DISH Q7828366
- name: Toto
- description: coconut cake in Jamaican cuisine
- countries: JM
- kinds: cake
- ingredients: coconut
- has Wikipedia article: en

## DISH Q7828466
- name: Tottenham cake
- description: sponge cake baked in large metal trays, covered either in pink icing or jam
- countries: GB
- kinds: cake
- has Wikipedia article: en

## DISH Q7829427
- name: Touton
- description: newfoundland pancake
- countries: CA
- kinds: food, pancake
- has Wikipedia article: en

## DISH Q78295261
- name: Ice cream
- description: frozen desert that you can easily hold in hand, often given to children
- countries: (none)
- kinds: ice cream
- ingredients: popsicle stick, ice cream cone

## DISH Q78349957
- name: Opatów krówki
- countries: PL
- kinds: krówki

## DISH Q7836557
- name: Treacle tart
- other names: {"zh": "糖蜜撻"}
- description: British desert
- countries: GB
- kinds: sweet tart
- ingredients: shortcrust pastry
- has Wikipedia article: en, zh

## DISH Q7843687
- name: Tripoline
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q7850109
- name: Tsukune
- description: Japanese chicken meatball
- countries: JP
- kinds: fish dish, chicken dish
- has Wikipedia article: en

## DISH Q7850498
- name: Tu
- description: Tibetan cheese cake, made with yak butter, brown sugar and water, made into a pastry
- countries: (none)
- kinds: food, cheesecake
- ingredients: yak butter
- has Wikipedia article: en

## DISH Q7852883
- name: Tunde ke kabab
- description: Buffalo meat galouti kebab, is a popular dish in Lucknow, India
- countries: IN
- kinds: kebab, dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q7853461
- name: Tuotuorou
- other names: {"zh": "坨坨肉"}
- description: Chinese pork dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q785537
- name: Cake of Hungary
- description: confectionery award
- countries: (none)
- kinds: cake, award, recognition

## DISH Q7855577
- name: Turli Tava
- countries: MK
- kinds: dish, beef dish
- ingredients: potato, mutton, beef
- has Wikipedia article: en

## DISH Q7856139
- name: Turon
- description: Philippine banana snack
- countries: PH
- kinds: banana dish
- ingredients: banana
- has Wikipedia article: en

## DISH Q7856511
- name: Turun sinappi
- description: Finnish mustard brand established 1926
- countries: FI
- kinds: mustard
- has Wikipedia article: en

## DISH Q7857393
- name: Tvøst og spik
- description: whalemeat and potato dish of the Faroe Islands
- countries: FO
- kinds: human food
- has Wikipedia article: en

## DISH Q78619741
- name: Tambunsu curry
- description: a traditional Minangkabau dish made from seasoned beef intestines
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, curry
- ingredients: Indonesian bay leaf, turmeric leaf, shallot, turmeric rhizome, garlic, ginger, Aleurites moluccanus, coconut milk, Alpinia galanga, tofu, egg as food, table salt

## DISH Q7862790
- name: Tương
- other names: {"zh": "Tương/醬"}
- description: condiment made from soybeans
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: fermented bean paste
- has Wikipedia article: en

## DISH Q7878708
- name: Ulam
- description: Traditional Malaysia salad originating from Malay Penisula
- countries: ID
- cuisines: Indonesian cuisine, Malay cuisine
- kinds: salad, Nasi ulam, food
- ingredients: leaf, vegetable
- has Wikipedia article: en

## DISH Q7879663
- name: Ginger snap
- other names: {"zh": "姜饼干"}
- description: biscuit with ginger flavor
- countries: (none)
- kinds: biscuit, gingerbread
- ingredients: gingerbread
- has Wikipedia article: en, zh

## DISH Q788124
- name: Bachwürfel
- description: cube-shaped confectionery
- countries: (none)
- kinds: confectionery
- ingredients: marzipan, chocolate
- has Wikipedia article: en

## DISH Q7882754
- name: Uncle Joe's Mint Balls
- description: traditional mints
- countries: (none)
- kinds: mint
- has Wikipedia article: en

## DISH Q7884162
- name: Vino cotto
- description: type of wine
- countries: IT
- cuisines: Abruzzese cuisine
- kinds: apéritif
- has Wikipedia article: en

## DISH Q7892214
- name: Taffy
- description: type of soft candy
- countries: (none)
- kinds: candy
- ingredients: sugar
- has Wikipedia article: en

## DISH Q7897138
- name: Unnakai
- description: plantain sweet dish from India
- countries: IN
- kinds: food, dessert
- ingredients: cooking banana
- has Wikipedia article: en

## DISH Q7899264
- name: Upside-down cake
- other names: {"zh": "翻转蛋糕"}
- description: type of cake
- countries: (none)
- kinds: cake
- ingredients: batter
- has Wikipedia article: en, zh

## DISH Q7901691
- name: Usal
- description: Maharastrian dish
- countries: IN
- cuisines: Maharashtrian cuisine
- kinds: side dish
- ingredients: lentil
- has Wikipedia article: en

## DISH Q7902573
- name: Utap
- description: Puff pastry cookie
- countries: PH
- kinds: food, pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q790433
- name: Challah
- other names: {"zh": "哈拉麵包"}
- description: special bread in Jewish cuisine and religion
- countries: IL
- cuisines: Jewish cuisine
- kinds: food, bread
- ingredients: wheat flour, egg as food, water
- has Wikipedia article: en, zh

## DISH Q79059164
- name: Pho ga
- description: Vietnamse version of chicken noodle soup
- countries: VN
- kinds: food, soup, noodle soup, chicken dish
- ingredients: rice noodle

## DISH Q79075787
- name: New York-style bagel
- description: variety of bagel originating from the Jewish community of New York City
- countries: US
- kinds: bagel
- has Wikipedia article: en

## DISH Q7908657
- name: Vaho
- description: Nicaraguan dish
- countries: NI
- kinds: dish, Wikimedia disambiguation page
- has Wikipedia article: en

## DISH Q79090568
- name: Caciotta marchigiana
- countries: IT
- kinds: cheese

## DISH Q79090764
- name: Pasta al fumè
- countries: IT
- kinds: first course

## DISH Q7912524
- name: Valomilk
- description: American marshmallow cream filled milk chocolate
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q7914788
- name: Vangibath
- description: South Indian dish
- countries: IN
- cuisines: Karnataka cuisine
- kinds: rice dish
- ingredients: eggplant, coconut, rice
- has Wikipedia article: en

## DISH Q79148257
- name: Banbury cheese
- description: English cheese, once produced in Banbury
- countries: (none)
- kinds: cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q791790
- name: Fricassee
- other names: {"zh": "白汁雞皇飯"}
- description: method of cooking meat
- countries: FR
- cuisines: French cuisine
- kinds: food preparation technique, ragout
- ingredients: white sauce, white meat
- has Wikipedia article: en, zh

## DISH Q7918342
- name: Vegetable sandwich
- description: type of sandwich
- countries: IN
- kinds: food, sandwich, type of food or dish
- ingredients: vegetable, bread
- has Wikipedia article: en

## DISH Q7918345
- name: Tarkari
- description: Vegetable dishes
- countries: (none)
- kinds: food, Indian curry
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q7919751
- name: Venetian sauce
- description: classical French herb sauce used to accompany fish; consists of a velouté and fish fumet base, equal quantities of tarragon vinegar and white wine, reduced with chopped shallots and chervil
- countries: (none)
- kinds: sauce, dish
- has Wikipedia article: en

## DISH Q792104
- name: Bejgli
- countries: (none)
- kinds: pastry, roll
- ingredients: poppy seed roll, poppy seed, flour

## DISH Q7928372
- name: Viennese whirl
- description: British shortbread biscuit, filled with cream and jam
- countries: (none)
- kinds: biscuit
- has Wikipedia article: en

## DISH Q7932918
- name: Vinyali
- description: Indian dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q79433149
- name: Hotelcake
- other names: {"nl": "Hotelcake"}
- countries: (none)
- kinds: pound cake

## DISH Q7959466
- name: Wagafi bread
- description: Iranian flatbread
- countries: IR
- kinds: food, bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q7959484
- name: Wagasi
- description: type of cheese
- countries: BJ
- kinds: cow's-milk cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q796270
- name: BLT
- other names: {"zh": "培根生菜番茄三明治"}
- description: bacon, lettuce, and tomato sandwich
- countries: US
- kinds: sandwich
- ingredients: tomato, mayonnaise, Lactuca sativa, bacon, bread
- has Wikipedia article: en, zh

## DISH Q7963023
- name: Wallenbergare
- description: Swedish dish generally consisting of ground veal, cream, egg yolks and coated in breadcrumbs
- countries: SE
- kinds: veal dish
- has Wikipedia article: en

## DISH Q7968279
- name: Wappameshi
- description: Japanese dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q7973452
- name: Water biscuit
- other names: {"zh": "水饼干"}
- description: type of cracker or biscuit
- countries: GB
- kinds: food, biscuit
- ingredients: flour
- has Wikipedia article: en

## DISH Q7974369
- name: Watermelon steak
- other names: {"zh": "烤西瓜排"}
- description: slices of watermelon, prepared by grilling, pan frying, baking, or roasting
- countries: (none)
- kinds: dish
- ingredients: watermelon
- has Wikipedia article: en, zh

## DISH Q797734
- name: Babka
- other names: {"zh": "巴布卡"}
- description: Central and Eastern European sweet yeast cake in the form of a tall cylinder
- countries: BY, PL, RU
- cuisines: Russian cuisine, Polish cuisine, Ukrainian cuisine, Belarusian cuisine
- kinds: food, cake, Easter bread, bundt cake
- ingredients: almond, yeast, flour, butter, egg, raisin, sugar, milk
- has Wikipedia article: en, zh

## DISH Q798409
- name: Backesgrumbeere
- other names: {"de": "Backesgrumbeere"}
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q799098
- name: Badische Schneckensuppe
- other names: {"de": "Badische Schneckensuppe"}
- countries: (none)
- cuisines: Baden cuisine
- kinds: dish
- ingredients: _Kartoffeln_zubereiten

## DISH Q7995632
- name: White hot
- description: variation on the hot dog found primarily in the Rochester, New York
- countries: US
- kinds: hot dog
- ingredients: pork
- has Wikipedia article: en

## DISH Q7995704
- name: White sugar sponge cake
- other names: {"zh": "白糖糕"}
- description: Chinese pastry
- countries: CN
- kinds: sponge cake
- ingredients: rice flour
- has Wikipedia article: en, zh

## DISH Q8010363
- name: Gopchang jeongol
- other names: {"zh": "韩式牛肠锅"}
- description: spicy Korean stew or casserole
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q8013024
- name: Jeonggwa
- other names: {"zh": "正果"}
- description: Korean confection
- countries: (none)
- kinds: hangwa
- has Wikipedia article: en

## DISH Q8017486
- name: Hoe-deopbap
- other names: {"zh": "生鱼片盖饭"}
- description: raw fish bibimbap
- countries: (none)
- kinds: bibimbap, rice dish, raw fish dish
- has Wikipedia article: en

## DISH Q8018130
- name: Nabak kimchi
- other names: {"zh": "萝卜片水泡菜"}
- description: watery kimchi made of thinly sliced Korean radish and napa cabbage
- countries: (none)
- kinds: radish kimchi
- ingredients: white radish
- has Wikipedia article: en

## DISH Q8024918
- name: Wine cake
- description: cake made with wine in Colombian cuisine
- countries: CO
- kinds: cake
- ingredients: wine
- has Wikipedia article: en

## DISH Q8025241
- name: Wingko
- description: Indonesian traditional pancake
- countries: ID
- kinds: food, kue
- ingredients: glutinous rice flour, coconut, table salt, sugar, margarine, Cocos nucifera
- has Wikipedia article: en

## DISH Q80262234
- name: Señor Croque
- description: dish
- countries: US
- kinds: dish
- ingredients: fried chicken, brioche, fried egg, Cheddar cheese, sauce

## DISH Q8031737
- name: Wonder Bread
- other names: {"zh": "沃登面包"}
- description: Brand name bread
- countries: US
- kinds: bread, food
- has Wikipedia article: en

## DISH Q8039094
- name: Wuhan duck
- description: Chinese dish
- countries: (none)
- kinds: dish
- ingredients: duck meat
- has Wikipedia article: en

## DISH Q8040160
- name: Wyngz
- description: chicken food product in the shape of a chicken wing or a bite-size appetizer-type product
- countries: (none)
- kinds: chicken dish

## DISH Q8042825
- name: Xacuti
- description: Goan dish of meat with white poppy seeds, coconut and dried red chilies
- countries: (none)
- kinds: food, Indian curry
- has Wikipedia article: en

## DISH Q8044057
- name: Xi gua lao
- description: traditional dish of Beijing
- countries: CN
- kinds: pastry
- ingredients: watermelon
- has Wikipedia article: en

## DISH Q804411
- name: Bakewell tart
- other names: {"zh": "英式巴旦木挞"}
- description: English confection consisting of a shortcrust pastry with a layer of jam and a sponge using ground almonds
- countries: GB
- kinds: sweet pie
- ingredients: raspberry jam, shortcrust pastry, frangipane, almond
- has Wikipedia article: en

## DISH Q8047029
- name: Yaka mein
- other names: {"zh": "亚卡面"}
- description: beef noodle soup
- countries: US
- kinds: food, beef noodle soup
- has Wikipedia article: en

## DISH Q8051909
- name: Yellow soybean paste
- other names: {"zh": "黄酱"}
- description: fermented paste made from yellow soybeans, salt, and water used in Chinese cuisine
- countries: (none)
- kinds: fermented bean paste
- has Wikipedia article: en, zh

## DISH Q8051963
- name: Yellowman
- description: Irish confectionery
- countries: (none)
- kinds: honeycomb toffee
- has Wikipedia article: en

## DISH Q8052488
- name: Yeotgangjeong
- description: Korean dessert
- countries: (none)
- kinds: food, puffed rice cake
- has Wikipedia article: en

## DISH Q805344
- name: Ballotine
- other names: {"zh": "無骨烤春雞"}
- description: preparation of poultry leg meat
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en, zh

## DISH Q8053485
- name: Yi mein
- other names: {"zh": "伊麵"}
- description: type of noodles used in Cantonese cuisine
- countries: CN
- kinds: food, Chinese noodles
- ingredients: wheat flour, egg as food
- has Wikipedia article: en, zh

## DISH Q8053692
- name: Yin Yang fish
- other names: {"zh": "糖醋活魚"}
- description: fish dish where the fish remains alive while being eaten
- countries: (none)
- kinds: fish dish, eating live seafood
- has Wikipedia article: en

## DISH Q8055450
- name: York Fruits
- description: English brand of fruit jellies
- countries: (none)
- kinds: fruit jellies
- has Wikipedia article: en

## DISH Q8055913
- name: Kalburabastı
- description: Turkish dessert
- countries: TR
- kinds: food, dessert
- ingredients: flour
- has Wikipedia article: en

## DISH Q8057789
- name: Youmian
- description: Variety of Chinese noodle
- countries: (none)
- kinds: egg noodle
- has Wikipedia article: en

## DISH Q805934
- name: Bamberger (Gebäck)
- other names: {"de": "Bamberger (Gebäck)"}
- countries: (none)
- kinds: viennoiserie

## DISH Q805957
- name: Bamberger Zwiebeln
- other names: {"de": "Bamberger Zwiebeln"}
- countries: (none)
- kinds: meat dish

## DISH Q8060137
- name: Yuca con mojo
- description: traditional Cuban side dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q8060464
- name: Yuhwang ori
- description: traditional Korean dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q806097
- name: Banana bread
- other names: {"zh": "香蕉面包"}
- description: type of bread or cake made with bananas
- countries: US
- cuisines: cuisine of the United States
- kinds: baking, quick bread, sweet bread, banana dish
- ingredients: flour, sugar, banana
- has Wikipedia article: en, zh

## DISH Q806099
- name: Banana chip
- description: dried, crispy slice of banana
- countries: (none)
- kinds: food, banana dish, dried banana
- ingredients: Saba banana, flavor enhancer, cooking oil, table salt, sugar
- has Wikipedia article: en

## DISH Q8061020
- name: Yum sen lon
- description: salad from Laos
- countries: (none)
- kinds: salad
- has Wikipedia article: en

## DISH Q806142
- name: Banbury cake
- description: food
- countries: GB
- cuisines: British cuisine
- kinds: dish, pie
- ingredients: puff pastry
- has Wikipedia article: en

## DISH Q8061747
- name: Yurla
- description: Tibetan wheat pastry dish
- countries: (none)
- kinds: food, pastry
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q8066663
- name: Zarda
- description: traditional South Asian sweet dish
- countries: IN
- cuisines: Indian cuisine, Pakistani cuisine, Bangladeshi cuisine
- kinds: dish, food
- ingredients: saffron, sugar, milk, rice
- has Wikipedia article: en

## DISH Q806839
- name: Banku
- other names: {"zh": "banku"}
- description: Ghanaian meal made from maize and cassava dough
- countries: BJ, GH, TG
- kinds: food, dish, swallow
- ingredients: Cassava dough, maize flour, cassava flour, table salt, water
- has Wikipedia article: en, zh

## DISH Q8068822
- name: Zelnik
- description: savory pie from the Balkans
- countries: TR
- kinds: food, pie
- ingredients: phyllo
- has Wikipedia article: en

## DISH Q806901
- name: Bannock
- other names: {"zh": "班諾克麵包"}
- description: quickbread of Scottish origin
- countries: (none)
- kinds: flatbread, quick bread
- has Wikipedia article: en, zh

## DISH Q8074583
- name: ZotZ
- description: candy brand
- countries: IT
- kinds: hard candy
- has Wikipedia article: en

## DISH Q8076477
- name: À l'amiral
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q8077757
- name: Çoban salad
- other names: {"zh": "牧羊人沙拉"}
- description: Turkish cuisine salad
- countries: TR
- kinds: dish, salad
- ingredients: tomato, Cucumis sativus, table salt, lemon juice, Piper, olive oil, Allium, parsley
- has Wikipedia article: en, zh

## DISH Q8078183
- name: Éisleker Ham
- description: speciality from the Oesling region in the north of Luxembourg
- countries: (none)
- kinds: ham
- has Wikipedia article: en

## DISH Q80923686
- name: Zemelach
- description: type of cookie in Ashkenazi Jewish cuisine
- countries: IL
- cuisines: Jewish cuisine, Soviet cuisine
- kinds: biscuit

## DISH Q8097583
- name: Rosolli
- description: Finnish Salad
- countries: FI
- kinds: salad
- has Wikipedia article: en

## DISH Q81
- name: Carrot
- other names: {"zh": "胡萝卜"}
- description: taproot of the domesticated carrot plant
- countries: (none)
- kinds: type of vegetable, food crop, root vegetable, taproot, finger food, food ingredient
- has Wikipedia article: en, zh

## DISH Q8103680
- name: Kalach
- description: Eastern European bread
- countries: HU, RU, UA
- cuisines: Czech cuisine, Ukrainian cuisine, Russian cuisine, Bulgarian cuisine, Polish cuisine
- kinds: yeast bread, food, baked good
- ingredients: wheat flour, flour
- has Wikipedia article: en

## DISH Q81039705
- name: Mazamorra de cochino
- other names: {"es": "mazamorra de cochino"}
- countries: PE
- kinds: meal, dessert

## DISH Q81130828
- name: Rotterdammertjes
- other names: {"nl": "Rotterdammertjes"}
- countries: (none)
- kinds: candy

## DISH Q812607
- name: Bayrisch Blockmalz
- description: Bavarian hard candy
- countries: DE
- kinds: hard candy

## DISH Q812609
- name: Bayrisch Kraut
- description: Bavarian cabbage dish
- countries: DE
- cuisines: Bavarian cuisine
- kinds: dish
- ingredients: beef stock, cabbage, onion, lard, vinegar, apple
- has Wikipedia article: en

## DISH Q814709
- name: Beignet
- other names: {"zh": "贝奈特饼"}
- description: pastry
- countries: FR
- kinds: fritter, dish
- ingredients: dough, powdered sugar
- has Wikipedia article: en, zh

## DISH Q815898
- name: Blini
- other names: {"zh": "布利尼"}
- description: eastern European pancake
- countries: FR, RU, US, AT, UA, MD
- cuisines: French cuisine, Russian cuisine, cuisine of the United States, Austrian cuisine, Ukrainian cuisine, Moldovan cuisine, Chechen cuisine, Ingush cuisine
- kinds: pancake
- ingredients: boiling water, flour, sugar, milk, egg as food, water
- has Wikipedia article: en, zh

## DISH Q81615262
- name: Adobong pugita
- description: Filipino dish
- countries: PH
- kinds: dish

## DISH Q81615502
- name: Poqui poqui
- description: filipino-Ilocano dish of eggs and chopped eggplants
- countries: PH
- kinds: dish
- ingredients: garlic, tomato, eggplant, bagoong, onion, egg as food
- has Wikipedia article: en

## DISH Q816663
- name: Jollof rice
- other names: {"zh": "加羅夫飯"}
- description: rice dish from West Africa
- countries: GH, NG, SN
- kinds: been cin, rice
- ingredients: vegetable oil, peppercorn, crayfish, seasoning, palm oil, Allium, table salt, rice, water, tomato
- has Wikipedia article: en, zh

## DISH Q816704
- name: Pâté
- other names: {"zh": "肉酱"}
- description: mixture of cooked ground meat and fat minced into a spreadable paste
- countries: RO
- cuisines: French cuisine, Russian cuisine
- kinds: dish, spread
- ingredients: minced meat, liver as food
- has Wikipedia article: en, zh

## DISH Q816851
- name: Cupcake
- other names: {"zh": "纸杯蛋糕"}
- description: type of small cake
- countries: US
- kinds: cake
- ingredients: raising agent, egg as food, flour, butter, sugar
- has Wikipedia article: en, zh

## DISH Q817282
- name: Beni shōga
- other names: {"zh": "薑片"}
- description: Japanese pickled ginger
- countries: JP
- kinds: food, side dish, tsukemono
- ingredients: umezu, ginger
- has Wikipedia article: en, zh

## DISH Q818674
- name: Meze
- other names: {"zh": "大拼盘"}
- description: small dish in the cuisine of the Near East and Balkans
- countries: TR
- kinds: food, dish, finger food, appetizer
- has Wikipedia article: en, zh

## DISH Q81902
- name: Irish potato candy
- description: candy from Philadelphia, USA
- countries: US
- kinds: candy, potato dish
- has Wikipedia article: en

## DISH Q8191952
- name: Harihari-nabe
- description: Japanese food
- countries: JP
- kinds: meat dish, nabemono
- ingredients: Brassica rapa subsp. nipposinica, Minke whale, whale meat
- has Wikipedia article: en

## DISH Q8193769
- name: Imoni
- other names: {"zh": "芋煮會"}
- description: taro and meat soup from Tōhoku, Japan
- countries: JP
- kinds: food, soup
- ingredients: Colocasia esculenta, potato
- has Wikipedia article: en, zh

## DISH Q8194132
- name: Hakata ramen
- other names: {"zh": "博多拉面"}
- countries: (none)
- kinds: tonkotsu ramen, ramen
- ingredients: ramen
- has Wikipedia article: zh

## DISH Q8196212
- name: Börek
- other names: {"zh": "土耳其薄饼"}
- description: stuffed phyllo pastry
- countries: (none)
- kinds: pie
- ingredients: phyllo
- has Wikipedia article: en

## DISH Q8205076
- name: Arroz a la cazuela
- description: Spanish rice dish
- countries: (none)
- kinds: dish

## DISH Q8205079
- name: Arroz carreteiro
- description: Brazilian rice dish
- countries: BR
- cuisines: Brazilian cuisine
- kinds: rice dish
- has Wikipedia article: en

## DISH Q8205081
- name: Arròs amb fesols i naps
- other names: {"ca": "arròs amb fesols i naps"}
- countries: (none)
- kinds: dish

## DISH Q8205104
- name: Arroz de sarrabulho
- description: Portuguese pork dish
- countries: (none)
- kinds: rice dish

## DISH Q8210687
- name: Ayam rica-rica
- description: Indonesian dish
- countries: ID
- kinds: food, main course, fried chicken, chicken dish
- ingredients: chicken as food, cooking oil, Cymbopogon citratus, lime, orange, table salt, sugar, water
- has Wikipedia article: en

## DISH Q821220
- name: Beutelwurst
- description: German blood sausage
- countries: (none)
- kinds: sausage, blood sausage, dish
- has Wikipedia article: en

## DISH Q821440
- name: Berliner Brot
- countries: (none)
- kinds: pastry

## DISH Q821630
- name: Berliner Luft
- countries: DE
- kinds: dessert
- ingredients: raspberry juice, beaten egg whites, egg yolk, gelatin, sugar

## DISH Q821733
- name: Berliner Schnitzel
- other names: {"de": "Berliner Schnitzel"}
- description: dish
- countries: DE
- kinds: dish, meat dish

## DISH Q82330310
- name: Chinese almond biscuit
- other names: {"zh": "杏仁餅"}
- description: Chinese pastry made with ground mung bean
- countries: CN
- kinds: cookie
- ingredients: vegetable oil, Vigna radiata, Prunus dulcis, butter, sugar, water
- has Wikipedia article: en, zh

## DISH Q8239266
- name: Bacalhau espiritual
- other names: {"es": "Bacalhau espiritual"}
- countries: (none)
- kinds: fish dish

## DISH Q824543
- name: Bernese sausage
- description: Austrian dish of cheese-stuffed sausage wrapped in bacon
- countries: AT
- kinds: meat dish
- ingredients: Vienna sausage, bacon, cheese

## DISH Q8245687
- name: Beirut sandwich
- description: Brazilian sandwich
- countries: BR
- cuisines: Brazilian cuisine
- kinds: type of food or dish, stuffed flatbread
- ingredients: pita, roast beef, tomato, cheese
- has Wikipedia article: en

## DISH Q824592
- name: Berner Platte
- other names: {"zh": "伯尔尼拼盘"}
- description: bernese traditional meat dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q8249032
- name: Bocadillo de tortilla
- description: Spanish omelette sandwich
- countries: (none)
- kinds: bocadillo

## DISH Q8249805
- name: Bok l'hong
- description: Cambodian papaya salad
- countries: KH
- kinds: dish, fruit salad
- ingredients: papaya, lime juice, peanut, green bean, shrimp paste, fish sauce, dried shrimp, monosodium L-glutamate, chili pepper, smoked fish, basil, tomato, table salt, sugar

## DISH Q8253265
- name: Buchada de bode
- description: traditional Northeastern Brazilian dish made with goat offal cooked inside the stomach
- countries: BR
- kinds: goat meat dish
- ingredients: goat meat

## DISH Q8255086
- name: Calas
- description: food
- countries: (none)
- kinds: rice dish
- has Wikipedia article: en

## DISH Q82551888
- name: Biscotti bolliti PAT
- other names: {"zh": "Biscotti bolliti PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: biscuit, baked good, pastry

## DISH Q8255731
- name: Callos a la madrileña
- description: Spanish dish
- countries: ES
- kinds: food, dish, Callos
- ingredients: tripe
- has Wikipedia article: en

## DISH Q8262017
- name: Canja a Doentes
- other names: {"es": "Canja a Doentes"}
- countries: (none)
- kinds: dish

## DISH Q8265768
- name: Lower leg
- description: portion of the body starting from the ankle and ending at the knee
- countries: (none)
- kinds: middle free limb segment, meat dish, class of anatomical entity, chiral organism subdivision type
- ingredients: lower leg proper, shin area, calf, knee
- has Wikipedia article: en

## DISH Q82753397
- name: Bubblegum ice cream
- description: ice cream with natural or artificial bubblegum flavoring
- countries: (none)
- kinds: ice cream, bubblegum-based food
- ingredients: bubblegum, ice cream

## DISH Q829243
- name: Donauwelle
- description: cake in Germany and Austria
- countries: DE
- kinds: sheet cake, sponge cake
- ingredients: buttercream, cocoa powder, egg as food, flour, butter, sugar, chocolate
- has Wikipedia article: en

## DISH Q829977
- name: Besoffener Kapuziner
- other names: {"de": "Besoffener Kapuziner"}
- countries: (none)
- kinds: dish

## DISH Q83120337
- name: Ciambellone
- description: Italian ring-shaped cake
- countries: IT
- kinds: bundt cake
- ingredients: ricotta, lemon zest

## DISH Q83131350
- name: Fusillini
- description: type of pasta, smaller version of fusilli
- countries: IT
- kinds: type of pasta, pasta

## DISH Q831381
- name: Bethmännchen
- description: Hessian pastry specialty
- countries: DE
- kinds: pastry, dish
- ingredients: marzipan
- has Wikipedia article: en

## DISH Q83143290
- name: Bourekas
- description: food
- countries: IL
- kinds: dish
- has Wikipedia article: en

## DISH Q83165
- name: Nutmeg
- other names: {"zh": "肉豆蔻"}
- description: spice from trees in the genus Myristica
- countries: ID
- kinds: spice, sedative, food ingredient, Myristica
- has Wikipedia article: en, zh

## DISH Q83213524
- name: Spéculoos de Hasselt
- other names: {"fr": "spéculoos de Hasselt"}
- countries: BE
- kinds: speculaas biscuit, cookie

## DISH Q832480
- name: Betthupferl
- other names: {"de": "Betthupferl"}
- description: German sayings: small sweetmeat; bedtime story
- countries: (none)
- kinds: sweetmeat, reading aloud

## DISH Q83364
- name: Vegetarianism
- other names: {"zh": "素食主義"}
- description: practice of abstaining from the consumption of meat
- countries: (none)
- cuisines: vegetarian cuisine
- kinds: diet, dietary restriction, lifestyle, social movement
- has Wikipedia article: en, zh

## DISH Q83376
- name: Rum
- other names: {"zh": "朗姆酒"}
- description: distilled alcoholic beverage made from sugarcane
- countries: (none)
- kinds: industry, liquor
- ingredients: Saccharum officinarum
- has Wikipedia article: en, zh

## DISH Q83397433
- name: Doce de ovos
- description: Portuguese egg custard
- countries: PT
- kinds: jam, custard
- ingredients: orange flower water, egg as food, sugar, drinking water
- has Wikipedia article: en

## DISH Q83421521
- name: Cagionetti
- countries: IT
- kinds: Christmas dessert

## DISH Q83423428
- name: Sfogliatelle
- countries: IT
- kinds: Christmas dessert

## DISH Q83452931
- name: Laklak (food)
- description: A traditional Balinese pancake with grated coconut and melted palm sugar
- countries: (none)
- kinds: rice cake
- has Wikipedia article: en

## DISH Q8345423
- name: Chipa Pirú
- other names: {"de": "Chipa Pirú"}
- countries: (none)
- kinds: baked good

## DISH Q8345498
- name: Mint chocolate
- other names: {"zh": "薄荷巧克力"}
- description: flavored chocolate, made by adding a mint flavoring
- countries: (none)
- kinds: chocolate, confectionery
- has Wikipedia article: en

## DISH Q834563
- name: Jiuniang
- other names: {"zh": "酒釀"}
- description: food
- countries: CN
- kinds: food, soup, dessert
- ingredients: glutinous rice, ethanol
- has Wikipedia article: en, zh

## DISH Q8347360
- name: Coca de Castelló
- other names: {"ca": "Coca de Castelló"}
- countries: ES
- kinds: dessert

## DISH Q8347364
- name: Coca d'albercocs
- other names: {"ca": "coca d'albercocs"}
- countries: ES
- kinds: dessert, coca

## DISH Q8347366
- name: Coca d'anís
- other names: {"ca": "coca d'anís"}
- countries: ES
- kinds: dessert

## DISH Q8347371
- name: Coca de dacsa
- other names: {"ca": "Coca de dacsa"}
- countries: ES
- kinds: dessert

## DISH Q8347373
- name: Coca de molletes
- other names: {"ca": "coca de molletes"}
- countries: ES
- cuisines: Valencian cuisine
- kinds: dessert
- ingredients: olive oil, flour, table salt

## DISH Q8347391
- name: Cochinillo asado
- description: Spanish pork dish
- countries: ES
- kinds: food, pork dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q8351601
- name: Crespillos
- countries: ES
- kinds: dessert

## DISH Q835336
- name: Cart noodle
- other names: {"zh": "车仔面"}
- description: Noodle dish which became popular in Hong Kong in the 1950s through being sold by street vendors from carts
- countries: HK
- kinds: noodle, dish
- ingredients: flour
- has Wikipedia article: en, zh
