# Review batch names-049

## DISH Q6068180
- name: İskilip dolması
- description: Turkish dish from İskilip, Çorum
- countries: TR
- kinds: food, traditional food, meat dish, rice dish
- ingredients: onion, meat, rice
- has Wikipedia article: en

## DISH Q6070788
- name: Pegao
- description: dish
- countries: (none)
- kinds: dish

## DISH Q6071076
- name: Pelotas de cocido en dulce
- other names: {"es": "Pelotas de cocido en dulce"}
- countries: (none)
- kinds: dessert

## DISH Q607114
- name: Thukpa
- other names: {"zh": "藏面"}
- description: noodle soup from Tibet and Nepal
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en, zh

## DISH Q6071916
- name: Pepito
- description: Type of sandwich
- countries: (none)
- kinds: sandwich
- ingredients: meat, bread
- has Wikipedia article: en

## DISH Q6072163
- name: Perdices de mar
- other names: {"es": "Perdices de mar"}
- countries: (none)
- kinds: tapas

## DISH Q6072201
- name: Perdiz escabechada
- other names: {"es": "perdiz escabechada"}
- countries: ES
- kinds: dish
- ingredients: partridge

## DISH Q60728748
- name: Llaucha
- description: empanada boliviana
- countries: (none)
- kinds: meal, pie
- ingredients: wheat flour, chili pepper, cheese

## DISH Q6072967
- name: Iron egg
- other names: {"zh": "鐵蛋"}
- description: egg-based dish from Taiwan
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: egg dish
- has Wikipedia article: en, zh

## DISH Q60738834
- name: Kuksu
- description: Uzbek-Korean noodle dish
- countries: (none)
- kinds: janchi-guksu, cold noodle
- has Wikipedia article: en

## DISH Q60738894
- name: Lugaw
- description: rice porridge dish in the Philippines
- countries: PH
- kinds: rice dish
- has Wikipedia article: en

## DISH Q60739784
- name: Laing
- description: Filipino dish
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q60739792
- name: Mamón
- description: traditional Filipino chiffon or sponge cakes
- countries: PH
- kinds: sponge cake, chiffon cake
- has Wikipedia article: en

## DISH Q60740502
- name: Humba
- description: Filipino braised pork dish
- countries: PH
- kinds: dish
- ingredients: soy sauce, pork, vinegar
- has Wikipedia article: en

## DISH Q60740508
- name: Pusô
- description: Filipino rice cake
- countries: PH
- kinds: Binalot
- has Wikipedia article: en

## DISH Q60740781
- name: Mango float
- other names: {"zh": "芒果漂浮"}
- description: food
- countries: PH
- cuisines: Filipino cuisine
- kinds: dessert
- ingredients: condensed milk, cracker, whipped cream, Savoiarde PAT, mango
- has Wikipedia article: en, zh

## DISH Q60742640
- name: Vantage loaf
- description: thirteenth loaf of a baker's dozen
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q60745567
- name: Mince on toast
- description: cooked ground meat on a slice of toasted bread
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q60748979
- name: Salukara
- description: pancake from Filipino cuisine
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q60749256
- name: Hilachas
- description: Guatemalan beef dish
- countries: GT
- kinds: dish
- has Wikipedia article: en

## DISH Q60750048
- name: Tapado
- description: Central American seafood soup
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q60750699
- name: Saskatoon berry pie
- description: pie with a saskatoon berry filling
- countries: CA
- kinds: pie
- ingredients: white sugar, lemon juice, Amelanchier alnifolia, flour
- has Wikipedia article: en

## DISH Q6075158
- name: Picos
- countries: ES
- kinds: meal, appetizer, baked good

## DISH Q60752375
- name: Kaysefe
- description: Turkish dessert made of dried fruits topped with melted butter
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q60754611
- name: Buddha bowl
- description: vegetarian meal, served on a bowl which consists of portions of several foods, served cold
- countries: (none)
- kinds: dish, salad, plant-based food
- has Wikipedia article: en

## DISH Q60755899
- name: Joe Frogger
- description: cookie
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q6075632
- name: Akçaabat meatballs
- description: Köfte dish from Turkish cuisine
- countries: (none)
- kinds: Köftes in the Turkish cuisine
- ingredients: meat
- has Wikipedia article: en

## DISH Q60760520
- name: Moche
- description: Pampangan sweet
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q60760532
- name: Mache
- description: Filipino rice dish
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q60760541
- name: Masi
- description: Philippine rice dish
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q60760831
- name: Puto bumbóng
- description: Filipino rice cake
- countries: PH
- kinds: snack
- has Wikipedia article: en

## DISH Q60761084
- name: Ginataang mais
- description: Filipino sweet corn and rice gruel
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q60761158
- name: Tortang talong
- description: Filipino egg and eggplant dish
- countries: PH
- cuisines: Filipino cuisine
- kinds: omelette
- ingredients: eggplant, egg as food, table salt
- has Wikipedia article: en

## DISH Q60761452
- name: Goto
- description: Filipino rice and beef tripe gruel
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q60761458
- name: Taba ng talangka
- description: Filipino seafood paste
- countries: PH
- kinds: fermented food, crab dish, condiment
- has Wikipedia article: en

## DISH Q60761467
- name: Burgo
- description: traditional food from Jambi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: pancake, dessert, snack, type of food or dish, soup, food, dish, traditional food
- ingredients: rice flour, Aleurites moluccanus, Kaempferia galanga, tapioca, coconut milk, Channa striata, Alpinia galanga, Coriandrum sativum, Allium sativum
- has Wikipedia article: en

## DISH Q60761825
- name: Panyalam
- description: traditional Filipino fried rice pancake
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q60762070
- name: Embutido
- description: Filipino cuisine
- countries: PH
- kinds: meatloaf
- has Wikipedia article: en

## DISH Q60762598
- name: Pininyahang manok
- description: Filipino chicken dish
- countries: PH
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q60762782
- name: Pastil
- description: Philippine packed-rice dish
- countries: PH
- cuisines: Filipino cuisine
- kinds: Binalot
- has Wikipedia article: en

## DISH Q60762918
- name: Paelya
- description: Philippine rice dish
- countries: ES, PH
- kinds: paella, dish
- has Wikipedia article: en

## DISH Q60763199
- name: Pancit choca
- description: Filipino seafood noodle dish
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q60763218
- name: Filipino spaghetti
- description: Filipino adaptation of Italian spaghetti with a sweet tomato sauce, sliced sausages, giniling and grated cheese
- countries: PH
- kinds: pasta dish
- ingredients: banana ketchup, tomato sauce, picadillo, sausage, spaghetti
- has Wikipedia article: en

## DISH Q60763456
- name: Tibok-tibok
- description: Pampangan dessert pudding
- countries: (none)
- cuisines: Kapampangan cuisine
- kinds: Manjar blanco, pudding
- has Wikipedia article: en

## DISH Q60764509
- name: Dinamita
- description: variant of lumpia
- countries: PH
- kinds: popiah, snack
- has Wikipedia article: en

## DISH Q60764932
- name: Lumpiang keso
- description: Filipino deep-fried appetizer
- countries: PH
- kinds: popiah
- has Wikipedia article: en

## DISH Q6076542
- name: Hoşmerim
- description: cheese-based Turkish dessert
- countries: TR
- kinds: food, dessert
- ingredients: semolina
- has Wikipedia article: en

## DISH Q6076844
- name: Peruvian Pisco
- other names: {"zh": "皮斯科葡萄酒"}
- description: grape brandy produced in Peru
- countries: PE
- kinds: liquor, activity, pisco
- has Wikipedia article: en

## DISH Q607690
- name: Tabbouleh
- other names: {"zh": "塔布勒沙拉"}
- description: Middle East vegetarian dish
- countries: LB, SY
- kinds: salad, vegetable dish
- ingredients: parsley, lemon juice, bulgur, olive oil
- has Wikipedia article: en, zh

## DISH Q60769823
- name: Pata tim
- description: Filipino braised pork hock dish
- countries: PH
- kinds: pork dish
- has Wikipedia article: en

## DISH Q6077023
- name: Pitufo (Málaga)
- other names: {"es": "Pitufo (Málaga)"}
- description: type of bread common in parts of Spain
- countries: (none)
- kinds: staple food, baked good
- ingredients: flour, table salt, water

## DISH Q60770307
- name: Sayongsong
- description: Filipino cuisine
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q6077132
- name: Piñonate
- description: Spanish dessert
- countries: ES
- kinds: dessert

## DISH Q607754
- name: Chicken burger
- description: chicken patty served in a hamburger bun
- countries: (none)
- kinds: burger, chicken sandwich
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q60775555
- name: Kandu Kukulhu
- description: Maldivian dish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q60776436
- name: Meat-free sausage roll
- description: savoury pastry snack
- countries: (none)
- kinds: food, snack, sausage roll
- ingredients: meat alternative, puff pastry
- has Wikipedia article: en

## DISH Q60776617
- name: Lechon manok
- description: chicken dish in Filipino cuisine
- countries: PH
- kinds: food, roast chicken, chicken dish
- has Wikipedia article: en

## DISH Q60776626
- name: Saikyoyaki
- description: fish marinating method
- countries: JP
- kinds: grilled fish
- ingredients: Saikyo miso, fish as food
- has Wikipedia article: en

## DISH Q6077919
- name: Karadeniz pidesi
- description: Turkish oven-baked dish consisting of a "pide" flatbread with a filling or topping.
- countries: TR
- kinds: food, pide

## DISH Q60785285
- name: Pyshka
- description: Russian doughnut
- countries: (none)
- kinds: doughnut
- has Wikipedia article: en

## DISH Q60785507
- name: Phapar ko Roti
- description: Nepali traditional food
- countries: (none)
- kinds: pancake
- has Wikipedia article: en

## DISH Q60793741
- name: Tlačenka
- other names: {"zh": "多羅千卡"}
- description: Czech and Slovak meat dish with brawn
- countries: (none)
- kinds: food, offal dish, head cheese
- has Wikipedia article: en, zh

## DISH Q60794865
- name: Shibajie mahua
- description: traditional pastry from Tianjin, China
- countries: (none)
- kinds: mahua

## DISH Q6080770
- name: Isi ewu
- description: Nigerian soup made from goat's head
- countries: NG
- kinds: dish, human food, food, meat, goat meat dish
- ingredients: potash, Monodora myristica, onion, goat meat, palm oil, spice, goat
- has Wikipedia article: en

## DISH Q6081067
- name: Isidudu
- description: soft porridge made from ground corn known as mealie meal
- countries: (none)
- kinds: porridge
- has Wikipedia article: en

## DISH Q6081915
- name: Pollo a la Villeroy
- description: type of chicken dish
- countries: (none)
- kinds: chicken dish

## DISH Q6081918
- name: Pollo al ajillo
- description: Spanish garlic chicken dish
- countries: (none)
- kinds: chicken dish
- ingredients: garlic, chicken as food

## DISH Q6081922
- name: Pollo al chipotle
- description: Mexican chicken dish
- countries: MX
- kinds: chicken dish

## DISH Q60823310
- name: Mbeyú
- other names: {"es": "Mbeyú"}
- countries: (none)
- kinds: cake

## DISH Q60823349
- name: Sugo alla puttanesca
- description: pasta sauce
- countries: IT
- cuisines: Italian cuisine
- kinds: tomato sauce, sauce
- ingredients: tomato, caper, olive, European anchovy, olive oil

## DISH Q6082370
- name: Ponche segoviano
- other names: {"es": "Ponche segoviano"}
- countries: ES
- kinds: dessert

## DISH Q6082412
- name: Ponderaciones
- description: Peruvian dessert of viceregal origin
- countries: PE
- kinds: meal, dessert

## DISH Q60825499
- name: Ajiaco
- description: typical soup of Colombia
- countries: (none)
- kinds: soup

## DISH Q6082957
- name: Porotos granados
- description: traditional Chilean stew
- countries: CL
- kinds: food, stew
- ingredients: Pochas
- has Wikipedia article: en

## DISH Q6083004
- name: Porra
- description: Spanish type of pan dough
- countries: ES
- kinds: fritter

## DISH Q6083159
- name: Tırşik çorbası
- description: poisonous plant
- countries: TR
- kinds: dish, organisms known by a particular common name

## DISH Q6083488
- name: Postre Balcarce
- description: Argentine dessert
- countries: (none)
- kinds: dessert
- ingredients: coconut, Pasta di mandorle PAT, sponge cake, dulce de leche, chestnut, whipped cream, meringue, walnut, powdered sugar
- has Wikipedia article: en

## DISH Q6083515
- name: Potaje carmelitano
- other names: {"es": "potaje carmelitano"}
- countries: ES
- cuisines: Spanish cuisine
- kinds: type of food or dish, potage

## DISH Q60836556
- name: Пряженина
- other names: {"ru": "Пряженина"}
- countries: (none)
- kinds: dish

## DISH Q60837189
- name: Crostini Toscani
- description: Tuscan crostini
- countries: IT
- kinds: crostini
- ingredients: pâté, toast

## DISH Q60837772
- name: Purcidd'
- other names: {"it": "Purcidd'"}
- countries: IT
- kinds: dessert

## DISH Q60839299
- name: Baci di Cremona
- other names: {"it": "Baci di Cremona"}
- countries: IT
- kinds: dessert

## DISH Q60841793
- name: Mécoulin
- other names: {"fr": "mécoulin"}
- countries: IT
- kinds: dessert

## DISH Q60841829
- name: Dolce Torino
- other names: {"it": "dolce Torino"}
- countries: IT
- kinds: dessert

## DISH Q60845769
- name: Torresmo
- other names: {"fr": "Torresmo"}
- countries: PT
- kinds: food
- ingredients: pig

## DISH Q60845894
- name: Рагу из оленины
- other names: {"ru": "рагу из оленины"}
- countries: (none)
- kinds: ragout
- ingredients: venison

## DISH Q60846082
- name: Shine Rice
- other names: {"de": "Shine Rice"}
- countries: (none)
- kinds: dish

## DISH Q60846897
- name: Seniyeh
- other names: {"de": "Seniyeh"}
- countries: (none)
- kinds: dish

## DISH Q60846962
- name: Eddoes Talkari
- other names: {"de": "Eddoes Talkari"}
- countries: (none)
- kinds: dish

## DISH Q60848614
- name: Teilchen
- other names: {"de": "Teilchen"}
- description: German pastry
- countries: (none)
- kinds: pastry

## DISH Q60850036
- name: Tatarczuch
- other names: {"pl": "Tatarczuch"}
- description: buckwheat bread
- countries: PL
- kinds: bread
- ingredients: buckwheat flour

## DISH Q60851443
- name: Tsatsa
- countries: BG
- cuisines: Bulgarian cuisine
- kinds: dish, fried fish

## DISH Q60851561
- name: Ingberlach
- description: desert of Jewish cuisine
- countries: IL
- cuisines: Jewish cuisine
- kinds: dessert, type of food or dish

## DISH Q6088454
- name: Bici bici
- other names: {"zh": "哔叽哔叽"}
- description: light summer dessert from Southern Turkey, especially Adana and Mersin provinces
- countries: TR
- cuisines: Turkish cuisine
- kinds: dish, dessert
- ingredients: corn starch, ice
- has Wikipedia article: en, zh

## DISH Q608979
- name: Fesenjān
- other names: {"zh": "紅石榴核桃燉雞"}
- description: Iranian stew
- countries: (none)
- kinds: type of food or dish, stew
- ingredients: pomegranate juice
- has Wikipedia article: en, zh

## DISH Q6090810
- name: Puchas
- other names: {"es": "Puchas"}
- countries: ES
- kinds: sweetness, dessert, Sierra de Francia
- ingredients: picatostes, oil, flour, Pimpinella anisum, table salt, sugar

## DISH Q6090816
- name: Puchero canario
- other names: {"es": "Puchero canario"}
- countries: (none)
- kinds: dish, cocido
- ingredients: garlic, chickpea, pineapple, corn on the cob, paprika, beef, pork, Cucurbita maxima, Phaseolus vulgaris, saffron, chorizo, bacon, chicken, carrot

## DISH Q6092760
- name: Pulte
- description: antique dish
- countries: ES
- kinds: dish

## DISH Q6093303
- name: Italian hot dog
- description: style of hot dog popular in New Jersey, USA
- countries: US
- kinds: food, hot dog
- ingredients: bread roll
- has Wikipedia article: en

## DISH Q6093643
- name: Pá-nolí
- other names: {"es": "Pá-nolí"}
- countries: ES
- kinds: dessert

## DISH Q6094013
- name: Arabaşı soup
- description: a traditional soup in Turkish cuisine
- countries: (none)
- kinds: soup, dish

## DISH Q60945230
- name: Dewberry jam
- description: jam made from dewberrys
- countries: (none)
- kinds: berry jam
- ingredients: dewberry, sugar

## DISH Q6094530
- name: Quesadilla herreña
- other names: {"es": "Quesadilla herreña"}
- countries: ES
- kinds: dessert

## DISH Q6094551
- name: Arribes de Salamanca Cheese
- countries: ES
- kinds: Spanish cheese, cheese

## DISH Q6094605
- name: Tronchon
- description: type of soft cheese from Spain
- countries: ES
- kinds: food, cheese, mixed milk cheese, type of cheese

## DISH Q6094633
- name: Ice cheeses
- countries: ES
- kinds: dessert

## DISH Q609505
- name: Bigoli
- description: type of pasta
- countries: IT
- kinds: type of pasta, pasta
- ingredients: whole-wheat flour
- has Wikipedia article: en

## DISH Q6095240
- name: Puçuko
- countries: TR
- kinds: dish

## DISH Q60964496
- name: Mariottes
- other names: {"fr": "Mariottes"}
- countries: (none)
- kinds: pastry

## DISH Q60968350
- name: Lammrostbiff
- other names: {"sv": "Lammrostbiff"}
- countries: (none)
- kinds: lamb meat, roast beef

## DISH Q60968355
- name: Grytbitar av lamm
- other names: {"sv": "Grytbitar av lamm"}
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat

## DISH Q60970570
- name: Pascal
- description: dish of Mexico
- countries: MX
- kinds: dish

## DISH Q60974738
- name: Краснодарский соус
- other names: {"ru": "Краснодарский соус"}
- countries: SU
- kinds: sauce, dish
- ingredients: spice, tomato, table salt, water

## DISH Q60977870
- name: Pâte à bombe
- description: Egg-based pastry base
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q60987380
- name: Tanukidon
- countries: JP
- kinds: donburi
- ingredients: tenkasu

## DISH Q60989866
- name: 房州びわゼリー
- other names: {"ja": "房州びわゼリー"}
- countries: (none)
- kinds: gelatin dessert

## DISH Q6099
- name: Escalope
- other names: {"zh": "香雞排"}
- description: breaded, fried flat piece of meat
- countries: FR
- kinds: food, meat, meat dish
- has Wikipedia article: en

## DISH Q60992501
- name: Beijing barbecue
- other names: {"zh": "炙子烤肉"}
- description: barbecued dish of Beijing, China
- countries: (none)
- kinds: meat dish
- has Wikipedia article: zh

## DISH Q60994541
- name: Danjiao
- other names: {"zh": "蛋饺"}
- description: Jiaozi wrapped in omelet
- countries: (none)
- kinds: jiaozi
- has Wikipedia article: zh

## DISH Q60996967
- name: Kelp stock
- countries: (none)
- kinds: stock, dashi
- ingredients: kombu

## DISH Q60997679
- name: Tai senbei
- countries: (none)
- kinds: senbei, Miyagegashi

## DISH Q6100269
- name: Ranfañote
- description: Peruvian bread pudding
- countries: PE
- kinds: dessert, bread pudding, meal
- ingredients: panela, Carya illinoinensis, walnut, bread

## DISH Q610130
- name: Charoset
- other names: {"zh": "棗泥醬"}
- description: a pastelike mixture of apples, nuts, cinnamon, and wine used during the seder meal on the Passover and symbolic of the clay from which the Israelites made bricks during their Egyptian slavery
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q61037096
- name: Caldo de carachama
- other names: {"es": "caldo de carachama"}
- countries: (none)
- kinds: meal, soup
- ingredients: Pseudorinelepis genibarbis

## DISH Q61043286
- name: Panadelsuppe
- other names: {"de": "Panadelsuppe"}
- countries: (none)
- kinds: dish

## DISH Q61045488
- name: Wing Bean Salad
- countries: TH
- kinds: salad, dish
- ingredients: Psophocarpus tetragonolobus

## DISH Q61057171
- name: Katsuo dashi
- countries: (none)
- kinds: dashi
- ingredients: katsuobushi

## DISH Q61058275
- name: Ushi-mabushi
- countries: (none)
- kinds: Japanese rice dish, beef dish

## DISH Q61065460
- name: Tabaheg
- description: traditional Balochi dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q6107288
- name: Revuelto Gramajo
- description: Argentinian potato dish
- countries: AR
- kinds: dish
- has Wikipedia article: en

## DISH Q61074537
- name: Stuffed cookie
- description: type of cookie
- countries: IR
- kinds: food, cookie, dessert
- has Wikipedia article: en

## DISH Q61075655
- name: Kabune pilavı
- other names: {"tr": "Kabune pilavı"}
- countries: TR
- kinds: dish

## DISH Q61075670
- name: Hamsiköy sütlacı
- countries: TR
- kinds: rice pudding

## DISH Q61075818
- name: Atom
- description: dessert from Turkey
- countries: (none)
- kinds: food, meringue
- ingredients: egg white, sugar, drinking water

## DISH Q61076655
- name: Hamsikoli
- other names: {"tr": "Hamsikoli"}
- countries: TR
- kinds: food
- ingredients: maize flour, European anchovy, chard, olive oil, onion

## DISH Q61078926
- name: Boil up
- description: Maori dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q610794
- name: Joppie sauce
- description: sauce made from mayonnaise, onions and curry powder
- countries: (none)
- kinds: condiment, sauce
- ingredients: onion, curry powder, mayonnaise
- has Wikipedia article: en

## DISH Q61081704
- name: Ciorbă rădăuțeană
- other names: {"ca": "Ciorbă rădăuțeană"}
- countries: RO
- kinds: ciorbă
- ingredients: chicken breast

## DISH Q61082068
- name: Chifteluțe marinate
- countries: RO
- kinds: dish

## DISH Q61085168
- name: Ciorbă de miel
- description: Romanian lamb soup
- countries: RO
- kinds: mutton soup
- ingredients: borș, lamb meat

## DISH Q61088572
- name: Kedah laksa
- description: Traditional Malaysian tangy, sour fish-based rice noodle soup originating from Kedah
- countries: MY
- cuisines: Malay cuisine
- kinds: laksa, noodle dish
- ingredients: rice noodle, Indian mackerel, chili pepper, Tamarindus indica

## DISH Q61088582
- name: Getas-getas
- countries: (none)
- kinds: food, Kuih

## DISH Q61090667
- name: Kkanpunggi
- description: Korean Chinese fried chicken dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q61090700
- name: Mul-kimchi
- other names: {"zh": "水辛奇"}
- description: Korean cuisine
- countries: (none)
- kinds: Kimchi

## DISH Q6109326
- name: Riñones al Jerez
- description: Spanish dish
- countries: (none)
- kinds: dish
- ingredients: sherry, kidney

## DISH Q61095632
- name: Eotang
- description: Korean fish soup
- countries: (none)
- kinds: guk, fish soup

## DISH Q61096026
- name: Momguk
- description: South Korean seaweed soup
- countries: KR
- kinds: guk
- ingredients: Sargassum fulvellum

## DISH Q61099328
- name: Cereal (Lotte Well Food)
- description: snack
- countries: (none)
- kinds: snack, confectionery

## DISH Q61114524
- name: Kewa datshi
- countries: BT
- cuisines: Bhutanese cuisine
- kinds: dish
- ingredients: Allium, table salt, potato, cheese

## DISH Q61114577
- name: Кева-фагша
- other names: {"ru": "Кева-фагша"}
- countries: BT
- kinds: dish
- ingredients: beef, potato

## DISH Q61114583
- name: Батура
- other names: {"uk": "Батура"}
- countries: (none)
- kinds: bread

## DISH Q611164
- name: Okroshka
- other names: {"zh": "俄羅斯凍湯"}
- description: Russian cold soup
- countries: RU
- cuisines: Russian cuisine
- kinds: food, cold sweet soup
- ingredients: culinary herb, potato, cucumber, boiled egg, smetana, kvass, table salt, carrot, dill, scallion, meat
- has Wikipedia article: en, zh

## DISH Q61117066
- name: Tanggo-tanggo
- description: Toba Batak food made from pork or dog meat
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, meat dish
- ingredients: Kaffir Lime Leaf, garlic, grated coconut, Andaliman, dog meat, bird's eye chili, Alpinia galanga, Allium ascalonicum, pork, chili pepper, Tamarindus indica, black pepper, Coriandrum sativum, ginger, Cymbopogon citratus, table salt, sugar

## DISH Q6112462
- name: Rosca madrileña
- other names: {"es": "rosca madrileña"}
- countries: (none)
- kinds: roscón

## DISH Q6112467
- name: Roscos de vi
- other names: {"ca": "Roscos de vi"}
- countries: ES
- kinds: dessert

## DISH Q6112469
- name: Roscos del Santo
- other names: {"es": "roscos del Santo"}
- countries: ES
- kinds: dessert, baked good, sweet bread

## DISH Q6112625
- name: Rosquillas de Ledesma
- other names: {"es": "rosquillas de Ledesma"}
- countries: (none)
- kinds: rosquilla

## DISH Q6112627
- name: Rosquillas de San Froilán
- other names: {"es": "rosquillas de San Froilán"}
- countries: (none)
- kinds: rosquilla

## DISH Q6112629
- name: Rosquillas de Santa Clara
- other names: {"es": "rosquillas de Santa Clara"}
- countries: ES
- kinds: dessert, rosquilla

## DISH Q6112632
- name: Rosquillas francesas
- other names: {"es": "rosquillas francesas"}
- countries: ES
- kinds: dessert

## DISH Q61127179
- name: Bánh phở
- description: wide Vietnamese rice noodle
- countries: VN
- kinds: food ingredient, rice noodle, bánh

## DISH Q61127980
- name: Сува пита
- other names: {"sr": "Сува пита"}
- countries: (none)
- kinds: dish

## DISH Q61128129
- name: Salčići
- description: Serbian dessert pastry
- countries: (none)
- kinds: dessert

## DISH Q61128132
- name: Reform torta
- description: Serbian multi-layer cake
- countries: RS
- cuisines: Serbian cuisine
- kinds: cake

## DISH Q61129128
- name: Kvrguša
- description: Bosnian savory pie
- countries: BA
- kinds: dish, pie
- ingredients: chicken as food, dough

## DISH Q61134376
- name: Leskovačka kavurma
- description: Serbian pork dish
- countries: RS
- kinds: dish, pork dish
- ingredients: pork skin

## DISH Q61139247
- name: Касапско мезе
- other names: {"bg": "Касапско мезе"}
- countries: (none)
- kinds: dish

## DISH Q6116728
- name: Sacristán (dulce)
- other names: {"es": "Sacristán (dulce)"}
- countries: ES
- kinds: dessert

## DISH Q6117020
- name: Sajta de pollo
- description: Bolivian chicken dish
- countries: (none)
- kinds: meal, chicken dish
- ingredients: chuño, chili pepper, chicken

## DISH Q6117115
- name: Saladilla
- other names: {"es": "Saladilla"}
- countries: (none)
- kinds: meal, bread, torta

## DISH Q6117451
- name: Salpicón de vaca
- other names: {"es": "Salpicón de vaca"}
- countries: (none)
- kinds: salad

## DISH Q6117472
- name: Devilled sauce
- description: Piquant or hot sauce
- countries: (none)
- kinds: sauce, dish

## DISH Q6119871
- name: Sancocho
- description: soup of Dominican Republic
- countries: (none)
- kinds: meal, soup

## DISH Q612128
- name: Pupusa
- other names: {"zh": "普普沙"}
- description: Salvadoran type of tortilla
- countries: SV
- kinds: meal, Salvadoran cuisine, tortilla
- ingredients: cornmeal, rice flour
- has Wikipedia article: en, zh

## DISH Q6121521
- name: Torrija
- description: traditional sweet
- countries: ES
- kinds: dessert
- ingredients: milk, bread

## DISH Q6121684
- name: Sapillos
- other names: {"es": "Sapillos"}
- countries: ES
- kinds: dessert

## DISH Q6121698
- name: Jaecheop-guk
- description: Korean clam soup
- countries: (none)
- kinds: food, guk, clam dish
- ingredients: clam
- has Wikipedia article: en

## DISH Q612283
- name: Brandade
- description: dish of cod, olive oil, and potatoes
- countries: FR
- kinds: fish dish
- ingredients: cod
- has Wikipedia article: en

## DISH Q6123113
- name: Seco
- description: Peruvian meat stew
- countries: (none)
- kinds: meal, dish, lamb dish
- ingredients: chicken as food, lamb meat, beef, meat
- has Wikipedia article: en

## DISH Q6125429
- name: Jakoten
- other names: {"zh": "雜魚天婦羅"}
- description: Fried surimi
- countries: JP
- kinds: fish surimi, agekamaboko
- ingredients: Poisson
- has Wikipedia article: en

## DISH Q6126022
- name: Jalamah
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat

## DISH Q612661
- name: Kalakukko
- other names: {"zh": "鱼包"}
- description: traditional food from the Finnish region of Savonia
- countries: FI
- cuisines: Finnish cuisine, Karelian cuisine
- kinds: dish, rye bread, fish dish, pork dish
- ingredients: fish fillet, rye flour, pork belly
- has Wikipedia article: en, zh

## DISH Q6126666
- name: Jalapeño popper
- other names: {"zh": "墨西哥辣椒酿芝士"}
- description: breaded, fried, stuffed jalapeño pepper
- countries: (none)
- kinds: stuffed peppers
- ingredients: minced meat, jalapeño
- has Wikipedia article: en

## DISH Q6127173
- name: Lanzhou beef noodle soup
- other names: {"zh": "兰州牛肉面"}
- description: beef noodle soup dish from Lanzhou, China
- countries: CN
- cuisines: Chinese cuisine
- kinds: type of food or dish, beef noodle soup, lamian
- ingredients: lamian
- has Wikipedia article: en, zh

## DISH Q6127463
- name: Jerk
- description: style of cooking native to Jamaica
- countries: (none)
- kinds: culinary speciality
- ingredients: jerk spice
- has Wikipedia article: en

## DISH Q61315167
- name: Narkeler naru
- description: Bengali sweet
- countries: (none)
- kinds: confectionery, laddu
- ingredients: coconut, jaggery, ghee, sugar

## DISH Q6131903
- name: Somarro
- description: Grilled lamb or pork roast
- countries: (none)
- kinds: dish

## DISH Q6132408
- name: Sopa de farigola
- other names: {"ca": "Sopa de farigola"}
- countries: (none)
- kinds: soup
- ingredients: Thymus vulgaris

## DISH Q6132420
- name: Sopa moruna
- other names: {"es": "sopa moruna"}
- countries: (none)
- kinds: type of food or dish, soup

## DISH Q6132427
- name: Sopas
- description: Food from the Middle Ages
- countries: ES
- kinds: dish

## DISH Q6132431
- name: Sopas de antruejo
- other names: {"es": "Sopas de antruejo"}
- countries: (none)
- kinds: soup, Extremaduran cuisine

## DISH Q6132434
- name: Sopa de Gato
- description: A thick soup from southern Spain
- countries: ES
- cuisines: Spanish cuisine
- kinds: food, soup
- ingredients: crumb
- has Wikipedia article: en

## DISH Q6132435
- name: Rastrojo soup
- countries: (none)
- kinds: soup

## DISH Q6132927
- name: Soyo
- description: soup
- countries: PY
- kinds: food, soup
- ingredients: meat
- has Wikipedia article: en

## DISH Q61355028
- name: Must cookie
- countries: GR
- kinds: cookie
- ingredients: clove, vegetable oil, must, flour, cinnamon, raisin

## DISH Q61355424
- name: Singara
- description: Snack
- countries: (none)
- kinds: pastry, samosa

## DISH Q61356432
- name: Slice of bread
- other names: {"zh": "吐司片"}
- description: a slice of bread to eat
- countries: (none)
- kinds: food, bread

## DISH Q61357071
- name: Kuriokowa
- description: Japanese dish containing chestnuts and rice usually eaten during the fall
- countries: JP
- kinds: okowa
- ingredients: chestnut, glutinous rice

## DISH Q61359762
- name: Chomchom of Belakoba
- countries: (none)
- kinds: confectionery, chomchom

## DISH Q61359888
- name: Kostar laddu
- countries: (none)
- kinds: confectionery, laddu

## DISH Q61360399
- name: Muger Jilipi
- countries: (none)
- kinds: confectionery, Jalebi

## DISH Q61360646
- name: Akhni
- description: Bengali rice dish
- countries: (none)
- kinds: mixed rice dish
- has Wikipedia article: en

## DISH Q61360738
- name: Chunga Pitha
- description: Traditional Assamese and Bengali rice cake
- countries: BD
- kinds: rice dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q61361153
- name: Gulai ikan asam padeh
- other names: {"id": "gulai ikan asam padeh"}
- countries: (none)
- kinds: dish, fish dish

## DISH Q61361712
- name: Beomuri
- countries: (none)
- kinds: tteok

## DISH Q61365210
- name: Ambal
- countries: (none)
- kinds: dish

## DISH Q61365250
- name: Dalna
- countries: (none)
- kinds: type of food or dish, vegetable dish

## DISH Q61365793
- name: Nam pla phrik
- description: Condiment used in Thai cuisine
- countries: TH
- kinds: condiment
- ingredients: fish sauce, Capsicum annuum

## DISH Q61366417
- name: Sylheti Duck Bamboo
- description: a curry, succulent duck with bamboo shoots
- countries: BD
- kinds: curry, duck dish
- ingredients: bamboo shoots, duck meat
- has Wikipedia article: en

## DISH Q61366482
- name: Soft Khichuri
- description: Rice dish associated with Ramadan
- countries: BD
- kinds: dish
- has Wikipedia article: en

## DISH Q6137009
- name: Aliado
- description: Chilean sandwich
- countries: CL
- kinds: meal, sandwich

## DISH Q613717
- name: Lampredotto
- description: Florentine dish
- countries: IT
- cuisines: Italian cuisine
- kinds: dish
- ingredients: abomasum, bread
- has Wikipedia article: en

## DISH Q6137769
- name: Cheese platter
- description: platter with various cheeses
- countries: (none)
- kinds: dish, platter

## DISH Q61378827
- name: Rico
- other names: {"gl": "Rico"}
- description: cookie
- countries: (none)
- kinds: cookie
- ingredients: Milk skin

## DISH Q61379780
- name: Ragaišis
- other names: {"lt": "Ragaišis"}
- countries: (none)
- kinds: bread

## DISH Q6139075
- name: Tarta capuchina
- other names: {"es": "Tarta capuchina"}
- countries: ES
- kinds: dessert

## DISH Q6139083
- name: Tarta típica de Jerez
- other names: {"es": "Tarta típica de Jerez"}
- countries: ES
- kinds: dessert

## DISH Q61407777
- name: Tapìt
- countries: IT
- kinds: food, biscuit
- ingredients: ammonium hydrogen carbonate, flour, sugar, water

## DISH Q6146843
- name: Tigre
- other names: {"eu": "Tigre"}
- countries: ES
- kinds: dish
- ingredients: onion, boiled egg, Mytilus galloprovincialis, bread crumbs

## DISH Q61473708
- name: Soft tunnbröd
- description: soft flatbread
- countries: (none)
- kinds: tunnbröd

## DISH Q61473727
- name: Crisp tunnbröd
- description: crisp flatbread
- countries: (none)
- kinds: tunnbröd

## DISH Q6147415
- name: Titaina
- description: Food from Valencia
- countries: (none)
- kinds: dish

## DISH Q614757
- name: Ovelgönne bread roll
- description: food
- countries: (none)
- kinds: bread, archaeological find
- has Wikipedia article: en

## DISH Q61497867
- name: Dambalkhacho
- countries: GE
- cuisines: Georgian cuisine
- kinds: Georgian cheese, dish
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q6150972
- name: Torta helada
- countries: PE
- kinds: meal, torta

## DISH Q6150975
- name: Torta Imperial
- countries: ES
- kinds: dessert

## DISH Q6150978
- name: Torta loca
- description: cake
- countries: ES
- kinds: pastry, dessert
- ingredients: egg yolk, sunflower oil, egg as food, flour, puff pastry, sugar

## DISH Q6150980
- name: Torta parda
- description: typical sweet from Cádíz
- countries: ES
- kinds: confectionery, dessert
- ingredients: Cabell d'àngel, almond, egg as food, spice, flour

## DISH Q6150997
- name: Tortilla de rodilla
- other names: {"es": "Tortilla de rodilla"}
- countries: ES
- kinds: dessert

## DISH Q6151004
- name: Tortilla paisana
- description: Spanish country-style omelette
- countries: (none)
- kinds: omelette

## DISH Q6151013
- name: Tortitas de Santa Clara
- other names: {"es": "Tortitas de Santa Clara"}
- countries: MX
- kinds: dessert

## DISH Q6151068
- name: Tostadas de crema
- other names: {"es": "Tostadas de crema"}
- countries: ES
- kinds: dessert

## DISH Q6151070
- name: Tostado
- countries: (none)
- kinds: dish, open sandwich

## DISH Q615315
- name: Moelleux au chocolat
- description: small chocolate cake
- countries: FR
- kinds: chocolate cake
- ingredients: butter

## DISH Q6154023
- name: Turriyones
- other names: {"es": "Turriyones"}
- countries: (none)
- kinds: dish, food

## DISH Q6154033
- name: Jangguk-juk
- description: Korean porridge
- countries: (none)
- kinds: juk
- ingredients: malgeun jangguk, beef
- has Wikipedia article: en

## DISH Q6155199
- name: Uchepo
- description: Mexican cuisine dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q61579505
- name: Chola sandwich
- description: Bolivian pork sandwich
- countries: BO
- cuisines: Bolivian cuisine
- kinds: meal, sandwich
- has Wikipedia article: en

## DISH Q61581272
- name: Tucumana
- countries: (none)
- kinds: street food, pie

## DISH Q61612
- name: Balsfjordost
- countries: NO
- kinds: goat cheese, cheese

## DISH Q6169641
- name: Yacuchupe
- other names: {"es": "yacuchupe"}
- countries: PE
- kinds: meal, soup

## DISH Q6169928
- name: Flavaĵoj de la Tranĉo
- other names: {"eo": "Flavaĵoj de la Tranĉo"}
- countries: ES
- kinds: dessert

## DISH Q6170718
- name: Zaalouk
- description: Moroccan dish
- countries: MA
- kinds: food, side dish
- ingredients: tomato, eggplant, bell pepper
- has Wikipedia article: en

## DISH Q6171844
- name: Zorongollo
- other names: {"es": "Zorongollo"}
- countries: (none)
- kinds: salad

## DISH Q617216
- name: Caramel shortbread
- description: Biscuit confectionery
- countries: (none)
- kinds: biscuit, confectionery, dessert bar
- ingredients: milk chocolate, shortbread, caramel
- has Wikipedia article: en

## DISH Q61743260
- name: Capra e fagioli
- description: Italian dish
- countries: IT
- kinds: goat meat dish, stew
- ingredients: common bean, goat meat, white wine
- has Wikipedia article: en

## DISH Q61750516
- name: Tartine
- description: open or buttered sandwich in Quebec
- countries: (none)
- kinds: type of food or dish, finger food, open sandwich
- ingredients: bread

## DISH Q61767137
- name: Blanco y negro
- other names: {"es": "Blanco y negro"}
- countries: ES
- kinds: meal, bocadillo

## DISH Q6176869
- name: Jello salad
- description: salad made with flavored gelatin, fruit, etc.
- countries: US
- kinds: salad, aspic
- ingredients: gelatin
- has Wikipedia article: en

## DISH Q6176900
- name: Jelly doughnut
- description: type of doughnut
- countries: (none)
- kinds: doughnut
- ingredients: gelatin dessert, stuffing
- has Wikipedia article: en

## DISH Q6177646
- name: Jenkki
- description: Finnish chewing gum brand
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q61794309
- name: Orange-flavoured crab meat
- other names: {"zh": "蟹酿橙"}
- description: crab dish in China
- countries: (none)
- kinds: crab dish
- ingredients: Brachyura, orange
- has Wikipedia article: zh

## DISH Q618291
- name: Jablko v županu
- other names: {"cs": "jablko v županu"}
- description: dish
- countries: (none)
- kinds: dish
- ingredients: dough, apple

## DISH Q618345
- name: Apple sauce
- other names: {"zh": "蘋果醬"}
- description: puréed apples
- countries: (none)
- kinds: purée, dish, mash
- ingredients: apple
- has Wikipedia article: en, zh

## DISH Q6185223
- name: Jerusalem mixed grill
- other names: {"zh": "耶路撒冷混和燒烤"}
- description: Israeli grilled meat dish
- countries: IL
- kinds: food, chicken dish
- has Wikipedia article: en

## DISH Q61888328
- name: Poppy seed roll
- other names: {"zh": "罌粟麵包卷"}
- description: pastry
- countries: (none)
- kinds: pastry, roll
- has Wikipedia article: en, zh

## DISH Q618910
- name: Fatoot
- description: food
- countries: YE
- kinds: food, bread
- has Wikipedia article: en

## DISH Q6189326
- name: Jeungpyeon
- other names: {"zh": "蒸饼"}
- description: Korean rice cake
- countries: (none)
- kinds: tteok
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q6189729
- name: Jewish apple cake
- description: dense cake made with apples and sold mostly in Pennsylvania, U.S.; not related to Jewish cuisine, despite its name
- countries: US
- kinds: food, cake
- ingredients: apple
- has Wikipedia article: en

## DISH Q61905778
- name: Baumerfladen
- other names: {"de": "Baumerfladen"}
- countries: (none)
- kinds: baked good

## DISH Q6192002
- name: Jibarito
- other names: {"zh": "炸大蕉三明治"}
- description: Green plantain sandwich
- countries: PR
- cuisines: cuisine of the United States
- kinds: food, sandwich
- ingredients: cooking banana, lettuce, tomato, mayonnaise, meat, cheese
- has Wikipedia article: en

## DISH Q6192074
- name: Jibu-ni
- description: Japanese meat stew dish
- countries: JP
- kinds: nimono, duck dish
- has Wikipedia article: en

## DISH Q6192335
- name: Jiggs dinner
- description: Canadian meal
- countries: CA
- kinds: dish
- has Wikipedia article: en

## DISH Q619414
- name: Abgoosht
- description: Iranian lamb dish
- countries: AM
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q61958895
- name: Prleška gibanica
- other names: {"sl": "prleška gibanica"}
- countries: SI
- kinds: Slovenian cuisine, layer cake

## DISH Q61964538
- name: Ají de achakana
- description: Bolivian dish
- countries: BO
- kinds: meal, stew
- ingredients: Neowerdermannia vorwerkii

## DISH Q61984600
- name: Rendang Talua
- description: egg dish with rendang spices
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, rendang
- ingredients: chicken egg, cooking oil, table salt

## DISH Q62005905
- name: Gorditas de nata
- description: Mexican dessert
- countries: MX
- kinds: dessert

## DISH Q62018789
- name: Discada
- description: rounded disc shaped cooking pan from northern Mexican and southwestern US cuisine
- countries: MX
- cuisines: Mexican cuisine, cuisine of the Southwestern United States
- kinds: dish, cookware and bakeware
- has Wikipedia article: en

## DISH Q62019316
- name: Roman pizza
- other names: {"zh": "羅馬披薩"}
- description: style of pizza originating in Rome
- countries: IT
- cuisines: Roman cuisine
- kinds: type of pizza
- ingredients: yellow cheese, dough
- has Wikipedia article: en, zh

## DISH Q62067066
- name: Tacacho
- description: Peruvian breakfast dish
- countries: (none)
- kinds: meal, banana dish
- has Wikipedia article: en

## DISH Q62067425
- name: Girella
- description: Italian dessert
- countries: (none)
- kinds: confectionery

## DISH Q62096367
- name: Kamferdrops
- description: Norwegian candy
- countries: (none)
- kinds: candy
- ingredients: camphor

## DISH Q620967
- name: Appenzeller Pantli IGP
- description: Swiss regional dried sausage
- countries: CH
- kinds: meat dish, Rohwurst, dry sausage
- ingredients: garlic, peppercorn, sausage casing, lardo, beef, pork, table salt

## DISH Q62101829
- name: Maulwurfkuchen
- other names: {"de": "Maulwurfkuchen"}
- countries: DE
- kinds: torte

## DISH Q62102359
- name: Longaniza de Aragón
- description: cured sausage typical of Aragon, Spain
- countries: ES
- kinds: food, embutido, linguiça
- ingredients: nutmeg, cinnamon, clove, table salt, garlic, peppercorn, pork, Origanum vulgare, Cuminum cyminum

## DISH Q6214793
- name: Jogi-jeot
- description: Korean condiment
- countries: (none)
- kinds: jeotgal
- ingredients: Larimichthys polyactis
- has Wikipedia article: en

## DISH Q622440
- name: Antipasto
- other names: {"zh": "前菜 (意大利)"}
- description: first course of a formal Italian meal
- countries: IT
- cuisines: Italian cuisine
- kinds: finger food, appetizer
- ingredients: cold cut
- has Wikipedia article: en, zh

## DISH Q622547
- name: Century egg
- other names: {"zh": "皮蛋"}
- description: Chinese egg-based culinary dish
- countries: CN
- cuisines: Chinese cuisine
- kinds: food, dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q62271704
- name: Belgian waffle
- description: breakfast waffle with light batter, large squares, and deep pockets
- countries: BE
- kinds: dish, waffle
- has Wikipedia article: en

## DISH Q623247
- name: Shkedei marak
- description: Israeli crouton
- countries: IL
- kinds: dish
- ingredients: flour
- has Wikipedia article: en

## DISH Q623550
- name: Bavarian cream
- other names: {"zh": "巴伐利亚奶油"}
- description: custard sauce
- countries: FR
- kinds: custard pudding
- ingredients: egg as food, milk
- has Wikipedia article: en, zh

## DISH Q623923
- name: Croquembouche
- other names: {"zh": "焦糖奶油松饼"}
- description: French dessert
- countries: FR
- cuisines: French cuisine
- kinds: dish
- ingredients: profiterole, caramel
- has Wikipedia article: en, zh

## DISH Q624004
- name: Mousse
- other names: {"zh": "慕斯"}
- description: soft prepared dessert that incorporates air bubbles to give it a light and airy texture
- countries: FR
- kinds: food, dish, culinary foam
- ingredients: beaten egg whites, egg as food
- has Wikipedia article: en, zh

## DISH Q62419125
- name: Schottsuppe
- other names: {"de": "Schottsuppe"}
- countries: (none)
- kinds: soup

## DISH Q624391
- name: Arabisches Reiterfleisch
- other names: {"de": "Arabisches Reiterfleisch"}
- countries: (none)
- kinds: meat dish

## DISH Q625539
- name: Hodu-gwaja
- description: Korean confection
- countries: KR
- cuisines: South Korean cuisine
- kinds: cookie
- ingredients: walnut, dough
- has Wikipedia article: en

## DISH Q625825
- name: Custard
- other names: {"zh": "奶黄"}
- description: variety of culinary preparations based on a cooked mixture of milk or cream and egg yolk
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: pastry, dessert with spoon
- ingredients: chicken egg yolk, vanilla, sugar, milk
- has Wikipedia article: en, zh

## DISH Q626125
- name: Agwi-jjim
- description: seafood dish, traditional in Korea
- countries: (none)
- kinds: fish dish
- ingredients: Lophiomus setigerus
- has Wikipedia article: en

## DISH Q626147
- name: Buldak
- other names: {"zh": "火辣鸡"}
- description: South Korean dish of chicken in a spicy sauce
- countries: KR
- kinds: food, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q626167
- name: Bunsik
- other names: {"zh": "粉食"}
- description: type of Korean dish
- countries: (none)
- kinds: dish
- ingredients: flour
- has Wikipedia article: en

## DISH Q6267210
- name: Johnny Marzetti
- description: Italian-American pasta dish
- countries: US
- cuisines: cuisine of the United States
- kinds: pasta dish
- ingredients: macaroni
- has Wikipedia article: en

## DISH Q626723
- name: Korean fried chicken
- other names: {"zh": "韓式炸雞"}
- description: fried chicken dishes created in South Korea
- countries: KR
- kinds: fried chicken
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q6269807
- name: Jokpyeon
- description: Korean aspic
- countries: (none)
- kinds: aspic
- ingredients: cow's trotters
- has Wikipedia article: en

## DISH Q6269826
- name: Jolada Rotti
- other names: {"zh": "高粱羅提"}
- description: Bread for the most of the North Karnataka
- countries: IN
- kinds: food, bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q627744
- name: Cacciatore
- other names: {"zh": "獵人燴雞"}
- description: Italian style of cuisine
- countries: IT
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q6279092
- name: Jos. Louis
- description: Canadian cake snack
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q629345
- name: Green curry
- other names: {"zh": "綠咖哩"}
- description: central Thai variety of curry
- countries: TH
- cuisines: Thai cuisine
- kinds: Thai curry
- ingredients: green curry paste, Thai eggplant, coconut milk
- has Wikipedia article: en, zh

## DISH Q6297757
- name: Jaynagarer Moa
- description: confectionery of West Bengal, India
- countries: IN
- kinds: confectionery, dessert
- ingredients: Kanakchur, cardamom, cashew nut, clarified butter, poppy seed, date, jaggery, ghee, puffed rice, raisin
- has Wikipedia article: en

## DISH Q629936
- name: Barros Jarpa
- description: Chilean sandwich with ham and melted cheese
- countries: CL
- kinds: sandwich
- ingredients: ham, cheese, bread
- has Wikipedia article: en
