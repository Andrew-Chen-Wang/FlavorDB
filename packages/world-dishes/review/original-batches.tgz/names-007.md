# Review batch names-007

## DISH Q108788274
- name: Nachos at Maya
- description: dish
- countries: US
- cuisines: Mexican cuisine
- kinds: dish
- ingredients: nachos

## DISH Q108794171
- name: Seonji-guk
- description: Korean blood stew
- countries: (none)
- kinds: guk
- has Wikipedia article: en

## DISH Q108794274
- name: Sweet and sour pork
- description: type of pork dish
- countries: (none)
- kinds: pork dish

## DISH Q108794306
- name: Subuta
- countries: (none)
- kinds: dish

## DISH Q108794909
- name: Topfenknödel
- countries: CZ
- cuisines: Austrian cuisine
- kinds: knödel, dish

## DISH Q108798661
- name: Southern fried chicken
- other names: {"zh": "美式炸雞"}
- description: fried chicken dish from the Southern United States
- countries: US
- kinds: fried chicken, type of food or dish
- has Wikipedia article: en, zh

## DISH Q108799327
- name: Niku-dofu
- countries: (none)
- kinds: dish

## DISH Q108808117
- name: Tuhuk fish satay
- description: Indonesian traditional food from Lampung
- countries: ID
- cuisines: Indonesian cuisine
- kinds: satay, dish, Indonesian cuisine, human food, traditional food, type of food or dish

## DISH Q108808119
- name: Pringsewu fish pindang
- description: fish soup from Lampung, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish

## DISH Q108808122
- name: Pindang bawung
- other names: {"id": "pindang bawung"}
- countries: ID
- kinds: food

## DISH Q108808192
- name: Peros masin
- other names: {"id": "peros masin"}
- countries: ID
- kinds: dish

## DISH Q10882706
- name: Artalejo
- other names: {"es": "Artalejo"}
- countries: (none)
- kinds: pie

## DISH Q10883503
- name: Ningyōyaki
- other names: {"zh": "人形烧"}
- countries: (none)
- kinds: Miyagegashi, wagashi
- ingredients: sweet bean paste
- has Wikipedia article: zh

## DISH Q108839458
- name: Crispy deep-fried mushroom
- description: Indonesian deep-fried battered mushroom
- countries: ID
- kinds: fried mushrooms
- ingredients: cooking oil, Pleurotus ostreatus

## DISH Q108841343
- name: K-brot
- description: German potato and rye wartime bread
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q108887239
- name: Pyzy
- other names: {"zh": "皮茲"}
- description: Polish potato dumplings (boiled in water) or yeast dumplings (steamed or baked)
- countries: (none)
- kinds: dish, knödel
- has Wikipedia article: en

## DISH Q10889060
- name: Tounao
- other names: {"zh": "傅山头脑"}
- description: mutton stew in Taiyuan, Shanxi, China, commonly eaten for breakfast
- countries: CN
- kinds: soup
- ingredients: lees, mutton, Dioscorea polystachya, wheat flour, Lotus rhizome
- has Wikipedia article: zh

## DISH Q10889324
- name: Sah-koa Noodles
- other names: {"zh": "煠寡麵"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: noodle dish
- has Wikipedia article: zh

## DISH Q108893457
- name: Crab bisque
- description: dish
- countries: FR
- kinds: bisque, dish
- ingredients: crab

## DISH Q108905093
- name: Dalgona
- other names: {"zh": "韩式椪糖"}
- description: Korean sugar candy
- countries: (none)
- kinds: sugar candy
- has Wikipedia article: en, zh

## DISH Q1089051
- name: Tripe soup
- other names: {"zh": "肚湯"}
- description: soup
- countries: (none)
- kinds: food, meat soup
- ingredients: tripe
- has Wikipedia article: en, zh

## DISH Q108919208
- name: Kari kapitan
- description: Indonesian Chinese cuisine
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q10892132
- name: 八寶冬粉
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q10892305
- name: Fried noodle with eight treasures
- other names: {"zh": "八珍炒麵"}
- countries: CN
- kinds: fried noodle, Chinese noodles
- has Wikipedia article: zh

## DISH Q108929231
- name: Taochiao
- countries: (none)
- kinds: fermented bean paste

## DISH Q108937158
- name: Causa ferreñafana
- other names: {"es": "causa ferreñafana"}
- countries: (none)
- kinds: dish
- ingredients: aji amarillo, chicken egg, corn on the cob, olive, lemon, cooking banana, Lactuca sativa

## DISH Q10894961
- name: Maocai
- other names: {"zh": "冒菜"}
- description: Chinese stew-like dish
- countries: CN
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q10895227
- name: Wintermelon soup
- other names: {"zh": "冬瓜盅"}
- countries: (none)
- kinds: soup
- has Wikipedia article: zh

## DISH Q108952861
- name: Kartofle pod beszamelem — inaczej
- other names: {"pl": "Kartofle pod beszamelem — inaczej"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108952869
- name: Kartofle smażone po francusku
- other names: {"pl": "Kartofle smażone po francusku"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108952877
- name: Kartofle tłuczone
- other names: {"pl": "Kartofle tłuczone"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108952885
- name: Kartofle w mundurach
- other names: {"pl": "Kartofle w mundurach"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108952893
- name: Kartofle z pieca
- other names: {"pl": "Kartofle z pieca"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108952902
- name: Kartofle zapiekane z grzybami
- other names: {"pl": "Kartofle zapiekane z grzybami"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108952910
- name: Kartofle zapiekane z rybą wędzoną
- other names: {"pl": "Kartofle zapiekane z rybą wędzoną"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108952919
- name: Kartofle zapiekane z serem
- other names: {"pl": "Kartofle zapiekane z serem"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108952926
- name: Kartofle ze słoniną
- other names: {"pl": "Kartofle ze słoniną"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108952935
- name: Kartofle ze śledziem
- other names: {"pl": "Kartofle ze śledziem"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108952943
- name: Kasza kartoflana z makiem
- other names: {"pl": "Kasza kartoflana z makiem"}
- description: potato dish
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962279
- name: Kluski kartoflane, delikatniejsze
- other names: {"pl": "Kluski kartoflane, delikatniejsze"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962283
- name: Kluski z surowych kartofli
- other names: {"pl": "Kluski z surowych kartofli"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962285
- name: Kluski z surowych kartofli zapiekane
- other names: {"pl": "Kluski z surowych kartofli zapiekane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962288
- name: Knedel czeski, w serwecie
- other names: {"pl": "Knedel czeski, w serwecie"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962291
- name: Knedle kartoflane
- other names: {"pl": "Knedle kartoflane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962295
- name: Knedle saskie
- other names: {"pl": "Knedle saskie"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962297
- name: Knedle turyńgskie
- other names: {"pl": "Knedle turyńgskie"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962300
- name: Kotlety kartoflane — inaczej
- other names: {"pl": "Kotlety kartoflane — inaczej"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962303
- name: Kotlety kartoflane (z ciasta na krokietki)
- other names: {"pl": "Kotlety kartoflane (z ciasta na krokietki)"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962306
- name: Kotlety kartoflane (zwykłe)
- other names: {"pl": "Kotlety kartoflane (zwykłe)"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962309
- name: Kotlety kartoflane z „duszą“
- other names: {"pl": "Kotlety kartoflane z „duszą“"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962311
- name: Kotlety kartoflane z nadzieniem mięsnem
- other names: {"pl": "Kotlety kartoflane z nadzieniem mięsnem"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962313
- name: Kotlety z kartofli i jaj
- other names: {"pl": "Kotlety z kartofli i jaj"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962316
- name: Krokietki kartoflane
- other names: {"pl": "Krokietki kartoflane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962319
- name: Krokietki kartoflane — inaczej
- other names: {"pl": "Krokietki kartoflane — inaczej"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962322
- name: Paszteciki kartoflane
- other names: {"pl": "Paszteciki kartoflane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962326
- name: Pasztet z kartofli
- other names: {"pl": "Pasztet z kartofli"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962329
- name: Pierogi kartoflane — inaczej
- other names: {"pl": "Pierogi kartoflane — inaczej"}
- countries: (none)
- kinds: recipe, pierogi, potato dish

## DISH Q108962332
- name: Pierogi z kartoflami
- other names: {"pl": "Pierogi z kartoflami"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962335
- name: Purée kartoflane
- other names: {"pl": "Purée kartoflane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962339
- name: Racuchy z kartofli — inaczej
- other names: {"pl": "Racuchy z kartofli — inaczej"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962342
- name: Racuchy z surowych kartofli
- other names: {"pl": "Racuchy z surowych kartofli"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962345
- name: Racuszki niemieckie
- other names: {"pl": "Racuszki niemieckie"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962347
- name: Sałata kartofl. z sosem majonezowym
- other names: {"pl": "Sałata kartofl. z sosem majonezowym"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962350
- name: Sałata kartoflana — inaczej
- other names: {"pl": "Sałata kartoflana — inaczej"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962353
- name: Sałata kartoflana z pomidorami
- other names: {"pl": "Sałata kartoflana z pomidorami"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962356
- name: Sałata z kartofli z rzeżuchą
- other names: {"pl": "Sałata z kartofli z rzeżuchą"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962359
- name: Słodkie placuszki kartoflane
- other names: {"pl": "Słodkie placuszki kartoflane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108962362
- name: Słowo wstępne
- other names: {"pl": "Słowo wstępne"}
- countries: (none)
- kinds: potato dish, recipe

## DISH Q108962365
- name: Stare kartofle, jak młode
- other names: {"pl": "Stare kartofle, jak młode"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q10896709
- name: Dāoxiāo miàn
- other names: {"zh": "刀削面"}
- description: Shanxi noodles
- countries: CN
- kinds: noodle dish
- ingredients: knife-cut noodle
- has Wikipedia article: en, zh

## DISH Q108971756
- name: „Gnochi“ włoskie
- other names: {"pl": "„Gnochi“ włoskie"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971759
- name: Babka z surowych kartofli
- other names: {"pl": "Babka z surowych kartofli"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971762
- name: Bomby kartoflane
- other names: {"pl": "Bomby kartoflane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971768
- name: Delikatne racuszki z surowych kartofli
- other names: {"pl": "Delikatne racuszki z surowych kartofli"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971771
- name: Forszmak
- other names: {"pl": "Forszmak"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971774
- name: Kartofelki „Lyonnaises“
- other names: {"pl": "Kartofelki „Lyonnaises“"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971777
- name: Kartofelki drążone
- other names: {"pl": "Kartofelki drążone"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971780
- name: Kartofelki surowe smażone
- other names: {"pl": "Kartofelki surowe smażone"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971783
- name: Kartoflanka na mleku
- other names: {"pl": "Kartoflanka na mleku"}
- countries: (none)
- kinds: soup, recipe, potato dish, potato soup

## DISH Q108971785
- name: Kartoflanka z pieczarkami
- other names: {"pl": "Kartoflanka z pieczarkami"}
- countries: (none)
- kinds: soup, recipe, potato dish, potato soup

## DISH Q108971788
- name: Kartofle „Duchesse“
- other names: {"pl": "Kartofle „Duchesse“"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971791
- name: Kartofle gotowane
- other names: {"pl": "Kartofle gotowane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971794
- name: Kartofle nadziewane
- other names: {"pl": "Kartofle nadziewane"}
- countries: (none)
- kinds: recipe, potato dish, chapter

## DISH Q108971797
- name: Kartofle nadziewane mięsem
- other names: {"pl": "Kartofle nadziewane mięsem"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971798
- name: Kartofle nadziewane pieczarkami
- other names: {"pl": "Kartofle nadziewane pieczarkami"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108971800
- name: Kartofle nadziewane szynką
- other names: {"pl": "Kartofle nadziewane szynką"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q108991482
- name: Kartofle — bomby
- other names: {"pl": "Kartofle — bomby"}
- countries: (none)
- kinds: recipe, chapter, potato dish

## DISH Q108991498
- name: Kartofle pieczone bez łupin
- other names: {"pl": "Kartofle pieczone bez łupin"}
- countries: (none)
- kinds: recipe, chapter, potato dish

## DISH Q108991507
- name: Kartofle smażone na oleju
- other names: {"pl": "Kartofle smażone na oleju"}
- countries: (none)
- kinds: recipe, chapter, potato dish

## DISH Q108991515
- name: Kartofle stare, jak młode
- other names: {"pl": "Kartofle stare, jak młode"}
- countries: (none)
- kinds: recipe, chapter, potato dish

## DISH Q108991525
- name: Kartofle wypiekane z formy
- other names: {"pl": "Kartofle wypiekane z formy"}
- countries: (none)
- kinds: recipe, chapter, potato dish

## DISH Q10899266
- name: Gua-bao
- other names: {"zh": "割包"}
- description: a flat folded steamed bun sandwiching various meats in Fujian cuisine
- countries: CN
- kinds: type of food or dish, sandwich, pork dish
- ingredients: Lotus leaf bread, coriander seed, pork belly, mustard, peanut
- has Wikipedia article: en, zh

## DISH Q1089959
- name: Churrasco
- other names: {"zh": "巴西烤肉"}
- description: Iberian barbecue
- countries: BR, ES
- kinds: meat dish
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q109007893
- name: Racuchy kartoflane
- other names: {"pl": "Racuchy kartoflane"}
- countries: (none)
- kinds: recipe, chapter, potato dish

## DISH Q109007896
- name: Racuchy kartoflane z owsianą mąką
- other names: {"pl": "Racuchy kartoflane z owsianą mąką"}
- countries: (none)
- kinds: recipe, chapter, potato dish

## DISH Q1090081
- name: Khuushuur
- other names: {"zh": "合子"}
- description: Mongolian food
- countries: MN
- kinds: food, stuffed pasta
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q109016652
- name: Ah Caramel!
- other names: {"fr": "Ah Caramel!"}
- countries: (none)
- kinds: dish

## DISH Q109017052
- name: Atasí
- other names: {"fon": "Atasí"}
- countries: (none)
- kinds: dish

## DISH Q109017053
- name: Acɔnmɔ
- other names: {"fon": "Acɔnmɔ"}
- countries: (none)
- kinds: dish

## DISH Q109017123
- name: Avaro
- description: Traditional bread from the Tuamotu Islands
- countries: (none)
- kinds: bread

## DISH Q109017302
- name: البسطيلة الحرة
- other names: {"ar": "البسطيلة الحرة"}
- countries: (none)
- kinds: dish

## DISH Q109017516
- name: Biscuit de Chablis
- other names: {"fr": "biscuit de Chablis"}
- countries: (none)
- kinds: dish

## DISH Q109017584
- name: Bomiwô
- description: Beninese dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q109017628
- name: بوبانيطة
- other names: {"ar": "بوبانيطة"}
- countries: (none)
- kinds: dish

## DISH Q109017637
- name: Boufertouna
- other names: {"fr": "boufertouna"}
- countries: (none)
- kinds: dish

## DISH Q109017674
- name: Bras de gitan
- other names: {"fr": "bras de gitan"}
- countries: (none)
- kinds: dish

## DISH Q109017702
- name: Briquet (alimentation)
- other names: {"fr": "Briquet (alimentation)"}
- countries: (none)
- kinds: casse-croûte

## DISH Q109017738
- name: Byala
- other names: {"fr": "byala"}
- countries: (none)
- kinds: dish

## DISH Q109017895
- name: Carotte de Saint-Valery
- other names: {"fr": "Carotte de Saint-Valery"}
- countries: (none)
- kinds: carrot

## DISH Q109019732
- name: Dholl puri
- description: deep fried flatbread filled with lentils
- countries: MU
- kinds: pancake, Dalpuri, flatbread
- ingredients: lentil, split chickpea, wheat flour

## DISH Q109019813
- name: Dariole d'Amiens
- other names: {"fr": "dariole d'Amiens"}
- countries: (none)
- kinds: dish

## DISH Q109021226
- name: Èba
- description: Beninese cuisine classic made with cassava flour
- countries: BJ
- kinds: dish

## DISH Q109024081
- name: Espérantine
- other names: {"fr": "espérantine"}
- countries: (none)
- kinds: dish

## DISH Q109036311
- name: كسكس بالبيض واللوز
- other names: {"ar": "كسكس بالبيض واللوز"}
- countries: (none)
- kinds: dish

## DISH Q109037701
- name: Douida
- description: dish from Rabat, Morocco
- countries: MA
- kinds: dish

## DISH Q109037735
- name: Fénétra
- other names: {"fr": "fénétra"}
- countries: (none)
- kinds: dish

## DISH Q109037785
- name: Févi
- countries: BJ
- kinds: culinary speciality

## DISH Q109037952
- name: فورما (طبق)
- other names: {"ar": "فورما (طبق)"}
- countries: TN
- cuisines: Tunisian cuisine
- kinds: dish
- ingredients: ketchup, egg as food, parsley, tagliatelle

## DISH Q109038040
- name: Galopin
- other names: {"fr": "galopin"}
- countries: (none)
- kinds: dish

## DISH Q109038189
- name: قناوية
- other names: {"ar": "قناوية"}
- countries: (none)
- kinds: dish

## DISH Q109038487
- name: Groux
- other names: {"fr": "groux"}
- countries: (none)
- kinds: porridge, dish
- ingredients: buckwheat flour

## DISH Q109038648
- name: Haricot de Soissons
- other names: {"fr": "haricot de Soissons"}
- countries: (none)
- kinds: dish

## DISH Q109039280
- name: Ifisashi
- description: Zambian food
- countries: ZM
- kinds: food, dish
- ingredients: onion, peanut oil, pumpkin, tomato, water
- has Wikipedia article: en

## DISH Q109039736
- name: Nage
- other names: {"fr": "nage"}
- countries: (none)
- kinds: dish

## DISH Q109040741
- name: Paleppa
- other names: {"fr": "paleppa"}
- countries: (none)
- kinds: dish

## DISH Q109040805
- name: Panzarotti
- other names: {"fr": "Panzarotti"}
- countries: (none)
- kinds: beignet

## DISH Q109040989
- name: Ka‘ak rbati
- other names: {"fr": "ka‘ak rbati"}
- description: almond-based Moroccan dessert
- countries: (none)
- kinds: dish

## DISH Q109041241
- name: Petit Fouleng
- other names: {"fr": "Petit Fouleng"}
- countries: BE
- kinds: goat cheese

## DISH Q109041526
- name: Kefta hrech
- other names: {"fr": "kefta hrech"}
- countries: (none)
- kinds: dish

## DISH Q109041589
- name: Kilibibi
- other names: {"fr": "Kilibibi"}
- countries: (none)
- kinds: sweetmeat

## DISH Q109041733
- name: Kom
- other names: {"fr": "kom"}
- countries: (none)
- kinds: dish

## DISH Q109041756
- name: Kondogo
- other names: {"fr": "kondogo"}
- countries: (none)
- kinds: dish

## DISH Q109041767
- name: Popelin
- other names: {"fr": "popelin"}
- countries: (none)
- kinds: pastry

## DISH Q109041787
- name: Kɔnkádà
- other names: {"fon": "Kɔnkádà"}
- countries: (none)
- kinds: dish

## DISH Q109042474
- name: Quénieu
- other names: {"fr": "quénieu"}
- countries: (none)
- kinds: viennoiserie

## DISH Q109042573
- name: Lamfarchakh
- other names: {"fr": "Lamfarchakh"}
- countries: (none)
- kinds: dish

## DISH Q109042764
- name: Le Cru du Clocher
- other names: {"fr": "Le Cru du Clocher"}
- description: Canadian raw milk cheese
- countries: CA
- kinds: cheese, raw-milk cheese, cow's-milk cheese, cheese from Quebec

## DISH Q109043967
- name: Macaron de Montmorillon
- other names: {"fr": "macaron de Montmorillon"}
- countries: (none)
- kinds: dish

## DISH Q109043970
- name: Macaron de Saint-Émilion
- other names: {"fr": "macaron de Saint-Émilion"}
- countries: (none)
- kinds: dish

## DISH Q109043983
- name: Sauce Albert
- other names: {"fr": "sauce Albert"}
- countries: (none)
- kinds: dish

## DISH Q109043993
- name: Sauce poulette
- other names: {"fr": "sauce poulette"}
- countries: (none)
- kinds: dish

## DISH Q109044011
- name: Madeleine du Pic
- other names: {"fr": "madeleine du Pic"}
- countries: (none)
- kinds: dish

## DISH Q109044260
- name: Ma tɛnjan
- other names: {"fon": "Ma tɛnjan"}
- countries: (none)
- kinds: dish

## DISH Q109044372
- name: Marchouqa
- other names: {"fr": "marchouqa"}
- countries: (none)
- kinds: dish

## DISH Q109044541
- name: Mataba
- other names: {"fr": "mataba"}
- countries: (none)
- kinds: dish

## DISH Q109044874
- name: المصرانة
- other names: {"ar": "المصرانة"}
- countries: (none)
- kinds: dish

## DISH Q109044882
- name: Soupe des hortillons
- other names: {"fr": "soupe des hortillons"}
- countries: (none)
- kinds: dish

## DISH Q109045015
- name: ميكاز
- other names: {"ar": "ميكاز"}
- countries: (none)
- kinds: dish

## DISH Q109045435
- name: Taillis
- other names: {"fr": "Taillis"}
- countries: (none)
- kinds: bread pudding

## DISH Q109045443
- name: Monyo
- description: Beninese sauce
- countries: BJ
- kinds: sauce, dish

## DISH Q109045445
- name: Talé-talé
- other names: {"fon": "Talé-talé"}
- countries: (none)
- kinds: dish

## DISH Q109045517
- name: Tarte à l'badrée
- description: French dessert
- countries: FR
- kinds: dish
- has Wikipedia article: en

## DISH Q109045526
- name: Tartouillat
- other names: {"fr": "Tartouillat"}
- countries: (none)
- kinds: clafoutis

## DISH Q109045609
- name: Telibɔ
- other names: {"fon": "Telibɔ"}
- countries: (none)
- kinds: dish

## DISH Q109045733
- name: Tévi
- other names: {"fon": "Tévi"}
- countries: (none)
- kinds: dish

## DISH Q109046610
- name: Wèli
- description: Beninese dish of fried potatoes
- countries: BJ
- kinds: dish

## DISH Q109046650
- name: Wôkoli
- description: Beninese culinary preparation made from wɔ̌
- countries: BJ
- kinds: dish
- ingredients: wo

## DISH Q109046795
- name: Mami btakan
- other names: {"zh": "竹筒飯"}
- countries: (none)
- kinds: rice in bamboo
- has Wikipedia article: zh

## DISH Q109046939
- name: Safran de Mund AOC
- description: spice from the Swiss village of Mund
- countries: CH
- kinds: spice

## DISH Q109071240
- name: Alu diye gule machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q10908539
- name: Gunkanmaki
- other names: {"zh": "军舰寿司"}
- description: sushi
- countries: JP
- cuisines: Japanese cuisine
- kinds: makizushi
- ingredients: red caviar, Oryza, nori
- has Wikipedia article: zh

## DISH Q109093343
- name: Kartofle nadziewane śledziem
- other names: {"pl": "Kartofle nadziewane śledziem"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093346
- name: Kartofle nadziewane wędzoną rybą
- other names: {"pl": "Kartofle nadziewane wędzoną rybą"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093348
- name: Kartofle nadziewane zapiekane z serem
- other names: {"pl": "Kartofle nadziewane zapiekane z serem"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093351
- name: Kartofle pieczone w łupinach
- other names: {"pl": "Kartofle pieczone w łupinach"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093353
- name: Kartofle pieczone, obierane
- other names: {"pl": "Kartofle pieczone, obierane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093355
- name: Kartofle po czesku
- other names: {"pl": "Kartofle po czesku"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093358
- name: Kartofle po włosku
- other names: {"pl": "Kartofle po włosku"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093360
- name: Kartofle po włosku — inaczej
- other names: {"pl": "Kartofle po włosku — inaczej"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093362
- name: Kartofle pod beszamelem
- other names: {"pl": "Kartofle pod beszamelem"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093365
- name: Kasza puchowa
- other names: {"pl": "Kasza puchowa"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093367
- name: Kluski kartoflane
- other names: {"pl": "Kluski kartoflane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093369
- name: Suflet kartoflany — inaczej
- other names: {"pl": "Suflet kartoflany — inaczej"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093371
- name: Suflet z kartofli
- other names: {"pl": "Suflet z kartofli"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093374
- name: Torcik kartoflany z serem
- other names: {"pl": "Torcik kartoflany z serem"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093376
- name: Wykwintne purée kartoflane
- other names: {"pl": "Wykwintne purée kartoflane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093378
- name: Zupa kartoflana z porami
- other names: {"pl": "Zupa kartoflana z porami"}
- countries: (none)
- kinds: potato soup, soup, recipe, potato dish

## DISH Q109093380
- name: Zwykła kartoflanka
- other names: {"pl": "Zwykła kartoflanka"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q109093383
- name: Zwykłe kartofle przysmażane
- other names: {"pl": "Zwykłe kartofle przysmażane"}
- countries: (none)
- kinds: recipe, potato dish

## DISH Q10909628
- name: 卜肉
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q10910138
- name: Luzhu Huoshao
- other names: {"zh": "卤煮火烧"}
- description: pork offal dish
- countries: CN
- kinds: offal, meat dish
- has Wikipedia article: en, zh

## DISH Q10910301
- name: Moje de bacalao
- other names: {"es": "Moje de bacalao"}
- countries: (none)
- cuisines: Castilian-Manchego cuisine, cuisine of the Region of Murcia, cuisine of the province of Ciudad Real
- kinds: dish

## DISH Q109119426
- name: Locro of Peru
- countries: (none)
- kinds: Locro, meal

## DISH Q109120573
- name: Katla machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q109120592
- name: Alu begun diye dhela machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q109120684
- name: Kaoru Kingoma Tan Tan Men
- countries: (none)
- kinds: dandan noodles

## DISH Q10912397
- name: Double skin milk
- other names: {"zh": "双皮奶"}
- description: Cantonese dessert
- countries: CN
- kinds: dish, confectionery
- has Wikipedia article: en, zh

## DISH Q1091253
- name: Nikuman
- other names: {"zh": "中華饅 (日本)"}
- description: Japanese dish of dumplings stuffed with meat, derived from the Chinese baozi
- countries: JP
- kinds: dish, stuffed pasta
- ingredients: dough
- has Wikipedia article: en, zh

## DISH Q10912991
- name: Mouth-watering Chicken
- other names: {"zh": "口水雞"}
- description: Sichuanese Cold Chicken Dish
- countries: CN
- cuisines: Sichuan cuisine
- kinds: cold dishes, chicken dish
- has Wikipedia article: zh

## DISH Q109132624
- name: Бакла эзмеси
- other names: {"ru": "Бакла эзмеси"}
- description: broad bean dish from Southern Turkey
- countries: TR
- cuisines: Turkish cuisine
- kinds: fava, dish
- ingredients: broad bean

## DISH Q10914420
- name: 台南小吃
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q10915484
- name: Taiwan ramen
- other names: {"zh": "台灣拉麵"}
- description: Japanese ramen dish
- countries: JP
- kinds: food, ramen
- has Wikipedia article: zh

## DISH Q10915604
- name: Taiwanese beef noodles
- other names: {"zh": "台灣牛肉麵"}
- description: Taiwanese soup dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: beef noodle soup
- has Wikipedia article: en, zh

## DISH Q10916834
- name: Walnut soup
- description: type of soup
- countries: MX
- cuisines: Italian cuisine, Mexican cuisine, Chinese cuisine
- kinds: tong sui
- ingredients: walnut
- has Wikipedia article: en

## DISH Q109173339
- name: Niramish khansir mangso
- description: Bengali cuisine
- countries: (none)
- kinds: goat meat dish

## DISH Q109189164
- name: Silltårta
- other names: {"sv": "Silltårta"}
- countries: SE
- kinds: dish

## DISH Q109191849
- name: Lemon cake
- countries: (none)
- kinds: cake
- ingredients: lemon
- has Wikipedia article: en

## DISH Q10921730
- name: 咖啡香腸
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q109218875
- name: Crinkle-cut fries
- description: fries cut with a corrugated knive or mandoline blade
- countries: (none)
- kinds: fries

## DISH Q109236402
- name: Batter bread
- description: Bread with a high liquid-to-flour ratio
- countries: (none)
- kinds: food, bread
- has Wikipedia article: en

## DISH Q10925229
- name: Four Herbs Soup
- other names: {"zh": "四神汤"}
- description: Chinese soup
- countries: (none)
- kinds: traditional Chinese medical formula, dish
- has Wikipedia article: zh

## DISH Q109259132
- name: Wardh Taifi
- description: rose characteristic to the Taif region and its cultural heritage and identity
- countries: SA
- kinds: Rosa

## DISH Q109260442
- name: Blueberry pancake
- description: pancake with blueberries in it
- countries: (none)
- kinds: pancake
- ingredients: blueberry
- has Wikipedia article: en

## DISH Q1092662
- name: Ciorbă de perișoare
- description: Romanian soup prepared with minced meat dumplings
- countries: RO
- kinds: food, soup
- ingredients: meatball
- has Wikipedia article: en

## DISH Q1092712
- name: Chipolata
- other names: {"zh": "直布羅陀腸"}
- description: type of sausage
- countries: FR
- kinds: sausage, Vienna sausage
- has Wikipedia article: en, zh

## DISH Q109286869
- name: Radish kimchi
- countries: (none)
- kinds: Kimchi

## DISH Q109289372
- name: Original Harmony Burger
- description: pork burger from Harmony Lunch
- countries: (none)
- kinds: hamburger
- ingredients: fried onion, pork

## DISH Q109302295
- name: Shuwa
- description: Omani lamb, mutton or goat dish
- countries: (none)
- kinds: lamb dish, goat meat dish

## DISH Q109310930
- name: Ropa vieja
- other names: {"es": "Ropa vieja"}
- countries: ES
- kinds: dish
- ingredients: chickpea, shredded beef, pork, fries, bacon

## DISH Q109311139
- name: Flama bread
- description: Spanish family of breads
- countries: ES
- kinds: bread

## DISH Q10931125
- name: Empanadilla
- countries: PE, PH
- kinds: dish, empanada
- has Wikipedia article: en

## DISH Q109311322
- name: Recado
- description: spice mixture
- countries: MX
- kinds: spice mix

## DISH Q109311779
- name: Dulce de leche ice cream
- description: flavored ice cream
- countries: AR
- kinds: ice cream, flavoring

## DISH Q109312180
- name: Cantos bread
- description: Spanish bread
- countries: ES
- kinds: bread

## DISH Q109312469
- name: Bollo sevillano
- description: Spanish bread
- countries: ES
- kinds: bread
- has Wikipedia article: en

## DISH Q109312726
- name: Piña
- description: Spanish bread
- countries: ES
- kinds: bread

## DISH Q109312993
- name: Jallulla
- description: Spanish sweet bread
- countries: ES
- kinds: bread

## DISH Q109313015
- name: Lumaconi
- other names: {"mul": "lumaconi"}
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta

## DISH Q109313047
- name: Quadrefiore
- countries: (none)
- kinds: pasta

## DISH Q109313057
- name: Riccioli
- countries: (none)
- kinds: pasta

## DISH Q109313278
- name: Barquette aux marrons
- other names: {"fr": "barquette aux marrons"}
- countries: (none)
- kinds: dish

## DISH Q109313400
- name: Castellane
- other names: {"mul": "castellane"}
- countries: IT
- kinds: pasta

## DISH Q109313406
- name: Creste di gallo
- countries: (none)
- kinds: pasta

## DISH Q109313407
- name: Medaglioni
- other names: {"mul": "medaglioni"}
- countries: (none)
- kinds: pasta

## DISH Q109313410
- name: Fiorentine
- other names: {"fr": "Fiorentine"}
- countries: (none)
- kinds: pasta

## DISH Q109313412
- name: Torchio
- other names: {"fr": "Torchio"}
- countries: (none)
- kinds: pasta

## DISH Q109313421
- name: Girandole
- other names: {"fr": "Girandole"}
- countries: (none)
- kinds: pasta

## DISH Q109313490
- name: Niño envuelto
- description: South American dish
- countries: AR
- kinds: dish
- has Wikipedia article: en

## DISH Q10931392
- name: Cuttlefish ball
- other names: {"zh": "墨鱼丸"}
- description: Chinese dish
- countries: CN
- kinds: seafood dish
- has Wikipedia article: zh

## DISH Q109314192
- name: Dehesa de Extremadura
- other names: {"es": "Dehesa de Extremadura"}
- countries: (none)
- kinds: jamón, Protected designation of origin

## DISH Q109315182
- name: Gwell
- other names: {"fr": "gwell"}
- countries: (none)
- kinds: dish

## DISH Q109325895
- name: Tahini halva
- countries: (none)
- kinds: halva
- ingredients: tehina

## DISH Q109330183
- name: Kaqdoq Minnyaq
- description: ritual food in almost every celebration in Makassar, Indonesia
- countries: ID
- kinds: dish

## DISH Q109332108
- name: Kembung Bertelor
- description: fish dishes from Bangka Belitung Islands, Indonesia
- countries: ID
- kinds: fish dish, dish

## DISH Q10934152
- name: Datong knife-shaved noodles
- other names: {"zh": "大同刀削面"}
- countries: CN
- kinds: noodle dish
- has Wikipedia article: zh

## DISH Q109342955
- name: Uji-kintoki
- other names: {"zh": "宇治金時"}
- countries: (none)
- kinds: kakigōri
- ingredients: red bean paste, matcha, ice
- has Wikipedia article: zh

## DISH Q109344166
- name: Zhàn jiàng cài
- other names: {"zh": "蘸醬菜"}
- countries: (none)
- cuisines: Northeastern Chinese cuisine
- kinds: vegetable dish
- has Wikipedia article: zh

## DISH Q109346137
- name: Mala crawfish
- other names: {"zh": "麻辣小龍蝦"}
- countries: CN
- kinds: dish
- has Wikipedia article: zh

## DISH Q109347773
- name: Ice cream mooncake
- other names: {"zh": "雪糕月餅"}
- countries: (none)
- kinds: mooncake
- has Wikipedia article: zh

## DISH Q109350330
- name: Chanasan makh
- other names: {"zh": "手抓肉"}
- description: boiled lamb
- countries: MN
- kinds: meat dish, lamb dish
- ingredients: mutton
- has Wikipedia article: zh

## DISH Q109353074
- name: Cemita
- description: bread from Puebla City, in México
- countries: MX
- kinds: bread, sandwich
- has Wikipedia article: en

## DISH Q109357016
- name: 絹のしらべ
- other names: {"ja": "絹のしらべ"}
- countries: (none)
- kinds: wagashi

## DISH Q109357605
- name: 清水羊羹
- other names: {"ja": "清水羊羹"}
- countries: (none)
- kinds: Miyagegashi

## DISH Q109359051
- name: Seri-nabe
- countries: JP
- kinds: nabemono
- ingredients: Oenanthe javanica

## DISH Q109359112
- name: Nezushi
- countries: (none)
- kinds: narezushi, New Year's food

## DISH Q109359120
- name: Yakyū castella
- description: Japanese sponge cake from Kōbe
- countries: (none)
- kinds: castella

## DISH Q109359499
- name: 超獣戯牙ガオロードチョコ
- other names: {"ja": "超獣戯牙ガオロードチョコ"}
- countries: (none)
- kinds: candy

## DISH Q109360335
- name: Nasi
- description: Indonesian and Malaysian cooked rice and/or other grains
- countries: (none)
- kinds: cooked grain

## DISH Q109360343
- name: Cơm
- description: Vietnamese cooked rice and/or other grains
- countries: (none)
- kinds: cooked grain

## DISH Q109361052
- name: Hikizuri
- countries: (none)
- kinds: sukiyaki, chicken dish

## DISH Q109361421
- name: Nantu
- other names: {"zh": "年頭"}
- countries: (none)
- kinds: muchi, New Year's food

## DISH Q109361900
- name: Shōjin-age
- countries: (none)
- kinds: Agemono, vegetable dish

## DISH Q109361903
- name: Deep-fried confection
- countries: (none)
- kinds: type of food or dish, confectionery, deep-fried food

## DISH Q109362788
- name: おかざきカレーパン
- other names: {"ja": "おかざきカレーパン"}
- countries: (none)
- kinds: curry bread

## DISH Q109363511
- name: Jinju naengmyeon
- countries: KR
- cuisines: South Korean cuisine
- kinds: naengmyeon

## DISH Q109364379
- name: Pork tamago onigiri
- countries: (none)
- kinds: onigiri, pork dish, egg dish
- ingredients: pork tamago

## DISH Q10936580
- name: Tāi-khe tāu-koa
- other names: {"zh": "大溪豆干"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish
- has Wikipedia article: zh

## DISH Q109366527
- name: サイダーかん
- other names: {"ja": "サイダーかん"}
- countries: (none)
- kinds: namagashi

## DISH Q10936666
- name: Dazhu gansi
- other names: {"zh": "大煮干丝"}
- description: Chinese tofu dish
- countries: (none)
- cuisines: Huaiyang cuisine
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q109368458
- name: Chī irichī
- countries: (none)
- kinds: meat dish, irichī

## DISH Q109368587
- name: くじゃく
- other names: {"ja": "くじゃく"}
- countries: JP
- kinds: egg dish, dish
- ingredients: fish paste, egg as food

## DISH Q109370422
- name: Contorno
- countries: (none)
- kinds: dish

## DISH Q1093768
- name: Bar-le-duc jelly
- other names: {"zh": "巴勒迪克果酱"}
- description: food
- countries: FR
- kinds: jam
- ingredients: currant
- has Wikipedia article: en, zh

## DISH Q109377884
- name: Diplomatica
- other names: {"de": "Diplomatica"}
- countries: (none)
- kinds: dessert, sweet dish

## DISH Q109377958
- name: Torta beca
- other names: {"es": "Torta beca"}
- countries: IT
- kinds: dessert

## DISH Q109378130
- name: Robiola di Cocconato
- other names: {"it": "Robiola di Cocconato"}
- countries: IT
- kinds: cheese
- ingredients: cow's milk

## DISH Q109378829
- name: Whopperitto
- description: dish
- countries: US
- kinds: dish
- ingredients: Whopper, burrito

## DISH Q1093790
- name: Bacon Explosion
- other names: {"zh": "烟肉大爆炸"}
- description: American pork dish
- countries: US
- kinds: bacon-wrapped food
- ingredients: fresh sausage, barbecue sauce, bacon
- has Wikipedia article: en, zh

## DISH Q109379179
- name: BLAT
- description: sandwich with bacon, lettuce, avocado and tomato
- countries: (none)
- kinds: sandwich
- ingredients: avocado, BLT

## DISH Q109379269
- name: Sauteed onions
- description: preparation of onions
- countries: (none)
- kinds: dish
- ingredients: onion

## DISH Q109380577
- name: Five Guys hamburgers
- description: dish
- countries: US
- kinds: dish
- ingredients: bun, hamburger

## DISH Q109380823
- name: Bean burgers
- description: type of hamburger
- countries: (none)
- kinds: dish
- ingredients: black turtle bean

## DISH Q109380830
- name: Lechuguino
- description: Spanish bread
- countries: ES
- kinds: bread

## DISH Q109381328
- name: Lamb burger
- description: dish made with lamb
- countries: (none)
- kinds: dish, hamburger
- ingredients: lamb meat, hamburger

## DISH Q109381386
- name: Potato bun
- description: bread type
- countries: (none)
- kinds: bread

## DISH Q10938562
- name: 大餅包小餅
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q109388991
- name: Venison burger
- description: hamburger made from venison
- countries: (none)
- kinds: dish, hamburger
- ingredients: venison

## DISH Q109389957
- name: Onion bread
- description: bread type
- countries: (none)
- kinds: bread
- ingredients: onion

## DISH Q109391476
- name: Alaçatı kurabiyesi
- other names: {"tr": "Alaçatı kurabiyesi"}
- countries: TR
- kinds: biscuit

## DISH Q109391479
- name: Turkish ring dessert
- description: Turkish dessert with sherbet
- countries: TR
- kinds: tulumba, dessert
- ingredients: sherbet, dough, oil

## DISH Q109393756
- name: Treasure chest
- description: ice cream from Heartbrand
- countries: (none)
- kinds: ice cream

## DISH Q109399388
- name: End of the bread
- description: crusty extreme of bread
- countries: (none)
- kinds: bread

## DISH Q109409667
- name: Honey walnut shrimp
- description: western-inspired Cantonese dish
- countries: (none)
- kinds: dish
- ingredients: shrimp, walnut
- has Wikipedia article: en

## DISH Q109413627
- name: Prarion
- other names: {"fr": "prarion"}
- countries: FR
- kinds: cake, pie, sweet pie
- ingredients: Vaccinium sect. Myrtillus, marzipan

## DISH Q109414823
- name: 牛肉炒豆丝
- countries: CN
- kinds: dish
- has Wikipedia article: zh

## DISH Q10941762
- name: Taigu Bing
- other names: {"zh": "太谷餅"}
- description: type of pastry from Taigu County
- countries: CN
- kinds: food
- has Wikipedia article: zh

## DISH Q109423278
- name: Bolillo con relleno
- other names: {"es": "bolillo con relleno"}
- countries: MX
- cuisines: Mexican cuisine
- kinds: street food, torta, food
- ingredients: Guajillo chili, bolillo, pork, Musa balbisiana, spice

## DISH Q109423425
- name: Galleta forta
- other names: {"ca": "Galleta forta"}
- countries: (none)
- kinds: bread
- ingredients: whole-wheat flour, sourdough, olive oil, table salt, water

## DISH Q109423540
- name: Asado de puerco
- description: traditional food from Nuevo León, México
- countries: MX
- kinds: asado, dish
- ingredients: pig

## DISH Q109424807
- name: Crystal bread
- description: bread from Barcelona, Spain
- countries: ES
- kinds: bread

## DISH Q109429025
- name: Drie-in-de-pan
- other names: {"nl": "Drie-in-de-pan"}
- countries: (none)
- kinds: dish

## DISH Q109429557
- name: Bánh tráng trộn
- description: Vietnamese street food dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1094305
- name: Luther Burger
- other names: {"zh": "路德汉堡"}
- description: hamburger or cheeseburger with one or more glazed doughnuts in place of the bun
- countries: US
- kinds: hamburger, dish
- ingredients: doughnut, hamburger
- has Wikipedia article: en, zh

## DISH Q109430747
- name: Keripik daun brayo
- other names: {"id": "Keripik daun brayo"}
- countries: (none)
- kinds: dish

## DISH Q109430748
- name: Rujak bejad
- other names: {"id": "Rujak bejad"}
- countries: (none)
- kinds: dish

## DISH Q109431540
- name: Sayur keluak ayam
- other names: {"id": "Sayur keluak ayam"}
- countries: (none)
- kinds: dish

## DISH Q109432661
- name: Nasi pager
- other names: {"id": "Nasi pager"}
- countries: (none)
- kinds: dish

## DISH Q109435904
- name: Kela Mrica
- other names: {"id": "Kela Mrica"}
- countries: (none)
- kinds: dish, fish dish
- ingredients: black pepper

## DISH Q109435907
- name: Botok masin
- description: Indonesian food
- countries: (none)
- kinds: dish

## DISH Q109436297
- name: Gulai tekuyung
- description: Indonesian dish of Jambi
- countries: (none)
- kinds: dish, type of food or dish, gulai
