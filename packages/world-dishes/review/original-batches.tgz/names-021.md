# Review batch names-021

## DISH Q132681438
- name: Xarró
- countries: (none)
- kinds: dish, stew
- ingredients: broad bean, pea, potato, cabbage, animal fats and oils, bean, broth, pasta

## DISH Q132681709
- name: Kielbasa slaska
- description: type of Polish brühwurst, typical of Upper Silesia
- countries: PL
- cuisines: Silesian cuisine
- kinds: dish, Brühwurst, pork dish, sausage
- ingredients: garlic, coriander seed, minced meat, paprika, pork, nutmeg, black pepper, table salt, drinking water

## DISH Q13270
- name: Biscuit
- other names: {"zh": "面饼"}
- description: sweet baked product
- countries: (none)
- kinds: snack, cookies, biscuits, crackers
- ingredients: wheat flour, baking powder, table salt, sugar, milk, water
- has Wikipedia article: en, zh

## DISH Q132744624
- name: Kameyama Miso Yaki udon
- countries: (none)
- kinds: yaki udon

## DISH Q132775271
- name: Spice burger
- description: breaded beef patty created in Ireland
- countries: IE
- kinds: patty
- has Wikipedia article: en

## DISH Q132800029
- name: Boba
- description: Spanish wheat bread
- countries: ES
- kinds: bread

## DISH Q1328259
- name: San-nakji
- other names: {"zh": "活章魚"}
- description: Korean dish of sliced raw octopus
- countries: (none)
- kinds: hoe, fish dish, octopus dish
- ingredients: Octopus minor
- has Wikipedia article: en, zh

## DISH Q132830790
- name: Empogola
- description: matooke cooked with its peelings
- countries: UG
- kinds: food
- ingredients: Matoke
- has Wikipedia article: en

## DISH Q132830862
- name: Ground nuts paste
- description: pounded ground nuts
- countries: UG
- kinds: sauce

## DISH Q1328462
- name: Honeycomb toffee
- other names: {"zh": "椪糖"}
- description: type of sweet candy
- countries: (none)
- kinds: confectionery, food, caramel, toffee
- ingredients: brown sugar, sodium bicarbonate, melting
- has Wikipedia article: en, zh

## DISH Q1328767
- name: Polonaise
- other names: {"zh": "波兰式顶篷"}
- description: sauce in Polish cuisine
- countries: RU
- cuisines: Russian cuisine
- kinds: dish, sauce
- ingredients: rusk, lemon juice, butter
- has Wikipedia article: en

## DISH Q1329680
- name: Chocolate chip
- other names: {"zh": "巧克力豆"}
- description: small chunk of chocolate
- countries: US
- kinds: chocolate, baking chip
- ingredients: chocolate
- has Wikipedia article: en, zh

## DISH Q132970274
- name: Gemischter Salat
- other names: {"de": "gemischter Salat"}
- countries: (none)
- kinds: salad, type of food or dish

## DISH Q13302
- name: Sorbet
- other names: {"zh": "雪葩"}
- description: frozen dessert
- countries: (none)
- kinds: frozen dessert, dessert with spoon, food
- ingredients: fruit juice, sugar, water
- has Wikipedia article: en, zh

## DISH Q13305
- name: Italian ice
- description: frozen dessert
- countries: IT
- kinds: frozen dessert
- has Wikipedia article: en

## DISH Q133082568
- name: KOLOKO Crispy Pea Snacks
- other names: {"zh": "可樂果"}
- description: Taiwanese snacks
- countries: TW
- kinds: snack
- has Wikipedia article: zh

## DISH Q13312
- name: Snow cone
- description: shaved ice dessert
- countries: (none)
- kinds: shaved ice
- has Wikipedia article: en

## DISH Q1331201
- name: Klachelsuppe
- other names: {"de": "Klachelsuppe"}
- countries: (none)
- kinds: dish

## DISH Q13314
- name: Parfait
- other names: {"zh": "芭菲"}
- description: frozen dessert
- countries: FR
- kinds: frozen dessert
- ingredients: syrup
- has Wikipedia article: en, zh

## DISH Q133160529
- name: Niglo
- countries: (none)
- kinds: dish
- ingredients: hedgehog

## DISH Q13319
- name: Frozen yogurt
- other names: {"zh": "霜凍優格"}
- description: frozen dessert
- countries: US
- kinds: frozen dessert
- ingredients: milk, yogurt
- has Wikipedia article: en, zh

## DISH Q133234631
- name: Pizza in Japan
- countries: (none)
- has Wikipedia article: en

## DISH Q133235403
- name: Mklats panir
- description: Armenian traditional cheese
- countries: AM
- kinds: cheese, type of cheese

## DISH Q133245973
- name: Kaszotto
- description: in Polish cuisine, dish made of groats prepared like risotto
- countries: PL
- cuisines: Polish cuisine
- kinds: neologism, dish, first course
- ingredients: groat

## DISH Q133258126
- name: Зіньківська ковбаса
- other names: {"uk": "Зіньківська ковбаса"}
- countries: UA
- kinds: dish

## DISH Q133259336
- name: Chakluk
- description: Meitei-style meal
- countries: (none)
- cuisines: Manipuri cuisine
- kinds: thali
- ingredients: culinary herb, condiment, seafood, vegetable, meat, rice
- has Wikipedia article: en

## DISH Q133261248
- name: Bongko
- other names: {"id": "Bongko"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: appetizer, kue, food, dish, traditional food, type of food or dish
- ingredients: palm sugar, rice flour, coconut milk, Pandanus amaryllifolius

## DISH Q133262108
- name: Wet-fried beef ho fun
- countries: CN
- kinds: beef dish

## DISH Q133269890
- name: Gonré
- description: burkinabè food
- countries: BF
- cuisines: restaurant
- kinds: dish, type of food or dish
- ingredients: hard-boiled egg, onion, bean, oil, ginger, Apium graveolens, parsley, Allium sativum, table salt, carrot

## DISH Q133270012
- name: Beans on toast
- description: baked beans on toasted bread
- countries: (none)
- kinds: dish
- ingredients: baked beans, toast
- has Wikipedia article: en

## DISH Q133280796
- name: Jälkiuunileipä
- other names: {"fi": "jälkiuunileipä"}
- countries: (none)
- kinds: bread

## DISH Q133284186
- name: Aluek trei ngeat
- description: Cambodian salad
- countries: KH
- kinds: salad
- ingredients: watermelon, dried fish
- has Wikipedia article: en

## DISH Q133286121
- name: Paille (pastry)
- description: French puff pastry
- countries: FR
- kinds: pastry

## DISH Q1332967
- name: White pudding
- other names: {"zh": "白布丁"}
- description: British and Irish dish of suet or fat, oatmeal or barley, breadcrumbs and sometimes pork filled into a natural or cellulose sausage casing
- countries: (none)
- kinds: savory pudding
- ingredients: pork
- has Wikipedia article: en, zh

## DISH Q133328684
- name: Kobaravina
- other names: {"fr": "Kobaravina"}
- countries: MG
- kinds: dish
- ingredients: peanut, sugar, rice, water

## DISH Q133449295
- name: As-sabʿa dūal
- description: Syrian dish
- countries: SY
- cuisines: Levantine cuisine
- kinds: dish

## DISH Q133451449
- name: Hummus bil-lahm
- description: Syrian mezze (dish)
- countries: SY
- cuisines: Levantine cuisine
- kinds: dish

## DISH Q133465144
- name: Emmamba
- description: Ugandan dish made by deep frying Lungfish
- countries: UG
- kinds: cuisine, type of food or dish, street food

## DISH Q133501493
- name: Ballorieh
- description: Middle Eastern sweet pastry made with pistachio filling and knafeh dough (qadaif).
- countries: SY
- kinds: food, dessert, pastry
- ingredients: pistachio nut, Kadayif

## DISH Q133504015
- name: Onunu
- description: Nigerian dish
- countries: NG
- kinds: food, dish, human food
- ingredients: yam, palm oil, cooking banana, table salt
- has Wikipedia article: en

## DISH Q133504868
- name: Tshaka Madesu
- description: beans and cassava leaves stew
- countries: CD
- cuisines: Congolese cuisine, Democratic Republic of the Congo cuisine
- kinds: stew
- ingredients: sweet paprika powder, bay leaf, bean, cassava

## DISH Q133521439
- name: Souloukhou
- other names: {"fr": "souloukhou"}
- countries: SN
- kinds: dish

## DISH Q133521585
- name: Domoda
- description: Senegalese dish
- countries: SN
- kinds: dish

## DISH Q133521607
- name: Thiébou Kéthiakh
- description: Senegalese dish
- countries: SN
- kinds: dish

## DISH Q133521632
- name: Mbaxalou saloum
- description: Senegalese dish
- countries: SN
- kinds: dish

## DISH Q133521643
- name: Ngourbane
- other names: {"fr": "Ngourbane"}
- countries: SN
- kinds: dish

## DISH Q133521658
- name: Thiou
- other names: {"fr": "Thiou"}
- countries: SN
- kinds: dish

## DISH Q133521675
- name: Thiou curry
- other names: {"fr": "Thiou curry"}
- countries: SN
- kinds: dish

## DISH Q133521709
- name: C'est bon
- other names: {"fr": "C'est bon"}
- countries: SN
- kinds: dish

## DISH Q133521758
- name: Thiéré Bassi Salté
- other names: {"fr": "Thiéré Bassi Salté"}
- countries: SN
- kinds: dish

## DISH Q133521777
- name: Fondé
- other names: {"fr": "Fondé"}
- countries: SN
- kinds: dish

## DISH Q133545451
- name: Poulet à l'estragon
- other names: {"fr": "poulet à l'estragon"}
- countries: (none)
- kinds: dish

## DISH Q133545453
- name: Poulet au vinaigre
- other names: {"fr": "poulet au vinaigre"}
- countries: (none)
- kinds: dish

## DISH Q133569467
- name: Bardakta mısır
- other names: {"tr": "bardakta mısır"}
- countries: (none)
- kinds: street food

## DISH Q133572474
- name: Etsiz çiğ köfte
- other names: {"tr": "etsiz çiğ köfte"}
- countries: (none)
- kinds: çiğ köfte

## DISH Q13360207
- name: Prosciutto di Parma PDO
- other names: {"zh": "Prosciutto di Parma DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: prosciutto, meat product
- ingredients: pork thigh
- has Wikipedia article: en, zh

## DISH Q13360264
- name: Pie
- other names: {"zh": "西式餡餅"}
- description: baked dish made of a pastry dough casing with a filling of sweet or savoury ingredients
- countries: RU, BR, PL, GB, UA
- cuisines: Russian cuisine, Brazilian cuisine, Polish cuisine, British cuisine, Ukrainian cuisine
- kinds: baked good, torta, bánh
- ingredients: pie crust, stuffing
- has Wikipedia article: en, zh

## DISH Q13360715
- name: Khanom chin
- other names: {"zh": "泰式米线"}
- description: Thai rice noodles
- countries: TH
- cuisines: Thai cuisine
- kinds: rice noodle, fermented food, food ingredient
- ingredients: rice
- has Wikipedia article: en

## DISH Q133622195
- name: Ripe plantain arepa
- description: Typical food from Colombia and Venezuela
- countries: CO
- kinds: type of food or dish, arepa
- ingredients: cooking banana

## DISH Q13362654
- name: Fried calamari
- other names: {"zh": "炸鱿鱼"}
- description: food
- countries: IT
- kinds: squid dish

## DISH Q13365379
- name: Ruthenian pierogi
- other names: {"zh": "羅司餃子"}
- description: type of Polish dumplings
- countries: PL
- cuisines: Polish cuisine
- kinds: pierogi, potato dish
- ingredients: tvorog, potato, peppercorn, fried onion, flour, table salt, water

## DISH Q133748072
- name: Koba (sweet)
- description: sweet
- countries: MG
- kinds: food, dish
- ingredients: peanut, banana leaf, rice flour, sugar

## DISH Q133758660
- name: Клёцкі з душамі
- other names: {"be": "клёцкі з душамі"}
- description: intangible cultural heritage site (category 'A'), code 23АК000110
- countries: (none)
- kinds: cultural heritage, dish, Cultural heritage of Belarus

## DISH Q13377687
- name: Bun
- other names: {"zh": "小圆面包"}
- description: small, soft, sometimes sweet, bread or bread roll
- countries: (none)
- kinds: bread, bread roll, snack
- ingredients: baking powder, dough, sugar, honey, flour, butter
- has Wikipedia article: en, zh

## DISH Q133806780
- name: Tapak kuda
- description: cake from Brunei
- countries: BN
- kinds: cake

## DISH Q133817
- name: Jeon
- other names: {"zh": "煎"}
- description: Korean pan-fried dish
- countries: (none)
- kinds: food, buchimgae
- ingredients: egg wash, flour
- has Wikipedia article: en

## DISH Q133817716
- name: Manioc au lait de coco
- other names: {"fr": "Manioc au lait de coco"}
- countries: MG
- kinds: dish, food
- ingredients: coconut milk, Sel Municipality, Sucre, cassava, cinnamon, vanilla

## DISH Q133824912
- name: ひっぱり餅
- other names: {"ja": "ひっぱり餅"}
- countries: JP
- kinds: confectionery

## DISH Q133824913
- name: 柳もち
- other names: {"ja": "柳もち"}
- countries: JP
- kinds: confectionery

## DISH Q133824914
- name: Kintoki Yōkan
- description: yōkan made in Haboro, Hokkaido, Japan
- countries: JP
- kinds: Yōkan

## DISH Q133824915
- name: あふ
- other names: {"ja": "あふ"}
- countries: JP
- kinds: steamed bread

## DISH Q133824921
- name: いわしの卯の花漬け
- other names: {"ja": "いわしの卯の花漬け"}
- countries: JP
- kinds: fish dish

## DISH Q133828898
- name: Orella de porco
- other names: {"gl": "orella de porco"}
- countries: (none)
- kinds: ear, pork dish

## DISH Q133852671
- name: Smothered burrito
- description: burrito with ingredients on the outside, meant to be eaten with utensils on a plate rather than held
- countries: (none)
- kinds: burrito

## DISH Q133856168
- name: Roncadin
- description: pizza, food industry in Meduno, Italy
- countries: (none)
- kinds: food industry

## DISH Q133861664
- name: Godrogodro
- description: Rice cake
- countries: (none)
- kinds: cake
- ingredients: coconut, sugar, rice

## DISH Q13386962
- name: Mango shaved ice
- other names: {"zh": "芒果冰"}
- description: Taiwanese shaved ice dessert with mango topping
- countries: TW
- kinds: shaved ice
- has Wikipedia article: en, zh

## DISH Q133871239
- name: Trivandrum Boli
- description: traditional delicacy from Kerala, India
- countries: IN
- kinds: food, flatbread
- has Wikipedia article: en

## DISH Q133876362
- name: 紅豆沙
- other names: {"zh-tw": "紅豆沙"}
- countries: (none)
- kinds: sweet bean paste, ingredient

## DISH Q1338822
- name: Samgyeopsal
- other names: {"zh": "韓式烤三層肉"}
- description: Korean grilled pork belly dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en, zh

## DISH Q133884319
- name: Cheesy Garlic Bread
- countries: TW
- kinds: food product
- ingredients: wheat starch, wheat flour, tapioca

## DISH Q133892366
- name: Soy ice cream
- description: type of ice cream
- countries: (none)
- kinds: frozen dessert

## DISH Q133894166
- name: Bielusz
- other names: {"pl": "bielusz"}
- countries: (none)
- kinds: yeast dough, cake
- ingredients: wheat flour, nutritional yeast, egg as food, butter

## DISH Q133894419
- name: Uchuku
- other names: {"qu": "Uchuku"}
- countries: BO
- kinds: dish

## DISH Q133894741
- name: Sorundatårta
- description: Swedish cake with apple or plum sauce
- countries: (none)
- kinds: torte

## DISH Q133898292
- name: Payesh with date palm jaggery
- description: payesh made with date palm jaggery
- countries: BD, IN
- kinds: dessert, rice dish
- ingredients: rice

## DISH Q133934563
- name: Pão de cará
- description: Brazilian type of bread
- countries: (none)
- kinds: bread, knowledge, recipe
- has Wikipedia article: en

## DISH Q133944003
- name: Cabrito de Extremadura
- description: Spanish goat meat
- countries: ES
- kinds: meat, goat meat

## DISH Q1339633
- name: Vindaloo
- other names: {"zh": "文達盧"}
- description: Indian dish
- countries: IN
- kinds: Indian curry
- ingredients: ginger, pork, chili pepper, vinegar, sugar
- has Wikipedia article: en, zh

## DISH Q133973038
- name: Camote de Puebla
- other names: {"es": "camote de Puebla"}
- countries: MX
- kinds: dessert, snack, fruit preparation, food paste
- ingredients: glucose syrup, Sweet potato

## DISH Q134005680
- name: Pastificio
- countries: (none)
- kinds: pasta, food industry

## DISH Q134005804
- name: Celeriac soup
- countries: (none)
- kinds: soup
- ingredients: celeriac

## DISH Q1340323
- name: Barros Luco
- other names: {"zh": "巴罗斯·卢科三明治"}
- description: Chilean hot sandwich
- countries: CL
- kinds: sandwich
- ingredients: beef, cheese
- has Wikipedia article: en

## DISH Q13403307
- name: Richman
- description: kind of fast food
- countries: SK
- kinds: fast food, type of food or dish
- ingredients: cucumber, salami, mayonnaise, Brassica

## DISH Q134043310
- name: Tel panir
- description: Armenian string cheese
- countries: AM
- kinds: cheese, string cheese

## DISH Q134050772
- name: খেজুরের গুড় দিয়ে তৈরি সুজির হালুয়া
- other names: {"bn": "খেজুরের গুড় দিয়ে তৈরি সুজির হালুয়া"}
- countries: BD, IN
- kinds: dessert
- ingredients: semolina

## DISH Q13405089
- name: Lontong balap
- description: Indonesian rice cake dish
- countries: (none)
- kinds: food, rice dish
- ingredients: lentho, tahu goreng, lontong
- has Wikipedia article: en

## DISH Q134078348
- name: Kerrie Kerrie
- other names: {"mul": "Kerrie Kerrie"}
- description: Traditional Aruban dish made of chopped fish with onions, tomato, and spices
- countries: AW
- kinds: dish, fish dish
- ingredients: tomato, onion, spice, fish

## DISH Q134080491
- name: Soto Aceh
- other names: {"id": "Soto Aceh"}
- countries: (none)
- kinds: soto

## DISH Q134097837
- name: Jin koro
- countries: (none)
- kinds: korokke, product

## DISH Q134097970
- name: Jin-Kara
- countries: (none)
- kinds: karaage, product

## DISH Q13411051
- name: Milhard
- description: kind of clafoutis
- countries: (none)
- kinds: clafoutis

## DISH Q134113306
- name: Zamnin
- other names: {"fr": "Zamnin"}
- countries: BF
- kinds: dish

## DISH Q134124724
- name: San Marko opil
- other names: {"eu": "San Marko opil"}
- countries: (none)
- kinds: viennoiserie
- ingredients: chocolate egg, baker's yeast, flour, sugar

## DISH Q1341251
- name: Energiebällchen
- other names: {"de": "Energiebällchen"}
- countries: (none)
- kinds: candy

## DISH Q134125172
- name: Chocolate crinkle
- description: Chocolate cookie
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q134128637
- name: Pražský koláč
- description: Czech dessert
- countries: CZ
- kinds: dessert
- has Wikipedia article: en

## DISH Q134139217
- name: Beef bhuna
- description: Spicy Bengali beef dish, cooked with hot spices and typically served with rice or flatbread.
- countries: BD
- cuisines: Bengali cuisine
- kinds: beef dish
- ingredients: beef dish

## DISH Q134139316
- name: Ruhi bhuna
- description: Bangladeshi dish made with ruhi fish
- countries: (none)
- kinds: fish dish

## DISH Q134152
- name: Pan loaf
- other names: {"zh": "長條麵包"}
- description: type of bread that is very soft inside and has thin crust
- countries: FR, GB, IT, US
- kinds: food, bread, white bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q134165564
- name: Creamy peanut butter
- description: type of peanut butter that is not crunchy
- countries: (none)
- kinds: peanut butter

## DISH Q13422497
- name: Sopa de ajo
- description: common Spanish soup
- countries: ES
- kinds: garlic soup

## DISH Q13422525
- name: Bublik
- other names: {"zh": "布勃利克"}
- description: ring-shaped bread roll
- countries: UA
- kinds: food, bread, baranki
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q134229749
- name: Moskalik (fish)
- description: small pickled herring
- countries: (none)
- kinds: pickled herring
- has Wikipedia article: en

## DISH Q13424725
- name: Verhuny
- description: Ukrainian dessert
- countries: (none)
- kinds: dish

## DISH Q134250583
- name: রোস
- other names: {"bn": "রোস"}
- countries: AF
- kinds: food

## DISH Q134257497
- name: Ami-meshi
- description: Japanese regional dish
- countries: (none)
- kinds: dish

## DISH Q134273738
- name: Sauerkraut soup
- description: soup made from sauerkraut
- countries: (none)
- kinds: sauerkraut, soup

## DISH Q134278410
- name: Chicken seekh kabab
- countries: BD, IN
- kinds: kebab
- ingredients: Indian cuisine

## DISH Q134280857
- name: Mouniaka
- other names: {"fr": "Mouniaka"}
- countries: GA
- kinds: food

## DISH Q134281292
- name: Nkoumou ofula
- other names: {"fr": "Nkoumou ofula"}
- countries: GA
- kinds: food

## DISH Q134281727
- name: White bean soup
- countries: (none)
- kinds: navy bean, soup

## DISH Q134282351
- name: Kyushu soy sauce
- other names: {"zh": "九州醤油"}
- description: Soy sauce primarily consumed in the Kyushu and Okinawa regions of Japan
- countries: (none)
- kinds: soy sauce
- has Wikipedia article: en

## DISH Q134284342
- name: Aubergine
- other names: {"fr": "Aubergine"}
- countries: GA
- kinds: food

## DISH Q134284489
- name: Batséki
- other names: {"fr": "Batséki"}
- countries: GA
- kinds: food

## DISH Q134295102
- name: Chanfaina galega
- other names: {"gl": "chanfaina galega"}
- countries: (none)
- cuisines: Galician cuisine
- kinds: embutido
- ingredients: pork

## DISH Q134298768
- name: Karbeyaz Tatlısı
- other names: {"tr": "Karbeyaz Tatlısı"}
- countries: (none)
- kinds: dessert
- ingredients: semolina

## DISH Q134298782
- name: Semolina halva
- description: Turkish dessert
- countries: TR
- kinds: dessert
- ingredients: semolina

## DISH Q134298793
- name: Sautéed potatoes
- description: dish
- countries: (none)
- kinds: potato dish

## DISH Q134298811
- name: Mosaic cake
- description: dessert
- countries: (none)
- kinds: cake

## DISH Q134298830
- name: Cherry tomatoes stuffed with cheese
- description: culinary preparation of cherry tomatoes stuffed with cheese
- countries: (none)
- kinds: stuffed tomatoes, dish
- ingredients: cherry tomato, cheese

## DISH Q134298833
- name: Jalapeño peppers stuffed with cheese
- description: dish
- countries: (none)
- kinds: stuffed tomatoes, dish
- ingredients: jalapeño, cheese

## DISH Q134298851
- name: Shredded carrot
- description: preparation of carrots
- countries: (none)
- kinds: carrot, prepared vegetable

## DISH Q134303113
- name: Nonnettes de Remiremont
- other names: {"fr": "nonnettes de Remiremont"}
- countries: (none)
- kinds: pastry

## DISH Q134312393
- name: Nihari Haleem
- description: variation of Haleem prepared using Nihari as its meat base
- countries: (none)
- cuisines: South Asian cuisine
- kinds: nihari, Haleem
- ingredients: lentil, nihari

## DISH Q134318940
- name: Fruit kissel
- countries: (none)
- kinds: kissel, dessert with spoon, fruit dish
- ingredients: list of culinary fruits, starch, sugar, drinking water

## DISH Q134328147
- name: Nyembouè
- other names: {"fr": "Nyembouè"}
- countries: (none)
- kinds: dish

## DISH Q13434072
- name: Sausage rolls
- other names: {"zh": "猪包毯"}
- description: variety of different sausage-based dishes
- countries: (none)
- kinds: meat dish
- ingredients: pastry, Vienna sausage
- has Wikipedia article: zh

## DISH Q13434162
- name: Sarma
- other names: {"zh": "萨尔玛"}
- description: cabbage, vine leaf, or other leaf roll
- countries: CY, GR
- cuisines: Turkish cuisine, Serbian cuisine, Cretan cuisine, Crimean Tatar cuisine
- kinds: meat dish, vine leaf roll, cabbage roll, rice dish, dolma, dish
- ingredients: minced meat, grape leaves, onion, oil, table salt, rice, Capsicum annuum, tomato
- has Wikipedia article: en

## DISH Q134344445
- name: Torta Bejarana
- other names: {"es": "Torta Bejarana"}
- countries: (none)
- kinds: cake

## DISH Q1343448
- name: Käsegebäck
- other names: {"de": "Käsegebäck"}
- countries: (none)
- kinds: viennoiserie

## DISH Q134355938
- name: Gapal
- other names: {"fr": "Gapal"}
- countries: BF
- kinds: food

## DISH Q134374794
- name: Dunakavics
- description: Hungarian candy
- countries: HU
- kinds: sweetmeat
- has Wikipedia article: en

## DISH Q1343820
- name: Som tam
- countries: TH
- kinds: green papaya salad
- ingredients: tomato, peanut, onion, Carica papaya, lime

## DISH Q134385
- name: Fugu
- other names: {"zh": "河豚"}
- description: various species of pufferfish
- countries: (none)
- kinds: fish as food, fish dish, organisms known by a particular common name
- ingredients: tetrodotoxin
- has Wikipedia article: en, zh

## DISH Q134395384
- name: Bai ye tofu
- other names: {"zh": "百頁豆腐"}
- countries: (none)
- kinds: tofu, food product
- has Wikipedia article: zh

## DISH Q134409015
- name: Pol roṭi
- other names: {"mul": "pol roṭi"}
- countries: LK
- kinds: roti
- ingredients: grated coconut, wheat flour

## DISH Q134410151
- name: Sprits
- other names: {"mul": "Sprits"}
- countries: (none)
- kinds: biscuit

## DISH Q134414782
- name: Alfajor santafesino
- description: alfajor in Santa Fe province, Argentina
- countries: (none)
- kinds: alfajor, candy
- ingredients: Italian meringue, dulce de leche, cookie

## DISH Q1344218
- name: Ensaïmada
- other names: {"zh": "蜗牛面包"}
- description: pastry product from Mallorca (Balearic Islandés)
- countries: ES
- cuisines: Balearic cuisine
- kinds: cake, dessert, type of food or dish
- ingredients: egg as food, lard, flour, sugar
- has Wikipedia article: en, zh

## DISH Q1344219
- name: Rúgbrauð
- description: Icelandic rye bread
- countries: IS
- kinds: rye bread
- has Wikipedia article: en

## DISH Q134434602
- name: Mersu
- description: confectionery of Mesopotamia
- countries: (none)
- kinds: food, confectionery

## DISH Q134446593
- name: Asparagi alla cilavegnese
- other names: {"it": "Asparagi alla cilavegnese"}
- countries: IT
- kinds: traditional food
- ingredients: asparagus, Parmesan, egg as food, butter

## DISH Q134467534
- name: Cassava puree
- countries: (none)
- kinds: dish

## DISH Q134467697
- name: Arepa pelada
- description: arepa prepared without industrial processing
- countries: VE
- kinds: arepa, food
- ingredients: maize

## DISH Q134469652
- name: Murcia's salad
- description: typical salad from the Region of Murcia
- countries: ES
- cuisines: cuisine of the Region of Murcia
- kinds: salad, food
- ingredients: tuna, hard-boiled egg, Allium, Olea europaea, tomato

## DISH Q134472900
- name: Feuilles de manioc à l'huile de palme
- other names: {"fr": "feuilles de manioc à l'huile de palme"}
- countries: (none)
- kinds: dish

## DISH Q134475160
- name: Kore mochi
- description: Japanese confection
- countries: JP
- kinds: pastry
- has Wikipedia article: en

## DISH Q134503399
- name: Jolbhora Sandesh
- description: traditional Bengali sweet
- countries: (none)
- kinds: sweetmeat
- has Wikipedia article: en

## DISH Q134524952
- name: Zakari
- other names: {"fr": "zakari"}
- countries: (none)
- kinds: viennoiserie

## DISH Q134528137
- name: Jiao ma ji
- other names: {"zh": "泰式椒麻雞"}
- description: Chinese dish of chicken with spices
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: zh

## DISH Q134530889
- name: Gino
- other names: {"sv": "Gino"}
- countries: SE
- kinds: dessert
- ingredients: berry, vanilla ice cream, fruit, white chocolate

## DISH Q134540343
- name: Ōsato miso curry
- description: variety of the Japanese curry from Ōsato, Kurokawa district, Miyagi prefecture, Japan
- countries: (none)
- kinds: Japanese curry, type of food or dish

## DISH Q134549691
- name: Sahpye
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q134562216
- name: Kashiwameshi
- description: Traditional Japanese rice dish
- countries: JP
- kinds: takikomi gohan, rice dish
- has Wikipedia article: en

## DISH Q134562217
- name: 羽根つき餃子
- other names: {"ja": "羽根つき餃子"}
- countries: (none)
- kinds: jiaozi

## DISH Q1345626
- name: Goro
- description: Norwegian sweet bread
- countries: NO
- kinds: food, wafer
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q134563705
- name: Bola doce mirandesa
- other names: {"es": "Bola doce mirandesa"}
- description: Portuguese sponge cake
- countries: (none)
- kinds: sponge cake

## DISH Q134579810
- name: Златка
- other names: {"be": "златка"}
- countries: (none)
- kinds: street food
- ingredients: white bread, ketchup, ham, mayonnaise, cheese

## DISH Q134579814
- name: Луста
- other names: {"be": "луста"}
- countries: (none)
- kinds: sandwich, street food

## DISH Q134579815
- name: Хадун
- other names: {"be": "хадун"}
- countries: (none)
- kinds: hot dog, street food

## DISH Q134587713
- name: Bungo durian
- other names: {"min": "Bungo durian"}
- countries: ID
- kinds: food

## DISH Q134590386
- name: Halloumi fries
- countries: (none)
- kinds: cheese stick
- ingredients: halloumi

## DISH Q134593156
- name: Telor gabus
- other names: {"bew": "telor gabus"}
- countries: ID
- kinds: traditional food

## DISH Q134593219
- name: Keripik jèngkol
- other names: {"bew": "keripik jèngkol"}
- countries: ID
- kinds: Indonesian cuisine, traditional food
- ingredients: Archidendron pauciflorum

## DISH Q134593257
- name: Gabus lengkio
- other names: {"bew": "gabus lengkio"}
- countries: ID
- kinds: dish, human food, traditional food

## DISH Q134603479
- name: Grybukai
- description: mushroom-shaped cookies from Lithuania
- countries: LT
- kinds: dessert

## DISH Q134609821
- name: Lamb brisket stew
- countries: (none)
- kinds: dish

## DISH Q134613830
- name: Kue abug
- other names: {"id": "kue abug"}
- countries: ID
- kinds: dish, traditional food
- ingredients: sago flour, grated coconut, palm sugar, rice flour, table salt

## DISH Q134621334
- name: Qatlama
- countries: AZ
- cuisines: Azerbaijani cuisine
- kinds: pastry

## DISH Q134621732
- name: Pão de Mistura de Seia
- description: Mixed flour bread from Seia, registered at Quintal do Forno in Paços da Serra
- countries: PT
- kinds: bread, intangible cultural heritage
- ingredients: wheat, yeast, salt, Secale cereale, water

## DISH Q134621860
- name: Pesor
- other names: {"id": "pesor"}
- countries: ID
- kinds: dish, human food, traditional food

## DISH Q1346373
- name: Stamppot
- other names: {"zh": "炖羽衣甘蓝"}
- description: Dutch potato dish
- countries: NL
- cuisines: Dutch cuisine
- kinds: food, dish
- ingredients: endive, Allium, broccoli, potato
- has Wikipedia article: en

## DISH Q1346399
- name: Prosphora
- description: bread used in Eastern Orthodox rituals
- countries: (none)
- kinds: bread
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q13466069
- name: Dragon's beard candy
- other names: {"zh": "龍鬚糖"}
- description: Chinese sweet
- countries: CN
- kinds: candy
- has Wikipedia article: en, zh

## DISH Q134688858
- name: Nasi daging
- other names: {"ms": "Nasi daging"}
- description: Traditional northern Malaysian spiced rice dish cooked with tender beef, typically served with a tangy tamarind dipping sauce
- countries: MY
- cuisines: Malay cuisine
- kinds: meat dish, rice dish
- ingredients: garlic, ginger, onion, ghee, beef, Cymbopogon citratus, rice

## DISH Q134690880
- name: Escudelles populars a Andorra
- other names: {"ca": "Escudelles populars a Andorra"}
- countries: (none)
- kinds: soup, Traditions of Catalonia
- ingredients: cereal, vegetable, potato, pork

## DISH Q134697603
- name: Ikomochi
- description: Japanese rice confection
- countries: (none)
- kinds: rice cake
- has Wikipedia article: en

## DISH Q1347028
- name: Pulled pork
- other names: {"zh": "煙燻手撕豬"}
- description: classic American barbecue dish
- countries: US
- cuisines: cuisine of the United States
- kinds: pork dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q134704040
- name: Pada de Vale de Ílhavo
- description: Pada bread from Vale de Ílhavo, registered at the Albergaria-à-velha Bread Festival, June 2025
- countries: PT
- kinds: food, bread, intangible cultural heritage
- ingredients: wheat flour, Poolish, salt, water

## DISH Q134723440
- name: Spagatkrapfen
- other names: {"de": "Spagatkrapfen"}
- countries: (none)

## DISH Q134726795
- name: Bika batu bulek
- other names: {"min": "Bika batu bulek"}
- countries: ID
- kinds: food
- ingredients: rice flour

## DISH Q134726804
- name: Gulai talua
- other names: {"min": "Gulai talua"}
- countries: ID
- kinds: food
- ingredients: coconut milk, bumbu, egg as food

## DISH Q134726855
- name: Sambalado jariang
- other names: {"min": "Sambalado jariang"}
- countries: ID
- kinds: salad, human food
- ingredients: Sambalado

## DISH Q134726859
- name: Gulai ikan nila
- other names: {"min": "Gulai ikan nila"}
- countries: ID
- kinds: food
- ingredients: coconut milk, bumbu, tilapia

## DISH Q134728717
- name: Bankietówka
- other names: {"pl": "bankietówka"}
- countries: PL
- cuisines: Polish cuisine
- kinds: cookie, cake

## DISH Q134731318
- name: Бекмес із кавуна
- other names: {"uk": "Бекмес із кавуна"}
- countries: UA
- kinds: dessert, confectionery, dish
- ingredients: watermelon juice, watermelon

## DISH Q134738058
- name: Confettura calabrese
- description: chili jam typical of Calabria, Italy
- countries: IT
- kinds: fruit jam

## DISH Q134739964
- name: Mushrooms on toast
- description: mushrooms on a slice of toasted bread
- countries: (none)
- kinds: dish
- ingredients: edible mushroom, toast

## DISH Q134774896
- name: Gulai jariang
- other names: {"min": "Gulai jariang"}
- countries: ID
- kinds: food
- ingredients: Archidendron pauciflorum, coconut milk, bumbu

## DISH Q134774918
- name: Dendeng masiak
- other names: {"min": "Dendeng masiak"}
- countries: (none)
- kinds: dendeng, human food

## DISH Q134774947
- name: Kipang bareh
- other names: {"min": "Kipang bareh"}
- countries: ID
- kinds: food, snack
- ingredients: glutinous rice

## DISH Q134775146
- name: Gulai sukun
- other names: {"min": "Gulai sukun"}
- countries: (none)
- cuisines: Padang cuisine
- kinds: human food

## DISH Q134775282
- name: Sarang balam
- other names: {"min": "Sarang balam"}
- countries: (none)
- cuisines: Padang cuisine
- kinds: snack, human food

## DISH Q134775487
- name: Randang cubadak
- other names: {"min": "Randang cubadak"}
- countries: ID
- cuisines: Minangkabau Wikipedia
- kinds: food
- ingredients: coconut milk, bumbu, Artocarpus heterophyllus

## DISH Q134775838
- name: Roti tenong
- other names: {"min": "Roti tenong"}
- countries: ID
- kinds: food, snack
- ingredients: roti, egg as food

## DISH Q134775984
- name: Pisang panggang
- other names: {"min": "Pisang panggang"}
- countries: ID
- kinds: food, snack, human food

## DISH Q13479641
- name: Scorcolga
- description: Romanian condiment made with walnuts and bread
- countries: MD, RO
- cuisines: Romanian cuisine, Moldovan cuisine
- kinds: sauce
- ingredients: garlic, walnut
- has Wikipedia article: en

## DISH Q13479746
- name: Covrigi
- description: Romanian baked goods similar to pretzels
- countries: RO
- kinds: food, bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q134817183
- name: Isombe
- other names: {"mul": "Isombe"}
- description: popular stew in Rwanda
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q134837243
- name: Bolo de Milho de Paraduça, Vale de Cambra
- other names: {"pt": "Bolo de Milho de Paraduça, Vale de Cambra"}
- countries: PT
- kinds: food, bread, intangible cultural heritage
- ingredients: maize flour, salt, water

## DISH Q1348512
- name: Erbsencoulis
- other names: {"de": "Erbsencoulis"}
- countries: (none)
- kinds: dish

## DISH Q134874173
- name: Ikan bilih goreng
- other names: {"min": "Ikan bilih goreng"}
- countries: ID
- kinds: food
- ingredients: Mystacoleucus padangensis, cooking oil

## DISH Q134874197
- name: Barendo Omellete
- countries: ID
- kinds: omelette, food
- ingredients: onion, egg as food

## DISH Q134874227
- name: Lontong cubadak
- other names: {"min": "Lontong cubadak"}
- countries: ID
- kinds: food
- ingredients: lontong, bumbu, Artocarpus heterophyllus

## DISH Q134880972
- name: Lontong paku
- other names: {"min": "Lontong paku"}
- countries: ID
- kinds: food
- ingredients: lontong, bumbu

## DISH Q134880990
- name: Samba buruak
- other names: {"min": "Samba buruak"}
- countries: ID
- kinds: food
- ingredients: Parkia speciosa, Engraulidae

## DISH Q134880996
- name: Gulai rabuang
- other names: {"min": "Gulai rabuang"}
- countries: ID
- kinds: food
- ingredients: bamboo shoots, bumbu

## DISH Q134885329
- name: Lećevački cheese
- description: traditional Croatian cheese
- countries: HR
- kinds: cheese

## DISH Q134892249
- name: Saka Manjū
- description: Traditional Japanese confectionery
- countries: (none)
- kinds: manjū
- has Wikipedia article: en

## DISH Q1348968
- name: Strawberry jam
- description: jam made from strawberries
- countries: (none)
- kinds: berry jam
- ingredients: strawberry, pectin, sugar
- has Wikipedia article: en

## DISH Q1349413
- name: Bamba
- description: peanut snack
- countries: IL
- kinds: snack, puffed grain, dish, product
- ingredients: Fragaria, flour
- has Wikipedia article: en

## DISH Q134957009
- name: Soutzoukakia smyrneika
- other names: {"it": "soutzoukakia smyrneika"}
- description: A "köfte" dish that originated in Izmir, Turkey, and common to the Turkish and Greek cuisines.
- countries: TR
- kinds: main course, Köftes in the Turkish cuisine
- ingredients: meat
- has Wikipedia article: en

## DISH Q134960036
- name: Polish style pickled cucumbers
- description: snack or semi-finished product of Polish cuisine made from cucumbers
- countries: PL
- kinds: preserved food, intermediate product, snack, fermented food
- ingredients: garlic, horseradish root, cucumber, brine, Anethum graveolens

## DISH Q134960082
- name: ಕೋರಿ ಪುಳಿಮುಂಚಿ
- other names: {"tcy": "ಕೋರಿ ಪುಳಿಮುಂಚಿ"}
- countries: (none)
- kinds: dish

## DISH Q134970941
- name: Hot pressed sandwich
- description: sandwich that was press-heated through pie iron or other cooking appliance
- countries: (none)
- kinds: sandwich
- ingredients: sliced bread, toast

## DISH Q134988569
- name: Puteri ayu
- description: Malay dessert
- countries: MY
- kinds: Kuih

## DISH Q134992253
- name: Roasted vegetables
- countries: (none)
- kinds: vegetable dish

## DISH Q135003095
- name: Tender tamarind leaves
- description: Edible young leaves from tamarind and similar trees, used in Telugu cuisine especially during spring
- countries: IN
- cuisines: Telugu cuisine
- kinds: leaf vegetable, food ingredient

## DISH Q135003473
- name: Seed
- description: The reproductive unit of a plant used for germination and food production |
- countries: IN
- kinds: plant reproduction, seed

## DISH Q135004750
- name: Bombay halwa
- description: Indian and Pakistani confectionery
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q135010731
- name: Cheese salad
- countries: (none)
- kinds: salad
- ingredients: cheese

## DISH Q135036621
- name: Reviro
- other names: {"es": "Reviro"}
- countries: (none)
- kinds: bread dish
- ingredients: wheat flour, animal fats and oils, table salt, water

## DISH Q135038148
- name: Tomato leather
- description: Foodstuff
- countries: GB
- kinds: food
- ingredients: blue tomato

## DISH Q135103632
- name: Oostakkerse vlaai
- other names: {"nl": "Oostakkerse vlaai"}
- countries: BE
- kinds: vlaai

## DISH Q135103638
- name: Bruegelse vlaai
- other names: {"nl": "Bruegelse vlaai"}
- countries: BE
- kinds: vlaai

## DISH Q135103987
- name: ASSFACE Diet
- description: Nutrition plan and brand, founded by Erika Rawes in the United States, focused on reducing added sugars and promoting whole foods
- countries: US
- kinds: diet

## DISH Q135112167
- name: The William Mitchell
- description: Artistic ice lolly
- countries: (none)
- kinds: ice pop

## DISH Q135112256
- name: The One With All the Colour
- description: Artistic ice cream
- countries: (none)
- kinds: ice cream
- ingredients: tutti frutti

## DISH Q135112272
- name: In Search of the Pineapple
- description: Artistic ice lolly
- countries: (none)
- kinds: ice pop

## DISH Q135116202
- name: Tojiko mame
- description: Japanese confectionery
- countries: JP
- kinds: wagashi
- has Wikipedia article: en

## DISH Q135180792
- name: Kiliṣi
- other names: {"yo": "Kiliṣi"}
- countries: (none)
- cuisines: Hausa cuisine
- kinds: stew, food

## DISH Q13519276
- name: Torcetti
- description: Northern Italian yeasted cookie
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q135222814
- name: Umxhaxha
- other names: {"xh": "Umxhaxha"}
- countries: (none)
- kinds: dish

## DISH Q135222876
- name: Kube mutli
- countries: IN
- kinds: human food
- ingredients: shellfish, rice

## DISH Q135239198
- name: Pattola kuah
- countries: ID
- kinds: human food

## DISH Q135258659
- name: Sajjige bajil
- countries: IN
- kinds: human food
- ingredients: poha

## DISH Q135258665
- name: Thimare chutney
- countries: IN
- kinds: chutney, human food

## DISH Q135265063
- name: Pizza with salami
- countries: IT
- cuisines: Italian cuisine
- ingredients: salami

## DISH Q135266214
- name: Lukum
- description: Sudanese Donuts
- countries: SD
- kinds: food, snack
- ingredients: baker's yeast, flour, table salt, sugar, water

## DISH Q135266265
- name: Aish baladi
- description: local Egyptian flatbread
- countries: EG
- kinds: food, flatbread
- ingredients: whole-wheat flour, flour

## DISH Q135266298
- name: ಪಂಚಕಜ್ಜಾಯ
- other names: {"tcy": "ಪಂಚಕಜ್ಜಾಯ"}
- countries: IN
- kinds: human food

## DISH Q135266305
- name: Banana flower curry
- countries: IN
- kinds: chutney, human food

## DISH Q135266364
- name: Sweet Potato Bajji
- countries: IN
- kinds: human food
- ingredients: Sweet potato

## DISH Q135266381
- name: Sweet potato curry
- countries: IN
- kinds: snack, human food
- ingredients: Sweet potato

## DISH Q1352696
- name: Chankonabe
- other names: {"zh": "相扑火锅"}
- description: Japanese stew
- countries: JP
- kinds: nabemono
- ingredients: dashi
- has Wikipedia article: en, zh

## DISH Q135270787
- name: Semiya upma
- countries: IN
- kinds: human food

## DISH Q135270790
- name: ಸಾರ್ನೆದಡ್ಡೆ
- other names: {"tcy": "ಸಾರ್ನೆದಡ್ಡೆ"}
- countries: IN
- kinds: human food

## DISH Q135272957
- name: Semovita
- description: a popular Nigerian brand of semolina flour, a type of wheat flour
- countries: NG
- kinds: food, dish
- ingredients: wheat flour

## DISH Q135273022
- name: Gala sausage roll
- description: snack made from pure beef filling and rich wheat based pastry
- countries: NG
- kinds: snack, food
- ingredients: flour, beef, table salt

## DISH Q135283413
- name: ಕೇನೆದ ಪುಂಡಿ
- other names: {"tcy": "ಕೇನೆದ ಪುಂಡಿ"}
- countries: IN
- kinds: human food

## DISH Q1352897
- name: Unadon
- other names: {"zh": "鳗鱼饭"}
- description: Japanese dish
- countries: JP
- kinds: dish, donburi, fish dish
- ingredients: unagi, rice
- has Wikipedia article: en, zh

## DISH Q135291985
- name: Thiebou Diola
- description: (also spelled Ceebu Diola) is a traditional rice-based dish from the Diola (Jola) ethnic group in the Casamance region of southern Senegal.
- countries: SN
- kinds: food
- ingredients: Fresh Seafood, Eggplants, Cubes, okra, dried fish, Sumbala, whole grain, palm oil, sauce, chili pepper, Hibiscus, Allium, tomato, Allium sativum, table salt

## DISH Q135313204
- name: Martaba' mihun
- other names: {"mad": "Martaba' mihun"}
- countries: ID
- kinds: human food, Mutabak

## DISH Q135313427
- name: Torcik Wedlowski
- description: Polish wafer cake covered in chocolate
- countries: PL
- kinds: wafer
- ingredients: wafer, chocolate
- has Wikipedia article: en

## DISH Q135319281
- name: Arganak
- description: traditional cooked Armenian soup
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q135333762
- name: Mutura sausage
- description: Kenyan delicacy made from cleaned animal intestines stuffed with a mixture of minced meat, blood, and spices
- countries: KE
- kinds: snack, food
- ingredients: meat, minced meat, intestines as food, spice
- has Wikipedia article: en

## DISH Q135334986
- name: Plasas
- description: traditional dish prepared in Ghana
- countries: GH, LR, SL
- kinds: dish, food
- ingredients: peanut butter, smoked fish, spice, leaf vegetable, meat

## DISH Q13537901
- name: Opekanec
- description: small baked balls of yeast dough
- countries: SK
- kinds: bakers' confection
- has Wikipedia article: en

## DISH Q135395863
- name: Pastel and Fataya
- description: traditional dish from West Africa
- countries: SN
- kinds: culinary speciality, snack
- ingredients: pastel, garlic, peanut oil, Capsicum, chili pepper, Tilapia mariae, vinegar, tomato, onion, table salt

## DISH Q135396619
- name: Pastís de la iaia
- other names: {"ca": "Pastís de la iaia"}
- countries: (none)
- kinds: cake

## DISH Q135400013
- name: Larb pa
- description: Lao fish salad
- countries: (none)
- kinds: larb

## DISH Q135403800
- name: Gofre amb gelat de llet merengada i cremaet
- other names: {"ca": "Gofre amb gelat de llet merengada i cremaet"}
- countries: (none)
- kinds: dessert
- ingredients: Cremat, Leche Merengada, waffle

## DISH Q135406996
- name: Red cabbage salad
- countries: (none)
- kinds: cabbage salad
- ingredients: red cabbage

## DISH Q135407771
- name: Curry soup
- countries: (none)
- kinds: soup
- ingredients: curry powder

## DISH Q135409316
- name: Bulyon
- other names: {"az": "Bulyon"}
- countries: (none)
- kinds: soup, human food

## DISH Q135409321
- name: Stewed beef
- countries: (none)
- kinds: beef dish

## DISH Q135411212
- name: Radhkha
- description: dish
- countries: TN
- kinds: dish
- ingredients: mashed tomatoes, peppercorn, olive oil, Allium sativum, table salt

## DISH Q135412763
- name: Soup Kandia
- description: traditional dish from West Africa
- countries: SN
- kinds: dish
- ingredients: garlic, okra, palm oil, Capsicum, beef, Oryza molida, table salt, meat, fish

## DISH Q135412815
- name: Yassa Guinar
- description: traditional dish from West Africa
- countries: SN
- kinds: food, fish dish
- ingredients: Oryza molida, chicken, fish

## DISH Q135415105
- name: Thiebou Yapp
- description: traditional dish from West Africa
- countries: SN
- kinds: dish, cuisine, meat, Oryza molida
- ingredients: pea, wafer dicing, onion, jasmine rice, Phaseolus lunatus, Red-bellied piranha, lamb meat, Capsicum, balsamic vinegar, Lactuca sativa, Phaseolus vulgaris, Welsh onion, Allium sativum, maize, table salt, vegetable, honey, carrot

## DISH Q135415632
- name: Angwamu (oil rice)
- description: Popular dish in Ghana made by frying rice in oil before adding water and cooking it until fluffy
- countries: GH
- cuisines: African cuisine
- kinds: food, cereal
- ingredients: Oryza molida, vegetable oil, Allium

## DISH Q135419287
- name: Vermicelle Poulet
- description: Senegalese couscous dish
- countries: SN
- cuisines: Mughlai cuisine
- kinds: dish
- ingredients: vermicelli, chicken, Peperomia heyneana, macedonia, lamb, chicken as food, Allium, vinegar, Allium sativum, table salt

## DISH Q135423366
- name: Weinsteinkraut
- other names: {"de": "Weinsteinkraut"}
- countries: (none)
- kinds: stew

## DISH Q135426406
- name: Makrout El Louz
- other names: {"fr": "Makrout El Louz"}
- countries: (none)
- kinds: Makroudh, pastry

## DISH Q135427283
- name: Abekatekonto soup
- description: Ghanaian soup, specifically a type of palm nut soup, often enjoyed with fufu.
- countries: GH
- kinds: soup, Palm nut
- ingredients: Palm nut, Capsicum, peanut, meat

## DISH Q135431951
- name: Dambu nama
- description: spiced shredded dried meat delicacy from Northern Nigeria
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q135432049
- name: Yumbeka
- description: A local Ghanian dish made out of beans leaves
- countries: (none)
- kinds: bean, dish
- ingredients: bean

## DISH Q135432161
- name: Bogobe
- countries: (none)
- kinds: porridge

## DISH Q135432421
- name: Yam Dumpling
- description: A dumpling made by pureeing a purple yam and coating it in rice flour.
- countries: (none)
- kinds: yam, dish
- ingredients: yam, rice

## DISH Q135433271
- name: Boko Boko Harees
- description: Boko Boko Harees is a traditional dish originating from the African country of Burundi
- countries: BI
- kinds: dish, wheat
- ingredients: turmeric, wheat, chicken breast, butter

## DISH Q135435296
- name: Капăртма
- other names: {"cv": "Капăртма"}
- countries: (none)
- cuisines: Chuvash cuisine
- kinds: food, dairy product

## DISH Q135437200
- name: Richeese Nabati
- description: Variant of Nabati Wafer
- countries: ID
- kinds: food product, wafer
- ingredients: cheese

## DISH Q135437322
- name: Soup meatball
- description: small meatball used in soup
- countries: (none)
- kinds: meatball
- ingredients: minced meat

## DISH Q135437340
- name: Bungo fruit (Saba comorensis)
- description: species of flowering plant
- countries: (none)
- kinds: fruit, plant

## DISH Q135437350
- name: Kadayif noodles
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q135437906
- name: Smocha
- description: Kenyan street food
- countries: (none)
- kinds: wrap
- ingredients: Kachumbari, Smokie, chapati

## DISH Q135439499
- name: Gatnabour
- description: Armenian dish
- countries: AM
- kinds: dish, Armenian cuisine

## DISH Q135440788
- name: Churrasca
- description: type of bread
- countries: CL
- kinds: bread

## DISH Q135442033
- name: Poached pear
- countries: (none)
- kinds: pear, dish
