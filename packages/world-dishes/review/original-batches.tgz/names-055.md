# Review batch names-055

## DISH Q83566646
- name: Chatnoir
- countries: JP
- kinds: Western confection

## DISH Q835895
- name: Pampuchy
- description: Polish steamed yeast dumpling
- countries: PL
- kinds: knödel, dish, pyzy
- ingredients: chicken egg, cow's milk, wheat flour, baker's yeast
- has Wikipedia article: en

## DISH Q83603766
- name: Tuwon shinkafa
- description: Nigerian rice pudding
- countries: NG
- kinds: dish, human food, rice, swallow
- ingredients: rice
- has Wikipedia article: en

## DISH Q83613130
- name: Baocui
- description: fried cracker
- countries: CN
- kinds: food, cracker, food ingredient

## DISH Q83629834
- name: Italian stuffed pasta
- countries: IT
- kinds: stuffed pasta

## DISH Q836773
- name: Jokbal
- other names: {"zh": "猪脚"}
- description: Korean dish of pork trotters
- countries: KR
- cuisines: Korean cuisine
- kinds: pork, dish, pork dish
- ingredients: ham hock
- has Wikipedia article: en

## DISH Q837207
- name: Pumpernickel
- other names: {"zh": "南瓜饼"}
- description: type of German rye bread
- countries: DE
- kinds: dish, rye bread
- ingredients: rye flour
- has Wikipedia article: en

## DISH Q837480
- name: Aspic
- other names: {"zh": "肉凍"}
- description: molded meat gelatin dish
- countries: FR, RU, EE, LV, UA, BY, LT
- cuisines: French cuisine, Russian cuisine, Estonian cuisine, Latvian cuisine, Ukrainian cuisine, Belarusian cuisine, Lithuanian cuisine
- kinds: food, dish, gelatin dessert, appetizer
- ingredients: beef, pork
- has Wikipedia article: en, zh

## DISH Q837620
- name: Egg waffle
- other names: {"zh": "鸡蛋仔"}
- description: Hongkongese street food
- countries: HK
- kinds: waffle
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q837647
- name: Dry-fried beef ho fun
- other names: {"zh": "干炒牛河"}
- description: a beef and noodle Cantonese dish
- countries: CN
- kinds: dish, beef dish
- ingredients: mung bean sprout, onion, shahe fen, soy sauce, beef
- has Wikipedia article: en, zh

## DISH Q83788660
- name: Rusa patkuko
- other names: {"eo": "rusa patkuko"}
- countries: (none)
- kinds: blini

## DISH Q838462
- name: Pork chop bun
- other names: {"zh": "猪扒包"}
- description: Macanese dish of a fried pork chop in a piggy bun
- countries: (none)
- kinds: food, sandwich, pork dish
- ingredients: piggy bun
- has Wikipedia article: en, zh

## DISH Q839910
- name: Pişmaniye
- description: Turkish sweet
- countries: TR
- kinds: dessert, dish
- ingredients: white sugar, flour
- has Wikipedia article: en

## DISH Q840448
- name: Cellophane noodles
- other names: {"zh": "粉丝"}
- description: transparent noodle made from starch
- countries: (none)
- kinds: starch noodle, noodle, string-like macaroni products
- ingredients: starch
- has Wikipedia article: en, zh

## DISH Q84087415
- name: Catless
- countries: FR, MU
- kinds: dish
- ingredients: potato

## DISH Q8410950
- name: Toruko rice
- other names: {"zh": "土耳其飯"}
- description: Japanese dish
- countries: JP
- cuisines: yōshoku
- kinds: type of food or dish, Japanese rice dish
- ingredients: tonkatsu, pilaf, spaghetti
- has Wikipedia article: zh

## DISH Q842187
- name: Koala's March
- other names: {"zh": "乐天小熊饼"}
- description: cookie snack from Japan
- countries: JP
- kinds: snack
- has Wikipedia article: en, zh

## DISH Q842221
- name: Meju
- other names: {"zh": "燻造"}
- description: fermented soybean bricks
- countries: KR
- cuisines: Korean cuisine
- kinds: food
- ingredients: soy bean, Aspergillus flavus var. oryzae
- has Wikipedia article: en

## DISH Q842376
- name: Har gow
- other names: {"zh": "虾饺"}
- description: traditional Cantonese dumpling
- countries: CN
- cuisines: Cantonese cuisine
- kinds: stuffed pasta, shrimp dish
- ingredients: shrimp and prawn as food, bamboo shoots
- has Wikipedia article: en, zh

## DISH Q842618
- name: Worcestershire sauce
- other names: {"zh": "辣酱油"}
- description: sauce
- countries: (none)
- kinds: fish sauce, fermented food
- ingredients: garlic, ginger, molasses, vinegar, soybean, fish
- has Wikipedia article: en, zh

## DISH Q843052
- name: Tteok-galbi
- other names: {"zh": "韓式烤肉餅"}
- description: grilled short rib patties
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q843252
- name: Saeujeot
- other names: {"zh": "韩国虾酱"}
- description: jeotgal made from small shrimp
- countries: (none)
- kinds: jeotgal
- ingredients: shrimp, table salt
- has Wikipedia article: en

## DISH Q843549
- name: Fuqi feipian
- other names: {"zh": "夫妻肺片"}
- description: Spicy Sichuan beef dish
- countries: CN
- cuisines: Chinese cuisine
- kinds: beef dish
- has Wikipedia article: en, zh

## DISH Q843795
- name: Bakso
- other names: {"zh": "肉丸子"}
- description: Tionghoa cuisine
- countries: ID
- kinds: food, meatball, minced food ball
- ingredients: garlic, ground beef, tapioca, egg white, scallion, rice vermicelli, beef, Brassica rapa subsp. chinensis, black pepper, baking powder, Apium graveolens, ice, table salt, sugar
- has Wikipedia article: en

## DISH Q843884
- name: Myeolchi-jeot
- other names: {"zh": "发酵咸凤尾鱼"}
- description: salted anchovies
- countries: (none)
- kinds: jeotgal
- ingredients: Engraulis japonicus
- has Wikipedia article: en

## DISH Q844029
- name: Ginger milk curd
- other names: {"zh": "姜汁撞奶"}
- description: Chinese dessert
- countries: CN
- kinds: pastry
- ingredients: ginger
- has Wikipedia article: en, zh

## DISH Q844314
- name: Siu mei
- other names: {"zh": "烧味"}
- description: Cantonese roasted meat
- countries: CN
- cuisines: Cantonese cuisine
- kinds: food
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q844466
- name: Siu yuk
- other names: {"zh": "烧猪"}
- description: variety of siu mei
- countries: CN
- kinds: meat dish, pork dish
- has Wikipedia article: en, zh

## DISH Q84457858
- name: Cansi
- description: Filipino beef soup originating from the Western Visayas
- countries: PH
- kinds: soup
- has Wikipedia article: en

## DISH Q84458251
- name: Sheet pizza
- description: Thin-crust style pizza baked on a baking sheet
- countries: (none)
- kinds: type of pizza
- ingredients: sheet pan
- has Wikipedia article: en

## DISH Q84509996
- name: Mohrenkopf
- description: German pastry
- countries: DE
- cuisines: German cuisine
- kinds: pastry
- ingredients: vanilla pudding, sponge cake, chocolate

## DISH Q845361
- name: Yumilgwa
- description: Korean dessert
- countries: (none)
- kinds: hangwa
- ingredients: rice
- has Wikipedia article: en

## DISH Q845367
- name: Gamja-jeon
- description: potato dish
- countries: (none)
- kinds: jeon, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q845376
- name: Ulmyeon
- other names: {"zh": "温滷面"}
- description: Korean-Chinese seafood noodle dish
- countries: (none)
- cuisines: Korean Chinese cuisine
- kinds: seafood dish, noodle dish
- ingredients: noodle
- has Wikipedia article: en, zh

## DISH Q84561780
- name: Azuki bean ice cream
- description: ice cream with natural or artificial Azuki bean flavoring
- countries: (none)
- kinds: ice cream, azuki bean based food
- ingredients: Vigna angularis, ice cream

## DISH Q84561781
- name: Azuki bean based food
- countries: (none)
- kinds: legume dish, type of food or dish
- ingredients: Vigna angularis

## DISH Q84561796
- name: Blackberry ice cream
- description: ice cream with natural or artificial blackberry flavoring
- countries: (none)
- kinds: ice cream, blackberry based food
- ingredients: blackberry, ice cream

## DISH Q84564532
- name: Baba de camelo
- description: Portuguese dessert
- countries: PT
- kinds: mousse
- ingredients: Prunus subg. Amygdalus, condensed milk, egg as food
- has Wikipedia article: en

## DISH Q84573706
- name: Blueberry ice cream
- description: ice cream with natural or artificial blueberry flavoring
- countries: (none)
- kinds: ice cream, blueberry based food
- ingredients: ice cream, blueberry

## DISH Q84573720
- name: Caramel ice cream
- description: ice cream with natural or artificial caramel flavoring
- countries: (none)
- kinds: ice cream, caramel based food
- ingredients: caramel, ice cream
- has Wikipedia article: en

## DISH Q84578333
- name: Romeu and Julieta
- description: Brazilian dessert made of cheese and guava paste
- countries: BR
- kinds: dessert
- ingredients: Goiabada, cheese
- has Wikipedia article: en

## DISH Q8459791
- name: Coca bamba
- other names: {"ca": "coca bamba"}
- countries: ES
- kinds: dessert

## DISH Q84598217
- name: Chili burritos
- description: fast food
- countries: (none)
- kinds: burrito

## DISH Q84602282
- name: Rot duan
- countries: TH
- kinds: street food

## DISH Q846310
- name: Trenette
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q846581
- name: White cut chicken
- other names: {"zh": "白切鸡"}
- description: Cantonese dish
- countries: CN
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q846849
- name: Hot pot
- other names: {"zh": "火锅"}
- description: Chinese and Southeast Asian dish
- countries: CN
- cuisines: Chinese cuisine
- kinds: soup, fondue, dish
- has Wikipedia article: en, zh

## DISH Q847245
- name: Hobak-juk
- other names: {"zh": "南瓜粥"}
- description: Korean porridge
- countries: (none)
- kinds: dish, juk
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q84725313
- name: Rodelika
- description: reproducible, seed-solid carrot
- countries: (none)
- kinds: carrot, plant variety

## DISH Q84761085
- name: Corn cheese
- description: Korean food
- countries: KR
- kinds: food, anju
- ingredients: mayonnaise, Zea mays Saccharata Group, mozzarella
- has Wikipedia article: en

## DISH Q847652
- name: Shuizhu
- other names: {"zh": "水煮"}
- description: Chinese dish
- countries: CN
- kinds: Sichuan cuisine, dish
- ingredients: vegetable oil, beef, chili pepper
- has Wikipedia article: en

## DISH Q848380
- name: Formai de Mut dell'Alta Valle Brembana PDO
- other names: {"zh": "Formai de Mut dell'Alta Valle Brembana DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: Italian cheese, cheese
- has Wikipedia article: en

## DISH Q8484030
- name: Dark soy sauce
- other names: {"zh": "老抽"}
- description: Chinese dark-coloured soy sauce used mainly for adding colour and flavour to dishes
- countries: CN
- kinds: soy sauce
- has Wikipedia article: en, zh

## DISH Q84871014
- name: Papari
- description: a traditional Banjar cake shaped like a bitter melon
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, kue, traditional food
- ingredients: glutinous rice flour, coconut milk, Pandanus amaryllifolius, table salt, sugar

## DISH Q848957
- name: Coto makassar
- description: Indonesian traditional soup
- countries: ID
- cuisines: Indonesian cuisine
- kinds: stew, soto, soup, food, dish, human food, type of food or dish
- ingredients: Indonesian bay leaf, shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, coriander seed, ginger, Tauco, rice water, peanut, fried onion, lontong, palm sugar, Aleurites moluccanus, coconut milk, scallion, Cinnamomum verum, broth, beef, Citrus × aurantiifolia, chili pepper, offal, black pepper, Cymbopogon citratus, Apium graveolens, Carum carvi, table salt, cooking oil, Alpinia galanga
- has Wikipedia article: en

## DISH Q849058
- name: Beef Stroganoff
- other names: {"zh": "斯特罗加诺夫牛肉"}
- description: sautéed beef served in sauce
- countries: FR, RU
- cuisines: French cuisine, Russian cuisine
- kinds: beef dish, Beef Stroganoff
- ingredients: tomato paste, smetana, beef
- has Wikipedia article: en

## DISH Q84955182
- name: Timpusca
- other names: {"es": "timpusca"}
- countries: (none)
- kinds: soup, meal

## DISH Q849816
- name: Rock candy
- other names: {"zh": "冰糖"}
- description: confection composed of relatively large sugar crystals
- countries: IR
- kinds: culinary speciality, confectionery
- ingredients: sugar
- has Wikipedia article: en, zh

## DISH Q851245
- name: Beuschel
- description: Austrian stew
- countries: (none)
- kinds: ragout, meat dish
- ingredients: offal
- has Wikipedia article: en

## DISH Q851714
- name: Mandu-guk
- other names: {"zh": "馒头汤"}
- description: food
- countries: KR
- cuisines: Korean cuisine
- kinds: guk
- ingredients: mandu
- has Wikipedia article: en, zh

## DISH Q851734
- name: Maeuntang
- description: Korean spicy fish soup
- countries: KR
- cuisines: Korean cuisine
- kinds: jjigae, fish soup
- ingredients: chili powder, gochujang, fish as food
- has Wikipedia article: en

## DISH Q851746
- name: Dashi
- other names: {"zh": "日式上湯"}
- description: class of soup and cooking stock used in Japanese cuisines
- countries: JP
- kinds: broth, dish
- ingredients: Saccharina japonica, katsuobushi
- has Wikipedia article: en, zh

## DISH Q85176137
- name: Kala bhuna
- description: Bangladeshi meat curry
- countries: BD
- kinds: food
- ingredients: beef
- has Wikipedia article: en

## DISH Q852261
- name: Buckling
- other names: {"zh": "腌魚"}
- description: hot smoked herring
- countries: DE
- kinds: smoked fish, fish dish
- ingredients: Clupea harengus
- has Wikipedia article: en

## DISH Q8529545
- name: Light soy sauce
- other names: {"zh": "生抽"}
- description: variety of Chinese soy sauce
- countries: (none)
- kinds: soy sauce
- has Wikipedia article: zh

## DISH Q85413737
- name: Udong
- other names: {"zh": "韩式打卤面"}
- description: Korean Chinese noodle soup
- countries: KR
- kinds: noodle dish

## DISH Q85428376
- name: Ayvalık tostu
- description: warm sandwich from Turkey
- countries: TR
- kinds: food, sandwich
- ingredients: pastırma, sujuk, sausage, cheese, bread
- has Wikipedia article: en

## DISH Q854904
- name: Bhatoora
- description: deep-fried leavened bread from the Indian Subcontinent
- countries: IN
- kinds: Indian bread, Pakistani bread
- ingredients: maida flour
- has Wikipedia article: en

## DISH Q855130
- name: Kompyang
- other names: {"zh": "光饼"}
- description: food
- countries: CN
- kinds: bread, bing
- ingredients: lard
- has Wikipedia article: en, zh

## DISH Q855373
- name: Ice pop
- other names: {"zh": "冰棍"}
- description: water-based frozen confection on a stick
- countries: US
- kinds: ice cream, ice cream bar
- ingredients: flavoring, juice, water
- has Wikipedia article: en, zh

## DISH Q855481
- name: Biaslag
- description: Mongolian cheese made from soured milk
- countries: MN
- kinds: cheese, dairy product
- ingredients: yak milk

## DISH Q855956
- name: Potato bread
- other names: {"zh": "馬鈴薯麵包"}
- description: bread made with potato and flour
- countries: (none)
- kinds: bread, potato dish
- ingredients: potato
- has Wikipedia article: en, zh

## DISH Q856034
- name: Bibeleskaes
- countries: (none)
- kinds: dish
- ingredients: curd

## DISH Q85630768
- name: Juanguila
- other names: {"es": "Juanguila"}
- countries: ES
- kinds: meal, dessert

## DISH Q856330
- name: Cracker
- other names: {"zh": "克力架"}
- description: food
- countries: US
- kinds: cookie, pastry, finger food, dry biscuits
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q8567266
- name: Gohan
- description: Japanese cooked rice
- countries: JP
- kinds: cooked grain, cooked rice, Japanese rice dish
- ingredients: Japanese rice

## DISH Q856899
- name: Deuk Deuk Tong
- other names: {"zh": "啄啄糖"}
- description: Hong Kongese sweet
- countries: CN, HK
- kinds: confectionery
- ingredients: maltose
- has Wikipedia article: en, zh

## DISH Q85735249
- name: Gbegiri
- description: traditional Nigerian soup
- countries: NG
- kinds: dish, cuisine, human food, soup
- ingredients: crayfish, seasoning, palm oil, table salt
- has Wikipedia article: en

## DISH Q85739611
- name: Achu soup
- description: traditional food (soup) in Cameroon,
- countries: CM
- kinds: soup, dish
- ingredients: cocoyam, palm oil, spice, water, fish
- has Wikipedia article: en

## DISH Q85742197
- name: Apio
- description: balkan Jewish braised celery root and carrot dish
- countries: (none)
- cuisines: Sephardic Jewish cuisine
- kinds: appetizer
- ingredients: Apium graveolens, carrot
- has Wikipedia article: en

## DISH Q85743298
- name: Ashishim
- description: Red lentil pancake dish of Ancient Israelite origin
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q85744456
- name: Ayam kodok
- description: Indonesian chicken dish
- countries: ID
- kinds: dish
- has Wikipedia article: en

## DISH Q85745394
- name: Barbecue spaghetti
- description: American pasta dish
- countries: (none)
- kinds: spaghetti, dish
- has Wikipedia article: en

## DISH Q85745501
- name: Barquette
- description: pastry shell in the shape of a boat
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q85747391
- name: Biscochos
- description: sephardi Jewish cookie
- countries: (none)
- kinds: cookie
- ingredients: sesame seed, vanilla extract, egg wash, cinnamon sugar, anise oil, orange juice, oil, flour, sugar
- has Wikipedia article: en

## DISH Q85748333
- name: Borracho beans
- description: traditional Mexican and Southern Texas dish
- countries: MX
- kinds: dish
- has Wikipedia article: en

## DISH Q85748980
- name: Brisket
- description: Jewish dish
- countries: IL
- cuisines: Jewish cuisine
- kinds: beef dish
- has Wikipedia article: en

## DISH Q85749574
- name: Burmese fried rice
- description: Fried rice dish
- countries: MM
- kinds: dish
- has Wikipedia article: en

## DISH Q85750898
- name: Cassia flower bud salad
- description: Festive Burmese salad
- countries: MM
- kinds: dish
- has Wikipedia article: en

## DISH Q85751421
- name: Champaran meat
- other names: {"zh": "瞻波蘭若煨肉"}
- description: meat dish
- countries: IN
- kinds: meat dish
- has Wikipedia article: en

## DISH Q85753239
- name: Coffin bread
- other names: {"zh": "棺材板"}
- description: Taiwanese bowl-shaped bread
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: food
- has Wikipedia article: en, zh

## DISH Q85754826
- name: Cup-bop
- description: Korean food truck dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q85755689
- name: Daral
- description: Filipino dessert crêpe
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q85757492
- name: Doughnut sandwich
- description: type of sandwich
- countries: (none)
- kinds: sandwich, doughnut
- has Wikipedia article: en

## DISH Q85758017
- name: Duvshaniot
- description: Honey cookies made for Jewish holidays
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q85760630
- name: Fatoot samneh
- description: Israeli fried pita and egg dish
- countries: IL
- kinds: dish
- has Wikipedia article: en

## DISH Q85762176
- name: Fritas de prasa
- description: sephardic Jewish leek fritters
- countries: IL
- cuisines: Sephardic Jewish cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q85764627
- name: Griot
- description: dish in Haitian cuisine
- countries: HT
- kinds: dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q85765579
- name: Braised eggs
- description: traditional Sephardi Jewish dish, popular in Israel
- countries: (none)
- kinds: dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q85767584
- name: Hsi htamin
- description: Burmese oiled rice snack
- countries: MM
- kinds: dish
- has Wikipedia article: en

## DISH Q85771170
- name: Jewish almond cookie
- description: Jewish cookie made with almonds
- countries: US
- kinds: cookie
- ingredients: almond, flour, sugar
- has Wikipedia article: en

## DISH Q85772622
- name: Jødekager
- description: cookie of Danish Jewish origin
- countries: DK
- kinds: food, cookie
- has Wikipedia article: en

## DISH Q85773496
- name: Kanika
- description: rice dish
- countries: IN
- kinds: rice dish
- has Wikipedia article: en

## DISH Q85774104
- name: Kerala beef fry
- description: dish made of beef in Kerala
- countries: IN
- kinds: beef dish
- has Wikipedia article: en

## DISH Q85774221
- name: Khao Jee Pâté
- description: Laotian sandwich
- countries: (none)
- kinds: sandwich
- has Wikipedia article: en

## DISH Q85775061
- name: Kugel Yerushalmi
- description: Baked casserole from Jerusalem
- countries: (none)
- cuisines: Ashkenazi Jewish cuisine, cuisine of Jerusalem
- kinds: human food, Kugel
- ingredients: chicken egg, noodle, black pepper, cinnamon, sugar
- has Wikipedia article: en

## DISH Q85775540
- name: Laffa
- description: Israeli flatbread
- countries: IL
- kinds: flatbread
- has Wikipedia article: en

## DISH Q85784501
- name: Mazalika
- description: Egyptian dish made of chicken liver and gizzard
- countries: EG
- kinds: poultry dish
- has Wikipedia article: en

## DISH Q85787805
- name: Nata de piña
- other names: {"zh": "菠萝奶油"}
- description: Food produced by fermented pineapple juice
- countries: PH
- kinds: confectionery
- has Wikipedia article: en

## DISH Q85789410
- name: Noodle latkes
- description: type of latke made with pasta
- countries: (none)
- kinds: dish, latke
- ingredients: noodle
- has Wikipedia article: en

## DISH Q85789437
- name: Norfolk hot dog
- description: hot dog served served with Lynnhaven mustard, onions and meat sauce, popular in Norfolk, Virginia, US
- countries: US
- kinds: hot dog
- has Wikipedia article: en

## DISH Q85790786
- name: Onion roll
- description: bread flavored with dry onions
- countries: US
- kinds: bread roll
- ingredients: onion
- has Wikipedia article: en

## DISH Q85792108
- name: Paprika Žitava
- description: PDO designated paprika
- countries: SK
- kinds: paprika
- has Wikipedia article: en

## DISH Q85792219
- name: Pargiyot
- description: Israeli skewered chicken dish
- countries: IL
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q85792397
- name: Pathein halawa
- description: Burmese rice desert
- countries: MM
- kinds: pudding
- has Wikipedia article: en

## DISH Q85795693
- name: Rainbow roll
- other names: {"zh": "彩虹卷"}
- description: uramaki sushi roll filled with cucumber, avocado and crab stick
- countries: US
- cuisines: Japanese cuisine
- kinds: sushi
- ingredients: crab stick, avocado, Cucumis sativus, rice
- has Wikipedia article: en

## DISH Q85800897
- name: Shirin polo
- description: persian celebratory rice dish
- countries: IR
- cuisines: Jewish cuisine, Iranian cuisine
- kinds: dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q85801047
- name: Shwe htamin
- description: Burmese golden rice (desert)
- countries: MM
- kinds: dish
- has Wikipedia article: en

## DISH Q85801250
- name: Sinanglay
- description: Filipino dish
- countries: PH
- kinds: fish dish
- has Wikipedia article: en

## DISH Q85801694
- name: Smoked brisket
- description: Beef barbecue dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q85802587
- name: Spicy chicken sandwich
- description: sandwich made with chicken
- countries: (none)
- kinds: burger
- has Wikipedia article: en

## DISH Q85810239
- name: Tortang kalabasa
- description: Filipino squash omelette
- countries: PH
- kinds: dish
- ingredients: calabaza
- has Wikipedia article: en

## DISH Q85811088
- name: Tupig
- description: Filipino food
- countries: PH
- kinds: rice cake
- has Wikipedia article: en

## DISH Q85814488
- name: Wasawasa
- description: local dish from Ghana
- countries: GH
- kinds: dish
- ingredients: Nyombeeka, cabbage, yam, onion, cooking oil, Capsicum, peanut, table salt, fish
- has Wikipedia article: en

## DISH Q85818437
- name: Alkaseba
- description: Middle Eastern dessert
- countries: (none)
- cuisines: Middle Eastern cuisine
- kinds: type of food or dish, dessert
- ingredients: Sesamum indicum, sesame oil

## DISH Q858339
- name: Tekkadon
- other names: {"zh": "鐵火丼"}
- description: Japanese rice dish topped with with tuna sashimi
- countries: JP
- kinds: donburi, Kaisen-don, rice dish, tuna dish, salmon dish
- has Wikipedia article: en, zh

## DISH Q858345
- name: Kusaya
- other names: {"zh": "臭魚乾"}
- description: Salted-dried and fermented fish produced in the Izu Islands
- countries: JP
- kinds: dried fish, fermented fish
- ingredients: Carangidae
- has Wikipedia article: en, zh

## DISH Q85850163
- name: Aboukir
- description: French layered dessert
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q85859991
- name: Brodetto all'anconetana
- other names: {"it": "Brodetto all'anconetana"}
- countries: (none)
- kinds: Brudet
- ingredients: fish

## DISH Q85861559
- name: Cullurelli
- other names: {"it": "Cullurelli"}
- countries: IT
- kinds: dessert

## DISH Q858627
- name: Pirog
- other names: {"zh": "皮羅格"}
- description: pastry of Russian/Eastern European origin with sweet or savory filling
- countries: RU
- kinds: dish, pie
- has Wikipedia article: en, zh

## DISH Q85862852
- name: Formaggini di Montevecchia
- other names: {"it": "Formaggini di Montevecchia"}
- countries: IT
- kinds: cheese

## DISH Q85869105
- name: たまコロ
- other names: {"ja": "たまコロ"}
- countries: (none)
- kinds: korokke

## DISH Q85869180
- name: Tsubojiru
- countries: (none)
- kinds: miso soup

## DISH Q85876025
- name: Bazo bread
- description: Mexican and Spanish traditional bread
- countries: ES, MX
- kinds: bread

## DISH Q85877207
- name: Romesco de peix
- other names: {"ca": "Romesco de peix"}
- countries: (none)
- kinds: dish

## DISH Q85878430
- name: 奉化水蜜桃
- countries: (none)
- kinds: peach
- has Wikipedia article: zh

## DISH Q85881727
- name: Mizu manjū
- countries: (none)
- kinds: manjū
- ingredients: kudzu powder

## DISH Q85882121
- name: 溪口千层饼
- countries: (none)
- kinds: snack
- has Wikipedia article: zh

## DISH Q85882288
- name: 牛乳パン
- other names: {"ja": "牛乳パン"}
- countries: (none)
- kinds: sweet bread

## DISH Q85882742
- name: 甜沫
- countries: (none)
- cuisines: Shandong cuisine
- kinds: dish, congee

## DISH Q85884749
- name: Tori chūka
- countries: (none)
- kinds: ramen, chicken dish

## DISH Q85884814
- name: Kuroishi Yakisoba
- countries: JP
- kinds: Yakisoba

## DISH Q859553
- name: Sundae
- other names: {"zh": "圣代"}
- description: ice cream dessert; consists of scoops of ice cream topped with sauce or syrup, and in some cases other toppings
- countries: US
- kinds: frozen dessert, Ice cream cup, type of food or dish
- ingredients: ice cream
- has Wikipedia article: en, zh

## DISH Q85967652
- name: Aillade sousu
- other names: {"az": "Aillade sousu"}
- countries: FR
- kinds: sauce

## DISH Q85971666
- name: LA Kalbi
- description: Korean beef dish
- countries: KR
- cuisines: Korean cuisine, Asian American cuisine
- kinds: dish, Galbi, beef dish
- ingredients: galbi

## DISH Q85972545
- name: Ganjang-chikin
- description: Korean fried chicken
- countries: (none)
- kinds: Korean fried chicken

## DISH Q85973066
- name: Meyhane pilavı
- description: Turkish bulgur dish
- countries: TR
- kinds: food, bulgur pilav
- ingredients: bulgur

## DISH Q85979768
- name: Bossam-kimchi
- description: Korean cuisine
- countries: KP
- cuisines: North Korean cuisine
- kinds: dish, Kimchi

## DISH Q85983197
- name: 竜鳳湯
- other names: {"ja": "竜鳳湯"}
- countries: (none)
- kinds: soup

## DISH Q85991120
- name: Hutsul sheep bryndzya
- description: sheep cheese typical of the Hutsul culinary tradition
- countries: (none)
- cuisines: Hutsul cuisine
- kinds: traditional food, cheese, Bryndza, sheep milk cheese, Hutsul bryndza
- has Wikipedia article: en

## DISH Q85992204
- name: Жууган піяз
- other names: {"uk": "Жууган піяз"}
- description: onion salad from Kyrgyzstan
- countries: KG
- kinds: Lactuca sativa
- ingredients: Allium, vinegar, table salt

## DISH Q85996689
- name: Moskva slices
- description: type of cake
- countries: RS
- cuisines: Serbian cuisine
- kinds: torte

## DISH Q859981
- name: Seswaa
- description: stewed meat dish of Botswana
- countries: BW
- kinds: meat dish, meal
- has Wikipedia article: en

## DISH Q85998157
- name: Prljo cheese
- countries: ME
- kinds: cheese

## DISH Q86004645
- name: Dhoda
- description: confection
- countries: (none)
- kinds: confectionery

## DISH Q86006763
- name: Don
- other names: {"vi": "don"}
- countries: VN
- cuisines: cuisine of Quảng Ngãi
- kinds: soup, seafood dish

## DISH Q860170
- name: Yin yang fried rice
- other names: {"zh": "鸳鸯炒饭"}
- description: Hong Kong rice dish
- countries: CN
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q86056865
- name: Palais royal
- other names: {"fr": "palais royal"}
- countries: FR
- kinds: pastry

## DISH Q86066688
- name: Repocheta
- description: Nicaraguan typical food
- countries: NI
- kinds: dish
- ingredients: corn tortilla, cabbage, bean, cheese

## DISH Q860808
- name: Chipotle
- other names: {"zh": "烟味辣椒"}
- description: smoke-dried jalapeño
- countries: MX
- kinds: dish, smoked food
- ingredients: jalapeño
- has Wikipedia article: en

## DISH Q860985
- name: Pork chop
- other names: {"zh": "猪排"}
- description: type of meat cut
- countries: (none)
- kinds: meat chop, pork, cuts of pork
- has Wikipedia article: en, zh

## DISH Q861189
- name: Chef salad
- other names: {"zh": "主厨沙拉"}
- description: U.S. salad consisting of hard-boiled eggs, one or more varieties of meat (e.g. ham, turkey, chicken, roast beef), tomatoes, cucumbers, and cheese, placed upon a bed of tossed lettuce or other leaf vegetables; a variety of dressings may be used
- countries: US
- kinds: salad
- ingredients: boiled egg, tomato, Cucumis sativus, cheese
- has Wikipedia article: en

## DISH Q861304
- name: Steak and kidney pie
- other names: {"zh": "牛排腰子派"}
- description: savory pie filled with diced beef, diced kidney, plus fried onion and brown gravy
- countries: GB
- kinds: food, meat pie, beef dish
- ingredients: fried onion, gravy, lamb meat, ox, beef, pork, kidney
- has Wikipedia article: en

## DISH Q86240778
- name: Bulgur pilav
- description: Turkish cuisine dish made with bulgur
- countries: (none)
- kinds: food, pilav
- ingredients: salça, cooking oil, bulgur

## DISH Q862557
- name: Osechi
- other names: {"zh": "御节料理"}
- description: assortment of food delicacies celebrating Japanese New Year
- countries: JP
- cuisines: Japanese cuisine
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q862595
- name: Sweet Potato Cupcake
- description: steamed sweet potato cupcakes from Indonesia
- countries: ID
- cuisines: Indonesian cuisine, jajan pasar
- kinds: kue, Kue mangkok, food, dish, human food, type of food or dish, jajan pasar
- ingredients: tapai singkong, wheat flour, rice flour, Sweet potato

## DISH Q862974
- name: Baekseolgi
- description: tteok (Korean rice cake) made of rice flour, sugar, and salt
- countries: (none)
- kinds: tteok
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q863626
- name: Fruit-filled dumplings
- countries: (none)
- kinds: dish

## DISH Q863794
- name: Chili
- other names: {"zh": "香辣肉酱"}
- description: American stew
- countries: MX
- cuisines: Tex-Mex, cuisine of the United States, Mexican cuisine
- kinds: stew, dish
- ingredients: minced meat, chili pepper
- has Wikipedia article: en, zh

## DISH Q863966
- name: Bourbon biscuit
- description: type of biscuit
- countries: (none)
- kinds: biscuit
- ingredients: dark chocolate
- has Wikipedia article: en

## DISH Q864154
- name: Geng
- other names: {"zh": "羹"}
- description: food
- countries: CN, TW
- kinds: food, soup
- has Wikipedia article: en, zh

## DISH Q865004
- name: Tajine
- other names: {"zh": "尖蓋鍋燴肉"}
- description: traditional Amazigh (Berber) stew named after the earthenware pot it was cooked in Maghreb
- countries: (none)
- kinds: stew, dish
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q865258
- name: Memil-buchimgae
- description: buckwheat pancake
- countries: (none)
- kinds: food, jeon
- ingredients: buckwheat seed
- has Wikipedia article: en

## DISH Q865773
- name: Chirashizushi
- other names: {"zh": "散壽司"}
- description: sushi consisting of a layer of vinegared rice with a variety of toppings (usually raw seafood) strewn on top
- countries: JP
- kinds: sushi
- ingredients: sumeshi
- has Wikipedia article: en, zh

## DISH Q865777
- name: Birnbrot
- description: yeasted bread with a filling made from dried fruit
- countries: CH
- cuisines: Swiss cuisine
- kinds: pastry
- ingredients: dried fruit
- has Wikipedia article: en

## DISH Q865790
- name: Poire belle Hélène
- other names: {"zh": "梨海琳"}
- description: dessert
- countries: FR
- kinds: dessert
- ingredients: pear, vanilla ice cream, syrup, chocolate syrup
- has Wikipedia article: en, zh

## DISH Q86605265
- name: Буженина
- other names: {"ru": "Буженина"}
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: food, dish
- ingredients: beef, pork

## DISH Q866153
- name: Frozen dessert
- other names: {"zh": "冰品"}
- description: dessert made by freezing
- countries: (none)
- kinds: dessert, frozen food
- has Wikipedia article: en, zh

## DISH Q86660144
- name: Sherbet
- description: Soviet dessert
- countries: (none)
- cuisines: Soviet cuisine
- kinds: dessert

## DISH Q86660323
- name: Choka
- description: Trinidadian dish
- countries: (none)
- kinds: dish

## DISH Q86661082
- name: Baleron
- description: smoked pork neck cut
- countries: PL
- kinds: smoked meat
- ingredients: pork
- has Wikipedia article: en

## DISH Q86661713
- name: Smetannik
- description: dish of Russian and Tatar cuisine
- countries: (none)
- kinds: pirog

## DISH Q866640
- name: Bisque
- other names: {"zh": "法式濃湯"}
- description: cream-based soup of French origin
- countries: FR
- cuisines: French cuisine
- kinds: fish soup, crab dish
- ingredients: white wine
- has Wikipedia article: en, zh

## DISH Q86664228
- name: Vincisgrassi alla maceratese
- description: first course from the province of Macerata based on egg pasta, meat sauce, béchamel and cheese
- countries: IT
- cuisines: cuisine of Marche
- kinds: dish

## DISH Q86664240
- name: Torta secca di Carpenedolo
- other names: {"it": "Torta secca di Carpenedolo"}
- countries: IT
- kinds: dessert

## DISH Q86664445
- name: Soupe à la valpellinoise
- other names: {"fr": "soupe à la valpellinoise"}
- countries: (none)
- kinds: soup
- ingredients: Fontina PDO, Savoy cabbage, butter, bread

## DISH Q86665833
- name: Pizza Rossini
- description: Specialties of Pesaro, Italy
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q86666132
- name: Torta di nocciole
- other names: {"it": "Torta di nocciole"}
- countries: IT
- kinds: dessert

## DISH Q86666208
- name: Юражная каша
- other names: {"ru": "Юражная каша"}
- countries: (none)
- kinds: dish

## DISH Q86670785
- name: Zuppa mitonata
- countries: (none)
- kinds: soup

## DISH Q866714
- name: Bistecca alla fiorentina
- description: Italian steak dish
- countries: IT
- kinds: beefsteak
- ingredients: meat
- has Wikipedia article: en

## DISH Q86672413
- name: Sospiro
- countries: IT
- kinds: dessert

## DISH Q86674159
- name: Torta 900
- description: historical cake designed in Ivrea, Italy
- countries: IT
- kinds: dessert, sponge cake
- has Wikipedia article: en

## DISH Q86674592
- name: Honey of Pojezierze Choszczeńskie
- countries: PL
- kinds: honey

## DISH Q86674950
- name: Dolce mattone
- other names: {"it": "Dolce mattone"}
- countries: IT
- kinds: dessert with spoon

## DISH Q86675115
- name: Chleb gwdowski
- other names: {"pl": "Chleb gwdowski"}
- countries: PL
- kinds: bread
- ingredients: dough

## DISH Q86675276
- name: Polenta e osei
- other names: {"it": "polenta e osei"}
- countries: IT
- kinds: confectionery, dessert

## DISH Q86683737
- name: Kwlikwli
- other names: {"fon": "kwlikwli"}
- countries: (none)
- kinds: dish

## DISH Q86685906
- name: Fjut
- countries: (none)
- cuisines: Category:Kuyavian cuisine
- kinds: food product, spread
- ingredients: sugar beet

## DISH Q86723752
- name: Khaan
- countries: (none)
- kinds: dish

## DISH Q86729367
- name: 発光路の強飯式
- other names: {"ja": "発光路の強飯式"}
- countries: (none)
- kinds: festival, matsuri, Gohan ritual
- ingredients: cooked rice

## DISH Q86732805
- name: Bolus
- description: brioche from Brussels, Belgium
- countries: BE
- kinds: sweet bread, viennoiserie
- ingredients: brown sugar, flour, butter, raisin, milk
- has Wikipedia article: en

## DISH Q86734341
- name: Miel vert
- other names: {"fr": "miel vert"}
- countries: FR
- kinds: honey

## DISH Q86735209
- name: ファンシー
- other names: {"ja": "ファンシー"}
- countries: JP
- kinds: cake
- ingredients: wheat flour, egg as food, cream, sugar

## DISH Q86736710
- name: Pão de Ló de Ovar
- description: traditional cake from Ovar, Portugal
- countries: PT
- cuisines: Portuguese cuisine
- kinds: food, cake
- ingredients: wheat flour, egg as food, sugar

## DISH Q86737140
- name: Oiwake Yōkan
- countries: (none)
- kinds: wagashi

## DISH Q86740452
- name: Anmochi zōni
- countries: (none)
- kinds: zōni

## DISH Q86740899
- name: Sanbuzhan
- other names: {"zh": "三不粘"}
- description: Chinese sweet dish of starch and eggs
- countries: CN
- cuisines: Chinese cuisine
- kinds: sweet dish
- ingredients: cooking oil, egg as food, starch

## DISH Q86744144
- name: Miyazu Curry Yakisoba
- description: local food in Miyazu, Kyoto, Japan
- countries: (none)
- kinds: Yakisoba

## DISH Q867610
- name: Dundee cake
- description: Scottish fruit cake
- countries: GB
- cuisines: British cuisine
- kinds: fruitcake
- ingredients: currant
- has Wikipedia article: en

## DISH Q868184
- name: Frìttuli
- description: traditional pork dish from Calabria, Italy
- countries: IT
- kinds: pork dish
- has Wikipedia article: en

## DISH Q86846384
- name: Schläscher Mohstriezel
- countries: (none)
- kinds: pastry

## DISH Q869080
- name: Pork shogayaki
- other names: {"zh": "姜汁烧肉"}
- description: Japanese dish of pork in a ginger soy sauce
- countries: JP
- kinds: pork dish
- ingredients: ginger, mirin, soy sauce, pork
- has Wikipedia article: en, zh

## DISH Q869086
- name: Hirayachi
- description: Okinawa-style pancake
- countries: JP
- kinds: pancake, okonomiyaki
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q869100
- name: Kiritanpo
- other names: {"zh": "烤米棒"}
- description: Japanese food
- countries: JP
- kinds: Japanese rice dish
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q869167
- name: Miyagegashi
- description: Japanese souvenir sweet
- countries: JP
- kinds: confectionery, miyage
- has Wikipedia article: en

## DISH Q869366
- name: Rotelle
- other names: {"zh": "車輪麵"}
- description: type of pasta
- countries: IT
- kinds: pasta
- ingredients: durum wheat semolina
- has Wikipedia article: en, zh

## DISH Q86948682
- name: Shahi jilapi
- description: Bangladeshi sweetmeat
- countries: (none)
- kinds: Jalebi
- has Wikipedia article: en

## DISH Q869617
- name: Garganelli
- description: tube-shaped sort of macaroni
- countries: IT
- kinds: pasta, type of pasta
- ingredients: flour
- has Wikipedia article: en

## DISH Q869660
- name: Scone
- other names: {"zh": "司康饼"}
- description: British quick bread
- countries: GB
- kinds: quick bread
- ingredients: wheat, raising agent, Avena sativa, Hordeum vulgare
- has Wikipedia article: en, zh

## DISH Q869700
- name: Swiss chocolate
- other names: {"zh": "瑞士巧克力"}
- description: chocolate produced in Switzerland
- countries: CH
- kinds: chocolate
- has Wikipedia article: en, zh

## DISH Q869714
- name: Campanelle
- description: type of pasta shaped like a bell or flower
- countries: IT
- kinds: pasta, type of pasta
- ingredients: wheat
- has Wikipedia article: en

## DISH Q869722
- name: Acini di pepe
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q870362
- name: Rice bread
- other names: {"zh": "米粉麵包"}
- description: food
- countries: ID
- kinds: food, bread, pastry, dish
- ingredients: rice flour
- has Wikipedia article: en, zh

## DISH Q8705390
- name: Buñuelo
- other names: {"zh": "油炸甜餅"}
- description: fried dough ball
- countries: ES
- cuisines: Latin American cuisine, Spanish cuisine
- kinds: fritter, confectionery, type of food or dish, doughnut
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q871272
- name: Fajita
- other names: {"zh": "墨西哥烤肉"}
- description: term found in Tex-Mex cuisine, commonly referring to any grilled meat usually served as a taco on a flour or corn tortilla
- countries: MX
- kinds: dish
- ingredients: wheat tortilla, meat, Capsicum annuum
- has Wikipedia article: en, zh

## DISH Q871311
- name: Baekseju
- other names: {"zh": "百岁酒"}
- description: Korean glutinous rice-based wine
- countries: (none)
- kinds: Medicinal liquor
- has Wikipedia article: en, zh

## DISH Q87131222
- name: Yukjeon
- countries: (none)
- kinds: jeon

## DISH Q871619
- name: Bear claw
- description: pastry with almond paste filling
- countries: US
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q872114
- name: Vanillerostbraten
- description: Austrian beef cutlet dish
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q872503
- name: Cucumber sandwich
- other names: {"zh": "黄瓜三明治"}
- description: traditionally composed of thin slices of cucumber placed between two thin slices of crustless, lightly buttered white bread
- countries: GB
- kinds: sandwich
- ingredients: cucumber, white bread
- has Wikipedia article: en, zh

## DISH Q872611
- name: Mohr im Hemd
- description: Austrian dessert
- countries: (none)
- kinds: pastry, dish
- has Wikipedia article: en

## DISH Q8727818
- name: Andesteg
- description: Danish roast duck
- countries: DK
- kinds: duck dish

## DISH Q872869
- name: Toruń gingerbread
- other names: {"zh": "托倫薑餅"}
- description: Polish gingerbread
- countries: PL
- kinds: biscuit, pryanik, Ginger Bread
- has Wikipedia article: en

## DISH Q872939
- name: Coffee jelly
- description: jelly dessert flavored with coffee and sugar
- countries: JP
- kinds: gelatin dessert
- ingredients: coffee
- has Wikipedia article: en

## DISH Q8729741
- name: Chocolate-covered banana
- other names: {"zh": "巧克力香蕉"}
- description: Japanese candy
- countries: (none)
- kinds: banana dish
- ingredients: banana, chocolate

## DISH Q87316441
- name: Moriguksu
- description: Korean noodle dish
- countries: KR
- kinds: noodle dish, Korean noodles

## DISH Q873336
- name: Shrimp toast
- other names: {"zh": "虾多士"}
- description: Chinese dim sum dish
- countries: (none)
- kinds: dim sum, shrimp dish
- ingredients: shrimp and prawn as food, pan loaf, bread
- has Wikipedia article: en, zh

## DISH Q87340113
- name: Figa albardada
- countries: (none)
- kinds: confectionery
- ingredients: buñuelo, fig

## DISH Q873699
- name: Gangjeong
- description: Korean confection
- countries: (none)
- kinds: hangwa
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q87408425
- name: Sójové řezy
- other names: {"cs": "Sójové řezy"}
- countries: (none)
- kinds: confectionery
- ingredients: soybean

## DISH Q874397
- name: Inarizushi
- other names: {"zh": "豆皮壽司"}
- description: Tofu pocket filled with rice
- countries: (none)
- kinds: sushi
- ingredients: sumeshi
- has Wikipedia article: en, zh

## DISH Q874626
- name: Snysk
- other names: {"da": "Snysk"}
- description: regional cuisine
- countries: (none)
- cuisines: Schleswig-Holstein cuisine
- kinds: dish

## DISH Q87482943
- name: Wafer cake
- countries: (none)
- kinds: confectionery
- ingredients: wafer cookie

## DISH Q875287
- name: Knieküchle
- description: deep fried dough pastry
- countries: AT, DE
- kinds: food, pastry, cruller
- has Wikipedia article: en

## DISH Q875363
- name: Wibele
- description: German sweet biscuit
- countries: DE
- kinds: biscuit
- ingredients: flour
- has Wikipedia article: en

## DISH Q87590
- name: Castella
- other names: {"zh": "卡斯提拉"}
- description: Japanese sponge cake
- countries: JP
- kinds: sponge cake, Nanbangashi
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q876150
- name: Kalkýš
- other names: {"cs": "kalkýš"}
- countries: (none)
- kinds: dish

## DISH Q87628536
- name: 石焼き鍋
- other names: {"ja": "石焼き鍋"}
- countries: JP
- kinds: dish
- ingredients: miso, seafood

## DISH Q876624
- name: Carbonara
- other names: {"zh": "培根蛋面"}
- description: pasta dish
- countries: IT, US
- cuisines: cuisine of the United States, Italian cuisine
- kinds: spaghetti, dish
- ingredients: spaghetti, table salt, peppercorn, pecorino, guanciale, egg as food
- has Wikipedia article: en, zh

## DISH Q876740
- name: Schlutzkrapfen
- description: type of stuffed pasta
- countries: (none)
- kinds: type of pasta, stuffed pasta
- ingredients: buckwheat seed
- has Wikipedia article: en

## DISH Q876781
- name: Vinschgauer
- description: South Tyrolean bread
- countries: IT
- kinds: bread

## DISH Q876814
- name: Fleckerl
- description: Austrian noodle type
- countries: (none)
- kinds: dish

## DISH Q876823
- name: Krautfleckerl
- countries: AT, CZ, HR
- cuisines: Austrian cuisine, Czech cuisine, Croatian cuisine
- kinds: dish
- ingredients: Fleckerl

## DISH Q87741042
- name: Seco de chabelo
- description: Peruvian dish
- countries: PE
- kinds: Seco, meal

## DISH Q877538
- name: Kifli
- other names: {"zh": "螺旋面包"}
- description: crescent-shaped bread roll, originating in Central Europe
- countries: AT
- kinds: bread roll
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q8776319
- name: Amanida catalana
- description: salad with cured meats tipical from Catalonia
- countries: (none)
- kinds: salad

## DISH Q87768625
- name: Deep-fried wonton
- countries: (none)
- kinds: dish, wonton, deep-fried food

## DISH Q87769626
- name: Rajogi
- other names: {"zh": "辣椒鸡"}
- description: Korean Chinese chicken dish
- countries: (none)
- kinds: chicken dish

## DISH Q87777671
- name: Shui jiao
- other names: {"zh": "水餃"}
- description: boiled jiaozi
- countries: (none)
- kinds: jiaozi
- has Wikipedia article: en, zh

## DISH Q877913
- name: Dango
- other names: {"zh": "团子"}
- description: Japanese rice flour dumpling
- countries: JP
- kinds: wagashi, dumpling, stuffed pasta
- ingredients: rice flour
- has Wikipedia article: en, zh

## DISH Q877957
- name: Shahe fen
- other names: {"zh": "沙河粉"}
- description: Chinese noodle
- countries: CN
- kinds: food, rice noodle
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q878318
- name: Hochzeitssuppe
- other names: {"zh": "結婚湯 (德國)"}
- description: food
- countries: DE
- kinds: dish, wedding soup
- ingredients: broth
- has Wikipedia article: en

## DISH Q87834609
- name: Shurumbo
- other names: {"es": "shurumbo"}
- countries: PE
- kinds: meal, soup

## DISH Q87840119
- name: Stuffat tal-fenek
- description: Rabbit stew, cuisine of Malta
- countries: MT
- kinds: dish
- has Wikipedia article: en

## DISH Q878624
- name: Congee
- other names: {"zh": "粥"}
- description: type of rice, millet or grain porridge or gruel popular in many Asian countries
- countries: (none)
- kinds: food, side dish, dessert, appetizer, rice dish
- ingredients: drinking water, rice
- has Wikipedia article: en, zh

## DISH Q878765
- name: Schnitzel Holstein
- description: German dish
- countries: DE
- kinds: veal dish
- ingredients: veal

## DISH Q879074
- name: Bitto PDO
- other names: {"zh": "Bitto DOP"}
- description: Italian PDO cheese
- countries: IT
- cuisines: cuisine of Valtellina
- kinds: cheese, cow's-milk cheese, Italian cheese
- ingredients: cow's milk

## DISH Q879133
- name: Spundekäs
- description: rhenish Hessian cheese specialty
- countries: DE
- cuisines: German cuisine
- kinds: dish, fresh cheese, German cheese
- ingredients: fresh cheese, quark
- has Wikipedia article: en

## DISH Q87919415
- name: Colache
- description: Sautéed zucchini with poblano pepper
- countries: MX
- kinds: dish

## DISH Q87920812
- name: Minguichi
- other names: {"es": "Minguichi"}
- countries: MX
- kinds: soup

## DISH Q87923314
- name: Obispo
- description: Pork sausage from Tenancingo (Mexico)
- countries: MX
- kinds: dish

## DISH Q87928460
- name: Khao phan phak
- description: Thai rice sheet wrap with vegetables
- countries: TH
- kinds: rice dish

## DISH Q87987417
- name: Stjerneskud
- description: seafood smørrebrød
- countries: DK
- kinds: smørrebrød, seafood dish

## DISH Q88006009
- name: Motichur Laddu
- countries: (none)
- kinds: confectionery, laddu
- ingredients: besan, ghee, sugar

## DISH Q880562
- name: Rostbrätel
- countries: DE
- kinds: pork dish
- has Wikipedia article: en

## DISH Q88079420
- name: Camotillo
- countries: PE
- kinds: meal, dessert
- ingredients: Sweet potato

## DISH Q88106294
- name: Cangrejo reventado
- other names: {"es": "cangrejo reventado"}
- countries: PE
- kinds: food
- ingredients: crab, chicken egg, Chondracanthus chamissoi

## DISH Q881582
- name: Nun's puffs
- description: dessert pastry
- countries: (none)
- kinds: dessert, buñuelo, meal
- ingredients: pastry cream
- has Wikipedia article: en

## DISH Q882576
- name: Brathering
- description: traditional German fish dish
- countries: DE
- kinds: fish dish, fried food
- ingredients: onion, bay leaf, vinegar, flour
- has Wikipedia article: en

## DISH Q882630
- name: Blauer Heinrich (Suppe)
- other names: {"de": "Blauer Heinrich (Suppe)"}
- countries: (none)
- kinds: dish

## DISH Q883002
- name: Mutzbraten
- description: spit-roasted pork specialty
- countries: DE
- cuisines: German cuisine
- kinds: pork dish
- ingredients: pork

## DISH Q883031
- name: Floating island
- description: French dessert consisting of a meringue floating on crème anglaise
- countries: FR
- kinds: dessert
- ingredients: crème anglaise, meringue
- has Wikipedia article: en

## DISH Q88359674
- name: Sfincione PAT
- other names: {"zh": "Sfincione PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good, type of pizza
- has Wikipedia article: en

## DISH Q883938
- name: Bleu des Causses
- other names: {"zh": "科斯蓝纹奶酪"}
- description: French cheese
- countries: FR
- kinds: French cheese, blue cheese, raw-milk cheese, cow's-milk cheese, industrial cheese, dairy cheese
- ingredients: cow's milk, Penicillium roqueforti
- has Wikipedia article: en

## DISH Q884055
- name: Els
- countries: DE
- kinds: bitters, regional product
- ingredients: Els La Vera

## DISH Q88462839
- name: Basque-style cheesecake
- other names: {"zh": "巴斯克起司蛋糕"}
- description: blackcrust cheesecake
- countries: ES
- cuisines: Basque cuisine
- kinds: sweet dish, food, cheesecake
- ingredients: cream cheese, egg as food, flour, cream, sugar
- has Wikipedia article: en, zh

## DISH Q884785
- name: Baking chocolate
- other names: {"zh": "烤巧克力"}
- description: type of dark chocolate as baking ingredient
- countries: (none)
- kinds: chocolate
- has Wikipedia article: en, zh

## DISH Q884787
- name: Wurstebrot
- other names: {"de": "Wurstebrot"}
- description: dish
- countries: (none)
- kinds: meat dish

## DISH Q885593
- name: Arenque
- other names: {"es": "Arenque"}
- description: fish dish
- countries: DE
- kinds: fish dish

## DISH Q886378
- name: Blunzengröstl
- other names: {"de": "Blunzengröstl"}
- description: potato dish
- countries: AT
- kinds: blood sausage, potato dish
- ingredients: blood sausage

## DISH Q886824
- name: Black soup
- other names: {"zh": "血湯"}
- description: ancient Spartan staple soup made of boiled pigs' legs, blood, salt and vinegar
- countries: GR
- kinds: pork blood soup
- ingredients: pork
- has Wikipedia article: en

## DISH Q886852
- name: Blutwurststrudel
- other names: {"de": "Blutwurststrudel"}
- countries: (none)
- kinds: meat dish

## DISH Q887700
- name: Thuringian sausage
- description: sausage from Germany
- countries: (none)
- kinds: Bratwurst, fresh sausage
- has Wikipedia article: en

## DISH Q888403
- name: Bobbes
- other names: {"de": "Bobbes"}
- countries: (none)
- kinds: viennoiserie

## DISH Q88851632
- name: Vety and atomi
- countries: FI
- kinds: lihapiirakka
- ingredients: lihapiirakka, ham, egg as food

## DISH Q888720
- name: Lefse
- other names: {"zh": "挪威薄餅"}
- description: Norwegian flatbread
- countries: NO
- kinds: flatbread, potato dish
- ingredients: dough, potato, milk
- has Wikipedia article: en

## DISH Q88962330
- name: Cream shrimp
- other names: {"zh": "富贵明虾"}
- countries: (none)
- kinds: shrimp dish

## DISH Q88979269
- name: करंजी
- other names: {"mr": "करंजी"}
- countries: (none)
- kinds: dessert
