# Review batch names-046

## DISH Q542335
- name: Pickled egg
- other names: {"zh": "醃蛋"}
- description: regional cuisine
- countries: GB, CN
- cuisines: British cuisine, Chinese cuisine
- kinds: egg dish
- ingredients: boiled egg, vinegar, egg
- has Wikipedia article: en

## DISH Q5427546
- name: Fa gao
- other names: {"zh": "發粿"}
- description: Chinese steamed cake
- countries: CN
- kinds: pastry, Thai desserts and snacks
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q542790
- name: Hujiao bing
- other names: {"zh": "胡椒餅"}
- description: Chinese baked bun
- countries: CN
- kinds: doughnut, snack, street food, dish
- has Wikipedia article: en, zh

## DISH Q5429635
- name: Fahsa
- description: Lamb dish
- countries: YE
- kinds: food, lamb dish
- ingredients: lamb meat, Trigonella foenum-graecum
- has Wikipedia article: en

## DISH Q54321806
- name: Puding Diraja
- description: Pudding served to Malay royal family
- countries: MY
- kinds: dessert
- has Wikipedia article: en

## DISH Q54321819
- name: Kebebe
- description: Traditional Malaysian food
- countries: MY
- kinds: salad
- has Wikipedia article: en

## DISH Q5434634
- name: Far far
- description: snack food of Indian origin
- countries: IN
- kinds: food, snack
- ingredients: potato starch
- has Wikipedia article: en

## DISH Q5435340
- name: Farinata
- other names: {"zh": "鹰嘴豆煎饼"}
- description: unleavened crêpe made from chickpea flour
- countries: FR, IT
- kinds: pancake
- ingredients: chickpea, besan, olive oil, water
- has Wikipedia article: en, zh

## DISH Q5435395
- name: Farl
- description: Scottish and Irish three-cornered flatbreads and cakes
- countries: (none)
- kinds: bread, food, flatbread
- has Wikipedia article: en

## DISH Q5436113
- name: Faroese puffin
- countries: (none)
- kinds: dish
- ingredients: Atlantic Puffin
- has Wikipedia article: en

## DISH Q54371695
- name: Kümmelsuppe
- other names: {"de": "Kümmelsuppe"}
- countries: (none)
- kinds: soup

## DISH Q54371849
- name: Chả trứng
- description: Vietnamese steamed omelette or egg meat loaf
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: food, chả, dish
- ingredients: pork, egg as food
- has Wikipedia article: en

## DISH Q5437245
- name: Fat rascal
- description: Traditional cake from Yorkshire
- countries: GB
- kinds: cake
- ingredients: currant
- has Wikipedia article: en

## DISH Q5437342
- name: Fatback
- other names: {"zh": "背部肥肉"}
- description: cut of meat from a domestic pig
- countries: (none)
- kinds: fat, dish, cuts of pork
- has Wikipedia article: en, zh

## DISH Q543805
- name: Reblochon
- other names: {"zh": "勒布洛雄奶酪"}
- description: soft washed-rind and smear-ripened French cheese made in the Alpine region of Savoy from raw cow's milk
- countries: FR
- kinds: raw-milk cheese, pressed uncooked cheese, French cheese, cow's-milk cheese, farmstead cheese, industrial cheese, dairy cheese
- ingredients: cow's milk, raw milk
- has Wikipedia article: en, zh

## DISH Q5438646
- name: Sipatti
- other names: {"fi": "Sipatti"}
- countries: (none)
- kinds: dish

## DISH Q5438829
- name: Mallorcan soup
- description: type of vegetable soup
- countries: (none)
- kinds: soup

## DISH Q54423330
- name: Fish sandwich
- other names: {"zh": "鱼堡"}
- description: a sandwich or burger made with fish
- countries: (none)
- kinds: burger
- has Wikipedia article: en

## DISH Q5444388
- name: Fermented fish
- description: fish cured by fermentation to reduce spoilage
- countries: (none)
- kinds: cured fish, fermented seafood
- ingredients: Puntius
- has Wikipedia article: en

## DISH Q5447680
- name: Fig roll
- other names: {"zh": "无花果卷"}
- description: snack food
- countries: EG
- kinds: recipe, food, pastry
- ingredients: Ficus
- has Wikipedia article: en

## DISH Q5447713
- name: Figgy duff
- other names: {"zh": "無花果袋裝布丁"}
- description: traditional bag pudding from the province of Newfoundland and Labrador, Canada
- countries: CA
- kinds: pudding
- ingredients: flour
- has Wikipedia article: en

## DISH Q5448419
- name: פיליו
- other names: {"he": "פיליו"}
- description: dessert of portuguese origin, also traditional in Brazil
- countries: PT
- kinds: type of food or dish, dessert, fritter
- ingredients: pumpkin, egg as food, flour, sugar
- has Wikipedia article: en

## DISH Q5448449
- name: Filindeu
- description: pasta from the Barbagia region of Sardinia
- countries: IT
- kinds: type of pasta, pasta
- has Wikipedia article: en

## DISH Q5448811
- name: Fillet of Beef Prince Albert
- description: foie gras wrapped in punded beef tenderloin wrapped in bacon
- countries: (none)
- kinds: food, beef dish
- has Wikipedia article: en

## DISH Q5449200
- name: Filone
- description: Italian bread
- countries: IT
- kinds: food, bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q5449208
- name: Filoz
- description: pancake
- countries: (none)
- kinds: pancake
- ingredients: Musa, jaggery
- has Wikipedia article: en

## DISH Q5450244
- name: Finger steak
- description: deep-fried steak strips
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q5450695
- name: Finnan haddie
- description: cold-smoked haddock, representative of a regional method of smoking with green wood and peat in north-east Scotland
- countries: GB
- cuisines: Scottish cuisine
- kinds: food, smoked haddock
- has Wikipedia article: en

## DISH Q5450828
- name: Finnish bread
- other names: {"zh": "燕麥麵包"}
- description: Bread of Finland
- countries: FI
- kinds: food, bread
- has Wikipedia article: en

## DISH Q545344
- name: Chipa guasu
- description: Paraguayan savory corn cake
- countries: (none)
- kinds: cake
- ingredients: maize
- has Wikipedia article: en

## DISH Q5454466
- name: Fish-shaped pastry
- countries: JP
- kinds: food, pastry
- ingredients: red bean paste
- has Wikipedia article: en

## DISH Q5454601
- name: Fish and brewis
- description: traditional Newfoundland meal consisting of cod and hard bread
- countries: (none)
- kinds: fish dish
- ingredients: cod
- has Wikipedia article: en

## DISH Q5454605
- name: Fish boil
- description: culinary tradition in areas of Wisconsin
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q5454607
- name: Fish chowder
- description: creamy soup containing fish
- countries: (none)
- kinds: fish soup, fish dish
- ingredients: fish
- has Wikipedia article: en

## DISH Q5454627
- name: Fish finger sandwich
- description: type of sandwich
- countries: (none)
- kinds: sandwich, fish dish
- ingredients: fish finger, bread
- has Wikipedia article: en

## DISH Q5454630
- name: Fish fry
- description: dish consisting of battered or breaded fried fish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q5454631
- name: Fish head casserole
- other names: {"zh": "砂锅鱼头"}
- description: Chinese cuisine
- countries: CN
- kinds: fish dish
- ingredients: fish head
- has Wikipedia article: en

## DISH Q5454639
- name: Fish head curry
- other names: {"zh": "咖喱鱼头"}
- description: Indonesian curry dish
- countries: SG
- kinds: fish curry
- has Wikipedia article: en, zh

## DISH Q5454652
- name: Fish moolie
- description: spicy fish and coconut dish
- countries: (none)
- kinds: fish dish, human food
- has Wikipedia article: en

## DISH Q5454668
- name: Fish soup
- other names: {"zh": "魚湯"}
- description: soup with fish
- countries: (none)
- kinds: soup, fish dish, dish by ingredient
- ingredients: shellfish, fish as food
- has Wikipedia article: en, zh

## DISH Q5454671
- name: Fish steak
- description: Type of meat cut
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q5454673
- name: Fish stew
- description: stew with a base or food ingredients of fish or seafood
- countries: (none)
- kinds: stew, fish dish
- has Wikipedia article: en

## DISH Q5454680
- name: Fish tea
- description: spicy soup in Caribbean cuisine, similar to a fish bouillon; includes ground yam, pumpkin, cassava, potatoes and green bananas, cooked until very soft
- countries: (none)
- kinds: fish soup, fish dish
- ingredients: yam
- has Wikipedia article: en

## DISH Q5457079
- name: Flake
- description: term used for shark flesh
- countries: AU
- cuisines: Australian cuisine
- kinds: human food
- ingredients: shark
- has Wikipedia article: en

## DISH Q5457441
- name: Flaons
- description: Cheesecake or stuffed pastry from Spanish and Catalan cuisines
- countries: (none)
- kinds: food, pastry
- ingredients: cheese
- has Wikipedia article: en

## DISH Q5457456
- name: Flapper pie
- description: dessert in Canadian cuisine
- countries: CA
- kinds: food, pie
- ingredients: graham cracker
- has Wikipedia article: en

## DISH Q545816
- name: Herbstmilchsuppe
- other names: {"de": "Herbstmilchsuppe"}
- countries: (none)
- cuisines: Bavarian cuisine
- kinds: soup, dish
- ingredients: curd

## DISH Q5458522
- name: Fleischkuekle
- description: Deep fried turnover with seasoned ground beef
- countries: RU
- kinds: meat pie
- has Wikipedia article: en

## DISH Q5459109
- name: Flies graveyard
- description: sweet pastries filled with currants or raisins
- countries: GB
- cuisines: British cuisine
- kinds: food, pastry
- ingredients: dough, Ribes nigrum, Ribes, raisin
- has Wikipedia article: en

## DISH Q5459704
- name: Flipper pie
- description: regional food dish in Canada
- countries: CA
- kinds: food, meat pie
- ingredients: Harp Seal
- has Wikipedia article: en

## DISH Q545985
- name: Fish sauce
- other names: {"zh": "魚露"}
- description: an amber-coloured liquid extracted from the fermentation of fish with sea salt
- countries: IN
- cuisines: Thai cuisine, Chinese cuisine
- kinds: sauce, fermented fish, fish dish
- ingredients: fish as food
- has Wikipedia article: en, zh

## DISH Q545994
- name: Brie de Melun
- other names: {"zh": "默倫布里"}
- description: unpasteurized brie manufactured in the town of Melun in the Brie region of northern France
- countries: FR
- kinds: white mold-rind cheese, raw-milk cheese, French cheese, farmstead cheese, industrial cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q546072
- name: Utopenec
- description: Czech food item
- countries: (none)
- kinds: dish

## DISH Q5462783
- name: Flummery
- description: dessert pudding
- countries: GB
- cuisines: British cuisine
- kinds: dessert with spoon
- ingredients: semolina, egg as food, sugar, white wine
- has Wikipedia article: en

## DISH Q5463599
- name: Flying saucer
- description: confectionery
- countries: BE
- kinds: confectionery
- ingredients: wafer paper, tartaric acid
- has Wikipedia article: en

## DISH Q5463730
- name: Fläskpannkaka
- description: pancake with pork made in the oven
- countries: SE
- kinds: pancake, pork dish
- ingredients: chicken egg, cow's milk, wheat flour, pork belly, table salt
- has Wikipedia article: en

## DISH Q5463808
- name: Foam cake
- other names: {"zh": "泡沫蛋糕"}
- description: cake primarily leavened by air that is beaten into egg whites
- countries: (none)
- kinds: cake
- ingredients: beaten egg whites, flour
- has Wikipedia article: en, zh

## DISH Q5464121
- name: Foglie d'ulivo
- description: type of pasta
- countries: IT
- kinds: type of pasta, pasta
- has Wikipedia article: en

## DISH Q5476380
- name: Sándwich de milanesa
- description: South American sandwich
- countries: (none)
- kinds: sandwich
- ingredients: Milanesa
- has Wikipedia article: en

## DISH Q5479342
- name: San Michali
- description: Greek cheese
- countries: GR
- kinds: cheese, cow's-milk cheese

## DISH Q5479643
- name: 波瓦葡式三明治
- description: food dish from Póvoa de Varzim, Portugal
- countries: PT
- kinds: food, sandwich
- ingredients: fiambre, linguiça, mustard, cheese, bread
- has Wikipedia article: en

## DISH Q5479684
- name: Polkagris
- description: white caramel bar with red colored spiral shape and mint taste attributed to Gränna in Sweden
- countries: SE
- kinds: stick candy, candy
- ingredients: sugar
- has Wikipedia article: en

## DISH Q5479702
- name: Nieve
- description: fruit flavored ice cream
- countries: MX
- kinds: meal, ice cream
- ingredients: fruit, water

## DISH Q5480841
- name: Morcipan
- countries: (none)
- kinds: bocadillo
- ingredients: blood sausage

## DISH Q548309
- name: Saint-Nectaire
- other names: {"zh": "圣内克泰尔"}
- description: a French AOC cheese made in the Auvergne region of central France.
- countries: FR
- kinds: raw-milk cheese, pressed uncooked cheese, cow's-milk cheese, farmstead cheese, industrial cheese, dairy cheese, pasteurized milk cheese, French cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q5484363
- name: Asado negro
- description: Venezuelan beef dish
- countries: VE
- kinds: beef dish
- ingredients: beef, red wine

## DISH Q5484859
- name: Chajá
- description: Uruguayan dessert
- countries: UY
- kinds: dessert
- ingredients: peach, sponge cake, meringue, cream, Uruguayan cuisine
- has Wikipedia article: en

## DISH Q54865035
- name: Rice soup
- description: soup made with rice as basic ingredient
- countries: (none)
- kinds: dish, soup
- ingredients: rice

## DISH Q5487418
- name: Kiusaus
- other names: {"fi": "Kiusaus"}
- countries: (none)
- kinds: dish

## DISH Q54875013
- name: Kibbeh mashwiyya
- description: Levantine dish, grilled kibbeh
- countries: SY
- cuisines: Arab cuisine, Syrian cuisine
- kinds: dish, meat dish, type of food or dish
- ingredients: meat

## DISH Q5488654
- name: Chocobanano
- description: frozen dessert made with a frozen banana covered with chocolate
- countries: (none)
- kinds: frozen dessert, banana dish, chocolate dish
- ingredients: frozen banana, chocolate

## DISH Q54888160
- name: Rundìtt
- countries: IT
- kinds: food, flatbread
- ingredients: flour, water

## DISH Q549081
- name: Jing jiang rou si
- other names: {"zh": "京酱肉丝"}
- description: Beijing dish of pork stir-fried with soya paste and served with leeks and doupi
- countries: (none)
- kinds: pork dish
- ingredients: onion, tianmianjiang, pork, tofu
- has Wikipedia article: en, zh

## DISH Q5491222
- name: Viche
- other names: {"es": "Viche"}
- countries: (none)
- kinds: dish

## DISH Q54952472
- name: Pizza puff
- description: deep-fried dough pocket filled with cheese, tomato sauce, and pizza toppings (sausage, pepperoni etc.), indigenous to Chicago
- countries: US
- kinds: dish
- has Wikipedia article: en

## DISH Q5495791
- name: Wijnbal
- other names: {"nl": "Wijnbal"}
- countries: (none)
- kinds: candy

## DISH Q54962774
- name: Campanian pasta
- description: pasta of Campania region, Italy
- countries: (none)
- kinds: pasta

## DISH Q5501442
- name: Frejon
- description: coconut bean soup
- countries: BR, NG, SL
- kinds: food, soup, dish
- ingredients: coconut, crayfish, Capsicum, tomato, table salt
- has Wikipedia article: en

## DISH Q550325
- name: Cahuamanta
- description: Mexican seafood dish
- countries: (none)
- kinds: seafood dish, shrimp dish
- has Wikipedia article: en

## DISH Q5503338
- name: Friand
- description: small almond cake
- countries: FR
- kinds: food, meat pastry
- ingredients: beurre noisette
- has Wikipedia article: en

## DISH Q5503409
- name: Fricot
- description: traditional Acadian dish
- countries: (none)
- kinds: dish, stew
- ingredients: meat
- has Wikipedia article: en

## DISH Q550354
- name: Ice milk
- description: Dish from the United States
- countries: (none)
- kinds: frozen dessert
- has Wikipedia article: en

## DISH Q5503603
- name: Fried-brain sandwich
- other names: {"zh": "油炸腦三明治"}
- description: sandwich of sliced calves' brains on sliced bread
- countries: US
- kinds: sandwich
- ingredients: pan loaf
- has Wikipedia article: en

## DISH Q5503615
- name: Fried bake
- description: Caribbean dish
- countries: GY
- kinds: dish
- has Wikipedia article: en

## DISH Q5503619
- name: Fried eggplant
- description: Turkish cuisine dish
- countries: (none)
- kinds: food, vegetable dish, fried food
- ingredients: eggplant
- has Wikipedia article: en

## DISH Q5503620
- name: Fried clams
- description: traditional New England seafood dish
- countries: US
- kinds: clam dish
- ingredients: Mya arenaria
- has Wikipedia article: en

## DISH Q5503623
- name: Fried mushrooms
- description: mushrooms which have been fried
- countries: (none)
- kinds: deep-fried food, mushroom dish
- ingredients: edible mushroom
- has Wikipedia article: en

## DISH Q5503624
- name: Fried dough
- other names: {"zh": "炸甜麵團"}
- description: North American fried dough pastry
- countries: CA, US
- kinds: fritter, pastries and scones
- ingredients: dough
- has Wikipedia article: en, zh

## DISH Q5503628
- name: Fried plantain
- description: cooked dish made from plantains
- countries: (none)
- kinds: dish, food, fruit
- ingredients: cooking banana, salt, plantain, vegetable oil
- has Wikipedia article: en

## DISH Q5503629
- name: Fried pie
- description: Type of dessert pie
- countries: US
- kinds: food, pie
- ingredients: fruit
- has Wikipedia article: en

## DISH Q5504554
- name: Frijoles charros
- description: Mexican pinto bean dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5504556
- name: Frijoles negros
- description: Latin American dish
- countries: (none)
- cuisines: Latin American cuisine
- kinds: meal, bean stew, bean dish
- ingredients: black turtle bean
- has Wikipedia article: en

## DISH Q5504736
- name: Frita
- description: Cuban hamburger
- countries: CU
- kinds: dish
- ingredients: onion, patty, Cuban bread, fries
- has Wikipedia article: en

## DISH Q5504742
- name: Fritaja
- other names: {"zh": "克羅埃西亞煎蛋"}
- description: Mediterranean Croatian and Slovenian dish
- countries: HR
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q550490
- name: Solyanka
- other names: {"zh": "雜拌湯"}
- description: soup
- countries: RU, BY, UA
- cuisines: Russian cuisine, cuisine of Berlin, Belarusian cuisine, Ukrainian cuisine, Soviet cuisine, cuisine of the German Democratic Republic
- kinds: soup, meat dish
- ingredients: caper, olive, Salzgurke, lemon, fish as food, broth, Olea europaea, Boletus edulis, meat, Citrus × limon, fish
- has Wikipedia article: en, zh

## DISH Q5505245
- name: Frogeye salad
- description: type of pasta salad, made with acini di pepe pasta, whipped topping, egg yolks, often with fruit (e.g. mandarin orange, pineapple), sometimes topped with marshmallows
- countries: US
- kinds: dessert salad, pasta dish
- ingredients: acini di pepe
- has Wikipedia article: en

## DISH Q550574
- name: Funeral potatoes
- description: potato dish
- countries: US
- kinds: hotdish, potato dish, potato casserole
- ingredients: hash brown
- has Wikipedia article: en

## DISH Q5506314
- name: Frozen banana
- description: banana dessert
- countries: (none)
- kinds: frozen dessert, banana dish
- ingredients: chocolate, banana
- has Wikipedia article: en

## DISH Q5506319
- name: Frozen noodles
- description: types of instantly prepared noodles that are sold frozen or chilled
- countries: (none)
- kinds: instant noodles
- has Wikipedia article: en

## DISH Q5506331
- name: Frozie cup
- description: Frozen dessert
- countries: AU
- kinds: dessert
- has Wikipedia article: en

## DISH Q5506367
- name: Fruit Gushers
- description: fruit snack candy with liquid filling made by General Mills under the Betty Crocker name
- countries: (none)
- kinds: food, tangible good, confectionery
- has Wikipedia article: en

## DISH Q5506393
- name: Fruit bun
- description: Sweet bread with fruit and spices
- countries: (none)
- kinds: food, sweet roll
- ingredients: fruit
- has Wikipedia article: en

## DISH Q5506400
- name: Fruit hat
- description: British steamed pudding made with a pastry of suet and flour, and filled with fruit
- countries: GB
- kinds: pudding
- ingredients: suet
- has Wikipedia article: en

## DISH Q5506414
- name: Fruit sours
- description: type of confectionery
- countries: (none)
- kinds: confectionery
- ingredients: gelatin
- has Wikipedia article: en

## DISH Q5507065
- name: Fudge Rounds
- description: Round snack cake made by Little Debbie
- countries: (none)
- kinds: snack cake
- has Wikipedia article: en

## DISH Q5507069
- name: Chocolate fudge cake
- description: chocolate cake containing fudge
- countries: (none)
- kinds: cake
- ingredients: chocolate cake
- has Wikipedia article: en

## DISH Q5508801
- name: Functional chewing gum
- description: Gum which serves a practical function
- countries: (none)
- kinds: chewing gum
- has Wikipedia article: en

## DISH Q5509196
- name: Funing big cake
- other names: {"zh": "阜宁大糕"}
- description: type of cake found in Funing County, China
- countries: CN
- kinds: cake
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q5509249
- name: Funkaso
- description: Hausa dish
- countries: NG
- kinds: food, pancake, human food
- ingredients: wheat, vegetable oil, wheat flour, millet, yeast, baking powder, table salt, sugar, honey
- has Wikipedia article: en

## DISH Q5509432
- name: Funšterc
- description: Slovenian national culinary dish
- countries: SI
- kinds: food, egg dish
- ingredients: flour
- has Wikipedia article: en

## DISH Q55144196
- name: Salsiccia gialla fina PAT
- other names: {"zh": "Salsiccia gialla fina PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- cuisines: cuisine of the province of Modena
- kinds: salume, fresh sausage, meat product, Italian sausage

## DISH Q551458
- name: Deviled egg
- other names: {"zh": "恶魔蛋"}
- description: egg-based dish
- countries: IT
- kinds: food, entrée
- ingredients: hard-boiled egg, stuffing
- has Wikipedia article: en, zh

## DISH Q551514
- name: Biancomangiare PAT
- other names: {"zh": "Biancomangiare PAT"}
- description: traditional Italian bakery product (PAT)
- countries: FR, IT
- kinds: budino, baked good
- ingredients: milk
- has Wikipedia article: en, zh

## DISH Q55152
- name: Religieuse
- other names: {"zh": "修女泡芙"}
- description: pastry
- countries: FR
- kinds: pastry
- ingredients: choux pastry
- has Wikipedia article: en, zh

## DISH Q55167
- name: Pineapple cake
- other names: {"zh": "鳳梨酥"}
- description: Taiwanese sweet traditional pastry
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: cake
- ingredients: pineapple jam
- has Wikipedia article: en, zh

## DISH Q5517015
- name: Gaifan
- other names: {"zh": "盖浇饭"}
- description: Chinese meals based on rice
- countries: CN
- cuisines: Chinese cuisine
- kinds: rice dish
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q5517536
- name: Gajak
- description: Indian sweet snack
- countries: IN
- kinds: brittle, mithai
- ingredients: sesame seed, jaggery
- has Wikipedia article: en

## DISH Q551774
- name: Agyasleves
- other names: {"fr": "agyasleves"}
- countries: (none)
- kinds: soup

## DISH Q55181446
- name: Amarene brusche di Modena
- other names: {"it": "amarene brusche di Modena"}
- countries: IT
- kinds: jam
- ingredients: sucrose, Amarena cherry, citric acid

## DISH Q55185326
- name: Cherry of Vignola
- countries: IT
- kinds: cherry, fruit
- ingredients: Mora di Vignola, Ferrovia cherries

## DISH Q5519122
- name: Gallo en chicha
- description: Central American chicken dish
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q5519964
- name: Game pie
- description: Savoury pie made with wild game
- countries: (none)
- kinds: food, meat pie
- ingredients: game
- has Wikipedia article: en

## DISH Q5521499
- name: Gansito
- description: Mexican dessert
- countries: MX
- kinds: snack cake
- has Wikipedia article: en

## DISH Q5521946
- name: Garash cake
- description: Bulgarian chocolate and walnut cake of 5 thin layers with a chocolate frosting
- countries: BG
- kinds: cake
- ingredients: walnut
- has Wikipedia article: en

## DISH Q5522421
- name: Garden salad
- description: type of salad that uses a base of leafy greens
- countries: (none)
- kinds: dish, salad
- ingredients: leaf vegetable
- has Wikipedia article: en

## DISH Q552287
- name: Linzertorte
- other names: {"zh": "林茲蛋糕"}
- description: Austrian pastry
- countries: AT
- kinds: cake, sweet pie
- ingredients: nut, lemon zest, egg yolk, flour, butter, cinnamon, jam
- has Wikipedia article: en, zh

## DISH Q55228866
- name: Pantesca salad
- description: typical dish of the island of Pantelleria
- countries: IT
- kinds: salad
- has Wikipedia article: en

## DISH Q552291
- name: Dacquoise
- other names: {"zh": "達克瓦茲蛋糕"}
- description: dessert cake with layers of almond and hazelnut meringue and whipped cream or buttercream
- countries: FR
- kinds: cake
- ingredients: meringue, almond, flour
- has Wikipedia article: en, zh

## DISH Q55231429
- name: Prosciutto di Bassiano
- description: Traditional ham of the Bassiano region
- countries: IT
- kinds: prosciutto
- ingredients: pork thigh

## DISH Q5523464
- name: Garlic fingers
- description: flatbread popular in Atlantic Canada
- countries: CA
- kinds: food, dish
- ingredients: garlic
- has Wikipedia article: en

## DISH Q5523466
- name: Garlic knot
- other names: {"zh": "大蒜麵包結"}
- description: type of garlic bread, originating from New York City, made from pizza dough scraps
- countries: US
- kinds: garlic bread, baked good
- ingredients: garlic
- has Wikipedia article: en, zh

## DISH Q55235305
- name: Storico ribelle
- other names: {"it": "Storico ribelle"}
- countries: IT
- cuisines: cuisine of Valtellina
- kinds: Italian cheese

## DISH Q5523588
- name: Garnacha
- description: Mesoamerican dish
- countries: (none)
- kinds: finger food, dish, recipe, type of food or dish
- ingredients: wheat tortilla, sauce, meat, potato, corn tortilla, onion
- has Wikipedia article: en

## DISH Q55238634
- name: Yam
- description: Thai salad
- countries: TH
- kinds: salad, dish

## DISH Q55238847
- name: Yam wun sen
- countries: (none)
- kinds: pasta salad, yam

## DISH Q5524478
- name: Garudiya
- description: Maldivian fish broth
- countries: MV
- kinds: food, tuna dish
- ingredients: Thunnini
- has Wikipedia article: en

## DISH Q552492
- name: Trdelník
- description: pastry
- countries: CZ
- cuisines: Hungarian cuisine, Slovak cuisine
- kinds: spit cake
- has Wikipedia article: en

## DISH Q5528400
- name: Gavvalu
- description: Indian foodstuff
- countries: IN
- kinds: dish
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q55285600
- name: Laoyou Rice Noodles
- other names: {"zh": "老友粉"}
- description: rice noodle dish originated from Nanning, Guangxi, China
- countries: (none)
- kinds: noodle dish
- has Wikipedia article: en, zh

## DISH Q5529194
- name: Gazpachuelo
- description: soup originating in Málaga, Spain
- countries: ES
- cuisines: Andalusian cuisine
- kinds: food, soup
- ingredients: garlic, fish stock, egg yolk, mayonnaise, olive oil
- has Wikipedia article: en

## DISH Q5529895
- name: Geera pork
- description: Pork stew popular in Trinidad and Tobago
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q55316189
- name: Crab cake sandwich
- description: type of sandwich
- countries: (none)
- kinds: sandwich
- has Wikipedia article: en

## DISH Q55316195
- name: Coddie
- description: deep fried snack food
- countries: (none)
- kinds: fishcake
- has Wikipedia article: en

## DISH Q553200
- name: Guōbāoròu
- other names: {"zh": "锅包肉"}
- description: sweet and sour pork dish of Northeast China
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en, zh

## DISH Q553905
- name: Wonton
- other names: {"zh": "馄饨"}
- description: type of dumpling commonly found in a number of Chinese cuisines
- countries: CN
- kinds: dumpling, stuffed pasta, food, type of pasta
- ingredients: dough
- has Wikipedia article: en, zh

## DISH Q554
- name: Cervelle de canut
- description: French cheese spread; specialty of Lyon
- countries: FR
- cuisines: French cuisine
- kinds: spread, appetizer, cheese spread
- ingredients: garlic, fromage frais, Allium ascalonicum, olive oil, vinegar
- has Wikipedia article: en

## DISH Q5541316
- name: Lardo di Colonnata PGI
- other names: {"zh": "Lardo di Colonnata IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: lardo, meat product

## DISH Q55503744
- name: Schlaatemer Rickli
- description: Swiss deep fried dough
- countries: CH
- kinds: deep-fried food

## DISH Q5550390
- name: Gerber sandwich
- description: open-faced sandwich with ham and cheese
- countries: US
- kinds: open sandwich
- ingredients: Provel cheese, ham, bread
- has Wikipedia article: en

## DISH Q555084
- name: Quince cheese
- description: fruit preserve made from quince pulp
- countries: ES, IT, PT
- cuisines: European cuisine, Latin American cuisine
- kinds: fruit preparation, food paste, marmelade
- ingredients: quince pulp, sugar
- has Wikipedia article: en

## DISH Q5551505
- name: Patay
- description: Cake made of white carob flour
- countries: AR
- kinds: cake
- has Wikipedia article: en

## DISH Q55521678
- name: Konoshiro-zushi
- description: sushi made with konoshiro (Konosirus punctatus)
- countries: (none)
- kinds: sushi
- ingredients: Konosirus punctatus

## DISH Q55521772
- name: きみごろも
- other names: {"ja": "きみごろも"}
- countries: (none)
- kinds: Miyagegashi

## DISH Q55522966
- name: Sawamochi
- countries: (none)
- kinds: mochi

## DISH Q55529085
- name: Mame shitogi
- countries: (none)
- kinds: confectionery
- ingredients: rice flour, bean, sugar

## DISH Q55529584
- name: ちりとり鍋
- other names: {"ja": "ちりとり鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q55539990
- name: 山の神まんじゅう
- other names: {"ja": "山の神まんじゅう"}
- countries: (none)
- kinds: manjū

## DISH Q5555446
- name: Chocolate de tablilla
- other names: {"es": "Chocolate de tablilla"}
- countries: MX
- kinds: dessert

## DISH Q55556985
- name: Braunschweiger Honigkuchen
- other names: {"de": "Braunschweiger Honigkuchen"}
- countries: (none)
- kinds: dish

## DISH Q5555725
- name: Ghari
- description: sweet dish from Gujarati cuisine, from Surat, India
- countries: (none)
- kinds: dish
- ingredients: ghee
- has Wikipedia article: en

## DISH Q5556168
- name: Gheimeh
- description: Iranian stew
- countries: (none)
- kinds: cuisine, stew, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q5556301
- name: Caracoles a la palentina
- other names: {"es": "Caracoles a la palentina"}
- countries: ES
- cuisines: cuisine of the province of Palencia
- kinds: food
- ingredients: snail as food, chili pepper, tomato, onion, chorizo

## DISH Q5556748
- name: Ragda patties
- description: Indian snack
- countries: IN
- kinds: chaat, snack
- ingredients: Lathyrus aphaca
- has Wikipedia article: en

## DISH Q5559227
- name: Gibraltar rock
- description: type of candy
- countries: US
- kinds: candy
- ingredients: sugar
- has Wikipedia article: en

## DISH Q55593280
- name: Nasi minyak
- description: traditional food from Jambi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: main course, rice dish, food, dish, traditional food
- ingredients: rice
- has Wikipedia article: en

## DISH Q55595875
- name: Broye
- other names: {"fr": "broye"}
- countries: FR
- kinds: dish

## DISH Q55596558
- name: Croquignole d'Uzès
- other names: {"fr": "Croquignole d'Uzès"}
- description: French pastry
- countries: FR
- kinds: pastry

## DISH Q55599165
- name: Poularde demi-deuil
- description: French dish
- countries: FR
- kinds: culinary speciality, poultry dish
- ingredients: truffle, poularde

## DISH Q55599828
- name: Saucisson brioché
- countries: (none)
- kinds: meat pastry
- ingredients: Saucisson de Lyon, brioche

## DISH Q55600023
- name: Toupi d'Ardèche
- other names: {"fr": "toupi d'Ardèche"}
- countries: FR
- kinds: dish

## DISH Q55600185
- name: Volailles de Janzé
- description: poultry from the region of Ille-et-Vilaine and neighboring cantons
- countries: FR
- kinds: poultry, human food

## DISH Q5560177
- name: Gigandes plaki
- description: Gian beans Greek dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q55605002
- name: Bataw
- description: leavened flatbread from Egypt
- countries: EG
- kinds: food
- has Wikipedia article: en

## DISH Q556052
- name: Teacake
- description: dessert item served with tea
- countries: GB
- kinds: food, sweet roll
- ingredients: dried fruit
- has Wikipedia article: en

## DISH Q55610619
- name: Eish fino
- description: baguette-shaped bread roll from Egypt made with wheat flour
- countries: EG
- kinds: bread roll
- has Wikipedia article: en

## DISH Q55612847
- name: Goujon
- description: French fried food
- countries: FR
- kinds: fish as food, human food
- has Wikipedia article: en

## DISH Q55615660
- name: Dokchok
- description: Thai flower cookie
- countries: TH
- kinds: cookie
- has Wikipedia article: en

## DISH Q55615912
- name: Kharvas
- description: Indian milk pudding
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q55623155
- name: Milk roll
- description: Type of enriched bread
- countries: (none)
- kinds: bread
- ingredients: wheat, milk
- has Wikipedia article: en

## DISH Q55629186
- name: Pasta all'Ortolana
- description: mixed vegetable pasta
- countries: IT
- kinds: pasta, dish

## DISH Q55629806
- name: Phat kaphrao
- other names: {"zh": "打抛猪肉饭"}
- description: Thai food
- countries: TH
- kinds: stir frying, dish
- ingredients: seafood, meat, Holy Basil
- has Wikipedia article: en, zh

## DISH Q55630493
- name: Prinjolata
- description: traditional dessert from Malta
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q5563074
- name: Ginger beef
- other names: {"zh": "姜汁牛肉"}
- description: canadian-Chinese dish
- countries: CA
- kinds: dish, beef dish
- ingredients: beef
- has Wikipedia article: en, zh

## DISH Q55632427
- name: Sambal shrimp
- description: Indonesian spicy dish made of shrimp
- countries: ID
- cuisines: Indonesian cuisine
- kinds: Sambal goreng, dish, human food, type of food or dish
- ingredients: garlic, ginger, onion, shrimp, Aleurites moluccanus, shrimp paste, chili pepper, Curcuma longa
- has Wikipedia article: en

## DISH Q55633641
- name: Soğan kebabı
- description: Turkish cuisine
- countries: TR
- kinds: dish
- has Wikipedia article: en

## DISH Q5563374
- name: Gionbō
- description: Japanese confectionery
- countries: JP
- kinds: wagashi
- ingredients: gyūhi
- has Wikipedia article: en

## DISH Q55638285
- name: Çökertme
- description: Turkish meat dish
- countries: TR
- cuisines: Turkish cuisine
- kinds: kebab, dish, food
- has Wikipedia article: en

## DISH Q55639922
- name: Huamo
- description: Decorated bun
- countries: CN
- kinds: food
- has Wikipedia article: en

## DISH Q55641393
- name: Pasta alla gricia
- description: pasta dish of Roman origins
- countries: IT
- kinds: first course, pasta dish
- ingredients: Pecorino Romano PDO, guanciale, pasta
- has Wikipedia article: en

## DISH Q55642975
- name: Daetong-bap
- description: rice in bamboo tube
- countries: (none)
- kinds: rice in bamboo
- has Wikipedia article: en

## DISH Q55648415
- name: Mumbar dolması
- description: Anatolian sausage
- countries: AM, TR
- kinds: sausage
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q55650512
- name: Kutach
- description: ancient Babylonian food
- countries: (none)
- kinds: food
- ingredients: milk, bread
- has Wikipedia article: en

## DISH Q55663678
- name: Kоłасzki
- description: Polish Christmas cookies
- countries: PL
- kinds: cookie

## DISH Q55673035
- name: Tava
- countries: AM
- kinds: dish
- ingredients: tomato, onion, lamb meat, zucchini

## DISH Q55693926
- name: Bloke kavla
- description: dish from southwestern Slovenia
- countries: SI
- kinds: dish, Slovenian cuisine

## DISH Q55697716
- name: 臺式漢餅
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: pastry
- has Wikipedia article: zh

## DISH Q55698065
- name: Tianshui noodles
- other names: {"zh": "甜水面"}
- description: Sichuan dish of thick noodles in a sauce of sweet soy sauce and chillis
- countries: CN
- kinds: noodle dish
- has Wikipedia article: zh

## DISH Q55700473
- name: Manqal salatı
- description: Azerbaijani salad
- countries: AZ
- kinds: salad

## DISH Q55700816
- name: Sheki halva
- description: Azerbaijan dessert
- countries: AZ
- cuisines: Azerbaijani cuisine
- kinds: dessert
- ingredients: cardamom, white sugar, hazelnut
- has Wikipedia article: en

## DISH Q55706051
- name: Zilviyə
- other names: {"az": "Zilviyə"}
- countries: (none)
- kinds: pastry

## DISH Q55706554
- name: Feşmək
- other names: {"az": "Feşmək"}
- countries: AZ
- kinds: pastry

## DISH Q55706649
- name: Şaftalı povidlosu
- other names: {"az": "Şaftalı povidlosu"}
- countries: (none)
- kinds: powidl

## DISH Q55708792
- name: Tmmyan
- other names: {"zh": "得麼面"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: Category:Taiwanese aboriginal culture and history, Atayal culture, dish
- has Wikipedia article: zh

## DISH Q55712540
- name: Lohkäse
- other names: {"de": "Lohkäse"}
- description: Fuel made from plant fibers; dish in parts of Germany
- countries: (none)
- kinds: fuel, dish
- ingredients: tanbark, pomace

## DISH Q5571519
- name: Glorified rice
- description: dessert from the American Midwest
- countries: US
- kinds: dessert salad
- ingredients: pineapple, whipped cream, rice
- has Wikipedia article: en

## DISH Q55715337
- name: Colline Pontine PDO
- other names: {"zh": "Colline Pontine DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: food, condiment, olive oil
- ingredients: olive oil

## DISH Q5571808
- name: Ragù
- other names: {"zh": "牛肉絲意粉"}
- description: meat-based sauce in Italian cuisine
- countries: FR, IT
- kinds: sugo, tomato dish, dish
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q55718484
- name: Baked rice
- other names: {"zh": "焗飯"}
- description: set index article
- countries: (none)
- kinds: rice dish
- has Wikipedia article: en

## DISH Q55725140
- name: Doro wat
- description: chicken wat
- countries: ER, ET
- kinds: Wat (food)
- ingredients: tomato, chicken egg, onion, niter kibbeh, chicken as food, berbere
- has Wikipedia article: en

## DISH Q5572731
- name: Ochío
- description: De Úbeda, Jaén
- countries: ES
- kinds: Úbeda, bread
- ingredients: paprika, olive oil, Pimpinella anisum, table salt, bread

## DISH Q55728796
- name: Noti
- countries: (none)
- kinds: tteok

## DISH Q55730267
- name: Paensae
- description: North Korean holiday dish
- countries: KP
- cuisines: North Korean cuisine
- kinds: holiday dish
- has Wikipedia article: en

## DISH Q55732697
- name: Yusanseul
- other names: {"zh": "溜三丝"}
- description: Korean Chinese dish
- countries: KR
- cuisines: Korean Chinese cuisine
- kinds: dish

## DISH Q55733775
- name: Malgeun jangguk
- description: Korean soup
- countries: (none)
- kinds: guk

## DISH Q55734701
- name: ᅟinstant jajangmyeon
- description: instant-noodle form of jajangmyeon
- countries: KR
- kinds: jajangmyeon, ramyeon

## DISH Q55735280
- name: Kongnamul gukbap
- description: Korean soup
- countries: KR
- kinds: soup
- ingredients: soybean sprout

## DISH Q55736051
- name: 혼돈 (음식)
- other names: {"ko": "혼돈 (음식)"}
- countries: (none)
- cuisines: North Korean cuisine
- kinds: dish

## DISH Q55736247
- name: 황태국
- other names: {"ko": "황태국"}
- countries: (none)
- kinds: guk

## DISH Q55736560
- name: Gaetteok
- description: cake made from various flours
- countries: KR
- kinds: dish

## DISH Q55737036
- name: Mukeunji
- countries: (none)
- kinds: Kimchi

## DISH Q55737195
- name: Bugeotguk
- description: Korean dried-fish soup
- countries: (none)
- kinds: guk, Korean cuisine
- ingredients: Theragra chalcogramma

## DISH Q55737768
- name: Jang-jorim
- other names: {"zh": "韩式酱牛肉"}
- description: Korean dish made of beef and soy sauce
- countries: KR
- kinds: jorim
- ingredients: soy sauce, beef
- has Wikipedia article: en

## DISH Q55739193
- name: Liquirizia di Calabria PDO
- other names: {"zh": "Liquirizia di Calabria DOP"}
- description: Italian PDO agricultural product
- countries: IT
- kinds: food, confectionery, agricultural product
- ingredients: liquorice, licorice candy

## DISH Q5574228
- name: Gnetum africanum
- other names: {"zh": "非洲买麻藤"}
- description: species of plant
- countries: (none)
- kinds: taxon, dish
- has Wikipedia article: en

## DISH Q5574984
- name: Medallones de Valjunquera
- other names: {"es": "Medallones de Valjunquera"}
- countries: ES
- kinds: dessert

## DISH Q557521
- name: Beer soup
- description: soup made with beer
- countries: (none)
- kinds: soup
- ingredients: roux, beer
- has Wikipedia article: en

## DISH Q5575346
- name: Goat roti
- description: traditional East-Indian food
- countries: (none)
- kinds: food, goat meat dish
- ingredients: goat
- has Wikipedia article: en

## DISH Q5575466
- name: Gobhi paratha
- description: Indian cauliflower flatbread
- countries: IN
- kinds: paratha, flatbread, dish
- has Wikipedia article: en

## DISH Q5575473
- name: Gobi manchurian
- other names: {"zh": "印式满洲菜"}
- description: deep fried cauliflower dish in Indo-Chinese cuisine
- countries: (none)
- kinds: human food, dish
- ingredients: cauliflower
- has Wikipedia article: en, zh

## DISH Q5578571
- name: Gold
- description: caramel covered biscuit bar snack food
- countries: (none)
- kinds: biscuit
- has Wikipedia article: en

## DISH Q55788394
- name: Schinkenbegräbnis
- countries: DE
- kinds: potato casserole
- ingredients: potato, ham

## DISH Q55788413
- name: Blutgemüse
- other names: {"de": "Blutgemüse"}
- countries: (none)
- kinds: dish

## DISH Q557968
- name: Anmitsu
- other names: {"zh": "豆沙水果涼粉"}
- description: mitsumame with red bean paste
- countries: JP
- kinds: mitsumame
- has Wikipedia article: en

## DISH Q55806825
- name: Pumpernickelsuppe
- countries: (none)
- kinds: dish

## DISH Q5581121
- name: Gombe
- description: traditional Norwegian dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q558133
- name: Wedding cake
- other names: {"zh": "结婚蛋糕"}
- description: cake for a wedding
- countries: (none)
- kinds: cake
- has Wikipedia article: en, zh

## DISH Q5581802
- name: Gongura
- description: edible form of the roselle plant
- countries: IN
- kinds: leaf vegetable
- has Wikipedia article: en

## DISH Q55831424
- name: Aranzada
- other names: {"it": "Aranzada"}
- countries: IT
- kinds: dessert

## DISH Q55831465
- name: U' pastizz rtunnar PAT
- other names: {"zh": "U' pastizz rtunnar PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- cuisines: cuisine of Basilicata
- kinds: meat dish, calzone, baked good
- has Wikipedia article: en

## DISH Q55832040
- name: Spaghetti alla siracusana
- description: pasta dish
- countries: IT
- cuisines: Syracusan cuisine
- kinds: food, pasta dish
- has Wikipedia article: en

## DISH Q55832172
- name: Cotoletta alla valdostana
- other names: {"it": "Cotoletta alla valdostana"}
- countries: (none)
- kinds: Cotoletta

## DISH Q55832414
- name: Africanetti
- other names: {"it": "Africanetti"}
- countries: IT
- kinds: dessert

## DISH Q55832714
- name: Timballo alla teramana
- other names: {"it": "timballo alla teramana"}
- countries: IT
- kinds: dish, timballo

## DISH Q55832716
- name: Scrippelle 'mbusse
- other names: {"it": "scrippelle 'mbusse"}
- countries: IT
- kinds: dish
- ingredients: broth

## DISH Q55833199
- name: Prosciutto amatriciano
- other names: {"it": "Prosciutto amatriciano"}
- countries: IT
- kinds: prosciutto

## DISH Q55833430
- name: Cozza tarantina PAT
- other names: {"zh": "Cozza tarantina PAT"}
- description: traditional Italian fish, mollusc or crustacean product (PAT)
- countries: IT
- kinds: mussel, seafood

## DISH Q5584732
- name: Gordita
- description: mexican meal
- countries: MX
- kinds: dish, food
- ingredients: corn tortilla, chicharrón, salsa (food)
- has Wikipedia article: en

## DISH Q558625
- name: Egg salad
- other names: {"zh": "鸡蛋沙拉"}
- description: hard-boiled eggs chopped and mixed with other ingredients
- countries: (none)
- kinds: salad, dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q55862687
- name: Mun tahu
- description: Chinese-Indonesian dish
- countries: ID
- kinds: soup
- ingredients: scallion, tofu
- has Wikipedia article: en

## DISH Q55862748
- name: Rujak juhi
- description: Variation of Indonesian indigenous food made from vegetables, fresh and pickled
- countries: ID
- kinds: salad, dish, human food
- ingredients: dried squid, potato, cabbage, cucumber, noodle, Lactuca sativa

## DISH Q5589145
- name: Government cheese
- description: commodity cheese controlled by the government of the United States
- countries: US
- kinds: cheese
- has Wikipedia article: en

## DISH Q5593383
- name: Graham cracker
- other names: {"zh": "全麥餅乾"}
- description: cracker confectionery usually sweetened with honey
- countries: US
- kinds: food, cracker
- ingredients: Graham flour
- has Wikipedia article: en

## DISH Q5593384
- name: Graham cracker crust
- other names: {"zh": "格雷厄姆餅乾脆皮"}
- description: pie crust made of ground graham crackers
- countries: (none)
- kinds: food, pie crust
- ingredients: graham cracker
- has Wikipedia article: en

## DISH Q559408
- name: Yōkan
- other names: {"zh": "羊羹"}
- description: Japanese dessert
- countries: JP
- kinds: wagashi, saogashi
- ingredients: agar
- has Wikipedia article: en, zh

## DISH Q559528
- name: Bacon, egg and cheese sandwich
- other names: {"zh": "培根鸡蛋奶酪三明治"}
- description: popular breakfast sandwich in the United States
- countries: (none)
- kinds: breakfast sandwich
- ingredients: egg as food, bacon, cheese, bread, chicken egg
- has Wikipedia article: en

## DISH Q5596598
- name: Grant loaf
- description: British wholemeal bread invented in World War II
- countries: (none)
- has Wikipedia article: en

## DISH Q5597000
- name: Grape pie
- description: fruit pie made from Concord grapes
- countries: US
- kinds: food, pie
- ingredients: Concord
- has Wikipedia article: en

## DISH Q55973978
- name: Kartoffelpaunzen
- other names: {"de": "Kartoffelpaunzen"}
- description: speciality from Tyrol
- countries: (none)
- kinds: dish

## DISH Q55987602
- name: Onjeschwedde
- description: raisin bread in Rhenish cuisine
- countries: DE
- kinds: raisin bread

## DISH Q5602039
- name: Greek pizza
- description: style of pizza baked in a shallow, heavily oiled pan
- countries: US
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q56023319
- name: Coburg Schmätzchen
- description: type of German gingerbread from the city of Coburg
- countries: (none)
- kinds: gingerbread

## DISH Q5602822
- name: Lauzinaj
- description: Almond confection
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q56040625
- name: Švilpikai (valgis)
- other names: {"lt": "Švilpikai (valgis)"}
- description: dish from Lithuanian cuisine
- countries: LT
- kinds: dish

## DISH Q5604093
- name: شیرینی روحافزا
- other names: {"fa": "شیرینی روحافزا"}
- countries: (none)
- kinds: pastry

## DISH Q56043447
- name: Fruit pie
- description: baked dish made of a pastry dough casing with a filling of fruit ingredients
- countries: (none)
- kinds: pie, fruit dish
- has Wikipedia article: en

## DISH Q5608621
- name: Griddle scone
- description: scone made with a griddle or frying pan
- countries: (none)
- kinds: food, scone
- has Wikipedia article: en

## DISH Q56087345
- name: Troach drop
- description: boiled sweet, favoured with aniseed, once popular in the English Midlands
- countries: (none)
- kinds: hard candy

## DISH Q5609167
- name: Grilled pizza
- countries: (none)
- has Wikipedia article: en

## DISH Q56097183
- name: Spaccata
- countries: (none)
- kinds: bread

## DISH Q5610120
- name: Grogue
- other names: {"zh": "格羅格酒 (維德角)"}
- description: Cape Verdean alcoholic beverage
- countries: CV
- kinds: liquor
- has Wikipedia article: en, zh

## DISH Q56115084
- name: Bramloše
- countries: (none)
- kinds: deep-fried food, potato-dough dumpling

## DISH Q5613295
- name: Guagua de pan
- description: bread of Andean origin
- countries: BO, EC, PE
- kinds: sweet bread, food, sweet roll
- ingredients: wheat
- has Wikipedia article: en

## DISH Q5613356
- name: Guajolota
- description: Form of street food made with a tamal
- countries: MX
- kinds: sandwich, food
- ingredients: bolillo
- has Wikipedia article: en

## DISH Q5615325
- name: Gui
- description: grilled dishes in Korean cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5617222
- name: Gulai ayam
- description: traditional Indonesian curry-like dish originating from Sumatra island
- countries: ID
- kinds: chicken curry
- ingredients: shallot, turmeric rhizome, caraway seeds, coriander seed, gulai, Aleurites moluccanus, chicken as food, coconut milk, chili pepper, nutmeg, Allium sativum
- has Wikipedia article: en

## DISH Q5618109
- name: Gumdrop
- description: type of candy
- countries: (none)
- kinds: candy
- ingredients: gelatin
- has Wikipedia article: en

## DISH Q5618566
- name: Gundain
- description: Tibetan pastry
- countries: (none)
- kinds: food, pastry
- ingredients: barley
- has Wikipedia article: en

## DISH Q5622888
- name: Guyuria
- description: traditional Chamorro cookies
- countries: GU
- kinds: cookie
- ingredients: coconut milk, flour, sugar
- has Wikipedia article: en

## DISH Q56231357
- name: Ambokueh
- other names: {"id": "ambokueh"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fritter, dish, human food, type of food or dish
- ingredients: rice flour, tofu, sausage, egg as food

## DISH Q56231359
- name: Angeun lada
- description: buffalo meat soup from Banten, Indonesia
- countries: (none)
- kinds: dish

## DISH Q56231368
- name: Asinan Betawi
- countries: (none)
- kinds: asinan
- ingredients: Napa cabbage, Lactuca sativa, peanut

## DISH Q56231369
- name: Asinan Bogor
- countries: ID
- cuisines: Indonesian cuisine
- kinds: asinan, dish, human food, type of food or dish
- ingredients: Syzygium polycephalum, cabbage, Napa cabbage, mung bean sprout, turnip, peanut, cucumber, Salacca zalacca, Pachyrhizus erosus, Spondias dulcis, chili pepper, Allium schoenoprasum, Sweet potato, Carica papaya, Syzygium aqueum, mango, carrot

## DISH Q56231429
- name: Biapong
- description: bakpao typical of North Sulawesi
- countries: ID
- cuisines: Indonesian cuisine
- kinds: bakpau, dish, human food, type of food or dish
- ingredients: wheat flour

## DISH Q56231471
- name: Carang mas
- description: Indonesian sweet snack
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, cracker, dish, human food, type of food or dish
- ingredients: Sweet potato

## DISH Q56231486
- name: Cilung
- description: food made from starch
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, street food, human food, traditional food, type of food or dish
- ingredients: sago flour, chicken egg, vegetable oil, monosodium L-glutamate, mineral water, table salt

## DISH Q56231570
- name: Es Goyang
- countries: ID
- cuisines: Indonesian cuisine
- kinds: ice cream, dish, human food, type of food or dish
- ingredients: coconut milk

## DISH Q56231645
- name: Godoh
- other names: {"ban": "Godoh"}
- countries: ID
- kinds: human food
- ingredients: jackfruit, flour

## DISH Q56231672
- name: Jenang grendul
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dessert, dish, human food, type of food or dish
- ingredients: glutinous rice flour, brown sugar, rice flour, coconut milk, table salt

## DISH Q56231674
- name: Jenang krasikan
- countries: ID
- cuisines: Indonesian cuisine
- kinds: Dodol, dish, human food, type of food or dish
- ingredients: glutinous rice flour, coconut milk, Pandanus amaryllifolius, table salt, sugar

## DISH Q56231696
- name: Kaldu Kokot
- other names: {"id": "Kaldu Kokot"}
- countries: (none)
- kinds: food, dish

## DISH Q56231735
- name: Timus
- description: Indonesia traditional cake
- countries: (none)
- kinds: Lepet, food, dessert, dish, type of food or dish

## DISH Q56231808
- name: Kerupuk upil
- other names: {"id": "kerupuk upil"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, cracker
- ingredients: tapioca flour, garlic, table salt

## DISH Q56231883
- name: Pepe’
- description: Indonesian specialty cakes from Betawi
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: sago flour, rice flour, coconut milk, food coloring, sugar

## DISH Q56231886
- name: Kue srikaya
- description: traditional food from Jambi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q56231949
- name: Laksa Bogor
- countries: (none)
- kinds: laksa
- ingredients: oncom, coconut milk, rice vermicelli

## DISH Q56231954
- name: Lapis talas Bogor
- description: Indonesian specialty cakes from Bogor
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: buttercream, food coloring, milk powder, cooking oil, Colocasia esculenta, egg as food, baking powder, cheese, margarine

## DISH Q56232037
- name: Bone marrow rice
- description: culinary specialties of Serang
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: Red Rice

## DISH Q56232041
- name: Nasi tumpang lethok
- other names: {"id": "nasi tumpang lethok"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: seedling, Asparagus bean, Holy Basil, cooked rice, Amaranthus, Artocarpus heterophyllus

## DISH Q56232059
- name: Pacri Nanas
- description: vegetable dish from Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, type of food or dish
- ingredients: pineapple, white sugar, star anise, Pandanus amaryllifolius, chili pepper, Cymbopogon citratus, cinnamon, table salt, water

## DISH Q56232060
- name: Pallu kacci
- description: Indonesian traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, soup, meal
- ingredients: Mangifera indica, Aleurites moluccanus, fish as food, cooking oil, Allium ascalonicum, chili pepper, black pepper, Curcuma longa, Cocos nucifera, table salt, water
