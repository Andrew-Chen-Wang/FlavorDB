# Review batch names-008

## DISH Q109436308
- name: Gulai belut
- other names: {"id": "Gulai belut"}
- countries: (none)
- kinds: dish, type of food or dish, Indonesian cuisine, gulai

## DISH Q109436407
- name: Bánh mì cá sấu
- other names: {"vi": "bánh mì cá sấu"}
- countries: VN
- cuisines: An Giang cuisine
- kinds: bánh mì

## DISH Q109436498
- name: Nem Lai Vung
- description: A specialty dish of Lai Vung commune.
- countries: VN
- kinds: dish
- has Wikipedia article: en

## DISH Q109436536
- name: Hảo Hảo
- description: brand of instant noodles created by Acecook Vietnam
- countries: (none)
- kinds: instant noodles
- has Wikipedia article: en

## DISH Q109438515
- name: Sambal salabance
- description: traditional fish-based sambal from Merangin, Jambi
- countries: ID
- kinds: fish dish, dish, type of food or dish

## DISH Q109439271
- name: Pempek sambal
- description: traditional food from Jambi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: street food, Pempek, food, dish, traditional food, type of food or dish

## DISH Q109439272
- name: Botok yuyu
- description: Indonesian dish
- countries: (none)
- kinds: dish

## DISH Q109439830
- name: Barobbo
- description: Indonesian food
- countries: ID, MY
- kinds: porridge

## DISH Q109440318
- name: Falafel burger
- description: dish
- countries: (none)
- kinds: dish
- ingredients: falafel, bread roll

## DISH Q109440360
- name: Sop Balungan Demak
- other names: {"id": "Sop Balungan Demak"}
- countries: (none)
- kinds: dish

## DISH Q109441388
- name: Gulai terjun daging
- other names: {"id": "Gulai terjun daging"}
- countries: (none)
- kinds: dish, type of food or dish, Indonesian cuisine, gulai
- ingredients: buffalo meat, coconut milk, goat meat, beef

## DISH Q109441389
- name: Daging masak hitam
- description: traditional meat dish from Jambi, Indonesia
- countries: ID
- kinds: Semur, food, dish, type of food or dish
- ingredients: meat

## DISH Q109453166
- name: Dalí bread
- description: type of bread inspired by Salvador Dalí
- countries: ES
- kinds: bread

## DISH Q109456534
- name: Jeotgukgalbi
- countries: KR
- kinds: meat dish

## DISH Q109459856
- name: トゥブバプ
- other names: {"ja": "トゥブバプ"}
- countries: KP
- cuisines: North Korean cuisine
- kinds: rice dish
- ingredients: bap, tofu

## DISH Q109460667
- name: オムクコロッケ
- other names: {"ja": "オムクコロッケ"}
- countries: KR
- kinds: deep-fried food

## DISH Q10946121
- name: Tasimi
- other names: {"zh": "它似蜜"}
- description: Chinese lamb dish
- countries: (none)
- kinds: lamb dish
- has Wikipedia article: zh

## DISH Q1094882
- name: Clam chowder
- other names: {"zh": "周打蜆湯"}
- description: chowders containing clams and broth
- countries: US
- cuisines: cuisine of the United States
- kinds: chowder, fish soup, clam dish
- ingredients: clam, broth
- has Wikipedia article: en, zh

## DISH Q109497393
- name: Fabiola
- description: bread type from Castile, Spain
- countries: ES
- kinds: bread

## DISH Q109502070
- name: Fruta de horno
- description: type of traditional Mexican cookie
- countries: MX
- cuisines: Mexican cuisine
- kinds: cookie, dessert, food
- ingredients: panela, cornmeal, wheat flour, lard, sugar, water

## DISH Q109519912
- name: Lemon ricotta pancakes
- description: pancake dish
- countries: US
- kinds: dish
- ingredients: cow's milk, lemon juice, ricotta, lemon zest, egg as food, flour, butter, baking powder, table salt

## DISH Q10952583
- name: Tigretón
- other names: {"es": "Tigretón"}
- countries: ES
- kinds: dessert

## DISH Q1095315
- name: Toum
- description: garlic sauce or dip common in the Levant
- countries: (none)
- kinds: dish, type of food or dish, sauce
- ingredients: garlic, vegetable oil, lemon juice, table salt
- has Wikipedia article: en

## DISH Q109532998
- name: Balık çorbası
- description: fish soup, Turkish style
- countries: (none)
- kinds: fish soup
- has Wikipedia article: en

## DISH Q109533885
- name: Sunsal-chikin
- description: Korean fried chicken
- countries: (none)
- kinds: Korean fried chicken

## DISH Q109536261
- name: Moon mist
- description: Canadian ice cream flavour
- countries: CA
- kinds: ice cream
- has Wikipedia article: en

## DISH Q109539600
- name: Lamprey pie
- description: Pastry dish with filling of lamprey
- countries: (none)
- kinds: pie
- has Wikipedia article: en

## DISH Q10954885
- name: Dodol betawi
- description: Typical Food in Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, Dodol
- ingredients: palm sugar, coconut milk, glutinous rice, sugar

## DISH Q109558070
- name: Croffle
- description: croissant dough cooked on a waffle pan
- countries: IE
- cuisines: cuisine of the United States, Irish cuisine, South Korean cuisine
- kinds: waffle, croissant, type of food or dish
- ingredients: croissant, waffle
- has Wikipedia article: en

## DISH Q109569010
- name: Khao Kriep Pak Mor
- countries: (none)
- kinds: appetizer
- ingredients: tapioca starch, arrowroot, rice flour

## DISH Q109569034
- name: Kaeng ho
- description: Northern Thai curry dish
- countries: TH
- kinds: Thai curry

## DISH Q109587599
- name: Barrel chicken
- other names: {"zh": "桶仔雞"}
- description: Taiwanese roasted chicken dish
- countries: TW
- kinds: dish
- has Wikipedia article: zh

## DISH Q109596034
- name: 浅野四十二万石
- other names: {"ja": "浅野四十二万石"}
- countries: (none)
- kinds: Miyagegashi

## DISH Q109596124
- name: Taiwan donut
- other names: {"zh": "台灣甜甜圈"}
- countries: (none)
- kinds: doughnut

## DISH Q109596277
- name: Lasagne alla bolognese
- countries: (none)
- kinds: dish, lasagna
- ingredients: bolognese sauce

## DISH Q109596821
- name: Doyō mochi
- countries: (none)
- kinds: mochi

## DISH Q109598159
- name: 諫早おこし
- other names: {"ja": "諫早おこし"}
- countries: (none)
- kinds: okoshi

## DISH Q109598332
- name: 室戸キンメ丼
- other names: {"ja": "室戸キンメ丼"}
- countries: JP
- kinds: Kaisen-don

## DISH Q109598458
- name: ぶどう饅頭
- other names: {"ja": "ぶどう饅頭"}
- countries: (none)
- kinds: Miyagegashi

## DISH Q109601782
- name: Potato Snack
- description: Japanese snack
- countries: JP
- kinds: snack

## DISH Q109602737
- name: プティ・パン
- other names: {"ja": "プティ・パン"}
- countries: (none)
- kinds: bread

## DISH Q109602739
- name: Isobeage
- description: tempura with seaweed batter
- countries: JP
- kinds: tempura, dish
- ingredients: nori

## DISH Q109602746
- name: Nagasaki tempura
- countries: (none)
- kinds: tempura

## DISH Q109604400
- name: Яичная кашка
- other names: {"ru": "Яичная кашка"}
- countries: (none)
- kinds: egg dish

## DISH Q109611860
- name: Shim alu bori diye tengra machher jhol
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q109611888
- name: Chingri diye lau ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q109615251
- name: Roast beef
- other names: {"zh": "烧牛肉"}
- description: various kinds of roasted beef
- countries: (none)
- kinds: roast, beef dish
- has Wikipedia article: zh

## DISH Q109616822
- name: Shredded meat
- countries: (none)
- kinds: meat dish

## DISH Q109630376
- name: Cocktail salad
- countries: (none)
- kinds: dish

## DISH Q109645027
- name: Mulo diye musur dal
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, lentil soup

## DISH Q109645225
- name: Bele machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q10964995
- name: Bingka
- description: Traditional Indonesian cake originating from East Kalimantan
- countries: ID
- kinds: dish, snack, human food, kue, traditional food, type of food or dish
- ingredients: wheat flour, coconut milk, egg as food, table salt, sugar
- has Wikipedia article: en

## DISH Q109659136
- name: Sugakima2 Jigoku no Aka Ramen
- countries: (none)
- kinds: ramen

## DISH Q109664551
- name: おかゆライス
- other names: {"ja": "おかゆライス"}
- countries: (none)
- kinds: rice dish
- ingredients: congee, rice

## DISH Q109667967
- name: Medianoche
- description: type of bread in Cuban cuisine made of soft, sweet egg dough
- countries: CU
- kinds: sweet bread
- ingredients: egg dough

## DISH Q109668004
- name: Elena Ruz
- description: Cuban turkey sandwich with cream cheese and strawberry jam on medianoche bread
- countries: CU
- kinds: sandwich
- ingredients: medianoche, turkey meat, strawberry jam, cream cheese

## DISH Q10969752
- name: Turkish honey
- description: Polish candy
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q10971166
- name: Timphan
- description: Indonesian steamed banana dumpling
- countries: ID
- cuisines: Acehnese cuisine, Indonesian cuisine
- kinds: food, dish, human food, dessert, banana dish
- ingredients: flour, table salt, sugar, banana, glutinous rice flour, latundan banana, jackfruit, banana leaf, coconut, wheat flour, coconut milk, cooking oil, Pandanus amaryllifolius, egg as food
- has Wikipedia article: en

## DISH Q10973598
- name: Hotch pot
- description: type of mutton soup
- countries: (none)
- kinds: food, soup
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q10976640
- name: Chanchigorri cake
- description: Spanish and Basque savory pastry
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q109771488
- name: Olgaengiguk
- countries: (none)
- kinds: guk

## DISH Q10978475
- name: Pekasam
- other names: {"zh": "马来腌鱼"}
- description: Malay fermented food originating from Perak and Kedah
- countries: ID, MY
- cuisines: Indonesian cuisine, side dish
- kinds: dish, human food, traditional food, type of food or dish, fish dish
- ingredients: freshwater fish, glutinous rice, table salt, sugar
- has Wikipedia article: en

## DISH Q109801608
- name: Stuffed velvet crab
- description: typical Spanish dish
- countries: ES
- kinds: dish

## DISH Q109820549
- name: Galician bread
- description: European protected geographical indication
- countries: ES
- kinds: bread
- has Wikipedia article: en

## DISH Q109827446
- name: Bannock
- description: indigenous North American bread
- countries: (none)
- cuisines: indigenous cuisine of the Americas
- kinds: frybread
- has Wikipedia article: en

## DISH Q10986174
- name: Sate madura
- description: a type of satay served with peanut sauce
- countries: ID
- cuisines: Indonesian cuisine, human food
- kinds: traditional food, type of food or dish, satay, dish, human food, meat, grilling
- ingredients: beef, peanut, chicken as food

## DISH Q109866
- name: Gyūhi
- other names: {"zh": "求肥"}
- description: Traditional Japanese sweet
- countries: JP
- kinds: wagashi
- ingredients: glutinous rice flour, mizuame, sugar
- has Wikipedia article: en, zh

## DISH Q10987
- name: Honey
- other names: {"zh": "蜂蜜"}
- description: sweet food made by bees mostly using nectar from flowers
- countries: (none)
- kinds: food ingredient, organic matter, confectionery, syrup, shelf-stable food, secretion or excretion, fodder
- ingredients: water, nectar
- has Wikipedia article: en, zh

## DISH Q109876240
- name: Guguta's hat
- description: Moldovan cake with cherries
- countries: MD
- kinds: dessert
- ingredients: sugar, cherry, pancake, cream

## DISH Q109886659
- name: Popping candy
- description: hard fizzy candy
- countries: (none)
- kinds: candy

## DISH Q10989778
- name: Bacalhau
- other names: {"zh": "馬介休"}
- description: dish, also the name for dried salted cod in Portuguese cuisine
- countries: PT
- kinds: fare, fish dish
- ingredients: Gadus morhua
- has Wikipedia article: en

## DISH Q109913747
- name: कलौंजी
- other names: {"bho": "कलौंजी"}
- countries: (none)
- kinds: dish

## DISH Q109914555
- name: Special sauce
- description: sauce made from curry ketchup, mayonnaise, onions and sambal
- countries: BE
- kinds: hot sauce, condiment
- ingredients: onion, curry ketchup, hot sauce, mayonnaise

## DISH Q109920940
- name: Mole rosa
- description: Mexican mole
- countries: MX
- kinds: sauce

## DISH Q109950188
- name: Tsybryki
- description: Belarusian fried potato dumplings
- countries: BY
- cuisines: Belarusian cuisine
- kinds: dish
- ingredients: vegetable oil, flour, potato

## DISH Q10997735
- name: Gujia
- description: also known as ghughra in gujarati
- countries: IN
- kinds: stuffed pasta
- ingredients: semolina
- has Wikipedia article: en

## DISH Q110042427
- name: Farinha Torrada
- description: Traditional candy from Sesimbra
- countries: PT
- kinds: cake

## DISH Q110056303
- name: Concoction rice
- description: Nigerian dish
- countries: NG
- kinds: food, rice
- ingredients: seasoning sauce, vegetable oil, palm oil, Ceratonia siliqua, table salt, vegetable, rice, fish, palm oil mill effluent, iru, Maggi, Capsicum, water
- has Wikipedia article: en

## DISH Q110061263
- name: Pizza Poro
- description: pizza made from smoked reindeer, tomato sauce, cheese, chanterelle mushrooms and red onion
- countries: FI
- kinds: dish
- ingredients: domesticated reindeer, tomato sauce, red onion, Cantharellus cibarius, cheese

## DISH Q110081689
- name: Tenkaippin
- countries: (none)
- kinds: ramen

## DISH Q110101486
- name: Takjil
- description: Food or drink that breaks fasts in Indonesia
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q110104063
- name: Təbriz paxlavası
- other names: {"az": "Təbriz paxlavası"}
- countries: (none)
- kinds: pastry

## DISH Q1101046
- name: Tyurya
- description: Russian cold soup
- countries: RU
- cuisines: Russian cuisine, Ukrainian cuisine, Belarusian cuisine
- kinds: food, cold sweet soup
- ingredients: vegetable oil, table salt, vegetable, bread, water

## DISH Q110108640
- name: Çürütmə
- other names: {"az": "Çürütmə"}
- countries: (none)
- kinds: pastry

## DISH Q110115559
- name: スックク
- other names: {"ja": "スックク"}
- countries: (none)
- kinds: guk
- ingredients: Artemisia princeps

## DISH Q110117776
- name: Changnanjeot
- description: Korean dish of spicy salted pollock innards
- countries: (none)
- kinds: Korean cuisine, jeotgal

## DISH Q110122147
- name: Boh puniaram
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: frikadeller, potato dish, dish
- ingredients: Kaffir Lime Leaf, turmeric rhizome, garlic, coconut, Aleurites moluccanus, Kaempferia galanga, food additive, chili pepper, egg as food, black pepper, Coriandrum sativum, table salt, sugar

## DISH Q110126962
- name: Yam with cod
- description: Cuban dish
- countries: CU
- kinds: dish

## DISH Q110127742
- name: Inyama yenhloko
- description: traditional meat dish in southern Africa
- countries: ZA
- kinds: meat, food
- has Wikipedia article: en

## DISH Q110129212
- name: Jruek Drien
- description: Acehnese cuisine from Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: fermented food, dish, type of food or dish
- ingredients: asparagus bean, Kaffir Lime Leaf, cassava root, Elephantopus scaber, durian, table salt, water

## DISH Q110132849
- name: Köbete
- description: traditional Crimean Tatar pie
- countries: (none)
- kinds: food, pie

## DISH Q110133485
- name: Soto Medan
- description: traditional soup from Medan, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: soto, dish, Indonesian cuisine, human food, traditional food, type of food or dish
- ingredients: Indonesian bay leaf, shallot, Kaffir Lime Leaf, caraway seeds, chicken as food, coconut milk, rice vermicelli, Alpinia galanga, Curcuma longa, Cymbopogon citratus, Allium sativum

## DISH Q110134687
- name: Belut goreng
- other names: {"ms": "Belut goreng"}
- countries: MY
- kinds: dish

## DISH Q110134698
- name: Bungong Kayee
- description: kind of dessert from Aceh, Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: cookie, dessert, sweetmeat, kue, dish
- ingredients: tapioca, food coloring, glutinous rice, egg as food, sugar

## DISH Q110144660
- name: Gang mourala machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q110146538
- name: Pommes à la Bruxelloise
- other names: {"fr": "pommes à la Bruxelloise"}
- countries: (none)
- kinds: type of food or dish, dessert
- ingredients: apple

## DISH Q11017447
- name: Bandeng presto
- description: typical milkfish dish from Indonesia
- countries: ID
- kinds: food
- ingredients: Chanos chanos

## DISH Q110189370
- name: Kostrada
- other names: {"eu": "Kostrada"}
- countries: (none)
- kinds: dessert

## DISH Q110215765
- name: Λαλάγγια
- other names: {"el": "Λαλάγγια"}
- countries: (none)
- kinds: dish

## DISH Q110220935
- name: Sinterklaas candy
- countries: BE
- kinds: confectionery, Saint Nicholas and Saint Martin fest, holiday dish

## DISH Q1102230
- name: Ukha
- other names: {"zh": "烏哈湯"}
- description: fish soup
- countries: RU
- kinds: food, fish soup
- ingredients: fish as food
- has Wikipedia article: en, zh

## DISH Q110253542
- name: Kucho chingrir borar jhol
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish, Jhol

## DISH Q110253556
- name: Sorshe diye khoyra machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q110253565
- name: Gang mourala machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q110255436
- name: Tarana
- description: typical Macedonian dish
- countries: MK
- kinds: dish
- ingredients: egg as food, flour, butter, table salt, milk

## DISH Q110256340
- name: Chocolate Santa Claus
- description: chocolate confectionery in the shape of Santa Claus
- countries: (none)
- kinds: figure, confectionery
- ingredients: chocolate

## DISH Q110256900
- name: Kouraikei Ramen
- description: Japanese noodle soup
- countries: (none)
- kinds: ramen

## DISH Q110263128
- name: Salmon carpaccio
- countries: (none)
- kinds: fish dish, seafood, carpaccio

## DISH Q110273315
- name: Pategrás
- description: semi-hard cheese from Argentina
- countries: AR
- kinds: cow's-milk cheese, cheese

## DISH Q110273622
- name: Akamiso
- countries: (none)
- kinds: miso

## DISH Q110273642
- name: Shiromiso
- countries: (none)
- kinds: miso

## DISH Q110273646
- name: Tanshokumiso
- countries: (none)
- kinds: miso

## DISH Q110276382
- name: Street food in Nigeria
- description: traditional cuisine of Nigeria
- countries: (none)
- kinds: street food

## DISH Q110277636
- name: Awasemiso
- countries: (none)
- kinds: miso

## DISH Q110279244
- name: Chocolate Easter Bunny
- description: rabbit-shaped chocolate confectionery eaten at Easter
- countries: (none)
- kinds: figure, confectionery, Easter food
- ingredients: chocolate

## DISH Q110279308
- name: Chocolate Saint Nicholas
- description: chocolate confectionery in the shape of Saint Nicholas
- countries: (none)
- kinds: figure, confectionery
- ingredients: chocolate

## DISH Q110282413
- name: Torró d'Ocata
- countries: (none)
- kinds: turrón

## DISH Q110293006
- name: Tullgarnspaj
- other names: {"sv": "Tullgarnspaj"}
- countries: (none)
- kinds: pie

## DISH Q110301589
- name: Kepta duona
- description: Lithuanian, latvian garlic bread chips
- countries: LT, LV
- kinds: bread, dish, garlic bread

## DISH Q110362900
- name: Pihta
- description: sacramental flatbread in Mandaeism
- countries: IQ, IR
- kinds: flatbread
- has Wikipedia article: en

## DISH Q110419691
- name: Onion soup
- description: type of vegetable soup
- countries: (none)
- kinds: soup
- ingredients: onion
- has Wikipedia article: en

## DISH Q110424383
- name: Pasta asciutta
- other names: {"de": "Pasta asciutta"}
- description: method of preparing pasta
- countries: (none)
- kinds: dish

## DISH Q110426863
- name: Masnovines
- countries: ES
- kinds: dish, artistic technique

## DISH Q110427128
- name: Dolmades
- countries: (none)
- kinds: meat dish, rice dish
- ingredients: mutton, rice

## DISH Q1104399
- name: Karaage
- other names: {"zh": "唐扬"}
- description: Japanese cooking technique
- countries: JP
- kinds: Agemono, chicken dish, food preparation technique
- has Wikipedia article: en, zh

## DISH Q110448601
- name: Bolón de verde
- other names: {"it": "Bolón de verde"}
- countries: EC
- kinds: Tacacho, dish

## DISH Q110456412
- name: Frittata con le ortiche
- other names: {"it": "Frittata con le ortiche"}
- countries: IT
- kinds: frittata
- ingredients: nettle leaf, egg as food

## DISH Q1104577
- name: Pepper steak
- other names: {"zh": "青椒肉丝"}
- description: pork dish
- countries: CN
- kinds: pork dish
- ingredients: pork
- has Wikipedia article: en, zh

## DISH Q1104585
- name: Cobb salad
- other names: {"zh": "科布色拉"}
- description: American garden salad
- countries: US
- cuisines: cuisine of the United States
- kinds: salad
- ingredients: tomato, avocado, vinaigrette, Lactuca, Persea americana, egg, bacon, cheese, chicken
- has Wikipedia article: en, zh

## DISH Q11045882
- name: Seruit
- description: Indonesian traditional fish cuisine from Lampung
- countries: ID
- cuisines: Indonesian cuisine, sambal, side dish
- kinds: dish, human food, fish dish, traditional food, type of food or dish
- ingredients: Tempoyak, Thunnus tonggol, Mangifera odorata, Citrus × aurantiifolia, tomato, Allium sativum, table salt, water

## DISH Q110460981
- name: Miele varesino
- other names: {"it": "miele varesino"}
- countries: IT
- kinds: honey

## DISH Q110469197
- name: Pan de coco
- description: Honduran sweet bread
- countries: HN
- kinds: sweet bread
- has Wikipedia article: en

## DISH Q110474734
- name: Potage Saint-Germain
- other names: {"fr": "Potage Saint-Germain"}
- countries: (none)
- kinds: dish, soup
- ingredients: Green pea, Pisum sativum

## DISH Q110498955
- name: Oldenzaalse kringelen
- other names: {"nl": "Oldenzaalse kringelen"}
- countries: (none)
- kinds: cookie

## DISH Q110502590
- name: Bronka smør
- other names: {"nb": "Bronka smør"}
- countries: NO
- kinds: dish

## DISH Q1105083
- name: Caramel apple
- other names: {"zh": "焦糖蘋果"}
- description: apple covered with layer of caramel
- countries: US
- cuisines: cuisine of the United States
- kinds: type of food or dish, confectionery
- ingredients: caramel, apple
- has Wikipedia article: en

## DISH Q1105215
- name: Cocido madrileño
- description: food
- countries: ES
- cuisines: cuisine of Madrid
- kinds: food, soup
- ingredients: chickpea
- has Wikipedia article: en

## DISH Q1105318
- name: Cocktail
- other names: {"de": "Cocktail"}
- description: dish
- countries: (none)
- kinds: dish

## DISH Q110533119
- name: Mollete of Antequera
- description: Protected Geographical Indication
- countries: ES
- kinds: bread
- has Wikipedia article: en

## DISH Q110536414
- name: Ninjakei Ramen
- countries: (none)
- kinds: ramen

## DISH Q1105503
- name: Coda alla vaccinara
- description: Italian stew using oxtail
- countries: IT
- cuisines: Italian cuisine, Roman cuisine
- kinds: beef dish, food
- ingredients: oxtail
- has Wikipedia article: en

## DISH Q1105512
- name: Lula kebab
- description: type of kebab, made from minced meat
- countries: AM, AZ
- kinds: kebab, dish
- ingredients: peppercorn, lavash, goat meat, Rhus coriaria, table salt, minced meat, onion
- has Wikipedia article: en

## DISH Q110557555
- name: Italian meat and sausage products
- description: meat and sausage products originating from Italy
- countries: IT
- kinds: charcuterie

## DISH Q110577413
- name: Fatira
- description: small, round, saltless, half-baked biscuit
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q110584431
- name: Muhlama
- description: Meal made from Rize region cheese and corn flour
- countries: TR
- kinds: food

## DISH Q11060059
- name: Sroki
- description: dish
- countries: (none)
- cuisines: sorbian cuisine
- kinds: dish

## DISH Q110611118
- name: White bread crust
- description: crust of a white bread
- countries: (none)
- kinds: food ingredient, bread

## DISH Q110611180
- name: Rye breadcrumb
- description: breadcrumb made of rye bread
- countries: (none)
- kinds: food ingredient, bread crumbs

## DISH Q110611288
- name: Vogelspeise
- description: historical name of a preparation made from chopped hard boiled eggs
- countries: (none)
- kinds: food ingredient, egg dish

## DISH Q110611289
- name: Egg milk
- description: homogeneous mixture of eggs and milk for further processing into egg custard
- countries: (none)
- kinds: food ingredient, egg dish

## DISH Q110612942
- name: Panotsang mani
- description: Filipino confection
- countries: (none)
- kinds: brittle
- has Wikipedia article: en

## DISH Q11061604
- name: Ping On Bun
- other names: {"zh": "幽包"}
- description: traditional sweet steamed bun from Cheung Chau, Hong Kong
- countries: CN
- kinds: bun
- has Wikipedia article: en, zh

## DISH Q11062733
- name: 庆岭活鱼
- countries: CN
- cuisines: Chinese cuisine
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q110627904
- name: Сливовое пюре
- other names: {"ru": "сливовое пюре"}
- countries: (none)
- kinds: mash

## DISH Q1106345
- name: Porchetta PAT
- other names: {"zh": "Porchetta PAT"}
- description: traditional Italian meat product (PAT)
- countries: FR, IT
- kinds: meat product, pork dish
- ingredients: pork
- has Wikipedia article: en, zh

## DISH Q110647160
- name: Librico de Yecla
- other names: {"es": "Librico de Yecla"}
- countries: ES
- kinds: confectionery
- ingredients: wafer cookie

## DISH Q110651436
- name: Groninger mosterdsoep
- other names: {"nl": "Groninger mosterdsoep"}
- countries: (none)
- kinds: dish, mustard soup

## DISH Q110655684
- name: Freshness Burger(Yaba-chō-ten)
- countries: (none)
- kinds: fast food

## DISH Q11065810
- name: Kaishui baicai
- other names: {"zh": "开水白菜"}
- description: napa cabbage dish originated from Sichuan
- countries: CN
- kinds: vegetable dish
- ingredients: Napa cabbage, chicken soup
- has Wikipedia article: zh

## DISH Q110664680
- name: Whole wheat spaghetti
- countries: (none)
- kinds: spaghetti

## DISH Q11066473
- name: Yellow curry
- other names: {"zh": "黃咖哩"}
- description: variety of curry
- countries: TH
- kinds: Thai curry
- has Wikipedia article: en, zh

## DISH Q110693434
- name: Ṣa
- description: sacramental flatbread in Mandaeism
- countries: (none)
- kinds: flatbread
- has Wikipedia article: en

## DISH Q110701994
- name: Naturschnitzel
- other names: {"de": "Naturschnitzel"}
- countries: (none)
- kinds: escalope

## DISH Q110702204
- name: Cocuixtle
- description: American fruit
- countries: MX
- kinds: fruit

## DISH Q110730621
- name: Indigenous Chocolate, LLC
- description: Native American bean-to.bar chocolate manufacturer
- countries: (none)
- kinds: chocolaterie, bean-to-bar

## DISH Q1107324
- name: Bolo de mel
- description: traditional cake from the Madeira Islands
- countries: PT
- kinds: cake
- ingredients: sugarcane honey, wheat flour, lemon, walnut, almond, citron, yeast, Foeniculum vulgare, cinnamon, Madeira wine (DOC), clove, orange
- has Wikipedia article: en

## DISH Q110738684
- name: Alentejano bread
- description: traditional Portuguese bread
- countries: PT
- cuisines: Portuguese cuisine
- kinds: bread
- has Wikipedia article: en

## DISH Q110738704
- name: Cutxaró
- description: Catalan sourdough
- countries: ES
- kinds: pre-ferment

## DISH Q110745670
- name: German baked apples
- description: German baked apples dessert
- countries: DE
- cuisines: dessert, Christmas dessert
- kinds: food
- ingredients: apple
- has Wikipedia article: en

## DISH Q110749148
- name: Champignonschnitzel
- other names: {"de": "Champignonschnitzel"}
- countries: (none)

## DISH Q11075630
- name: Yanpi
- other names: {"zh": "扁肉燕"}
- description: type of Chinese wonton skin
- countries: (none)
- kinds: dish
- ingredients: pork, glutinous rice
- has Wikipedia article: en, zh

## DISH Q11076102
- name: Braised pork slices
- other names: {"zh": "扣肉"}
- description: dish
- countries: CN
- cuisines: Chinese cuisine
- kinds: meat dish, food, type of food or dish
- has Wikipedia article: zh

## DISH Q11076619
- name: Patriotic soup
- other names: {"zh": "护国菜"}
- description: vegetable soup
- countries: CN
- kinds: vegetable soup, dish
- ingredients: edible mushroom, leaf vegetable
- has Wikipedia article: en, zh

## DISH Q110768007
- name: Chitol machher peti kalia
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q11076814
- name: Min ba gu
- other names: {"zh": "抿八股"}
- countries: CN
- kinds: food
- has Wikipedia article: zh

## DISH Q11077259
- name: Daigaku imo
- other names: {"zh": "拔絲地瓜"}
- description: Japanese fried and candied sweet potatoes
- countries: JP
- kinds: snack, potato dish, sweet potato fries
- ingredients: Sweet potato
- has Wikipedia article: zh

## DISH Q110776121
- name: Bolo de bolacha
- description: Portuguese biscuit cake
- countries: PT
- cuisines: Portuguese cuisine
- kinds: cake
- ingredients: Marie biscuit, cream, coffee
- has Wikipedia article: en

## DISH Q11078065
- name: Pork ribs rice
- other names: {"zh": "排骨米饭"}
- description: Chinese dish with several regional variations (Hong Kong, Taiwan, Shanghai etc.)
- countries: CN, TW
- cuisines: Chinese cuisine
- kinds: rice dish, pork dish
- ingredients: pork ribs, cooked rice
- has Wikipedia article: zh

## DISH Q11078498
- name: Tshik-á-mī
- other names: {"zh": "摵仔麵"}
- description: traditional Taiwanese noodle dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: flour-based food
- has Wikipedia article: en, zh

## DISH Q11078597
- name: Sarmale
- description: Romanian and Moldovan culinary specialty
- countries: RO
- cuisines: Romanian cuisine, Moldovan cuisine
- kinds: cabbage roll, dish
- ingredients: minced meat
- has Wikipedia article: en

## DISH Q11079928
- name: Wenchang chicken
- other names: {"zh": "文昌鸡"}
- description: Chinese chicken dish
- countries: CN
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q110800802
- name: Pisarei
- description: type of pasta
- countries: IT
- cuisines: Italian cuisine
- kinds: type of pasta
- ingredients: bread crumbs, flour

## DISH Q110821764
- name: 重庆辣子鸡
- countries: CN
- kinds: dish
- ingredients: chicken as food, Sichuan pepper

## DISH Q1108310
- name: Melon and ham
- other names: {"zh": "蜜瓜火腿"}
- description: appetizer
- countries: (none)
- kinds: appetizer
- ingredients: muskmelon, ham
- has Wikipedia article: en, zh

## DISH Q110831239
- name: Frikadellisupp
- countries: EE, LV
- kinds: soup
- ingredients: frikadeller

## DISH Q110834503
- name: Bánh nhúng
- countries: (none)
- kinds: dish, bánh

## DISH Q110834778
- name: Bánh trôi
- description: Vietnamese dessert
- countries: VN
- kinds: bánh, dish
- ingredients: panela, glutinous rice

## DISH Q110834827
- name: Bánh chay
- countries: VN
- kinds: bánh, dish
- ingredients: mung bean, glutinous rice

## DISH Q11085987
- name: Wuxi Fried Spare Ribs
- other names: {"zh": "无锡酱排"}
- description: Chinese pork rib dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en, zh

## DISH Q11087090
- name: Asahikawa ramen
- other names: {"zh": "旭川拉麵"}
- description: Japanese ramen dish
- countries: JP
- kinds: shoyu ramen, ramen in Hokkaido
- has Wikipedia article: zh

## DISH Q110880257
- name: Escargots à la bourguignonne
- description: escargot dish
- countries: (none)
- kinds: dish

## DISH Q110885312
- name: Kunpen
- countries: (none)
- kinds: confectionery

## DISH Q110885432
- name: Tauchīchō
- countries: (none)
- kinds: deep-fried confection

## DISH Q1108866
- name: Cornbread
- other names: {"zh": "玉米面包"}
- description: American bread made from cornmeal
- countries: US
- kinds: maize bread
- ingredients: cornmeal, sugar
- has Wikipedia article: en, zh

## DISH Q110887633
- name: Malaxto
- other names: {"az": "Malaxto"}
- countries: GE
- cuisines: Georgian cuisine
- kinds: dish
- ingredients: green bean

## DISH Q110889230
- name: Clear soup
- other names: {"zh": "清汤"}
- description: a clear soup or a broth
- countries: (none)
- kinds: soup

## DISH Q110891687
- name: Zopako
- description: Basque traditional bread
- countries: ES
- kinds: bread

## DISH Q110894306
- name: Phirni
- description: rice pudding dessert
- countries: IN
- kinds: rice pudding, rice dish
- has Wikipedia article: en

## DISH Q110910093
- name: Mogatla
- description: oxtail stew of Botswana
- countries: BW
- kinds: oxtail soup, stew
- ingredients: oxtail

## DISH Q110910147
- name: Morogo wa dinawa
- description: dish of cowpea leaves and beans
- countries: (none)
- kinds: vegetable dish
- ingredients: bean, leaf

## DISH Q11091874
- name: Moonlight cake
- other names: {"zh": "月光餅"}
- description: type of traditional Hakka mooncake; white and disc-like
- countries: CN
- cuisines: Hakka cuisine
- kinds: food, mooncake
- has Wikipedia article: en, zh

## DISH Q110920147
- name: Cristines de Sant Blai
- other names: {"ca": "Cristines de Sant Blai"}
- countries: (none)
- kinds: cake, brioche

## DISH Q110924259
- name: Mouillette
- other names: {"fr": "mouillette"}
- countries: FR
- kinds: dish

## DISH Q11093486
- name: Sapporo ramen
- other names: {"zh": "札幌拉麵"}
- description: Japanese dish
- countries: JP
- kinds: miso ramen, ramen in Hokkaido
- has Wikipedia article: zh

## DISH Q110945408
- name: Самбук (блюдо)
- other names: {"ru": "Самбук (блюдо)"}
- countries: RU
- cuisines: Russian cuisine
- kinds: sweet dish, mousse
- ingredients: mash, beaten egg whites

## DISH Q110953641
- name: Mollete
- description: Mexican bread dish
- countries: MX
- kinds: dish

## DISH Q110962505
- name: Kebebet
- description: variant of the kibbeh dish made of meat and bulgur with aromatic stuffing
- countries: (none)
- kinds: meat dish, kibbeh
- ingredients: lamb meat, bulgur, parsley, onion

## DISH Q110966095
- name: Boule de pain
- other names: {"fr": "Boule de pain"}
- countries: (none)
- kinds: bread

## DISH Q110977435
- name: Focaccia di Gordona
- countries: (none)
- kinds: focaccia

## DISH Q11098740
- name: Piñonada
- description: Spanish confection made with pine nuts
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q1110192
- name: Chinsuko
- other names: {"zh": "金楚糕"}
- description: Japanese biscuit
- countries: (none)
- kinds: cookie, Miyagegashi
- ingredients: wheat flour, lard, sugar
- has Wikipedia article: en, zh

## DISH Q111019266
- name: Cheela
- description: type of Indian pancake
- countries: IN
- cuisines: Indian cuisine
- kinds: Indian bread, dish
- ingredients: besan, spice

## DISH Q111025673
- name: Stoccafisso accomodato
- other names: {"it": "stoccafisso accomodato"}
- countries: IT
- kinds: fish dish

## DISH Q111025980
- name: Kosai
- description: food in West Africa
- countries: (none)
- cuisines: West African cuisine
- kinds: food

## DISH Q111032329
- name: Nyombeeka
- description: Vegetables food in Ghana
- countries: GH
- kinds: food

## DISH Q11103307
- name: Dongshan duck head
- other names: {"zh": "東山鴨頭"}
- countries: TW
- kinds: dish
- has Wikipedia article: zh

## DISH Q111038870
- name: Curry antillais aux bananes
- countries: (none)
- kinds: dish

## DISH Q111040548
- name: Curry in the United Kingdom
- other names: {"zh": "英國咖哩"}
- countries: GB
- cuisines: British cuisine
- kinds: curry, aspect in a geographic region
- has Wikipedia article: en, zh

## DISH Q111040626
- name: Pui Metuli Diye Amudi Macher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q111046463
- name: Obwarzanek krakowski
- other names: {"zh": "克拉科夫貝果"}
- description: braided ring-shaped bread product
- countries: PL
- kinds: obwarzanek, dish
- ingredients: Sesamum indicum, poppy seed, dough, table salt
- has Wikipedia article: en, zh

## DISH Q111084204
- name: Catatos
- description: Angolan fried caterpillar dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q11108995
- name: Xá Lợi Pagoda raids
- other names: {"zh": "查抄舍利寺"}
- description: series of attacks on Buddhist pagodas in South Vietnam on 21 August 1963 by the Army of the Republic of Vietnam Special Forces and combat police, ordered by Ngô Đình Nhu
- countries: (none)
- kinds: military operation, chicken nugget
- has Wikipedia article: en, zh

## DISH Q111092704
- name: Sfilacci
- description: type of processed red meat typical of the Veneto region in North Italy
- countries: IT
- kinds: human food
- ingredients: horse meat

## DISH Q111097996
- name: Kurume Yakitori
- description: local cuisine in Kurume, Fukuoka, Japan
- countries: (none)
- kinds: dish, yakitori

## DISH Q11113287
- name: Arem-Arem
- description: Indonesia traditional food from Central Java
- countries: ID
- cuisines: Indonesian cuisine
- kinds: traditional food, rice dish, food, dish, human food, type of food or dish
- ingredients: potato, minced meat, ragout, cooked rice, carrot
- has Wikipedia article: en

## DISH Q111133655
- name: Raw licorice
- countries: (none)
- kinds: licorice candy

## DISH Q11114189
- name: Cenil
- description: East Java traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: cassava root, coconut, coconut milk, food coloring, agar, table salt, sugar
- has Wikipedia article: en

## DISH Q111143066
- name: Supakatsu
- countries: JP
- kinds: dish

## DISH Q11117465
- name: Salt and pepper squid
- other names: {"zh": "椒鹽鮮魷"}
- countries: CN
- cuisines: Cantonese cuisine
- kinds: squid dish
- has Wikipedia article: zh

## DISH Q111182015
- name: Pan de cañada
- description: Spanish bread
- countries: ES
- cuisines: Aragonese cuisine
- kinds: bread
- has Wikipedia article: en

## DISH Q111190656
- name: Freiberger Bauerhase
- other names: {"de": "Freiberger Bauerhase"}
- countries: DE
- kinds: pastry

## DISH Q111207593
- name: Boudoir
- other names: {"fr": "boudoir"}
- countries: (none)
- kinds: Savoiarde PAT, biscuit
- ingredients: sponge cake

## DISH Q111207636
- name: Bucellatum
- other names: {"fr": "Bucellatum"}
- countries: (none)
- kinds: biscuit, hardtack

## DISH Q111207981
- name: Chebbakia de Rabat
- other names: {"fr": "chebbakia de Rabat"}
- countries: (none)
- kinds: dish

## DISH Q111209150
- name: Ganse
- other names: {"fr": "ganse"}
- countries: (none)
- kinds: dish

## DISH Q111209158
- name: Pächter's Healthcake
- countries: (none)
- kinds: pastry

## DISH Q111210031
- name: Lamdarbal
- other names: {"fr": "Lamdarbal"}
- countries: (none)
- kinds: dish

## DISH Q111210846
- name: Œufs au jus
- other names: {"fr": "œufs au jus"}
- countries: (none)
- kinds: dish

## DISH Q111211275
- name: Quiques
- other names: {"fr": "quiques"}
- countries: (none)
- kinds: culinary speciality

## DISH Q111211710
- name: Soupe de salade
- other names: {"fr": "soupe de salade"}
- countries: (none)
- kinds: soup

## DISH Q111211805
- name: Tarte brésilienne
- other names: {"fr": "tarte brésilienne"}
- countries: (none)
- kinds: cake

## DISH Q111227491
- name: Blueberry scone
- description: scone with blueberries
- countries: (none)
- kinds: scone
- ingredients: blueberry

## DISH Q111239919
- name: Champagnerkraut
- other names: {"de": "Champagnerkraut"}
- countries: (none)
- kinds: dish

## DISH Q111272426
- name: Mollete melenero
- description: typical street dish in Cuba
- countries: CU
- kinds: dish

## DISH Q111283137
- name: Olive bread
- description: bread with chopped olives
- countries: IT
- kinds: bread
- ingredients: olive
- has Wikipedia article: en

## DISH Q11128412
- name: 毛血旺
- description: Chongqing blood and tripe hotpot-style dish
- countries: CN
- cuisines: Chinese cuisine
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q111306412
- name: Shinko maki
- countries: (none)
- kinds: norimaki
- ingredients: tsukemono

## DISH Q111317807
- name: Bagharj
- description: Armenian sweet bread
- countries: AM
- cuisines: Armenian cuisine
- kinds: food, pastry
- ingredients: egg as food, flour, butter, table salt, sugar, water
- has Wikipedia article: en

## DISH Q111318005
- name: White gummy bear
- description: type of gummy bear
- countries: (none)
- kinds: gummy bear

## DISH Q111329417
- name: Laotan sauerkraut beef noodles
- other names: {"zh": "老坛酸菜牛肉面"}
- description: type of instant noodles
- countries: CN
- kinds: instant noodles, type of food or dish
- has Wikipedia article: zh

## DISH Q111335689
- name: Molasses Gulab
- countries: EG
- kinds: pastry

## DISH Q111356050
- name: Natto-maki
- countries: (none)
- kinds: makizushi
- ingredients: nattō

## DISH Q111365597
- name: Taco árabe
- description: Mexican dish
- countries: MX
- kinds: taco, antojito
- ingredients: lamb meat

## DISH Q11137498
- name: Steam Pot Chicken
- other names: {"zh": "汽锅鸡"}
- countries: CN
- kinds: chicken dish
- has Wikipedia article: zh

## DISH Q111381747
- name: Tumact me tulez
- description: pasta dish from Basilicata, Italy
- countries: (none)
- cuisines: cuisine of Basilicata
- kinds: dish
- ingredients: pasta
- has Wikipedia article: en

## DISH Q111398890
- name: Totoposte
- countries: MX
- kinds: flatbread, tortilla
- ingredients: maize, lard, table salt, water

## DISH Q111398939
- name: Tamal de bola
- other names: {"es": "Tamal de bola"}
- countries: MX
- kinds: food, antojito, tamale
- ingredients: corn husk, maize, Pipián, mole, chicken soup, masa, pork, lard

## DISH Q11140708
- name: Shacha noodle
- other names: {"zh": "沙茶面"}
- description: Chinese noodle dish
- countries: CN
- kinds: noodle soup
- has Wikipedia article: en, zh

## DISH Q11141042
- name: Cimol
- description: Typical Sundanese snacks
- countries: ID
- cuisines: Indonesian cuisine
- kinds: street food, dish, human food, type of food or dish
- ingredients: chili powder, tapioca

## DISH Q11142810
- name: Cilok
- description: Sundanese boiled or fried tapioca flour balls
- countries: ID
- cuisines: Indonesian cuisine
- kinds: street food, dish, human food, type of food or dish
- ingredients: tapioca flour, wheat flour, tapioca, table salt
- has Wikipedia article: en

## DISH Q111432206
- name: Грибная икра
- other names: {"ru": "Грибная икра"}
- countries: RU, BY
- cuisines: Russian cuisine, Belarusian cuisine
- kinds: spread, convenience food, mushroom dish
- ingredients: dried mushrooms, onion

## DISH Q111443336
- name: Fyrstekake
- description: pound cake
- countries: NO
- kinds: pound cake
- ingredients: shortcrust pastry
- has Wikipedia article: en

## DISH Q11144465
- name: Cireng
- description: Indonesian fritters
- countries: ID
- cuisines: Indonesian cuisine
- kinds: street food, food, dish
- ingredients: table salt, water, garlic, wheat, tapioca, scallion, cooking oil, black pepper, Apium graveolens

## DISH Q111446124
- name: Jukti fuler chorchori
- countries: (none)
- kinds: charchari

## DISH Q111446143
- name: Jukti Phooler Bora
- description: bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q1114674
- name: Tomato purée
- other names: {"zh": "纯番茄汁"}
- description: tomato based food
- countries: IT
- kinds: purée, preserved food, tomato dish
- ingredients: tomato
- has Wikipedia article: en, zh

## DISH Q11147805
- name: Nagashi sōmen
- other names: {"zh": "流水麵"}
- description: Japanese noodle dish
- countries: JP
- kinds: sōmen, noodle dish
- has Wikipedia article: en, zh

## DISH Q111494142
- name: Negitoro maki
- countries: JP
- kinds: norimaki, type of food or dish

## DISH Q11149430
- name: 浮水虱目魚羹
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q11151345
- name: Navy curry
- other names: {"zh": "海軍咖喱"}
- description: form of Japanese curry
- countries: JP
- kinds: Japanese curry, food
- has Wikipedia article: zh

## DISH Q111515886
- name: とて焼
- other names: {"ja": "とて焼"}
- countries: JP
- kinds: dish
- ingredients: chicken egg, cow's milk, wheat flour

## DISH Q1115198
- name: Nocciolini di Chivasso
- description: Italian meringue cookies
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q111524317
- name: Vegan kebab
- countries: (none)
- kinds: dish, vegan product

## DISH Q11153171
- name: Shenkeng tofu
- other names: {"zh": "深坑豆腐"}
- countries: TW
- kinds: dish, snack
- ingredients: tofu
- has Wikipedia article: zh

## DISH Q111544307
- name: Bread roll pizzas
- description: Bread rolls that are gratinated with a topping or filled with ingredients similar to those on a pizza
- countries: (none)
- kinds: bread roll

## DISH Q111551122
- name: Haferflockensuppe
- other names: {"de": "Haferflockensuppe"}
- countries: (none)
- kinds: soup, dish, Bland diet

## DISH Q111575659
- name: Curd-cheese doughnuts
- countries: (none)
- kinds: doughnut

## DISH Q111589037
- name: Nimame
- other names: {"zh": "煮豆子"}
- countries: (none)
- kinds: nimono
- ingredients: bean

## DISH Q111589124
- name: Chicken fillet roll
- description: hot chicken fillet in a roll
- countries: IE
- kinds: chicken dish, bread dish, sandwich
- ingredients: chicken as food, bread
- has Wikipedia article: en

## DISH Q111604426
- name: Tarempa noodles
- description: traditional noodle dish from Riau Islands, Indonesia
- countries: ID
- cuisines: Riau Islands
- kinds: noodle, street food, jajan pasar, food, fast food, dish, type of food or dish
- ingredients: Thunnus tonggol, seafood, noodle, egg as food
- has Wikipedia article: en

## DISH Q111609502
- name: Chausson aux pommes
- other names: {"zh": "绍松欧波姆"}
- description: French pastry filled with applesauce
- countries: FR
- kinds: apple turnover
- ingredients: puff pastry, apple
- has Wikipedia article: en

## DISH Q111609577
- name: Apfeltaschen
- countries: (none)
- kinds: apple turnover

## DISH Q11161
- name: Lyonnaise potatoes
- description: French dish of sliced pan-fried potatoes and thinly sliced onions sautéed in butter with parsley
- countries: FR
- cuisines: French cuisine
- kinds: culinary speciality, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q11162
- name: Ciccioli
- description: traditional Italian dish
- countries: IT
- kinds: cracklings, dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q111628882
- name: Torta de pellizco
- description: Typical cake from Ubrique and Alcalá de los Gazules, Spain
- countries: ES
- kinds: dessert, torta
- ingredients: anise seed, seed oil, wheat flour, lemon, olive oil, yeast, Pimpinella anisum, cinnamon, sugar

## DISH Q111653031
- name: Te tuae
- description: Dried Pandanus Paste from Kiribati
- countries: (none)
- kinds: fruit dish
- ingredients: Pandanus tectorius
- has Wikipedia article: en

## DISH Q111674044
- name: 구슬 아이스크림
- other names: {"ko": "구슬 아이스크림"}
- description: ice cream with bead shape
- countries: US
- kinds: ice cream

## DISH Q11168485
- name: Regañao
- description: topped flatbread typical of the Teruel area in Spain
- countries: ES
- cuisines: Aragonese cuisine
- kinds: bread
- has Wikipedia article: en

## DISH Q111687252
- name: Pan Sobado de La Rioja
- description: Spanish bread
- countries: (none)
- kinds: bread

## DISH Q111705550
- name: Taco pizza
- description: pizza with taco ingredients
- countries: MX
- kinds: dish
- ingredients: taco
- has Wikipedia article: en

## DISH Q111708336
- name: Cagouilles à la charentaise
- countries: FR
- kinds: human food
- ingredients: Helix aspersa

## DISH Q1117173
- name: Sarde in saor PAT
- other names: {"zh": "Sarde in saor PAT"}
- description: traditional Italian fish, mollusc or crustacean product (PAT)
- countries: IT
- cuisines: cuisine of Veneto
- kinds: seafood, dish, antipasto
- ingredients: European pilchard, onion
- has Wikipedia article: en

## DISH Q111724269
- name: Bean stew
- countries: (none)
- kinds: stew, legume dish

## DISH Q11172495
- name: Fish tofu
- other names: {"zh": "鱼豆腐"}
- description: fish product
- countries: CN
- kinds: fish dish
- has Wikipedia article: en, zh

## DISH Q11172505
- name: 魚酥
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q11172760
- name: Dace fish ball
- other names: {"zh": "鯪魚球"}
- countries: (none)
- kinds: meatball
- ingredients: mud carp
- has Wikipedia article: zh

## DISH Q11173321
- name: Chinese flower cake
- other names: {"zh": "鲜花饼"}
- countries: CN
- kinds: Chinese bakery product
- has Wikipedia article: zh

## DISH Q11174346
- name: Chicken and duck blood soup
- other names: {"zh": "鸡鸭血汤"}
- description: Shanghainese soup-based blood dish, using the blood of chicken and duck as a principal ingredient
- countries: (none)
- kinds: blood soup, chicken dish
- ingredients: chicken as food, duck meat
- has Wikipedia article: en, zh

## DISH Q11174489
- name: 鸭赏
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q111745712
- name: Zagłębiowska zalewajka
- other names: {"pl": "zagłębiowska zalewajka"}
- countries: (none)
- kinds: zalewajka
