# Review batch names-043

## DISH Q43731854
- name: Fried dog meat
- other names: {"zh": "炸蒸狗肉"}
- description: Chinese dish
- countries: (none)
- kinds: dish
- ingredients: dog meat

## DISH Q43731937
- name: Jugged dog meat
- other names: {"zh": "瓦罐香狗肉"}
- countries: (none)
- kinds: dish
- ingredients: dog meat

## DISH Q43732009
- name: Hot and sour dog meat
- other names: {"zh": "酸辣狗肉"}
- countries: (none)
- kinds: dish
- ingredients: dog meat

## DISH Q43732163
- name: Lingchuan dog meat
- other names: {"zh": "灵川狗肉"}
- countries: (none)
- kinds: dish
- ingredients: dog meat

## DISH Q43732309
- name: Binyang dog leg dish
- other names: {"zh": "宾阳狗脚"}
- countries: (none)
- kinds: dish
- ingredients: dog meat

## DISH Q43732501
- name: Braised dog meat and tofu
- other names: {"zh": "狗肉炖豆腐"}
- description: Chinese dish
- countries: (none)
- kinds: dish
- ingredients: dog meat, tofu

## DISH Q4373369
- name: Heotjesabap
- other names: {"zh": "假祭祀飯"}
- description: Korean bibimbap variant
- countries: (none)
- kinds: bibimbap, dish
- has Wikipedia article: en, zh

## DISH Q43736933
- name: Flower River Dog Meat
- other names: {"zh": "花江狗肉"}
- countries: (none)
- kinds: dish
- ingredients: dog meat

## DISH Q43768843
- name: Babarsa
- description: sweet of West Bengal
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q4377047
- name: Borș
- description: sour liquid made from fermented wheat or barley bran used in Romanian and Moldovan cuisine to make soups
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q43770676
- name: Pan dei morti
- description: Italian cake for All Saints' Day celebrations
- countries: (none)
- cuisines: Lombard cuisine
- kinds: pastry
- ingredients: candied fruit, cocoa powder, egg white, fortified wine, pine nut, almond, spice, flour, biscuit, sugar

## DISH Q4381008
- name: Philadelphia roll
- other names: {"zh": "费城卷"}
- description: type of sushi
- countries: US
- kinds: uramakizushi
- ingredients: smoked salmon, cream cheese
- has Wikipedia article: en

## DISH Q4381357
- name: Jucy Lucy
- other names: {"zh": "多汁露西"}
- description: cheeseburger that has the cheese inside the meat patty instead of on top, resulting in a melted core of cheese within the patty
- countries: US
- kinds: hamburger, cheeseburger
- ingredients: cheese, hamburger
- has Wikipedia article: en

## DISH Q4381782
- name: Chạo tôm
- other names: {"zh": "蔗蝦"}
- description: Vietnamese dish of shrimp surimi grilled on a sugar cane stick
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: shrimp dish
- has Wikipedia article: en, zh

## DISH Q4382275
- name: Pot pie
- other names: {"zh": "锅派"}
- description: type of savory pie, often with meat
- countries: (none)
- kinds: meat pie
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q4383705
- name: Bread sauce
- description: Sauce made with milk and bread crumbs
- countries: GB
- cuisines: British cuisine
- kinds: food, sauce, condiment, use of bread
- has Wikipedia article: en

## DISH Q4384100
- name: Lahpet thohk
- other names: {"zh": "茶叶拌豆"}
- description: Burmese dish of tea leaves
- countries: MM
- kinds: food, Burmese salad
- ingredients: lahpet
- has Wikipedia article: zh

## DISH Q4385016
- name: Saimin
- other names: {"zh": "夏威夷細麵"}
- description: Hawaiian noodle soup dish
- countries: US
- kinds: food, noodle soup
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q4388197
- name: Ikayaki
- other names: {"zh": "烤鱿鱼"}
- description: Japanese grilled squid
- countries: JP
- kinds: squid dish
- ingredients: Teuthida
- has Wikipedia article: en

## DISH Q4388689
- name: Bialy
- description: yeasted bread roll
- countries: PL
- kinds: food, yeast bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q4389530
- name: Ehōmaki
- other names: {"zh": "惠方卷"}
- description: sushi roll eaten during setsubun
- countries: JP
- kinds: futomaki
- ingredients: Datemaki, cucumber, nori, rice
- has Wikipedia article: zh

## DISH Q4390491
- name: Rasstegai
- description: Russian pastry
- countries: RU
- kinds: food, pastry, dish
- ingredients: yeast dough
- has Wikipedia article: en

## DISH Q4390825
- name: Mechado
- description: Filipino dish
- countries: PH
- kinds: viand, beef dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q4391495
- name: Paila marina
- description: Chilean stew
- countries: CL
- kinds: food, seafood dish
- ingredients: tomato, potato, shellfish, fish stock, fish as food, oil, onion, Allium sativum, table salt, white wine, Capsicum annuum, carrot
- has Wikipedia article: en

## DISH Q4391949
- name: Maple bacon donut
- description: dessert food
- countries: US
- kinds: doughnut
- ingredients: dough
- has Wikipedia article: en

## DISH Q4393189
- name: Remojón
- other names: {"es": "remojón"}
- countries: (none)
- cuisines: cuisine of the province of Almería
- kinds: salad

## DISH Q4401133
- name: Ichigoni
- description: Japanese seafood soup
- countries: JP
- kinds: suimono
- ingredients: uni, Haliotis

## DISH Q4405673
- name: Salamata
- description: Russian porridge
- countries: RU
- cuisines: Russian cuisine
- kinds: porridge

## DISH Q4405719
- name: Snickers salad
- description: US dessert dish of Snickers bars, apples, and whipped cream
- countries: US
- kinds: dessert salad
- ingredients: Snickers
- has Wikipedia article: en

## DISH Q44080298
- name: Banglar Rosogolla
- description: sweet of Bengal
- countries: (none)
- kinds: confectionery, rosogolla
- ingredients: chhena, jaggery, sugar, milk

## DISH Q440884
- name: Schwenker
- description: dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q44130098
- name: Nabadwip’s Red Curd
- description: Sweets of Bengal
- countries: (none)
- kinds: Mishti doi, confectionery
- has Wikipedia article: en

## DISH Q4413207
- name: Nävgröt
- description: Värmland porridge made from rye flour and served with pork and lingonberry jam
- countries: (none)
- kinds: dish

## DISH Q44192309
- name: Aporreadillo
- description: Mexican dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q4421267
- name: Sichenyky
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: dish
- ingredients: fish as food, egg as food, meat

## DISH Q4425232
- name: Smorodinówka
- other names: {"pl": "Smorodinówka"}
- countries: (none)
- kinds: dish

## DISH Q4425569
- name: Снежок
- other names: {"ru": "Снежок"}
- countries: SU
- kinds: yogurt, fermented milk product, fermented milk products, other than sour cream and cottage cheese
- ingredients: Lactobacillus delbrueckii subsp. bulgaricus, milk

## DISH Q4426758
- name: Fermented bean paste
- other names: {"zh": "豆醬"}
- description: fermented foods made from ground soybeans
- countries: (none)
- kinds: fermented food, bean paste
- has Wikipedia article: en, zh

## DISH Q4430349
- name: Сочиво
- other names: {"ru": "сочиво"}
- countries: (none)
- kinds: dish

## DISH Q443962
- name: Capuns
- description: Stuffed chard leaves from Swiss cuisine
- countries: CH
- kinds: dumpling, cabbage roll
- ingredients: dried meat, chard, spätzle
- has Wikipedia article: en

## DISH Q4443389
- name: Strasbourg pie
- countries: (none)
- kinds: dish
- ingredients: truffle, Testrates, pork

## DISH Q4445281
- name: Sugudai
- description: Russian fish dish
- countries: RU
- kinds: raw fish dish
- ingredients: raw fish

## DISH Q4448062
- name: Cheese soup
- other names: {"zh": "起司濃湯"}
- description: type of soup
- countries: (none)
- kinds: soup
- ingredients: cheese
- has Wikipedia article: en, zh

## DISH Q44506308
- name: Injo-gogi-bap
- description: North Korean food dish
- countries: KP
- cuisines: North Korean cuisine
- kinds: dish
- ingredients: injo-gogi, bap
- has Wikipedia article: en

## DISH Q4451119
- name: Tandyr kebab
- other names: {"zh": "馕坑烤肉"}
- countries: CN
- cuisines: Uyghur cuisine
- kinds: dish
- has Wikipedia article: zh

## DISH Q4452497
- name: Soto Bandung
- description: Indonesian traditional soup dish
- countries: ID
- kinds: food, soup, soto

## DISH Q44541
- name: Pancake
- other names: {"zh": "薄烤饼"}
- description: a brown thin, round cake made of eggs, milk and flour
- countries: US
- cuisines: French cuisine, Russian cuisine, Austrian cuisine, Polish cuisine
- kinds: dish, quick bread, Batter bread, battercake, pancake
- ingredients: egg as food, oil, flour, milk
- has Wikipedia article: en, zh

## DISH Q4456752
- name: Tetyorki cookies
- countries: RU
- cuisines: Russian cuisine
- kinds: cookie, pryanik
- ingredients: rye flour

## DISH Q4462874
- name: Three Pies
- countries: (none)
- cuisines: Ossetian cuisine
- kinds: dish
- ingredients: Ossetian pies

## DISH Q446578
- name: Arrosticini
- description: lamb dish
- countries: IT
- cuisines: Abruzzese cuisine
- kinds: lamb dish, skewer
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q447296
- name: Aloo gobi
- description: Indian curry dish with cauliflower and potatoes
- countries: IN
- kinds: potato dish, Indian curry
- ingredients: cauliflower, potato
- has Wikipedia article: en

## DISH Q448043
- name: Hangikjöt
- other names: {"zh": "吊肉"}
- description: lamb dish
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q44835923
- name: Печенье, но не галеты и крекеры
- other names: {"ru": "печенье, но не галеты и крекеры"}
- countries: (none)
- kinds: flour confectionery products

## DISH Q44843044
- name: Шоколад и шоколадные изделия
- other names: {"ru": "шоколад и шоколадные изделия"}
- countries: (none)
- kinds: chocolate and sugar confectionery, Sweet confectionery products (ОКП 91 2000)

## DISH Q449011
- name: Instant soup
- other names: {"zh": "速食湯"}
- description: soup designed for fast and simple preparation
- countries: (none)
- kinds: soup, instant food, product, convenience food
- has Wikipedia article: en, zh

## DISH Q44909552
- name: Fischbeuschelsuppe
- other names: {"de": "Fischbeuschelsuppe"}
- countries: AT
- cuisines: Austrian cuisine
- kinds: dish

## DISH Q4493304
- name: Cocktail bun
- other names: {"zh": "雞尾包"}
- description: Sweet bun with coconut
- countries: HK
- kinds: food, sweet roll
- ingredients: Cocos nucifera
- has Wikipedia article: en, zh

## DISH Q449506
- name: Goat meat
- other names: {"zh": "山羊肉"}
- description: meat from the domestic goat used as food
- countries: (none)
- kinds: meat, goat meat dish, bovid meat
- has Wikipedia article: en, zh

## DISH Q4497819
- name: Khinkal
- description: traditional Caucasian dish
- countries: (none)
- kinds: dish
- ingredients: lamb meat, flour, table salt, water
- has Wikipedia article: en

## DISH Q4499369
- name: Aukstā zupa
- description: cold beet soup
- countries: LV
- kinds: soup, cold sweet soup
- ingredients: hard-boiled egg, kefir, beet, Cucumis sativus

## DISH Q4499565
- name: Milanesa napolitana
- description: Argentinean meat dish
- countries: (none)
- kinds: beef dish
- ingredients: Milanesa

## DISH Q4501320
- name: Khrenovina
- description: horseradish-based sauce in Russian cuisine
- countries: RU
- cuisines: Russian cuisine
- kinds: dish, horseradish sauce
- ingredients: garlic clove, garlic, tomato, horseradish root, salt
- has Wikipedia article: en

## DISH Q4502669
- name: Khychyn
- countries: (none)
- kinds: dish

## DISH Q4503220
- name: Bomba toledana
- description: Typical tapas from Toledo, Spain
- countries: (none)
- kinds: potato dish

## DISH Q4506424
- name: Chicken tabaka
- other names: {"zh": "打平鸡"}
- description: chicken dish
- countries: GE
- cuisines: Georgian cuisine, Soviet cuisine
- kinds: chicken dish, food
- ingredients: chicken as food, smetana, Tkemali
- has Wikipedia article: en, zh

## DISH Q4506872
- name: Chakapuli
- description: Georgian stew
- countries: GE
- cuisines: Georgian cuisine
- kinds: lamb dish
- ingredients: plum, Anethum, lamb meat, Petroselinum, tarragon, Tkemali, Coriandrum sativum, onion, Allium sativum, salt
- has Wikipedia article: en

## DISH Q451039
- name: Leipziger Allerlei
- description: Vegetable dish, also with crab or chicken
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q45136345
- name: Paillasson de l'Isle d'Orléans
- other names: {"fr": "Paillasson de l'Isle d'Orléans"}
- countries: (none)
- kinds: cow's-milk cheese, artisan cheese, Cheese in Canada, pasteurized milk cheese, cheese from Quebec
- ingredients: cow's milk

## DISH Q4515956
- name: Chilindrón
- countries: (none)
- kinds: stew

## DISH Q4516114
- name: Chipwich
- description: ice cream sandwich
- countries: (none)
- kinds: ice cream sandwich
- ingredients: ice cream
- has Wikipedia article: en

## DISH Q45164783
- name: Postej
- other names: {"da": "postej"}
- description: type of paté made from meat, liver, or fish
- countries: (none)
- kinds: pâté, food

## DISH Q4516736
- name: Chikhirtma
- other names: {"zh": "奇希爾圖馬"}
- description: traditional Georgian chicken soup
- countries: GE
- kinds: food, soup
- ingredients: maize flour, mutton, turkey meat, lemon, chicken as food, egg as food, spice
- has Wikipedia article: en, zh

## DISH Q4517033
- name: Chogi
- description: Georgian salad
- countries: GE
- kinds: salad
- ingredients: Beta, Cornus, Allium

## DISH Q4518649
- name: Beluga caviar
- other names: {"zh": "白鱘魚子醬"}
- description: caviar made of the roe of the beluga sturgeon (Huso huso)
- countries: (none)
- kinds: caviar
- has Wikipedia article: en

## DISH Q4520152
- name: Shanga
- description: open pies in Komi, Mari, Russian and Udmurt cuisines
- countries: RU
- cuisines: Russian cuisine, Mari cuisine, Udmurt cuisine
- kinds: pirog
- ingredients: flour

## DISH Q4522744
- name: Shelpek
- description: kazakh flatbread, using butter, milk and sugar
- countries: KZ
- kinds: dish
- ingredients: vegetable oil, baker's yeast, sour cream, sodium bicarbonate, flour, butter, table salt, sugar, milk
- has Wikipedia article: en

## DISH Q452383
- name: Lübeck Marzipan
- description: regional marzipan speciality
- countries: DE
- kinds: marzipan, food product
- ingredients: Pasta di mandorle PAT, sugar
- has Wikipedia article: en

## DISH Q4526137
- name: Char siu rice
- other names: {"zh": "叉烧饭"}
- description: rice dish in Hong Kong
- countries: CN
- kinds: rice dish
- ingredients: char siu, cooked rice
- has Wikipedia article: zh

## DISH Q453174
- name: Onsen tamago
- other names: {"zh": "溫泉蛋"}
- description: egg dish
- countries: JP
- kinds: coddled egg, dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q4531863
- name: Slavink
- description: meat dish
- countries: (none)
- kinds: pork dish, roll
- ingredients: minced meat, pork, bacon
- has Wikipedia article: en

## DISH Q45344116
- name: KafBikh
- description: Traditional Iranian sweet
- countries: IR
- kinds: dish
- ingredients: sweetmeat, plant-based diet
- has Wikipedia article: en

## DISH Q4535039
- name: Yurma
- countries: RU
- cuisines: Russian cuisine, Komi cuisine
- kinds: dish
- ingredients: bouillon, fish as food, meat, chicken

## DISH Q453741
- name: Leipziger Lerche
- description: Pastry from Leipzig, Saxony, Germany
- countries: DE
- kinds: pastry
- ingredients: shortcrust pastry, jam
- has Wikipedia article: en

## DISH Q4543774
- name: Bolado
- other names: {"es": "bolado"}
- countries: ES
- kinds: dessert

## DISH Q4544654
- name: Mala
- other names: {"zh": "麻辣"}
- description: Spicy Chinese sauce
- countries: CN
- kinds: taste, condiment
- has Wikipedia article: en, zh

## DISH Q4545971
- name: Gelatin dessert
- other names: {"zh": "果冻"}
- description: dessert made with gelatin
- countries: GB
- kinds: dessert with spoon
- ingredients: gelatin
- has Wikipedia article: en, zh

## DISH Q4550892
- name: 15 bean soup
- description: packaged dry bean soup product from the N.K. Hurst Co.
- countries: US
- kinds: food, soup
- ingredients: lentil, chickpea, kidney bean, navy bean, black turtle bean, black-eyed pea, split pea, Phaseolus lunatus, pinto bean
- has Wikipedia article: en

## DISH Q4560594
- name: Layered cream cake
- description: type of cake especially common in the Nordic region
- countries: (none)
- kinds: cake
- ingredients: sponge cake, whipped cream
- has Wikipedia article: en

## DISH Q457255
- name: Frankfurter Kranz
- description: German buttercream cake from Frankfurt
- countries: DE
- kinds: sponge cake, viennoiserie
- ingredients: Biscuit preparation, pâte sablée
- has Wikipedia article: en

## DISH Q45746754
- name: Risotto col puntèl
- countries: (none)
- kinds: risotto
- has Wikipedia article: en

## DISH Q45790414
- name: Mie cakalang
- description: Indonesian traditional noodle
- countries: ID
- kinds: food, main course
- has Wikipedia article: en

## DISH Q45809044
- name: Kheer
- description: Indian dessert
- countries: (none)
- kinds: food, dessert
- has Wikipedia article: en

## DISH Q45849
- name: Pastel de Tentúgal
- description: Portuguese pastry
- countries: PT
- kinds: pastry
- ingredients: doce de ovos, dough
- has Wikipedia article: en

## DISH Q4589121
- name: Boknafisk
- description: Variant of stockfish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q45901803
- name: Chapssal doughnut
- description: Korean sweet glutinous rice doughnuts
- countries: (none)
- kinds: doughnut
- ingredients: wheat flour, red bean paste, glutinous rice, baking powder, table salt, sugar
- has Wikipedia article: en

## DISH Q45912917
- name: Cocoa
- description: good, condiment, flavor, food ingredient or product solid derived from Theobroma cacao; precursor of commercial chocolates
- countries: (none)
- kinds: condiment, intermediate good, flavoring, food ingredient, chocolate

## DISH Q46070600
- name: Sườn nướng
- description: Vietnamese grilled pork ribs
- countries: VN
- kinds: meat dish
- ingredients: spare ribs
- has Wikipedia article: en

## DISH Q4609537
- name: 2007 Vietnam food scare
- description: food contamination event in Vietnam
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q461919
- name: Kurume ramen
- countries: (none)
- kinds: tonkotsu ramen

## DISH Q46208
- name: Swiss wing
- other names: {"zh": "瑞士雞翼"}
- description: chicken wing dish of Hong Kong
- countries: CN, HK
- kinds: chicken dish
- ingredients: Swiss sauce, chicken wing, chicken as food
- has Wikipedia article: en, zh

## DISH Q46324654
- name: Deram-deram
- countries: ID
- kinds: dish

## DISH Q46349219
- name: Injo-gogi
- description: North Korean mock meat
- countries: KP
- cuisines: North Korean cuisine
- kinds: meat alternative, soy food
- ingredients: soybean meal

## DISH Q463872
- name: Ketwurst
- description: style of hot dog created in the GDR
- countries: DD
- cuisines: cuisine of the German Democratic Republic
- kinds: hot dog
- ingredients: bockwurst, ketchup, bread roll
- has Wikipedia article: en

## DISH Q464545
- name: Chinmi
- description: Japanese delicacies
- countries: JP
- kinds: dish
- has Wikipedia article: en

## DISH Q4646989
- name: A-gei
- other names: {"zh": "淡水阿给"}
- description: Taiwanese dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish, type of food or dish
- ingredients: fried tofu, cellophane noodles
- has Wikipedia article: en, zh

## DISH Q464826
- name: Matsumaezuke
- description: Japanese pickles
- countries: JP
- kinds: tsukemono, seafood dish
- ingredients: kombu, kazunoko, dried shredded squid
- has Wikipedia article: en

## DISH Q46485609
- name: Zillertaler Krapfen
- other names: {"de": "Zillertaler Krapfen"}
- countries: (none)
- kinds: dish

## DISH Q4652020
- name: AIV fodder
- description: type of silage
- countries: FI
- kinds: fodder
- has Wikipedia article: en

## DISH Q4661429
- name: Aam papad
- description: fruit leather made out of mango pulp
- countries: IN
- kinds: dessert
- ingredients: mango
- has Wikipedia article: en

## DISH Q46623421
- name: Veneziana
- description: Italian sweet pastry
- countries: IT
- kinds: bread, confectionery
- ingredients: candied fruit, egg as food, flour, butter, sugar
- has Wikipedia article: en

## DISH Q4667156
- name: Abernethy biscuit
- description: biscuit
- countries: (none)
- kinds: biscuit
- ingredients: hardtack
- has Wikipedia article: en

## DISH Q46705956
- name: Speculaaspop
- other names: {"nl": "Speculaaspop"}
- countries: (none)
- kinds: speculaas biscuit

## DISH Q4670754
- name: Kintsuba
- description: Japanese candy
- countries: (none)
- kinds: wagashi

## DISH Q46707672
- name: Hong dou tang
- other names: {"zh": "紅豆湯"}
- description: dessert
- countries: CN
- cuisines: Cantonese cuisine, Chinese cuisine
- kinds: dessert
- ingredients: Vigna angularis
- has Wikipedia article: en, zh

## DISH Q4674231
- name: Ackee and saltfish
- other names: {"zh": "阿開木煮鹹魚"}
- description: Jamaican national dish
- countries: JM
- kinds: fish dish, meal
- ingredients: dried and salted cod, Blighia sapida
- has Wikipedia article: en, zh

## DISH Q4674758
- name: Acqua pazza
- description: Italian cuisine
- countries: IT
- kinds: fish dish
- ingredients: parsley, garlic, tomato, oil, fish
- has Wikipedia article: en

## DISH Q467545
- name: Pla ra
- description: Southeast Asian fermented fish seasoning
- countries: TH
- kinds: fish sauce
- ingredients: rice bran, fermented fish, rice flour
- has Wikipedia article: en

## DISH Q4675762
- name: Head cheese
- other names: {"zh": "頭肉凍塊"}
- description: cold cut non-dairy meat jelly or terrine
- countries: CH, CN, IT
- kinds: cold cut, charcuterie, dish, aspic, meat dish, Sülzwurst
- has Wikipedia article: en

## DISH Q46811683
- name: Jungguk-naengmyeon
- description: korean-Chinese noodle dish
- countries: KR
- cuisines: Korean Chinese cuisine
- kinds: naengmyeon, noodle soup
- has Wikipedia article: en

## DISH Q4683966
- name: Adobada
- description: Mexican dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q4684013
- name: Adobe bread
- description: type of oven bread from southwest USA
- countries: US
- kinds: food, bread
- has Wikipedia article: en

## DISH Q4689116
- name: Afghan biscuit
- description: traditional New Zealand biscuit containing cornflakes and cocoa powder, topped with chocolate icing and walnut
- countries: NZ
- kinds: biscuit
- ingredients: cocoa powder, corn flakes, walnut, flour, butter, sugar
- has Wikipedia article: en

## DISH Q4689119
- name: Afghan bread
- other names: {"zh": "阿富汗麵餅"}
- description: national bread of Afghanistan
- countries: AF
- kinds: food, flatbread
- has Wikipedia article: en, zh

## DISH Q46925983
- name: Kerstkransje
- other names: {"nl": "kerstkransje"}
- countries: (none)
- kinds: confectionery

## DISH Q4698754
- name: Airline chicken
- description: food dish composed of a boneless chicken breast with the drumette attached
- countries: (none)
- kinds: chicken dish
- ingredients: chicken breast
- has Wikipedia article: en

## DISH Q4699128
- name: Aish merahrah
- description: flatbread made with ground fenugreek seeds and maize
- countries: EG
- kinds: food, flatbread
- ingredients: Trigonella foenum-graecum
- has Wikipedia article: en

## DISH Q46995215
- name: Борщ польскый
- other names: {"rue": "Борщ польскый"}
- countries: (none)
- kinds: borscht

## DISH Q4699691
- name: Ajdov Kruh
- description: Slovenian bread
- countries: SI
- kinds: flatbread
- ingredients: buckwheat seed
- has Wikipedia article: en

## DISH Q4699709
- name: Ajethna
- countries: IN
- kinds: food, Indian curry
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q4700271
- name: Akanes
- description: regional Greek Sweet (from Serres)
- countries: GR
- kinds: confectionery
- ingredients: starch
- has Wikipedia article: en

## DISH Q47002773
- name: Chestnut tagliatelle
- countries: (none)
- kinds: tagliatelle
- ingredients: chestnut flour

## DISH Q47004156
- name: Nabari Gyujiru
- description: beef soup
- countries: (none)
- kinds: shirumono
- ingredients: Iga beef

## DISH Q47004974
- name: Okoho
- description: Nigerian soup
- countries: NG
- kinds: soup, food, dish
- has Wikipedia article: en

## DISH Q47005562
- name: Mfarakeh
- description: Arab dish of potato, egg, ghee, cumin, salt, pepper, and coriander leaves, served as part of a mezze
- countries: (none)
- kinds: dish
- ingredients: potato, egg as food
- has Wikipedia article: en

## DISH Q47005642
- name: Ewa Agoyin
- description: delicacy of the Agoyin people from the Republic of Benin and popular in Lagos, Nigeria
- countries: NG
- kinds: street food, food, dish
- ingredients: bean
- has Wikipedia article: en

## DISH Q4701369
- name: Akki rotti
- other names: {"zh": "米羅提"}
- description: karnataka Cuisine
- countries: IN
- kinds: roti, rice dish, flatbread
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q4701955
- name: Akumaki
- other names: {"zh": "鹼粽"}
- description: Japanese-style confection, which is made in South Kyushu
- countries: JP
- kinds: mochi, wagashi
- ingredients: Bambusoideae, glutinous rice
- has Wikipedia article: en

## DISH Q4701981
- name: Akuri
- description: Persian and Indian Parsi dish of scrambled eggs with mint or coriander and turmeric
- countries: IN
- cuisines: Indian cuisine, Iranian cuisine
- kinds: dish
- ingredients: coriander seed, turmeric, scrambled eggs
- has Wikipedia article: en

## DISH Q4703104
- name: Se'i
- description: Indonesian dish
- countries: ID
- kinds: smoking, Indonesian cuisine, meal, pork dish, beef dish, food, dish, human food
- ingredients: pork, black pepper, Allium sativum, table salt
- has Wikipedia article: en

## DISH Q4703440
- name: Lalap
- other names: {"zh": "拉拉柏"}
- description: Indonesian raw vegetable salad
- countries: ID
- kinds: salad
- has Wikipedia article: en

## DISH Q47038431
- name: Elarji
- description: Georgian cheese-based dish
- countries: GE
- kinds: kasha
- ingredients: Sulguni, maize, table salt, water
- has Wikipedia article: en

## DISH Q470519
- name: Mochi
- other names: {"zh": "麻糬"}
- description: Japanese rice cake made of mochigome
- countries: (none)
- kinds: wagashi, Japanese rice dish, glutinous rice cake
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q4705519
- name: Alaea salt
- description: unrefined sea salt mixed with a red alae volcanic clay
- countries: US
- kinds: table salt
- has Wikipedia article: en

## DISH Q47089226
- name: Sukhoe
- description: blanched seafood, vegetables, or offals
- countries: (none)
- kinds: hoe
- has Wikipedia article: en

## DISH Q4720543
- name: Alexandertorte
- other names: {"zh": "亞歷山大蛋糕"}
- description: dessert
- countries: LV
- kinds: pastry
- ingredients: raspberry jam, dough, hagelslag, icing
- has Wikipedia article: en, zh

## DISH Q473108
- name: Ammerländer Schinken
- description: North German ham
- countries: (none)
- kinds: smoked ham
- has Wikipedia article: en

## DISH Q473202
- name: Majorero cheese PDO
- description: Spanish protected designation of origin for cheese from Fuerteventura
- countries: ES
- kinds: food, cheese, goat cheese, Spanish cheese, Protected designation of origin
- ingredients: goat milk
- has Wikipedia article: en

## DISH Q47325100
- name: Far aux pruneaux
- other names: {"fr": "Far aux pruneaux"}
- countries: (none)
- kinds: Far Breton

## DISH Q473271
- name: Pepernoot
- description: tiny Dutch cookie made from many rich ingredients
- countries: NL
- cuisines: Dutch cuisine
- kinds: Strooigoed, dish
- ingredients: anise seed, clove, rye flour, peppercorn, nutmeg, butter, cinnamon, honey
- has Wikipedia article: en

## DISH Q47347125
- name: Torta paesana
- description: cake made from stale bread soaked in milk
- countries: CH, IT
- kinds: cake
- ingredients: Amaretto macaron, aroma, candied fruit, pine nut, Theobroma cacao, biscuit, raisin, milk, bread
- has Wikipedia article: en

## DISH Q4736109
- name: Kinema
- description: food of Nepal
- countries: NP
- kinds: fermented food, soy food, food
- ingredients: soy bean, soybean
- has Wikipedia article: en

## DISH Q473662
- name: Mutschel
- description: bread
- countries: DE
- kinds: bread
- has Wikipedia article: en

## DISH Q4737104
- name: Alu Potala Rasa
- description: Pointed gourd and potato curry
- countries: IN
- kinds: Indian curry, vegetable dish
- ingredients: gourd, potato
- has Wikipedia article: en

## DISH Q4739207
- name: Amala
- description: traditional Yoruba Nigerian food made of root flour
- countries: NG
- cuisines: Yoruba cuisine
- kinds: swallow, food, dish, human food
- ingredients: cassava flour, yam, amala
- has Wikipedia article: en

## DISH Q47393310
- name: Lobster Yee Mein
- other names: {"zh": "龍蝦伊麵"}
- description: lobster dish of Hong Kong, China
- countries: CN
- kinds: seafood dish, noodle dish
- ingredients: yi mein, Palinuridae
- has Wikipedia article: zh

## DISH Q47408669
- name: Parmatieddi
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q4741197
- name: Ambelopoulia
- description: Traditional Greek Cypriot dish
- countries: CY
- kinds: food, meat, dish
- has Wikipedia article: en

## DISH Q4742021
- name: Ambuyat
- other names: {"zh": "西米糕"}
- description: traditional Brunei, Sabah and Sarawak dish
- countries: BN
- kinds: food, dish
- ingredients: sago
- has Wikipedia article: en, zh

## DISH Q47452383
- name: Biscuit de Bruxelles
- other names: {"fr": "Biscuit de Bruxelles"}
- countries: (none)
- kinds: cookie

## DISH Q47454216
- name: Smazhenyna
- description: Ukrainian cuisine
- countries: (none)
- kinds: meat dish

## DISH Q4745436
- name: American chop suey
- other names: {"zh": "美式雜燴"}
- description: New England dish of macaroni, ground beef, tomato sauce, and vegetables
- countries: US
- kinds: pasta dish
- ingredients: tomato sauce, ground beef, macaroni
- has Wikipedia article: en

## DISH Q4745482
- name: Khao phat amerikan
- other names: {"zh": "美國炒飯"}
- description: Thai fried rice dish with "American" side ingredients like fried chicken, ham, hot dogs, raisins, ketchup, and croutons
- countries: TH
- cuisines: Thai cuisine
- kinds: fried rice, rice dish
- ingredients: cooked rice, ketchup
- has Wikipedia article: en, zh

## DISH Q4745483
- name: American goulash
- description: U.S. dish of pasta, ground beef cooked with aromatics, tomatoes, and cheese
- countries: US
- kinds: casserole, pasta dish
- ingredients: beef
- has Wikipedia article: en

## DISH Q47457751
- name: Puhkeniki
- description: Ukrainian cuisine
- countries: (none)
- kinds: dish

## DISH Q47458616
- name: Chereshnyanka
- description: Ukrainian cuisine
- countries: UA
- kinds: mousse

## DISH Q47464157
- name: Barbecue sandwich
- description: barbecue-style sandwich
- countries: (none)
- kinds: sandwich
- has Wikipedia article: en

## DISH Q47465227
- name: Goan nevri
- description: food
- countries: IN
- kinds: dessert, dish

## DISH Q4746811
- name: Amish preaching soup
- description: U.S. bean soup
- countries: US
- kinds: food, soup
- ingredients: bean
- has Wikipedia article: en

## DISH Q47471931
- name: Chorizo pizza
- countries: (none)

## DISH Q47471957
- name: Tuna pizza
- countries: (none)
- ingredients: tomato, onion, Thunnus, mozzarella

## DISH Q47472036
- name: Raspberry pie
- description: pie with a raspberry filling
- countries: (none)
- kinds: pie
- ingredients: Butter, Salt, lemon juice, raspberry, sugar
- has Wikipedia article: en

## DISH Q47472060
- name: Papaya jam
- description: jam made from papayas
- countries: (none)
- kinds: fruit jam

## DISH Q47472068
- name: Pear jam
- description: jam made from pears
- countries: (none)
- kinds: fruit jam

## DISH Q47472092
- name: Lemon soy yogurts
- countries: (none)
- kinds: soy yogurt

## DISH Q47472117
- name: Ham croissant
- countries: (none)
- kinds: croissant

## DISH Q47472139
- name: Cherry jam
- description: jam made from cherrys
- countries: (none)
- kinds: fruit jam
- ingredients: cherry

## DISH Q47472145
- name: Cherry soy yogurts
- countries: (none)
- kinds: soy yogurt

## DISH Q47472160
- name: Chocolate croissant
- countries: (none)
- kinds: croissant

## DISH Q47472163
- name: Chocolate dessert
- description: dessert made primarily of chocolate
- countries: (none)
- kinds: dessert, chocolate dish

## DISH Q47472171
- name: Bolognese pizzas
- countries: (none)

## DISH Q4748563
- name: Tempoyak
- other names: {"zh": "榴莲酱"}
- description: Malay condiment made from fermented durian
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: Durio, Durio zibethinus
- has Wikipedia article: en

## DISH Q47487417
- name: Koulouria
- description: traditional food of Rhodes, Greece
- countries: GR
- kinds: pasta

## DISH Q47489422
- name: Tain
- description: Serbian military bread from beginning of 20. century
- countries: (none)
- kinds: bread

## DISH Q4750734
- name: Anadama bread
- description: yeast bread from the northeastern United States
- countries: US
- kinds: yeast bread
- ingredients: wheat
- has Wikipedia article: en

## DISH Q47508606
- name: Beef ravioli
- countries: (none)
- kinds: ravioli

## DISH Q4751737
- name: Anarsa
- description: sweet food from India
- countries: IN
- kinds: sweet dish, Indian cuisine
- ingredients: poppy seed, rice flour, jaggery
- has Wikipedia article: en

## DISH Q4752767
- name: Anchovy essence
- description: thick, oily sauce of pounded anchovies and spices
- countries: (none)
- kinds: fish sauce
- has Wikipedia article: en

## DISH Q47527989
- name: Cheese soufflé
- description: soufflé made with cheese
- countries: FR
- kinds: dish, soufflé
- ingredients: chicken egg, cheese

## DISH Q47530595
- name: Savoury pie
- description: dish
- countries: (none)
- kinds: dish, pie

## DISH Q4754537
- name: Andong jjimdak
- other names: {"zh": "安东炖鸡"}
- description: Korean chicken dish originating from Andong
- countries: KR
- kinds: Jjim, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q4764932
- name: Animal cracker
- description: cookie baked in the shape of an animal
- countries: (none)
- kinds: food, cracker
- has Wikipedia article: en

## DISH Q4765302
- name: Aniseed ball
- description: hard round sweet
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q4765304
- name: Aniseed twist
- description: boiled sweet
- countries: (none)
- kinds: hard candy
- has Wikipedia article: en

## DISH Q477248
- name: Pastry
- other names: {"zh": "糕点"}
- description: various baked products made of dough
- countries: (none)
- kinds: food, baked good, bánh, pastries and scones
- has Wikipedia article: en, zh

## DISH Q4773001
- name: Qistibi
- other names: {"zh": "馅饼合子"}
- description: bashkir, Tatar and Udmurt flatbread dish
- countries: (none)
- cuisines: Tatarstan cuisine, Bashkir cuisine
- kinds: flatbread
- ingredients: dough, oil
- has Wikipedia article: en

## DISH Q4774679
- name: Iberico ham
- other names: {"zh": "伊比利亚火腿"}
- description: Bellota ham
- countries: ES, PT
- kinds: jamón, presunto
- ingredients: ham
- has Wikipedia article: en, zh

## DISH Q4779197
- name: Apas
- description: oblong-shaped biscuit from the Philippines
- countries: PH
- kinds: food, biscuit
- has Wikipedia article: en

## DISH Q4781270
- name: Apple drops
- description: British confection
- countries: (none)
- kinds: hard candy
- has Wikipedia article: en

## DISH Q4781271
- name: Apple crisp
- description: dessert
- countries: (none)
- kinds: dish, pie
- ingredients: apple
- has Wikipedia article: en

## DISH Q4781285
- name: Apple soup
- description: soup prepared using apples as a primary ingredient
- countries: (none)
- kinds: food, fruit soup
- ingredients: apple
- has Wikipedia article: en

## DISH Q4782215
- name: Apteekin salmiakki
- description: brand of salty liquorice
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q4783300
- name: Arab salad
- description: Salad dishes within Arabic cuisine
- countries: (none)
- kinds: salad
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q4784160
- name: Aranygaluska
- description: traditional Hungarian dessert
- countries: HU
- cuisines: Hungarian cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q4784939
- name: Arbroath smokie
- description: hot-smoked haddock from Arbroath, Angus, Scotland
- countries: (none)
- kinds: smoked haddock
- ingredients: haddock
- has Wikipedia article: en

## DISH Q4793849
- name: Maaltijdsalade
- other names: {"nl": "maaltijdsalade"}
- description: salad eaten as a meal on its own
- countries: (none)
- kinds: salad

## DISH Q4794069
- name: Army & Navy Sweets
- description: traditional boiled sweet
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q4796280
- name: Arroz chaufa
- description: Chinese-Peruvian dish of fried rice
- countries: PE
- kinds: fried rice, meal
- ingredients: chicken egg, dark soy sauce, chicken as food, rice
- has Wikipedia article: en

## DISH Q4796283
- name: Arroz à grega
- description: Brazilian rice dish
- countries: BR
- kinds: dish, food
- ingredients: Daucus carota, Pisum sativum, raisin, maize, rice
- has Wikipedia article: en

## DISH Q4796545
- name: Arsik
- description: Indonesian Batak carp fish with spicy ingredients
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fish dish, dish, human food, type of food or dish
- ingredients: Indonesian bay leaf, shallot, turmeric rhizome, Tilia leaf, ginger, Cymbopogon, Garcinia atroviridis, Etlingera elatior, onion, bay leaf, Asparagus bean, Aleurites moluccanus, Alpinia galanga, chili pepper, goldfish, Allium schoenoprasum, Allium sativum, table salt, sugar, water
- has Wikipedia article: en

## DISH Q48034588
- name: Pinsa
- description: Italian pizza variant
- countries: IT
- cuisines: Roman cuisine
- kinds: focaccia, single course
- has Wikipedia article: en

## DISH Q4803469
- name: Asam pedas
- other names: {"zh": "亚参辣鱼"}
- description: Malay and Minangkabau food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fish stew, fish dish, soup, cuisine, dish, human food, type of food or dish
- ingredients: beef, fish
- has Wikipedia article: en, zh

## DISH Q4804429
- name: Ash Reshteh
- description: type of aush
- countries: IR
- kinds: food, soup
- has Wikipedia article: en

## DISH Q4804467
- name: Cochinita pibil
- description: Mexican slow-roasted pork dish
- countries: (none)
- kinds: pork dish
- ingredients: citrus fruit, annatto, pork
- has Wikipedia article: en

## DISH Q4806808
- name: Asian soup
- description: East Asian Varieties of Soup
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q4807004
- name: Asinan
- description: pickled vegetable or fruit dish from Indonesia
- countries: ID
- kinds: salad, street food, jajan pasar, food
- ingredients: mung bean sprout, cucumber, fried onion, krupuk, tofu, Lactuca sativa
- has Wikipedia article: en

## DISH Q4811596
- name: Bazlama
- description: Turkish flatbread
- countries: TR
- kinds: bread, flatbread, food
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q4811799
- name: Ekmek kadayıfı
- other names: {"zh": "Ekmek kadayıfı"}
- description: Turkish dessert
- countries: TR
- kinds: pudding, dish
- ingredients: bread
- has Wikipedia article: en, zh

## DISH Q481774
- name: Amuse-bouche
- other names: {"zh": "开胃小点"}
- description: single, bite-sized hors d’œuvre
- countries: FR
- kinds: dish
- has Wikipedia article: en

## DISH Q4817829
- name: Changaa
- description: distilled alcoholic beverage
- countries: KE
- kinds: liquor, moonshine
- has Wikipedia article: en

## DISH Q4818958
- name: Bülbülyuvası
- description: Turkish dessert
- countries: SY, TR
- kinds: dessert, dish
- ingredients: phyllo
- has Wikipedia article: en

## DISH Q4822264
- name: Şehriye
- description: Turkish pasta used in soups and other dishes
- countries: TR
- kinds: pasta, food
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q4822464
- name: Nokul
- description: Turkish dessert, especially from the central Black Sea Region
- countries: TR
- kinds: Turkish breads, sweet bread, dish
- ingredients: hazelnut, walnut, raisin
- has Wikipedia article: en

## DISH Q4822751
- name: Aush
- other names: {"zh": "阿富汗麵湯"}
- description: soup from various countries in the Middle East
- countries: AF, AM, AZ, IR, TR
- kinds: food, soup
- ingredients: barley, broth, noodle, yogurt
- has Wikipedia article: en, zh

## DISH Q4822752
- name: Ashak
- other names: {"zh": "阿富汗餃子"}
- description: Afghan dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q4823701
- name: Şekerpare
- description: Turkish dessert
- countries: (none)
- kinds: food, dessert, dish
- ingredients: cooking oil, flour, sugar
- has Wikipedia article: en

## DISH Q4831844
- name: Meatball
- other names: {"zh": "肉圓"}
- description: dish made from ground meat rolled into a small ball-like form
- countries: (none)
- kinds: meat dish, minced food ball, frozen meat semi-finished products
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q4833324
- name: Añejo cheese
- description: Mexican cheese
- countries: MX
- kinds: food
- has Wikipedia article: en

## DISH Q4833482
- name: Kumru
- description: Turkish sandwich, especially from the Aegean region (İzmir and env.)
- countries: TR
- kinds: sandwich, food
- ingredients: tomato, kaşar, sujuk, fried egg, bread
- has Wikipedia article: en

## DISH Q4833788
- name: B.C. roll
- other names: {"zh": "卑诗卷"}
- description: sushi containing barbecued salmon and cucumber
- countries: CA
- kinds: uramakizushi, salmon dish, dish
- ingredients: salmon, cucumber
- has Wikipedia article: en, zh

## DISH Q4838117
- name: Babute
- description: Congolese dish
- countries: CD
- kinds: dish
- ingredients: apricot, ground beef, curry powder
- has Wikipedia article: en

## DISH Q4838284
- name: Baby Gaga
- countries: (none)
- kinds: ice cream
- ingredients: breast milk

## DISH Q4838579
- name: Bacalhau com natas
- description: Salt cod casserole
- countries: PT
- cuisines: Portuguese cuisine
- kinds: dried and salted cod, potato dish, fish dish
- ingredients: onion, dried and salted cod, fries, cream
- has Wikipedia article: en

## DISH Q4838580
- name: Bacalaíto
- description: seafood dish from Puerto Rico
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q4838581
- name: Bacalhau com todos
- description: Cod recipe in Portuguese cuisine
- countries: PT
- kinds: fish dish
- has Wikipedia article: en

## DISH Q4838584
- name: Bacalhau à Gomes de Sá
- description: typical fish from Porto, Portugal
- countries: PT
- cuisines: Portuguese cuisine
- kinds: potato dish, bacalhau, fish dish
- ingredients: onion, dried and salted cod, olive, egg as food, olive oil, parsley, potato
- has Wikipedia article: en

## DISH Q4838586
- name: Bacalhau à Zé do Pipo
- description: Bacalhau casserole
- countries: PT
- cuisines: Portuguese cuisine
- kinds: potato dish, bacalhau, fish dish
- ingredients: onion, dried and salted cod, olive, mashed potato, mayonnaise, olive oil, milk, Capsicum annuum
- has Wikipedia article: en

## DISH Q4839946
- name: Bacon ice cream
- other names: {"zh": "培根冰淇淋"}
- description: ice cream made by adding bacon to egg custard and freezing the mixture
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en, zh

## DISH Q4839949
- name: Bacon soup
- description: type of soup
- countries: (none)
- kinds: food, soup
- ingredients: bacon
- has Wikipedia article: en

## DISH Q4839950
- name: Bacon sundae
- description: sundae prepared using typical sundae ingredients and bacon
- countries: (none)
- kinds: sundae
- ingredients: bacon
- has Wikipedia article: en

## DISH Q4839953
- name: Bacon sandwich
- other names: {"zh": "英式煙肉三文治"}
- description: sandwich of cooked bacon
- countries: GB
- kinds: meat sandwich
- ingredients: bacon, bread
- has Wikipedia article: en, zh

## DISH Q48405301
- name: Conchiglioni
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: durum flour

## DISH Q4841270
- name: Baeksuk
- other names: {"zh": "白熟"}
- description: Korean culinary term
- countries: (none)
- kinds: food, soup
- ingredients: meat
- has Wikipedia article: en

## DISH Q4841448
- name: Bagara khana
- description: spiced rice food from Telangana, India
- countries: (none)
- kinds: rice dish
- ingredients: basmati
- has Wikipedia article: en

## DISH Q4842073
- name: Bagoong
- description: Philippine fermented fish condiment
- countries: PH
- kinds: fish sauce, condiment
- ingredients: fermented fish
- has Wikipedia article: en

## DISH Q4843156
- name: Bai pong moan
- description: Cambodian soup
- countries: (none)
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q4843243
- name: Baik kut kyee kaik
- description: Noodle dish from Myanmar
- countries: MM
- kinds: food, shrimp dish, squid dish
- ingredients: shahe fen
- has Wikipedia article: en

## DISH Q484528
- name: 皇南面包
- description: South Korean pastry with a filling of red bean paste
- countries: (none)
- cuisines: South Korean cuisine
- kinds: food, pastry
- ingredients: red bean paste
- has Wikipedia article: en, zh

## DISH Q4845303
- name: Arzúa-Ulloa cheese
- description: Spanish protected designation of origin for Galician cheese
- countries: ES
- kinds: cow's-milk cheese, Spanish cheese, Protected designation of origin
- has Wikipedia article: en

## DISH Q4848884
- name: Baji
- description: type of beaten rice eaten in Nepal
- countries: NP
- kinds: rice dish
- has Wikipedia article: en

## DISH Q4849055
- name: Baked bean sandwich
- description: type of sandwich
- countries: US
- kinds: sandwich
- ingredients: bread
- has Wikipedia article: en

## DISH Q4849349
- name: Bakewell pudding
- other names: {"zh": "貝克威爾布丁"}
- description: traditional food originating in Bakewell
- countries: (none)
- kinds: food, pudding
- ingredients: flaky pastry, Pasta di mandorle PAT, egg as food, jam
- has Wikipedia article: en

## DISH Q4850247
- name: Balchão
- description: South Asian dish with a spicy and sour sauce
- countries: IN
- kinds: food, seafood dish, pork dish
- ingredients: recheado masala, fish as food
- has Wikipedia article: en

## DISH Q4850672
- name: Tamalito de maíz con frijoles
- description: traditional Honduran dish
- countries: HN
- kinds: dish
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q4850911
- name: Balila
- description: Levantine dish
- countries: LB
- kinds: dish
- ingredients: garlic, chickpea, lemon juice, spice
- has Wikipedia article: en

## DISH Q48512589
- name: Jojorong
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food
- ingredients: rice flour

## DISH Q4853511
- name: Bammy
- description: Jamaican flatbread
- countries: JM
- kinds: food, flatbread
- ingredients: cassava root
- has Wikipedia article: en

## DISH Q4853859
- name: Banana boat
- other names: {"zh": "香蕉艇"}
- description: dessert made of banana
- countries: (none)
- kinds: food, banana dish
- ingredients: banana
- has Wikipedia article: en, zh

## DISH Q4853862
- name: Banana cue
- other names: {"zh": "沙爹香蕉"}
- description: barbequed banana dish from the Philippines
- countries: (none)
- kinds: banana dish, skewer
- ingredients: Saba banana
- has Wikipedia article: en, zh

## DISH Q4855649
- name: Bánh canh
- description: Vietnamese thick noodle soup
- countries: VN
- kinds: soup, seafood dish, fish dish, pork dish
- ingredients: bánh canh, tapioca
- has Wikipedia article: en

## DISH Q4856836
- name: Banmian
- other names: {"zh": "板麵"}
- description: Chinese noodle dish
- countries: CN, MY, SG
- kinds: pasta dish, noodle dish
- ingredients: anchovy, egg as food, flour
- has Wikipedia article: en, zh

## DISH Q4857446
- name: Chhoah-peng
- other names: {"zh": "刨冰"}
- description: shaved ice dessert
- countries: (none)
- kinds: food, shaved ice
- has Wikipedia article: en, zh

## DISH Q4859633
- name: Barberton chicken
- other names: {"zh": "巴伯頓炸雞"}
- description: serbian-American fried chicken dish
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q4861163
- name: Barley bread
- description: type of bread made from barley flour
- countries: (none)
- kinds: bread, baked good
- ingredients: barley flour
- has Wikipedia article: en

## DISH Q4861253
- name: Barm cake
- description: soft, round, flattish bread roll from North West England
- countries: (none)
- kinds: baked good, bread
- ingredients: barm
- has Wikipedia article: en

## DISH Q4868531
- name: Batagor
- description: Sundanese food from Indonesia
- countries: ID
- kinds: food, fish dish, type of food or dish
- ingredients: garlic, onion, peppercorn, fish as food, sesame oil, Allium ascalonicum, tofu, egg as food, flour, table salt, sugar
- has Wikipedia article: en

## DISH Q4868733
- name: Batchoy
- description: Filipino Noodle Dish
- countries: PH
- kinds: food, soup
- ingredients: noodle
- has Wikipedia article: en

## DISH Q4869727
- name: Battered sausage
- description: savory fried meat dish from Britain and Ireland
- countries: GB
- kinds: sausage, pork dish
- ingredients: sausage, batter
- has Wikipedia article: en

## DISH Q48724049
- name: Tomato chutney
- description: chutney prepared using tomatoes
- countries: (none)
- kinds: chutney, tomato dish
- ingredients: tomato, table salt, sugar
- has Wikipedia article: en

## DISH Q48730021
- name: Kasundi
- description: Bengali mustard sauce
- countries: (none)
- kinds: sauce
- ingredients: mustard, spice, table salt
- has Wikipedia article: en

## DISH Q48730981
- name: Apam Johol
- description: Sweetened rice cake in Malaysia
- countries: MY
- kinds: kue, rice cake
- ingredients: brown sugar, palm sugar, rice flour, Baccaurea motleyana, yeast
- has Wikipedia article: en

## DISH Q48731366
- name: Pakistani bread
- countries: (none)
- kinds: South Asian bread
- has Wikipedia article: en

## DISH Q48731505
- name: Sarpuria
- description: sweet originating from West Bengal, India
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q4873584
- name: Baursak
- other names: {"zh": "蒙古馃子"}
- description: traditional fried dough food peculiar to the cuisines of Central Asia, Bashkortostan and Middle East
- countries: KZ, TR, KG
- cuisines: Kazakh cuisine, Turkish cuisine, Cuisine of Uzbekistan, Tatarstan cuisine, Kyrgyz cuisine
- kinds: food, fried dough
- ingredients: wheat flour, dough, egg as food, butter, cream, salt, milk, water
- has Wikipedia article: en, zh

## DISH Q48741336
- name: Trenton tomato pie
- description: type of Italian tomato pie
- countries: US
- kinds: Italian tomato pie
- has Wikipedia article: en

## DISH Q48744234
- name: Uo-suki
- countries: (none)
- kinds: nabemono, fish dish

## DISH Q48744745
- name: 栗蒸し羊羹
- other names: {"ja": "栗蒸し羊羹"}
- countries: JP
- kinds: Yōkan

## DISH Q48744747
- name: Uguisu pan
- description: a kind of anpan
- countries: JP
- kinds: anpan
- ingredients: uguisu an, bread

## DISH Q48744876
- name: もも太郎
- other names: {"ja": "もも太郎"}
- countries: (none)
- kinds: frozen dessert

## DISH Q48745423
- name: 嵐山辛モツ焼そば
- other names: {"ja": "嵐山辛モツ焼そば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q48745707
- name: Ogi yōkan
- description: Japanese confectionery
- countries: JP
- kinds: Yōkan
- has Wikipedia article: en

## DISH Q48746044
- name: Senju negi
- countries: JP
- kinds: Welsh onion, vegetable

## DISH Q48746468
- name: Sky
- countries: (none)
- kinds: ice cream

## DISH Q48748447
- name: Alfred le Fermier
- description: Canadian cheese
- countries: CA
- kinds: raw-milk cheese, cow's-milk cheese, cheese from Quebec

## DISH Q48749228
- name: Shichifukujin arare
- description: Japanese rice cracker
- countries: JP
- kinds: arare

## DISH Q48750480
- name: ホルそば
- other names: {"ja": "ホルそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q48751627
- name: 飯能すいーとん
- other names: {"ja": "飯能すいーとん"}
- countries: (none)
- kinds: suiton

## DISH Q48751767
- name: Miso potatoes
- countries: (none)
- kinds: tempura, potato dish

## DISH Q48752050
- name: おなっとう
- other names: {"ja": "おなっとう"}
- countries: JP
- kinds: rice dish

## DISH Q48752482
- name: かいこの王国
- other names: {"ja": "かいこの王国"}
- countries: (none)
- kinds: confectionery

## DISH Q48753429
- name: Leberspätzle
- other names: {"de": "Leberspätzle"}
- countries: (none)
- kinds: dish

## DISH Q48754335
- name: Errötendes Mädchen
- other names: {"de": "Errötendes Mädchen"}
- countries: (none)
- kinds: dish

## DISH Q48754738
- name: Nbushī
- countries: (none)
- kinds: vegetable dish

## DISH Q48755607
- name: Gratin de bananes
- other names: {"fr": "gratin de bananes"}
- countries: (none)
- kinds: dish

## DISH Q48756009
- name: Poutine à trou
- countries: (none)
- kinds: dessert
- ingredients: apple

## DISH Q48758222
- name: Steak au four
- description: German dish
- countries: DE
- cuisines: German
- kinds: dish

## DISH Q48758790
- name: Kotobuki yokan
- countries: (none)
- kinds: Yōkan

## DISH Q48760475
- name: パサン
- other names: {"ja": "パサン"}
- countries: (none)
- kinds: confectionery

## DISH Q48762320
- name: Bara-zushi
- description: form of sushi
- countries: (none)
- kinds: chirashizushi
- ingredients: Bah-sò, usuyaki tamago, beni shōga, kamaboko

## DISH Q4876256
- name: Bean Sprouts Chicken
- other names: {"zh": "芽菜雞"}
- description: Chicken dish with bean sprouts
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q4876265
- name: Bean pie
- description: sweet custard and bean pie; associated with African-American Muslim culture
- countries: US
- cuisines: African-American Muslim cuisine
- kinds: food, pie, dish
- ingredients: custard, bean, egg as food
- has Wikipedia article: en
