# Review batch names-024

## DISH Q139005874
- name: Bay-kara
- countries: (none)
- kinds: karaage, product

## DISH Q139008367
- name: Vorschmack
- description: Finnish dish
- countries: FI
- kinds: dish

## DISH Q139071793
- name: Fish curry
- countries: (none)
- kinds: curry, fish dish

## DISH Q139072490
- name: Vegetable curry
- countries: (none)
- kinds: curry, vegetable dish

## DISH Q139105458
- name: Caraway comfit
- description: candied caraway seeds
- countries: (none)
- kinds: comfit
- ingredients: caraway seeds, sugar

## DISH Q139118951
- name: Cipolla rosa di Bassano PAT
- other names: {"zh": "Cipolla rosa di Bassano PAT"}
- description: traditional Italian fruit, vegetable or cereal product (PAT)
- countries: IT
- kinds: onion, agricultural product

## DISH Q139118953
- name: Cipolla bianca di Chioggia PAT
- other names: {"zh": "Cipolla bianca di Chioggia PAT"}
- description: traditional Italian fruit, vegetable or cereal product (PAT)
- countries: IT
- kinds: onion, white onion, agricultural product

## DISH Q139130853
- name: Khao man gai
- description: Thai poached chicken and rice dish
- countries: TH
- cuisines: Thai cuisine
- kinds: rice dish, chicken dish, dish
- ingredients: chicken as food, rice

## DISH Q139148492
- name: Cassopipa PAT
- other names: {"zh": "Cassopipa PAT"}
- description: traditional Italian fish, mollusc or crustacean product (PAT)
- countries: IT
- cuisines: cuisine of Veneto
- kinds: seafood, single course

## DISH Q139148656
- name: Schizzotto PAT
- other names: {"zh": "Schizzotto PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- cuisines: cuisine of Padua
- kinds: baked good, unleavened bread, sweet bread

## DISH Q139148657
- name: Torta ortigara PAT
- other names: {"zh": "Torta ortigara PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: dessert, baked good

## DISH Q139148658
- name: Smegiassa PAT
- other names: {"zh": "Smegiassa PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- cuisines: cuisine of Veneto
- kinds: dessert, baked good

## DISH Q139206037
- name: Chocolate in Japan
- countries: (none)
- kinds: chocolate
- has Wikipedia article: en

## DISH Q139251202
- name: Zibdieh
- description: Palestinian dish, shrimps in spicy tomato sauce
- countries: (none)
- kinds: dish
- ingredients: parsley, garlic, coriander seed, tomato, chili pepper, Cuminum cyminum, olive oil

## DISH Q139266197
- name: Taiwanese Hot pot
- other names: {"zh": "臺式火鍋"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: hot pot

## DISH Q139270254
- name: Zlyvana kasha
- description: traditional porridge from Karnaukhivka, Ukraine
- countries: UA
- kinds: porridge, dish
- ingredients: potato, salo, onion, chicken as food, millet, egg as food, rice

## DISH Q139275409
- name: Zakarpattia honey
- description: honey with protected geographical indication from Zakarpattia, Ukraine
- countries: (none)
- kinds: honey

## DISH Q139284387
- name: Psatyr
- description: traditional Easter bread of the Nadazovia Greeks
- countries: UA
- kinds: bread

## DISH Q139292971
- name: 新 あなたの心もと〜ろとろ 僕の好きな物を組み合わせてみました入江丼
- other names: {"ja": "新 あなたの心もと〜ろとろ 僕の好きな物を組み合わせてみました入江丼"}
- countries: (none)
- kinds: donburi, product
- ingredients: poke, rice

## DISH Q139293346
- name: 葱香る唐揚げ丼
- other names: {"ja": "葱香る唐揚げ丼"}
- countries: (none)
- kinds: donburi, product
- ingredients: karaage, ginger, Welsh onion, rice

## DISH Q139294220
- name: ベイカラほりにし味
- other names: {"ja": "ベイカラほりにし味"}
- countries: (none)
- kinds: Bay-kara, product
- ingredients: Bay-kara

## DISH Q139294480
- name: ベイカラ ヤンニョムチキン味
- other names: {"ja": "ベイカラ ヤンニョムチキン味"}
- countries: (none)
- kinds: Bay-kara, product

## DISH Q139295999
- name: Bay Gyoza
- countries: (none)
- kinds: jiaozi, product

## DISH Q139296393
- name: ベイメンチ
- other names: {"ja": "ベイメンチ"}
- countries: (none)
- kinds: menchi-katsu, product

## DISH Q139326060
- name: Bay kara Tokube Chu ver.～
- countries: (none)
- kinds: karaage, product
- ingredients: Bay-kara

## DISH Q1393435
- name: Salzkuchen
- countries: (none)

## DISH Q139344209
- name: Nasi ayam
- description: Malaysian chicken rice dish
- countries: MY
- cuisines: Malay cuisine
- kinds: rice dish
- ingredients: pandan leaf, chicken as food, soy sauce, chili pepper, rice
- has Wikipedia article: en

## DISH Q139352694
- name: Korean cream cheese garlic bread
- description: Korean-style garlic bread filled with sweetened cream cheese
- countries: KR
- kinds: garlic bread

## DISH Q139377324
- name: Baba-sharpanyna
- description: Ukrainian dish
- countries: UA
- kinds: dish, food, zapikanka
- ingredients: spice, flour, onion, fish as food
- has Wikipedia article: en

## DISH Q139377873
- name: Pommes Darphin
- description: potato dish
- countries: FR
- kinds: potato dish
- ingredients: potato

## DISH Q139408916
- name: 河南蒸菜
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q139409102
- name: 鯉魚焙麵
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q139413840
- name: Shpachky
- description: ritual baked goods from Horodyshche region, Ukraine
- countries: UA
- kinds: baked good, pirozhki

## DISH Q139414293
- name: Chewette
- description: pastry items that were eaten in England from the late 14th to the beginning of the 17th centuries
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q139439156
- name: 擂辣椒皮蛋
- countries: (none)
- kinds: dish, Hunan cuisine
- has Wikipedia article: zh

## DISH Q139439477
- name: 生汆丸子
- countries: (none)
- kinds: dish, meatball soup
- has Wikipedia article: zh

## DISH Q139449422
- name: Paccheri salsiccia
- countries: (none)
- kinds: dish
- ingredients: paccheri

## DISH Q1394677
- name: Kaisen-don
- other names: {"zh": "海鮮蓋飯"}
- description: Japanese seafood rice bowl
- countries: (none)
- kinds: donburi, seafood dish

## DISH Q139472819
- name: Fried meatball
- other names: {"zh": "炸丸子"}
- description: Chinese dish
- countries: (none)
- kinds: dish, Chinese cuisine
- has Wikipedia article: zh

## DISH Q139497890
- name: Quenu
- other names: {"de": "Quenu"}
- countries: (none)
- kinds: cake

## DISH Q139500157
- name: Guruli gvezeli
- description: traditional Georgian crescent-shaped pie from Guria region of western Georgia
- countries: (none)
- kinds: food, dish
- has Wikipedia article: en

## DISH Q139501650
- name: Dagga
- description: spicy tomato salad from Gaza
- countries: PS
- cuisines: Palestinian cuisine
- kinds: salad, dish
- ingredients: garlic, tomato, lemon juice, chili pepper, olive oil, vinegar, table salt

## DISH Q139503554
- name: Crispy potatoes
- countries: (none)
- kinds: potato dish
- ingredients: potato

## DISH Q139503993
- name: Musafan
- description: Palestinian round flat bread made from yeast dough
- countries: PS
- kinds: bread, flatbread, type of food or dish
- ingredients: wheat flour, baker's yeast, olive oil, table salt, drinking water

## DISH Q139505285
- name: Tamago Sando
- description: Japanese-style egg salad sandwich
- countries: (none)
- kinds: sandwich
- has Wikipedia article: en

## DISH Q139551259
- name: Potatis- och purjolökssoppa
- other names: {"sv": "potatis- och purjolökssoppa"}
- countries: (none)
- kinds: soup, potato dish

## DISH Q139556341
- name: Fidget pie
- description: cured pork and apple pie
- countries: (none)
- kinds: savoury pie
- has Wikipedia article: en

## DISH Q139569390
- name: Snounieh
- description: Levantine dessert based on boiled wheat
- countries: SA, PS
- cuisines: Arab cuisine, Levantine cuisine, Palestinian cuisine
- kinds: dessert
- ingredients: wheat, pistachio nut, pomegranate, rose water, walnut, copra, almond, cinnamon, raisin, sugar, honey

## DISH Q139579958
- name: Zuppa di ajucche
- other names: {"it": "zuppa di ajucche"}
- countries: (none)
- kinds: dish

## DISH Q139582297
- name: Madlouqa
- description: Levantine dessert
- countries: (none)
- cuisines: Levantine cuisine
- kinds: dessert
- ingredients: qishta

## DISH Q139585697
- name: Pempek Lenjer
- description: variation of the pempek dish
- countries: ID
- cuisines: Indonesian cuisine, Palembang cuisine
- kinds: fish dish, food, dish, type of food or dish, human food, traditional food, Pempek
- ingredients: garlic, tapioca, egg white, fish as food, cooking oil, table salt, water

## DISH Q139585819
- name: Pepes Mlanding Teri
- description: traditional food of Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q139587337
- name: 金牛角
- countries: TW
- kinds: pastry, viennoiserie
- ingredients: yak butter, puff pastry
- has Wikipedia article: zh

## DISH Q139596773
- name: Ganso Shachimonaka
- description: shachihoko-shaped monaka confection created in 1921 by Ganso Shachimonaka Honten, Nagoya, Japan
- countries: JP
- kinds: monaka

## DISH Q139597098
- name: Kibbeh samak
- description: Lebanese dish made of fish meat
- countries: LB
- kinds: meze, kibbeh, fish dish
- ingredients: cumin seed, coriander seed, sumac, onion, peppercorn, bulgur, pine nut, walnut, chili pepper, cinnamon, table salt, fish

## DISH Q139601249
- name: 韓国風タコミートバーガー
- other names: {"ja": "韓国風タコミートバーガー"}
- countries: (none)
- kinds: hamburger, product
- ingredients: bun, beef, maize

## DISH Q139619401
- name: Bouzelouf
- description: A popular dish found in Algerian cuisine
- countries: (none)
- kinds: dish

## DISH Q139622335
- name: Amsterdamse koggetjes
- description: traditional Dutch cookies
- countries: (none)
- kinds: cookie

## DISH Q139659622
- name: Onigirazu
- description: type of onigiri
- countries: JP
- kinds: onigiri
- ingredients: stuffing, cooked rice, nori

## DISH Q139665794
- name: Amsterdamse korstjes
- other names: {"nl": "Amsterdamse korstjes"}
- countries: (none)
- kinds: cookie, pastry, ontbijtkoek
- ingredients: spice, Pimpinella anisum, Secale cereale, honey

## DISH Q13967255
- name: Pestil
- description: Turkish dessert
- countries: TR
- kinds: dessert
- has Wikipedia article: en

## DISH Q139679814
- name: Pierogi
- other names: {"pl": "pierogi"}
- description: pasties or dumplings with filling
- countries: (none)
- kinds: dish
- ingredients: stuffing, dough

## DISH Q139700288
- name: Mille-Feuille Nabe
- description: Japanese food
- countries: JP
- kinds: food, stew

## DISH Q139701309
- name: Ketupat gulai kapau
- description: breakfast from West Sumatra
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, Indonesian cuisine, human food, type of food or dish
- ingredients: granulated sugar, Indonesian bay leaf, turmeric leaf, asparagus bean, shallot, Kaffir Lime Leaf, garlic, ginger, cabbage, Garcinia xanthochymus, lontong, seedling, coconut milk, Scarlet-backed Flowerpecker, bird's eye chili, Alpinia galanga, Artocarpus heterophyllus, Curcuma longa, table salt

## DISH Q139714031
- name: Ulmo honey
- description: monofloral honey produced from nectar of the Eucryphia cordifolia tree, native to Chile
- countries: CL
- kinds: honey, monofloral honey
- ingredients: nectar, Eucryphia cordifolia

## DISH Q1397169
- name: Farsu magru
- description: Sicilian meat dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q139719072
- name: Wiener Backfleisch
- other names: {"de": "Wiener Backfleisch"}
- countries: AT
- kinds: Tafelspitz, beef dish
- ingredients: bread crumbs, beef, egg as food, Armoracia rusticana

## DISH Q1397211
- name: Soft serve
- other names: {"zh": "軟雪糕"}
- description: type of ice cream that is softer than regular ice creams as a result of air being introduced during freezing
- countries: US
- kinds: ice cream
- ingredients: milk powder, guar gum, carrageenan, locust bean gum, fat, sugar, milk, drinking water
- has Wikipedia article: en, zh

## DISH Q1397302
- name: Faschierte Laibchen
- description: dish
- countries: (none)
- kinds: cutlet, dish, meat dish
- ingredients: minced meat

## DISH Q1397493
- name: Fasnachtschüechli
- countries: (none)
- kinds: fritter

## DISH Q139759698
- name: Basbaas cagaar
- description: somalian hot sauce
- countries: SO
- kinds: hot sauce
- has Wikipedia article: en

## DISH Q139761682
- name: Rook pie
- description: rook meat baked into pie
- countries: (none)
- kinds: game pie
- ingredients: Rook
- has Wikipedia article: en

## DISH Q139761797
- name: Yorkshire Christmas pie
- description: English pie
- countries: GB
- kinds: Raised pie, dish
- has Wikipedia article: en

## DISH Q139761836
- name: Raised pie
- description: type of pie
- countries: (none)
- kinds: pie
- has Wikipedia article: en

## DISH Q139770134
- name: Amanida de cors de palmera
- other names: {"ca": "Amanida de cors de palmera"}
- countries: (none)
- kinds: food, dish

## DISH Q1397738
- name: Fastenbrezel
- other names: {"de": "Fastenbrezel"}
- countries: (none)
- kinds: viennoiserie

## DISH Q139802375
- name: Blood Sausage from Beasain
- countries: ES
- kinds: dish

## DISH Q139809866
- name: Motoho
- other names: {"ca": "Motoho"}
- countries: (none)
- kinds: food, dish

## DISH Q139816409
- name: Xian doujiang
- other names: {"zh": "鹹豆漿"}
- description: savory soy milk soup eaten
- countries: TW, CN
- cuisines: Taiwanese cuisine, Shanghai cuisine
- kinds: soup, dish
- ingredients: youtiao, soy sauce, soy milk, vinegar
- has Wikipedia article: zh

## DISH Q139816842
- name: Stir-fry green bean
- description: traditional food of Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q139816855
- name: Soto krendegan
- description: traditional food of Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, traditional food

## DISH Q139819437
- name: Arrufadas de Coimbra
- other names: {"pt": "Arrufadas de Coimbra"}
- countries: PT
- kinds: bread

## DISH Q139819495
- name: Colo de freira
- other names: {"mul": "colo de freira"}
- countries: PT
- kinds: food, sweetmeat

## DISH Q139819619
- name: Rosas da rainha
- other names: {"pt": "rosas da rainha"}
- countries: PT
- kinds: conventual sweets

## DISH Q139819775
- name: Manjar branco
- other names: {"pt": "manjar branco"}
- countries: PT
- kinds: conventual sweets
- ingredients: white sugar, rice flour, orange flower water, chicken as food, milk

## DISH Q139819830
- name: Pastel de Lorvão
- other names: {"pt": "Pastel de Lorvão"}
- countries: (none)
- kinds: conventual sweets, type of food or dish

## DISH Q139819866
- name: Pudim das Clarissas
- other names: {"pt": "pudim das Clarissas"}
- countries: PT
- kinds: sweetmeat
- ingredients: egg yolk, sugar

## DISH Q139819912
- name: Trouxa de ovos
- other names: {"pt": "trouxa de ovos"}
- countries: (none)
- kinds: conventual sweets, type of food or dish

## DISH Q139820043
- name: Broa baixada da Mealhada
- other names: {"pt": "broa baixada da Mealhada"}
- countries: PT
- kinds: bread

## DISH Q139820814
- name: BayStars Nachos
- countries: (none)
- kinds: nachos, product
- ingredients: cheese sauce, salsa (food), tortilla chip

## DISH Q139845808
- name: Bakasang
- description: a traditional fermented fish sauce from eastern Indonesia
- countries: (none)
- kinds: dish
- ingredients: skipjack tuna, table salt, drinking water

## DISH Q139846003
- name: Taiwanese Steak
- other names: {"zh": "台式牛排"}
- description: Steak in Taiwan
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish, beefsteak
- ingredients: beef

## DISH Q139855677
- name: Bubur habang
- other names: {"id": "bubur habang"}
- countries: ID
- kinds: porridge, dish
- ingredients: palm sugar, coconut milk, table salt, rice

## DISH Q139856083
- name: Pupudak sagu
- other names: {"id": "pupudak sagu"}
- countries: ID
- kinds: dish, street food
- ingredients: sago flour, banana leaf, palm sugar, coconut milk, Pandanus amaryllifolius, table salt, sugar

## DISH Q139856415
- name: Ular-ular
- other names: {"bjn": "ular-ular"}
- countries: ID
- kinds: dish
- ingredients: Garam, coconut, palm sugar, Pandanus amaryllifolius, sago, sugar

## DISH Q13986541
- name: Kahuda
- other names: {"cs": "kahuda"}
- countries: (none)
- kinds: dish

## DISH Q139881211
- name: Weltmeisterbrötchen
- other names: {"de": "Weltmeisterbrötchen"}
- description: FIFA World Cup related bread rolls in Germany
- countries: DE
- kinds: bread roll

## DISH Q139882113
- name: Lak-a Noodles
- other names: {"zh": "搦仔麵"}
- description: Taiwanese noodle dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: noodle dish

## DISH Q139885834
- name: Dolly Varden cake
- description: layer cake
- countries: (none)
- kinds: layer cake
- has Wikipedia article: en

## DISH Q139890123
- name: Μελίχλωρο
- other names: {"el": "Μελίχλωρο"}
- countries: GR
- kinds: sheep milk cheese, cheese

## DISH Q139890497
- name: うどラーメン
- other names: {"ja": "うどラーメン"}
- countries: (none)
- kinds: ramen

## DISH Q139892680
- name: Taja
- other names: {"es": "taja"}
- description: type of bread from Navarre, Spain
- countries: ES
- kinds: bread

## DISH Q139905696
- name: Pastel de pollo
- description: Colombian chicken pastry
- countries: CO
- cuisines: Colombian cuisine
- kinds: food, pastry
- ingredients: canola oil, Sesamum indicum, chicken breast, wheat flour, sea salt, egg as food, cheese

## DISH Q139907614
- name: Tāu-mī
- other names: {"zh": "兜麵"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish

## DISH Q139915904
- name: Buffalo-style pizza
- description: style of pizza from Buffalo, New York
- countries: (none)
- has Wikipedia article: en

## DISH Q139934067
- name: Instant stock
- other names: {"zh": "方便高汤"}
- description: dehydrated bouillon used for cooking
- countries: (none)
- kinds: instant soup, condiment, imitation food

## DISH Q139947647
- name: Patachi
- other names: {"es": "Patachi"}
- countries: PE
- kinds: dish

## DISH Q139960699
- name: Uitsmijter
- description: Dutch egg dish of fried eggs on bread, usually with ham and/or cheese
- countries: NL
- cuisines: Dutch cuisine
- kinds: open sandwich, egg dish
- ingredients: white bread, Gouda, fried egg, ham, bread
- has Wikipedia article: en

## DISH Q139961898
- name: Harisse
- description: Kashmiri meat dish
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q139963953
- name: Chamorro red rice
- description: chamorro rice dish colored with annatto
- countries: (none)
- kinds: rice dish
- has Wikipedia article: en

## DISH Q139976172
- name: Robert E. Lee cake
- description: American layer cake
- countries: (none)
- kinds: layer cake
- has Wikipedia article: en

## DISH Q139997460
- name: מאזה מניקה
- other names: {"he": "מאזה מניקה"}
- countries: IT
- kinds: pasta

## DISH Q139997901
- name: Kandas suna
- other names: {"id": "kandas suna"}
- countries: ID
- kinds: dish

## DISH Q140010226
- name: Mukōzuke
- description: Hors d'oeuvre in kaiseki cuisine or the small dish used for it.
- countries: (none)
- kinds: dish, tableware, hors-d'œuvre

## DISH Q140042843
- name: Duffin
- description: doughnut and muffin hybrid cake
- countries: GB
- kinds: doughnut, muffin

## DISH Q140068316
- name: Brown bread ice cream
- description: flavour of ice cream
- countries: (none)
- kinds: food, ice cream flavor
- has Wikipedia article: en

## DISH Q140069747
- name: Cato's Globi
- description: cheesecake bites, ancient roman cuisine
- countries: (none)
- kinds: dessert, dumpling

## DISH Q140157702
- name: Chitlins
- description: chitterlings dish of the Southern United States
- countries: (none)
- cuisines: cuisine of the Southern United States, soul food
- kinds: intestines as food
- has Wikipedia article: en

## DISH Q140159539
- name: خبيصة (حلويات)
- other names: {"ar": "خبيصة (حلويات)"}
- countries: (none)
- kinds: dessert, food

## DISH Q140159693
- name: ملبن (حلوى)
- other names: {"ar": "ملبن (حلوى)"}
- countries: (none)
- kinds: dessert, food

## DISH Q140164594
- name: Dakgom
- other names: {"zh": "江米鸡"}
- description: North Korean chicken and rice dish
- countries: (none)
- cuisines: North Korean cuisine
- kinds: chicken dish

## DISH Q1401891
- name: Viennoiserie
- description: baked goods made from a fat-enriched yeast-leavened dough
- countries: FR
- kinds: sweet bread, bakers' confection
- ingredients: Danish pastry dough
- has Wikipedia article: en

## DISH Q140192769
- name: Sopa de burro canso
- other names: {"gl": "Sopa de burro canso"}
- countries: ES
- cuisines: Galician cuisine
- kinds: dessert, dish
- ingredients: lemon, cinnamon, sugar, bread, wine

## DISH Q1401956
- name: Feinkostsalat
- other names: {"de": "Feinkostsalat"}
- countries: (none)
- kinds: salad

## DISH Q140197903
- name: Anisplätzchen
- other names: {"de": "Anisplätzchen"}
- countries: (none)
- kinds: viennoiserie

## DISH Q140199021
- name: うなぎのポリット
- other names: {"ja": "うなぎのポリット"}
- countries: (none)
- kinds: unagi, senbei, food product
- ingredients: bone

## DISH Q140247979
- name: Hånnlamb
- other names: {"mul": "Hånnlamb"}
- countries: SE
- kinds: lamb meat, sheep meat

## DISH Q140289332
- name: Brik danouni
- description: Tunisian dish
- countries: TN
- kinds: Brik, dish
- has Wikipedia article: en

## DISH Q140291446
- name: Beer brat
- description: type of sausage
- countries: (none)
- kinds: Bratwurst
- has Wikipedia article: en

## DISH Q140298634
- name: Vinegar pie
- description: type of pie made from vinegar
- countries: US
- kinds: dessert, sweet pie
- ingredients: Lemon Extract, unsalted butter, chicken egg, vinegar, flour, sugar
- has Wikipedia article: en

## DISH Q140308670
- name: Waraji katsudon
- description: Cuisine of Chichibu, Saitama prefecture.
- countries: (none)
- kinds: dish

## DISH Q140309389
- name: Dingle pie
- description: meat pie made in Ireland
- countries: IE
- cuisines: Irish cuisine
- kinds: meat pie
- ingredients: lamb meat, puff pastry

## DISH Q140331989
- name: Eggplant rolls
- description: Mediterranean dish
- countries: (none)
- cuisines: Mediterranean cuisine
- kinds: dish
- ingredients: eggplant

## DISH Q140411644
- name: Bho Bhi Guê
- other names: {"zh": "无米粿"}
- description: snack of Chaoshan
- countries: (none)
- kinds: xiaochi
- ingredients: Allium tuberosum, Sweet potato
- has Wikipedia article: zh

## DISH Q140418822
- name: Checkerboard Cake
- countries: (none)
- kinds: cake

## DISH Q140419602
- name: Adidas
- countries: PH
- kinds: meat dish
- has Wikipedia article: en

## DISH Q140423317
- name: Helmet
- other names: {"pl": "Helmet"}
- countries: (none)
- kinds: meat dish

## DISH Q140425649
- name: Lokcing
- other names: {"ms": "Lokcing"}
- description: Traditional Southeast Asian skewered and grilled fish paste balls, popular as a street food in Malaysia and Southern Thailand
- countries: MY
- kinds: satay, fish dish
- ingredients: tapioca flour, fish paste, chili pepper, sugar

## DISH Q140430995
- name: Day-old chick
- description: Filipino fried chicken hatchling
- countries: (none)
- kinds: fried chicken, street food, chick, skewer
- has Wikipedia article: en

## DISH Q140435739
- name: Pais pisang
- description: traditional cake from Kalimantan Selatan
- countries: (none)
- kinds: cake

## DISH Q140444347
- name: Leipäressu
- other names: {"fi": "Leipäressu"}
- countries: (none)
- kinds: dish

## DISH Q140444348
- name: Tirripaisti
- other names: {"fi": "Tirripaisti"}
- countries: (none)
- kinds: dish

## DISH Q140444349
- name: Venäjän Kulitsa
- other names: {"fi": "Venäjän Kulitsa"}
- countries: (none)
- kinds: dish

## DISH Q140444350
- name: Palvimakkara
- other names: {"fi": "Palvimakkara"}
- countries: (none)
- kinds: sausage, dish

## DISH Q140444352
- name: Shanghai-taco
- other names: {"fi": "Shanghai-taco"}
- countries: (none)
- kinds: dish

## DISH Q140444353
- name: Lanttukukko
- other names: {"fi": "Lanttukukko"}
- countries: (none)
- kinds: dish

## DISH Q140447303
- name: Pies in Pennsylvania
- description: history and cultural significance of pies in Pennsylvania
- countries: (none)
- kinds: pie in American cuisine
- has Wikipedia article: en

## DISH Q140454149
- name: Gamaj kabab
- description: traditional Gilaki stew from northern Iran
- countries: IR
- cuisines: Iranian cuisine
- kinds: stew

## DISH Q140454228
- name: Sainfoin honey
- description: monofloral honey from the nectar of sainfoin (Onobrychis viciifolia)
- countries: KG, KZ, TR
- kinds: monofloral honey, honey
- ingredients: Onobrychis viciifolia

## DISH Q140455658
- name: Stuffed chicken wings
- description: chicken wing dish
- countries: (none)
- kinds: chicken dish, stuffed food
- ingredients: chicken wing

## DISH Q140469754
- name: Italini Gelato
- countries: (none)
- kinds: ice cream, enterprise

## DISH Q140471515
- name: Sorrentinos argentinos
- description: Sorrentinos are a type of Argentine ravioli, but larger, more circular and originally wrapped without fluted edge. The dough is made with flour and eggs, and the filling of the original recipe consists of York ham and mozzarella.
- countries: (none)
- kinds: pasta

## DISH Q140473442
- name: Fainè sassarese
- other names: {"it": "fainè sassarese"}
- countries: (none)
- cuisines: cuisine of Liguria, cuisine of Sardinia
- kinds: Farinata di ceci

## DISH Q140474028
- name: Salade de museau
- other names: {"fr": "salade de museau"}
- countries: FR
- kinds: dish
- ingredients: pickled cucumber, vinaigrette, snout

## DISH Q140475304
- name: Churrasco marino
- description: Chilean fish sandwich
- countries: CL
- kinds: sandwich

## DISH Q140502350
- name: Baked fruit dessert
- description: fruit dessert with a topping
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q140518956
- name: Crayfish soup
- countries: (none)
- kinds: soup, crayfish as food, dish
- ingredients: crayfish

## DISH Q140520554
- name: Ofé Egwusi
- description: a traditional Igbo soup
- countries: (none)
- kinds: dish

## DISH Q140520817
- name: Fullkornsbröd
- other names: {"sv": "fullkornsbröd"}
- countries: (none)
- kinds: bread
- ingredients: wholemeal flour

## DISH Q140521127
- name: Lobster soup
- countries: (none)
- kinds: soup, lobster as food, dish
- ingredients: lobster

## DISH Q140521514
- name: Flan glacé
- other names: {"fr": "flan glacé"}
- countries: (none)
- kinds: cake

## DISH Q140523122
- name: Tumbarella
- other names: {"it": "tumbarella"}
- countries: IT
- kinds: stuffed pasta, sweet dish

## DISH Q140528272
- name: Ante
- other names: {"es": "ante"}
- description: Mexican dessert
- countries: (none)
- kinds: sponge cake

## DISH Q140528708
- name: Zelekivka zlyvanka
- countries: UA
- kinds: dish, porridge
- ingredients: Allium, Anethum graveolens, parsley, Allium sativum, table salt, potato, carrot, neckwear, salo, scallion, millet, Piper

## DISH Q1405557
- name: Schmarrn
- description: type of Austrian or Bavarian dishes consisting of a larger piece of food that is cut into pieces and stirred
- countries: (none)

## DISH Q140578443
- name: Dolmadakiа
- description: Greek dish made of stuffed grape leaves
- countries: GR
- kinds: dish
- has Wikipedia article: en

## DISH Q140586135
- name: Українські обрядові хліби
- other names: {"uk": "українські обрядові хліби"}
- countries: UA
- kinds: dish, bread

## DISH Q140589660
- name: Café Noir
- description: cookie
- countries: (none)
- kinds: cookie, biscuit
- ingredients: rapeseed oil, invert sugar, flour, icing, biscuit, sugar, coffee

## DISH Q140597616
- name: Bombay salad
- countries: IN
- kinds: salad

## DISH Q140611219
- name: Bird's nest pudding
- description: dessert resembling eggs in a nest
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q140621167
- name: Cookies "konyky and baryshni"
- description: Christmas cookies from Holovkivka, Kirovohrad Oblast, Ukraine
- countries: (none)
- kinds: Christmas cookies, panianky

## DISH Q140635489
- name: Carp on a stick
- description: smoked fish dish from Croatia
- countries: HR
- cuisines: Hungarian cuisine, Croatian cuisine
- kinds: smoked fish, fish dish
- ingredients: paprika, carp, table salt

## DISH Q140642111
- name: Abbacchio Romano PGI
- other names: {"zh": "Abbacchio Romano IGP"}
- description: Italian PGI fresh meat
- countries: IT
- kinds: meat

## DISH Q140642112
- name: Acciughe sotto sale del Mar Ligure PGI
- other names: {"zh": "Acciughe sotto sale del Mar Ligure IGP"}
- description: Italian PGI fish, mollusc or crustacean product
- countries: IT
- kinds: seafood

## DISH Q140642118
- name: Agnello del Centro Italia PGI
- other names: {"zh": "Agnello del Centro Italia IGP"}
- description: Italian PGI fresh meat
- countries: IT
- kinds: meat

## DISH Q140642137
- name: Bergamotto di Reggio Calabria - Olio essenziale PDO
- other names: {"zh": "Bergamotto di Reggio Calabria - Olio essenziale DOP"}
- description: Italian PDO essential oil
- countries: IT
- kinds: essential oil

## DISH Q140642140
- name: Bresaola della Valtellina PGI
- other names: {"zh": "Bresaola della Valtellina IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642144
- name: Burrata di Andria PGI
- other names: {"zh": "Burrata di Andria IGP"}
- description: Italian PGI cheese
- countries: IT
- kinds: cheese

## DISH Q140642146
- name: Caciottone di Norcia PGI
- other names: {"zh": "Caciottone di Norcia IGP"}
- description: Italian PGI cheese
- countries: IT
- kinds: cheese

## DISH Q140642150
- name: Cantucci Toscani PGI
- other names: {"zh": "Cantucci Toscani IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good

## DISH Q140642159
- name: Carne Salada del Trentino PGI
- other names: {"zh": "Carne Salada del Trentino IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642191
- name: Colatura di alici di Cetara PDO
- other names: {"zh": "Colatura di alici di Cetara DOP"}
- description: Italian PDO fish, mollusc or crustacean product
- countries: IT
- kinds: seafood

## DISH Q140642198
- name: Coppa di Parma PGI
- other names: {"zh": "Coppa di Parma IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642202
- name: Cozza di Scardovari PDO
- other names: {"zh": "Cozza di Scardovari DOP"}
- description: Italian PDO fish, mollusc or crustacean product
- countries: IT
- kinds: seafood

## DISH Q140642203
- name: Crudo di Cuneo PDO
- other names: {"zh": "Crudo di Cuneo DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product

## DISH Q140642205
- name: Culurgionis d'Ogliastra PGI
- other names: {"zh": "Culurgionis d'Ogliastra IGP"}
- description: Italian PGI pasta
- countries: IT
- kinds: pasta

## DISH Q140642206
- name: Dauno PDO
- other names: {"zh": "Dauno DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642207
- name: Erbazzone Reggiano PGI
- other names: {"zh": "Erbazzone Reggiano IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good

## DISH Q140642223
- name: Finocchiona PGI
- other names: {"zh": "Finocchiona IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642229
- name: Formaggio di Fossa di Sogliano PDO
- other names: {"zh": "Formaggio di Fossa di Sogliano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642234
- name: Gorgonzola PDO
- other names: {"zh": "Gorgonzola DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642255
- name: Lucanica di Picerno PGI
- other names: {"zh": "Lucanica di Picerno IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642256
- name: Lucca PDO
- other names: {"zh": "Lucca DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642282
- name: Montasio PDO
- other names: {"zh": "Montasio DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642286
- name: Mortadella Bologna PGI
- other names: {"zh": "Mortadella Bologna IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642287
- name: Mortadella di Prato PGI
- other names: {"zh": "Mortadella di Prato IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642298
- name: Olio Campania PGI
- other names: {"zh": "Olio Campania IGP"}
- description: Italian PGI olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642300
- name: Olio di Puglia PGI
- other names: {"zh": "Olio di Puglia IGP"}
- description: Italian PGI olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642301
- name: Olio di Roma PGI
- other names: {"zh": "Olio di Roma IGP"}
- description: Italian PGI olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642304
- name: Olio Lucano PGI
- other names: {"zh": "Olio Lucano IGP"}
- description: Italian PGI olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642307
- name: Pagnotta del Dittaino PDO
- other names: {"zh": "Pagnotta del Dittaino DOP"}
- description: Italian PDO bakery product
- countries: IT
- kinds: baked good

## DISH Q140642309
- name: Panpepato di Terni PGI
- other names: {"zh": "Panpepato di Terni IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good

## DISH Q140642315
- name: Pane Toscano PDO
- other names: {"zh": "Pane Toscano DOP"}
- description: Italian PDO bakery product
- countries: IT
- kinds: baked good

## DISH Q140642316
- name: Panforte di Siena PGI
- other names: {"zh": "Panforte di Siena IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good

## DISH Q140642317
- name: Parmigiano Reggiano PDO
- other names: {"zh": "Parmigiano Reggiano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642326
- name: Pecorino delle Balze Volterrane PDO
- other names: {"zh": "Pecorino delle Balze Volterrane DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642327
- name: Pecorino del Monte Poro PDO
- other names: {"zh": "Pecorino del Monte Poro DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642329
- name: Pecorino di Picinisco PDO
- other names: {"zh": "Pecorino di Picinisco DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642332
- name: Pecorino Siciliano PDO
- other names: {"zh": "Pecorino Siciliano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642347
- name: Piada Romagnola PGI
- other names: {"zh": "Piada Romagnola IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good

## DISH Q140642352
- name: Pitina PGI
- other names: {"zh": "Pitina IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642353
- name: Pizzoccheri della Valtellina PGI
- other names: {"zh": "Pizzoccheri della Valtellina IGP"}
- description: Italian PGI pasta
- countries: IT
- kinds: pasta

## DISH Q140642359
- name: Prosciutto Amatriciano PGI
- other names: {"zh": "Prosciutto Amatriciano IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642365
- name: Prosciutto di Sauris PGI
- other names: {"zh": "Prosciutto di Sauris IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642368
- name: Provola dei Nebrodi PDO
- other names: {"zh": "Provola dei Nebrodi DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642370
- name: Provolone Valpadana PDO
- other names: {"zh": "Provolone Valpadana DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642371
- name: Spretz Tzaorì PDO
- other names: {"zh": "Spretz Tzaorì DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642380
- name: Ricciarelli di Siena PGI
- other names: {"zh": "Ricciarelli di Siena IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good

## DISH Q140642395
- name: Salame Felino PGI
- other names: {"zh": "Salame Felino IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642398
- name: Salame S. Angelo PGI
- other names: {"zh": "Salame S. Angelo IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642404
- name: Salva Cremasco PDO
- other names: {"zh": "Salva Cremasco DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642405
- name: Sardegna PDO
- other names: {"zh": "Sardegna DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642410
- name: Seggiano PDO
- other names: {"zh": "Seggiano DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642411
- name: Sicilia PGI
- other names: {"zh": "Sicilia IGP"}
- description: Italian PGI olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642416
- name: Südtiroler Speck PGI
- other names: {"zh": "Südtiroler Speck IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642420
- name: Stelvio o Stilfser PDO
- other names: {"zh": "Stelvio o Stilfser DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese

## DISH Q140642422
- name: Schüttelbrot Alto Adige PGI
- other names: {"zh": "Schüttelbrot Alto Adige IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good

## DISH Q140642428
- name: Terre Aurunche PDO
- other names: {"zh": "Terre Aurunche DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642431
- name: Tinca Gobba Dorata del Pianalto di Poirino PDO
- other names: {"zh": "Tinca Gobba Dorata del Pianalto di Poirino DOP"}
- description: Italian PDO fish, mollusc or crustacean product
- countries: IT
- kinds: seafood

## DISH Q140642436
- name: Tuscia PDO
- other names: {"zh": "Tuscia DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642437
- name: Umbria PDO
- other names: {"zh": "Umbria DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642456
- name: Vulture PDO
- other names: {"zh": "Vulture DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q140642460
- name: Zampina Sammichelina PGI
- other names: {"zh": "Zampina Sammichelina IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product

## DISH Q140642551
- name: Sevadas di Sardegna PGI
- other names: {"zh": "Sevadas di Sardegna IGP"}
- description: Italian PGI agricultural product
- countries: IT
- kinds: baked good

## DISH Q140644397
- name: Betamax (food)
- description: a Filipino dish made from chicken, duck or pig blood
- countries: PH
- kinds: dish
- ingredients: blood
- has Wikipedia article: en

## DISH Q140645901
- name: Mocetta PAT
- other names: {"zh": "Mocetta PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140645903
- name: Saouseusse PAT
- other names: {"zh": "Saouseusse PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140645904
- name: Teteun PAT
- other names: {"zh": "Teteun PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140645905
- name: Tseur achétaye PAT
- other names: {"zh": "Tseur achétaye PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140645907
- name: Brossa PAT
- other names: {"zh": "Brossa PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140645909
- name: Formaggio di capra a pasta molle PAT
- other names: {"zh": "Formaggio di capra a pasta molle PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140645911
- name: Formaggio di pecora o capra a pasta pressata PAT
- other names: {"zh": "Formaggio di pecora o capra a pasta pressata PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140645912
- name: Formaggio misto PAT
- other names: {"zh": "Formaggio misto PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140645913
- name: Reblec PAT
- other names: {"zh": "Reblec PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140645914
- name: Reblec de crama PAT
- other names: {"zh": "Reblec de crama PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140645915
- name: Salignoùn PAT
- other names: {"zh": "Salignoùn PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140645916
- name: Séras PAT
- other names: {"zh": "Séras PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140645917
- name: Toma di Gressoney PAT
- other names: {"zh": "Toma di Gressoney PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140645920
- name: Micóoula PAT
- other names: {"zh": "Micóoula PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140645921
- name: Piata di Issogne PAT
- other names: {"zh": "Piata di Issogne PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140645922
- name: Beuro coló PAT
- other names: {"zh": "Beuro coló PAT"}
- description: traditional Italian edible fat (PAT)
- countries: IT
- kinds: edible fats and oils

## DISH Q140645923
- name: Beuro de brossa PAT
- other names: {"zh": "Beuro de brossa PAT"}
- description: traditional Italian edible fat (PAT)
- countries: IT
- kinds: edible fats and oils

## DISH Q140645924
- name: Burro centrifugato di siero PAT
- other names: {"zh": "Burro centrifugato di siero PAT"}
- description: traditional Italian edible fat (PAT)
- countries: IT
- kinds: edible fats and oils

## DISH Q140645925
- name: Seupa à la vapelenentze PAT
- other names: {"zh": "Seupa à la vapelenentze PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140650734
- name: Einstein
- description: 2008 Brazilian television film
- countries: BR
- kinds: Lactuca sativa

## DISH Q140654622
- name: Micischia PAT
- other names: {"zh": "Micischia PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654623
- name: Salsicciotto frentano PAT
- other names: {"zh": "Salsicciotto frentano PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654627
- name: Soppressata PAT
- other names: {"zh": "Soppressata PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654637
- name: Cagionetti PAT
- other names: {"zh": "Cagionetti PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654639
- name: Pizza scime PAT
- other names: {"zh": "Pizza scime PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654642
- name: Supposte PAT
- other names: {"zh": "Supposte PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654645
- name: Marruca dei Certosini della Grancia di San Demetrio PAT
- other names: {"zh": "Marruca dei Certosini della Grancia di San Demetrio PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654647
- name: Pizza rustica PAT
- other names: {"zh": "Pizza rustica PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654651
- name: Involtini di interiora d'agnello/capretto arrostiti PAT
- other names: {"zh": "Involtini di interiora d'agnello/capretto arrostiti PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140654655
- name: Tagliolini con il latte PAT
- other names: {"zh": "Tagliolini con il latte PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140654661
- name: Agnello da latte PAT
- other names: {"zh": "Agnello da latte PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654663
- name: Spalla di San Secondo PAT
- other names: {"zh": "Spalla di San Secondo PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654674
- name: Bustrengo PAT
- other names: {"zh": "Bustrengo PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654677
- name: Gialletti PAT
- other names: {"zh": "Gialletti PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654683
- name: Gnocco fritto PAT
- other names: {"zh": "Gnocco fritto PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654687
- name: Passatelli PAT
- other names: {"zh": "Passatelli PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654691
- name: Pasta rasa PAT
- other names: {"zh": "Pasta rasa PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654696
- name: Sfoglia dell'Emilia PAT
- other names: {"zh": "Sfoglia dell'Emilia PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654701
- name: Straccadenti PAT
- other names: {"zh": "Straccadenti PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654704
- name: Stricchetti PAT
- other names: {"zh": "Stricchetti PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654710
- name: Tagliatelle con gli stridoli PAT
- other names: {"zh": "Tagliatelle con gli stridoli PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654714
- name: Tigella modenese PAT
- other names: {"zh": "Tigella modenese PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654717
- name: Tortelli di ricotta alla piacentina PAT
- other names: {"zh": "Tortelli di ricotta alla piacentina PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654720
- name: Tortelli di zucca PAT
- other names: {"zh": "Tortelli di zucca PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654724
- name: Zuppa inglese PAT
- other names: {"zh": "Zuppa inglese PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654736
- name: Bruzzo PAT
- other names: {"zh": "Bruzzo PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q140654753
- name: Scarpelle PAT
- other names: {"zh": "Scarpelle PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654756
- name: Uccelli PAT
- other names: {"zh": "Uccelli PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654760
- name: Carne di capra PAT
- other names: {"zh": "Carne di capra PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654762
- name: Salsiccia alla salentina PAT
- other names: {"zh": "Salsiccia alla salentina PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654773
- name: Paposcia (Pizza a vamp) di Vico del Gargano PAT
- other names: {"zh": "Paposcia (Pizza a vamp) di Vico del Gargano PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654775
- name: Pucce PAT
- other names: {"zh": "Pucce PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654777
- name: Paparine 'nfucate PAT
- other names: {"zh": "Paparine 'nfucate PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140654779
- name: Piselli a cecamariti PAT
- other names: {"zh": "Piselli a cecamariti PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140654781
- name: Spezzatu PAT
- other names: {"zh": "Spezzatu PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140654785
- name: Salsiccia sarda PAT
- other names: {"zh": "Salsiccia sarda PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product

## DISH Q140654797
- name: Coccoi a pitzus PAT
- other names: {"zh": "Coccoi a pitzus PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654799
- name: Coccoietto con l'uovo PAT
- other names: {"zh": "Coccoietto con l'uovo PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654801
- name: Culurgiones PAT
- other names: {"zh": "Culurgiones PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654803
- name: Focacce di ricotta PAT
- other names: {"zh": "Focacce di ricotta PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654805
- name: Pani e saba PAT
- other names: {"zh": "Pani e saba PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654808
- name: Uciatìni PAT
- other names: {"zh": "Uciatìni PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good

## DISH Q140654810
- name: Insalata di tonno PAT
- other names: {"zh": "Insalata di tonno PAT"}
- description: traditional Italian traditional dish (PAT)
- countries: IT
- kinds: dish

## DISH Q140654812
- name: Musciame di tonno Sardo PAT
- other names: {"zh": "Musciame di tonno Sardo PAT"}
- description: traditional Italian fish, mollusc or crustacean product (PAT)
- countries: IT
- kinds: seafood

## DISH Q140654820
- name: Carne fresca di vacca PAT
- other names: {"zh": "Carne fresca di vacca PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product
