# Review batch names-011

## DISH Q113432237
- name: Hvedebrød
- other names: {"da": "Hvedebrød"}
- countries: (none)
- kinds: bread

## DISH Q113432251
- name: Krydder
- description: Danish breakfast bread
- countries: DK
- kinds: bread

## DISH Q113432255
- name: Maskintorsk
- other names: {"da": "maskintorsk"}
- countries: (none)
- kinds: dish

## DISH Q11343229
- name: Muchi
- other names: {"zh": "鬼餅"}
- description: type of soft confectionery made of pounded glutinous rice
- countries: (none)
- kinds: annual event, mochi, confectionery
- ingredients: rice
- has Wikipedia article: en

## DISH Q11344145
- name: メロンゼリー
- other names: {"ja": "メロンゼリー"}
- countries: (none)
- kinds: gelatin dessert

## DISH Q11344563
- name: モヨロ鍋
- other names: {"ja": "モヨロ鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q113451751
- name: Banjar Satay
- description: traditional satay dish from South Kalimantan, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: satay, dish, Indonesian cuisine, human food, type of food or dish
- ingredients: skewer, chicken as food

## DISH Q113455543
- name: Xis
- description: Brazilian grilled sandwich
- countries: BR
- cuisines: Brazilian cuisine
- kinds: sandwich
- has Wikipedia article: en

## DISH Q1134556
- name: Fuet
- description: Catalan, dry cured pork sausage
- countries: ES
- kinds: dry sausage
- ingredients: pork
- has Wikipedia article: en

## DISH Q11346020
- name: Yokosuka navy burger
- countries: JP
- kinds: food, hamburger

## DISH Q11346203
- name: Yōguru
- description: yogurt-like snack
- countries: (none)
- kinds: dagashi

## DISH Q113463632
- name: Hignai bonbon
- other names: {"fr": "Hignai bonbon"}
- countries: (none)
- kinds: candy
- ingredients: condensed milk

## DISH Q113463691
- name: Gâteau sec
- other names: {"fr": "Gâteau sec"}
- countries: (none)
- kinds: beignet

## DISH Q113463719
- name: Wouri bonbon
- other names: {"fr": "Wouri bonbon"}
- countries: (none)
- kinds: candy

## DISH Q113463743
- name: Souka bonbon
- other names: {"fr": "Souka bonbon"}
- countries: GN
- kinds: cake
- ingredients: sugar

## DISH Q11346907
- name: Radio-yaki
- countries: JP
- kinds: beef dish
- ingredients: tendon as food, wheat flour

## DISH Q11347260
- name: Rafute
- other names: {"zh": "沖繩東坡肉"}
- description: pork rib dish in the Okinawan cuisine
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en, zh

## DISH Q11347431
- name: Lamu shabu
- countries: (none)
- kinds: shabu-shabu, nabemono

## DISH Q113474336
- name: Kouya noun hignai
- description: cassava couscous with curdled milk
- countries: GN
- kinds: couscous

## DISH Q11347447
- name: Ramune
- description: Japanese confectionery
- countries: JP
- kinds: tablet candy
- has Wikipedia article: en

## DISH Q11347758
- name: Ramen salad
- countries: (none)
- kinds: salad, ramen in Hokkaido, cold noodle

## DISH Q11347764
- name: Ramen and rice
- description: set menu of ramen dish
- countries: (none)
- kinds: ramen

## DISH Q113483181
- name: Œufs à la Cardinal
- other names: {"fr": "œufs à la Cardinal"}
- countries: (none)
- kinds: culinary speciality

## DISH Q113484300
- name: Choux borai
- other names: {"fr": "Choux borai"}
- countries: GN
- kinds: sauce

## DISH Q113484314
- name: Tola borai
- other names: {"fr": "Tola borai"}
- countries: GN
- kinds: sauce

## DISH Q11348512
- name: Hearth bread
- description: rustic or artisan bread
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q113487285
- name: Roseau d'Annecy
- countries: (none)
- kinds: field of study, bonbon
- ingredients: liqueur, chocolate

## DISH Q113495133
- name: Frixen Cola
- other names: {"an": "Frixen Cola"}
- countries: ES
- kinds: human food
- ingredients: stevia, caffeine, water

## DISH Q11349663
- name: Lettuce maki
- countries: (none)
- kinds: makizushi

## DISH Q11349819
- name: Retort pouch curry
- other names: {"zh": "速食咖哩"}
- countries: (none)
- kinds: Japanese curry, retort pouch

## DISH Q11349852
- name: Rebanira itame
- other names: {"zh": "韭菜炒牛肝"}
- description: dish in Japanese Chinese cuisine consisting of liver, garlic chives, and mung bean sprouts
- countries: JP
- cuisines: Japanese Chinese cuisine
- kinds: dish
- ingredients: mung bean sprout, liver as food, Allium tuberosum

## DISH Q11349933
- name: Lemon steak
- countries: JP
- kinds: beefsteak
- ingredients: lemon, beef

## DISH Q11350917
- name: ロースハム
- other names: {"ja": "ロースハム"}
- countries: (none)
- kinds: ham

## DISH Q113510622
- name: 당당치킨
- other names: {"ko": "당당치킨"}
- countries: (none)
- kinds: Korean fried chicken

## DISH Q11351069
- name: Romen
- countries: (none)
- kinds: fried noodle, noodle soup

## DISH Q11351260
- name: Wairo monaka
- countries: (none)
- kinds: bribery, monaka

## DISH Q11351281
- name: Wine yokan
- description: yokan made with wine
- countries: (none)
- kinds: Yōkan
- ingredients: wine

## DISH Q11351431
- name: Wani ryori
- description: Japanese regional cuisine made from shark meat
- countries: (none)
- kinds: dish, fish dish
- ingredients: shark as food

## DISH Q11352226
- name: Roll with sliced sausage
- countries: AT
- kinds: sandwich
- ingredients: Kaiser roll, sausage

## DISH Q11352485
- name: Ichimi tougarashi
- description: Japanese chili pepper-only seasoning
- countries: JP
- kinds: condiment, chili powder

## DISH Q113528312
- name: Moquai noun kiri
- other names: {"fr": "Moquai noun kiri"}
- countries: GN
- kinds: dessert

## DISH Q11353238
- name: Issen yōshoku
- other names: {"zh": "一錢洋食"}
- description: Japanese crepe-like dish with Worcestershire sauce and chopped scallion
- countries: JP
- kinds: teppanyaki

## DISH Q113534616
- name: Käferbohnensalat
- countries: AT
- kinds: salad
- ingredients: onion, pumpkin seed oil, snap bean

## DISH Q11353687
- name: Nanakusa-gayu
- countries: (none)
- kinds: congee, Japanese rice dish

## DISH Q113541568
- name: Eier mit Sahnen Sauce
- other names: {"de": "Eier mit Sahnen Sauce"}
- countries: (none)
- kinds: dish

## DISH Q113543725
- name: 石門活魚
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish
- has Wikipedia article: zh

## DISH Q11355117
- name: 三官飴
- other names: {"ja": "三官飴"}
- countries: (none)
- kinds: ame

## DISH Q11355298
- name: Misaki tuna ramen
- countries: (none)
- kinds: ramen

## DISH Q11355376
- name: Sanpeijiru
- countries: (none)
- kinds: nabemono, shirumono, fish dish

## DISH Q11355870
- name: 三杯もち
- other names: {"ja": "三杯もち"}
- countries: (none)
- kinds: mochi

## DISH Q113560755
- name: Air-fried fries
- description: fries cooked in an air fryer
- countries: (none)
- kinds: fries
- has Wikipedia article: en

## DISH Q11356842
- name: 三石羊羹
- other names: {"ja": "三石羊羹"}
- countries: (none)
- kinds: Yōkan

## DISH Q11356922
- name: Mikasano
- description: confectionery manufactured in Taketa, Oita, Japan
- countries: (none)
- kinds: Miyagegashi, wagashi
- ingredients: dough

## DISH Q11356975
- name: 三色パン
- other names: {"ja": "三色パン"}
- countries: (none)
- kinds: sweet bread

## DISH Q11357853
- name: Bublanina
- description: fruit sponge cake
- countries: CZ, PL, SK
- kinds: sponge cake

## DISH Q1135831
- name: Rogan josh
- other names: {"zh": "奶油羊肉咖哩"}
- description: Aromatic curried meat
- countries: IR
- kinds: dish, lamb dish, mutton curry
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q11358938
- name: Kamikawa ramen
- countries: (none)
- kinds: ramen in Hokkaido

## DISH Q113590177
- name: Rådhuspandekage
- other names: {"da": "Rådhuspandekage"}
- description: Sweet dish served traditionally by the Copenhagen Town Hall at festivities
- countries: (none)
- kinds: pancake

## DISH Q11362646
- name: Jambo mochi
- countries: JP
- kinds: mochi, skewer

## DISH Q113627927
- name: Kebda Mchermla
- countries: DZ
- kinds: dish, recipe

## DISH Q113627938
- name: Arayech
- countries: DZ
- kinds: pastry

## DISH Q1136304
- name: Istrian stew
- description: stew
- countries: HR
- kinds: food, stew
- ingredients: bean
- has Wikipedia article: en

## DISH Q113632050
- name: Cuisine gauloise
- countries: (none)
- kinds: dish

## DISH Q113644741
- name: Суточные щи
- other names: {"ru": "Суточные щи"}
- countries: RU
- cuisines: Russian cuisine
- kinds: shchi, dish
- ingredients: pig head, sauerkraut

## DISH Q1136488
- name: Gozinaki
- other names: {"zh": "戈吉納基"}
- description: sweetness made of nuts and honey
- countries: GE
- cuisines: Georgian cuisine
- kinds: brittle
- ingredients: caramel, nut, honey
- has Wikipedia article: en, zh

## DISH Q113653553
- name: Pâté de campagne breton
- other names: {"fr": "Pâté de campagne breton"}
- countries: FR
- kinds: Pâté de campagne, human food

## DISH Q113659074
- name: Celozrnné pečivo
- other names: {"cs": "celozrnné pečivo"}
- countries: (none)
- kinds: pastry
- ingredients: whole grain

## DISH Q11366283
- name: Nakashibetsu milky ramen
- countries: (none)
- kinds: ramen in Hokkaido

## DISH Q113664446
- name: Saag gosht
- description: saag with meat
- countries: (none)
- kinds: dish
- ingredients: saag, meat

## DISH Q113666509
- name: Taco acorazado
- countries: MX
- cuisines: Mexican cuisine
- kinds: dish, street food, taco
- ingredients: Phaseolus vulgaris, rice, corn tortilla, ragout, sauce

## DISH Q113667563
- name: Seviyan
- description: sweet dish
- countries: (none)
- cuisines: South Asian cuisine
- kinds: kheer, sweet dish
- ingredients: vermicelli, milk

## DISH Q1136702
- name: Passatelli
- description: typical pasta from Romagna
- countries: IT
- cuisines: Italian cuisine
- kinds: pasta
- ingredients: grated cheese, bread crumbs, egg as food
- has Wikipedia article: en

## DISH Q11367190
- name: Nakami soup
- description: okinawan pork tripe soup
- countries: JP
- kinds: soup, offal dish, New Year's food
- ingredients: offal

## DISH Q11367434
- name: Miyako kombu
- description: Japanese kelp snack
- countries: JP
- kinds: snack
- ingredients: kelp

## DISH Q11367883
- name: Kushikino tuna ramen
- countries: (none)
- kinds: ramen, tuna dish

## DISH Q11367956
- name: Marubōro
- other names: {"zh": "丸芳露"}
- countries: (none)
- kinds: bolo

## DISH Q113680312
- name: Tohu chauk
- description: dried Burmese tofu
- countries: MM
- kinds: dried food
- ingredients: Burmese tofu

## DISH Q1136833
- name: Radiatori
- description: shaped pasta
- countries: IT
- kinds: type of pasta, pasta
- has Wikipedia article: en

## DISH Q1136847
- name: Strozzapreti
- description: type of pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q113685888
- name: Cupim casqueirado
- other names: {"pt": "Cupim casqueirado"}
- countries: BR
- kinds: human food, dish
- ingredients: rucola, beef, cassava, parsley, tomato, onion

## DISH Q1136876
- name: Okinawa soba
- other names: {"zh": "冲绳面条"}
- description: Ryukyuan food
- countries: JP
- kinds: dish, Japanese noodles
- ingredients: noodle
- has Wikipedia article: en, zh

## DISH Q1136907
- name: Cream pie
- other names: {"zh": "奶油派"}
- description: multi layered custard cream based pie
- countries: US
- kinds: sweet pie
- ingredients: cream
- has Wikipedia article: en

## DISH Q113699860
- name: Torrone di Caltanissetta PAT
- other names: {"zh": "Torrone di Caltanissetta PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: turrón, food, dessert, baked good

## DISH Q11370574
- name: Chichi dango
- description: type of Japanese confectionery
- countries: (none)
- kinds: gyūhi, Miyagegashi, dango
- ingredients: coconut milk
- has Wikipedia article: en

## DISH Q11370671
- name: 乾燥餅
- other names: {"ja": "乾燥餅"}
- countries: (none)
- kinds: mochi, dried food

## DISH Q113712201
- name: Congolaiske
- other names: {"nl": "congolaiske"}
- countries: (none)
- kinds: type of food or dish, Praline

## DISH Q1137204
- name: Country Captain
- description: curried chicken and rice dish in the Southern US; a mild stew of browned chicken pieces, onions, and curry powder with almonds and raisins or currants over rice
- countries: US
- kinds: food, chicken curry, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q11372049
- name: Gokkateya yokan
- countries: (none)
- kinds: Yōkan

## DISH Q11372295
- name: Gokabou
- other names: {"zh": "五家寶"}
- description: Japanese confection
- countries: JP
- kinds: wagashi
- ingredients: rice
- has Wikipedia article: en

## DISH Q113724362
- name: Nkate cake
- description: Ghanaian and Equatoguinean peanut sweet
- countries: (none)
- kinds: candy
- ingredients: peanut

## DISH Q11372634
- name: Goshiki namagashi
- countries: (none)
- kinds: pentad, namagashi

## DISH Q11372639
- name: Goshiki mame
- countries: (none)
- kinds: higashi
- ingredients: pea

## DISH Q11373260
- name: 井上鍋
- other names: {"ja": "井上鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q113739
- name: Katsuobushi
- other names: {"zh": "柴鱼片"}
- description: dried, fermented, and smoked skipjack tuna
- countries: CN, JP
- kinds: smoked fish, cured fish, dried fish, fish dish
- ingredients: skipjack tuna
- has Wikipedia article: en, zh

## DISH Q11374720
- name: Kyōgashi
- countries: (none)
- kinds: wagashi

## DISH Q11374829
- name: Kyoto ramen
- other names: {"zh": "京都拉麵小路"}
- countries: (none)
- kinds: ramen
- has Wikipedia article: zh

## DISH Q1137574
- name: Porkkanalaatikko
- description: traditional Finnish dish
- countries: FI
- kinds: dish
- ingredients: carrot
- has Wikipedia article: en

## DISH Q11376061
- name: 頭髮醬油
- countries: (none)
- kinds: imitation food
- ingredients: head hair
- has Wikipedia article: zh

## DISH Q1137679
- name: Baozi
- other names: {"zh": "包子"}
- description: filled bun
- countries: CN
- cuisines: Chinese cuisine
- kinds: food, type of food or dish, dumpling, stuffed pasta, bun
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q1137701
- name: Taco rice
- description: popular example of Okinawan cuisine
- countries: JP
- kinds: Okinawan cuisine, taco, Japanese rice dish
- ingredients: Lactuca, salsa (food), beef, tomato, rice
- has Wikipedia article: en

## DISH Q11377628
- name: Tanindon
- description: Japanese rice dish of pork and eggs
- countries: JP
- cuisines: Japanese cuisine
- kinds: egg dish, donburi, meat dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q11377735
- name: 仙台づけ丼
- other names: {"ja": "仙台づけ丼"}
- countries: JP
- kinds: donburi

## DISH Q11377768
- name: Sendai ramen
- countries: (none)
- kinds: ramen

## DISH Q11377799
- name: Sendai miso
- countries: (none)
- kinds: miso

## DISH Q11378086
- name: 仙台駄菓子
- other names: {"ja": "仙台駄菓子"}
- countries: (none)
- kinds: dagashi

## DISH Q11378279
- name: 代用醤油
- other names: {"ja": "代用醤油"}
- description: Soy sauce substitute
- countries: (none)
- kinds: soy sauce, imitation food

## DISH Q113785146
- name: Hiroshimayaki
- description: type of okonomiyaki
- countries: (none)
- kinds: okonomiyaki

## DISH Q11378803
- name: Iyo satsuma
- countries: JP
- kinds: shirumono

## DISH Q11378917
- name: Ise takuan
- countries: (none)
- kinds: takuan
- ingredients: Misono daikon

## DISH Q11380763
- name: Datemaki
- other names: {"zh": "伊達卷"}
- countries: (none)
- kinds: fish dish, egg dish
- ingredients: chicken egg, fish surimi

## DISH Q113815312
- name: Kansai-Style Okonomiyaki
- countries: (none)
- kinds: okonomiyaki

## DISH Q11381926
- name: Chimigin
- description: Aleut dish
- countries: (none)
- kinds: dish

## DISH Q113826628
- name: Saag aloo
- description: saag with potato
- countries: IN
- cuisines: Punjabi cuisine
- kinds: dish
- ingredients: potato, saag

## DISH Q113828119
- name: Cotignac d'Orléans
- other names: {"fr": "cotignac d'Orléans"}
- countries: FR
- kinds: confectionery
- ingredients: alginate, quince, ponceau 4R, tartaric acid, sugar, water

## DISH Q113833737
- name: Biétrumé
- other names: {"fr": "Biétrumé"}
- countries: BE
- kinds: krówki, sweetmeat

## DISH Q113833808
- name: Bostock
- description: pastry
- countries: FR
- kinds: viennoiserie

## DISH Q1138371
- name: Crab cake
- other names: {"zh": "蟹肉餅"}
- description: American crab dish
- countries: US
- cuisines: cuisine of the United States
- kinds: crab dish, dish
- ingredients: crab meat
- has Wikipedia article: en, zh

## DISH Q113839234
- name: Langue écarlate
- other names: {"fr": "langue écarlate"}
- countries: (none)
- kinds: dish

## DISH Q113840194
- name: Omelette aux fines herbes
- other names: {"fr": "omelette aux fines herbes"}
- countries: (none)
- kinds: dish

## DISH Q113840312
- name: Pâté (pâtisserie)
- other names: {"fr": "Pâté (pâtisserie)"}
- countries: FR
- kinds: pastry, dish

## DISH Q113840402
- name: Plokkfiskur
- other names: {"de": "Plokkfiskur"}
- countries: (none)
- kinds: dish

## DISH Q11384932
- name: Sano ramen
- countries: (none)
- kinds: ramen

## DISH Q113850233
- name: Steamed prawns with garlic
- other names: {"zh": "蒜蓉蒸蝦"}
- description: Chinese dish
- countries: CN
- kinds: dish
- ingredients: garlic, Melicertus kerathurus, rice vermicelli

## DISH Q113854965
- name: Pickling broth
- countries: (none)
- kinds: Collard liquor

## DISH Q113855577
- name: Arippayasam
- description: Payasasm made of rice
- countries: (none)
- kinds: payasam, sweet dish

## DISH Q11385745
- name: 保存パン
- other names: {"ja": "保存パン"}
- countries: (none)
- kinds: preserved food, bread

## DISH Q113858365
- name: 黄面鸡
- countries: (none)
- kinds: chicken dish, food preparation technique
- has Wikipedia article: zh

## DISH Q113859684
- name: Zucchini slice
- description: dish common in Australia and New Zealand
- countries: AU
- cuisines: Australian cuisine, New Zealand cuisine
- kinds: frittata
- ingredients: zucchini
- has Wikipedia article: en

## DISH Q11386094
- name: Shinshū miso
- countries: JP
- kinds: miso

## DISH Q11386205
- name: 信玄鍋
- other names: {"ja": "信玄鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q11388871
- name: Nyūzen Brown Ramen
- countries: (none)
- kinds: miso ramen

## DISH Q11389772
- name: Halawa
- description: Egyptian food prepared from Tehina, sugar and flavors
- countries: (none)
- kinds: pastry

## DISH Q113900228
- name: South Asian bread
- description: bread of the Indian subcontinent
- countries: (none)
- kinds: bread

## DISH Q113900280
- name: ਬੋਟੀ
- other names: {"pa": "ਬੋਟੀ"}
- countries: (none)
- kinds: finger food, piece, edible tableware, dimensionless unit, unit of amount, counting unit, type of technology, use of bread
- ingredients: South Asian bread, meat

## DISH Q11390440
- name: Hatchō Miso
- countries: JP
- kinds: miso

## DISH Q11390680
- name: Yakidai
- countries: (none)
- kinds: grilled fish
- ingredients: red seabream

## DISH Q11390969
- name: Yawata-maki
- countries: JP
- kinds: fish dish, roll
- ingredients: Arctium lappa

## DISH Q11391124
- name: Hachinohe ramen
- countries: (none)
- kinds: shoyu ramen

## DISH Q11391553
- name: Hachiōji ramen
- other names: {"zh": "八王子拉麵"}
- countries: (none)
- kinds: ramen, shoyu ramen

## DISH Q11392360
- name: 六方焼
- other names: {"ja": "六方焼"}
- countries: (none)
- kinds: wagashi

## DISH Q11392516
- name: 六角凧サブレー
- other names: {"ja": "六角凧サブレー"}
- countries: (none)
- kinds: Sablé

## DISH Q1139319
- name: Semla
- other names: {"zh": "薩姆拉"}
- description: traditional Scandinavian sweet roll associated with Shrove Tuesday
- countries: FI, SE
- cuisines: Swedish cuisine, Finnish cuisine
- kinds: food, sweet roll
- has Wikipedia article: en, zh

## DISH Q1139364
- name: Chūkadon
- other names: {"zh": "中华丼"}
- description: Japanese dish
- countries: JP
- kinds: dish, donburi, rice dish
- has Wikipedia article: en, zh

## DISH Q11393750
- name: Gu-zōni
- countries: (none)
- kinds: zōni

## DISH Q1139389
- name: Dal
- other names: {"zh": "滨豆黄糊糊"}
- description: pulses used throughout South Asia in cooking
- countries: (none)
- kinds: bean, dish, food ingredient
- has Wikipedia article: en, zh

## DISH Q113945861
- name: Fruit sandwich
- description: sandwich originating in Japan
- countries: JP
- kinds: sandwich, fruit dish

## DISH Q113946149
- name: Golonka
- countries: (none)
- kinds: meat dish, dish
- ingredients: ham hock

## DISH Q113948914
- name: Louise cake
- description: New Zealand shortcake
- countries: NZ
- kinds: shortcake
- has Wikipedia article: en

## DISH Q11395289
- name: 冷しゃぶ
- other names: {"ja": "冷しゃぶ"}
- countries: (none)
- kinds: shabu-shabu

## DISH Q11395299
- name: 冷たい肉そば
- other names: {"ja": "冷たい肉そば"}
- countries: JP
- kinds: dish, soba

## DISH Q11395303
- name: Hiyashi ramen
- other names: {"zh": "冷拉麵"}
- countries: (none)
- kinds: ramen, cold noodle
- has Wikipedia article: zh

## DISH Q11395307
- name: Hiyashiru
- description: cold miso soup
- countries: JP
- kinds: miso soup, cold sweet soup

## DISH Q113958126
- name: Cukroví
- other names: {"cs": "cukroví"}
- countries: (none)
- kinds: candy

## DISH Q11395942
- name: Hakodate ramen
- other names: {"zh": "函館拉麵"}
- countries: (none)
- kinds: ramen in Hokkaido, shio ramen

## DISH Q11396182
- name: Kiriboshi daikon
- countries: JP
- kinds: vegetable dish
- ingredients: Japanese radish

## DISH Q11396701
- name: Beppu reimen
- countries: JP
- kinds: naengmyeon

## DISH Q11396840
- name: Rikyū manjū
- countries: (none)
- kinds: manjū
- ingredients: muscovado

## DISH Q11397032
- name: 削りかまぼこ
- other names: {"ja": "削りかまぼこ"}
- countries: (none)
- kinds: kamaboko

## DISH Q11398680
- name: Kajiki Manjū
- description: Traditional steamed Japanese confection
- countries: (none)
- kinds: Miyagegashi
- has Wikipedia article: en

## DISH Q113988259
- name: Mozzarella di Gioia del Colle PDO
- other names: {"zh": "Mozzarella di Gioia del Colle DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, mozzarella

## DISH Q113996881
- name: Sour soup fish
- other names: {"zh": "酸汤鱼"}
- description: Chinese fish soup dish
- countries: (none)
- kinds: fish dish, sour soup, food
- has Wikipedia article: en, zh

## DISH Q11399815
- name: Sukesōyaki
- countries: (none)
- kinds: funoyaki

## DISH Q11399904
- name: 労研饅頭
- other names: {"ja": "労研饅頭"}
- countries: JP
- kinds: confectionery

## DISH Q11400397
- name: Katsuura tantanmen
- other names: {"zh": "勝浦式擔擔麵"}
- countries: JP
- kinds: dandan noodles
- ingredients: chili oil

## DISH Q1140186
- name: Danish
- other names: {"zh": "丹麥酥"}
- description: multilayered, laminated sweet pastry
- countries: AT, DK
- cuisines: Danish cuisine
- kinds: viennoiserie
- ingredients: Danish pastry dough
- has Wikipedia article: en, zh

## DISH Q114023789
- name: Roll
- description: any roll-like dish
- countries: (none)
- kinds: dish

## DISH Q11402431
- name: Ramen in Hokkaido
- other names: {"zh": "北海道拉麵"}
- countries: (none)
- kinds: ramen

## DISH Q114040821
- name: Dendermondse paardenworsten
- other names: {"nl": "Dendermondse paardenworsten"}
- countries: (none)
- kinds: stew, dish

## DISH Q114042285
- name: シーユー
- other names: {"ja": "シーユー"}
- countries: TH
- kinds: soy sauce

## DISH Q114042294
- name: トヨ (食品)
- other names: {"ja": "トヨ (食品)"}
- countries: PH
- kinds: soy sauce

## DISH Q11404913
- name: 十勝清水牛玉ステーキ丼
- other names: {"ja": "十勝清水牛玉ステーキ丼"}
- countries: (none)
- kinds: rice dish

## DISH Q11404916
- name: 十勝芽室コーン炒飯
- other names: {"ja": "十勝芽室コーン炒飯"}
- countries: (none)
- kinds: chāhan

## DISH Q11405053
- name: Jūmonji ramen
- countries: (none)
- kinds: shoyu ramen

## DISH Q1140567
- name: Pineapple bun
- other names: {"zh": "菠萝面包"}
- description: sweet bun, popular in Hong Kong, named after its characteristic topping, similar to the surface of a pineapple fruit; does not contain any pineapples
- countries: HK
- kinds: food, sweet roll, bun
- has Wikipedia article: en, zh

## DISH Q114057994
- name: Durus kura
- description: Traditional fried chicken curry
- countries: BD
- cuisines: Bangladeshi cuisine
- kinds: roast chicken
- ingredients: chicken
- has Wikipedia article: en

## DISH Q11406984
- name: Hansuke dōfu
- countries: (none)
- kinds: tofu
- ingredients: eel head, tofu

## DISH Q11408324
- name: Nanzenji tofu
- other names: {"zh": "南禪寺豆腐"}
- countries: (none)
- kinds: tofu

## DISH Q11408416
- name: Nanbangashi
- other names: {"zh": "南蛮菓子"}
- description: Japanese sugar confectionery
- countries: (none)
- kinds: food, wagashi

## DISH Q11408569
- name: Nambu sembei
- description: Japanese rice cracker
- countries: JP
- kinds: confectionery, senbei

## DISH Q11409239
- name: Atsugi sirokoro horumon
- other names: {"zh": "厚木內臟燒肉"}
- countries: JP
- kinds: offal dish, horumonyaki
- ingredients: offal

## DISH Q1141033
- name: Jajangmyeon
- other names: {"zh": "韩式炸酱面"}
- description: Chinese-style Korean noodle dish
- countries: (none)
- cuisines: Korean Chinese cuisine
- kinds: food, pasta dish
- ingredients: chunjang, noodle
- has Wikipedia article: en, zh

## DISH Q11412305
- name: Kagamigahara kimuchi
- countries: JP
- kinds: pickle, Kimchi

## DISH Q11412389
- name: Awase yōkan
- countries: (none)
- kinds: Yōkan

## DISH Q11412640
- name: Kibi dango
- other names: {"zh": "吉備團子"}
- description: Japanese sweet
- countries: (none)
- kinds: Miyagegashi, dango
- ingredients: gyūhi
- has Wikipedia article: en

## DISH Q11412715
- name: 吉原殿中
- other names: {"ja": "吉原殿中"}
- countries: (none)
- kinds: wagashi

## DISH Q1141370
- name: Monkey brains
- other names: {"zh": "猴脑"}
- description: supposed culinary dish
- countries: (none)
- kinds: dish, brain as food
- has Wikipedia article: en, zh

## DISH Q11413827
- name: Génoise cake
- other names: {"zh": "热那亚蛋糕"}
- description: French sponge cake named after the city of Genoa
- countries: FR
- kinds: sponge cake
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q11414538
- name: Yoshino torimeshi
- countries: JP
- kinds: takikomi gohan, chicken dish

## DISH Q1141574
- name: Crostini
- other names: {"zh": "油煎面包块"}
- description: Italian appetizer
- countries: IT
- kinds: bread dish, dish
- ingredients: bread, topping
- has Wikipedia article: en

## DISH Q1141633
- name: Crottin de Berry à l’Huile d’Olive
- countries: FR
- kinds: dish

## DISH Q11416718
- name: Kure reimen
- countries: JP
- kinds: hiyashi chūka

## DISH Q11416782
- name: Gojiru
- countries: JP
- kinds: shirumono
- ingredients: soy bean

## DISH Q11417011
- name: Miso oden
- countries: (none)
- kinds: oden

## DISH Q11417013
- name: Miso curry milk ramen
- description: dish from Aomori, Japan
- countries: JP
- kinds: miso ramen

## DISH Q11417014
- name: Miso-katsu
- other names: {"zh": "味噌豬排"}
- countries: JP
- kinds: food, dish, tonkatsu
- ingredients: miso, pork

## DISH Q11417017
- name: Miso matsukaze
- countries: (none)
- kinds: Kyōgashi, saogashi

## DISH Q11417019
- name: Miso nikomi udon
- description: Japanese noodle dish in which udon noodles are stewed in a miso soup
- countries: (none)
- kinds: nabemono, Japanese noodles, nikomi udon
- ingredients: miso

## DISH Q11417020
- name: Dengaku
- countries: JP
- kinds: food, kushiyaki
- ingredients: konnyaku, miso, Colocasia esculenta, tofu

## DISH Q11417021
- name: Miso manjū
- countries: (none)
- kinds: manjū
- ingredients: miso

## DISH Q11417298
- name: Wakayama ramen
- description: Japanese noodle soup
- countries: JP
- kinds: ramen

## DISH Q11417716
- name: Wakaura senbei
- other names: {"zh": "和歌浦煎餅"}
- countries: (none)
- kinds: senbei, Miyagegashi

## DISH Q11418243
- name: 和風きのこスパゲッティ
- other names: {"ja": "和風きのこスパゲッティ"}
- countries: (none)
- kinds: pasta dish
- ingredients: edible mushroom, spaghetti

## DISH Q11418356
- name: Shinagawa-meshi
- countries: (none)
- kinds: Japanese rice dish, shrimp dish

## DISH Q11418497
- name: 唐々鍋
- other names: {"ja": "唐々鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q11418701
- name: Tōmanjū
- countries: (none)
- kinds: manjū

## DISH Q11419150
- name: Kitakata Ramen Burger
- countries: JP
- kinds: dish, hamburger, Japanese noodles

## DISH Q11420167
- name: 四里餅
- other names: {"ja": "四里餅"}
- countries: (none)
- kinds: daifuku

## DISH Q1142029
- name: Crumpet
- other names: {"zh": "烤麵餅"}
- description: Small unsweetened griddle bread
- countries: GB
- cuisines: British cuisine
- kinds: flatbread
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q11420440
- name: 国会丼
- other names: {"ja": "国会丼"}
- countries: (none)
- kinds: donburi

## DISH Q1142123
- name: Gamja-tang
- other names: {"zh": "脊骨土豆汤"}
- description: Korean stew
- countries: (none)
- kinds: guk, pork dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q114213193
- name: Amandelbroodje
- other names: {"nl": "Amandelbroodje"}
- countries: (none)
- kinds: pastry, type of food or dish
- ingredients: puff pastry

## DISH Q11423039
- name: Tosani
- countries: (none)
- kinds: nimono
- ingredients: katsuobushi

## DISH Q11423044
- name: 土佐維新バーガー
- other names: {"ja": "土佐維新バーガー"}
- countries: (none)

## DISH Q1142483
- name: Tart
- other names: {"zh": "挞"}
- description: baked dessert dish, a filled pastry base with an open top not covered with pastry
- countries: (none)
- kinds: pastry, pie
- ingredients: shortcrust pastry, pastry
- has Wikipedia article: en, zh

## DISH Q1142503
- name: Shiokara
- other names: {"zh": "鹽辛"}
- description: Japanese snack made of salty seafood
- countries: JP
- kinds: fermented food, seafood dish, type of food or dish
- has Wikipedia article: en, zh

## DISH Q1142506
- name: Crépinette
- other names: {"zh": "油網包"}
- description: French sausage
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q11425631
- name: Botchan dango
- other names: {"zh": "少爺團子"}
- countries: (none)
- kinds: dango

## DISH Q1142836
- name: Khash
- description: type of food
- countries: IQ
- cuisines: Armenian cuisine, Georgian cuisine, Iranian cuisine, Azerbaijani cuisine, Ossetian cuisine
- kinds: stew, yahni
- ingredients: rumen, beef
- has Wikipedia article: en

## DISH Q11428578
- name: Shio-anbin
- other names: {"zh": "鹹大福"}
- countries: (none)
- kinds: daifuku

## DISH Q11428579
- name: Shio-ika
- countries: (none)
- kinds: salted squid

## DISH Q11428593
- name: Shio horumon
- countries: (none)
- kinds: salt-cured meat, horumonyaki, pork dish

## DISH Q11428594
- name: Shio ramen
- description: Japanese noodle soup
- countries: JP
- kinds: ramen

## DISH Q114290659
- name: Chicken yassa
- countries: SN
- cuisines: African cuisine
- kinds: chicken as food, Yassa (edziban)
- ingredients: yellow onion, chicken leg, vegetable oil, lemon juice, habanero, table salt

## DISH Q1142939
- name: Cuberdon
- description: cone-shaped Belgian candy
- countries: BE
- kinds: food, gummy candy
- has Wikipedia article: en

## DISH Q1142998
- name: Mimosa sugar ball
- description: type of religious offering
- countries: NP
- kinds: food, confectionery
- ingredients: sugar
- has Wikipedia article: en

## DISH Q11430289
- name: Yūgao ramen
- countries: (none)
- kinds: ramen

## DISH Q114328512
- name: Comtesse de Vichy
- other names: {"fr": "Comtesse de Vichy"}
- countries: FR
- kinds: raw-milk cheese, cow's-milk cheese, natural-rind soft cheese

## DISH Q11433503
- name: Yamatoni
- other names: {"zh": "大和煮"}
- countries: (none)
- kinds: meat dish, nimono, food preparation technique
- has Wikipedia article: zh

## DISH Q114347778
- name: Julienke
- description: Belgian snack bar dish
- countries: BE
- kinds: dish, fast food, potato dish
- ingredients: viandel, fried onion, gravy, mayonnaise, fries

## DISH Q114348085
- name: Hay cheese
- countries: (none)
- kinds: cow's-milk cheese

## DISH Q114352250
- name: Chhilka Roti
- description: Indian traditional bread
- countries: IN
- kinds: flatbread, roti, rice dish
- ingredients: chickpea, rice
- has Wikipedia article: en

## DISH Q114353925
- name: 麦焼酎
- other names: {"ja": "麦焼酎"}
- countries: JP
- kinds: liquor, shōchū

## DISH Q11435991
- name: Ōmura-zushi
- countries: (none)
- kinds: oshizushi

## DISH Q11438619
- name: Ōfunato sanma ramen
- countries: (none)
- kinds: ramen

## DISH Q1144102
- name: Yakisoba
- other names: {"zh": "日式炒麵"}
- description: Japanese stir-fry noodles
- countries: JP
- kinds: fried noodle, Japanese noodles
- ingredients: noodle
- has Wikipedia article: en, zh

## DISH Q1144106
- name: Yeot
- other names: {"zh": "韓菓子糖"}
- description: Korean sticky sweets
- countries: (none)
- kinds: hangwa
- ingredients: bap
- has Wikipedia article: en

## DISH Q11441527
- name: Osakayaki
- other names: {"zh": "大阪燒"}
- countries: (none)
- kinds: pancake, street food

## DISH Q114421385
- name: Gongura Chicken Curry Recipe - Andhra Style Gongura Chicken
- description: Andhra Style Gongura Chicken recipe by Archanakitchen
- countries: (none)
- cuisines: Āndhra
- kinds: Chicken karahi

## DISH Q114421387
- name: Pudina Khara Pongal
- description: Rice and Lentils Cooked With Mint Leaves & Mild Spices
- countries: IN
- cuisines: South Indian cuisine, Indian vegetarian cuisine
- kinds: dish, rice dish

## DISH Q11442200
- name: Tenchūka
- countries: (none)
- kinds: shoyu ramen

## DISH Q114422469
- name: Sarı burma
- description: rolled baklava
- countries: (none)
- kinds: baklava
- ingredients: phyllo

## DISH Q114423669
- name: Ayam pongteh
- countries: (none)
- cuisines: Peranakan cuisine
- kinds: chicken dish

## DISH Q11442514
- name: Tenpinumē manjū
- countries: (none)
- kinds: manjū

## DISH Q11442943
- name: 天狗納豆
- other names: {"ja": "天狗納豆"}
- countries: (none)
- kinds: nattō

## DISH Q11442950
- name: Tentamadon
- countries: (none)
- kinds: tendon, egg dish

## DISH Q11443039
- name: Tenri ramen
- other names: {"zh": "天理拉面"}
- countries: JP
- kinds: ramen
- has Wikipedia article: zh

## DISH Q11443332
- name: Temmado
- countries: (none)
- kinds: yaki udon

## DISH Q11443995
- name: Taipien
- description: Chinese-Japanese noodle soup from Kumamoto, Japan
- countries: (none)
- kinds: soup, dish, pasta dish

## DISH Q11445430
- name: Nara chameshi
- countries: JP
- kinds: chameshi

## DISH Q114457441
- name: Carbonade
- description: dish of French cuisine
- countries: FR
- kinds: dish
- ingredients: beef

## DISH Q11447460
- name: Himeji ramen
- description: a variety of soy sauce ramen from Himeji, Hyogo prefecture, Japan
- countries: (none)
- kinds: shoyu ramen

## DISH Q11447901
- name: 子宝ちんこすこう
- other names: {"ja": "子宝ちんこすこう"}
- countries: (none)
- kinds: chinsuko

## DISH Q1144889
- name: Tsampa
- other names: {"zh": "糌粑"}
- description: roasted flour for porridge
- countries: (none)
- kinds: porridge
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q114496226
- name: Schusterlaberl
- other names: {"de": "Schusterlaberl"}
- countries: AT
- kinds: small pastry, Mischbrot

## DISH Q11449789
- name: 宇都宮焼きそば
- other names: {"ja": "宇都宮焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q11450321
- name: Abekawamochi
- description: Japanese confection
- countries: JP
- kinds: dish, mochi
- ingredients: kinako

## DISH Q1145039
- name: Sujebi
- other names: {"zh": "面片汤"}
- description: hand-pulled dough soup
- countries: (none)
- kinds: soup, dish
- has Wikipedia article: en

## DISH Q11450919
- name: Yasunagamochi
- countries: (none)
- kinds: mochi

## DISH Q11451687
- name: An'yōji ramen
- countries: (none)
- kinds: miso ramen

## DISH Q11453069
- name: Muroran yakitori
- countries: JP
- kinds: yakitori, yakiton

## DISH Q11454169
- name: Miyazaki ramen
- countries: (none)
- kinds: tonkotsu ramen

## DISH Q114559542
- name: Zhēngjiao
- other names: {"zh": "蒸饺"}
- description: Chinese steamed dumpling
- countries: (none)
- kinds: jiaozi
- has Wikipedia article: zh

## DISH Q11456299
- name: 富山おでん
- other names: {"ja": "富山おでん"}
- countries: (none)
- kinds: nabemono

## DISH Q11456312
- name: Toyama black ramen
- countries: JP
- kinds: shoyu ramen

## DISH Q114564249
- name: Herbal gummy supplement
- description: natural supplement delivered in gummies
- countries: (none)
- kinds: gummy candy, botanical dietary supplement

## DISH Q114564252
- name: Ashwagandha gummies
- description: type of herbal gummy supplement
- countries: (none)
- kinds: herbal gummy supplement

## DISH Q114564263
- name: Hemp-based gummies
- description: type of gummy candy and/or herbal supplement
- countries: (none)
- kinds: herbal gummy supplement

## DISH Q114564265
- name: CBD gummies
- description: type of gummy candy
- countries: (none)
- kinds: hemp-based gummies

## DISH Q114564301
- name: Sambucus nigra gummies
- description: type of herbal gummy
- countries: (none)
- kinds: herbal gummy supplement

## DISH Q11457145
- name: 富田の焼き蛤
- other names: {"ja": "富田の焼き蛤"}
- countries: JP
- kinds: clam dish

## DISH Q11457280
- name: Furano Omu-Curry
- countries: JP
- kinds: Japanese curry rice

## DISH Q11458199
- name: Tsushima tonchan
- countries: (none)
- kinds: pork dish

## DISH Q1145832
- name: Fried Coke
- description: Coca-Cola flavored batter that is fried and topped with various toppings
- countries: US
- kinds: dessert
- ingredients: batter
- has Wikipedia article: en

## DISH Q11458898
- name: Ogura toast
- description: Japanese breakfast dish
- countries: JP
- kinds: food, toast
- ingredients: red bean paste, toast
- has Wikipedia article: en

## DISH Q1146046
- name: Dongpo pork
- other names: {"zh": "东坡肉"}
- description: Hangzhou dish made by pan-frying and then red cooking pork belly
- countries: CN
- cuisines: Chinese cuisine
- kinds: pork dish
- has Wikipedia article: en, zh

## DISH Q11462940
- name: 小田原おでん
- other names: {"ja": "小田原おでん"}
- countries: (none)
- kinds: nabemono

## DISH Q11462941
- name: Odawaradon
- countries: JP
- kinds: dish, donburi

## DISH Q11464369
- name: 小鍋立て
- other names: {"ja": "小鍋立て"}
- countries: (none)
- kinds: nabemono

## DISH Q11465459
- name: Onomichi ramen
- other names: {"zh": "尾道拉麵"}
- countries: (none)
- kinds: ramen

## DISH Q1146697
- name: Cuy chactado
- countries: (none)
- kinds: dish

## DISH Q1146771
- name: Gefilte fish
- description: dish made from a poached mixture of ground deboned fish
- countries: IL
- cuisines: Jewish cuisine
- kinds: dish
- ingredients: whitefish, spice, bread, carrot
- has Wikipedia article: en

## DISH Q114679328
- name: Bocadillo de lomo
- other names: {"es": "Bocadillo de lomo"}
- description: type of sandwich
- countries: (none)
- kinds: bocadillo
- ingredients: pork, sandwich

## DISH Q1146928
- name: Puri
- other names: {"zh": "印度脆餅"}
- description: food
- countries: IN
- kinds: food, bread
- ingredients: atta
- has Wikipedia article: en, zh

## DISH Q114701058
- name: Kwas wigilijny
- other names: {"pl": "kwas wigilijny"}
- countries: PL
- cuisines: galician cuisine, Polish cuisine
- kinds: soup, Christmas tradition
- ingredients: sauerkraut, spice, table salt, potato, water, dried mushrooms, onion, millet porridge

## DISH Q11470942
- name: Sannzoku-yaki
- countries: JP
- kinds: chicken dish

## DISH Q114714086
- name: Butter board
- description: type of dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q11472234
- name: Ramen in Okayama Prefecture
- countries: (none)
- kinds: ramen

## DISH Q11473964
- name: Iwa-okoshi
- countries: (none)
- kinds: okoshi
- ingredients: rice

## DISH Q11474262
- name: Iwakunizushi
- description: variety of pressed sushi
- countries: JP
- kinds: oshizushi

## DISH Q11475216
- name: 岩槻ねぎの塩焼きそば
- other names: {"ja": "岩槻ねぎの塩焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q11475284
- name: Iwanuma tonchan
- countries: (none)
- kinds: horumonyaki

## DISH Q114756150
- name: Silesian roulade
- description: food from Silesian cuisine
- countries: (none)
- cuisines: Silesian cuisine
- kinds: roulade

## DISH Q114757173
- name: Śląsko Modro Kapusta (Red Cabbage with Onion and Bacon)
- countries: (none)
- cuisines: Silesian cuisine
- kinds: dish
- ingredients: red cabbage

## DISH Q11476280
- name: Shimazushi
- description: style of sushi
- countries: JP
- kinds: nigirizushi
- ingredients: karashi

## DISH Q1147853
- name: Tamale
- other names: {"zh": "塔馬利"}
- description: corn-based food from Mesoamerica, traditionally wrapped in corn husks or banana leaves
- countries: (none)
- cuisines: Latin American cuisine
- kinds: dish
- ingredients: corn husk, cornmeal, banana leaf, chicken as food, beef, pork
- has Wikipedia article: en, zh

## DISH Q11479217
- name: 川越太麵炒麵
- countries: (none)
- kinds: Yakisoba

## DISH Q11479380
- name: Suhama
- other names: {"zh": "州濱"}
- countries: (none)
- kinds: Kyōgashi, saogashi, soy food

## DISH Q114796671
- name: Walnut tart
- description: dessert
- countries: (none)
- kinds: sweet tart
- ingredients: walnut

## DISH Q11481352
- name: Jōya-nabe
- countries: JP
- kinds: nabemono, pork dish

## DISH Q11481892
- name: Freeze-dried mochi
- countries: (none)
- kinds: mochi, dried food
