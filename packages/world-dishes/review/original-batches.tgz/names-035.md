# Review batch names-035

## DISH Q251981
- name: Crispbread
- description: flat and dry type of bread or cracker
- countries: SE
- kinds: flatbread, cracker
- ingredients: oat flour, rye flour, wheat flour, seed, flour
- has Wikipedia article: en

## DISH Q25202841
- name: Sugar Mama
- description: Discontinued candy in the Sugar Babies line
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q25203618
- name: Fura
- description: food in west Africa
- countries: NG
- kinds: food
- ingredients: soy bean, millet flour, clove, ginger, raw milk, table salt, sugar
- has Wikipedia article: en

## DISH Q25206205
- name: ഒമർ
- other names: {"ml": "ഒമർ"}
- description: caramel candy
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q25212648
- name: Kapana
- description: grilled beef
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q25220508
- name: Whistle Pops
- description: brand of sweets
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q25220535
- name: Goat meat pepper soup
- description: spicy Nigerian soup
- countries: NG
- kinds: food, dish, soup, goat meat dish
- ingredients: onion, crayfish, goat meat, Capsicum, table salt, water
- has Wikipedia article: en

## DISH Q25220557
- name: Tomato sandwich
- other names: {"zh": "番茄三明治"}
- description: type of sandwich
- countries: US
- kinds: sandwich, tomato dish
- ingredients: sandwich bread, tomato, mayonnaise
- has Wikipedia article: en

## DISH Q25220562
- name: Cheese and tomato sandwich
- other names: {"zh": "奶酪和番茄三明治"}
- description: type of sandwich
- countries: (none)
- kinds: sandwich, cheese sandwich, tomato sandwich
- has Wikipedia article: en

## DISH Q25220878
- name: Melon soup
- description: soup prepared using melons as a primary ingredient
- countries: (none)
- kinds: fruit soup
- ingredients: melon
- has Wikipedia article: en

## DISH Q25221268
- name: Chlebíček
- description: open-faced sandwich originating from the Czech Republic
- countries: (none)
- kinds: open sandwich
- has Wikipedia article: en

## DISH Q25221462
- name: Italian chickpea soup
- description: Italian soup based on chickpeas
- countries: (none)
- kinds: chickpea dish
- has Wikipedia article: en

## DISH Q25221573
- name: Tom khlong
- description: Thai soup
- countries: TH
- kinds: soup, fish dish
- ingredients: Tamarindus indica
- has Wikipedia article: en

## DISH Q25221673
- name: Spuccadella
- description: Italian-American bread roll
- countries: (none)
- kinds: bread roll
- has Wikipedia article: en

## DISH Q25221878
- name: Poke
- description: Eastern Polynesia dessert
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q25223099
- name: Chāhan
- other names: {"zh": "日式炒饭"}
- description: Japanese fried rice
- countries: JP
- cuisines: Japanese Chinese cuisine
- kinds: fried rice
- ingredients: oil, egg, vegetable
- has Wikipedia article: en, zh

## DISH Q25223685
- name: Puls
- description: staple dish of Ancient Rome
- countries: (none)
- kinds: dish
- ingredients: farro, table salt, water
- has Wikipedia article: en

## DISH Q2524291
- name: Prekmurska gibanica
- description: Slovenian layered pastry
- countries: SI
- kinds: food, layer cake, Slovenian cuisine
- ingredients: flour
- has Wikipedia article: en

## DISH Q2527136
- name: Bssisa
- description: dish from Tunisia
- countries: (none)
- kinds: mixture, tradition, ritual, dish, human food
- has Wikipedia article: en

## DISH Q25302535
- name: Ledikeni
- description: Indian sweet from Bengal
- countries: (none)
- kinds: confectionery
- ingredients: chhena, sugar, milk
- has Wikipedia article: en

## DISH Q25302577
- name: Pinni
- description: Punjabi dessert eaten mostly in winter
- countries: IN
- kinds: dessert
- ingredients: jaggery, ghee, almond, flour
- has Wikipedia article: en

## DISH Q25302803
- name: Medu vada
- description: South Indian breakfast snack made from black gram
- countries: IN
- kinds: food, breakfast, Vada
- ingredients: Vigna mungo
- has Wikipedia article: en

## DISH Q2530462
- name: Christoffel pastry
- description: pastry of meringue and chocolate mousse
- countries: (none)
- kinds: food, pastry

## DISH Q253209
- name: Esterházy torte
- description: type of layer cake
- countries: HU
- cuisines: Hungarian cuisine
- kinds: torte
- has Wikipedia article: en

## DISH Q25327061
- name: Xuanwei ham
- other names: {"zh": "宣威火腿"}
- description: Chinese dry-cured ham
- countries: CN
- kinds: ham
- has Wikipedia article: en, zh

## DISH Q25327105
- name: Tamale pie
- description: pie and casserole dish
- countries: US
- kinds: casserole
- has Wikipedia article: en

## DISH Q2533856
- name: Voressen
- countries: CH
- cuisines: Swiss cuisine
- kinds: ragout, dish

## DISH Q25339635
- name: Texas Tommy
- other names: {"zh": "德克薩斯湯米"}
- description: grilled, split hot dog with bacon and cheese
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q2535744
- name: Moutbrood
- other names: {"nl": "moutbrood"}
- countries: (none)
- kinds: bread

## DISH Q25377559
- name: Granola bar
- description: confection
- countries: (none)
- kinds: confectionery, snack bar
- ingredients: granola
- has Wikipedia article: en

## DISH Q25380201
- name: Großer Brauner Fond
- other names: {"de": "Großer Brauner Fond"}
- countries: (none)
- kinds: dish

## DISH Q25381365
- name: Lücha fobing
- other names: {"zh": "綠茶彿餅"}
- description: Hunan dish
- countries: CN
- kinds: pastry
- ingredients: sesame seed, green tea

## DISH Q25381779
- name: Pagnon borain
- other names: {"fr": "Pagnon borain"}
- countries: BE
- kinds: sweet pie

## DISH Q25383130
- name: Soupou Kandja
- description: Senegalese okra soup
- countries: (none)
- kinds: soup, okra soup
- has Wikipedia article: en

## DISH Q25383277
- name: Wassa-wassa
- description: mainly Beninese dish based on yam cossettes
- countries: BJ
- kinds: culinary speciality

## DISH Q25386716
- name: Pig foot souse
- other names: {"de": "Pig foot souse"}
- countries: (none)
- kinds: dish

## DISH Q25387730
- name: Bami Mu Daeng
- other names: {"de": "Bami Mu Daeng"}
- countries: (none)
- kinds: dish

## DISH Q25388438
- name: Hannibal sauce
- description: sauce of tomatoes, onions, and Cayenne peppers
- countries: BE
- kinds: condiment, sauce
- ingredients: tomato, onion, cayenne pepper

## DISH Q25388495
- name: Tajine el bey
- description: Tunisian dish
- countries: TN
- kinds: dish
- ingredients: minced meat, rigouta, onion, egg as food, Spinacia oleracea, spice

## DISH Q25388744
- name: Khobz mbesses
- description: bread
- countries: TN
- kinds: bread

## DISH Q25388871
- name: Warmbrunner Gebäck
- other names: {"de": "Warmbrunner Gebäck"}
- countries: (none)
- kinds: viennoiserie

## DISH Q25388897
- name: Doigts de Fatma
- description: entrée
- countries: (none)
- kinds: entrée

## DISH Q25389845
- name: Grenki
- countries: (none)
- kinds: baked good
- ingredients: cooking oil, bread

## DISH Q253899
- name: Reisfleisch
- description: Austrian dish
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q25395624
- name: Marjolaine
- description: pastry
- countries: FR
- kinds: meal, pastry
- ingredients: ganache, praline, dacquoise, dough, cream, sugar, chocolate

## DISH Q25404221
- name: Aaruul
- countries: MN
- kinds: dairy product, Mongolian dairy products
- ingredients: cow's milk, yak milk

## DISH Q25405067
- name: Cabeza de cerdo
- other names: {"es": "Cabeza de cerdo"}
- countries: (none)
- kinds: pork dish

## DISH Q25409651
- name: Peixinho
- other names: {"fr": "Peixinho"}
- countries: (none)
- kinds: beefsteak, cut of beef

## DISH Q25410968
- name: Chiaro di luna
- other names: {"it": "Chiaro di luna"}
- countries: IT
- kinds: dessert
- ingredients: almond, jam

## DISH Q25412980
- name: Kaszak
- other names: {"pl": "Kaszak"}
- countries: (none)
- kinds: pastry

## DISH Q25413607
- name: Chocho
- other names: {"es": "Chocho"}
- countries: ES
- kinds: dessert

## DISH Q25418402
- name: Ốc vú nàng
- description: Vietnamese shellfish-based culinary specialty
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: culinary speciality, seafood
- has Wikipedia article: en

## DISH Q254234
- name: Marillenknödel
- description: food
- countries: AT
- kinds: pastry, Erdäpfelknödel
- has Wikipedia article: en

## DISH Q25428551
- name: Bonecas de massa
- description: edibe puppets typical of Madeira
- countries: (none)
- kinds: folklore, pastry, puppet

## DISH Q25429699
- name: Espetada em pau de louro
- other names: {"pt": "Espetada em pau de louro"}
- countries: PT
- kinds: dish
- ingredients: meat

## DISH Q25429735
- name: Bom-bocado
- other names: {"pt": "bom-bocado"}
- countries: (none)
- kinds: confectionery

## DISH Q25431007
- name: Pão no bafo
- description: typical dish from Palmeira, Paraná
- countries: (none)
- kinds: dish

## DISH Q2545009
- name: Liquorice allsorts
- description: sweet
- countries: (none)
- kinds: gummy candy
- ingredients: liquorice, licorice candy
- has Wikipedia article: en

## DISH Q25450904
- name: Blunkett salad
- description: Tunisian dish
- countries: TN
- kinds: dish
- has Wikipedia article: en

## DISH Q25452130
- name: Pulled oats
- countries: (none)
- kinds: vegetarian cuisine, dish, meat alternative
- ingredients: oats

## DISH Q25452135
- name: Masmouta salad
- description: Tunisian dish
- countries: TN
- kinds: dish
- has Wikipedia article: en

## DISH Q25453328
- name: Hulikakku
- other names: {"fi": "Hulikakku"}
- countries: (none)
- kinds: bread

## DISH Q25454785
- name: Trida
- description: traditional Algerian dish
- countries: (none)
- kinds: dish
- ingredients: pasta
- has Wikipedia article: en

## DISH Q25458340
- name: Manuk labakh
- description: Southeastern Acehnese Cuisine from Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, Kuih, chicken dish
- ingredients: shallot, black pepper, garlic, coconut, chicken as food, white pepper, Alpinia galanga, Cymbopogon citratus, Carum carvi, table salt

## DISH Q25464887
- name: Nasi guri
- description: kind of rice dishes from Aceh, Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, rice dish
- ingredients: Indonesian bay leaf, cooked grain, coconut milk, broth, glutinous rice, Cymbopogon citratus

## DISH Q25465250
- name: Soto Petanahan
- other names: {"id": "Soto Petanahan"}
- countries: (none)
- kinds: soto

## DISH Q25466619
- name: Kropokhan rice
- description: typical food in Demak, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: shallot, bison meat, garlic, coconut milk, table salt, sugar

## DISH Q25466760
- name: Gatot
- description: Javanese traditional cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, kue, type of food or dish, snack, meal
- ingredients: cassava root, Cocos nucifera, sugar

## DISH Q25466841
- name: Tempe Gembus
- countries: ID
- kinds: dish
- ingredients: tofu, yeast

## DISH Q25466936
- name: Javanese doughnut
- description: Javanese traditional doughnut
- countries: (none)
- cuisines: Javanese cuisine
- kinds: doughnut
- ingredients: cassava
- has Wikipedia article: en

## DISH Q25466948
- name: Bolang-baling
- description: Fried bread with a crispy outer crust
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, bread, cookie
- ingredients: wheat flour, table salt, sugar

## DISH Q25468249
- name: Bontosan
- other names: {"id": "Bontosan"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, snack, human food, type of food or dish

## DISH Q25468949
- name: Gabus pucung
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, soup
- ingredients: Indonesian bay leaf, Aleurites moluccanus, shrimp paste, Kaempferia galanga, Pangium edule, Channa striata, Scarlet-backed Flowerpecker, bird's eye chili, Alpinia galanga, Allium ascalonicum, Citrus × aurantiifolia, Curcuma longa, Cymbopogon citratus, Allium sativum, table salt, water

## DISH Q25469451
- name: Sambal Jambu Mete
- other names: {"id": "Sambal Jambu Mete"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: cashew nut, bird's eye chili, chili pepper, table salt, sugar

## DISH Q25469522
- name: Raden chili sauce
- description: Jepara-style chili sauce
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: shrimp paste, bird's eye chili, cooking oil, chili pepper, tomato, table salt

## DISH Q25475661
- name: Perlenka
- description: thin bread
- countries: BG
- kinds: pita

## DISH Q25476285
- name: Мървеница
- other names: {"bg": "Мървеница"}
- countries: (none)
- kinds: dish

## DISH Q25476873
- name: Kuih madu kasirat, Indonesia
- other names: {"ms": "Kuih madu kasirat, Indonesia"}
- countries: BN, ID
- kinds: kue, dish
- ingredients: coconut, palm sugar, rice flour, table salt

## DISH Q2548021
- name: Appam
- other names: {"zh": "阿榜糕"}
- description: South Indian and Sri Lankan pancake made with fermented rice batter and coconut milk
- countries: IN, LK
- kinds: pancake, dish
- ingredients: tapai singkong, wheat flour, fermentation starter, rice flour, coconut milk, batter, sugar
- has Wikipedia article: en, zh

## DISH Q25485264
- name: Қазақ халқының ұлттық тағам түрлері
- other names: {"kk": "Қазақ халқының ұлттық тағам түрлері"}
- countries: (none)
- kinds: dish

## DISH Q25485307
- name: Sarawak laksa
- description: Sarawak traditional dish
- countries: MY
- cuisines: Peranakan cuisine
- kinds: laksa, noodle dish
- ingredients: chicken as food, coconut milk, rice vermicelli, egg as food

## DISH Q25485663
- name: Languette
- description: thin elongated piece of beef
- countries: FR
- kinds: dish
- ingredients: beef

## DISH Q2548949
- name: Vine leaf roll
- description: dishes made by stuffing rice, cheese or ground meat in vine (grape) leaves (rolls)
- countries: TR
- cuisines: Turkish cuisine, Palestinian cuisine
- kinds: food, dish
- ingredients: garlic
- has Wikipedia article: en

## DISH Q254922
- name: Liptauer
- other names: {"zh": "利普萄軟質乾酪"}
- description: central European cheese-based spread
- countries: SK
- cuisines: Austrian cuisine, Hungarian cuisine, Slovak cuisine
- kinds: dish, spread
- ingredients: Bryndza, quark
- has Wikipedia article: en, zh

## DISH Q25496702
- name: Šimtalapis
- description: type of pastry in the cuisine of Polish-Lithuanian Tatars
- countries: LT
- kinds: pastry

## DISH Q254979
- name: Cinnamon roll
- other names: {"zh": "肉桂面包卷"}
- description: sweet food pastry
- countries: SE
- kinds: food, sweet roll, bun
- ingredients: wheat flour, yeast, cinnamon, sugar
- has Wikipedia article: en, zh

## DISH Q2550270
- name: Tarte al d'jote
- description: Belgian culinary specialty
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q255048
- name: Tunnbröd
- description: bread
- countries: SE
- kinds: flatbread, type of food or dish
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q25512128
- name: Melindre
- other names: {"es": "melindre"}
- countries: (none)
- cuisines: Galician cuisine
- kinds: sweetmeat
- ingredients: egg as food, flour, butter, sugar

## DISH Q2551579
- name: Wassersuppe (Gericht)
- other names: {"de": "Wassersuppe (Gericht)"}
- countries: (none)
- kinds: dish

## DISH Q25520186
- name: Soʻk oshi
- other names: {"uz": "Soʻk oshi"}
- countries: (none)
- kinds: dish

## DISH Q25525331
- name: Shavla
- countries: (none)
- kinds: dish

## DISH Q25528989
- name: Халвайтар
- other names: {"ru": "Халвайтар"}
- countries: (none)
- kinds: dish

## DISH Q25536192
- name: Phogatsa
- countries: GR
- kinds: pastry

## DISH Q25536638
- name: Timsah görünüşlü ət piroqu
- other names: {"az": "Timsah görünüşlü ət piroqu"}
- countries: (none)
- kinds: börek

## DISH Q25537158
- name: Kluai khaek
- other names: {"ms": "Kluai khaek"}
- countries: TH
- kinds: banana dish
- ingredients: banana

## DISH Q25537356
- name: ไข่น้ำ
- other names: {"th": "ไข่น้ำ"}
- countries: TH
- kinds: dish

## DISH Q2553796
- name: Weck, Worscht un Woi
- other names: {"de": "Weck, Worscht un Woi"}
- countries: (none)
- kinds: dish, traditional food
- ingredients: bologna, bread roll, wine

## DISH Q2553843
- name: Weckewerk
- description: Sausage specialty from North Hesse
- countries: (none)
- cuisines: Hessian cuisine
- kinds: sausage, dish
- has Wikipedia article: en

## DISH Q25538525
- name: Doli Roti
- countries: (none)
- kinds: food, roti

## DISH Q25542894
- name: Leum Kleun
- other names: {"zh": "忘吞糕"}
- countries: TH
- kinds: dessert, Thai cuisine

## DISH Q25543169
- name: Nam phrik long ruea
- description: Thai dish
- countries: TH
- kinds: pork dish
- has Wikipedia article: en

## DISH Q25551956
- name: Adai
- description: South Indian rice based tiffin
- countries: (none)
- kinds: breakfast, rice dish

## DISH Q2555488
- name: Christmas carp
- description: traditional fish dish
- countries: AT, CZ, DE
- kinds: fish dish, Christmas food, traditional food
- ingredients: Cyprinus carpio
- has Wikipedia article: en

## DISH Q25557652
- name: Bulls-eye
- description: a peppermint-flavoured boiled sweet, similar to a humbug
- countries: (none)
- kinds: hard candy

## DISH Q25558267
- name: Pwdin Eryri
- description: steamed pudding originally from northern Wales
- countries: (none)
- kinds: pudding

## DISH Q2555906
- name: Kozak
- other names: {"nl": "Kozak"}
- countries: (none)
- kinds: food, cookie

## DISH Q25563576
- name: Presh jahni
- other names: {"sq": "Presh jahni"}
- countries: (none)
- kinds: dish

## DISH Q25563591
- name: Bamje jahni
- other names: {"sq": "Bamje jahni"}
- countries: (none)
- kinds: dish

## DISH Q2557248
- name: Weisslacker
- description: German semi-soft cheese
- countries: DE
- kinds: cow's-milk cheese, German cheese, dairy product
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q255761
- name: Marble cake
- other names: {"zh": "大理石蛋糕"}
- description: type of cake
- countries: DE
- kinds: cake, food
- has Wikipedia article: en, zh

## DISH Q2557649
- name: Amba
- other names: {"zh": "安巴"}
- description: mango pickle condiment
- countries: IQ
- cuisines: Iraqi cuisine
- kinds: spread, dip, human food
- ingredients: mango
- has Wikipedia article: en

## DISH Q25579358
- name: Tempe Bacem
- description: Traditional food of Indoensia
- countries: ID
- kinds: food, cuisine, type of food or dish, dish
- ingredients: Tempe, Alpinia galanga, Cymbopogon citratus, coriander seed, brown sugar, white onion, bay leaf, coconut water, red onion, soy sauce, table salt

## DISH Q25580565
- name: Bakso Malang
- countries: (none)
- kinds: food, dish
- ingredients: bakso, rice vermicelli, krupuk, tofu, soup

## DISH Q25581115
- name: Bakwan Malang
- description: Indonesian meatball soup
- countries: ID
- kinds: meatball soup
- ingredients: celery, garlic, meatball, bakwan, tapioca, beef, black pepper, ice, table salt

## DISH Q25588431
- name: Puzhukku
- description: kerala dish
- countries: (none)
- kinds: dish

## DISH Q2560560
- name: Blodpalt
- other names: {"zh": "血蛋糕"}
- description: Northern Finnish dumplings made with flour and blood
- countries: FI
- cuisines: Swedish cuisine, Finnish cuisine, Latvian cuisine
- kinds: pudding
- ingredients: blood
- has Wikipedia article: en

## DISH Q2560689
- name: Anzac biscuit
- other names: {"zh": "澳新军团饼干"}
- description: sweet biscuit popular in Australia and New Zealand
- countries: AU
- cuisines: Australian cuisine, New Zealand cuisine
- kinds: cookie, biscuit
- ingredients: rolled oats
- has Wikipedia article: en, zh

## DISH Q2561177
- name: Lūʻau
- other names: {"zh": "芋頭葉包豬肉"}
- description: native Hawaiian cuisine dish
- countries: (none)
- cuisines: Polynesian cuisine
- kinds: fish dish, pork dish
- has Wikipedia article: en

## DISH Q25616467
- name: Soeskreakeling
- other names: {"fy": "soeskreakeling"}
- countries: (none)
- kinds: kringle

## DISH Q25616486
- name: Stip yn't Gat
- other names: {"fy": "Stip yn't Gat"}
- countries: (none)
- kinds: dish

## DISH Q25617893
- name: Zemola
- other names: {"lmo": "Zemola"}
- countries: (none)
- kinds: dish
- ingredients: common wheat flour, chestnut flour, butter, table salt, water

## DISH Q25617898
- name: Mondeghili
- description: Italian fried meatball
- countries: IT
- cuisines: Italian cuisine
- kinds: minced food ball
- ingredients: egg as food, butter, meat, milk, bread
- has Wikipedia article: en

## DISH Q25619729
- name: Wet Tha Dote Htoe
- other names: {"zh": "緬甸豬雜串"}
- description: Burmese street food
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q25630136
- name: Burayot
- other names: {"id": "Burayot"}
- description: Sundanese traditional dish
- countries: ID
- kinds: food, snack, traditional food
- ingredients: brown sugar, rice flour, coconut oil

## DISH Q25631239
- name: Bantan
- description: Mongolian soup
- countries: MN
- kinds: soup

## DISH Q2563305
- name: Smultring
- description: Norwegian doughnut
- countries: NO
- kinds: doughnut
- ingredients: dough
- has Wikipedia article: en

## DISH Q2563471
- name: Alheira
- description: type of Portuguese sausage
- countries: PT
- cuisines: Portuguese cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q25640114
- name: Moereflaaj
- other names: {"li": "Moereflaaj"}
- countries: (none)
- kinds: vlaai

## DISH Q25640280
- name: Cherry soup of Sint-Truiden
- countries: BE
- kinds: dish, soup
- ingredients: cherry

## DISH Q25640342
- name: Endive with cracklings
- countries: (none)
- kinds: dish
- ingredients: cracklings, Cichorium endivia

## DISH Q25640379
- name: Gans op de wies va Visé
- other names: {"li": "Gans op de wies va Visé"}
- countries: BE
- cuisines: cuisine of Belgium
- kinds: dish

## DISH Q25640396
- name: Chicken ragout
- countries: (none)
- kinds: ragout

## DISH Q25640423
- name: Stökskeseflaaj
- other names: {"li": "Stökskeseflaaj"}
- countries: (none)
- kinds: vlaai

## DISH Q25640478
- name: Ulezeiver
- countries: (none)
- kinds: bitters

## DISH Q25640559
- name: Boumsjpek
- other names: {"li": "Boumsjpek"}
- countries: (none)
- kinds: dish

## DISH Q25640632
- name: Klopsjènk
- other names: {"li": "Klopsjènk"}
- countries: (none)
- kinds: dish

## DISH Q25643944
- name: Alu Bhaja
- description: fried potato
- countries: (none)
- kinds: potato dish

## DISH Q25643982
- name: Palua ladu
- description: sweet item from Bhadrak, Odisha
- countries: (none)
- kinds: dessert

## DISH Q2564638
- name: Bananas Foster
- description: fried dessert made from bananas, dough, a buttery sauce, and ice cream
- countries: US
- kinds: banana dish, dessert
- ingredients: brown sugar, liqueur, rum, butter, cinnamon, ice cream, banana, vanilla ice cream
- has Wikipedia article: en

## DISH Q2565281
- name: Westfälische Rinderwurst
- other names: {"zh": "威斯特法伦牛肉肠"}
- description: Type of German sausage
- countries: DE
- cuisines: German cuisine
- kinds: kaszanka
- has Wikipedia article: en

## DISH Q25659210
- name: Gumposat
- other names: {"se": "Gumposat"}
- countries: (none)
- kinds: dish

## DISH Q2565922
- name: Ema datshi
- description: a cheese and chili-based dish from Bhutan
- countries: BT
- cuisines: Bhutanese cuisine
- kinds: dish
- ingredients: Datshi, chili pepper
- has Wikipedia article: en

## DISH Q256622
- name: Powidl
- other names: {"zh": "波維多爾"}
- description: zwetschgen spread
- countries: CZ, PL
- kinds: dessert, varenye, plum butter
- ingredients: plum
- has Wikipedia article: en, zh

## DISH Q25662717
- name: Adobong Goto
- countries: (none)
- kinds: dish

## DISH Q25673308
- name: Chemar
- other names: {"zh": "切玛"}
- description: an auspicious offering to make at the Losar shrine to bring prosperity in the new year
- countries: (none)
- kinds: food
- has Wikipedia article: zh

## DISH Q25674234
- name: Guthuk
- description: A traditional celebration involving preparation of Thukpa, a broth-based soup, with 9 ingredients on the 29th lunar day of the last month of the year.
- countries: CN
- cuisines: Tibetan cuisine
- kinds: type of food or dish, Thukpa, festive meal
- ingredients: dough, legume, vegetable, meat

## DISH Q25679113
- name: Rybnik
- description: Russian fish pie
- countries: RU
- cuisines: Russian cuisine
- kinds: dish, pirog
- ingredients: fish as food

## DISH Q25679249
- name: Lingonberry pie
- description: type of pie filled with lingonberry
- countries: (none)
- kinds: dessert, sweet pie
- ingredients: lingonberry, dough

## DISH Q25681686
- name: Kruukplaetjes
- other names: {"zea": "Kruukplaetjes"}
- countries: (none)
- kinds: dish

## DISH Q25681718
- name: Paptaart
- other names: {"nl": "paptaart"}
- countries: (none)
- kinds: dish

## DISH Q25685948
- name: Kaya phuthi
- other names: {"ay": "Kaya phuthi"}
- countries: (none)
- kinds: dish

## DISH Q25687438
- name: Panžakaj
- description: Erzyan national dish
- countries: (none)
- cuisines: Erzyan cuisine
- kinds: dish

## DISH Q2568765
- name: Maldive fish
- description: cured tuna traditionally produced in Maldives
- countries: MV
- cuisines: Sri Lankan cuisine, Maldivian cuisine
- kinds: cured fish, tuna dish
- has Wikipedia article: en

## DISH Q25688465
- name: Pancong
- description: Indonesian specialty cakes
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, snack, human food, type of food or dish, kue
- ingredients: coconut, rice flour, sugar

## DISH Q25688473
- name: Aweueh peuet plôh peuet
- other names: {"ace": "aweueh peuet plôh peuet"}
- countries: ID
- kinds: spice

## DISH Q2569162
- name: Weaner Wäschermadln
- other names: {"bar": "Weaner Wäschermadln"}
- description: Austrian dish
- countries: (none)
- kinds: dish

## DISH Q25695452
- name: Öpke-hésip
- other names: {"zh": "面肺子和米肠子"}
- description: lamb lung and rice sausage dish of Xinjiang, China
- countries: CN
- kinds: offal dish
- ingredients: lamb lung, hasip
- has Wikipedia article: zh

## DISH Q25697201
- name: Muboora
- description: dish, soup with pumpkin leaves in Vorspeise in Zimbabwe
- countries: ZW
- kinds: soup, appetizer

## DISH Q25700572
- name: Arroz caldo
- description: Filipino rice and chicken gruel
- countries: PH
- kinds: congee, lugaw
- has Wikipedia article: en

## DISH Q25702519
- name: Tentalaria
- countries: (none)
- kinds: candy

## DISH Q25703460
- name: Хьхьахьхьари
- other names: {"lbe": "хьхьахьхьари"}
- countries: (none)
- cuisines: Lak cuisine
- kinds: dish, soup

## DISH Q25704086
- name: Isitambu
- description: samp and beans, traditional Zulu dish
- countries: (none)
- kinds: stew

## DISH Q25704451
- name: Tavioka
- description: Fijian dessert
- countries: FJ
- kinds: dessert
- ingredients: cassava root, coconut cream, sugar, banana

## DISH Q2571599
- name: Qatayef
- description: Middle Eastern dessert in the form of small pancakes stuffed with sweet filling
- countries: LB, PS, EG, JO, SY
- cuisines: Levantine cuisine, Lebanese cuisine, Palestinian cuisine, Egyptian cuisine, Jordanian cuisine, Syrian cuisine
- kinds: dessert, dish, pancake
- ingredients: pistachio nut, cardamom, wheat flour, baker's yeast, semolina, walnut, almond, baking powder, cinnamon, table salt, sugar, milk, drinking water
- has Wikipedia article: en

## DISH Q2572122
- name: Pryanik
- other names: {"zh": "香料糕饼"}
- description: Traditional Eastern European cake
- countries: (none)
- kinds: food, cookie, cake, confectionery, gingerbread confectionary
- has Wikipedia article: en

## DISH Q2578366
- name: Cavatappi
- description: type of pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q2579351
- name: Couque de Dinant
- other names: {"zh": "迪南饼干"}
- description: very hard biscuit from the Belgian city of Dinant
- countries: (none)
- kinds: food, cookie
- has Wikipedia article: en, zh

## DISH Q2580945
- name: Warabimochi
- other names: {"zh": "蕨餅"}
- description: Japanese jelly-like confection
- countries: JP
- kinds: mochi, wagashi
- ingredients: bracken starch, kinako, sugar
- has Wikipedia article: en, zh

## DISH Q258279
- name: Pancake soup
- other names: {"zh": "薄煎餅條湯"}
- description: food
- countries: DE
- kinds: food, soup
- ingredients: broth
- has Wikipedia article: en, zh

## DISH Q25842375
- name: Street food of Thailand
- other names: {"zh": "泰国街头美食"}
- description: overview of Thai street food
- countries: (none)
- kinds: street food
- has Wikipedia article: en, zh

## DISH Q258455
- name: Totopo
- description: oaxacan nixtamalized corn flatbread
- countries: MX
- kinds: tortilla
- has Wikipedia article: en

## DISH Q2585262
- name: Swedish white bread
- description: Dutch bread
- countries: (none)
- kinds: bread

## DISH Q2587663
- name: Rollot
- description: French cheese
- countries: FR
- kinds: cheese, French cheese, cow's-milk cheese, farmstead cheese, washed-rind cheese, dairy cheese
- ingredients: cow's milk

## DISH Q259100
- name: Trippa alla fiorentina
- description: Tuscan tripe dish from the Florence area
- countries: IT
- kinds: main course
- ingredients: tripe

## DISH Q2591051
- name: Tiết canh
- other names: {"zh": "越南鴨血"}
- description: traditional dish of raw blood (commonly pork or duck) pudding served with cooked meat in northern Vietnamese cuisine
- countries: VN
- kinds: pudding, blood soup
- ingredients: Persicaria odorata, fish sauce, duck meat, blood as food, pork, peanut
- has Wikipedia article: en

## DISH Q259148
- name: Schweinsbraten
- description: roasted pork, popular dish in Germany, Austria and Czech Republic
- countries: (none)
- kinds: food, pork, roast
- ingredients: pork, knödel, Brassica oleracea var. capitata

## DISH Q2592256
- name: Hochepot
- description: Dutch meat and vegetable stew
- countries: (none)
- kinds: dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q25936230
- name: Beyin salata
- description: Turkish offal dish
- countries: TR
- kinds: salad

## DISH Q2595034
- name: Goodie bag
- description: rolled, printed paper bag or cone containing a small toy, trinket, or treat
- countries: (none)
- kinds: toy, paper bag, confectionery, gift

## DISH Q2595324
- name: Wurstbrot
- description: A Wurstbrot is a slice of bread spread with slices of lunch meat or sausage.
- countries: DE
- kinds: sandwich
- ingredients: sausage, bread
- has Wikipedia article: en

## DISH Q259550
- name: Apple butter
- description: highly concentrated form of apple sauce produced by long, slow cooking of apples with cider or water to a point where the sugar in the apples caramelizes
- countries: BE, DE
- kinds: spread, syrup
- ingredients: apple
- has Wikipedia article: en

## DISH Q2595950
- name: Wähe
- description: Swiss custard-filled tart
- countries: CH
- cuisines: Swiss cuisine
- kinds: tart
- has Wikipedia article: en

## DISH Q2597970
- name: Zalmsalade
- other names: {"nl": "zalmsalade"}
- countries: (none)
- kinds: salad

## DISH Q259874
- name: Curry puff
- other names: {"zh": "咖喱角"}
- description: snack pie
- countries: (none)
- kinds: food, pie
- ingredients: curry
- has Wikipedia article: en, zh

## DISH Q25997959
- name: Croûte au fromage
- description: Cheese dish from Switzerland and Savoie (France)
- countries: CH
- kinds: dish, cheese dish
- ingredients: Swiss cheeses

## DISH Q2599893
- name: Sufganiyah
- description: Round Hanukkah jelly doughnut
- countries: IL
- cuisines: Israeli cuisine
- kinds: sweet bread
- has Wikipedia article: en

## DISH Q25999115
- name: Oštiepok
- description: Slovakian smoked cheese
- countries: SK
- kinds: food, smoked cheese, Slovak cheese
- ingredients: sheep milk
- has Wikipedia article: en

## DISH Q26000128
- name: Chicken wing and ham
- description: chicken wings stuffed with ham
- countries: CN
- cuisines: Cantonese cuisine
- kinds: stuffed chicken wings
- ingredients: chicken wing, ham

## DISH Q2601766
- name: Yufka bread
- description: flatbread made with dough leaves
- countries: TR
- kinds: food, saj bread
- has Wikipedia article: en

## DISH Q2601887
- name: Boxty
- description: traditional Irish potato pancake
- countries: IE
- kinds: potato pancake, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q2604496
- name: Matnakash
- description: Armenian bread
- countries: AM
- cuisines: Armenian cuisine
- kinds: food, bread
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q26046157
- name: Jeyuk Bokkeum
- other names: {"zh": "韓式辣炒豬肉"}
- description: Korean meat dish
- countries: (none)
- kinds: bokkeum, pork dish
- ingredients: gochujang, pork

## DISH Q2606334
- name: Oranjekoeke
- other names: {"cs": "Oranjekoeke"}
- countries: (none)
- kinds: food, pastry

## DISH Q260929
- name: St. Lucia bun
- description: Scandinavian dessert traditionally eaten on Saint Lucy's Day (13 Dec.), containing saffron and raisins, often in the form of a reversed S shape
- countries: SE
- kinds: Christmas dessert, sweet roll, saffron bread
- ingredients: wheat flour, yeast, saffron, raisin

## DISH Q2609461
- name: Yusheng
- other names: {"zh": "捞起鱼生"}
- description: Cantonese-style raw fish salad
- countries: CN
- kinds: salad, salmon dish, raw fish dish
- has Wikipedia article: en, zh

## DISH Q2609925
- name: Sûpengrottenbrij
- other names: {"fy": "sûpengrottenbrij"}
- countries: (none)
- kinds: type of food or dish, porridge
- ingredients: pearl barley, buttermilk

## DISH Q2610074
- name: Custard bun
- other names: {"zh": "奶黃包"}
- countries: CN
- kinds: pastry
- has Wikipedia article: zh

## DISH Q2613548
- name: Chura kampo
- description: tibetan cheese
- countries: (none)
- kinds: Tibetan cheese, cheese
- has Wikipedia article: en

## DISH Q261387
- name: Apple strudel
- other names: {"zh": "維也納蘋果卷"}
- description: apple-filled pastry
- countries: AT, IT
- kinds: strudel, sweet dish
- ingredients: bread crumbs, powdered sugar, butter, cinnamon, sugar, apple
- has Wikipedia article: en, zh

## DISH Q2615138
- name: Shirred eggs
- description: eggs that have been baked in a flat-bottomed dish
- countries: FR
- kinds: food, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q261830
- name: Raspeball
- description: potato dish
- countries: NO
- kinds: prefabrication, potato dish
- ingredients: potato, chicken egg, potato starch
- has Wikipedia article: en

## DISH Q2619014
- name: Stip
- description: Dutch dish
- countries: (none)
- kinds: porridge
- ingredients: buckwheat seed
- has Wikipedia article: en

## DISH Q26211079
- name: Maize bread
- other names: {"zh": "玉米面包"}
- description: bread made from maize
- countries: MX
- kinds: bread, quick bread
- ingredients: Zea mays Saccharata Group

## DISH Q26212501
- name: Turkish style semolina dessert
- description: Turkish cuisine dessert, generally served with ice cream, sometimes in the hollow inside
- countries: TR
- kinds: dish, dessert

## DISH Q2622030
- name: Kharcho
- other names: {"zh": "卡爾喬"}
- description: soup
- countries: GE
- cuisines: Georgian cuisine
- kinds: food, soup
- ingredients: pomegranate juice, walnut, beef, tomato, Allium sativum, rice
- has Wikipedia article: en, zh

## DISH Q262280
- name: Mustamakkara
- other names: {"zh": "黑香肠"}
- description: Finnish blood sausage variant
- countries: FI
- kinds: blood sausage
- has Wikipedia article: en, zh

## DISH Q26233481
- name: Thua khiao tom namtan
- other names: {"zh": "绿豆汤"}
- description: Thai dessert
- countries: (none)
- kinds: dessert
- has Wikipedia article: en, zh

## DISH Q2624505
- name: Alu tikki
- description: snack originating from the Indian subcontinent
- countries: IN
- kinds: chaat, snack
- ingredients: potato
- has Wikipedia article: en

## DISH Q2625025
- name: Zosui
- other names: {"zh": "雜炊"}
- description: Japanese rice and vegetable soup
- countries: JP
- kinds: dish, food, soup, Japanese rice dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q26252043
- name: Drop
- other names: {"fr": "drop"}
- countries: (none)
- kinds: licorice candy

## DISH Q2626283
- name: Pain à la grecque
- other names: {"mul": "pain à la grecque"}
- description: Brusselian pastry
- countries: BE
- kinds: pastry, bread
- ingredients: brown sugar, cinnamon, sugar
- has Wikipedia article: en

## DISH Q26265213
- name: Alkaline rice dumplings
- other names: {"zh": "鹼粽"}
- countries: (none)
- kinds: zongzi
- has Wikipedia article: zh

## DISH Q26269264
- name: Pförtchen
- countries: (none)
- kinds: pastry

## DISH Q2626928
- name: Calavera
- other names: {"zh": "头骨"}
- description: Mexican skull model made out of sugar or clay
- countries: MX
- kinds: Alfeñique
- ingredients: sucrose, clay
- has Wikipedia article: en

## DISH Q26271735
- name: Granatsplitter
- description: sweet pastry
- countries: (none)
- kinds: pastry

## DISH Q262796
- name: Manti
- other names: {"zh": "土耳其饺子"}
- description: dish
- countries: (none)
- kinds: dish, dumpling, stuffed pasta
- has Wikipedia article: en, zh

## DISH Q2628185
- name: Cranachan
- other names: {"zh": "覆盆莓黄金燕麦"}
- description: Scottish dessert
- countries: (none)
- kinds: dessert
- ingredients: whipped cream
- has Wikipedia article: en

## DISH Q2629070
- name: Kindermanstik
- other names: {"nl": "kindermanstik"}
- countries: (none)
- kinds: type of food or dish, bread

## DISH Q2629673
- name: Flik
- other names: {"nl": "Flik"}
- countries: (none)
- kinds: candy

## DISH Q2631681
- name: Dressed herring
- other names: {"zh": "舒巴"}
- description: Russian layered salad
- countries: SU
- cuisines: Russian cuisine, Soviet cuisine
- kinds: dish, herring salad
- ingredients: potato, fried and pickled herring, Beta, Clupea, mayonnaise, Beta vulgaris, egg as food, onion, egg, carrot
- has Wikipedia article: en

## DISH Q2631692
- name: Pasta di mandorle PAT
- other names: {"zh": "Pasta di mandorle PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT, TR
- kinds: food, baked good, confectionery
- ingredients: almond
- has Wikipedia article: en

## DISH Q263223
- name: Mozartkugel
- other names: {"zh": "莫札特巧克力"}
- description: chocolate-covered filled confection invented in Salzburg, named after Mozart
- countries: AT
- kinds: Belgian praline, confectionery
- ingredients: pistachio nut, marzipan, chocolate
- has Wikipedia article: en, zh

## DISH Q2632589
- name: Lazanki
- description: type of pasta and dishes made with it in Polish, Lithuanian, Belarusian, Russian, Ukrainian cuisine
- countries: PL
- kinds: dish, pasta
- has Wikipedia article: en

## DISH Q263351
- name: Iekei Ramen
- other names: {"zh": "家系拉麵"}
- description: type of ramen containing pork marrow, soy sauce broth and thick, straight noodles
- countries: JP
- cuisines: Japanese cuisine
- kinds: ramen
- has Wikipedia article: en, zh

## DISH Q2634430
- name: Curd rice
- description: Indian dish
- countries: IN
- kinds: dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q2634653
- name: Coxinha
- description: popular food in Brazil
- countries: BR
- cuisines: Brazilian cuisine
- kinds: chicken dish
- ingredients: wheat flour, chicken as food, bread crumbs, dough
- has Wikipedia article: en

## DISH Q2635144
- name: Sorrel soup
- other names: {"zh": "酸模濃湯"}
- description: Eastern European dish
- countries: RU, IL, PL, UA, BY
- cuisines: Russian cuisine, Jewish cuisine, Polish cuisine, Ukrainian cuisine, Belarusian cuisine
- kinds: dish, soup
- ingredients: potato, onion, pork ribs, smetana, egg as food, Rumex acetosa, egg, water, carrot
- has Wikipedia article: en, zh

## DISH Q2636022
- name: Manakish
- description: Levantine flatbread dish
- countries: LB
- kinds: flatbread, dish
- has Wikipedia article: en

## DISH Q263675
- name: Punschkrapfen
- description: Austrian confection
- countries: AT
- kinds: sponge cake
- ingredients: sponge cake
- has Wikipedia article: en

## DISH Q263698
- name: Milk-cream strudel
- description: food
- countries: AT
- kinds: food, strudel
- has Wikipedia article: en

## DISH Q263948
- name: Žemlovka
- description: food
- countries: CZ
- kinds: food, pastry
- ingredients: apple
- has Wikipedia article: en

## DISH Q26398337
- name: Iranian pizza
- description: style of pizza served in Iran and the Iranian diaspora
- countries: IR
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q2640746
- name: Azu
- description: traditional Tatar dish
- countries: (none)
- kinds: dish
- ingredients: vegetable, meat

## DISH Q2641023
- name: Belyash
- description: Tatar and Bashkir fried dough pastry
- countries: KZ
- cuisines: Kazakh cuisine, Soviet cuisine, Tatarstan cuisine, Bashkir cuisine, Kalmyk cuisine
- kinds: pirozhki, stuffed food
- ingredients: beef, spice, flour, table salt, water
- has Wikipedia article: en

## DISH Q2641073
- name: Gandaham
- other names: {"nl": "Gandaham"}
- countries: (none)
- kinds: ham

## DISH Q2641090
- name: Red caviar
- description: caviar made from the roe of salmon, trout, or cod
- countries: (none)
- kinds: caviar
- ingredients: roe
- has Wikipedia article: en

## DISH Q2642060
- name: Broa
- other names: {"zh": "Broa"}
- description: type of bread
- countries: BR
- kinds: food, bread
- ingredients: cornmeal
- has Wikipedia article: en, zh

## DISH Q264215
- name: Salzburger Nockerl
- description: Austrian sweet soufflé
- countries: AT
- kinds: soufflé, sweet dish
- ingredients: chicken egg, flour, egg, sugar, milk
- has Wikipedia article: en

## DISH Q2643588
- name: Hong Kong cream bun
- other names: {"zh": "奶油包"}
- description: Chinese bun
- countries: (none)
- kinds: cream roll
- has Wikipedia article: en, zh

## DISH Q2643794
- name: Tushonka
- other names: {"zh": "图尚卡"}
- description: Soviet canned meat product
- countries: (none)
- kinds: dish, canning, food product
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q264558
- name: Žganci
- description: dish in Slovenian and Croatian cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q264758
- name: Mohnnudel
- description: potato dish
- countries: AT
- kinds: potato-dough dumpling
- has Wikipedia article: en

## DISH Q26492667
- name: Doganitang
- countries: KR
- kinds: dish

## DISH Q26492973
- name: Živáňská pečeně
- other names: {"cs": "Živáňská pečeně"}
- countries: (none)
- kinds: dish

## DISH Q2649721
- name: Almnuss
- other names: {"de": "Almnuss"}
- countries: (none)
- kinds: viennoiserie

## DISH Q265457
- name: Rum baba
- other names: {"zh": "蘭姆巴巴"}
- description: cake saturated in rum
- countries: FR
- kinds: dessert, yeast cake
- ingredients: egg as food, rum
- has Wikipedia article: en, zh

## DISH Q2654880
- name: Matzah brei
- description: sauteed matzo omelette
- countries: IL
- cuisines: Jewish cuisine
- kinds: dish
- ingredients: flat water, cooking oil, matzah, egg as food
- has Wikipedia article: en

## DISH Q2655119
- name: Melomakarono
- description: Greek Christmas dessert
- countries: GR
- kinds: human food
- ingredients: semolina
- has Wikipedia article: en

## DISH Q2659824
- name: Papa rellena
- description: traditional dish in Peruvian cuisine
- countries: (none)
- kinds: meal, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q2662315
- name: Meatball sandwich
- description: type of sandwich
- countries: US
- cuisines: cuisine of the United States
- kinds: meat sandwich
- ingredients: meatball, bread
- has Wikipedia article: en

## DISH Q2663339
- name: Branntwein-Suppe
- other names: {"de": "Branntwein-Suppe"}
- countries: (none)
- kinds: dish

## DISH Q2663499
- name: Schoten
- countries: (none)
- kinds: bread roll

## DISH Q2663815
- name: Mujadara
- other names: {"zh": "穆贾达达"}
- description: dish of Levantine cuisine
- countries: CY
- cuisines: Cypriot cuisine, Middle Eastern cuisine
- kinds: rice dish
- ingredients: fried onion, Oryza, Carum, Lens, Lens culinaris, olive oil, Allium, rice
- has Wikipedia article: en

## DISH Q266529
- name: Mehlspeise
- other names: {"de": "Mehlspeise"}
- countries: DE
- kinds: dish, baking
- ingredients: flour

## DISH Q266540
- name: Kaiserschmarrn
- other names: {"zh": "皇帝煎餅"}
- description: sweet Austrian dish, similar to a shredded pancake
- countries: AT
- kinds: pancake, Schmarrn
- ingredients: egg as food, flour, sugar, milk
- has Wikipedia article: en, zh

## DISH Q2665744
- name: Humita
- description: dish prepared in Chile, Perú, Argentina, Bolivia, Ecuador and Colombia
- countries: (none)
- kinds: meal, dish
- ingredients: maize, cornmeal, onion, basil, butter
- has Wikipedia article: en

## DISH Q2666603
- name: Chimichanga
- other names: {"zh": "恰米強克捲"}
- description: Mexican or Southwestern American dish consisting of a deep-fried burrito
- countries: MX
- cuisines: cuisine of the United States, Mexican cuisine
- kinds: type of food or dish, burrito
- ingredients: wheat tortilla
- has Wikipedia article: en, zh

## DISH Q26670
- name: Paper covered bone
- other names: {"zh": "紙包骨"}
- description: popular snack
- countries: CN
- kinds: dish
- has Wikipedia article: zh

## DISH Q2667251
- name: Rosette
- description: thin, cookie-like deep-fried pastry of Scandinavian origin
- countries: SE
- kinds: cookie, pastry, viennoiserie
- has Wikipedia article: en

## DISH Q2667800
- name: Chura loenpa
- description: tibetan cheese
- countries: (none)
- kinds: Tibetan cheese, cheese, pressed cooked cheese, mixed milk cheese
- ingredients: sheep milk
- has Wikipedia article: en

## DISH Q26678593
- name: Hlavička
- other names: {"cs": "hlavička"}
- countries: (none)
- kinds: dish

## DISH Q2668259
- name: Popara
- description: bread and broth dish
- countries: TR
- kinds: dish
- has Wikipedia article: en

## DISH Q26690042
- name: Confetti di Sulmona
- description: candy-coated almonds
- countries: IT
- cuisines: Abruzzese cuisine
- kinds: dragée
- has Wikipedia article: en

## DISH Q2669274
- name: Tandoor bread
- description: bread made in a tandoor
- countries: IQ
- kinds: food, flatbread
- ingredients: flour, drinking water
- has Wikipedia article: en

## DISH Q26693028
- name: Nazook
- description: Armenian pastry
- countries: AM
- kinds: pastry
- ingredients: white sugar, smetana, egg as food, yeast, flour, butter
- has Wikipedia article: en

## DISH Q2669352
- name: Medisterpølse
- description: type of Scandinavian sausage
- countries: DK
- kinds: pork dish, fresh sausage
- has Wikipedia article: en

## DISH Q266997
- name: Egg in the basket
- other names: {"zh": "鸡蛋篮子"}
- description: egg fried in a hole in a slice of bread
- countries: US
- cuisines: cuisine of the United States
- kinds: dish
- ingredients: egg as food, bread, chicken egg
- has Wikipedia article: en

## DISH Q26706802
- name: Kilor
- description: Type of bread
- countries: IQ, TR, IR, SY
- cuisines: Kurdish cuisine
- kinds: type of food or dish, bread

## DISH Q2671154
- name: Kitfo
- other names: {"zh": "基特富"}
- description: Ethiopian plate: marinated raw beef meat
- countries: ER, ET
- kinds: raw beef dish
- ingredients: raw meat
- has Wikipedia article: en

## DISH Q2671459
- name: Polvoron
- other names: {"zh": "食谱/西班牙小饼"}
- description: Andalusian shortbread
- countries: ES
- kinds: pastry
- ingredients: almond, flour, sugar, milk
- has Wikipedia article: en

## DISH Q26743338
- name: Hertzoggie
- description: jam-filled cookie
- countries: ZA
- cuisines: South African cuisine
- kinds: food, cookie
- ingredients: flour
- has Wikipedia article: en

## DISH Q2674820
- name: Hubertus bread
- countries: (none)
- kinds: bread

## DISH Q267497
- name: Eintopf
- other names: {"zh": "一锅烩"}
- description: traditional German pot-stew
- countries: DE
- cuisines: German cuisine
- kinds: dish, stew, potato dish
- has Wikipedia article: en, zh

## DISH Q267554
- name: Dried fruit bread
- description: sweet bread baked with dried fruit
- countries: FR
- kinds: cake
- has Wikipedia article: en

## DISH Q26769086
- name: Lotus-seed-paste mooncake
- other names: {"zh": "蓮蓉月餅"}
- countries: (none)
- kinds: mooncake, lotus seed paste cake
- ingredients: lotus seed paste
- has Wikipedia article: zh

## DISH Q26769088
- name: Custard mooncake
- other names: {"zh": "奶黃月餅"}
- countries: HK
- cuisines: Hong Kong cuisine
- kinds: mooncake
- has Wikipedia article: zh

## DISH Q267726
- name: Easter bread
- other names: {"zh": "復活節麵包"}
- description: bread traditionally eaten around Easter
- countries: (none)
- kinds: bread, pastry, Easter food
- has Wikipedia article: en

## DISH Q267763
- name: Apple horseradish
- description: apple and horseradish sauce
- countries: AT, DE
- kinds: sauce, dish
- ingredients: chrain, horseradish root, cream, table salt, sugar, Citrus × limon, apple

## DISH Q2678876
- name: Boerenomelet
- other names: {"nl": "boerenomelet"}
- countries: (none)
- kinds: omelette

## DISH Q26791887
- name: Sweet pie
- description: pie which is not salty
- countries: (none)
- kinds: pastry, pie, bakers' confection
- has Wikipedia article: en

## DISH Q2679937
- name: Pelmeni
- other names: {"zh": "俄國餃子"}
- description: Russian dumplings
- countries: RU
- cuisines: Soviet cuisine, Russian cuisine
- kinds: frozen meat semi-finished products, prepared and preserved meat and poultry meat, meat offal or animal blood products, other; extracts and juices from meat, fish and aquatic invertebrates (OKPD 15.13.12), dumpling, stuffed pasta
- ingredients: table salt, meat, beef stock, chicken stock, dill, onion, peppercorn, dough, egg as food, butter
- has Wikipedia article: en, zh

## DISH Q26806341
- name: Beyran
- description: Turkish soup
- countries: TR
- kinds: dish, soup
- has Wikipedia article: en

## DISH Q268114
- name: Fisherman's soup
- other names: {"zh": "漁夫湯"}
- description: Hungarian fish soup
- countries: HU
- kinds: fish soup, food
- ingredients: tomato, Hungarian wax pepper, onion, paprika, fish as food
- has Wikipedia article: en, zh

## DISH Q26848933
- name: Military biscuit
- description: biscuit issued in the Swiss military
- countries: CH
- kinds: hardtack
- has Wikipedia article: en

## DISH Q26857408
- name: Nameshi dengaku
- countries: (none)
- kinds: dish
- ingredients: Nameshi, dengaku

## DISH Q26857710
- name: To-beram
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish

## DISH Q2687127
- name: Beijinho
- description: Brazilian birthday party candy
- countries: BR
- cuisines: Brazilian cuisine
- kinds: confectionery
- ingredients: clove, coconut, condensed milk, sugar
- has Wikipedia article: en

## DISH Q26877711
- name: Milchkonfitüre
- other names: {"de": "Milchkonfitüre"}
- countries: (none)
- kinds: dish

## DISH Q2688167
- name: Indian bread
- description: type of bread
- countries: (none)
- kinds: South Asian bread
- has Wikipedia article: en

## DISH Q26884006
- name: Ofada rice
- description: Name for heritage varieties of rice grown in south-west Nigeria and used in a variety of dishes
- countries: NG
- cuisines: Nigerian cuisine
- kinds: dish, human food
- ingredients: iru, vegetable oil, seasoning, table salt
- has Wikipedia article: en

## DISH Q26884481
- name: Pletskeskook
- other names: {"li": "Pletskeskook"}
- countries: (none)
- kinds: pastry

## DISH Q268857
- name: 炸飯丸球
- description: traditional Italian dish
- countries: IT
- cuisines: Italian cuisine
- kinds: rice dish, fried food, rice ball
- ingredients: bread crumbs, rice
- has Wikipedia article: en, zh

## DISH Q26897677
- name: Sugared cranberries
- countries: BY
- kinds: dessert, dish
- ingredients: cranberry, powdered sugar

## DISH Q2691193
- name: Lammetjespap
- other names: {"nl": "lammetjespap"}
- countries: (none)
- kinds: type of food or dish, porridge

## DISH Q26928862
- name: Beschuitbol
- other names: {"nl": "beschuitbol"}
- countries: (none)
- kinds: food, bread

## DISH Q26936785
- name: Macha
- countries: (none)
- kinds: confectionery

## DISH Q26936786
- name: Soru Chakli
- description: Pancake pitha from Eastern India
- countries: IN
- kinds: human food, Pitha, fermented food
- ingredients: lentil, rice

## DISH Q26936803
- name: Shukto
- description: One kind of Bengali Cuisine
- countries: (none)
- kinds: type of food or dish, vegetable dish
- has Wikipedia article: en

## DISH Q2695207
- name: Fleuron (Gebäck)
- other names: {"de": "Fleuron (Gebäck)"}
- countries: (none)
- kinds: viennoiserie
