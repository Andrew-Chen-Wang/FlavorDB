# Review batch names-051

## DISH Q65241855
- name: Pinsuyaki
- countries: (none)
- kinds: baby castella

## DISH Q65242333
- name: Perunalimppu
- other names: {"fi": "Perunalimppu"}
- countries: (none)
- kinds: bread

## DISH Q65242339
- name: Perunapuuro
- other names: {"fi": "Perunapuuro"}
- countries: (none)
- kinds: dish

## DISH Q65242495
- name: Pikkuleipä
- other names: {"fi": "Pikkuleipä"}
- countries: (none)
- kinds: pastry

## DISH Q65243771
- name: Rantakala
- other names: {"fi": "Rantakala"}
- countries: (none)
- kinds: fish dish

## DISH Q65244350
- name: Sekaleipä
- other names: {"fi": "sekaleipä"}
- description: bread
- countries: (none)
- kinds: bread
- ingredients: baker's yeast, flour, water

## DISH Q65244506
- name: Siskonmakkarakeitto
- other names: {"fi": "Siskonmakkarakeitto"}
- countries: (none)
- kinds: dish

## DISH Q65245034
- name: Suutarinlohi
- other names: {"fi": "Suutarinlohi"}
- countries: (none)
- kinds: fish dish

## DISH Q65245575
- name: Topseilvellinki
- other names: {"fi": "Topseilvellinki"}
- countries: (none)
- kinds: dessert

## DISH Q65249937
- name: Arayes
- description: Middle East streetfood, minced meat in pita bred
- countries: (none)
- kinds: street food
- ingredients: pita, meat
- has Wikipedia article: en

## DISH Q65251381
- name: Bubur kampiun
- description: Indonesia traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, congee
- ingredients: rice flour, coconut milk, Vigna radiata, Pandanus amaryllifolius, glutinous rice, table salt, sugar, banana

## DISH Q65251483
- name: Beef tendon curry
- description: food made from beef tendon/skin
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, beef
- ingredients: Garcinia xanthochymus fruit, Kaffir Lime Leaf, ginger, cowhide, cow's trotters, coconut milk, Alpinia galanga, Allium ascalonicum, chili pepper, Curcuma longa, Cymbopogon citratus, Allium sativum

## DISH Q65251557
- name: Bika
- other names: {"id": "Bika"}
- countries: (none)
- kinds: food, cookie, kue
- ingredients: grated coconut, rice flour, table salt

## DISH Q65251561
- name: Kue katen
- other names: {"min": "Kue katen"}
- countries: ID
- cuisines: Padang cuisine
- kinds: dish, kue
- ingredients: granulated sugar, corn starch, coconut, tapioca, table salt

## DISH Q65251674
- name: Palai rinuak
- other names: {"min": "Palai rinuak"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: type of food or dish, food, dish, fish dish
- ingredients: shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, ginger, grated coconut, rawit, Alpinia galanga, Citrus × aurantiifolia, chili pepper, Cymbopogon citratus, table salt, Indonesian bay leaf, turmeric leaf

## DISH Q65251692
- name: Pangek cubadak
- other names: {"id": "Pangek cubadak"}
- description: Indonesian specialty dish made from young jackfruit
- countries: ID
- kinds: food, type of food or dish, gulai
- ingredients: Indonesian bay leaf, turmeric leaf, Kaffir Lime Leaf, jackfruit, coconut milk, Alpinia galanga, broth, Allium ascalonicum, chili pepper, black pepper, Curcuma longa, ginger, Allium sativum, table salt

## DISH Q65251886
- name: Singgang ayam
- other names: {"min": "Singgang ayam"}
- countries: (none)
- kinds: human, chicken dish

## DISH Q65261401
- name: 室根からあげ
- other names: {"ja": "室根からあげ"}
- countries: (none)
- kinds: chicken karaage

## DISH Q652628
- name: Sainte-Maure de Touraine
- other names: {"zh": "图赖讷地区圣莫尔奶酪"}
- description: goat-milk cheese from the department of Indre-et-Loire, France
- countries: FR
- kinds: goat cheese, raw-milk cheese, French cheese, farmstead cheese, industrial cheese, natural-rind soft cheese, dairy cheese
- ingredients: goat milk, straw
- has Wikipedia article: en

## DISH Q65264135
- name: Yakushima ramen
- countries: (none)
- kinds: ramen

## DISH Q65273709
- name: 生たまご生プリン
- other names: {"ja": "生たまご生プリン"}
- countries: (none)
- kinds: confectionery

## DISH Q65273971
- name: 田舎饅頭
- other names: {"ja": "田舎饅頭"}
- countries: (none)
- kinds: manjū

## DISH Q65281575
- name: 蟹ヶ坂飴
- other names: {"ja": "蟹ヶ坂飴"}
- countries: (none)
- kinds: wagashi

## DISH Q6528443
- name: Mataz
- description: filled dumplings in Circassian cuisine
- countries: (none)
- kinds: dumpling, dish
- has Wikipedia article: en

## DISH Q65292860
- name: Rice with foxtail millet
- description: Korean staple food
- countries: (none)
- kinds: dish

## DISH Q65293809
- name: 鶴岡のお雛菓子
- other names: {"ja": "鶴岡のお雛菓子"}
- countries: (none)
- kinds: wagashi

## DISH Q65293815
- name: Kirisansho
- countries: (none)
- kinds: kirizashō

## DISH Q65304196
- name: Upka
- description: Tajik dish
- countries: TJ
- kinds: dish
- ingredients: cattle lung, milk

## DISH Q65322420
- name: Nuget gedhang
- other names: {"jv": "nuget gedhang"}
- countries: (none)
- kinds: sweetmeat

## DISH Q65336960
- name: No htamin
- description: Frestive milk rice dish from Burma
- countries: MM
- kinds: dish
- has Wikipedia article: en

## DISH Q65343519
- name: Cingkaruk
- description: a traditional Banjar snack made from glutinous rice
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, confectionery, jajan pasar, snack, Dodol
- ingredients: grated coconut, palm sugar, banana

## DISH Q65343730
- name: Mustofa Potatoes
- description: dry dish consisting of thinly sliced potatoes
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, snack, potato dish
- ingredients: garlic, tomato, palm sugar, Allium ascalonicum, chili pepper, peanut, potato

## DISH Q65343866
- name: Putri noong
- description: A traditional Sundanese steamed cake made from grated cassava with a banana filling
- countries: ID
- kinds: dish, type of food or dish, kue
- ingredients: cassava root, banana leaf, coconut, coconut milk, vanilla, table salt, sugar, margarine, banana

## DISH Q6538385
- name: Japanese style peanuts
- other names: {"zh": "日式花生"}
- description: Japanese-Mexican snack food
- countries: MX
- kinds: nut, Peanuts in a crispy shell
- ingredients: peanut
- has Wikipedia article: en, zh

## DISH Q65391959
- name: Micca
- description: bread type
- countries: (none)
- kinds: bread

## DISH Q65392665
- name: Brune koeke
- other names: {"fy": "brune koeke"}
- countries: (none)

## DISH Q65392830
- name: Soetelief
- other names: {"fy": "soetelief"}
- countries: (none)

## DISH Q65392897
- name: Wite koeke
- other names: {"fy": "wite koeke"}
- countries: (none)

## DISH Q6539373
- name: Lia
- description: prepared food
- countries: IN
- kinds: dish
- has Wikipedia article: en

## DISH Q65398168
- name: પૌંઆનો શીરો
- other names: {"gu": "પૌંઆનો શીરો"}
- countries: (none)
- kinds: dish

## DISH Q65400891
- name: Muffuletta
- other names: {"id": "Muffuletta"}
- description: sicilian bread
- countries: (none)
- kinds: bread

## DISH Q6541482
- name: Caciocavallo Silano PDO
- other names: {"zh": "Caciocavallo Silano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: pasta filata, Italian cheese, cheese
- ingredients: cow's milk

## DISH Q65418429
- name: Cæxæradžyn
- countries: (none)
- cuisines: Ossetian cuisine
- kinds: Ossetian pies

## DISH Q65430396
- name: Vospapour
- description: Armenian lentil soup
- countries: AM
- kinds: lentil soup

## DISH Q65433497
- name: Frappe
- other names: {"fr": "frappe"}
- countries: (none)
- kinds: dish

## DISH Q65446427
- name: Waina
- description: savory fried rice or maize cake from Nigeria
- countries: NG
- kinds: dish, human food

## DISH Q65449083
- name: Buah jingah
- description: a traditional Indonesian cake made from mashed mung beans and sweet potatoes
- countries: ID
- kinds: kue, dish, type of food or dish
- ingredients: cassava root, coconut, rice flour, Sweet potato, table salt, sugar

## DISH Q65449108
- name: Gandasturi
- description: a traditional Indonesian cake made from boiled mung beans
- countries: ID
- kinds: dish, type of food or dish
- ingredients: wheat flour, rice flour, coconut milk, Vigna radiata, cooking oil, egg as food, vanilla, table salt, sugar, water

## DISH Q6545590
- name: Entrée
- other names: {"zh": "副菜"}
- description: dish served before the main course of a meal; either the first dish or following a soup or other small dish or dishes
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q654626
- name: Mie
- other names: {"nl": "Mie"}
- countries: (none)
- kinds: dish

## DISH Q6546642
- name: Lighvan Cheese
- description: brined curd sheep's milk cheese traditionally made in Iran
- countries: IR
- cuisines: Iranian cuisine
- kinds: sheep milk cheese
- ingredients: sheep milk
- has Wikipedia article: en

## DISH Q6547351
- name: Likëngë
- description: Italian sausage
- countries: IT
- kinds: Italian sausage, pork dish
- has Wikipedia article: en

## DISH Q6549260
- name: Limerick Ham
- description: method of preparing a joint of bacon within the cuisine of Ireland
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q655040
- name: Oden
- other names: {"zh": "关东煮"}
- description: Japanese dish
- countries: JP
- cuisines: Japanese cuisine
- kinds: nabemono, nimono
- has Wikipedia article: en, zh

## DISH Q6551020
- name: Tutmaç soup
- description: traditional Turkish cuisine dish (soup)
- countries: TR
- kinds: soup

## DISH Q655235
- name: Muffuletta
- description: sandwich
- countries: US
- kinds: dish
- has Wikipedia article: en

## DISH Q65524341
- name: Cloudberry jam
- description: jam of cloudberries
- countries: (none)
- kinds: jam
- ingredients: cloudberry, pectin, sugar

## DISH Q65545224
- name: Fig jam
- description: jam made from figs
- countries: (none)
- kinds: fruit jam
- ingredients: fig

## DISH Q65547070
- name: Glass noodle salad
- description: salad made with glass noodles
- countries: (none)
- kinds: salad, noodle dish
- ingredients: cellophane noodles

## DISH Q65547303
- name: Sourdough baguette
- description: bread
- countries: (none)
- ingredients: sourdough

## DISH Q65547592
- name: Roasted cauliflower
- description: vegetarian dish
- countries: (none)
- kinds: food, vegetable dish
- ingredients: cauliflower

## DISH Q65548127
- name: Pulled chicken
- description: method of cooking chicken
- countries: (none)
- kinds: dish, chicken dish
- ingredients: chicken as food

## DISH Q65548218
- name: Seed cracker
- description: food
- countries: (none)
- kinds: cracker
- ingredients: seed

## DISH Q65548263
- name: Lentil salad
- description: salad made with lentils
- countries: (none)
- kinds: salad
- ingredients: lentil

## DISH Q65548270
- name: Browned Brussels sprouts
- description: dish of cooked Brussels sprouts
- countries: (none)
- kinds: dish
- ingredients: brussels sprouts

## DISH Q65554137
- name: Raw ball
- description: raw food confection
- countries: (none)
- kinds: confectionery

## DISH Q65561282
- name: Artichoke creme
- description: creme with artichoke
- countries: (none)
- kinds: food, soup
- ingredients: globe artichoke

## DISH Q65561673
- name: San jacobo
- other names: {"es": "san jacobo"}
- countries: ES
- kinds: cordon bleu, breading
- ingredients: Paris ham, cheese

## DISH Q65564214
- name: Patitas con maní
- other names: {"es": "patitas con maní"}
- countries: PE
- kinds: guiso, meal
- ingredients: pig's trotters, potato, peanut

## DISH Q65581385
- name: Soupe verte à la mauve
- other names: {"fr": "soupe verte à la mauve"}
- countries: (none)
- kinds: soup

## DISH Q65589417
- name: Warm goat cheese salad
- description: French dish, consisting of Chèvre cheese served hot
- countries: FR
- kinds: cheese salad, dish
- ingredients: goat cheese, salad
- has Wikipedia article: en

## DISH Q6559431
- name: Open sandwich
- other names: {"zh": "單面三明治"}
- description: single slice of bread with food items on top
- countries: (none)
- kinds: sandwich, type of food or dish
- ingredients: food ingredient, bread
- has Wikipedia article: en, zh

## DISH Q6564586
- name: Ka'ak al-Quds
- description: Israeli bread
- countries: (none)
- kinds: bread, baked good, Ka'ak, food
- has Wikipedia article: en

## DISH Q65694198
- name: Yam pottage
- description: Ghanaian food made from yam and stew
- countries: GH
- kinds: food, type of food or dish
- ingredients: garlic, tomato, ginger, dried fish, onion, cocoyam, palm oil, chili pepper, table salt, drinking water
- has Wikipedia article: en

## DISH Q657007
- name: Chocolate letter
- description: letters of the alphabet made of chocolate
- countries: (none)
- kinds: Sinterklaas candy
- ingredients: chocolate
- has Wikipedia article: en

## DISH Q6570706
- name: Chraime
- description: dish of fish in spicy tomato sauce which originates in the Maghreb
- countries: (none)
- kinds: dish
- ingredients: Pilpelchuma, fish
- has Wikipedia article: en

## DISH Q65737686
- name: Lashka
- description: national dish of Mari El
- countries: (none)
- cuisines: Mari cuisine
- kinds: noodle soup, dish
- ingredients: dough, Pisum, potato, meat, milk, fish

## DISH Q6574446
- name: Su böreği
- description: food
- countries: TR
- kinds: börek
- has Wikipedia article: en

## DISH Q6575260
- name: Kipper
- other names: {"zh": "腌魚"}
- description: lightly salted and cold smoked herring
- countries: IM
- kinds: smoked fish, fish dish
- has Wikipedia article: en, zh

## DISH Q65769686
- name: Beetroot soup
- countries: (none)
- kinds: food, soup
- ingredients: beet

## DISH Q6578151
- name: Orange soup
- description: soup based on orange vegetables such as pumpkin, carrot, yam
- countries: (none)
- kinds: vegetable soup

## DISH Q657835
- name: Pincho moruno
- description: meat skewer
- countries: ES
- kinds: food, lamb dish, chicken dish, skewer
- ingredients: lamb meat, meat
- has Wikipedia article: en

## DISH Q6581424
- name: Paçanga
- description: Turkish börek type
- countries: TR
- kinds: börek, dish
- has Wikipedia article: en

## DISH Q658413
- name: Bread crumbs
- other names: {"zh": "麵包屑"}
- description: small pieces of dried bread used as a culinary ingredient
- countries: (none)
- kinds: bread
- ingredients: bread
- has Wikipedia article: en, zh

## DISH Q6585018
- name: Mafrum
- description: Libyan-Jewish and Tunisian-Jewish meat dish
- countries: LY, TN
- cuisines: Jewish cuisine, Tunisian cuisine, Libyan cuisine
- kinds: stuffed vegetable, dish
- ingredients: minced meat, potato
- has Wikipedia article: en

## DISH Q6585755
- name: Mercimek köftesi
- description: Turkish cold dish (or meze) of "balls" of boiled red lentils, bulgur, green onions etc
- countries: TR
- kinds: food, meze
- ingredients: onion, tomato paste, bulgur, Lens, olive oil
- has Wikipedia article: en

## DISH Q6588272
- name: Kubaneh
- description: traditional food from Yemeni cuisine
- countries: YE
- kinds: bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q6591
- name: Speculaas biscuit
- other names: {"zh": "焦糖饼干"}
- description: traditional spiced biscuit from the Low Countries
- countries: NL
- cuisines: Dutch cuisine
- kinds: biscuit
- ingredients: speculaas
- has Wikipedia article: en, zh

## DISH Q659277
- name: Valençay
- other names: {"zh": "瓦朗赛"}
- description: unpasteurised goats-milk cheese from the province of Berry, France
- countries: FR
- kinds: raw-milk cheese, French cheese, farmstead cheese, industrial cheese, dairy cheese, goat cheese, white mold-rind cheese
- ingredients: goat milk
- has Wikipedia article: en

## DISH Q6593562
- name: Urnebes
- description: spicy Serbian salad dish
- countries: RS
- kinds: salad
- ingredients: cheese
- has Wikipedia article: en

## DISH Q6593882
- name: Kazandibi
- other names: {"zh": "卡贊迪比"}
- description: Turkish dessert (sort of milk pudding)
- countries: TR
- kinds: dessert
- has Wikipedia article: en

## DISH Q659636
- name: Chocolate con churros
- description: Spanish sweet dish
- countries: (none)
- kinds: sweet dish
- ingredients: porra, churro, chocolate

## DISH Q65994712
- name: Pepitos de crema
- countries: (none)
- kinds: meal, dessert

## DISH Q66049024
- name: Applebee's Butter Pecan Blondie
- description: dessert from Applebee's
- countries: US
- kinds: dessert

## DISH Q66049052
- name: Applebee's Triple Chocolate Meltdown
- description: dessert
- countries: US
- kinds: dessert
- ingredients: vanilla ice cream, chocolate syrup, chocolate cake

## DISH Q66049068
- name: Applebee's Spinach + Artichoke Dip
- description: dish
- countries: US
- kinds: dish
- ingredients: spinach and artichoke dip

## DISH Q66049079
- name: Spinach and artichoke dip
- description: food
- countries: (none)
- kinds: dish, spinach dip
- ingredients: spinach, globe artichoke

## DISH Q66049188
- name: Applebee's Classic Combo
- description: appetizer at Applebee's
- countries: US
- kinds: appetizer
- ingredients: artichoke dip, chips and dip, Buffalo wings, mozzarella stick, quesadilla

## DISH Q66133427
- name: Potage à la Marcus Hill
- description: recipe for veal soup
- countries: (none)
- kinds: soup

## DISH Q662125
- name: Vacherin Mont-d'Or
- description: Soft cheese made in France and Switzerland
- countries: CH, FR
- kinds: raw-milk cheese, French cheese, cow's-milk cheese, washed-rind cheese, Swiss cheeses
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q662189
- name: Sfogliatelle
- other names: {"zh": "義式千層酥"}
- description: Italian filled pastry
- countries: IT
- cuisines: Italian cuisine
- kinds: pastry
- ingredients: puff pastry
- has Wikipedia article: en

## DISH Q66246606
- name: Pickled fish
- description: fish dish prepared by marinating any of various sorts of fish
- countries: (none)
- kinds: fish dish

## DISH Q6629253
- name: Karsambaç
- description: snow and pekmez or syrup (or honey) dessert
- countries: TR
- kinds: dessert, type of food or dish
- ingredients: molasses, snow

## DISH Q66311565
- name: Revani
- description: Turkish cuisine dessert
- countries: (none)
- kinds: dessert, food
- ingredients: semolina, egg as food, flour, yogurt, sugar

## DISH Q66317711
- name: Manhattan Clam Chowder
- description: Clam chowder with red, tomato-based broth, without milk or cream
- countries: (none)
- kinds: clam chowder

## DISH Q663306
- name: Beşbarmaq
- other names: {"zh": "别什巴尔马克"}
- description: Turkic lamb dish
- countries: KZ, TM, KG
- cuisines: Kazakh cuisine, Cuisine of Uzbekistan, Turkmen cuisine, Tatarstan cuisine, Bashkir cuisine, Kyrgyz cuisine, Karakalpak cuisine, Uyghur cuisine
- kinds: finger food, lamb dish
- ingredients: noodle, onion, meat, lamb meat
- has Wikipedia article: en, zh

## DISH Q66330986
- name: Guargüero
- description: Peruvian fried dessert
- countries: PE
- kinds: dessert, meal

## DISH Q66364496
- name: Mücendra pilavı
- description: dish from the Turkish Cypriot cuisine
- countries: (none)
- cuisines: cuisine of Northern Cyprus
- kinds: pilav, food
- ingredients: lentil, onion, rice

## DISH Q66425668
- name: Sanguito
- countries: (none)
- kinds: meal, confectionery

## DISH Q66426184
- name: Arroz tapado
- other names: {"es": "arroz tapado"}
- countries: (none)
- kinds: meal, rice dish

## DISH Q664836
- name: Bricelet
- description: Swiss wafer
- countries: (none)
- kinds: wafer cookie

## DISH Q6658215
- name: Liver soup
- description: Chinese cuisine
- countries: CN
- kinds: soup
- ingredients: pork

## DISH Q6658276
- name: Livermush
- description: American pork and cornmeal dish
- countries: US
- kinds: pork dish
- has Wikipedia article: en

## DISH Q66602059
- name: Fish ragout
- countries: (none)
- kinds: ragout
- ingredients: fish as food

## DISH Q66604754
- name: Menestron
- countries: (none)
- kinds: meal, soup

## DISH Q66613654
- name: Chicken Wonton Tacos
- description: dish at Applebee's
- countries: US
- kinds: dish
- ingredients: cilantro, coleslaw, taco, sauce, chicken

## DISH Q666242
- name: Flatbread
- other names: {"zh": "烤餅"}
- description: type of bread
- countries: (none)
- kinds: bread, bing
- ingredients: flour, table salt, water
- has Wikipedia article: en, zh

## DISH Q6663590
- name: Lobby
- description: type of stew
- countries: (none)
- kinds: stew, beef dish
- has Wikipedia article: en

## DISH Q6664328
- name: Teriyaki burger
- description: Japanese burger with teriyaki sauce
- countries: (none)
- kinds: hamburger
- ingredients: teriyaki sauce

## DISH Q6665217
- name: Hedik
- description: Turkish dish
- countries: AZ, IR, TR
- kinds: food

## DISH Q6665463
- name: Lockets
- description: confectionery product
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q6669461
- name: Lomi
- description: type of noodle soup
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q66720241
- name: बुड्ढी के बाल
- other names: {"hi": "बुड्ढी के बाल"}
- description: a type of sugar candy
- countries: (none)
- kinds: sugar candy

## DISH Q6672749
- name: Long John
- description: American pastry
- countries: (none)
- kinds: doughnut
- ingredients: dough
- has Wikipedia article: en

## DISH Q6673476
- name: Aarrearkku
- other names: {"fi": "Aarrearkku"}
- countries: (none)
- kinds: candy

## DISH Q667478
- name: Cheeseburger
- other names: {"zh": "起司堡"}
- description: hamburger topped with cheese
- countries: US
- kinds: hamburger, sandwich, type of food or dish
- ingredients: bun, patty, cheese
- has Wikipedia article: en, zh

## DISH Q6674872
- name: Lontong Cap Go Meh
- other names: {"zh": "隆東十五暝"}
- description: Indonesian dish
- countries: ID
- kinds: chicken dish
- ingredients: garlic, coriander seed, peppercorn, lontong, Aleurites moluccanus, coconut milk, cooking oil, Allium ascalonicum, chicken
- has Wikipedia article: en, zh

## DISH Q66809735
- name: Teegebäck
- other names: {"de": "Teegebäck"}
- countries: (none)
- kinds: viennoiserie

## DISH Q66817770
- name: Carne polaca
- description: Mexican meat dish
- countries: MX
- kinds: dish
- ingredients: cabbage, chicken as food, beef

## DISH Q668269
- name: Tiroler Gröstl
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q6682881
- name: 野薑花粽
- countries: CN
- kinds: zongzi
- has Wikipedia article: zh

## DISH Q6685108
- name: Phat si io
- other names: {"zh": "泰式炒河"}
- description: Asian stir fried noodle dish
- countries: TH
- cuisines: Thai cuisine
- kinds: noodle dish
- ingredients: rice noodle, noodle, egg as food
- has Wikipedia article: en, zh

## DISH Q668855
- name: Scrambled eggs
- other names: {"zh": "炒蛋"}
- description: dish
- countries: (none)
- kinds: food, dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q6689683
- name: Lountza
- description: Cypriot meat delicacy
- countries: CY, IT
- kinds: dish
- ingredients: coriander seed, pork, table salt, wine

## DISH Q66918180
- name: Vlčnovský vdolek
- countries: (none)
- kinds: kolach, sweet dish

## DISH Q66937606
- name: Torta
- description: Catalan type of black bread
- countries: (none)
- kinds: black bread

## DISH Q66979416
- name: Yassı kadayıf
- description: Turkish dessert
- countries: TR
- kinds: dessert, food

## DISH Q669996
- name: Kuku
- other names: {"zh": "波斯煎蛋餅"}
- description: genre of Persian food, made with egg as a binder and another ingredient
- countries: AZ, IR
- kinds: food, dish
- ingredients: herb, egg as food
- has Wikipedia article: en, zh

## DISH Q6704560
- name: Luo si zhuan
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q67079568
- name: Gulai Tepek Ikan
- countries: (none)
- kinds: dish, type of food or dish

## DISH Q6708220
- name: Lymonnyk
- countries: (none)
- kinds: food, sweet pie
- ingredients: lemon

## DISH Q67088571
- name: Braised Shaak Roast
- description: entrée served at Docking Bay 7 Food and Cargo
- countries: (none)
- kinds: entrée
- ingredients: pot roast, edible mushroom, kale, cavatelli

## DISH Q6710583
- name: Lyutika
- description: Bulgarian vegetable dish
- countries: BG
- kinds: salad
- ingredients: Capsicum
- has Wikipedia article: en

## DISH Q67187245
- name: Cooked ham
- countries: (none)
- kinds: ham, cooked whole-muscle cut

## DISH Q67187258
- name: Smoked ham
- countries: (none)
- kinds: ham, smoked meat

## DISH Q67187283
- name: Knochenschinken
- other names: {"de": "Knochenschinken"}
- countries: (none)
- kinds: raw ham

## DISH Q67197494
- name: Schilleder Torte
- other names: {"cs": "Schilleder Torte"}
- countries: (none)
- kinds: torte

## DISH Q6720982
- name: Maachha Bihana
- description: Indian curry dish with fish roe
- countries: IN
- kinds: fish dish, Indian curry
- has Wikipedia article: en

## DISH Q6723517
- name: Machh bhaja
- description: Bengali-style fish fry
- countries: (none)
- kinds: fish fry
- has Wikipedia article: en

## DISH Q6723519
- name: Machha Jhola
- description: fish curry in Bengali cuisine
- countries: (none)
- kinds: Indian curry, Jhol, fish curry
- ingredients: fish
- has Wikipedia article: en

## DISH Q6724837
- name: Macon
- description: bacon substitute
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q6726660
- name: Maddur vada
- other names: {"zh": "馬德杜爾點心"}
- description: savoury fritter-type snack from South India
- countries: (none)
- kinds: Vada
- has Wikipedia article: en

## DISH Q6728543
- name: Madras curry
- other names: {"zh": "马德拉斯咖哩"}
- description: Indian curry dish
- countries: IN
- kinds: sauce, Indian curry
- ingredients: chili powder
- has Wikipedia article: en

## DISH Q6729605
- name: Magaj
- other names: {"zh": "馬嘉滋"}
- description: offal dish originating from India
- countries: IN
- kinds: food, dish
- ingredients: brain
- has Wikipedia article: en

## DISH Q673154
- name: Cervelat
- other names: {"zh": "施华力肠"}
- description: Swiss pork sausage
- countries: CH
- cuisines: Swiss cuisine
- kinds: Brühwurst, national dish
- has Wikipedia article: en, zh

## DISH Q6734969
- name: Mahua
- other names: {"zh": "麻花"}
- description: Chinese dough twist that is fried in peanut oil
- countries: CN
- kinds: doughnut
- ingredients: dough
- has Wikipedia article: en, zh

## DISH Q6738866
- name: Makchang-gui
- description: beef abomasum
- countries: KR
- cuisines: Korean cuisine
- kinds: Gui, beef dish
- ingredients: abomasum
- has Wikipedia article: en

## DISH Q6740762
- name: Malabar matthi curry
- description: south Indian fish curry
- countries: IN
- kinds: Indian curry, fish curry
- ingredients: sardine
- has Wikipedia article: en

## DISH Q67412028
- name: Smoked Kaadu Ribs
- description: entrée served at Docking Bay 7 Food and Cargo
- countries: (none)
- kinds: entrée
- ingredients: spare ribs, coleslaw, muffin

## DISH Q67440705
- name: Ribbon noodle
- description: type of noodle
- countries: (none)
- kinds: type of pasta, pasta, noodle

## DISH Q6744505
- name: Etli ekmek
- description: Turkish "pide" from the city and province of Konya
- countries: TR
- kinds: pide, food
- ingredients: dough, vegetable, meat
- has Wikipedia article: en

## DISH Q67445556
- name: Grated chocolate
- countries: (none)
- kinds: chocolate

## DISH Q67445831
- name: Blackberry marmalade
- description: marmalade made from blackberries
- countries: (none)
- kinds: marmalade

## DISH Q6744641
- name: Malt loaf
- description: type of sweet leavened bread
- countries: GB
- kinds: bread
- ingredients: malt
- has Wikipedia article: en

## DISH Q6744769
- name: Malted milk
- other names: {"zh": "麥乳精餅乾"}
- description: biscuit
- countries: (none)
- kinds: biscuit
- has Wikipedia article: en

## DISH Q67448569
- name: Conchigliette
- other names: {"de": "Conchigliette"}
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta

## DISH Q6745014
- name: Malva pudding
- description: South African sweet pudding
- countries: ZA
- cuisines: South African cuisine
- kinds: food, dessert
- has Wikipedia article: en

## DISH Q6747205
- name: Manchamanteles
- description: Mexican stew
- countries: MX
- kinds: dish
- has Wikipedia article: en

## DISH Q6747588
- name: Manchester tart
- description: English baked tart
- countries: GB
- cuisines: English cuisine
- kinds: food, pie
- ingredients: shortcrust pastry
- has Wikipedia article: en

## DISH Q6747617
- name: Manchow soup
- other names: {"zh": "满洲汤"}
- description: indian-Chinese soup
- countries: IN
- cuisines: Indian Chinese cuisine
- kinds: soup
- ingredients: vegetable
- has Wikipedia article: en, zh

## DISH Q6748129
- name: Mandoca
- description: Venezuelan fried dough dessert
- countries: VE
- kinds: food, bread
- ingredients: cornmeal, cheese
- has Wikipedia article: en

## DISH Q6748208
- name: Limpa bread
- description: scandinavian rye bread flavored with caraway and orange peel
- countries: SE
- cuisines: Swedish cuisine
- kinds: bread, rye bread
- ingredients: rye flour, linear maltodextrin, yeast, butter, sugar
- has Wikipedia article: en

## DISH Q6748240
- name: Mandu-gwa
- description: Korean dessert in the shape of mandu
- countries: KR
- cuisines: Korean cuisine
- kinds: yumilgwa
- ingredients: dough
- has Wikipedia article: en

## DISH Q674980
- name: Luxemburgerli
- description: confectionery made in Switzerland
- countries: (none)
- kinds: macaron
- has Wikipedia article: en

## DISH Q6750304
- name: Maniçoba
- description: Brazilian pork dish
- countries: BR
- cuisines: Brazilian cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q6750905
- name: Mannish water
- description: goat soup in Jamaican cuisine
- countries: JM
- kinds: food, soup, goat meat dish
- ingredients: goat
- has Wikipedia article: en

## DISH Q6752009
- name: Manteca colorá
- description: Andalusian cooking ingredient and dish
- countries: ES
- kinds: food, spread
- ingredients: lard
- has Wikipedia article: en

## DISH Q6754021
- name: Maple slaw
- description: variation of Coleslaw
- countries: CA
- kinds: salad
- ingredients: maple syrup

## DISH Q6754314
- name: Maque choux
- description: corn, green bell pepper, onion (and sometimes garlic), celery, and tomato, braised in a pot
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q675466
- name: Bosintang
- other names: {"zh": "補身湯"}
- description: Korean soup of dog meat
- countries: KR
- cuisines: Korean cuisine
- kinds: food, soup, guk
- ingredients: dog meat
- has Wikipedia article: en, zh

## DISH Q6754905
- name: Anginara
- countries: (none)
- kinds: appetizer
- ingredients: zucchini

## DISH Q67577553
- name: Funchi
- other names: {"nl": "Funchi"}
- countries: (none)
- kinds: dish
- ingredients: maize

## DISH Q67587611
- name: Pickled sun-dried tomato
- description: sun-dried tomato in oil
- countries: (none)
- kinds: vegetable, sun-dried tomato, pickle

## DISH Q67589074
- name: Passionfruit jam
- description: marmelade made of passionfruits
- countries: (none)
- kinds: jam, marmalade

## DISH Q67590842
- name: Millerighe
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta

## DISH Q67591158
- name: Tortellini filled with cheese
- description: type of tortellini
- countries: (none)
- kinds: type of pasta, tortellini
- ingredients: ricotta, tortellini, cheese

## DISH Q67597080
- name: Bündner Torte
- countries: CH
- kinds: torte

## DISH Q6763008
- name: Marie Rose sauce
- description: British condiment
- countries: (none)
- kinds: condiment, sauce
- ingredients: tomato, peppercorn, lemon juice, Worcestershire sauce, mayonnaise
- has Wikipedia article: en

## DISH Q6773064
- name: Marry girl cake
- other names: {"zh": "喜饼"}
- description: ceremonial cake used as a wedding gift in traditional Chinese wedding ceremony
- countries: CN
- kinds: pastry, sponge cake
- has Wikipedia article: en, zh

## DISH Q677640
- name: Pecorino
- other names: {"zh": "義大利綿羊乾酪"}
- description: Italian cheese made from sheep's milk
- countries: IT
- cuisines: Italian cuisine
- kinds: sheep milk cheese, Italian cheese, cheese
- ingredients: sheep milk, rennet
- has Wikipedia article: en, zh

## DISH Q67769796
- name: Natillas de Piura
- description: Peruvian candy
- countries: PE
- kinds: confectionery, meal

## DISH Q67771283
- name: Hazelnut brittle
- description: brittle made with hazelnuts
- countries: (none)
- kinds: hazelnut, brittle

## DISH Q67773441
- name: Blossom honey
- description: type of honey
- countries: (none)
- kinds: honey

## DISH Q67777170
- name: Venison goulash
- countries: (none)
- kinds: goulash, venison

## DISH Q6779865
- name: Mary Jane
- description: candy
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q6782232
- name: Mas huni
- description: Maldivian dish
- countries: MV
- kinds: food, tuna dish
- ingredients: Thunnini
- has Wikipedia article: en

## DISH Q6782239
- name: Mas riha
- description: Maldivian dish
- countries: MV
- kinds: tuna dish, fish curry
- ingredients: Thunnini
- has Wikipedia article: en

## DISH Q6782555
- name: Masan
- description: Tibetan pastry made with tsampa, dry cubic or curd cheese, yak butter, brown sugar and water
- countries: (none)
- kinds: food, pastry
- ingredients: tsampa, yak butter
- has Wikipedia article: en

## DISH Q67826473
- name: Chicken donut sandwich
- description: chicken sandwich with donuts serving is the upper and lower buns
- countries: (none)
- kinds: chicken burger

## DISH Q6782752
- name: Masaura
- description: Nepali fermented food
- countries: NP
- kinds: food, fermented food
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q67848749
- name: Sweet potato haupia pie
- description: Hawaiian dessert
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q67864248
- name: Graved salmon
- description: salmon preparation type
- countries: (none)
- kinds: salmon, fish dish

## DISH Q67866507
- name: Görcstészta
- description: Hungarian soup noodles
- countries: HU
- kinds: noodle
- ingredients: onion, paprika, wheat flour, egg as food, lard, table salt, water

## DISH Q67871306
- name: Käsewähe
- description: savory Swiss cheese tart
- countries: (none)
- kinds: wähe
- ingredients: egg as food, cream, cheese

## DISH Q6787315
- name: Mathri
- description: Indian snack
- countries: IN
- kinds: human food, snack
- ingredients: maida flour
- has Wikipedia article: en

## DISH Q67873453
- name: Redcurrant jam
- description: jam made from redcurrants
- countries: (none)
- kinds: fruit jam
- ingredients: redcurrant

## DISH Q67881839
- name: Veal escalope
- description: veal schnitzel
- countries: (none)
- kinds: veal, Wiener schnitzel

## DISH Q6789588
- name: Matta rice
- description: indigenous variety of rice grown in Palakkad district of Kerala, India
- countries: IN
- kinds: rice
- has Wikipedia article: en

## DISH Q6789614
- name: Mattar paneer
- description: Indian cheese and peas dish
- countries: IN
- kinds: dish, paneer, pea
- ingredients: pea, paneer
- has Wikipedia article: en

## DISH Q6794330
- name: Mavželj
- description: meatball wrapped in caul fat and roasted in the oven.
- countries: (none)
- kinds: meatball, pork dish, offal dish
- ingredients: cow's milk, onion, caul fat, offal, bread
- has Wikipedia article: en

## DISH Q6794563
- name: Zarb
- description: Arabic dish
- countries: (none)
- kinds: dish
- ingredients: lamb meat

## DISH Q67956728
- name: Hüdel
- other names: {"de": "Hüdel"}
- countries: (none)
- kinds: sweet dish

## DISH Q6796608
- name: Mae West
- description: Canadian dessert cake
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q6797913
- name: Maypo
- description: brand of instant maple-flavored oatmeal cereal
- countries: US
- kinds: breakfast cereal
- ingredients: oatmeal
- has Wikipedia article: en

## DISH Q67994149
- name: Rolled fillet of ham
- description: fillet of ham
- countries: (none)
- kinds: ham

## DISH Q68005229
- name: Sochen'
- description: lean thin Flatbread
- countries: (none)
- kinds: flatbread, dish
- ingredients: hemp oil, flour, table salt, water

## DISH Q680242
- name: Bhaji
- description: spicy snack
- countries: (none)
- kinds: fritter, appetizer
- ingredients: besan
- has Wikipedia article: en

## DISH Q6803398
- name: سيالات
- other names: {"ar": "سيالات"}
- countries: (none)
- kinds: pastry

## DISH Q6804256
- name: Meat and potato pie
- description: English pie dish
- countries: GB
- kinds: food, pie
- has Wikipedia article: en

## DISH Q6807728
- name: Meeshay
- other names: {"zh": "缅甸米线"}
- description: Noodle dish from Myanmar
- countries: MM
- kinds: salad
- has Wikipedia article: en, zh

## DISH Q6807955
- name: Mefun
- other names: {"zh": "女奮"}
- description: salted salmon kidney
- countries: JP
- kinds: fermented food, seafood dish, shiokara
- ingredients: chum salmon
- has Wikipedia article: en, zh

## DISH Q6809071
- name: Meghli
- description: Levantine rice pudding
- countries: SA, LB, PS
- cuisines: Arab cuisine, Levantine cuisine, Lebanese cuisine, Palestinian cuisine
- kinds: pudding, food
- ingredients: rice, anise seed, caraway seeds, pistachio nut, coconut, rice flour, pine nut, walnut, almond, cinnamon, sugar
- has Wikipedia article: en

## DISH Q68098673
- name: Heringskartoffeln
- other names: {"de": "Heringskartoffeln"}
- countries: DE
- cuisines: German cuisine
- kinds: dish
- ingredients: potato

## DISH Q6810141
- name: Mein gon
- description: type of noodle-shaped cracker
- countries: US
- kinds: food, cracker
- has Wikipedia article: en

## DISH Q681326
- name: Laguiole cheese
- other names: {"zh": "拉约勒奶酪"}
- description: French cheese
- countries: FR
- kinds: raw-milk cheese, pressed uncooked cheese, French cheese, cow's-milk cheese, farmstead cheese, dairy cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q6813732
- name: Melt sandwich
- description: type of cheese sandwich
- countries: US
- kinds: sandwich
- ingredients: bread
- has Wikipedia article: en

## DISH Q681488
- name: Bossche bol
- other names: {"zh": "登波士球"}
- description: food
- countries: (none)
- kinds: pastry
- ingredients: profiterole, couverture chocolate, whipped cream
- has Wikipedia article: en, zh

## DISH Q6815190
- name: Memela
- description: Masa cake in Mexican cuisine
- countries: MX
- kinds: food, pancake
- ingredients: masa
- has Wikipedia article: en

## DISH Q6816534
- name: Menchi-katsu
- other names: {"zh": "炸肉餅"}
- description: Japanese breaded and deep-fried ground meat patty
- countries: JP
- cuisines: yōshoku
- kinds: food, meat dish, katsu
- ingredients: panko, meat
- has Wikipedia article: en, zh

## DISH Q6817673
- name: Menudo
- description: Philippine stew
- countries: PH
- kinds: tomato dish, stew
- has Wikipedia article: en

## DISH Q6817675
- name: Menudo
- other names: {"zh": "墨西哥牛肚湯"}
- description: Mexican soup
- countries: MX
- kinds: beef dish, offal dish, tripe soup
- has Wikipedia article: en, zh

## DISH Q681770
- name: Frankfurter Würstchen
- other names: {"zh": "法蘭克福腸"}
- description: sausage specialty from Frankfurt, Hesse
- countries: DE
- kinds: Brühwurst, German sausage, dish
- ingredients: pork
- has Wikipedia article: en, zh

## DISH Q681841
- name: Leberkäse
- other names: {"zh": "luxurious dining"}
- description: baked loaf of finely minced sausage meat
- countries: CH, AT, DE
- cuisines: Swiss cuisine, Austrian cuisine, German cuisine, Bavarian cuisine
- kinds: dish, forcemeat
- ingredients: pork
- has Wikipedia article: en

## DISH Q68185511
- name: Pickled tomato
- description: normally dried tomatoes pickled in olive oil
- countries: (none)
- kinds: vegetable, antipasto, sun-dried tomato, pickling, preserved food

## DISH Q68186174
- name: Ox eye
- description: pastry in Germany and Switzerland
- countries: CH, DE
- kinds: pastry

## DISH Q68188774
- name: Stuffed olive
- description: olives filled with something
- countries: (none)
- kinds: antipasto, olive

## DISH Q68190380
- name: Smoked trout
- description: fish dish
- countries: (none)
- kinds: smoked fish
- ingredients: trout fillet

## DISH Q68218294
- name: Olives stuffed with pimento
- countries: (none)
- kinds: convenience food, stuffed olive

## DISH Q68221865
- name: Peach jam
- description: jam made from peachs
- countries: (none)
- kinds: fruit jam

## DISH Q68222235
- name: Plum compote
- countries: (none)
- kinds: compote
- ingredients: plum

## DISH Q682384
- name: Galbi
- other names: {"zh": "韓式烤牛肋骨"}
- description: grilled beef or pork ribs in Korean cuisine
- countries: (none)
- kinds: pork dish, beef dish
- ingredients: cattle
- has Wikipedia article: en, zh

## DISH Q6826082
- name: Mexican pizza
- countries: MX
- kinds: dish
- has Wikipedia article: en

## DISH Q6827067
- name: Mi krop
- description: Thai dish
- countries: TH
- cuisines: Thai cuisine
- kinds: dish
- ingredients: rice vermicelli
- has Wikipedia article: en

## DISH Q6827079
- name: Mi san dao
- other names: {"zh": "蜜三刀"}
- description: fried cake glazed in malt sugar
- countries: CN
- kinds: pastry
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q6827082
- name: Mi zhi hu lu
- description: traditional dish in Beijing cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q68273992
- name: Smoked eel
- countries: (none)
- kinds: smoked fish, eel as food
- ingredients: eel as food

## DISH Q6827710
- name: Mianwo
- other names: {"zh": "麵窩"}
- description: Chinese donut
- countries: CN
- cuisines: Hubei cuisine, Chinese cuisine
- kinds: rice dish, dish, merienda
- ingredients: Sesamum indicum, ginger, Welsh onion, soybean, rice
- has Wikipedia article: en, zh

## DISH Q68288966
- name: Braised beef
- description: cut of meat
- countries: (none)
- kinds: meat dish, cut of beef

## DISH Q683080
- name: Fischbrötchen
- description: food: bread & fish
- countries: DE
- kinds: sandwich, fish dish, food
- ingredients: onion, pickle, remoulade, bread, fish, fish as food, bread roll
- has Wikipedia article: en

## DISH Q683425
- name: Vermicelles
- description: Swiss dessert of riced chestnut puree
- countries: CH
- cuisines: Swiss cuisine
- kinds: dessert
- ingredients: chestnut puree

## DISH Q68355161
- name: Goat liver
- description: liver of a goat
- countries: (none)
- kinds: goat meat, liver as food

## DISH Q6837841
- name: Michigan salad
- other names: {"zh": "密西根沙律"}
- description: variety of green salad
- countries: US
- kinds: salad
- has Wikipedia article: en

## DISH Q6839312
- name: كفتة البوسنة
- other names: {"ar": "كفتة البوسنة"}
- countries: (none)
- kinds: meat dish

## DISH Q6842216
- name: Midget Gems
- description: English sweets
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q68431905
- name: Roulades meat
- description: meat to prepare roulade dish
- countries: (none)
- kinds: cut of beef, roulade

## DISH Q6843519
- name: Mie kering
- description: Indonesian type of noodle
- countries: ID
- kinds: culinary speciality
- has Wikipedia article: en

## DISH Q68467213
- name: Sucking pork haunch
- description: leg of a suckling pork
- countries: (none)
- kinds: suckling pig

## DISH Q68487716
- name: Beef goulash
- description: cut of beef
- countries: (none)
- kinds: goulash, cut of beef

## DISH Q68493141
- name: Spring roll pastry
- countries: (none)
- kinds: dough, pastry

## DISH Q68493668
- name: Wholemeal pasta
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta

## DISH Q68493943
- name: Juniper wood smoked bacon
- description: type of ham
- countries: (none)
- kinds: smoked ham

## DISH Q68495119
- name: Smoked chicken
- other names: {"zh": "熏鸡"}
- countries: (none)
- kinds: smoked meat, chicken dish

## DISH Q68495399
- name: Smoked halibut
- description: smoked fish
- countries: (none)
- kinds: smoked fish, halibut

## DISH Q68497532
- name: Mango ice cream
- description: fruit ice cream
- countries: (none)
- kinds: ice cream, sorbetes, mango
- has Wikipedia article: en

## DISH Q68530595
- name: Chicken-fried chicken
- description: dish
- countries: US
- kinds: dish
- ingredients: fried chicken, gravy

## DISH Q6853367
- name: Padaek
- description: traditional Lao condiment made from pickled or fermented fish that has been cured
- countries: LA
- kinds: fish sauce
- has Wikipedia article: en

## DISH Q685352
- name: Tteokguk
- other names: {"zh": "韓式打糕湯"}
- description: food
- countries: (none)
- kinds: food, soup, guk
- ingredients: tteok
- has Wikipedia article: en, zh

## DISH Q6855605
- name: Quince jam
- description: jam made from quinces
- countries: (none)
- kinds: fruit jam
- ingredients: quince

## DISH Q685680
- name: Grünkohlessen
- description: curly kale-based food
- countries: (none)
- kinds: food, dish
- ingredients: kale
- has Wikipedia article: en

## DISH Q68594050
- name: Turkish mantı
- description: food from Turkish cuisine
- countries: TR
- kinds: food, manti, stuffed pasta

## DISH Q6859846
- name: Millionbøf
- description: Danish beef dish
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q68631373
- name: Nộm hoa chuối
- description: Vietnamise salad
- countries: VN
- kinds: dish, salad

## DISH Q6863335
- name: Minchee
- other names: {"zh": "免治"}
- description: Macanese dish
- countries: CN
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q686427
- name: Schäufele
- description: traditional German dish
- countries: (none)
- kinds: pork dish
- ingredients: Kartoffelklösse, pork shoulder, scapula
- has Wikipedia article: en

## DISH Q6868659
- name: Mombar
- description: Human food
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q6869576
- name: Mint chocolate chip
- description: ice cream flavor composed of mint-flavored ice cream with small chocolate chips
- countries: (none)
- kinds: ice cream
- ingredients: mint
- has Wikipedia article: en

## DISH Q68704387
- name: Mandelfisch
- description: Swiss almond-filled shortcrust pastry in the shape of a fish
- countries: CH
- kinds: pastry

## DISH Q6874747
- name: Miruhulee boava
- description: Maldivian delicacy
- countries: MV
- kinds: food, octopus dish
- ingredients: Octopoda
- has Wikipedia article: en

## DISH Q687579
- name: Tête de Moine
- description: Swiss cheese
- countries: CH, FR
- kinds: food, French cheese, farmstead cheese, pressed half-cooked cheese, dairy cheese, Swiss cheeses
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q6880780
- name: Mitarashi dango
- other names: {"zh": "御手洗团子"}
- description: shouyu (soy sauce) dango
- countries: JP
- kinds: dango, skewer
- has Wikipedia article: en, zh

## DISH Q6881572
- name: Mishti doi
- description: Dessert of Bengal
- countries: (none)
- kinds: yogurt, confectionery
- ingredients: milk
- has Wikipedia article: en

## DISH Q6882841
- name: Šakotis
- other names: {"zh": "樹蛋糕"}
- description: traditional Polish-Lithuanian cake
- countries: PL, BY, LT
- cuisines: Polish cuisine, Belarusian cuisine, Lithuanian cuisine
- kinds: spit cake
- ingredients: egg as food, flour
- has Wikipedia article: en, zh

## DISH Q6883975
- name: Mixed grill
- description: meal with grilled meats
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q6887866
- name: Cow's feet soup
- description: hearty broth made from cow's feet, served as a snack or meal
- countries: BR
- kinds: food, beef dish
- has Wikipedia article: en

## DISH Q68935801
- name: Schnippelsuppe
- other names: {"de": "Schnippelsuppe"}
- countries: (none)
- kinds: soup

## DISH Q689416
- name: Basler Läckerli
- description: hard spice biscuit originating from Basel, Switzerland
- countries: CH
- cuisines: Swiss cuisine
- kinds: pastry, biscuit
- ingredients: candied fruit, flour, nut, honey
- has Wikipedia article: en

## DISH Q6894609
- name: Moin moin
- description: traditional Nigerian food
- countries: NG
- cuisines: Nigerian cuisine
- kinds: snack, savory pudding
- ingredients: vegetable oil, onion, black-eyed pea, crayfish, chicken as food, seasoning, palm oil, Capsicum, egg as food, table salt
- has Wikipedia article: en

## DISH Q6899667
- name: Mongolian beef
- other names: {"zh": "蒙古牛肉"}
- description: Taiwanese beef dish
- countries: TW
- kinds: beef dish
- has Wikipedia article: en, zh

## DISH Q6899671
- name: Mongolian barbecue
- other names: {"zh": "蒙古烤肉"}
- description: Taiwanese stir-fried dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: meat dish
- has Wikipedia article: en, zh

## DISH Q689984
- name: Papanași
- other names: {"zh": "帕帕納西"}
- description: Romanian and Moldovan traditional fried or boiled pastry
- countries: RO
- cuisines: Romanian cuisine, Moldovan cuisine
- kinds: pastry, dish
- has Wikipedia article: en, zh

## DISH Q690048
- name: Turtle soup
- other names: {"zh": "綠龜湯"}
- description: soup or stew made from the flesh of the turtle
- countries: CN
- kinds: soup
- ingredients: meat
- has Wikipedia article: en

## DISH Q690165
- name: Scacciata PAT
- other names: {"zh": "Scacciata PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good
- ingredients: bread
- has Wikipedia article: en

## DISH Q690292
- name: Fritter
- other names: {"zh": "油炸什锦"}
- description: fried sweet or savory pastry
- countries: ID
- cuisines: cuisine of the United States, British cuisine, Canadian cuisine
- kinds: pastry, snack, street food, deep-fried food
- ingredients: batter
- has Wikipedia article: en

## DISH Q6903124
- name: Mont di
- description: Burmese dishes with thin-rice noodles
- countries: MM
- kinds: salad
- has Wikipedia article: en

## DISH Q6906362
- name: Montreal hot dog
- description: type of hot dog
- countries: CA
- kinds: hot dog
- has Wikipedia article: en

## DISH Q6907058
- name: Moo goo gai pan
- description: Americanized version of a Cantonese dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q69075939
- name: Cartocciata
- other names: {"it": "cartocciata"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: food

## DISH Q69076334
- name: Paté di sfoglia
- other names: {"it": "paté di sfoglia"}
- countries: (none)
- kinds: dish

## DISH Q69077175
- name: Sfincione di riso
- other names: {"it": "sfincione di riso"}
- countries: IT
- kinds: dessert
- ingredients: zest, sugar, rice

## DISH Q6909182
- name: Aqît
- description: Kurdish food
- countries: (none)
- kinds: dish
