# Review batch names-050

## DISH Q6301925
- name: Jubilee chicken
- description: A chicken based dish, created to celebrate the jubilees of different British monarchs
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q6302328
- name: Judd mat Gaardebounen
- description: Savory dish from Luxembourg
- countries: (none)
- kinds: pork dish
- ingredients: Vicia faba var. major, pig
- has Wikipedia article: en

## DISH Q6304924
- name: Lihapiirakka
- description: Finnish savory pie filled with ground meat and cooked rice
- countries: FI
- kinds: dish, pirozhki, pie
- has Wikipedia article: en

## DISH Q63118359
- name: Frikandelbroodje
- description: Dutch snack consisting of a frikandel in puff pastry
- countries: (none)
- kinds: snack
- ingredients: curry ketchup, frikandel, puff pastry

## DISH Q63172977
- name: Cacen ddu
- description: traditional cake produced in Patagonia
- countries: (none)
- kinds: cake

## DISH Q63255906
- name: Picante surtido
- description: traditional dish in Bolivia
- countries: BO
- kinds: meal, fast food

## DISH Q63256449
- name: Helado de canela
- other names: {"es": "helado de canela"}
- countries: CL
- kinds: ice cream
- ingredients: Opuntia, cinnamon, sugar

## DISH Q632850
- name: Caldero
- countries: ES
- cuisines: cuisine of the Region of Murcia
- kinds: rice dish

## DISH Q63347864
- name: Anchovy sauce
- countries: (none)
- kinds: fish sauce
- ingredients: anchovy

## DISH Q633615
- name: Calamari sandwich
- other names: {"zh": "魷魚三文治"}
- description: sandwich with a filling of fried squid rings, popular in Madrid, Spain
- countries: ES
- kinds: sandwich, squid as food
- has Wikipedia article: en

## DISH Q63368126
- name: 롤로
- other names: {"ko": "롤로"}
- countries: (none)
- kinds: fast food

## DISH Q6343342
- name: Kaalan
- description: kerala dish
- countries: (none)
- kinds: curry, side dish
- ingredients: coconut, yogurt
- has Wikipedia article: en

## DISH Q6343722
- name: Kabab torsh
- description: traditional kebab from northern cities of Iran, consisting of meat marinated in walnuts, pomegranate, parsley, olive oil, and garlic, cooked on skewers over charcoal
- countries: IR
- cuisines: Iranian cuisine
- kinds: beef dish, kebab
- has Wikipedia article: en

## DISH Q63439786
- name: Frittata di luvertin
- description: Hop omelette from northern Italy
- countries: (none)
- kinds: egg dish

## DISH Q63442854
- name: Sinantolan
- description: Filipino dish
- countries: PH
- kinds: food, dish
- ingredients: Santol
- has Wikipedia article: en

## DISH Q6344459
- name: Kabuli pulaw
- other names: {"zh": "喀布爾抓飯"}
- description: Afghan dish
- countries: AF
- cuisines: Afghan cuisine
- kinds: recipe, rice dish
- ingredients: lamb meat, raisin, rice, carrot
- has Wikipedia article: en, zh

## DISH Q6344478
- name: Kabuni
- description: Albanian dessert, consists of cooked rice with raisins and meat stock
- countries: AL
- cuisines: Albanian cuisine
- kinds: food, dessert
- ingredients: rice
- has Wikipedia article: en

## DISH Q6345286
- name: Kadboli
- description: Indian snack
- countries: IN
- kinds: snack, food
- ingredients: flour
- has Wikipedia article: en

## DISH Q63453010
- name: Chorizo de Bilbao
- description: type of Philippine pork and beef dry sausage
- countries: PH
- kinds: sausage
- ingredients: pork
- has Wikipedia article: en

## DISH Q6345457
- name: Kadhi
- description: dish originating from the Indian subcontinent
- countries: IN
- kinds: food, soup
- ingredients: besan, yogurt
- has Wikipedia article: en

## DISH Q6345991
- name: Kaeng khae
- other names: {"zh": "假蒟咖喱"}
- description: northern Thai curry, made of Piper sarmentosum, Lao coriander, cha-om, Acmella oleracea leaves, the dry cores of the Bombax ceiba flower, Sesbania grandiflora flowers, ivy gourds, eggplants, bamboo shoots, pea eggplants, fresh chilies, and mushrooms
- countries: TH
- kinds: Thai curry
- has Wikipedia article: en, zh

## DISH Q6345995
- name: Kaeng pa
- other names: {"zh": "丛林咖喱"}
- description: spicy and watery curry variety from the forested areas of Thailand; lacks coconut milk; includes kaffir lime peel and leaves, lemongrass, green peppercorn, galangal, garlic, pea eggplant, and chili
- countries: TH
- kinds: Thai curry
- has Wikipedia article: en, zh

## DISH Q6345997
- name: Kaeng som
- other names: {"zh": "酸咖喱"}
- description: sour and spicy fish curry with vegetables popular in central Thailand
- countries: TH
- kinds: Thai curry, seafood dish, fish dish
- ingredients: curry paste, Tamarindus indica
- has Wikipedia article: en, zh

## DISH Q634703
- name: Bollit de pilotes
- other names: {"ca": "Bollit de pilotes"}
- countries: (none)
- kinds: dish, guiso

## DISH Q6348264
- name: Kairi ka do pyaza
- description: Lamb dish from India
- countries: IN
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q6349050
- name: Kaju katli
- description: Indian dessert similar to a barfi
- countries: IN
- kinds: dessert
- ingredients: Cashew
- has Wikipedia article: en

## DISH Q6349052
- name: Kaju barfi
- description: Indian sweet
- countries: IN
- kinds: food, barfi
- ingredients: Cashew, sugar, milk
- has Wikipedia article: en

## DISH Q6349317
- name: Kakavia
- description: fish group from Greece
- countries: CY
- cuisines: Greek cuisine
- kinds: soup, fish dish
- has Wikipedia article: en

## DISH Q6351599
- name: Kalathappam
- description: Indian dessert
- countries: IN
- kinds: type of food or dish, dessert
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q63522006
- name: Pane parruozzo
- other names: {"it": "pane parruozzo"}
- countries: IT
- kinds: dish, bread

## DISH Q63522014
- name: Cuddhura
- other names: {"it": "Cuddhura"}
- countries: IT
- kinds: dessert

## DISH Q63522799
- name: Crescente (gastronomia)
- other names: {"it": "Crescente (gastronomia)"}
- countries: (none)
- kinds: focaccia

## DISH Q63524591
- name: Burrata di Andria
- description: Italian cheese
- countries: IT
- kinds: cheese, cow's-milk cheese, burrata

## DISH Q63524838
- name: Kategna
- description: specialty of Eritrean and Ethiopian cuisine
- countries: ER, ET
- kinds: appetizer
- ingredients: injera

## DISH Q63525671
- name: Colombe pasquali PAT
- other names: {"zh": "Colombe pasquali PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: dessert, baked good

## DISH Q63525686
- name: Cuddrireddra PAT
- other names: {"zh": "Cuddrireddra PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, dessert, baked good

## DISH Q63525694
- name: Cuddura di San Paulu
- other names: {"it": "Cuddura di San Paulu"}
- countries: IT
- kinds: bread

## DISH Q635999
- name: Compote
- other names: {"zh": "糖煮水果"}
- description: dessert of fruit cooked in syrup
- countries: (none)
- kinds: dessert
- ingredients: syrup, fruit
- has Wikipedia article: en, zh

## DISH Q636242
- name: Schwarzsauer
- other names: {"zh": "德國血湯"}
- description: German dish of blood with various spices cooked in vinegar water
- countries: (none)
- kinds: meat dish, blood soup
- ingredients: blood as food, vinegar
- has Wikipedia article: en

## DISH Q63626
- name: Deche
- other names: {"es": "Deche"}
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q6363439
- name: Kanjika
- description: Indian subcontinental dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q6367928
- name: Karah Parshad
- description: Prasad in Gurudwara
- countries: (none)
- kinds: halva, Prasad
- ingredients: whole-wheat flour, ghee, sugar
- has Wikipedia article: en

## DISH Q6374193
- name: Kasha varnishkes
- description: traditional Ashkenazi Jewish dish
- countries: (none)
- kinds: dish
- ingredients: buckwheat porridge, onion, schmaltz, farfalle
- has Wikipedia article: en

## DISH Q637463
- name: Frozen custard
- other names: {"zh": "冷冻奶油冻"}
- description: cold dessert
- countries: (none)
- kinds: ice cream, custard
- ingredients: egg as food, milk
- has Wikipedia article: en

## DISH Q6374730
- name: Kasseropita
- description: Greek pie made from phyllo and kasseri cheese
- countries: GR
- kinds: food, pie
- ingredients: phyllo, kasseri
- has Wikipedia article: en

## DISH Q6374981
- name: Kata-kat
- description: Pakistani meat dish
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q6377352
- name: Kati roll
- description: street-food dish originating from Kolkata, West Bengal
- countries: IN
- kinds: food, dish
- has Wikipedia article: en

## DISH Q6378612
- name: Katův šleh
- description: traditional Czech dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q6379127
- name: Tirit
- description: broth and bread dish from the Turkish cuisine
- countries: (none)
- kinds: dish, food
- ingredients: sheep
- has Wikipedia article: en

## DISH Q6382374
- name: Kebakko
- description: Finnish meat dish
- countries: FI
- kinds: meat dish
- has Wikipedia article: en

## DISH Q6383611
- name: Keihan rice
- other names: {"zh": "琉球雞飯"}
- description: amami dish
- countries: JP
- kinds: Japanese rice dish, chicken dish
- has Wikipedia article: en, zh

## DISH Q6384329
- name: Chantilly cream
- description: sweet whipped cream
- countries: FR
- kinds: food ingredient, dairy product, culinary foam, dessert with spoon
- ingredients: whipped cream, powdered sugar
- has Wikipedia article: en

## DISH Q6385328
- name: Kek Lapis Sarawak
- other names: {"zh": "砂拉越千层糕"}
- description: type of layer cake
- countries: MY
- kinds: layer cake
- ingredients: butter
- has Wikipedia article: en, zh

## DISH Q6385448
- name: Kelaguen
- other names: {"zh": "關島捲餅"}
- description: Chamorro dish from the Northern Mariana Islands
- countries: GU, MP
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q6387099
- name: Kemplang
- description: Indonesian fish cracker snack
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, snack, human food, type of food or dish, fish dish
- ingredients: Acanthocybium solandri
- has Wikipedia article: en

## DISH Q6391336
- name: Kenpi
- description: Japanese Potato chips
- countries: JP
- kinds: snack, wagashi, sweet potato fries, higashi
- ingredients: Sweet potato
- has Wikipedia article: en

## DISH Q6392456
- name: Tabriz köfte
- description: Iranian meatball
- countries: (none)
- kinds: food, kofta
- has Wikipedia article: en

## DISH Q6393299
- name: Kerak telor
- description: Indonesian spicy omelette dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, egg dish
- ingredients: ginger, grated coconut, peppercorn, fried onion, palm sugar, chili, dried shrimp, glutinous rice, egg as food
- has Wikipedia article: en

## DISH Q6394874
- name: Kesaria Peda
- description: Indian sweet dish
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q6395436
- name: Ketoprak
- description: Indonesian vegetarian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, food, salad, street food, jajan pasar
- ingredients: rice cake, mung bean sprout, Indonesian peanut sauces, rice vermicelli, krupuk, soy sauce, tofu
- has Wikipedia article: en

## DISH Q63956134
- name: Tuna tartare
- description: raw tuna dish
- countries: (none)
- kinds: dish, tartare
- ingredients: Thunnus

## DISH Q63974883
- name: Pastitsado
- description: red wine stew with rooster or beef
- countries: (none)
- kinds: stew

## DISH Q63974888
- name: Fish Bianco
- countries: (none)
- kinds: fish dish

## DISH Q63974891
- name: Veal Fricando
- countries: (none)
- kinds: dish

## DISH Q63974895
- name: Zorka
- countries: (none)
- kinds: pie

## DISH Q63974897
- name: Sikomaida
- countries: (none)
- kinds: dessert

## DISH Q6398629
- name: Keşkül
- description: milk and almond pudding from the Turkish cuisine
- countries: TR
- kinds: food, dessert
- ingredients: Prunus dulcis
- has Wikipedia article: en

## DISH Q6398992
- name: Khai yat sai
- description: Thai egg dish
- countries: TH
- kinds: egg dish
- has Wikipedia article: en

## DISH Q63993923
- name: Gaudes
- countries: FR
- kinds: culinary speciality, dish

## DISH Q6400371
- name: Khanom bueang
- description: Thai food
- countries: TH
- kinds: food, flatbread
- ingredients: rice
- has Wikipedia article: en

## DISH Q6400372
- name: Khanom chan
- other names: {"zh": "泰式千層糕"}
- description: ancient Thai dessert
- countries: TH
- kinds: food, dessert, Thai desserts and snacks
- has Wikipedia article: en, zh

## DISH Q6400994
- name: Khauk swè thoke
- description: Burmese dish of wheat noodles, dried shrimp, shredded cabbage, carrots, fish sauce and lime
- countries: MM
- kinds: Burmese salad
- has Wikipedia article: en

## DISH Q6401206
- name: Kheer sagar
- description: Indian cheese dish
- countries: (none)
- kinds: food, confectionery
- ingredients: chhena, milk
- has Wikipedia article: en

## DISH Q6401568
- name: Khichra
- description: variation of the dish Haleem
- countries: IN
- kinds: food, soup
- ingredients: meat
- has Wikipedia article: en

## DISH Q64025364
- name: Ayam geprek
- description: Indonesian chicken dish
- countries: ID
- kinds: fried chicken
- ingredients: garlic, fried chicken, chili pepper, table salt
- has Wikipedia article: en

## DISH Q64027420
- name: Bismarck-Eiche
- other names: {"de": "Bismarck-Eiche"}
- countries: (none)
- kinds: viennoiserie

## DISH Q6403206
- name: Khushka Rice
- description: Rice dish of primarily South Asian origin
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q6403489
- name: Sweet coal
- description: typical Christmas dessert
- countries: ES
- kinds: confectionery, dessert, ame
- has Wikipedia article: en

## DISH Q6404116
- name: Kichadi
- description: Cuisine of Kerala
- countries: IN
- kinds: dish
- ingredients: curd, pumpkin
- has Wikipedia article: en

## DISH Q64043245
- name: Scallion pancakes
- description: scallion-based food
- countries: (none)
- kinds: pancake

## DISH Q6405076
- name: Kidyo
- description: Candy (southwest coast of India)
- countries: IN
- cuisines: Indian cuisine
- kinds: confectionery
- has Wikipedia article: en

## DISH Q6406382
- name: Lentil rice
- description: Azerbaijani food
- countries: AZ, IR
- kinds: human food, food
- has Wikipedia article: en

## DISH Q64065384
- name: Calf liver
- description: liver of cattle calfs commonly eaten as food by humans
- countries: (none)
- kinds: dish, food ingredient, offal, veal, liver as food

## DISH Q6406630
- name: Castañas con leche
- other names: {"es": "Castañas con leche"}
- countries: (none)
- cuisines: Galician cuisine
- kinds: dish
- ingredients: chestnut, milk

## DISH Q64068239
- name: Ritter Sport Fine Milk Chocolate
- description: Product of Ritter Sport
- countries: (none)
- kinds: Ritter Sport
- ingredients: cocoa

## DISH Q6407655
- name: Killie pie
- description: a steak and gravy pie
- countries: (none)
- kinds: food, pie
- has Wikipedia article: en

## DISH Q640769
- name: Jiaozi
- other names: {"zh": "饺子"}
- description: Chinese dumplings
- countries: CN
- cuisines: Chinese cuisine
- kinds: cuisine, dumpling, stuffed pasta
- ingredients: flour, meat
- has Wikipedia article: en, zh

## DISH Q640839
- name: Pouligny-saint-pierre
- description: French goat cheese
- countries: FR
- kinds: French cheese, goat cheese, farmstead cheese, industrial cheese, natural-rind soft cheese, dairy cheese
- ingredients: milk, goat milk
- has Wikipedia article: en

## DISH Q6410637
- name: Chongos zamoranos
- description: Dessert of Mexican cuisine made of curdled milk
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q6411978
- name: King Ranch Chicken
- description: A Tex-Mex dish similar to lasagna
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q6411995
- name: King Rib
- description: British minced pork patty
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q6413862
- name: Kinilnat
- description: salad
- countries: PH
- kinds: salad
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q64149140
- name: Ube ice cream
- other names: {"zh": "參薯冰淇淋"}
- description: Filipino ice cream made with purple yam
- countries: PH
- kinds: food, ice cream
- ingredients: Dioscorea alata
- has Wikipedia article: en

## DISH Q64149261
- name: Ube cake
- other names: {"zh": "參薯蛋糕"}
- description: traditional Filipino chiffon cake or sponge cake
- countries: PH
- kinds: food, chiffon cake
- ingredients: ube halaya
- has Wikipedia article: en, zh

## DISH Q64166152
- name: Bison burger
- description: hamburger made with bison
- countries: (none)
- kinds: type of food or dish, fast food, dish, burger, meat sandwich
- ingredients: bison meat

## DISH Q64166194
- name: Fried chicken wings
- description: deep fried chicken wings
- countries: (none)
- kinds: fried chicken, chicken dish
- ingredients: chicken wing

## DISH Q6416946
- name: Baghali polo
- description: Iranian rice dish
- countries: IR
- kinds: pilaf
- has Wikipedia article: en

## DISH Q6418060
- name: Kitchener bun
- description: sweet pastry made and sold in South Australia since 1915
- countries: AU
- kinds: dessert, pastry
- has Wikipedia article: en

## DISH Q641945
- name: Myma
- description: Ancient Greek meat dish
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q6419571
- name: Kladdkaka
- other names: {"zh": "瑞典巧克力蛋糕"}
- description: chocolate mud cake eaten in Sweden and Finland
- countries: SE
- kinds: chocolate cake
- ingredients: chicken egg, wheat flour, cocoa powder, butter, sugar
- has Wikipedia article: en, zh

## DISH Q6420111
- name: Kleicha
- other names: {"zh": "伊拉克曲奇餅"}
- description: middle Eastern cookie
- countries: (none)
- kinds: confectionery
- ingredients: cardamom
- has Wikipedia article: en

## DISH Q64216206
- name: Nasi goreng Jawa
- description: Javanese fried rice
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q6423078
- name: Milmyeon
- other names: {"zh": "小麥麵"}
- description: South Korean noodle dish
- countries: KR
- cuisines: South Korean cuisine
- kinds: naengmyeon
- ingredients: noodle
- has Wikipedia article: en, zh

## DISH Q6425739
- name: Şiş köfte
- other names: {"zh": "中東羊肉卡巴"}
- description: Kofte meatballs grilled on a skewer
- countries: (none)
- kinds: Köftes in the Turkish cuisine
- has Wikipedia article: en

## DISH Q6426645
- name: Achappam
- other names: {"zh": "蜂窩餅"}
- description: deep fried cookie made with rice flour
- countries: IN, LK
- kinds: food, cookie, dish
- ingredients: rice flour, coconut milk, egg as food
- has Wikipedia article: en, zh

## DISH Q6426801
- name: Kokoro
- description: Nigerian snack food
- countries: NG
- kinds: snack
- ingredients: cassava root, ginger, amala, peanut oil, maize, table salt, sugar
- has Wikipedia article: en

## DISH Q6427787
- name: Koloocheh
- description: Persian cookie
- countries: IR
- kinds: food, cookie, pastry
- has Wikipedia article: en

## DISH Q6427832
- name: Kolot
- description: Type of bread roll from Turkey
- countries: TR
- kinds: baked good, bread roll
- ingredients: cooking oil, flour, sodium chloride
- has Wikipedia article: en

## DISH Q6428248
- name: Kombdi vade
- description: konkani meal
- countries: IN
- kinds: food, Indian curry
- ingredients: chicken curry, Vada
- has Wikipedia article: en

## DISH Q6429813
- name: Konro Soup
- description: beef ribs soup dish from Makasar
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, Indonesian cuisine, human food, type of food or dish, soup
- ingredients: Indonesian bay leaf, buah keluak, Aleurites moluccanus, Citrus hystrix, Alpinia galanga, Allium ascalonicum, Tamarindus indica, Cymbopogon citratus, Allium sativum, table salt
- has Wikipedia article: en

## DISH Q6432035
- name: Korean taco
- other names: {"zh": "韓式墨西哥夾餅"}
- description: Korean-Mexican fusion disk
- countries: MX
- kinds: taco
- has Wikipedia article: en, zh

## DISH Q643225
- name: Rempeyek
- other names: {"zh": "花生脆餅"}
- description: Javanese savoury cracker
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, krupuk, fried food
- ingredients: rice flour, shallot, peanut, coconut milk, egg as food, table salt, sugar, Kaffir Lime Leaf, garlic, coriander seed
- has Wikipedia article: en

## DISH Q6432257
- name: Kori Rotti
- description: Mangalorean dish of chicken (Kori in Tulu) curry with rice flakes called rutti
- countries: IN
- kinds: human food, chicken dish
- has Wikipedia article: en

## DISH Q6432978
- name: Kosambari
- description: Seasoned split pulses salad
- countries: IN
- kinds: South Indian cuisine, salad
- ingredients: cereal legume
- has Wikipedia article: en

## DISH Q6434112
- name: Kotlet schabowy
- other names: {"zh": "波蘭炸豬排"}
- description: Polish variety of pork breaded cutlet
- countries: PL
- cuisines: Polish cuisine
- kinds: dish, food, breaded cutlet, pork dish
- ingredients: pork loin, bread crumbs, egg as food, lard, black pepper, flour, table salt
- has Wikipedia article: en

## DISH Q64343255
- name: Tiler Naru
- description: Bengali sweet
- countries: (none)
- kinds: confectionery, laddu
- ingredients: Sesamum indicum, jaggery

## DISH Q64343260
- name: Sarbhaja
- description: a sweet of Bengal
- countries: IN, BD
- cuisines: Bengali cuisine
- kinds: confectionery
- ingredients: cardamom, vegetable oil, maida flour, sugar, water
- has Wikipedia article: en

## DISH Q64343274
- name: White bonde of Kamarpukur
- countries: (none)
- kinds: confectionery

## DISH Q64343301
- name: Telebhaja
- description: Bengali snacks
- countries: (none)
- kinds: fast food, human food
- ingredients: vegetable oil, onion, table salt, potato

## DISH Q64348067
- name: Math
- description: sweet of Bengal
- countries: (none)
- kinds: confectionery

## DISH Q64348073
- name: Murki
- countries: (none)
- kinds: confectionery, laddu

## DISH Q64358326
- name: Beef and broccoli
- description: Chinese-American dish
- countries: US
- cuisines: American Chinese cuisine
- kinds: dish
- ingredients: broccoli, beef
- has Wikipedia article: en

## DISH Q643633
- name: Rosquilla
- description: Spanish sweet
- countries: (none)
- kinds: bread, biscuit, meal
- has Wikipedia article: en

## DISH Q64364273
- name: Fen hao zi
- other names: {"zh": "粉耗子"}
- countries: CN
- kinds: cellophane noodles
- ingredients: potato starch

## DISH Q6436687
- name: Krembanan
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q6436724
- name: Cremeschnitte
- description: layer cake
- countries: (none)
- kinds: mille-feuille
- has Wikipedia article: en

## DISH Q6436743
- name: Napoleonka
- other names: {"zh": "拿破仑卡"}
- description: cream pastry from Poland
- countries: PL
- kinds: cream pie
- ingredients: Cream, whipped cream, puff pastry
- has Wikipedia article: en

## DISH Q64392032
- name: Malakoff-Tuatn
- other names: {"bar": "Malakoff-Tuatn"}
- countries: AT
- kinds: torte

## DISH Q643995
- name: Skirt steak
- other names: {"zh": "skirt steak"}
- countries: (none)
- kinds: Plate steak
- has Wikipedia article: en

## DISH Q6441202
- name: Kubdari
- description: Georgian dish
- countries: GE
- cuisines: Georgian cuisine
- kinds: cake, food, bread
- ingredients: spice, flour, table salt, meat, water
- has Wikipedia article: en

## DISH Q6441843
- name: Kue cubit
- description: Indonesian snack
- countries: ID
- kinds: street food, kue
- ingredients: sodium bicarbonate, egg as food, flour, butter, baking powder, vanilla, table salt, sugar, milk
- has Wikipedia article: en

## DISH Q6441849
- name: Putu piring
- other names: {"zh": "嘟嘟糕"}
- description: Traditional Singaporean snack made from rice flour and stuffed with sweet fillings
- countries: SG
- kinds: dessert, kue, Kue putu
- ingredients: coconut
- has Wikipedia article: en, zh

## DISH Q64463218
- name: Saucisson chaud
- countries: FR
- kinds: dish, culinary speciality

## DISH Q644776
- name: Neapolitan ice cream
- other names: {"zh": "那不勒斯冰淇淋"}
- description: an ice cream composed of three separate flavors (typically vanilla, chocolate, and strawberry) arranged side by side in the same container, usually without any barrier between them
- countries: DE, IT
- kinds: ice cream
- ingredients: strawberry ice cream, vanilla ice cream, chocolate ice cream
- has Wikipedia article: en, zh

## DISH Q64490692
- name: Abunuabunu
- description: Ghanaian soup of the people from the Brong Ahafo Region
- countries: GH
- kinds: soup
- has Wikipedia article: en

## DISH Q6449309
- name: Kuzumochi
- description: Japanese dish
- countries: JP
- kinds: mochi, wagashi
- ingredients: kuromitsu, kinako, kudzu powder, sugar
- has Wikipedia article: en

## DISH Q64504666
- name: Gari and beans
- description: Staple food in Ghana
- countries: GH
- kinds: food

## DISH Q6453677
- name: Peach castella
- countries: (none)
- kinds: castella

## DISH Q6454033
- name: Köttsoppa
- description: meat and vegetable soup
- countries: (none)
- kinds: meat soup
- has Wikipedia article: en

## DISH Q64555345
- name: Parihuela
- countries: PE
- kinds: meal, fish soup

## DISH Q6457441
- name: Yahni
- description: broth or stew
- countries: TR
- kinds: dish
- has Wikipedia article: en

## DISH Q64594571
- name: Bola de oro
- other names: {"es": "bola de oro"}
- countries: PE
- kinds: meal, dessert

## DISH Q646003
- name: Pain aux raisins
- description: French pastry
- countries: FR
- kinds: type of food or dish, food, viennoiserie, Schnecken
- ingredients: pastry cream, baker's yeast, hazelnut, almond, egg as food, flour, butter, raisin, sugar, milk, water
- has Wikipedia article: en

## DISH Q64613472
- name: Kojak
- other names: {"ca": "Kojak"}
- description: lollipop from Hungary
- countries: (none)
- kinds: confectionery, lollipop
- ingredients: chocolate

## DISH Q646237
- name: Kommissbrot
- other names: {"zh": "黑方包"}
- description: food
- countries: DE
- kinds: food product, bread
- ingredients: rye, sourdough
- has Wikipedia article: en

## DISH Q64624850
- name: Canned soup
- countries: (none)
- kinds: soup, canned food

## DISH Q6466556
- name: Laal maans
- description: ethnic food of Rajasthan
- countries: IN
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q6466629
- name: Komaj sehen
- description: Iranian pastry
- countries: IR
- kinds: pastry
- has Wikipedia article: en

## DISH Q64667651
- name: Lasary
- description: type of Madagascan salad
- countries: MG
- kinds: food
- has Wikipedia article: en

## DISH Q6469786
- name: Ladob
- description: Seychelles dish
- countries: SC
- kinds: dish, food
- ingredients: sugar, sweet potato, cow's milk, cooking banana
- has Wikipedia article: en

## DISH Q6469877
- name: Hanımgöbeği
- description: Turkish cuisine dessert
- countries: TR
- kinds: food, dessert
- has Wikipedia article: en

## DISH Q64700257
- name: Leche rizada
- description: Ice-cream-like snack or dessert without egg
- countries: (none)
- kinds: dairy product, frozen dessert
- ingredients: cinnamon, sugar, milk

## DISH Q6470962
- name: Vlašić cheese
- countries: BA
- kinds: cheese
- has Wikipedia article: en

## DISH Q6471877
- name: Lagane e cicciari
- description: Italian pasta dish
- countries: IT
- kinds: pasta dish
- ingredients: pappardelle
- has Wikipedia article: en

## DISH Q6473288
- name: Lahndi
- description: Pashtun dried meat dish
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q6473713
- name: Lai fun
- other names: {"zh": "酹粉"}
- description: variety of Chinese noodles
- countries: CN
- kinds: food, Chinese noodles
- has Wikipedia article: en, zh

## DISH Q64743077
- name: Gari foto
- description: locally made food from Ghana and Benin
- countries: BJ, GH
- kinds: food
- ingredients: garri

## DISH Q64760509
- name: Bittersweet chocolate
- countries: (none)
- kinds: chocolate

## DISH Q6478911
- name: Lakerda
- other names: {"zh": "鹽漬齒鰆"}
- description: Turkish style salted fish (bonito)
- countries: TR
- kinds: article, meze
- ingredients: fish as food
- has Wikipedia article: en, zh

## DISH Q6481050
- name: Lamb fries
- other names: {"zh": "羊睪丸"}
- description: lamb testicles used as food
- countries: (none)
- kinds: testicle as food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en, zh

## DISH Q64831532
- name: Tsupukka
- description: pie dish originating from Karelia
- countries: FI, RU
- kinds: pie
- ingredients: smetana, porridge, flour, butter

## DISH Q64832758
- name: Pancit buko
- description: Filipino dish
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q64864188
- name: Sagu
- description: Brazilian dessert made with tapioca pearls
- countries: (none)
- kinds: dessert
- ingredients: tapioca ball, sugar, red wine
- has Wikipedia article: en

## DISH Q6487583
- name: Lanterne
- description: type of pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q648822
- name: Zunda
- other names: {"zh": "毛豆泥"}
- description: Japanese sweet bean paste
- countries: JP
- kinds: sweet bean paste
- ingredients: edamame
- has Wikipedia article: zh

## DISH Q649043
- name: Shoestring potatoes
- description: potato dish
- countries: (none)
- kinds: fries, potato dish

## DISH Q6493
- name: Labskaus
- description: culinary specialty from Northern Germany and Scandinavia
- countries: DE, NO, DK
- cuisines: German cuisine, Norwegian cuisine, Danish cuisine
- kinds: dish, beef dish
- has Wikipedia article: en

## DISH Q649535
- name: Solomon Gundy
- description: Jamaican pickled fish pâté
- countries: JM
- kinds: food, pâté
- ingredients: smoked fish
- has Wikipedia article: en

## DISH Q6497093
- name: Lattice
- description: pattern of pastry
- countries: (none)
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q6497852
- name: Wiener schnitzel
- other names: {"zh": "维也纳炸牛排"}
- description: breaded veal schnitzel
- countries: AT
- kinds: veal dish, schnitzel
- ingredients: veal, bread crumbs, egg as food
- has Wikipedia article: en, zh

## DISH Q64989889
- name: Coconut burger
- description: Filipino veggie burger
- countries: PH
- kinds: veggie burger
- has Wikipedia article: en

## DISH Q6499081
- name: Spettekaka
- description: cone-shaped cake mostly associated with the southernmost region of Sweden, Scania
- countries: SE
- kinds: spit cake, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q6499669
- name: Cabbage roll
- other names: {"zh": "白菜卷"}
- description: half-meat dish of cabbage leaves with a filling  from Central and Eastern Europe
- countries: FR, RU, CH, SE, FI, AT, DE, IL, IT, HU, RO, BG, AR, TR, AM, GR, PL, CZ, SK, EE, MA, LV, GE, RS, MK, AL, MT, IR, EG, UA, MD, HR, BY, AZ, IQ, SY, SD, LT
- cuisines: French cuisine, Russian cuisine, Swiss cuisine, Swedish cuisine, Finnish cuisine, Austrian cuisine, German cuisine, Israeli cuisine, Italian cuisine, Hungarian cuisine, Romanian cuisine, Bulgarian cuisine, Argentine cuisine, Turkish cuisine, Armenian cuisine, Greek cuisine, Polish cuisine, Czech cuisine, Slovak cuisine, Estonian cuisine, Moroccan cuisine, Latvian cuisine, Georgian cuisine, Serbian cuisine, Macedonian cuisine, Albanian cuisine, Maltese cuisine, Iranian cuisine, Egyptian cuisine, Ukrainian cuisine, Moldovan cuisine, Croatian cuisine, Belarusian cuisine, Azerbaijani cuisine, Kurdish cuisine, Sudanese cuisine, Lithuanian cuisine, Bukharan Jewish cuisine
- kinds: dish, stuffed vegetable
- ingredients: minced meat, edible mushroom, Brassica oleracea var. capitata, onion, vegetable, meat, rice
- has Wikipedia article: en, zh

## DISH Q6501598
- name: Sirloin steak
- other names: {"zh": "沙朗牛排"}
- description: beef steak cut from the loin
- countries: (none)
- kinds: meat, cut of beef, beefsteak
- has Wikipedia article: en, zh

## DISH Q6501890
- name: Casserole
- other names: {"zh": "法国砂锅"}
- description: type of food
- countries: (none)
- kinds: dish, Pizzas, casseroles, type of food or dish
- has Wikipedia article: en, zh

## DISH Q6503900
- name: Okoshimono
- countries: (none)
- kinds: wagashi

## DISH Q65041957
- name: Aloor Chop
- description: snack originating from the Indian subcontinent
- countries: (none)
- kinds: fried food, potato dish
- has Wikipedia article: en

## DISH Q65043034
- name: Sinigapuna
- description: Filipino rice dish
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q65043042
- name: Tinapayan
- description: dish in Filipino cuisine
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q65044268
- name: Gari and beans
- description: Ghanaian food
- countries: GH
- kinds: human food
- has Wikipedia article: en

## DISH Q65044294
- name: Kikomando
- description: Sliced chapati and beans
- countries: UG
- kinds: dish, human food
- ingredients: tomato, cabbage, onion, chapati, bean
- has Wikipedia article: en

## DISH Q65048859
- name: 酱汁肉
- countries: CN
- kinds: dish
- ingredients: pork
- has Wikipedia article: zh

## DISH Q65049504
- name: Poi
- description: traditional Samoan dessert
- countries: WS
- kinds: dessert
- ingredients: coconut milk, banana, mango
- has Wikipedia article: en

## DISH Q65050205
- name: Hausa koko
- description: Ghanaian spicy millet porridge
- countries: (none)
- kinds: porridge
- ingredients: clove, peppercorn, Grains of Selim, millet, spice
- has Wikipedia article: en

## DISH Q65050511
- name: Binakle
- description: type of steamed rice cake
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q65050738
- name: Shuipen yangrou
- other names: {"zh": "水盆羊肉"}
- description: mutton soup in Shaanxi
- countries: (none)
- kinds: soup
- has Wikipedia article: zh

## DISH Q65051168
- name: Piutu
- description: Tausug dessert with mashed cassava
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q65051302
- name: Satang
- other names: {"zh": "糁汤"}
- description: Chinese soup commonly for breakfast at Shandong-Jiangsu-Anhui-Henan intersection
- countries: (none)
- kinds: soup
- has Wikipedia article: zh

## DISH Q65051309
- name: Surou
- other names: {"zh": "酥肉"}
- description: fried pork dish
- countries: (none)
- kinds: fried pork
- has Wikipedia article: en, zh

## DISH Q65051772
- name: Saozimian
- other names: {"zh": "岐山臊子面"}
- description: noodle dish of Shaanxi
- countries: (none)
- kinds: noodle dish
- has Wikipedia article: zh

## DISH Q65052606
- name: Khanom khuai ling
- description: Thai dessert
- countries: TH
- kinds: dessert
- has Wikipedia article: en

## DISH Q65054415
- name: Conveyor belt hot pot
- countries: (none)
- kinds: hot pot
- has Wikipedia article: en

## DISH Q65057632
- name: Hot and spicy cheese bread
- description: cheese bread from Madison, Wisconsin
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q65058271
- name: Jewish rye bread
- description: bread commonly used in Jewish deli sandwiches
- countries: (none)
- kinds: rye bread
- ingredients: rye flour, wheat flour, yeast
- has Wikipedia article: en

## DISH Q65059020
- name: Ginataang ampalaya
- description: Filipino stew made from bitter melon and tinapa
- countries: PH
- kinds: dish
- ingredients: Tinapa, coconut milk, Momordica charantia
- has Wikipedia article: en

## DISH Q65059194
- name: Ginataang munggo
- description: Filipino dessert
- countries: PH
- kinds: dish
- ingredients: coconut milk, Vigna radiata, sugar, rice
- has Wikipedia article: en

## DISH Q65059258
- name: Chicken under a brick
- description: roast chicken dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q65059324
- name: Ginataang isda
- description: Filipino fish stew
- countries: PH
- kinds: dish
- ingredients: garlic, ginger, coconut milk, fish as food
- has Wikipedia article: en

## DISH Q65059348
- name: Ginataang manok
- description: Filipino chicken soup
- countries: PH
- kinds: chicken curry
- has Wikipedia article: en

## DISH Q65059692
- name: Ginataang kuhol
- description: Filipino snail dish
- countries: PH
- kinds: dish
- ingredients: shrimp paste, coconut milk, snail
- has Wikipedia article: en

## DISH Q65060587
- name: Ice buko
- description: Filipino frozen dessert
- countries: PH
- kinds: frozen dessert
- ingredients: condensed milk, coconut water
- has Wikipedia article: en

## DISH Q65060609
- name: Buko salad
- other names: {"zh": "布科色拉"}
- description: Filipino fruit salad dessert
- countries: PH
- kinds: dessert
- ingredients: coconut
- has Wikipedia article: en

## DISH Q65063699
- name: Masa podrida
- description: traditional Filipino shortbread cookies
- countries: PH
- kinds: cookie
- has Wikipedia article: en

## DISH Q65064131
- name: Nilasing na hipon
- description: Filipino shrimp dish
- countries: PH
- kinds: shrimp dish
- has Wikipedia article: en

## DISH Q65064132
- name: Ginataang hipon
- description: Filipino seafood soup that does not use vegetables
- countries: PH
- kinds: dish
- ingredients: shrimp, coconut milk
- has Wikipedia article: en

## DISH Q65064149
- name: Caycay
- description: Visayan cookie popular in Mindanao
- countries: PH
- kinds: snack, cookie
- ingredients: peanut, calamansi, honey
- has Wikipedia article: en

## DISH Q65065239
- name: Ginataang labong
- description: Filipino vegetable stew
- countries: PH
- kinds: dish
- ingredients: bamboo shoots, coconut milk
- has Wikipedia article: en

## DISH Q65066634
- name: Kiampong
- description: Filipino glutinous rice casserole
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q65067382
- name: Erachichor
- description: Kerala cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q65068807
- name: Almond pressed duck
- description: cantonese duck dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q65069699
- name: Khanom khai pla
- description: Thai dessert
- countries: TH
- kinds: dessert
- has Wikipedia article: en

## DISH Q65072654
- name: Khao mu daeng
- description: Thai rice and pork dish
- countries: TH
- kinds: dish
- has Wikipedia article: en

## DISH Q65077962
- name: Pizzarello
- description: traditional food from Apulia, southern Italy
- countries: IT
- kinds: dish
- ingredients: Olea europaea, tomato, bread
- has Wikipedia article: en

## DISH Q65080126
- name: Sorol
- description: Filipino dish
- countries: PH
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q65080131
- name: Palapa
- description: sweet and spicy Filipino condiment
- countries: PH
- cuisines: Filipino cuisine
- kinds: condiment
- ingredients: Sakurab
- has Wikipedia article: en

## DISH Q65080132
- name: Piyanggang manuk
- description: Filipino chicken dish
- countries: PH
- cuisines: Filipino cuisine
- kinds: viand, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q65080144
- name: Piaparan
- description: Maranao dish
- countries: PH
- cuisines: Filipino cuisine
- kinds: viand, fish dish
- has Wikipedia article: en

## DISH Q65080153
- name: Kuning
- description: Philippine cuisine
- countries: PH
- kinds: rice dish
- has Wikipedia article: en

## DISH Q65084218
- name: Burong isda
- description: Filipino dish of rice and pickled fish
- countries: PH
- kinds: fish dish
- has Wikipedia article: en

## DISH Q65084223
- name: Balao-balao
- description: Filipino fermented shrimp and rice dish
- countries: PH
- kinds: fermented food, rice dish, shrimp dish
- has Wikipedia article: en

## DISH Q65084693
- name: Tungrymbai
- description: fermented soy product
- countries: IN
- kinds: fermented food, soy food
- ingredients: soy bean
- has Wikipedia article: en

## DISH Q65084902
- name: Ube crinkles
- description: Filipino cookies
- countries: PH
- kinds: cookie
- ingredients: Dioscorea alata
- has Wikipedia article: en

## DISH Q65086205
- name: Kiping
- description: Filipino food
- countries: PH
- kinds: wafer cookie
- has Wikipedia article: en

## DISH Q65086224
- name: Ginataang langka
- description: Filipino vegetable stew
- countries: PH
- kinds: dish
- ingredients: jackfruit, coconut milk
- has Wikipedia article: en

## DISH Q65086266
- name: Pilipit
- description: traditional Filipino doughnut
- countries: PH
- cuisines: Filipino cuisine
- kinds: twisted doughnut
- has Wikipedia article: en

## DISH Q65086269
- name: Kumukunsi
- description: Maguindanaoan deep-fried doughnut
- countries: PH
- cuisines: Filipino cuisine
- kinds: deep-fried confection, doughnut
- ingredients: duck egg, butter
- has Wikipedia article: en

## DISH Q65086435
- name: Bariis iskukaris
- other names: {"zh": "索馬里抓飯"}
- description: Somali cuisine
- countries: SO
- kinds: food
- ingredients: onion, basmati, chicken as food, Capsicum, Pisum sativum, raisin
- has Wikipedia article: en, zh

## DISH Q65086552
- name: Aparon
- description: Filippino dish
- countries: PH
- cuisines: Filipino cuisine
- kinds: wafer
- has Wikipedia article: en

## DISH Q65086591
- name: Yema cake
- description: Filipino chiffon cake with a custard filling known as yema
- countries: PH
- kinds: chiffon cake
- has Wikipedia article: en

## DISH Q65087240
- name: Philippine asado
- description: Philippine method of cooking
- countries: PH
- kinds: food preparation technique, meat dish
- has Wikipedia article: en

## DISH Q65087419
- name: Pinagong
- description: food item
- countries: PH
- kinds: bread roll
- has Wikipedia article: en

## DISH Q65087426
- name: Cornick
- description: Philippine and Spanish deep-fried corn snack
- countries: ES, PH
- kinds: corn snack
- ingredients: maize
- has Wikipedia article: en

## DISH Q65089369
- name: Bagnet
- description: Filipino dish of deep-fried pork belly
- countries: PH
- kinds: chicharrón, pork dish
- ingredients: pork belly
- has Wikipedia article: en

## DISH Q65089436
- name: Brazo de Mercedes
- description: traditional Filipino meringue roll
- countries: PH
- kinds: food
- ingredients: custard, meringue
- has Wikipedia article: en

## DISH Q65089597
- name: Puto seco
- description: disc-shaped, powdery rice-based cookies of the Philippines
- countries: PH
- kinds: cookie
- has Wikipedia article: en

## DISH Q65089598
- name: Ngohiong
- description: Filipino appetizer
- countries: PH
- kinds: appetizer
- has Wikipedia article: en

## DISH Q65089898
- name: Grandma pizza
- description: pizza variety originating from Long Island, New York
- countries: US
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q65090003
- name: Shakoy
- description: traditional Filipino deep-fried twisted doughnut
- countries: PH
- kinds: twisted doughnut
- has Wikipedia article: en

## DISH Q65090435
- name: Dongaseu
- description: Korean pork dish
- countries: KR
- cuisines: gyeongyangsik
- kinds: tonkatsu
- has Wikipedia article: en

## DISH Q65091072
- name: Abula
- description: soup of Yoruba people in Nigeria
- countries: NG
- kinds: soup
- ingredients: Ewedu soup, Potash, potash, iru, onion, Maggi, bean, palm oil, Capsicum, table salt, water, jute
- has Wikipedia article: en

## DISH Q65091448
- name: Ginataang kalabasa
- description: Filipino vegetable stew
- countries: PH
- kinds: dish
- ingredients: calabaza, coconut milk
- has Wikipedia article: en

## DISH Q65095584
- name: Плакия
- other names: {"bg": "Плакия"}
- countries: (none)
- kinds: dish
- ingredients: onion, vegetable

## DISH Q65117153
- name: Soup du Barry
- description: French soup made from cauliflower, potatoes, and stock
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q65117391
- name: Babbouche
- description: Moroccan dish
- countries: MA
- cuisines: Moroccan cuisine
- kinds: dish
- ingredients: ras el hanout, snail, liquorice, Mentha pulegium, Thymus, Rosmarinus officinalis, Elettaria cardamomum, Pimpinella anisum
- has Wikipedia article: en

## DISH Q65119827
- name: Odkac
- description: Somali dish consisting of preserved meat
- countries: SO
- kinds: meat dish
- has Wikipedia article: en

## DISH Q65122114
- name: Vanilla slice
- description: two pastry sheets filled with custard, iced and cut into squares
- countries: NZ
- kinds: pastry
- has Wikipedia article: en

## DISH Q65122859
- name: Pinasugbo
- description: Filipino dessert
- countries: PH
- kinds: dessert
- has Wikipedia article: en

## DISH Q65125970
- name: Московит (блюдо)
- other names: {"ru": "Московит (блюдо)"}
- countries: RU
- cuisines: Russian cuisine
- kinds: gelatin dessert

## DISH Q65127104
- name: Korzinochki
- countries: (none)
- kinds: cake

## DISH Q65130085
- name: Tressian
- other names: {"it": "Tressian"}
- countries: IT
- kinds: dessert

## DISH Q65132045
- name: Salsiccia rossa di Castelpoto
- other names: {"it": "salsiccia rossa di Castelpoto"}
- description: traditional Italian food
- countries: IT
- cuisines: campanian cuisine
- kinds: sausage, salami, prodotto agroalimentare tradizionale
- ingredients: fennel leaves, bell pepper, pork, table salt

## DISH Q65132424
- name: Pupi cull'ova PAT
- other names: {"zh": "Pupi cull'ova PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, dessert, baked good

## DISH Q65132461
- name: Cuddureddi PAT
- other names: {"zh": "Cuddureddi PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, dish, baked good, dessert

## DISH Q65132586
- name: Cudduraci
- other names: {"it": "Cudduraci"}
- countries: IT
- kinds: dessert

## DISH Q65145678
- name: Sispa
- other names: {"fr": "Sispa"}
- countries: (none)
- kinds: dish

## DISH Q651462
- name: Couverture chocolate
- description: high-quality chocolate that contains a higher percentage of cocoa butter than baking or eating chocolate
- countries: (none)
- kinds: chocolate
- ingredients: cocoa powder
- has Wikipedia article: en

## DISH Q65150941
- name: מלאי
- other names: {"he": "מלאי"}
- countries: RO
- kinds: casserole
- ingredients: maize flour, milk

## DISH Q65151728
- name: Slavonski med
- description: Croatian honey
- countries: HR
- cuisines: Croatian cuisine
- kinds: honey
- has Wikipedia article: en

## DISH Q65153051
- name: Манник
- other names: {"ru": "манник"}
- countries: (none)
- kinds: pie
- ingredients: semolina, milk

## DISH Q65153692
- name: Jambon d'Auvergne
- description: French dried ham
- countries: FR
- kinds: jamón

## DISH Q6515767
- name: Мурза
- other names: {"be-tarask": "мурза"}
- countries: (none)
- kinds: dish

## DISH Q6516224
- name: Leek soup
- description: vegetable-based soup dish
- countries: (none)
- kinds: food, vegetable soup
- ingredients: potato, leek
- has Wikipedia article: en

## DISH Q65163168
- name: Tabernero
- countries: ES
- kinds: tapas, dish, Pisto

## DISH Q65163701
- name: Tsi'ik de venado
- other names: {"es": "Tsi'ik de venado"}
- countries: MX
- kinds: dish

## DISH Q6516633
- name: Toy
- description: Swedish chewing gum
- countries: (none)
- kinds: chewing gum
- has Wikipedia article: en

## DISH Q65194563
- name: Bröd i Finland
- other names: {"sv": "Bröd i Finland"}
- countries: (none)
- kinds: bread

## DISH Q65194685
- name: Hallonlakritsskalle
- countries: (none)
- kinds: candy

## DISH Q65205156
- name: Urutan
- description: Balinese cousine
- countries: ID
- kinds: human food, food
- ingredients: pork, intestine

## DISH Q65205169
- name: Napoleons
- other names: {"ca": "Napoleons"}
- countries: (none)
- kinds: dish

## DISH Q65208584
- name: Lembut satay
- description: traditional food from Betawi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay
- ingredients: satay sauce, lontong, ketupat, beef

## DISH Q65209211
- name: Ondol singkong
- description: Indonesian traditional food
- countries: (none)
- kinds: dish

## DISH Q65209835
- name: Gogos
- other names: {"id": "gogos"}
- description: food made from white or black sticky rice that has been mixed with coconut milk, then wrapped in banana leaves and grilled
- countries: (none)
- kinds: rice dish

## DISH Q65210405
- name: Ayam panggang
- description: cocos (Keeling) Islands chicken dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, roast chicken
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q65210412
- name: Bebai maghing
- other names: {"id": "Bebai maghing"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, kue
- ingredients: glutinous rice flour, coconut milk, sugar, potato

## DISH Q65210593
- name: Jadah manten
- description: Indonesian traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, kue

## DISH Q65210830
- name: Bakakak hayam
- description: traditional Sundanese chicken dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, roast chicken, grilled chicken
- has Wikipedia article: en

## DISH Q65210868
- name: Brongkos
- description: Indonesian beef stew
- countries: ID
- kinds: food
- has Wikipedia article: en

## DISH Q65211925
- name: Pacri nenas Pontianak
- other names: {"id": "pacri nenas Pontianak"}
- countries: ID
- kinds: soup
- ingredients: pineapple

## DISH Q65211932
- name: Palai Bada
- description: West Sumatra anchovy dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, pepes
- ingredients: Engraulidae

## DISH Q65213454
- name: Asem satay
- description: Indonesian cuisine
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay
- ingredients: beef, pork, Tamarindus indica

## DISH Q65213460
- name: Milk beef satay
- description: variations of typical Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: Indonesian cuisine, human food, type of food or dish, dish, satay
- ingredients: rice flour, beef

## DISH Q6521356
- name: Lemon drop
- other names: {"zh": "水果硬糖"}
- description: sugar coated, lemon-flavored candy
- countries: (none)
- kinds: drops
- ingredients: sugar
- has Wikipedia article: en

## DISH Q6521359
- name: Lemon ice box pie
- other names: {"zh": "檸檬冰盒派"}
- description: dessert consisting of lemon juice, eggs, and condensed milk in a pie crust
- countries: US
- kinds: pie
- has Wikipedia article: en, zh

## DISH Q6521367
- name: Lemon tart
- other names: {"zh": "檸檬塔"}
- description: dessert dish
- countries: FR
- kinds: sweet tart, meal
- ingredients: lemon, egg yolk, sugar
- has Wikipedia article: en, zh

## DISH Q65213789
- name: Abon Ikan Bandeng
- description: Makanan Khas Indonesia yang terbuat dari bahan baku ikan bandeng yang telah dipisahkan dari durinya yang dilumatkan kemudian dikukus dan dicampurkan bumbu rempah rempah yang kemudian digoreng hingga minyaknya berkurang dan kering.
- countries: ID
- kinds: food, type of food or dish, fish dish
- ingredients: Chanos chanos

## DISH Q65213802
- name: Biji ketapang
- other names: {"bew": "biji ketapang"}
- countries: ID
- kinds: dish, human food, traditional food

## DISH Q65213901
- name: Pupu
- description: Indonesian food
- countries: ID
- kinds: frikadeller
- ingredients: rice flour, skipjack tuna, Alpinia galanga, Allium ascalonicum, Cymbopogon citratus

## DISH Q65215552
- name: Lumpensuppe
- other names: {"de": "Lumpensuppe"}
- countries: HU
- cuisines: Hungarian cuisine
- kinds: dish, soup

## DISH Q65216477
- name: Katalabrox
- other names: {"eu": "Katalabrox"}
- countries: (none)
- kinds: dessert

## DISH Q65234287
- name: Gamjabap
- description: Korean dish of rice and potatoes
- countries: (none)
- kinds: dish
- ingredients: potato, rice

## DISH Q65234442
- name: Katsu ramen
- countries: (none)
- kinds: shoyu ramen
- ingredients: tonkatsu

## DISH Q65234499
- name: Holomuussi
- other names: {"fi": "Holomuussi"}
- countries: FI
- kinds: traditional food
- ingredients: pork

## DISH Q65234925
- name: しょうゆマヨスパゲティ
- other names: {"ja": "しょうゆマヨスパゲティ"}
- countries: JP
- kinds: pasta dish

## DISH Q65235042
- name: そば米汁
- other names: {"ja": "そば米汁"}
- countries: JP
- kinds: buckwheat porridge

## DISH Q65235267
- name: Firni
- other names: {"de": "Firni"}
- countries: AZ
- kinds: dessert

## DISH Q65236023
- name: Juustopaisti
- other names: {"fi": "juustopaisti"}
- description: Finnish traditional food
- countries: FI
- kinds: dish, traditional food

## DISH Q65236098
- name: Miso katsu ramen
- countries: (none)
- kinds: miso ramen
- ingredients: tonkatsu

## DISH Q65236447
- name: Blodklubb
- other names: {"nb": "blodklubb"}
- countries: (none)
- kinds: bread
- ingredients: blood

## DISH Q65238329
- name: Kashi dofu
- description: acorn starch jelly
- countries: (none)
- kinds: pudding, gelatin dessert
- ingredients: acorn

## DISH Q65238841
- name: Lasimestarin silli
- other names: {"fi": "Lasimestarin silli"}
- countries: (none)
- kinds: fish dish
