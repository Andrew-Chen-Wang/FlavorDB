# Review batch names-022

## DISH Q135442115
- name: Potato curry
- description: curry with potatoes
- countries: (none)
- kinds: curry, potato dish

## DISH Q135442153
- name: Ritual Christmas prianyky of Sloboda Ukraine
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: pryanik

## DISH Q135442387
- name: Zapekanka
- description: casserole, baked pudding
- countries: (none)
- kinds: dish, Pizzas, casseroles
- has Wikipedia article: en

## DISH Q135446912
- name: Banana Breakfast Cookies
- description: Banana Date Breakfast Cookies are soft, gluten-free, and naturally sweetened with ripe bananas and dates.
- countries: (none)
- kinds: dish, banana
- ingredients: chicken egg, olive oil, nutmeg, cinnamon, vanilla, banana

## DISH Q135447217
- name: Cake doughnut
- description: doughnut type using cake batter
- countries: (none)
- kinds: doughnut
- has Wikipedia article: en

## DISH Q135448393
- name: Acara
- description: is a very common variety of beans in Africa, especially in Senegal.
- countries: SN
- kinds: dish
- ingredients: black turtle bean, white bean paste, red bean paste, Vigna unguiculata

## DISH Q135448408
- name: Madd
- description: Senegalese dish
- countries: SN
- kinds: dish
- ingredients: seed, pulp, Capsicum, table salt, sugar, juice, water

## DISH Q135448417
- name: Lakh
- description: Senegalese couscous dish
- countries: SN
- kinds: dish
- ingredients: wheat, sour cream, flour

## DISH Q135448444
- name: Bouye Juice
- description: Senegalese couscous dish
- countries: SN
- cuisines: Senegalese cuisine
- kinds: dish
- ingredients: creamer, beverage industry, bouye

## DISH Q135449174
- name: Potato biscuits
- description: A Cookie made of potatoes
- countries: IN
- kinds: food product, cookie
- ingredients: potato

## DISH Q135454522
- name: ತೇರೆದ ಕೊಡಿತ್ತ ಚಟ್ನಿ
- other names: {"tcy": "ತೇರೆದ ಕೊಡಿತ್ತ ಚಟ್ನಿ"}
- countries: IN
- kinds: human food, porridge
- ingredients: coconut, castor oil, chili pepper, Cuminum cyminum

## DISH Q135457738
- name: Thiebou Diola
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q135472092
- name: Maekjeok
- other names: {"zh": "貊炙"}
- description: Korean meat dish
- countries: KR
- cuisines: Korean cuisine
- kinds: meat dish, Korean barbecue, food
- has Wikipedia article: en

## DISH Q135472995
- name: Meen-vada
- countries: IN
- kinds: human food
- ingredients: fish as food

## DISH Q135484032
- name: Sega blawong
- other names: {"jv": "sega blawong"}
- countries: (none)
- cuisines: Javanese cuisine
- kinds: rice dish, dish

## DISH Q135486726
- name: Calulu and Funge
- description: Calulu and Funge are traditional dishes from Angola
- countries: AO
- kinds: soup, dish
- ingredients: cassava root, garlic, tomato, palm oil, Allium, Sweet potato, vegetable, fish

## DISH Q135487511
- name: Кукар
- other names: {"cv": "Кукар"}
- countries: (none)
- cuisines: Chuvash cuisine
- kinds: food

## DISH Q135488580
- name: Richoco Nabati
- description: Variant of Nabati Wafer
- countries: ID
- kinds: food product, wafer
- ingredients: Theobroma cacao

## DISH Q135494034
- name: Cabrito (Goat Meat Stew)
- description: Angolan Goat meat stew
- countries: AO
- cuisines: African cuisine
- kinds: stew, goat meat pepper soup
- ingredients: goat meat, olive oil, Allium, red wine

## DISH Q135498221
- name: Katlam
- description: traditional Kashmiri bread
- countries: (none)
- cuisines: Kashmiri cuisine
- kinds: bread, dish
- has Wikipedia article: en

## DISH Q135509388
- name: Makayabu
- description: Makayabu is a traditional Congolese and Angolans food prepared with salted fish, vegetables, and traditional spices.
- countries: AO, CD
- cuisines: African cuisine
- kinds: food, dish
- ingredients: cabbage, Capsicum, vegetable, fish

## DISH Q135509581
- name: Kamundele
- other names: {"mul": "Kamundele"}
- description: Kamundele is a Congolese-style beef kebab dish, also known as brochette de boeuf.
- countries: CD
- kinds: dish
- ingredients: goat meat stock, vegetable oil, kosher salt, beef

## DISH Q135509960
- name: Mbwengi (Black Eyed Peas)
- description: Congolese Food
- countries: CD
- kinds: food
- ingredients: Plantago afra, peanut butter, nutmeg

## DISH Q135533555
- name: Polenta rognosa
- other names: {"it": "Polenta rognosa"}
- countries: (none)
- kinds: traditional food

## DISH Q13557309
- name: Gołąbki
- other names: {"zh": "波蘭甘藍菜捲"}
- description: Central European dish
- countries: PL
- cuisines: Polish cuisine
- kinds: cabbage roll
- ingredients: Brassica oleracea var. capitata
- has Wikipedia article: en

## DISH Q135623631
- name: Sopi aw'i Playa
- other names: {"pap": "Sopi aw'i Playa"}
- description: Traditional fish soup
- countries: AW, CW
- kinds: soup, traditional food
- ingredients: onion, paprika, herb, potato, fish

## DISH Q135629302
- name: Pasta all'amatriciana
- description: pasta dish
- countries: (none)
- kinds: pasta dish
- ingredients: amatriciana sauce, spaghetti

## DISH Q135642191
- name: Coffee-flavored cake
- description: cake with coffee flavor
- countries: (none)
- kinds: cake
- ingredients: coffee

## DISH Q135643358
- name: Sikil p'ak
- other names: {"es": "Sikil p'ak"}
- countries: MX
- kinds: dish

## DISH Q13564483
- name: Koottukari
- description: yellow curry
- countries: IN
- kinds: food, Indian curry
- ingredients: coconut
- has Wikipedia article: en

## DISH Q135646299
- name: Pithali
- description: traditional savoury dish originating from the Jamalpur District in Mymensingh Division, Bangladesh
- countries: BD
- kinds: dish
- has Wikipedia article: en

## DISH Q135650124
- name: Esh
- description: Chadian dish
- countries: TD
- kinds: dish
- has Wikipedia article: en

## DISH Q135650550
- name: Dough-sealed soup
- description: Mongolian dish
- countries: MN
- cuisines: Mongolian cuisine
- kinds: dish, soup

## DISH Q135650619
- name: Khailmag
- description: Mongolian dessert
- countries: MN
- cuisines: Mongolian cuisine
- kinds: dessert, butter

## DISH Q13566136
- name: Shekarpareh
- description: Iranian candy
- countries: IR
- kinds: food, pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q135669240
- name: Lontar cake
- description: traditional food from Indonesia
- countries: ID
- kinds: dessert, dish, pie
- ingredients: granulated sugar, chicken egg, corn starch, condensed milk, wheat flour, hot water, milk powder, egg yolk, vanilla, margarine

## DISH Q13568060
- name: Roti
- description: wrap style sandwich
- countries: TT
- kinds: food, sandwich, pie
- ingredients: potato
- has Wikipedia article: en

## DISH Q135683547
- name: ミルヒライス
- other names: {"ja": "ミルヒライス"}
- countries: (none)
- cuisines: Nordic cuisine
- kinds: type of food or dish, rice dish
- ingredients: cow's milk, cinnamon, rice

## DISH Q135718733
- name: Cake bite
- description: small bite-sized cake
- countries: (none)
- kinds: cake

## DISH Q135726819
- name: Limburgse vlaai
- other names: {"nl": "Limburgse vlaai"}
- countries: (none)
- kinds: vlaai

## DISH Q135734993
- name: Khobz el-dâr
- description: type of leavened bread made in the Maghreb
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q135739047
- name: Yellow tofu
- countries: (none)
- cuisines: Javanese cuisine
- kinds: dish, tofu

## DISH Q135739915
- name: Paklé
- description: Javanese rice dish
- countries: (none)
- cuisines: Javanese cuisine
- kinds: dish
- ingredients: chicken as food, egg as food, rice

## DISH Q135740198
- name: Пудбивана пасуля
- other names: {"rue": "пудбивана пасуля"}
- countries: (none)
- cuisines: Rusyn cuisine
- kinds: dish
- ingredients: bean, milk

## DISH Q135742149
- name: Pork curry
- countries: (none)
- kinds: curry, pork dish

## DISH Q1358074
- name: Candy apple
- other names: {"zh": "糖苹果"}
- description: whole apples covered in a hard toffee or sugar candy coating
- countries: US
- kinds: confectionery
- ingredients: apple
- has Wikipedia article: en, zh

## DISH Q13581171
- name: Paletta Biellese
- description: Italian pork shoulder ham
- countries: IT
- kinds: prosciutto
- ingredients: pork shoulder

## DISH Q135826435
- name: Pecora in cappotto
- other names: {"fr": "pecora in cappotto"}
- countries: (none)
- kinds: dish
- ingredients: sheep meat

## DISH Q135826755
- name: Trattalia
- other names: {"it": "trattalia"}
- countries: IT
- kinds: dish

## DISH Q135826759
- name: Abats d'agneau
- other names: {"fr": "abats d'agneau"}
- countries: (none)
- kinds: offal, lamb meat, dish

## DISH Q135827096
- name: Abats de chèvre
- other names: {"fr": "abats de chèvre"}
- countries: (none)
- kinds: offal, goat meat, dish

## DISH Q135827263
- name: Viande de chèvre rôtie à la broche
- other names: {"fr": "viande de chèvre rôtie à la broche"}
- countries: IT
- kinds: dish
- ingredients: goat meat

## DISH Q135827542
- name: Berbeche in cappotto
- other names: {"it": "berbeche in cappotto"}
- countries: IT
- kinds: dish
- ingredients: sheep meat, onion, potato

## DISH Q135827876
- name: Prosciutto di Talana
- other names: {"fr": "prosciutto di Talana"}
- countries: IT
- kinds: dish, prosciutto

## DISH Q13582838
- name: Rihaakuru
- description: fish-based sauce
- countries: (none)
- kinds: fish dish, tuna dish
- has Wikipedia article: en

## DISH Q13583872
- name: Kosmatice
- other names: {"cs": "kosmatice"}
- countries: (none)
- kinds: dish
- ingredients: egg as food, flour, Sambucus nigra

## DISH Q135840981
- name: Vegan sushi
- countries: (none)
- cuisines: vegan cuisine
- kinds: sushi, vegan food, vegetarian food

## DISH Q135841346
- name: Tukir
- countries: (none)
- kinds: dish

## DISH Q13584745
- name: Veal Oscar
- description: culinary creation
- countries: (none)
- kinds: veal dish
- has Wikipedia article: en

## DISH Q135870257
- name: Green chile cheeseburger
- description: dish
- countries: (none)
- cuisines: New Mexican cuisine
- kinds: dish
- ingredients: burger bun, lettuce, New Mexico chile, patty, cheese

## DISH Q135908643
- name: Xinghwimbi
- other names: {"ts": "Xinghwimbi"}
- countries: (none)
- kinds: dish

## DISH Q135910841
- name: Samin goxo
- other names: {"eu": "Samin goxo"}
- countries: (none)
- kinds: dessert
- ingredients: condensed milk, lemon juice, yogurt

## DISH Q135921153
- name: Hot beef commercial
- description: roast beef sandwich
- countries: US
- cuisines: Minnesotan cuisine
- kinds: dish, food
- ingredients: pot roast, white bread, gravy, mashed potato
- has Wikipedia article: en

## DISH Q135921156
- name: Hot dago
- description: sausage sandwich
- countries: US
- kinds: dish, food
- ingredients: Italian sausage
- has Wikipedia article: en

## DISH Q135921159
- name: Walleye sandwich
- description: fried fish sandwich
- countries: US
- cuisines: Canadian cuisine, Minnesotan cuisine
- kinds: dish, food
- ingredients: Walleye, bread
- has Wikipedia article: en

## DISH Q135921166
- name: South American
- description: minced meat sandwich
- countries: US
- cuisines: Minnesotan cuisine
- kinds: dish, food
- ingredients: celery, tomato, minced meat, onion, Capsicum
- has Wikipedia article: en

## DISH Q135921173
- name: Wild rice pancake
- description: type of American food
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q135925569
- name: Mrkvanec
- other names: {"cs": "mrkvanec"}
- countries: CZ
- kinds: pastry, Buchteln
- ingredients: poppy seed, yeast dough, carrot

## DISH Q135927604
- name: خبز معمر
- other names: {"ar": "خبز معمر"}
- countries: MA
- kinds: dish

## DISH Q135927668
- name: Cranberry wild rice bread
- description: type of American rice bread
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q135927675
- name: Wild rice salad
- description: cold salad in Minnesotan cuisine
- countries: US
- cuisines: Minnesotan cuisine
- kinds: dish, food
- has Wikipedia article: en

## DISH Q135934553
- name: Dendermondse vlaai
- other names: {"nl": "Dendermondse vlaai"}
- countries: BE
- kinds: type of food or dish, sweet pie

## DISH Q135943559
- name: Stewed white cabbage
- countries: (none)
- kinds: stew, Brassica oleracea f. alba, dish

## DISH Q135972869
- name: Mississippi Mud
- countries: US
- kinds: stuffing
- ingredients: chocolate

## DISH Q135973674
- name: Kaeng thepho
- description: Thai curry dish
- countries: TH
- kinds: pork curry
- has Wikipedia article: en

## DISH Q135976952
- name: Hatley Road
- description: cheese from Quebec
- countries: CA
- kinds: cow's-milk cheese, cheese from Quebec
- ingredients: cow's milk

## DISH Q135978064
- name: Ampow
- description: Filipino sweet puffed rice cake
- countries: PH
- kinds: puffed rice cake
- has Wikipedia article: en

## DISH Q135980010
- name: Minced meat pie
- countries: (none)
- kinds: savoury pie
- ingredients: minced meat

## DISH Q135981036
- name: Cumboo
- other names: {"om": "Cumboo"}
- countries: (none)
- kinds: dish

## DISH Q135989767
- name: Chicken kebab
- description: type of kebab made from chicken
- countries: (none)
- kinds: doner kebab, dish
- ingredients: chicken as food

## DISH Q135989793
- name: Kebab sandwich
- description: sandwich that is, generally sold in kebab shops
- countries: TR
- kinds: sandwich, doner kebab
- ingredients: kebab

## DISH Q135991111
- name: Renyons de masero
- other names: {"ca": "Renyons de masero"}
- countries: (none)
- ingredients: tomato, eggplant

## DISH Q135991180
- name: Innichner butterkäse PAT
- other names: {"zh": "Innichner butterkäse PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese, cow's-milk cheese

## DISH Q135992934
- name: Pasta with mozzarella, tomato and basil
- countries: IT
- kinds: pasta dish
- ingredients: basil, tomato, pasta

## DISH Q136026276
- name: Polárkový dort
- other names: {"cs": "Polárkový dort"}
- countries: CZ
- kinds: dessert

## DISH Q136035763
- name: Marshall
- description: Registered signature cake of Ulus Patisserie
- countries: TR
- kinds: food, cake

## DISH Q136084592
- name: Birchermuesli
- description: original muesli recipe invented by Maximilian Bircher-Benner
- countries: CH
- cuisines: Swiss cuisine
- kinds: dish, muesli
- ingredients: nut, condensed milk, lemon juice, rolled oats, apple

## DISH Q136086697
- name: Notella
- description: chocolate hazelnut spread that mimics Nutella
- countries: (none)
- kinds: chocolate spread, hazelnut spread, imitation food

## DISH Q136087023
- name: Liluva
- description: residual water from processing legumes
- countries: (none)
- cuisines: vegan cuisine
- kinds: food ingredient, residual water
- ingredients: legume, water

## DISH Q136087059
- name: Aquafaba meringue
- description: meringue made from whipped aquafaba and sugar
- countries: FR
- cuisines: vegan cuisine
- kinds: confectionery, meringue
- ingredients: beaten aquafaba, sugar

## DISH Q136087103
- name: Mashed chickpea
- description: chickpea dish
- countries: (none)
- kinds: chickpea dish, porridge
- ingredients: chickpea

## DISH Q136087963
- name: Shtridhelat
- other names: {"it": "shtridhelat"}
- countries: (none)
- kinds: pasta, food

## DISH Q136089368
- name: Pulled Chicken Burger
- countries: (none)
- kinds: hamburger, product

## DISH Q136093120
- name: பொரிவிளங்காய் உருண்டை
- other names: {"ta": "பொரிவிளங்காய் உருண்டை"}
- countries: (none)
- cuisines: Tamil cuisine
- kinds: human food, snack

## DISH Q136101449
- name: Tartufata
- other names: {"pl": "tartufata"}
- countries: (none)
- kinds: vegetable dish

## DISH Q1361086
- name: Chocolate bar
- other names: {"zh": "巧克力棒"}
- description: confection of sweetened chocolate
- countries: (none)
- kinds: sweetmeat, confectionery, candy bar, chocolate dish
- ingredients: chocolate
- has Wikipedia article: en, zh

## DISH Q136118473
- name: Frikatxa
- other names: {"eu": "Frikatxa"}
- countries: (none)
- kinds: lamb dish, egg dish, dish
- ingredients: lamb, offal, egg as food

## DISH Q1361771
- name: Piccata
- description: Italian dish
- countries: IT
- kinds: fish dish, chicken dish, veal dish
- has Wikipedia article: en

## DISH Q1361859
- name: Bordelaise sauce
- other names: {"zh": "波尔多酱汁"}
- description: French wine sauce
- countries: FR
- kinds: sauce
- ingredients: red wine
- has Wikipedia article: en, zh

## DISH Q136190530
- name: 高島とんちゃん
- other names: {"ja": "高島とんちゃん"}
- countries: JP
- kinds: chicken dish

## DISH Q136190538
- name: 鯖しゃぶ
- other names: {"ja": "鯖しゃぶ"}
- countries: JP
- kinds: shabu-shabu

## DISH Q136190539
- name: 会津白べこラーメン
- other names: {"ja": "会津白べこラーメン"}
- countries: JP
- kinds: ramen

## DISH Q136190541
- name: 天ぷらまんじゅう
- other names: {"ja": "天ぷらまんじゅう"}
- countries: JP
- kinds: tempura, manjū

## DISH Q136190542
- name: 田舎ずし
- other names: {"ja": "田舎ずし"}
- countries: JP
- kinds: sushi

## DISH Q136190543
- name: こけらずし
- other names: {"ja": "こけらずし"}
- countries: JP
- kinds: sushi

## DISH Q136190544
- name: 菜豆腐
- other names: {"ja": "菜豆腐"}
- countries: JP
- kinds: tofu

## DISH Q136190548
- name: 鹿角ホルモン
- other names: {"ja": "鹿角ホルモン"}
- countries: JP
- kinds: offal dish

## DISH Q136192494
- name: Tøyen-Cola
- description: Norwegian open-source cola
- countries: NO
- kinds: open source cola

## DISH Q136213839
- name: 北京飯
- other names: {"ja": "北京飯"}
- countries: (none)
- kinds: donburi

## DISH Q136213860
- name: ひこね丼
- other names: {"ja": "ひこね丼"}
- countries: (none)
- kinds: donburi

## DISH Q136213867
- name: ほるホル丼
- other names: {"ja": "ほるホル丼"}
- countries: (none)
- kinds: donburi

## DISH Q136213891
- name: トマト丼
- other names: {"ja": "トマト丼"}
- countries: (none)
- kinds: donburi

## DISH Q136229810
- name: さばの姿ずし
- other names: {"ja": "さばの姿ずし"}
- countries: JP
- kinds: sushi

## DISH Q136229811
- name: Gonan omusubi
- countries: JP
- kinds: onigiri

## DISH Q136229812
- name: どろ焼
- other names: {"ja": "どろ焼"}
- countries: JP
- kinds: okonomiyaki

## DISH Q136229814
- name: げんなり寿司
- other names: {"ja": "げんなり寿司"}
- countries: JP
- kinds: sushi

## DISH Q136229815
- name: 梅ごはん
- other names: {"ja": "梅ごはん"}
- countries: JP
- kinds: rice dish

## DISH Q136229816
- name: 重箱入りぼたもち
- other names: {"ja": "重箱入りぼたもち"}
- countries: JP
- kinds: botamochi

## DISH Q136229817
- name: カンカンずし
- other names: {"ja": "カンカンずし"}
- countries: JP
- kinds: sushi

## DISH Q136229818
- name: けんさ焼き
- other names: {"ja": "けんさ焼き"}
- description: onigiri-based snack
- countries: JP
- kinds: onigiri

## DISH Q136229819
- name: ばんだい餅
- other names: {"ja": "ばんだい餅"}
- countries: JP
- kinds: mochi

## DISH Q136230569
- name: Kacapoły
- other names: {"pl": "kacapoły"}
- countries: PL
- kinds: dish
- ingredients: tvorog, potato, peppercorn, wheat flour, table salt

## DISH Q136238303
- name: Buttermilk Chicken
- description: Traditional Malaysian crispy fried chicken dish tossed in a creamy, savory sauce of butter, evaporated milk, chili, and curry leaves
- countries: (none)
- kinds: chicken dish, human food, type of food or dish
- ingredients: evaporated milk, chicken as food, bird's eye chili, Murraya koenigii, butter, Allium sativum

## DISH Q1362405
- name: Gelato
- other names: {"zh": "義式冰淇淋"}
- description: Italian style of ice cream
- countries: IT
- kinds: ice cream, frozen dessert
- ingredients: cream, sugar, milk
- has Wikipedia article: en, zh

## DISH Q136271573
- name: Pichita de Gato
- other names: {"es": "Pichita de Gato"}
- countries: ES
- kinds: table grape variety

## DISH Q136281801
- name: Ayaraya Oka
- description: A food prepared and eaten by Igbo people in Nigeria, particularly people of Nsukka in Enugu state.
- countries: NG
- kinds: food, dish, human food
- ingredients: onion, maize, table salt, vegetable, Capsicum annuum, pigeon pea, palm oil

## DISH Q136288509
- name: Dulces de La Ligua
- other names: {"es": "Dulces de La Ligua"}
- countries: (none)
- kinds: confectionery

## DISH Q136288988
- name: Zenne pot
- description: Brussels dish made from bloempanch, dry sausage, whelks and cabbage cooked in gueuze
- countries: BE
- cuisines: cuisine of Brussels
- kinds: dish
- ingredients: bloempanch, dry sausage, cabbage, onion, gueuze, Buccinum undatum, cream

## DISH Q1363042
- name: Giandujotto PAT
- other names: {"zh": "Giandujotto PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good, bonbon
- ingredients: Gianduja
- has Wikipedia article: en, zh

## DISH Q136309140
- name: MX3 Capsule
- description: Philippine dietary supplement capsule derived from mangosteen pericarp, rich in xanthones
- countries: PH
- kinds: Garcinia mangostana, capsule, dietary supplement, xanthones

## DISH Q136319879
- name: Shira kaa'ula
- other names: {"guc": "Shira kaa'ula"}
- countries: (none)
- kinds: dish

## DISH Q13632478
- name: Zhimazao
- other names: {"zh": "芝麻棗"}
- description: Sesame ball
- countries: CN
- kinds: pastry
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q136327320
- name: Num akor
- description: Cambodian dessert
- countries: KH
- kinds: rice cake
- ingredients: glutinous rice flour, grated coconut, palm sugar, coconut cream
- has Wikipedia article: en

## DISH Q136342043
- name: Fast food item
- description: quickly prepared and conveniently packaged food product typically sold by fast food restaurants
- countries: (none)
- kinds: dish

## DISH Q136345512
- name: Manpukuji carrot
- description: very long carrot from Japan
- countries: (none)
- kinds: carrot
- has Wikipedia article: en

## DISH Q136346177
- name: Jar jow
- description: char siu and vegetables in sweet and sour sauce
- countries: (none)
- kinds: food, dish
- ingredients: char siu
- has Wikipedia article: en

## DISH Q136346682
- name: Caprese sandwich
- description: sandwich with tomato, mozzarella, and olive oil
- countries: (none)
- kinds: sandwich
- ingredients: basil, tomato, mozzarella, bread

## DISH Q1363560
- name: Chestnut spread
- description: spread made of chestnut fruits
- countries: FR
- kinds: spread, confectionery
- ingredients: syrup, marron, marron glacé

## DISH Q136358191
- name: Tortenmumie
- other names: {"de": "Tortenmumie"}
- countries: (none)
- kinds: nut cake

## DISH Q136361024
- name: Pholar
- description: mixed fruit plater dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q136361431
- name: Einbrennte Hund
- other names: {"de": "Einbrennte Hund"}
- countries: AT
- kinds: side dish, potato dish
- ingredients: potato

## DISH Q136363230
- name: Sate Lodok
- description: a typical satay dish made from small pieces of meat skewered in a certain way, then grilled and served with spices which are characteristic of Tembok Village.
- countries: ID
- kinds: food, satay
- ingredients: chicken as food

## DISH Q1363716
- name: Piccalilli
- description: relish of chopped pickled vegetables and spices
- countries: (none)
- kinds: relish
- ingredients: pickling
- has Wikipedia article: en

## DISH Q136373880
- name: Khurchan
- description: Sweet food of North India
- countries: IN
- kinds: human food, sweet dish, cow's milk
- has Wikipedia article: en

## DISH Q136387693
- name: Gingerbread heart
- description: heart shaped gingerbread
- countries: (none)
- kinds: gingerbread
- ingredients: gingerbread, icing

## DISH Q136390939
- name: Salsa tamarindo
- other names: {"es": "salsa tamarindo"}
- countries: PE
- kinds: sauce

## DISH Q136391037
- name: Bebalung
- other names: {"id": "Bebalung"}
- description: Sasaknese traditional food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: cuisine, human food, type of food or dish

## DISH Q136393819
- name: Bakeapple pie
- description: Canadian dessert
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q136393820
- name: Caribou stew
- description: Canadian dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q136393839
- name: Jellied moose nose
- description: Canadian and Alaskan Indigenous delicacy
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q136393848
- name: Cod au gratin
- description: Canadian dish
- countries: CA
- kinds: dish
- has Wikipedia article: en

## DISH Q136394648
- name: Soy skewers
- countries: BF
- kinds: dish, street food, skewer

## DISH Q136396484
- name: ゴム焼きそば
- other names: {"ja": "ゴム焼きそば"}
- description: Soul food from Fukuchiyama City, Kyoto Prefecture.
- countries: (none)
- kinds: dish

## DISH Q136416797
- name: Camel milk chocolate
- description: chocolate made on milk produced by female camels
- countries: (none)
- kinds: chocolate
- ingredients: camel milk

## DISH Q136418745
- name: Fruktsmörgås
- other names: {"sv": "fruktsmörgås"}
- countries: (none)
- kinds: open sandwich

## DISH Q136420774
- name: Tuna melt
- description: type of sandwich
- countries: (none)
- kinds: melt sandwich
- ingredients: Thunnus

## DISH Q13642570
- name: Gistbrood
- other names: {"nl": "gistbrood"}
- countries: (none)
- kinds: bread

## DISH Q136428542
- name: Menestra palentina
- other names: {"es": "menestra palentina"}
- countries: ES
- cuisines: cuisine of the province of Palencia
- kinds: food, menestra
- ingredients: batter, vegetable

## DISH Q136438204
- name: 笹かまぼこ
- other names: {"ja": "笹かまぼこ"}
- countries: (none)
- kinds: kamaboko, human food

## DISH Q136440414
- name: Kunrri
- countries: (none)
- cuisines: Sindhi cuisine
- kinds: food

## DISH Q13644362
- name: Ramadan pide
- description: Turkish traditional bread
- countries: TR
- kinds: dish, bread, pide
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q136445830
- name: Rock Salt of Ranomay
- description: Rock salt of Madagascar
- countries: MG
- kinds: table salt, social movement, mixture, food preservative, food ingredient
- ingredients: manganese, calcium, potassium, iron

## DISH Q136446240
- name: Tramontana
- description: Argentine dessert and ice cream flavor
- countries: (none)
- kinds: food, ice cream
- has Wikipedia article: en

## DISH Q13644850
- name: Murabba
- description: Savoury or sweet jam pickle or achar in many regions of Pakistan, Iran, North India, Azerbaijan, Armenia and Georgia
- countries: (none)
- kinds: fruit preserves, food
- has Wikipedia article: en

## DISH Q136459564
- name: Omebe
- description: Indigenous Soup to Esan people
- countries: NG
- kinds: soup

## DISH Q136472281
- name: Cantenaar
- description: cheese
- countries: (none)
- kinds: cheese

## DISH Q136472283
- name: Maigre du Nord
- description: Belgian cheese
- countries: BE
- kinds: cheese

## DISH Q136475952
- name: Kharkivske biscuit
- description: multi-layer biscuit cookie made in Kharkiv
- countries: UA
- kinds: cookie
- ingredients: powidl, biscuit, waffle

## DISH Q136484195
- name: White Amala
- description: staple swallow food from the Yoruba people of southwestern Nigeria
- countries: NG
- cuisines: Yoruba cuisine
- kinds: swallow, food, dish, human food
- ingredients: cassava flour, water, amala

## DISH Q136485184
- name: Iyan
- description: pounded-yam
- countries: NG
- kinds: dish, swallow, human food
- ingredients: yam

## DISH Q136485229
- name: Ikọkọrẹ
- description: a pottage made from purple yam
- countries: NG
- kinds: dish, human food
- ingredients: yam
- has Wikipedia article: en

## DISH Q136486119
- name: Dawanke
- description: Food
- countries: NG
- kinds: food

## DISH Q136486535
- name: Sombi
- other names: {"fr": "Sombi"}
- description: traditional West African dish
- countries: SN
- kinds: dish
- ingredients: coconut milk, Oryza molida, Abbot Suger, table salt, drinking water
- has Wikipedia article: en

## DISH Q136486631
- name: Asun-iṣu
- description: Asun-iṣu is a Yoruba dish from Nigeria, which is a peppered and roasted yam, often prepared for celebrations and gatherings
- countries: NG
- kinds: dish, human food
- ingredients: yam

## DISH Q136486693
- name: Elubọ Ẹbẹ
- description: A meal made from yam
- countries: NG
- kinds: dish, human food
- ingredients: yam

## DISH Q136486705
- name: Ọjọjọ
- description: a delicious Nigerian snack made from grated water yam
- countries: NG
- kinds: dish, human food
- ingredients: yam, palm oil
- has Wikipedia article: en

## DISH Q136486724
- name: Lafun
- description: a traditional Nigerian "swallow" food, a starchy side dish made from fermented cassava flour, also known as white amala
- countries: NG
- kinds: dish, human food
- ingredients: cassava root

## DISH Q136486733
- name: Bẹju
- description: Cassava bread
- countries: NG
- kinds: dish, swallow, human food
- ingredients: cassava root

## DISH Q136486862
- name: Iṣapa
- description: Egusi soup cooked with fresh white zobo flower
- countries: NG
- kinds: dish, human food
- ingredients: vegetable

## DISH Q136486885
- name: Burukutu
- description: an alcoholic beverage, brewed from the grains of Guinea corn (Sorghum bicolor) and millet (Pennisetum glaucum)
- countries: NG
- kinds: dish, human food
- ingredients: millet, Sorghum, maize

## DISH Q136487236
- name: Plantain Fufu
- description: a popular West African swallow food
- countries: NG
- cuisines: Yoruba cuisine
- kinds: swallowing, food, dish, human food
- ingredients: cooking banana, drinking water

## DISH Q136487793
- name: Denderu
- description: Delicacy of Kanuri people
- countries: NG
- kinds: delicacy

## DISH Q13649208
- name: Milleens
- other names: {"zh": "米利斯芝士"}
- description: Irish farmhouse cheese brand
- countries: IE
- kinds: dairy product
- has Wikipedia article: en, zh

## DISH Q136500311
- name: Oreiller de la Belle Aurore
- other names: {"fr": "Oreiller de la Belle Aurore"}
- countries: FR
- kinds: meat pastry, pâté en croûte, dish

## DISH Q136502926
- name: Salsiccia pasqualora partinicese
- other names: {"it": "Salsiccia pasqualora partinicese"}
- countries: IT
- kinds: dry sausage

## DISH Q136513295
- name: Baked zucchini slices
- countries: (none)
- kinds: tapas, dish
- ingredients: zucchini

## DISH Q136515447
- name: Salame di tonno
- other names: {"it": "Salame di tonno"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: fish dish

## DISH Q136515562
- name: Συκομαΐδα
- other names: {"el": "Συκομαΐδα"}
- countries: GR
- kinds: local food, traditional food
- ingredients: dried fig

## DISH Q13651680
- name: Natinombur
- description: Batak traditional dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, fish dish
- ingredients: shallot, ginger, Andaliman, Etlingera elatior, Aleurites moluccanus, bird's eye chili, Alpinia galanga, Oreochromis niloticus, Cymbopogon citratus, orange, table salt
- has Wikipedia article: en

## DISH Q136523566
- name: Smidyn cabbage
- countries: (none)
- kinds: intangible cultural heritage, dish

## DISH Q136523624
- name: Artopil
- other names: {"eu": "Artopil"}
- countries: (none)
- kinds: dessert
- ingredients: maize

## DISH Q136524084
- name: Argentine cake
- description: Argentine dessert
- countries: (none)
- kinds: cake, food
- ingredients: sponge cake, dulce de leche
- has Wikipedia article: en

## DISH Q136526294
- name: Menola salata PAT
- other names: {"zh": "Menola salata PAT"}
- description: traditional Italian fish, mollusc or crustacean product (PAT)
- countries: IT
- kinds: food product, Spicara maena, seafood, human food
- ingredients: Spicara maena, Trapani salt ponds, Spicara smaris

## DISH Q136527600
- name: Strawberry salad
- countries: (none)
- kinds: salad
- ingredients: strawberry

## DISH Q136537392
- name: Zarzuela
- description: a spiced seafood and fish stew served with sauces on a bed of rice
- countries: ES
- kinds: stew, dish

## DISH Q136538519
- name: Maatjes
- description: cured herring made from young female herrings
- countries: (none)
- kinds: dish

## DISH Q136538525
- name: Maasa
- description: shallow fried cakes made from millet or sorghum dough that has been allowed to undergo lactic acid bacterial fermentation
- countries: (none)
- kinds: dish, fried food
- ingredients: sorghum grain, millet

## DISH Q136557181
- name: Covrig muscelean
- other names: {"ro": "Covrig muscelean"}
- countries: (none)
- kinds: baked good

## DISH Q136563124
- name: Stelja of Sjenica
- countries: RS
- kinds: dried meat

## DISH Q136564070
- name: Fritay
- description: street foods associated with Haitian culture
- countries: (none)
- kinds: food, street food
- has Wikipedia article: en

## DISH Q136564522
- name: Confetti square
- description: dessert bar
- countries: (none)
- kinds: dessert bar
- has Wikipedia article: en

## DISH Q1365868
- name: Pork belly
- other names: {"zh": "猪腩"}
- description: boneless cut of fatty meat from the belly of a pig
- countries: (none)
- kinds: bacon, pork, primal cut, pork dish
- has Wikipedia article: en, zh

## DISH Q136621351
- name: Gulai gajeboh
- other names: {"min": "Gulai gajeboh"}
- countries: (none)
- cuisines: Padang cuisine
- kinds: human food

## DISH Q1366456
- name: Panini
- other names: {"zh": "帕尼诺"}
- description: Italian-style sandwich
- countries: IT
- cuisines: Italian cuisine
- kinds: type of food or dish, sandwich, finger food, bánh, bread dish
- ingredients: bread
- has Wikipedia article: en, zh

## DISH Q136647933
- name: Fuoco dell'Etna
- other names: {"it": "Fuoco dell'Etna"}
- countries: IT
- kinds: liquor

## DISH Q136648172
- name: Gidata
- other names: {"it": "Gidata"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish

## DISH Q13666435
- name: Kalitsounia
- description: cheese or herb pie associated with Crete
- countries: GR
- cuisines: Greek cuisine
- kinds: type of food or dish, dessert
- ingredients: mizithra, flour, honey
- has Wikipedia article: en

## DISH Q136674379
- name: Mrváň
- other names: {"cs": "Mrváň"}
- countries: SK
- kinds: pastry

## DISH Q136674388
- name: Disco fries
- description: dish of french fries with gravy and cheese
- countries: US
- kinds: food, dish
- ingredients: gravy, fries, cheese
- has Wikipedia article: en

## DISH Q136678592
- name: Maiorchino di Novara di Sicilia PAT
- other names: {"zh": "Maiorchino di Novara di Sicilia PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: Italian cheese, cheese

## DISH Q136679835
- name: Busiate with Trapanese pesto
- description: typical Sicilian dish
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish
- ingredients: Busiate, pesto alla trapanese

## DISH Q136681409
- name: Miele delle Madonie PAT
- other names: {"zh": "Miele delle Madonie PAT"}
- description: traditional Italian animal product (PAT)
- countries: IT
- kinds: honey, animal product

## DISH Q136689274
- name: Queso andino
- other names: {"es": "Queso andino"}
- countries: PE
- kinds: cheese

## DISH Q136695982
- name: Obaruša
- description: food dish from Sandžak
- countries: RS
- kinds: dish

## DISH Q136696297
- name: Feo de Villalpando
- other names: {"es": "Feo de Villalpando"}
- countries: ES
- kinds: confectionery

## DISH Q136700752
- name: Pollo al carbon
- description: Grilled chicken
- countries: MX
- kinds: food, dish
- has Wikipedia article: en

## DISH Q136701
- name: Zabaione
- other names: {"zh": "萨巴雍"}
- description: Italian dessert
- countries: IT
- kinds: dessert
- ingredients: egg as food, sugar
- has Wikipedia article: en

## DISH Q136718362
- name: Labor Inducer
- other names: {"zh": "催產漢堡"}
- description: hamburger served in Minnesota, US
- countries: (none)
- kinds: hamburger
- has Wikipedia article: en, zh

## DISH Q136722956
- name: Lomitos de Valladolid
- other names: {"es": "Lomitos de Valladolid"}
- countries: MX
- kinds: dish
- ingredients: tomato, pork loin, sofrito

## DISH Q136732109
- name: Christmas chips
- countries: IE
- kinds: potato dish, food

## DISH Q136746224
- name: Fegato caiolato
- other names: {"it": "Fegato caiolato"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: pork dish

## DISH Q136747013
- name: Oliva nera passuluni
- other names: {"it": "oliva nera passuluni"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: olive

## DISH Q136747233
- name: Pasta reale di Tortorici
- other names: {"it": "Pasta reale di Tortorici"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: food

## DISH Q136747267
- name: Cubaita di Racalmuto
- other names: {"it": "Cubaita di Racalmuto"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dessert

## DISH Q136747276
- name: Cucchitella di Sciacca
- other names: {"it": "Cucchitella di Sciacca"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dessert

## DISH Q136747307
- name: Taralli di Racalmuto
- other names: {"it": "Taralli di Racalmuto"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dessert

## DISH Q136747335
- name: Badduzzi di riso
- other names: {"it": "Badduzzi di riso"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish

## DISH Q136747343
- name: Caciu all'argintera
- other names: {"it": "Caciu all'argintera"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish

## DISH Q136747361
- name: Cardi in pastella
- other names: {"it": "cardi in pastella"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish

## DISH Q136747378
- name: Cavata
- other names: {"it": "cavata"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: pasta

## DISH Q136747391
- name: Coddra chi sardi
- other names: {"it": "Coddra chi sardi"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish

## DISH Q136747403
- name: Focaccia al sambuco
- other names: {"it": "Focaccia al sambuco"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish

## DISH Q136747438
- name: Macco di grano
- other names: {"it": "macco di grano"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: soup

## DISH Q136747452
- name: Pasta con i broccoli arriminati
- other names: {"it": "pasta con i broccoli arriminati"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish

## DISH Q136747461
- name: Polpette di creta
- other names: {"it": "polpette di creta"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish
- ingredients: water, garlic, egg as food, cheese, bread

## DISH Q136747471
- name: Miele delle Egadi
- other names: {"it": "Miele delle Egadi"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: honey

## DISH Q136747479
- name: Miele di Trapani
- other names: {"it": "Miele di Trapani"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: honey

## DISH Q136774181
- name: Gâteau lorrain
- other names: {"mul": "Gâteau lorrain"}
- countries: (none)
- kinds: cake, dish

## DISH Q136787113
- name: Vacherin glacé
- countries: (none)
- kinds: frozen dessert
- has Wikipedia article: en

## DISH Q136799884
- name: Хотин шуган
- other names: {"uk": "Хотин шуган"}
- countries: (none)
- cuisines: Buryat cuisine
- kinds: dish

## DISH Q136802858
- name: Khanfaroosh
- description: fried dessert flavoured with saffron and cardamom
- countries: SA, IR
- cuisines: Arab cuisine, Iranian cuisine, Emirati cuisine
- kinds: dessert, pastry, finger food
- ingredients: batter

## DISH Q136805629
- name: Მუხურის თაფლი
- other names: {"ka": "მუხურის თაფლი"}
- countries: (none)
- kinds: honey

## DISH Q136824382
- name: Pedis panas
- description: traditional food of Sasaknese
- countries: ID
- kinds: dish, traditional food, type of food or dish
- ingredients: asparagus bean, Sicyos edulis, Napa cabbage, peanut

## DISH Q136825771
- name: Підбивані лопатки
- other names: {"uk": "Підбивані лопатки"}
- countries: UA
- kinds: soup
- ingredients: ribs, onion, green bean, corned beef, potato, carrot

## DISH Q136831453
- name: Hause of cakes
- description: A pastry center in Sabon Tasha, Kaduna, Nigeria
- countries: (none)
- kinds: pastry

## DISH Q136840945
- name: Cypriot kolokasi
- description: Edible root crop traditionally cultivated in Cyprus and used in regional Cypriot cuisine
- countries: CY
- kinds: food plant, vegetable, tuber

## DISH Q136842110
- name: Mshosh
- description: Traditional Armenian dish made from lentils or beans
- countries: AM
- kinds: prepared food, dish
- ingredients: lentil, dried apricot, onion, bean, walnut

## DISH Q136842707
- name: Сушена бринза
- other names: {"uk": "Сушена бринза"}
- countries: BG, MD, UA
- kinds: Bryndza, cheese

## DISH Q136863319
- name: Borgmesterstang
- other names: {"da": "borgmesterstang"}
- countries: (none)
- kinds: Danish
- ingredients: Danish pastry dough

## DISH Q136880981
- name: Fiskekaker
- description: Norwegian fish dish
- countries: NO
- kinds: fishcake, fish dish

## DISH Q136881027
- name: Eomuk
- description: Korean fish cake
- countries: (none)
- kinds: fishcake, fish dish

## DISH Q136922
- name: Aşure
- other names: {"zh": "阿舒拉粥"}
- description: Middle Eastern dessert
- countries: (none)
- kinds: dish, dessert, porridge
- ingredients: grain, condiment, bean, Phaseolus, dried fruit, Pisum sativum, raisin, Triticum, nut, sugar, rice, water
- has Wikipedia article: en

## DISH Q136946348
- name: Sayur lebui
- description: Sasaknese traditional food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: cuisine, human food, type of food or dish
- ingredients: shrimp paste, Cajanus cajan, Scarlet-backed Flowerpecker, Alpinia galanga, table salt, sugar

## DISH Q136950129
- name: Pondu ya madesu
- other names: {"ln": "Pondu ya madesu"}
- countries: (none)
- kinds: dish

## DISH Q136953874
- name: Chicken chop
- other names: {"zh": "鸡扒"}
- description: Malaysian-styled fried or grilled chicken dish
- countries: MY
- kinds: dish
- has Wikipedia article: en

## DISH Q1369929
- name: Esterházy (Beilage)
- other names: {"de": "Esterházy (Beilage)"}
- countries: (none)
- kinds: dish

## DISH Q137008533
- name: Sweet Tuak
- description: Sasaknese traditional food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: cuisine, human food, type of food or dish

## DISH Q137008547
- name: Seaweed dodol
- description: Sasaknese traditional food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, cuisine, human food, traditional food, type of food or dish
- ingredients: glutinous rice flour, Vanilla planifolia, coconut milk, edible seaweed, dye, sugar, water

## DISH Q137008549
- name: Sasasknese Soto
- description: Sasaknese traditional food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: cuisine, human food, type of food or dish

## DISH Q137008551
- name: Chicken beberuk
- description: Sasaknese traditional food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: cuisine, human food, type of food or dish

## DISH Q137035588
- name: Steak sandwich
- description: Australian dish
- countries: AU
- kinds: sandwich
- has Wikipedia article: en

## DISH Q137039330
- name: Crousty
- countries: FR
- kinds: dish
- ingredients: fried chicken, sauce, rice

## DISH Q137064171
- name: Inasua
- countries: ID
- kinds: food, dish, fermented fish, fish dish

## DISH Q137161212
- name: Burangir
- other names: {"btm": "Burangir"}
- countries: ID
- kinds: traditional food
- ingredients: Uncaria, areca nut, betel, tobacco

## DISH Q137164363
- name: Coconut cookies
- countries: (none)
- kinds: cookie

## DISH Q137168352
- name: Jiangguotou
- description: Chinese braised pork bone dish from Northeast China
- countries: CN
- kinds: dish
- ingredients: pork bones, soy sauce, pork, spice

## DISH Q137170361
- name: Godiya spacial Bread
- description: Bread Company
- countries: (none)
- kinds: bread

## DISH Q137181279
- name: Pantrid maridad
- other names: {"lmo": "Pantrid maridad"}
- countries: IT
- kinds: dish
- ingredients: broth, egg as food, butter

## DISH Q137188021
- name: Œufs pochés à la crème d'époisses
- other names: {"fr": "œufs pochés à la crème d'époisses"}
- countries: FR
- kinds: dish
- ingredients: poached egg, Époisses, crème fraîche, white wine

## DISH Q137213270
- name: Sicilian lemon
- description: lemons cultivated in Sicily's favorable climate of warm sun, humid sea air, and fertile soil and known for their tart and acidic flavor, strong aroma, and thick, rough skin
- countries: IT
- kinds: fruit, lemon

## DISH Q137217603
- name: Ashoka Halwa
- description: Confectionery from Tamil Nadu, India
- countries: IN
- cuisines: Tamil cuisine
- kinds: sweet dish, halva
- ingredients: Vigna radiata, ghee
- has Wikipedia article: en

## DISH Q1372313
- name: Krautshäuptchen
- description: cabbage dish from northern Hesse, Germany
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1372354
- name: Botamochi
- other names: {"zh": "萩餅"}
- description: Japanese confection
- countries: JP
- kinds: mochi, wagashi, rice dish
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q137251497
- name: Goat loin
- other names: {"mul": "goat loin"}
- description: cut of goat meat
- countries: (none)
- kinds: food, goat meat

## DISH Q137267399
- name: School cake
- description: British traybake dessert
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q137270440
- name: Silaw
- other names: {"zh": "喜烙"}
- description: Taiwanese Aboriginal dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish, Category:Taiwanese aboriginal culture and history
- ingredients: pork
- has Wikipedia article: zh

## DISH Q137270645
- name: Cinavu
- other names: {"zh": "吉拿富"}
- description: Taiwanese Aboriginal dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish, Category:Taiwanese aboriginal culture and history
- ingredients: Trichodesma calycosum, Setaria italica

## DISH Q13729160
- name: Humkessoep
- description: Dutch soup
- countries: (none)
- kinds: food, soup

## DISH Q137302987
- name: Kinper
- other names: {"zh": "金伯樂"}
- countries: (none)
- kinds: mochi, dish
- ingredients: Setaria italica

## DISH Q137303325
- name: Slate Barbecue
- other names: {"zh": "石板烤肉"}
- countries: (none)
- kinds: grilled meat

## DISH Q1373466
- name: Chiffon cake
- other names: {"zh": "雪芳蛋糕"}
- description: type of cake
- countries: US
- cuisines: cuisine of the United States
- kinds: foam cake
- ingredients: cooking oil, flour, baking powder
- has Wikipedia article: en, zh

## DISH Q137361963
- name: Pihlohlo mwehng
- other names: {"de": "Pihlohlo mwehng"}
- countries: (none)
- kinds: dessert

## DISH Q1373750
- name: Yakgwa
- other names: {"zh": "药果"}
- description: Korean dessert
- countries: KR
- cuisines: Korean cuisine
- kinds: confectionery, food, yumilgwa
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q137375176
- name: Shagorana
- description: A special dish served at Bangladeshi weddings
- countries: BD
- kinds: dish, food
- has Wikipedia article: en

## DISH Q137376040
- name: Num kom
- description: Cambodian steamed rice cake
- countries: (none)
- kinds: rice cake
- has Wikipedia article: en

## DISH Q137391836
- name: Erdäpfelgulasch
- other names: {"de": "Erdäpfelgulasch"}
- countries: AT
- cuisines: Austrian cuisine
- kinds: goulash, stew, potato dish
- ingredients: onion, paprika, debrecener, potato

## DISH Q137393900
- name: Kyalla
- description: Traditional Armenian dish consisting of a roasted bull's head
- countries: AM
- kinds: dish, prepared food
- ingredients: bull's head
- has Wikipedia article: en

## DISH Q13739544
- name: Jouster pof
- other names: {"nl": "Jouster pof"}
- countries: (none)
- kinds: food, currant bun

## DISH Q137427370
- name: Varieties of biryani
- description: rice-based dishes
- countries: (none)
- kinds: biryani
- has Wikipedia article: en

## DISH Q137428052
- name: 干炸响铃
- other names: {"wuu": "干炸响铃"}
- countries: (none)
- cuisines: Hangzhou cuisine
- kinds: human food

## DISH Q13742999
- name: Kersttimp
- other names: {"nl": "kersttimp"}
- countries: (none)
- kinds: food, bread

## DISH Q13744332
- name: Knapkook
- other names: {"li": "Knapkook"}
- countries: (none)
- kinds: food, cookie

## DISH Q13744399
- name: Knipbrood
- other names: {"nl": "knipbrood"}
- countries: (none)
- kinds: bread

## DISH Q13745976
- name: Krokantbrood
- other names: {"nl": "krokantbrood"}
- countries: (none)
- kinds: bread

## DISH Q13746442
- name: Kwarktaart
- description: cheesecake with a large layer of (often sweet) cottage cheese
- countries: (none)
- kinds: cake

## DISH Q137476970
- name: Ančka
- other names: {"cs": "Ančka"}
- countries: (none)
- kinds: soup

## DISH Q137565708
- name: Klepon
- other names: {"jv": "Klepon"}
- countries: ID
- kinds: food, snack

## DISH Q137565820
- name: Cingkhui
- other names: {"id": "Cingkhui"}
- countries: ID
- kinds: food, snack

## DISH Q137565863
- name: Ie bu peudah
- countries: ID
- kinds: food, dish, type of food or dish
- has Wikipedia article: en

## DISH Q137566036
- name: Blayag
- other names: {"id": "Blayag"}
- countries: ID
- kinds: food, dish, type of food or dish
