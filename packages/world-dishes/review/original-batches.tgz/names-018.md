# Review batch names-018

## DISH Q12563760
- name: Сірне
- other names: {"kk": "Сірне"}
- description: traditional Kazakh dish
- countries: KZ
- cuisines: Kazakh cuisine
- kinds: dish, meat dish
- ingredients: wild boar meat

## DISH Q12564210
- name: Сөк
- other names: {"kk": "Сөк"}
- description: Kazakh dish
- countries: KZ
- kinds: dish
- ingredients: sorghum grain, millet, milk

## DISH Q125660200
- name: خبز الدار
- other names: {"ar": "خبز الدار"}
- countries: (none)
- kinds: dish

## DISH Q125661541
- name: Palouza
- other names: {"fr": "palouza"}
- countries: (none)
- kinds: dish

## DISH Q125681425
- name: Külçə
- other names: {"az": "külçə"}
- countries: (none)
- kinds: cookie

## DISH Q12568984
- name: Hasip
- other names: {"zh": "中亚米肠"}
- countries: (none)
- kinds: dish, sausage
- ingredients: cumin seed, mutton, onion, liver as food, tail fat, black pepper, rice

## DISH Q12569086
- name: Hime
- description: Buryat sausage made from beef
- countries: (none)
- cuisines: Buryat cuisine
- kinds: dish, sausage
- ingredients: onion, beef, flour, water

## DISH Q12569285
- name: Хушан
- other names: {"kk": "Хушан"}
- description: Tajik dish
- countries: TJ
- cuisines: Asian cuisine
- kinds: dish, stuffed pasta
- ingredients: meat

## DISH Q125700998
- name: Paratha roll
- description: street food of Pakistan
- countries: PK
- cuisines: Pakistani cuisine
- kinds: dish
- ingredients: paratha
- has Wikipedia article: en

## DISH Q12570482
- name: Шорпо
- other names: {"kk": "Шорпо"}
- description: Kyrgyz dish
- countries: KG
- kinds: dish, meat dish
- ingredients: hogget, paprika fruit, tomato, potato, onion

## DISH Q12571403
- name: Ugre
- other names: {"de": "Ugre"}
- countries: (none)
- kinds: dish

## DISH Q12572081
- name: Yuasa
- description: Bashkir national dish
- countries: (none)
- kinds: dish

## DISH Q125728421
- name: Bolo Martha Rocha
- other names: {"pt": "Bolo Martha Rocha"}
- countries: BR
- kinds: cake

## DISH Q125730878
- name: فاكهة اللوز
- other names: {"ar": "فاكهة اللوز"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: pastry, Pastries of Algeria
- ingredients: confiture, almond, flour

## DISH Q125738914
- name: Penne Siciliano
- countries: (none)
- kinds: pasta dish

## DISH Q12574039
- name: Қалжа
- other names: {"kk": "Қалжа"}
- description: Dish prepared for young women after childbirth
- countries: KZ
- cuisines: Kazakh cuisine
- kinds: dish, meat dish
- ingredients: meat

## DISH Q125744517
- name: Chiffonnade de jambon
- other names: {"fr": "chiffonnade de jambon"}
- countries: (none)
- kinds: pork dish

## DISH Q125744524
- name: Chorba beida
- other names: {"fr": "Chorba beida"}
- countries: (none)
- kinds: dish

## DISH Q125747968
- name: Cochelin d'Évreux
- other names: {"fr": "cochelin d'Évreux"}
- countries: (none)
- kinds: dish

## DISH Q125749843
- name: Coudenou
- other names: {"fr": "coudenou"}
- countries: (none)
- kinds: dish, Boudin blanc

## DISH Q12574985
- name: Қарма
- other names: {"kk": "Қарма"}
- description: Wheat flour dish
- countries: KZ
- cuisines: Kazakh cuisine
- kinds: dish, baked good
- ingredients: wheat flour

## DISH Q125750003
- name: Sop srengéngé
- other names: {"jv": "Sop srengéngé"}
- countries: ID
- kinds: human food, soup
- ingredients: Auriculariaceae, fried onion, chicken as food, egg as food, Pisum sativum, carrot

## DISH Q12575016
- name: Qarta
- description: Type of horse meat
- countries: (none)
- kinds: dish, horse meat
- ingredients: horse meat, rectum
- has Wikipedia article: en

## DISH Q125750575
- name: كسكس الحمامة
- other names: {"ar": "كسكس الحمامة"}
- countries: (none)
- kinds: dish

## DISH Q12575407
- name: Kimay
- description: Beef dish
- countries: (none)
- kinds: dish, meat dish
- ingredients: beef
- has Wikipedia article: en

## DISH Q125754246
- name: Tel'noe
- description: dish in Russian cuisine
- countries: RU
- cuisines: Russian cuisine
- kinds: dish, fish dish
- ingredients: fish fillet, chicken egg, peppercorn, wheat flour, table salt

## DISH Q125762872
- name: Sup buah (minuman Indonesia)
- other names: {"id": "sup buah (minuman Indonesia)"}
- countries: ID
- kinds: frozen dessert

## DISH Q125768378
- name: Chicken galantina
- description: Filipino stuffed chicken dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q1257791
- name: Ampyang
- description: Indonesia traditional snack made of peanut and brown sugar
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack
- ingredients: peanut, palm sugar

## DISH Q125787688
- name: Spaghetti al tonno
- other names: {"it": "spaghetti al tonno"}
- countries: (none)
- kinds: pasta dish

## DISH Q12578785
- name: Älme
- description: Kazakh dish
- countries: KZ
- kinds: dish, sweet dish
- ingredients: oil, flour, sugar

## DISH Q12579156
- name: Быжы
- other names: {"ce": "Быжы"}
- countries: KG
- cuisines: Kyrgyz cuisine
- kinds: dish, food
- ingredients: garlic, onion, bay leaf, liver as food, rice, carrot

## DISH Q125797909
- name: Dumb bread
- description: bread from United States Virgin Islands
- countries: VG, VI
- kinds: bread
- has Wikipedia article: en

## DISH Q125801330
- name: Bangude pulimunchi
- description: Mangalorean fish-based dish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q1258151
- name: Mohnzelten
- description: Sweet Austrian pastry that's a specialty of the Waldviertel region
- countries: (none)
- kinds: dish

## DISH Q125823765
- name: Glögg cup
- description: small cup for drinking glögg
- countries: (none)
- kinds: glogg, demitasse

## DISH Q12583445
- name: Geotjeori
- description: Korean pickled vegetable dish
- countries: (none)
- kinds: Kimchi

## DISH Q12584589
- name: Soboro-ppang
- description: Korean streusel bread
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q12584598
- name: Tanggu huoshao
- other names: {"zh": "糖鼓火烧"}
- description: Chinese dessert
- countries: (none)
- cuisines: Korean Chinese cuisine
- kinds: dish
- has Wikipedia article: zh

## DISH Q125848063
- name: Caldo de piranha
- description: typical dish of Brazilian cuisine
- countries: (none)
- kinds: fish dish
- ingredients: piranha

## DISH Q1258510
- name: Tirtlan PAT
- other names: {"zh": "Tirtlan PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: dish, baked good, fritter

## DISH Q12585924
- name: Gukhwa-ppang
- description: Korean snack
- countries: (none)
- kinds: pulppang
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q125861439
- name: Matambre with milk
- description: Typical uruguayan dish
- countries: UY
- kinds: dish
- ingredients: Matambre, milk

## DISH Q125863016
- name: Cigarette russe
- description: thin tubular cookies, cigarette shaped biscuits
- countries: FR, NL
- cuisines: French cuisine, cuisine of Belgium, Dutch cuisine
- kinds: cookie, side dish

## DISH Q1258670
- name: Dreught Fisch
- other names: {"de": "Dreught Fisch"}
- countries: (none)
- kinds: fish dish

## DISH Q125867352
- name: Ganmianpi
- description: A type of Chinese noodle dish
- countries: (none)
- kinds: dish

## DISH Q125876944
- name: زلابية_بوفاريك
- other names: {"ar": "زلابية_بوفاريك"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: semolina

## DISH Q125882310
- name: Odamakimushi
- countries: JP
- kinds: chawanmushi

## DISH Q125891711
- name: かき雑煮
- other names: {"ja": "かき雑煮"}
- countries: JP
- kinds: zōni

## DISH Q125891722
- name: かぶ雑煮
- other names: {"ja": "かぶ雑煮"}
- countries: JP
- kinds: zōni

## DISH Q125891751
- name: Seigaku mochi
- countries: JP
- kinds: mochi

## DISH Q125893923
- name: Brioche Tressée à la Noisette (Nusszopf)
- countries: (none)
- kinds: dish

## DISH Q125895553
- name: Caldo de zorra
- other names: {"fr": "caldo de zorra"}
- countries: (none)
- kinds: dish

## DISH Q125905146
- name: Shirako
- other names: {"fr": "Shirako"}
- countries: JP
- kinds: dish
- ingredients: milt

## DISH Q12590788
- name: Dadaegi
- countries: (none)
- kinds: condiment, Yangnyeom

## DISH Q12591047
- name: Dak-gangjeong
- description: fried chicken dish
- countries: KR
- kinds: chicken dish, Korean fried chicken

## DISH Q125911836
- name: Meltinia
- description: Cake from Santorini
- countries: GR
- kinds: food, cake

## DISH Q1259136
- name: Drisheen
- other names: {"zh": "愛爾蘭羊血腸"}
- description: type of Irish blood sausage pudding
- countries: (none)
- kinds: embutido, pudding, blood sausage
- has Wikipedia article: en

## DISH Q12591784
- name: 大田站刀削麵
- countries: KR
- kinds: culinary speciality

## DISH Q125919992
- name: Asianot
- other names: {"it": "Asianot"}
- countries: IT
- kinds: dessert, biscuit

## DISH Q125921077
- name: Montansier
- other names: {"fr": "Montansier"}
- countries: (none)
- kinds: pastry

## DISH Q12593188
- name: Don-jeonya
- description: pan-fried meat patties
- countries: (none)
- kinds: jeon

## DISH Q12593636
- name: Dwaeji-gukbap
- other names: {"zh": "猪肉汤饭"}
- description: Korean rice soup category
- countries: KR
- kinds: dish
- has Wikipedia article: en

## DISH Q125941414
- name: فانيد
- other names: {"ar": "فانيد"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish, cake, Pastries of Algeria
- ingredients: Prunus amygdalus, powdered sugar, flour

## DISH Q125942798
- name: Moraya
- description: South American freeze-dried potato product
- countries: BO, PE
- kinds: food

## DISH Q125945201
- name: Salade russe de Malmedy
- other names: {"fr": "Salade russe de Malmedy"}
- countries: (none)
- kinds: composed salad

## DISH Q125947773
- name: Pain Suisse
- description: French pastry
- countries: (none)
- kinds: viennoiserie
- has Wikipedia article: en

## DISH Q125961310
- name: Tarocco
- other names: {"fr": "tarocco"}
- countries: (none)
- kinds: dish

## DISH Q125963115
- name: Ortanique
- other names: {"fr": "Ortanique"}
- countries: (none)
- kinds: dish

## DISH Q125992703
- name: Tèrmits fregits
- other names: {"ca": "tèrmits fregits"}
- countries: (none)
- kinds: dish
- ingredients: termite, cooking oil

## DISH Q12599371
- name: 비29
- description: Korean sweet with curry flavor
- countries: KR
- kinds: confectionery

## DISH Q12599538
- name: Bingtteok
- description: dish from Jeju, South Korea
- countries: (none)
- kinds: tteok

## DISH Q125996418
- name: Savory pudding
- countries: (none)
- kinds: pudding

## DISH Q125999569
- name: Custard pudding
- countries: (none)
- kinds: budino, custard dessert

## DISH Q12600103
- name: Triangular gimbap
- description: Rice shaped into a triangle and wrapped with seaweed
- countries: KR
- kinds: onigiri, gimbap

## DISH Q126044669
- name: Mkhwani
- other names: {"ca": "Mkhwani"}
- countries: (none)
- kinds: dish
- ingredients: Cucurbita maxima

## DISH Q126076817
- name: Nthochi
- other names: {"ca": "Nthochi"}
- countries: MW
- kinds: dish

## DISH Q12608980
- name: Uja
- description: Korean food
- countries: KR
- kinds: food, jajangmyeon

## DISH Q126091181
- name: Chipa cuiabana
- other names: {"pt": "Chipa cuiabana"}
- countries: BR
- kinds: snack, bread, chipa
- ingredients: tapioca starch, chicken egg, cheese, milk

## DISH Q126098121
- name: Katirisala
- description: traditional Bugis cake that originates from the Ajatappareng region in South Sulawesi, Indonesia
- countries: ID
- kinds: dish, traditional food, type of food or dish, kue
- ingredients: brown sugar, coconut, coconut milk, glutinous rice, egg as food, table salt

## DISH Q126107460
- name: Polish croquette
- description: pancake folded with stuffing, breaded and fried in a pan
- countries: PL
- cuisines: Polish cuisine
- kinds: pancake, roll

## DISH Q126163056
- name: Cheese horses
- countries: UA
- kinds: cheese, craft

## DISH Q12616544
- name: Jesa
- description: class of dishes used for jesa rituals in Korea
- countries: (none)
- kinds: religious cuisine
- ingredients: fruit, Kimchi, alcohols

## DISH Q126171749
- name: Сяканя
- other names: {"ba": "сяканя"}
- countries: (none)
- cuisines: Mordovian cuisine
- kinds: dish

## DISH Q126174164
- name: Pineapple upside-down cake
- description: type of cake
- countries: (none)
- kinds: cake, upside-down cake
- has Wikipedia article: en

## DISH Q12618468
- name: Jjamjjamyeon
- description: Chinese-Korean noodle dish
- countries: KR
- kinds: noodle dish
- ingredients: jjamppong, jajangmyeon

## DISH Q126190581
- name: Ginseng chicken soup
- other names: {"zh": "人参鸡汤"}
- description: Soup
- countries: CN, MY
- kinds: soup
- has Wikipedia article: en, zh

## DISH Q12619366
- name: 초두부탕
- other names: {"ko": "초두부탕"}
- countries: (none)
- kinds: guk

## DISH Q12620637
- name: コンナムルクッ
- other names: {"ja": "コンナムルクッ"}
- countries: (none)
- kinds: guk
- ingredients: soybean sprout

## DISH Q12621434
- name: Padak
- other names: {"zh": "葱丝炸鸡"}
- description: South Korean chicken dish made from fried chicken and scallions
- countries: KR
- kinds: Korean fried chicken
- ingredients: chicken as food, Welsh onion
- has Wikipedia article: en

## DISH Q1262538
- name: Sherbet
- description: type of powder
- countries: (none)
- kinds: powder, confectionery
- ingredients: sugar
- has Wikipedia article: en

## DISH Q12627962
- name: Biska
- description: Spirits made from herbs
- countries: HR
- kinds: liquor, Komovica

## DISH Q126282439
- name: Huarache toluqueño
- other names: {"es": "Huarache toluqueño"}
- countries: MX
- kinds: dish

## DISH Q126284886
- name: Ila Alasepo
- description: Nigerian soup
- countries: NG
- kinds: food, soup
- has Wikipedia article: en

## DISH Q12631969
- name: Gužvara
- other names: {"hr": "Gužvara"}
- description: type of cake
- countries: (none)
- kinds: type of food or dish, cake

## DISH Q12632250
- name: Hib
- description: Croatian dessert
- countries: HR
- kinds: dessert
- ingredients: fig, almond, brandy

## DISH Q126328858
- name: Pizzasnurr
- other names: {"nb": "Pizzasnurr"}
- countries: (none)
- kinds: dish

## DISH Q12632900
- name: Imotska torta
- description: Croatian tart
- countries: HR
- kinds: tart

## DISH Q12633056
- name: Istarski pršut
- description: cured and dried ham
- countries: HR, SI
- kinds: prosciutto
- ingredients: pork thigh
- has Wikipedia article: en

## DISH Q12634585
- name: Kljukusa
- description: traditional Bosnian dish
- countries: (none)
- kinds: dish
- ingredients: potato

## DISH Q12634793
- name: Kotlovina
- description: Croatian dish
- countries: (none)
- kinds: food
- has Wikipedia article: en

## DISH Q126364815
- name: Mushroom broth
- countries: (none)
- kinds: broth, mushroom dish
- ingredients: mushroom, spice, water

## DISH Q126370082
- name: Pastasciutta antifascista
- description: Italian dish
- countries: IT
- kinds: dish
- ingredients: butter, pasta
- has Wikipedia article: en

## DISH Q12640393
- name: Pretepena juha
- description: Croatian soup
- countries: HR
- kinds: soup

## DISH Q126434266
- name: Salade hawaïenne
- description: Hawaiian-style salad with rice and fruit
- countries: US
- kinds: dish, fruit salad, rice dish

## DISH Q1265899
- name: Lachsschinken
- other names: {"de": "Lachsschinken"}
- countries: (none)
- kinds: ham

## DISH Q126598260
- name: Mango soup
- description: soup
- countries: (none)
- kinds: soup
- ingredients: mango

## DISH Q126598273
- name: Gujarati mango soup
- description: mango soup
- countries: (none)
- kinds: mango soup
- ingredients: fenugreek seed, cumin seed, coriander seed, turmeric, vegetable oil, mustard seed, besan, bird's eye chili, Murraya koenigii, chili pepper, Ferula assa-foetida, yogurt, table salt, sugar, mango

## DISH Q1266715
- name: Winzerschnitten
- other names: {"de": "Winzerschnitten"}
- description: dish
- countries: (none)
- kinds: dish

## DISH Q126681364
- name: Manqué
- description: cake
- countries: (none)
- kinds: dish, cake

## DISH Q126709310
- name: Lacto ice
- countries: (none)
- kinds: ice cream

## DISH Q126718176
- name: Pyŏngyang onban
- other names: {"zh": "平壤温饭"}
- description: North Korean dish of cooked rice and toppings with chicken broth
- countries: KP
- kinds: dish, gukbap
- ingredients: chicken soup, cooked rice

## DISH Q126736819
- name: 枣糕
- countries: (none)
- kinds: cake
- has Wikipedia article: zh

## DISH Q1267766
- name: Kasseler Brot
- other names: {"de": "Kasseler Brot"}
- countries: DE
- kinds: bread

## DISH Q126777
- name: Pasty
- other names: {"zh": "康沃尔肉馅饼"}
- description: baked pastry filled with meat or vegetables
- countries: GB
- kinds: pastry, cuisine
- has Wikipedia article: en, zh

## DISH Q126783792
- name: Batiburrillo
- description: Paraguayan dish
- countries: PY
- kinds: dish
- ingredients: sweet paprika powder, tongue as food, kidney as food, peppercorn, bell pepper, liver as food, heart as food, tripe, chili pepper, lard, oil, onion, Allium sativum, table salt, wine

## DISH Q1268122
- name: Duxelles
- description: dish used as a flavour base in other recipes consisting of finely chopped mushrooms, onions and herbs
- countries: FR
- cuisines: French cuisine
- kinds: dish, mushroom dish
- ingredients: onion, edible mushroom, herb, butter
- has Wikipedia article: en

## DISH Q12681999
- name: Acar timun
- other names: {"ms": "Acar timun"}
- countries: (none)
- kinds: dish

## DISH Q12682917
- name: Asam gumpal
- other names: {"ms": "Asam gumpal"}
- countries: MY
- kinds: Kuih

## DISH Q12684230
- name: Bosou
- description: Kadazandusun appetizer
- countries: MY
- kinds: fermented food, dish
- has Wikipedia article: en

## DISH Q12684337
- name: Bubur lambuk
- description: porridge
- countries: MY
- kinds: porridge
- has Wikipedia article: en

## DISH Q1268555
- name: Rose hip jam
- description: sweet spread made from rose hips, common to Germany and Switzerland.
- countries: (none)
- kinds: jam, food, spread, food paste
- ingredients: rose hip, sugar
- has Wikipedia article: en

## DISH Q126856764
- name: Sbriciolata
- description: Italian dessert
- countries: (none)
- kinds: cake

## DISH Q12686079
- name: Emping padi
- description: traditional snack and cultural heritage of the Malay farming community
- countries: MY
- cuisines: Malay cuisine
- kinds: rice dish
- ingredients: grain

## DISH Q126862111
- name: Petits cailloux
- other names: {"fr": "Petits cailloux"}
- description: amuse-bouche
- countries: (none)
- kinds: amuse-bouche, dish

## DISH Q126874473
- name: Soupe de Poule soie
- other names: {"fr": "soupe de Poule soie"}
- description: Chinese medicinal chicken soup
- countries: CN
- cuisines: Chinese cuisine
- kinds: chicken soup

## DISH Q126888623
- name: Lort cha
- description: Cambodian stir fry dish
- countries: (none)
- cuisines: Cambodian Chinese cuisine
- kinds: dish, food
- ingredients: silver needle noodles
- has Wikipedia article: en

## DISH Q12690604
- name: Kuih apam
- description: Traditional South and Southeast Asian steamed cake or pancake made from fermented rice batter
- countries: MY
- kinds: pancake, kue
- ingredients: rice flour, coconut milk, yeast, sugar

## DISH Q12690611
- name: Akok
- other names: {"zh": "东海岸传统糕点"}
- description: Traditional Malaysian sweet wrinkled egg pastry from Kelantan and Terengganu
- countries: MY
- cuisines: Malay cuisine
- kinds: kue, egg dish
- ingredients: wheat flour, palm sugar, coconut milk, egg as food
- has Wikipedia article: en

## DISH Q12690615
- name: Kuih bom
- countries: (none)
- kinds: Kuih

## DISH Q12690618
- name: Bunga pudak
- other names: {"ms": "bunga pudak"}
- description: traditional dessert from Kedah, Malaysia
- countries: (none)
- kinds: dessert
- ingredients: coconut, food coloring, flour, table salt, sugar

## DISH Q12690622
- name: Kuih cek mek molek
- other names: {"ms": "Kuih cek mek molek"}
- countries: MY
- kinds: Kuih

## DISH Q12690624
- name: Kuih kosui
- description: Malaysian steamed rice cake
- countries: (none)
- kinds: Kuih
- has Wikipedia article: en

## DISH Q126906240
- name: Tuggkåda
- other names: {"sv": "Tuggkåda"}
- countries: (none)
- kinds: candy

## DISH Q12690627
- name: Nekbat
- description: Malay kuih
- countries: MY
- kinds: Kuih

## DISH Q12690634
- name: Kuih tepung kapur
- other names: {"ms": "Kuih tepung kapur"}
- countries: MY
- cuisines: Malay cuisine
- kinds: Kuih

## DISH Q126907616
- name: Taco de chicharra
- other names: {"es": "taco de chicharra"}
- countries: MX
- kinds: food
- ingredients: tortilla, chicharrón, chili pepper, tomato, pig

## DISH Q126910292
- name: Zalewajka z Rogowa
- other names: {"pl": "Zalewajka z Rogowa"}
- countries: PL
- kinds: soup

## DISH Q12691235
- name: Laksam
- description: Meal in Malaysia
- countries: MY
- cuisines: Malay cuisine
- kinds: noodle dish
- ingredients: rice flour

## DISH Q126914195
- name: Widerbergare
- countries: (none)
- kinds: sandwich
- ingredients: roast beef

## DISH Q126919465
- name: Bacon-wrapped enoki
- description: dish made of enoki mushrooms wrappend in bacon
- countries: (none)
- kinds: bacon-wrapped food, mushroom dish

## DISH Q126938440
- name: 走り井餅
- other names: {"ja": "走り井餅"}
- countries: (none)
- kinds: wagashi

## DISH Q126943933
- name: Hobak-yeot
- countries: (none)
- kinds: yeot

## DISH Q126946571
- name: Smiley fritz
- description: South Australian sliced sausage
- countries: AU
- kinds: human food, sausage
- has Wikipedia article: en

## DISH Q126956532
- name: Saikouk
- description: traditional Moroccan meal, consisting of barley or wheat, then buttermilk
- countries: MA
- cuisines: Berber (Amazigh) cuisine, Moroccan cuisine
- kinds: food, flour-based food
- ingredients: barley, wheat, buttermilk

## DISH Q126961970
- name: Dal Tadka
- description: Indian dish
- countries: IN
- kinds: dish, dal
- has Wikipedia article: en

## DISH Q12698743
- name: Chicken rice ball
- description: Chinese food
- countries: (none)
- cuisines: Peranakan cuisine
- kinds: chicken dish
- ingredients: chicken as food, rice

## DISH Q12700644
- name: Pinaasakan
- description: Kadazandusun traditional fish dish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q12701417
- name: Pulut panggang
- other names: {"zh": "烤香辣糯米饭"}
- description: Traditional Malaysian grilled banana leaf-wrapped glutinous rice roll filled with spicy coconut or prawn floss
- countries: MY
- cuisines: Malay cuisine
- kinds: glutinous rice, rice dish
- ingredients: Shrimp, grated coconut, banana leaf, coconut milk, glutinous rice

## DISH Q127037926
- name: Bubur ase
- description: type of porridge
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, congee
- ingredients: Semur, asinan, congee, rice, water

## DISH Q1270535
- name: Waldviertler
- description: type of sausage
- countries: AT
- kinds: sausage
- has Wikipedia article: en

## DISH Q12709581
- name: Soto Padang
- description: Indonesian dish
- countries: ID
- cuisines: Indonesia
- kinds: fast food, street food, soto, jajan pasar, dish, type of food or dish
- ingredients: lime wedge, garlic, manis, ginger, rice vermicelli, beef, water
- has Wikipedia article: en

## DISH Q12709593
- name: Spaghetti bolognese
- description: pasta dish
- countries: (none)
- kinds: pasta dish
- ingredients: bolognese sauce, spaghetti
- has Wikipedia article: en

## DISH Q12711188
- name: Tahu campur
- description: Lamongan tofu dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: tofu, type of food or dish, dish, human food
- ingredients: kecap, shallot, Kaffir Lime Leaf, garlic, petis, mung bean sprout, lontong, noodle, beef, tofu, Curcuma longa, Cymbopogon citratus, Carum carvi, sugar
- has Wikipedia article: en

## DISH Q1271177
- name: Döppekooche
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q12713735
- name: Betasuppe
- other names: {"nb": "betasuppe"}
- countries: (none)
- kinds: soup

## DISH Q12713819
- name: Blanklefse
- description: Type of flatbread
- countries: NO
- cuisines: Norwegian cuisine
- kinds: lefse, baked good
- ingredients: rye flour, skimmed milk, wheat flour

## DISH Q12715233
- name: Haglette
- description: Food made from milk
- countries: NO
- kinds: dish
- ingredients: cow's milk

## DISH Q12716458
- name: Lauvsteik
- description: Dish typically served at various food outlets such as gas stations, roadside taverns, and other serving locations
- countries: NO
- cuisines: Norwegian cuisine
- kinds: fast food, dish
- ingredients: fries, meat

## DISH Q127164636
- name: Loimulohi
- description: Finnish fish dish
- countries: (none)
- kinds: loimukala
- has Wikipedia article: en

## DISH Q127165110
- name: Таўканіца
- other names: {"be": "Таўканіца"}
- countries: (none)
- kinds: dish, purée, kasha
- ingredients: salo, onion, table salt, potato

## DISH Q12717245
- name: American pancake
- countries: (none)
- kinds: pancake

## DISH Q127256854
- name: Sándwich York
- description: Chilean ham and egg sandwich
- countries: CL
- kinds: sandwich, ham sandwich, egg dish, meal
- ingredients: black pepper, ham, egg as food, oil, table salt

## DISH Q127271189
- name: Chemilico
- description: meat and fried egg sandwich
- countries: CL
- kinds: sandwich, meal
- ingredients: black pepper, egg as food, oil, table salt, meat

## DISH Q12728629
- name: Frupt
- other names: {"ro": "Frupt"}
- countries: (none)
- kinds: dish

## DISH Q12729772
- name: Gâscă (mâncare)
- other names: {"ro": "Gâscă (mâncare)"}
- countries: (none)
- kinds: dish

## DISH Q127316296
- name: Black Lovers
- countries: JP
- kinds: Western confection
- ingredients: black soybean, corn kernel, chocolate

## DISH Q127344726
- name: AirHeads 9 Bars
- description: 9-bar pack of AirHeads
- countries: (none)
- kinds: AirHeads, candy, multi-pack
- ingredients: AirHeads Pink Lemonade, AirHeads White Mystery, AirHeads Blue Raspberry, AirHeads Watermelon, AirHeads Cherry

## DISH Q127344987
- name: AirHeads 6 Bars
- description: 6-bar pack of AirHeads
- countries: (none)
- kinds: AirHeads, candy, multi-pack
- ingredients: AirHeads White Mystery, AirHeads Blue Raspberry, AirHeads Orange, AirHeads Grape, AirHeads Watermelon, AirHeads Cherry

## DISH Q127345419
- name: AirHeads 5 Bars
- description: 5-bar pack of AirHeads
- countries: (none)
- kinds: AirHeads, candy, multi-pack
- ingredients: AirHeads Citrus Rush, AirHeads White Mystery, AirHeads Blue Raspberry, AirHeads Strawberry, AirHeads Watermelon, AirHeads Cherry

## DISH Q12738131
- name: Plachie
- other names: {"ro": "Plachie"}
- countries: (none)
- kinds: dish

## DISH Q127388
- name: Veka
- description: Eastern European bread
- countries: (none)
- kinds: white bread
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q12740865
- name: Silvoiță
- other names: {"ro": "silvoiță"}
- countries: RO
- kinds: spread, fruit preserves
- ingredients: Prunus domestica

## DISH Q127420779
- name: Porridge yam
- description: yam recipe that's eaten by most tribe in Nigeria
- countries: NG
- kinds: food, dish
- ingredients: yam, seasoning, palm oil, Allium, vegetable

## DISH Q127420982
- name: Tarte vigneronne
- other names: {"fr": "tarte vigneronne"}
- countries: (none)
- kinds: tart
- ingredients: puff pastry, apple

## DISH Q127420994
- name: Confiture de vin de Chinon
- other names: {"fr": "confiture de vin de Chinon"}
- countries: (none)
- kinds: confiture

## DISH Q127433632
- name: Alivongvong
- other names: {"zh": "阿里鳳鳳"}
- description: Taiwanese Aboriginal dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: food, Category:Taiwanese aboriginal culture and history, dish
- ingredients: Pandanus tectorius, Oryza molida
- has Wikipedia article: en

## DISH Q127434113
- name: Весна
- other names: {"ru": "Весна"}
- countries: (none)
- cuisines: Soviet cuisine
- kinds: salad, dish

## DISH Q12743560
- name: Virșli
- countries: RO
- kinds: sausage, food
- ingredients: mutton, goat meat, beef

## DISH Q12744663
- name: Bajamak
- other names: {"sr": "Bajamak"}
- countries: (none)
- kinds: dish

## DISH Q127460400
- name: Chhena Mandua
- description: Indian dessert
- countries: IN
- kinds: dessert

## DISH Q127477120
- name: Barbacue
- description: Nigerian delicious cusine which includes meat and fish
- countries: (none)
- kinds: delicacy
- ingredients: brown sugar, paprika, apple cider vinegar, table salt, water

## DISH Q127505297
- name: Anischräbeli
- other names: {"de": "Anischräbeli"}
- countries: (none)
- kinds: pastry

## DISH Q127505622
- name: Jenamani
- description: Indian dessert
- countries: IN
- kinds: dessert

## DISH Q127509818
- name: Salade vosgienne
- countries: (none)
- kinds: dish

## DISH Q127513241
- name: Honeydew honey
- description: honey made by bees using honeydew
- countries: (none)
- kinds: honey
- has Wikipedia article: en

## DISH Q127513534
- name: Porridge beans
- description: Nigerians highly proteinous food
- countries: (none)
- kinds: dish, food
- ingredients: bean, palm oil, Capsicum, Allium, table salt

## DISH Q127514863
- name: Mafalda (cucina)
- other names: {"it": "Mafalda (cucina)"}
- countries: (none)
- kinds: bread, Sicilian cuisine

## DISH Q12752003
- name: Zlatiborska pršuta
- description: Serbian smoked ham
- countries: RS
- kinds: prosciutto, meat product

## DISH Q127532457
- name: Khuruma
- description: item offered to Lord Jagannath as Chhapan Bhog
- countries: IN
- kinds: dessert

## DISH Q1275331
- name: Oxtail
- other names: {"zh": "牛尾"}
- description: tail of an ox
- countries: (none)
- kinds: meat, tail, cut of beef, dish
- has Wikipedia article: en, zh

## DISH Q1275345
- name: Schöberl
- other names: {"de": "Schöberl"}
- countries: (none)
- kinds: dish

## DISH Q12754541
- name: Lenja pita
- description: Montenegrin and Serbian dessert
- countries: (none)
- kinds: cake, kolach

## DISH Q1275518
- name: Kilishi
- other names: {"zh": "給力希"}
- description: Hausa dish of spiced dried beef, mutton or goat meat
- countries: NE, NG
- kinds: dish, human nutrition, human food
- ingredients: onion, beef, table salt, cayenne pepper
- has Wikipedia article: en

## DISH Q12757321
- name: Plazma cake
- description: soft cake made with Plazma biscuits
- countries: (none)
- kinds: cake

## DISH Q12758929
- name: Slavski kolač
- description: Serbian celebration cake
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q127599395
- name: Radhaballav
- description: item offered to Lord Jagannath as Chhapan Bhog
- countries: IN
- kinds: dessert

## DISH Q127606236
- name: Hansakeli
- description: item offered to Lord Jagannath as Chhapan Bhog
- countries: IN
- kinds: dessert

## DISH Q12761030
- name: Cicvara
- description: traditional meal
- countries: BA, ME, RS
- kinds: food
- ingredients: maize, kaymak

## DISH Q127685020
- name: Гусарская печень
- other names: {"ru": "Гусарская печень"}
- countries: RU
- cuisines: Russian cuisine
- kinds: meat dish

## DISH Q127685368
- name: Skoblyanka
- description: Russian dish made with meat, potatoes and mushrooms
- countries: RU
- cuisines: Russian cuisine
- kinds: dish, meat dish
- ingredients: potato, veal, edible mushroom

## DISH Q127688644
- name: Грибы в сметане
- other names: {"ru": "Грибы в сметане"}
- countries: RU
- cuisines: Russian cuisine
- kinds: dish
- ingredients: edible mushroom, smetana, onion

## DISH Q12777734
- name: Treszka
- other names: {"hu": "Treszka"}
- countries: (none)
- kinds: salad

## DISH Q12784236
- name: Aleluja
- description: turnip peels soup
- countries: SI
- kinds: soup

## DISH Q12785386
- name: Bakalca
- description: Dish of mutton and vegetables
- countries: SI
- kinds: dish
- ingredients: mutton, vegetable

## DISH Q12785648
- name: Belokranjska pogača
- description: Slovene flatbread
- countries: SI
- kinds: flatbread, focaccia
- ingredients: cumin seed, farina, egg as food, yeast, table salt, water

## DISH Q1278785
- name: Kibbeling
- other names: {"zh": "炸魚塊"}
- description: Dutch seafood snack, consisting of chunks of deep-fried cod or other fish
- countries: (none)
- kinds: snack, fish dish
- has Wikipedia article: en, zh

## DISH Q1278788
- name: Panforte
- description: dessert from Siena, Italy
- countries: IT
- kinds: fruitcake, Christmas dessert
- ingredients: nut
- has Wikipedia article: en

## DISH Q1278795
- name: Potthucke
- description: potato dish
- countries: (none)
- kinds: casserole, potato casserole

## DISH Q127975406
- name: Sal de Maras
- other names: {"es": "Sal de Maras"}
- countries: PE
- kinds: table salt, practice, product
- ingredients: table salt

## DISH Q12799268
- name: Posolanka
- description: Slovenian dish
- countries: SI
- cuisines: Slovenian cuisine
- kinds: pastry, dish

## DISH Q128006259
- name: Dal Pitha
- description: Bihari dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q128034120
- name: Trolli Apple Rings
- description: Sour-tasting fruit gums with apple flavor
- countries: (none)
- kinds: sweetmeat

## DISH Q12806195
- name: Vrtanek
- description: Slovenian braided bread
- countries: SI
- kinds: food, bread
- has Wikipedia article: en

## DISH Q12806669
- name: Zgornjesavinjski želodec
- description: Slovene cured meat
- countries: SI
- kinds: meat dish, dried meat

## DISH Q12808559
- name: Arnavut ciğeri
- description: Turkish cold platter (meze) made of liver
- countries: TR
- kinds: dish
- has Wikipedia article: en

## DISH Q12809407
- name: Stuffed artichoke
- description: artichoke dishes made by filling the flower
- countries: TR
- kinds: dish, food
- ingredients: globe artichoke, olive oil

## DISH Q12809408
- name: Artichoke rechel
- description: "reçel" (Turkish style jam or murabba) made with artichokes
- countries: TR
- kinds: food

## DISH Q12810864
- name: Stuffed mussels
- description: stuffed mussels, Turkish style
- countries: TR
- kinds: rice dish
- has Wikipedia article: en

## DISH Q12811344
- name: Badımcan çığırtması
- description: eggplant and egg dish
- countries: AZ
- kinds: dish, food

## DISH Q12812242
- name: Torpedo dessert
- description: buttery, flaky viennoiserie bread roll
- countries: BG, TR
- kinds: dessert, viennoiserie, dish
- ingredients: baker's yeast, dough, butter
- has Wikipedia article: en

## DISH Q12812711
- name: Zerde
- other names: {"zh": "番紅花米布丁"}
- description: Iranian cuisine dessert
- countries: TR
- kinds: pudding, food
- ingredients: pistachio nut, rose water, saffron, raisin, sugar, rice, water
- has Wikipedia article: en, zh

## DISH Q12812820
- name: Chigirtma
- description: Azeri cuisine egg dish
- countries: AZ
- kinds: egg dish, food
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q12812924
- name: Izmir bomb
- description: Turkish dessert
- countries: TR
- kinds: dessert
- has Wikipedia article: en

## DISH Q12812990
- name: Urfa biber
- description: dried and processed red pepper spice from Şanlıurfa, Turkey
- countries: TR
- cuisines: Şanlıurfa cuisine
- kinds: crushed red pepper, spice
- ingredients: chili pepper
- has Wikipedia article: en

## DISH Q12813066
- name: Şevketibostan yemeği
- description: Turkish lamb dish
- countries: (none)
- kinds: food, lamb dish, vegetable dish
- ingredients: dandelion, lamb meat
- has Wikipedia article: en

## DISH Q12814360
- name: Fumu
- other names: {"hu": "fumu"}
- countries: (none)
- kinds: kalach

## DISH Q12817265
- name: Shakarap
- description: salad from Central Asia
- countries: KG, TJ, UZ
- cuisines: Kazakh cuisine, Cuisine of Uzbekistan, Tajik cuisine, Kyrgyz cuisine
- kinds: salad
- ingredients: tomato, onion, table salt, garlic, Allium, Anethum graveolens
- has Wikipedia article: en

## DISH Q12821
- name: Milanesa
- other names: {"zh": "米蘭炸肉排"}
- description: breaded cutlet dish
- countries: IT
- cuisines: Italian cuisine
- kinds: meal, meat dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q12822374
- name: Gijda
- description: Type of bread
- countries: (none)
- kinds: baked good, bread
- ingredients: baker's yeast, flour

## DISH Q128239140
- name: Naute
- other names: {"de": "Naute"}
- countries: (none)
- kinds: confectionery

## DISH Q12824052
- name: Jizza
- description: Uzbek food
- countries: UZ
- kinds: food
- ingredients: fat

## DISH Q128257664
- name: Spaghetti
- description: food dish containing spaghetti. For the variety of pasta see Q20026
- countries: (none)
- kinds: dish, pasta dish
- ingredients: spaghetti

## DISH Q12827502
- name: Miyoncha
- description: dessert
- countries: (none)
- kinds: dessert, type of food or dish

## DISH Q12829823
- name: Patir
- description: Type of bread
- countries: (none)
- kinds: baked good, bread
- ingredients: baker's yeast, flour, sodium chloride

## DISH Q12835574
- name: Alana
- description: food from Azerbaijan
- countries: AZ
- kinds: fare
- ingredients: pear, nut

## DISH Q12837200
- name: Badambura
- description: Azerbaijani almond pastry
- countries: AZ
- cuisines: Azerbaijani cuisine
- kinds: pastry
- ingredients: almond
- has Wikipedia article: en

## DISH Q12838065
- name: Mchadi
- description: Georgian bread
- countries: GE
- cuisines: Georgian cuisine
- kinds: flatbread
- ingredients: maize flour
- has Wikipedia article: en

## DISH Q1283824
- name: Nộm
- description: Vietnamese salad
- countries: (none)
- kinds: salad
- has Wikipedia article: en

## DISH Q12839883
- name: Azeri herb kuku
- description: Turkish type of kuku recipe
- countries: (none)
- kinds: food, kuku

## DISH Q12841103
- name: Kömbe
- description: kind of sweet bread, or çörek
- countries: TR
- kinds: food, dish
- has Wikipedia article: en

## DISH Q12844474
- name: قوغال
- other names: {"ar": "قوغال"}
- countries: (none)
- kinds: cookie

## DISH Q12845074
- name: Salçalı biftek
- description: beef or veal dish from the Turkish cuise, the steak is first fried, then covered with a tomato-based sauce and cooked either in the oven or in a pan
- countries: (none)
- kinds: dish
- ingredients: tomato

## DISH Q12845878
- name: Soyutma
- description: soup from the Caucasus that is Azerbaijan's national dish
- countries: (none)
- kinds: soup
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q12848581
- name: Çiyələk piroqu
- other names: {"az": "Çiyələk piroqu"}
- countries: (none)
- kinds: börek

## DISH Q12848613
- name: Çudu
- description: thin stuffed flatbread, national dish in Dagestan
- countries: (none)
- kinds: pie
- ingredients: yeast dough, lamb meat, herb, beef

## DISH Q1284887
- name: Red velvet cake
- other names: {"zh": "红色天鹅绒蛋糕"}
- description: chocolate cake
- countries: US
- kinds: dish, layer cake
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q12849581
- name: Çörek
- description: Turkish teatime bread, generally sweet
- countries: TR
- kinds: pastry, dish
- has Wikipedia article: en

## DISH Q12850403
- name: Əyirdək
- other names: {"az": "Əyirdək"}
- description: type of dough
- countries: AZ
- cuisines: Azerbaijani cuisine
- kinds: dough, food paste
- ingredients: cow's milk, flour, sugar

## DISH Q12850447
- name: Əzmə
- description: Azerbaijani meal
- countries: AZ
- kinds: dish
- ingredients: liver as food

## DISH Q1285427
- name: Knackwurst
- description: type of sausage
- countries: DE
- kinds: sausage, Brühwurst
- has Wikipedia article: en

## DISH Q12859415
- name: Pot Noodle
- description: brand of instant noodle snack foods
- countries: (none)
- kinds: cup noodle
- has Wikipedia article: en

## DISH Q12862169
- name: Adjarian khachapuri
- countries: (none)
- kinds: khachapuri

## DISH Q12866
- name: Sabre St. Simon
- description: sword-shaped cake
- countries: ES
- kinds: cookie, Tortell

## DISH Q1286804
- name: Makkaraperunat
- description: street food
- countries: FI
- kinds: dish
- ingredients: condiment, fries, sausage
- has Wikipedia article: en

## DISH Q128713376
- name: Fruit bat soup
- countries: PW
- kinds: soup, type of food or dish
- ingredients: bat, ginger, coconut milk, spice

## DISH Q12874138
- name: Astakomakaronada
- description: Greek pasta dish with lobster
- countries: GR
- kinds: pasta dish
- ingredients: lobster

## DISH Q128752600
- name: Galleta de sal
- description: Cuban cracker
- countries: CU
- cuisines: Cuban cuisine
- kinds: food

## DISH Q1287602
- name: Liegnitzer Bomben
- countries: (none)
- kinds: pryanik

## DISH Q128791403
- name: Polacca aversana
- other names: {"it": "polacca aversana"}
- countries: IT
- kinds: dessert, type of food or dish

## DISH Q1287919
- name: Roti jala
- description: type of pancake that looks like lace originating from Johor history
- countries: MY
- cuisines: Malay cuisine
- kinds: desert, crêpe, pancake
- ingredients: turmeric, wheat flour, coconut milk, egg as food
- has Wikipedia article: en

## DISH Q128803497
- name: Pastas de pescado
- other names: {"es": "Pastas de pescado"}
- countries: (none)
- kinds: pasta

## DISH Q128804541
- name: Hot soup
- description: soup eaten while hot
- countries: (none)
- kinds: dish, soup

## DISH Q12880652
- name: Μανιταρόπιτα
- other names: {"el": "Μανιταρόπιτα"}
- countries: (none)
- kinds: pastry
- ingredients: phyllo, mushroom

## DISH Q12880790
- name: Mahalepi
- description: Cypriot dessert
- countries: (none)
- kinds: dessert, dish
- ingredients: rose water, mahleb, flour, sugar, drinking water

## DISH Q12881337
- name: Bouyiourdi
- description: Greek dish of baked feta
- countries: GR
- cuisines: Greek cuisine
- kinds: dish, meze
- ingredients: feta, olive oil, Capsicum annuum, tomato
- has Wikipedia article: en

## DISH Q12884619
- name: Spetsofai
- description: Greek sausage dish
- countries: GR
- kinds: meat dish
- ingredients: tomato sauce, loukaniko, bell pepper

## DISH Q12884882
- name: Strapatsada
- description: Greek dish with eggs and tomatoes
- countries: GR
- kinds: dish
- ingredients: egg as food, tomato, feta, olive oil, table salt, Capsicum annuum
- has Wikipedia article: en

## DISH Q12885736
- name: Fasolakia
- description: Greek green bean dish
- countries: GR
- kinds: dish
- ingredients: green bean

## DISH Q128882024
- name: Jolly Rancher Cherry
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128882095
- name: Jolly Rancher Green Apple
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128882129
- name: Jolly Rancher Blue Raspberry
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128882158
- name: Jolly Rancher Grape
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128882198
- name: Jolly Rancher Watermelon
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128882269
- name: Jolly Rancher Lemon
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128882427
- name: Jolly Rancher Strawberry
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128882577
- name: Jolly Rancher Peach
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128882613
- name: Jolly Rancher Orange
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128882707
- name: Jolly Rancher Fruit Punch
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128882967
- name: Jolly Rancher Mountain Berry
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883042
- name: Jolly Rancher Pineapple
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883136
- name: Jolly Rancher Sour Cherry
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883163
- name: Jolly Rancher Sour Green Apple
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883192
- name: Jolly Rancher Sour Blue Raspberry
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883228
- name: Jolly Rancher Sour Watermelon
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883252
- name: Jolly Rancher Sour Wild Strawberry
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883353
- name: Jolly Rancher Raspberry
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883474
- name: Jolly Rancher Wild Strawberry
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883508
- name: Jolly Rancher Strawberry-Watermelon
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883567
- name: Jolly Rancher Raspberry Lemonade
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883700
- name: Jolly Rancher Strawberry Smoothie
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883735
- name: Jolly Rancher Watermelon Smoothie
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883760
- name: Jolly Rancher Peach Smoothie
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883786
- name: Jolly Rancher Orange Smoothie
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883823
- name: Jolly Rancher Mixed Berry Smoothie
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128883904
- name: Jolly Rancher Cinnamon Fire!
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128884006
- name: Jolly Rancher Mango
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128884042
- name: Jolly Rancher Golden Pineapple
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128884069
- name: Jolly Rancher Lime
- description: flavor of Jolly Rancher hard candy
- countries: (none)
- kinds: hard candy, Jolly Rancher

## DISH Q128903900
- name: Khanom phra phai
- description: Thai traditional dessert
- countries: TH
- kinds: dessert
