# Review batch names-047

## DISH Q56232108
- name: Prol tape
- other names: {"jv": "prol tape"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, confectionery

## DISH Q56232120
- name: Rawon nguling
- other names: {"jv": "Rawon nguling"}
- description: traditional cuisine
- countries: ID
- kinds: food, rawon, soup

## DISH Q56232129
- name: Roko-Roko Cangkuning
- other names: {"id": "Roko-Roko Cangkuning"}
- countries: ID
- kinds: dish

## DISH Q56232138
- name: Eel rujak
- description: Indonesian spicy eel salad
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: shallot, turmeric rhizome, garlic, coriander seed, eel as food, cooking oil, table salt

## DISH Q56232192
- name: Pecel Gudeg
- other names: {"id": "Pecel Gudeg"}
- countries: ID
- kinds: food

## DISH Q56232200
- name: Pelasan uceng
- description: steamed freshwater loach in banana leaves
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, pepes
- ingredients: Arrow loach

## DISH Q56232215
- name: Pindang patin
- description: iridescent shark soup
- countries: ID
- cuisines: Indonesian cuisine, Palembang cuisine
- kinds: dish
- ingredients: garlic, onion, Alpinia galanga, iridescent shark, chili pepper

## DISH Q56232224
- name: Pothil
- description: Indonesian snack made of cassava flour
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, cracker
- ingredients: garlic, coriander seed, cassava flour, cassava, table salt

## DISH Q56232266
- name: Pork satay
- description: traditional food from Bali, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay
- ingredients: shallot, garlic, coriander seed, kecap manis, soy sauce, pork, table salt

## DISH Q56232277
- name: Goat Satay
- description: is a traditional Indonesian dish made from tender meat of a young goat
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay

## DISH Q56232291
- name: Rabbit satay
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, satay
- ingredients: kecap, shallot, garlic, coriander seed, peanut, rabbit meat, palm sugar, Curcuma longa

## DISH Q56232342
- name: Soto Bebek
- other names: {"id": "Soto Bebek"}
- countries: (none)
- kinds: soto, food

## DISH Q56232343
- name: Soto Bogor
- description: Indonesian soup
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, soup
- ingredients: cauliflower, garlic, ginger, Cymbopogon, bay leaf, Alpinia galanga, Allium ascalonicum, beef, chili pepper, table salt, sugar

## DISH Q56232344
- name: Soto Daging Bening
- other names: {"id": "Soto Daging Bening"}
- countries: (none)
- kinds: soto, food

## DISH Q56232345
- name: Soto Daging Pak Amir Tunjungtirto
- other names: {"id": "Soto Daging Pak Amir Tunjungtirto"}
- countries: (none)
- kinds: soto, food

## DISH Q56232346
- name: Soto kambing Tunggulwulung
- other names: {"id": "Soto kambing Tunggulwulung"}
- countries: (none)
- kinds: soto, food

## DISH Q56232348
- name: Soto Kecapan
- other names: {"id": "Soto Kecapan"}
- countries: (none)
- kinds: soto, food

## DISH Q56232349
- name: Soto Kendal
- other names: {"id": "Soto Kendal"}
- countries: (none)
- kinds: soto, food

## DISH Q56232350
- name: Soto Klethuk
- other names: {"id": "Soto Klethuk"}
- countries: (none)
- kinds: soto, food

## DISH Q56232351
- name: Soto Kwali
- other names: {"id": "Soto Kwali"}
- countries: (none)
- kinds: soto, food

## DISH Q56232352
- name: Soto Kwali Klaten
- other names: {"id": "Soto Kwali Klaten"}
- countries: (none)
- kinds: soto, food

## DISH Q56232353
- name: Soto Pamekasan
- other names: {"id": "Soto Pamekasan"}
- countries: (none)
- kinds: soto, food

## DISH Q56232354
- name: Soto Sadang
- other names: {"id": "Soto Sadang"}
- countries: (none)
- kinds: soto, food

## DISH Q56232356
- name: Soto tegal
- other names: {"id": "Soto tegal"}
- countries: (none)
- kinds: soto, food

## DISH Q56232363
- name: Tofu stick
- description: traditional food from Kediri, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, tofu, cracker

## DISH Q56232372
- name: Sompil
- description: traditional food from Trenggalek, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, rice dish

## DISH Q56232374
- name: Sop ayam
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, soup
- ingredients: shallot, Kaffir Lime Leaf, ginger, chicken as food, Cymbopogon citratus, Apium graveolens, carrot

## DISH Q56232377
- name: Sop senerek
- description: Indonesian soup
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, soup
- ingredients: chicken stock, spinach, kidney bean, chicken as food, scallion, Apium graveolens, carrot

## DISH Q56232379
- name: Soto Ayam Kampung Tulungagung
- other names: {"id": "Soto Ayam Kampung Tulungagung"}
- countries: (none)
- kinds: soto, food

## DISH Q56232430
- name: Tape ketan ireng
- other names: {"jv": "tape ketan ireng"}
- countries: ID
- cuisines: Indonesian cuisine, cuisine
- kinds: dish, human food, type of food or dish, Tapai, Ketanireng

## DISH Q56235994
- name: Tteokmyeon
- countries: (none)
- kinds: Garae-tteok

## DISH Q56236136
- name: Sun-dubu
- description: extra soft tofu
- countries: (none)
- kinds: tofu

## DISH Q5623917
- name: Gyabrag
- description: Pancake in Tibetan cuisine
- countries: (none)
- kinds: food, pancake
- ingredients: barley
- has Wikipedia article: en

## DISH Q5624090
- name: Gyeran-jjim
- other names: {"zh": "雞卵蒸"}
- description: Korean custardy dish based on steamed eggs
- countries: (none)
- kinds: egg dish
- ingredients: egg
- has Wikipedia article: en

## DISH Q56241382
- name: Gersten
- other names: {"de": "Gersten"}
- countries: (none)
- kinds: dish

## DISH Q56250611
- name: Confectionery
- countries: (none)
- kinds: sweetmeat

## DISH Q5625377
- name: Gypsy tart
- description: Tart that Originated in Kent, United Kingdom
- countries: (none)
- kinds: tart
- ingredients: pastry
- has Wikipedia article: en

## DISH Q56253895
- name: Kkori-gomtang
- other names: {"zh": "牛尾湯"}
- description: oxtail soup in Korean cuisine
- countries: (none)
- kinds: oxtail soup, gomguk
- ingredients: oxtail
- has Wikipedia article: zh

## DISH Q56257612
- name: Αλιάδα
- other names: {"el": "Αλιάδα"}
- countries: (none)
- kinds: skordalia

## DISH Q56257632
- name: Αυγοκαλάμαρα
- other names: {"el": "Αυγοκαλάμαρα"}
- countries: GR
- kinds: confectionery

## DISH Q56257633
- name: Αρμεξιά
- other names: {"el": "Αρμεξιά"}
- countries: GR
- kinds: Greek cheese
- ingredients: sheep milk, goat milk

## DISH Q56259008
- name: Ganghoe
- description: Korean fish and vegetable dish
- countries: (none)
- kinds: hoe
- has Wikipedia article: en

## DISH Q56260022
- name: Eel Noodles
- other names: {"zh": "鱔魚意麵"}
- description: Taiwanese eel dish
- countries: TW
- kinds: meat dish
- ingredients: ì-mī, yi mein, eel as food, Monopterus albus
- has Wikipedia article: en, zh

## DISH Q5626815
- name: Güirila
- description: maize tortilla
- countries: NI
- kinds: food, bread
- has Wikipedia article: en

## DISH Q56278726
- name: Tihlo
- description: Ethiopian snack
- countries: ET
- kinds: dish
- has Wikipedia article: en

## DISH Q56280821
- name: Maraq
- description: broth soup
- countries: SO
- kinds: soup
- has Wikipedia article: en

## DISH Q56292893
- name: Brown shrimp as food
- description: flesh from Crangon crangon
- countries: (none)
- kinds: shrimp and prawn as food, dish
- has Wikipedia article: en

## DISH Q56294997
- name: Veal stew
- countries: (none)
- kinds: dish

## DISH Q56295002
- name: Blanne Jang
- other names: {"de": "Blanne Jang"}
- countries: (none)
- kinds: dish

## DISH Q56295510
- name: Hühnerspießchen
- other names: {"de": "Hühnerspießchen"}
- countries: (none)
- kinds: dish

## DISH Q56296735
- name: Rolled roast
- description: meat dish
- countries: DE
- kinds: meat dish, roll

## DISH Q56297456
- name: Weltmeisterbrot
- other names: {"de": "Weltmeisterbrot"}
- description: FIFA world cup related bread type in Germany
- countries: DE
- kinds: bread

## DISH Q56297683
- name: Wine soup
- description: soup
- countries: (none)
- kinds: soup, dish

## DISH Q56297948
- name: Fruchtkaramelle
- other names: {"de": "Fruchtkaramelle"}
- countries: (none)
- kinds: candy
- ingredients: glucose syrup, sugar

## DISH Q56299640
- name: Loukoumades
- description: Greek fried dough dessert
- countries: GR
- kinds: dessert
- ingredients: baker's yeast, olive oil, cinnamon, sugar, honey, milk, water

## DISH Q56299804
- name: Tahlia
- other names: {"fr": "tahlia"}
- countries: (none)
- kinds: dish

## DISH Q56299924
- name: Witte pens
- other names: {"nl": "witte pens"}
- countries: BE
- kinds: regional product, pork dish, sausage
- ingredients: pork, egg as food, milk, bread

## DISH Q56299959
- name: Arroz doce
- other names: {"fr": "Arroz doce"}
- countries: (none)
- kinds: dessert
- ingredients: Sucre en poudre, egg yolk, cinnamon, milk, rice

## DISH Q56300018
- name: مبرجة
- other names: {"ar": "مبرجة"}
- countries: (none)
- kinds: cake

## DISH Q56300140
- name: Akassa
- description: type of dough made from cooked, ground and soaked corn, eaten in Benin, Nigeria, Burkina Faso, Togo and Côte d'Ivoire
- countries: BF, BJ, CI, NG, TG
- kinds: dish, dough

## DISH Q56307726
- name: Molotof
- description: Portuguese dessert
- countries: PT
- cuisines: Portuguese cuisine
- kinds: dessert, dish
- ingredients: egg white, sugar
- has Wikipedia article: en

## DISH Q56308209
- name: Tsybulnyki
- description: Ukrainian onion pancakes
- countries: UA
- kinds: dish, oladyi
- has Wikipedia article: en

## DISH Q56311538
- name: Kondreh (food)
- description: Cameroonian stew
- countries: CM
- kinds: dish
- has Wikipedia article: en

## DISH Q56315370
- name: Chocolate fondant
- countries: (none)
- kinds: chocolate cake
- ingredients: chicken egg, wheat flour, sugar, chocolate

## DISH Q56315793
- name: Pudim
- description: Homemade Portuguese dessert with milk, eggs and sugar, cooked in a bain-marie
- countries: PT
- kinds: crème caramel
- ingredients: cow's milk, egg as food, sugar

## DISH Q56316733
- name: Sojeok
- description: tofu or vegetable skewers
- countries: (none)
- kinds: jeok

## DISH Q56318608
- name: Bard
- countries: (none)
- kinds: fatback

## DISH Q56318681
- name: Bolivian bread
- countries: (none)
- kinds: bread, meal

## DISH Q56319981
- name: Bénédictin
- other names: {"fr": "bénédictin"}
- countries: (none)
- kinds: cake

## DISH Q56320624
- name: Schinkengipfeli
- description: ham-filled croissant
- countries: CH
- cuisines: Swiss cuisine

## DISH Q56320644
- name: Peanut stew
- other names: {"zh": "花生燉煮"}
- description: Western African stew
- countries: SN
- kinds: peanut sauces
- ingredients: cabbage, okra, Cuminum cyminum, Allium, Curcuma longa, leaf, Allium sativum, maize, paper, chicken, carrot
- has Wikipedia article: en, zh

## DISH Q56321400
- name: Plato paceño
- description: Bolivian dish
- countries: (none)
- kinds: dish
- ingredients: maize, fried cheese, potato, Phaseolus lunatus

## DISH Q56322334
- name: Tavë dheu
- other names: {"it": "Tavë dheu"}
- countries: (none)
- kinds: dish

## DISH Q56324405
- name: Charms
- description: Italian candy
- countries: (none)
- kinds: candy

## DISH Q56324986
- name: Nureum-jeok
- description: egg-washed and pan-fried skewers
- countries: (none)
- kinds: jeok

## DISH Q56345506
- name: Ulster fry
- description: Northern Ireland breakfast meal
- countries: (none)
- kinds: full breakfast
- ingredients: tomato, soda bread, potato bread, sausage, egg as food, bacon

## DISH Q56345566
- name: Raggmunk
- description: Swedish potato pancake
- countries: SE
- kinds: potato pancake

## DISH Q56346661
- name: Azevia
- description: Portuguese fried pastry with various fillings
- countries: PT
- kinds: meal, confectionery
- has Wikipedia article: en

## DISH Q56346680
- name: Iso ramen
- countries: (none)
- kinds: ramen

## DISH Q56346823
- name: Burma soup
- description: Japanese Tochigi Mashiko's soup
- countries: (none)
- kinds: shirumono, pork dish
- ingredients: tomato, kidney bean, potato, eggplant, summer vegetable, curry powder, udon, pork, chili pepper, dashi, pho, carrot

## DISH Q56347154
- name: Salad chicken
- description: Japanese packed chicken
- countries: (none)
- kinds: snack, processed meat, chicken dish

## DISH Q56348878
- name: 小鮎の甘露煮
- other names: {"ja": "小鮎の甘露煮"}
- countries: (none)
- kinds: Tsukudani

## DISH Q56349591
- name: 黄精飴
- other names: {"ja": "黄精飴"}
- countries: (none)
- kinds: gyūhi

## DISH Q56353552
- name: Chocotone
- other names: {"pt": "chocotone"}
- countries: (none)
- kinds: panettone

## DISH Q56355857
- name: Палюшки
- other names: {"ru": "Палюшки"}
- countries: (none)
- kinds: varenyky, dish

## DISH Q56361009
- name: Ash-e badenjan
- description: iranian dish
- countries: (none)
- kinds: Aush, dish

## DISH Q56365932
- name: Kabab soltani
- countries: (none)
- kinds: chelow kabab
- has Wikipedia article: en

## DISH Q5636956
- name: Pantruca
- description: Chilean soup with home-made noodles (pantrucas)
- countries: CL
- kinds: food, soup, noodle
- ingredients: flour
- has Wikipedia article: en

## DISH Q5637746
- name: Meatballs with rice
- description: dish
- countries: (none)
- kinds: dish
- ingredients: meatball, rice

## DISH Q5638274
- name: Postre vigilante
- description: dessert
- countries: (none)
- kinds: confectionery
- ingredients: dulce de batata, Goiabada, quince cheese, cheese

## DISH Q5638807
- name: Aceitada
- other names: {"es": "Aceitada"}
- countries: (none)
- kinds: bun

## DISH Q56390165
- name: Sambal Poyah
- other names: {"id": "Sambal Poyah"}
- countries: (none)
- kinds: dish

## DISH Q56391469
- name: Soto Gombong
- other names: {"id": "Soto Gombong"}
- countries: (none)
- kinds: soto

## DISH Q56391582
- name: Holat
- other names: {"id": "holat"}
- countries: ID
- kinds: soup, fish dish
- ingredients: ginger, onion, fish as food, Phyllanthus emblica, table salt

## DISH Q56391669
- name: Itiak Lado Mudo
- description: Duck with green chili
- countries: ID
- kinds: duck dish
- ingredients: duck meat, chili pepper

## DISH Q56391757
- name: Tabheg
- description: rice wrapped in banana leaves and rolled
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish
- ingredients: banana leaf, rice

## DISH Q56392441
- name: Fried meatball
- description: Sundanese fried meatball
- countries: ID
- kinds: fritter, snack
- ingredients: bakso

## DISH Q56392543
- name: Citruk
- description: traditional Indonesian snack from Tasikmalaya, West Java, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack
- ingredients: garlic, wheat flour, Kaempferia galanga, tapioca, cooking oil, table salt, water

## DISH Q56392589
- name: Sayur besan
- description: traditional yellow coconut milk soup from the Betawi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: human food, type of food or dish, dish, soup
- ingredients: rice vermicelli, dried shrimp, Parkia speciosa, potato, tomato, Saccharum edule, coconut milk, cellophane noodles, scallion

## DISH Q56392804
- name: Tere siga
- description: Ethiopian and Eritrean dish
- countries: (none)
- kinds: raw beef dish
- ingredients: raw meat

## DISH Q56393200
- name: Man reman
- description: traditional snack from Sumenep, Madura (East Java), Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, sweet dish
- ingredients: glutinous rice flour, palm sugar, cooking oil

## DISH Q56393494
- name: Anyang
- description: Indonesian traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, salad, type of food or dish
- ingredients: seedling, Asparagus bean, Allium ascalonicum, beef, chili pepper, Carica papaya, Cocos nucifera, table salt

## DISH Q56394196
- name: Nasi jaha
- other names: {"id": "nasi jaha"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: rice dish, dish, human food, type of food or dish
- ingredients: ginger, Bambu, coconut milk, Pandanus amaryllifolius, glutinous rice, Cymbopogon citratus, rice

## DISH Q56394259
- name: Nasi kabaka
- other names: {"id": "nasi kabaka"}
- countries: ID
- kinds: rice dish

## DISH Q56397725
- name: Dried squid
- other names: {"zh": "乾魷魚"}
- description: type of seafood
- countries: (none)
- kinds: Himono, squid dish
- ingredients: Sepiida, Teuthida
- has Wikipedia article: zh

## DISH Q56398981
- name: Pelleng
- description: Pakpak Batak traditional cuisine
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: Indonesian bay leaf, shallot, garlic, ginger, cooked rice, chili pepper, Curcuma longa, Cymbopogon citratus

## DISH Q56399237
- name: Rendang lokan
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: rendang, side dish, dish, human food, type of food or dish
- ingredients: Indonesian bay leaf, garlic, clam, Aleurites moluccanus, coconut milk, Alpinia galanga, Allium ascalonicum, chili pepper, nutmeg, black pepper, Curcuma longa, ginger, Cymbopogon citratus, table salt, sugar

## DISH Q56402878
- name: Horta
- other names: {"fi": "Horta"}
- countries: (none)
- kinds: dish

## DISH Q56408977
- name: Dalmatian ham
- countries: (none)
- kinds: prosciutto

## DISH Q56411177
- name: Plombir
- other names: {"zh": "普隆比尔冰淇淋"}
- description: ice cream from USSR
- countries: FR
- kinds: ice cream
- has Wikipedia article: en

## DISH Q56411494
- name: Sempol
- description: variation of traditional Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: tapioca, chicken as food, egg as food, Apium graveolens, carrot, skewer

## DISH Q56411796
- name: Soto gading
- other names: {"id": "Soto gading"}
- countries: (none)
- kinds: soto

## DISH Q56412603
- name: Pempek lenggang
- description: variant of pempek
- countries: ID
- cuisines: Indonesian cuisine
- kinds: Pempek, dish, human food, type of food or dish
- ingredients: sago flour, garlic, chicken egg, banana leaf, palm sugar, tapioca, scallion, fish as food, acetic acid, table salt

## DISH Q56413424
- name: Babae
- other names: {"id": "babae"}
- countries: ID
- kinds: soup, porridge

## DISH Q56413999
- name: Nasi katok
- description: Bruneian rice dish
- countries: BN
- kinds: dish
- has Wikipedia article: en

## DISH Q56416642
- name: Jagung bose
- description: Indonesian food
- countries: (none)
- kinds: porridge, food, dish, human food
- ingredients: kidney bean, peanut, coconut milk

## DISH Q56422976
- name: Морська капуста
- other names: {"uk": "Морська капуста"}
- description: food
- countries: (none)
- kinds: dish

## DISH Q564271
- name: Bánh bao
- other names: {"zh": "包饼"}
- description: Vietnamese bun
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: dish, bánh
- ingredients: minced meat
- has Wikipedia article: en, zh

## DISH Q5642869
- name: Étouffée
- other names: {"zh": "新奧爾良燴海鮮"}
- description: American stew
- countries: US
- kinds: dish, food
- ingredients: shellfish
- has Wikipedia article: en

## DISH Q5643056
- name: Hallongrotta
- description: cookie with raspberry jam filling
- countries: SE
- kinds: cookie
- ingredients: raspberry jam, wheat flour, baker's ammonia, powdered sugar, margarine
- has Wikipedia article: en

## DISH Q5643212
- name: Hallulla
- description: rounded type of bread
- countries: CL
- kinds: white bread, leavened bread
- has Wikipedia article: en

## DISH Q5643322
- name: Taro dumpling
- other names: {"zh": "芋角"}
- description: Chinese cuisine
- countries: CN
- kinds: dim sum, food
- has Wikipedia article: en, zh

## DISH Q5643900
- name: Ham and egg bun
- other names: {"zh": "火腿雞蛋包"}
- description: type of Hong Kong pastry
- countries: BR, HK
- kinds: egg dish, brioche, ham sandwich, pork dish
- ingredients: flour, cooked ham, egg as food
- has Wikipedia article: en, zh

## DISH Q5643903
- name: Ham salad
- description: anglo-american dish
- countries: (none)
- kinds: food, salad, onion, pork dish
- ingredients: green pepper, celery, onion, pickled cucumber, relish, ham, mayonnaise
- has Wikipedia article: en

## DISH Q56441185
- name: Agnes Bernauer torte
- description: Bavarian layer cake
- countries: (none)
- kinds: torte, layer cake

## DISH Q5644416
- name: Hamdog
- description: Australian sandwich that consists of a shaped bread bun with a beef patty cut in two, and a frankfurter placed in between the two halves
- countries: AU
- kinds: hamburger
- ingredients: Hamburg steak, hot dog
- has Wikipedia article: en

## DISH Q564491
- name: Tacacá
- other names: {"zh": "酸麻蝦湯"}
- description: typical Amazon soup
- countries: BR
- kinds: food, soup
- has Wikipedia article: en, zh

## DISH Q564494
- name: Galinhada
- other names: {"zh": "加利尼亚达鸡肉饭"}
- description: Brazilian chicken and rice dish
- countries: (none)
- kinds: stew, chicken dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q564500
- name: Caruru
- description: Brazilian stew
- countries: BR
- kinds: stew
- ingredients: okra, onion, nut, dried shrimp, palm oil
- has Wikipedia article: en

## DISH Q564506
- name: Shrimp sandwich
- description: open sandwich with shrimps
- countries: (none)
- kinds: open sandwich
- ingredients: sandwich bread, chicken egg, shrimp and prawn as food, lemon, mayonnaise

## DISH Q564509
- name: Kho
- other names: {"zh": "越南紅燒燉牛肉"}
- description: cooking technique
- countries: VN
- kinds: stew
- ingredients: beef
- has Wikipedia article: en

## DISH Q564557
- name: Oxtail soup
- other names: {"zh": "牛尾汤"}
- description: soup made with beef tails
- countries: (none)
- kinds: soup
- ingredients: oxtail
- has Wikipedia article: en, zh

## DISH Q564560
- name: Phu Thê Cake
- other names: {"zh": "夫妻餅"}
- description: Vietnamese rice cake
- countries: VN
- kinds: dessert, wedding gift, bánh
- has Wikipedia article: en, zh

## DISH Q564570
- name: Chả lụa
- other names: {"zh": "扎肉"}
- description: common type of sausage in Vietnamese cuisine, made of pork and wrapped in banana leaves
- countries: (none)
- kinds: sausage, pork dish, beef dish
- has Wikipedia article: en, zh

## DISH Q564573
- name: Canh chua
- description: Vietnamese sour soup dish
- countries: VN
- kinds: fish dish, sour soup
- ingredients: fish
- has Wikipedia article: en

## DISH Q564622
- name: Cabbage soup
- description: food
- countries: RU, PL, UA
- cuisines: Russian cuisine, Polish cuisine, Ukrainian cuisine
- kinds: vegetable soup
- ingredients: stock, Brassica oleracea, Brassica oleracea var. capitata
- has Wikipedia article: en

## DISH Q564629
- name: Anna's torte
- description: chocolate torte
- countries: (none)
- kinds: torte
- ingredients: chocolate

## DISH Q564722
- name: Charqui
- countries: (none)
- kinds: food, cooking technique, beef dish

## DISH Q5647753
- name: Haneeth
- description: slow-roasted lamb dish from the Arabian Peninsula
- countries: YE
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q564786
- name: Jägerschnitzel
- other names: {"zh": "猎人肉排"}
- description: classic, fried meat dish
- countries: (none)
- kinds: schnitzel
- has Wikipedia article: en, zh

## DISH Q56490023
- name: Sugar-free candy
- description: candy made with a sugar substitute
- countries: (none)
- kinds: candy, sugar-free product
- ingredients: non-nutritive sweetener

## DISH Q56493317
- name: Argentine pizza
- description: variety of pizzas originated in Buenos Aires, Argentina
- countries: AR
- cuisines: Argentine cuisine
- kinds: type of pizza
- ingredients: tomato sauce, dough, mozzarella
- has Wikipedia article: en

## DISH Q5650062
- name: Hojaldres de Astorga
- countries: ES
- kinds: dessert

## DISH Q5651265
- name: Güevos encapotaos
- other names: {"ast": "güevos encapotaos"}
- countries: (none)
- kinds: food, dish, egg dish
- ingredients: egg as food

## DISH Q56512885
- name: Fugazzetta
- description: Argentina pizza variety
- countries: AR

## DISH Q5652554
- name: Happy Cake
- description: Hawaiian fruit cake
- countries: US
- kinds: cake
- ingredients: pineapple
- has Wikipedia article: en

## DISH Q56525731
- name: Mutton soup
- other names: {"zh": "羊汤"}
- description: soup containing mutton or lamb
- countries: (none)
- kinds: soup, type of food or dish
- ingredients: mutton, lamb meat

## DISH Q5653655
- name: Rosca chonchina
- description: Chilean sweet
- countries: CL
- kinds: food, rosquilla

## DISH Q5655520
- name: Hard dough bread
- countries: JM
- kinds: bread, baked good
- ingredients: flour
- has Wikipedia article: en

## DISH Q56559327
- name: Pit beef
- description: roast beef prepared over a charcoal fire
- countries: (none)
- kinds: dish, beef dish
- has Wikipedia article: en

## DISH Q5656299
- name: Ras malai
- description: Bengali sweet made with Indian cheese
- countries: (none)
- kinds: dessert
- ingredients: pistachio nut, cardamom, chhena, Malai, saffron, sugar
- has Wikipedia article: en

## DISH Q5656392
- name: Aceite del Bajo Aragón
- description: Spanish olive oil
- countries: ES
- kinds: olive oil

## DISH Q5656583
- name: Achilata
- description: ice cream
- countries: (none)
- kinds: ice cream

## DISH Q5656677
- name: Acitrón
- description: Mexican Candy
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q565715
- name: Reibekuchen
- description: German potato pancake
- countries: DE
- kinds: potato pancake
- ingredients: potato
- has Wikipedia article: en

## DISH Q5657318
- name: Mukbil Pollo
- other names: {"cs": "Mukbil Pollo"}
- description: chicken cooked in an underground Mayan oven
- countries: MX
- cuisines: cuisine of Yucatán
- kinds: dish
- ingredients: píib, banana leaf, masa, chicken as food, lard, spice

## DISH Q565767
- name: Ragout
- other names: {"zh": "黑椒燴鹿肉"}
- description: main-dish stew
- countries: (none)
- kinds: dish, meat dish, stew
- has Wikipedia article: en

## DISH Q56582296
- name: Waffle fries
- other names: {"zh": "薯格"}
- description: crinkle-cut french fries
- countries: (none)
- kinds: fries
- has Wikipedia article: en

## DISH Q56599054
- name: Beschuit
- countries: (none)
- kinds: bread

## DISH Q56599055
- name: Beskuit
- other names: {"af": "beskuit"}
- countries: (none)
- kinds: baked good

## DISH Q56599845
- name: Buttenmost
- description: Swiss regional variety of rose hip jam
- countries: CH
- kinds: Rose hip jam

## DISH Q5660287
- name: Aguamiel (postre)
- other names: {"es": "Aguamiel (postre)"}
- countries: ES
- kinds: dessert

## DISH Q56611571
- name: Miso katsudon
- countries: (none)
- kinds: katsudon, donburi
- ingredients: Miso-katsu

## DISH Q5661511
- name: Ajo colorao
- other names: {"es": "ajo colorao"}
- countries: (none)
- kinds: type of food or dish, potato dish

## DISH Q5661529
- name: Patates forneres
- other names: {"ca": "Patates forneres"}
- description: potatoes sliced in thin pieces and usually cooked in the oven
- countries: (none)
- kinds: potato dish

## DISH Q5662088
- name: Eris  (Confection)
- description: Traditional Confection of Tabriz
- countries: (none)
- kinds: pastry
- ingredients: Pistacia vera
- has Wikipedia article: en

## DISH Q5663370
- name: Fardelejos
- other names: {"es": "Fardelejos"}
- countries: ES
- kinds: dessert

## DISH Q5663825
- name: Bezhi
- description: Kurdish cookie
- countries: (none)
- kinds: Wikimedia disambiguation page, pastry
- has Wikipedia article: en

## DISH Q5663872
- name: Albóndigas de bacalao
- description: Spanish cod meatballs
- countries: (none)
- kinds: dish
- ingredients: parsley, garlic, potato, cod, pine nut, egg as food

## DISH Q56650496
- name: Ardei umpluţi
- description: Romanian stuffed pepper dish
- countries: (none)
- kinds: stuffed peppers

## DISH Q5665969
- name: گلابشکر
- other names: {"fa": "گلابشکر"}
- countries: (none)
- kinds: pastry

## DISH Q5666489
- name: Alfajor
- description: Spanish cookie-like dessert
- countries: (none)
- kinds: food, dessert

## DISH Q5668956
- name: Bajoques farcides
- other names: {"ca": "Bajoques farcides"}
- countries: (none)
- kinds: dish, rice dish

## DISH Q5669719
- name: Palourdes marinières
- countries: ES
- kinds: dish
- ingredients: tomato, onion, clam, white wine

## DISH Q5669743
- name: Almendrado
- other names: {"es": "Almendrado"}
- countries: ES
- kinds: dish, jam
- ingredients: almond, sugar, honey

## DISH Q5669841
- name: Almojábana
- other names: {"es": "almojábana"}
- countries: ES
- cuisines: Spanish cuisine
- kinds: type of food or dish, fritter

## DISH Q56702339
- name: Bushman fondue
- description: South African dish
- countries: (none)
- kinds: fondue, dish

## DISH Q5670573
- name: Alpisteras de Sanlúcar de Barrameda
- other names: {"es": "Alpisteras de Sanlúcar de Barrameda"}
- countries: ES
- kinds: dessert

## DISH Q56707172
- name: Gerbeaud cake
- description: Hungarian dessert
- countries: HU
- kinds: cake

## DISH Q56707179
- name: Vienna cream puff
- description: Austrian dessert
- countries: AT
- kinds: cake

## DISH Q5673259
- name: Potaje de vigilia
- description: easter plate
- countries: (none)
- kinds: type of food or dish, potage

## DISH Q5673771
- name: Pambazo
- description: Mexican traditional dish
- countries: MX
- kinds: sandwich, pork dish
- has Wikipedia article: en

## DISH Q5674757
- name: Shirazi salad
- other names: {"zh": "设拉子沙拉"}
- description: Iranian salad
- countries: IR
- cuisines: Iranian cuisine
- kinds: salad, side dish
- has Wikipedia article: en, zh

## DISH Q5674824
- name: Seer Torshi
- description: Persian pickled garlic
- countries: IR
- kinds: food, pickle
- ingredients: garlic, wine vinegar
- has Wikipedia article: en

## DISH Q567516
- name: Milbenkäse
- other names: {"zh": "蟎蟲奶酪"}
- description: cheese flavored by live mites
- countries: DE
- kinds: cheese, German cheese
- ingredients: Tyrophagus casei, fresh cheese
- has Wikipedia article: en

## DISH Q56756138
- name: Baarer Räbentorte
- description: Swiss layer cake
- countries: CH
- kinds: torte
- ingredients: meringue, butter, Savoiarde PAT

## DISH Q5677028
- name: Rice with hare
- description: typical dish of traditional Castilian cuisine
- countries: (none)
- cuisines: Castilian cuisine
- kinds: dish, rice dish

## DISH Q5678787
- name: Lor mee
- other names: {"zh": "滷麵"}
- description: Southeast Asia Chinese dish
- countries: MY
- kinds: noodle dish
- ingredients: dark soy sauce, black vinegar, corn starch, Chinese noodles, five-spice powder, egg as food
- has Wikipedia article: en, zh

## DISH Q5679218
- name: Maejap-gwa
- description: Korean dessert
- countries: (none)
- kinds: yumilgwa
- has Wikipedia article: en

## DISH Q5679304
- name: Haslet
- description: refers to a pork meatloaf
- countries: GB
- kinds: food, meatloaf, pork dish
- has Wikipedia article: en

## DISH Q56798412
- name: Biggest Gata of the World
- countries: (none)
- kinds: Gata

## DISH Q56806241
- name: Kalai ruti
- description: Bangladeshi traditional flatbread
- countries: BD
- kinds: roti

## DISH Q5682366
- name: Sōmen salad
- other names: {"zh": "素麵沙拉"}
- description: Japanese noodle-based dish
- countries: JP
- kinds: salad, pasta salad
- ingredients: sōmen
- has Wikipedia article: en, zh

## DISH Q5682941
- name: ترحلوا با هویج
- other names: {"fa": "ترحلوا با هویج"}
- countries: (none)
- kinds: pastry

## DISH Q568347
- name: Anpan
- other names: {"zh": "豆沙麵包"}
- description: sweet bun filled with red bean paste, white beans, sesame, or chestnut
- countries: JP
- kinds: viennoiserie, sweet bread
- ingredients: red bean paste
- has Wikipedia article: en, zh

## DISH Q5683825
- name: Lalak
- countries: DZ
- kinds: dish
- ingredients: bran

## DISH Q5684599
- name: Hawaiian haystack
- other names: {"zh": "夏威夷干草堆"}
- description: Hawaiian rice dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q5684686
- name: Hawawshi
- description: traditional Egyptian dish
- countries: EG
- kinds: dish
- has Wikipedia article: en

## DISH Q5684811
- name: Zeytoon parvardeh
- description: Iranian olive pomegranate dish
- countries: IR
- kinds: dish
- ingredients: olive
- has Wikipedia article: en

## DISH Q5687118
- name: Ajo mataero
- other names: {"es": "Ajo mataero"}
- countries: ES
- cuisines: Castilian-Manchego cuisine
- kinds: food, dish, morteruelo
- ingredients: pork liver, crumb

## DISH Q5687757
- name: Palak paneer
- description: Indian dish with cheese
- countries: (none)
- kinds: food, Indian curry
- ingredients: paneer, Spinacia oleracea
- has Wikipedia article: en

## DISH Q56877598
- name: Lori
- description: type of Armenian cheese
- countries: AM
- kinds: cheese, type of cheese
- ingredients: cow's milk

## DISH Q56884785
- name: Rusk
- other names: {"es": "Rusk"}
- countries: (none)
- kinds: rusk

## DISH Q56893397
- name: Bogurar doi
- description: type of curd from Bogura
- countries: BD
- kinds: Mishti doi, desert, confectionery
- has Wikipedia article: en

## DISH Q5690018
- name: Roujiamo
- other names: {"zh": "肉夹馍"}
- description: type of Chinese street food
- countries: CN
- kinds: pork dish, jiamo
- ingredients: flatbread, pork
- has Wikipedia article: en, zh

## DISH Q5690994
- name: Kelane
- description: flat bread with varied fillings from Kurdistan
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q5691167
- name: Cake Yazdi
- description: pastry of Yazd, Iran
- countries: IR
- kinds: pastry
- has Wikipedia article: en

## DISH Q5692333
- name: Bollo escarchado
- other names: {"es": "Bollo escarchado"}
- countries: (none)
- kinds: baked good
- ingredients: wheat flour

## DISH Q5694314
- name: جوزغند
- other names: {"fa": "جوزغند"}
- countries: (none)
- kinds: pastry

## DISH Q5695228
- name: Heavy cake
- description: traditional cake from Cornwall
- countries: GB
- kinds: cake
- ingredients: flour
- has Wikipedia article: en

## DISH Q5696815
- name: Baghala ghatogh
- description: northern Iranian dish made with fava beans, dill, and eggs
- countries: IR
- kinds: stew, egg dish
- has Wikipedia article: en

## DISH Q5696884
- name: Sarapatel
- description: Portuguese ingredient mix
- countries: PT
- kinds: pork dish
- has Wikipedia article: en

## DISH Q5697020
- name: Pastel de cabrachu
- other names: {"ast": "Pastel de cabrachu"}
- countries: (none)
- kinds: dish, cake
- ingredients: Scorpaena scrofa

## DISH Q5700175
- name: Loobia polo
- description: Iranian dish of rice, green beans, and beef or lamb
- countries: IR
- kinds: dish
- has Wikipedia article: en

## DISH Q570038
- name: Shopska salad
- other names: {"zh": "保加利亞沙拉"}
- description: cold salad found all through Southeastern Europe
- countries: BG
- kinds: salad
- ingredients: sirene, onion, tomato, Cucumis sativus, cheese
- has Wikipedia article: en, zh

## DISH Q5700719
- name: حاجی بادام
- other names: {"fa": "حاجی بادام"}
- countries: (none)
- kinds: pastry

## DISH Q5701588
- name: Qema
- description: Iraqi dish
- countries: IQ
- cuisines: Iraqi cuisine
- kinds: rice dish, type of food or dish
- ingredients: tomato paste, beef, cicer arietinum, oil, table salt, rice
- has Wikipedia article: en

## DISH Q5702275
- name: Unleavened bread
- other names: {"zh": "無酵餅"}
- description: bread not inflated by yeast or other leaveners
- countries: (none)
- kinds: dish, bread
- ingredients: flour, table salt, water
- has Wikipedia article: en, zh

## DISH Q5703544
- name: Egg-stuffed arepa
- description: Arepa, typical of the Caribbean Region of Colombia
- countries: CO
- kinds: pancake, type of food or dish
- ingredients: cornmeal, masa, egg as food, oil, table salt

## DISH Q5703916
- name: Laboo
- countries: (none)
- kinds: dish
- ingredients: beet

## DISH Q5704569
- name: بادام سوخته
- other names: {"fa": "بادام سوخته"}
- countries: (none)
- kinds: pastry

## DISH Q5705446
- name: Arrollado de huaso
- description: Chilean dish
- countries: CL
- kinds: embutido

## DISH Q5706288
- name: Arroz a la zamorana
- countries: (none)
- kinds: dish

## DISH Q5706291
- name: Arroz atollado
- countries: CO
- kinds: rice dish, meal
- ingredients: potato, rice
- has Wikipedia article: en

## DISH Q5706305
- name: Arròs amb bledes
- other names: {"ca": "Arròs amb bledes"}
- countries: (none)
- kinds: dish
- ingredients: white bean, potato, chard, rice

## DISH Q5706310
- name: Arroz con bogavante
- description: Spanish dish with rice and lobster
- countries: (none)
- kinds: dish
- ingredients: rice as food, Homarus gammarus

## DISH Q5706318
- name: Seafood rice
- countries: (none)
- kinds: meal, rice dish

## DISH Q5706333
- name: Arroz de fríjol cabecita negra
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5706337
- name: Arroz de lisa
- description: traditional Colombian seafood dish
- countries: CO
- kinds: course
- ingredients: rice
- has Wikipedia article: en

## DISH Q5707569
- name: Hellimli
- description: Foodstuff
- countries: CY
- kinds: food, pastry
- ingredients: halloumi
- has Wikipedia article: en

## DISH Q5707723
- name: Asadurilla
- countries: (none)
- kinds: dish

## DISH Q5708446
- name: الحلاوة البربرية
- other names: {"ar": "الحلاوة البربرية"}
- countries: IR
- kinds: dessert
- ingredients: wheat

## DISH Q5710501
- name: Ate
- description: fruit preserves
- countries: ES
- kinds: quince cheese
- ingredients: quince

## DISH Q5711624
- name: Bastani
- description: Persian saffron ice cream
- countries: IR
- kinds: ice cream
- ingredients: rose water, egg as food, Pistacia vera, saffron, vanilla, sugar, milk
- has Wikipedia article: en

## DISH Q5714984
- name: Azafrán de la Mancha
- description: saffron from Castilla-La Mancha
- countries: ES
- kinds: saffron, spice

## DISH Q5715053
- name: Azeite de Moura
- countries: PT
- kinds: olive oil

## DISH Q5715906
- name: Nan-e Nokhodchi
- description: Chickpea cookie
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q5718989
- name: Banderilla
- other names: {"eu": "Banderilla"}
- countries: (none)
- kinds: tapas

## DISH Q57198707
- name: Schlorzifladen
- description: Swiss tart with a filling of stewed pears and cream
- countries: (none)
- kinds: wähe

## DISH Q5719932
- name: Gosh-e fil
- other names: {"zh": "波斯炸甜麵團"}
- description: Afghan and Iranian doughnut
- countries: AF
- kinds: food, pastry
- has Wikipedia article: en, zh

## DISH Q57205077
- name: Prawn Rougaille
- description: Mauritian dish primarily composed of tomato-based sauce and prawn
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q57206027
- name: Kung sarong
- description: Deep fried prawns wrapped in egg noodles
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5721298
- name: Bartolillos
- countries: ES
- cuisines: Spanish cuisine
- kinds: fritter, type of food or dish

## DISH Q5721367
- name: شاخه نبات
- other names: {"fa": "شاخه نبات"}
- countries: (none)
- kinds: pastry

## DISH Q572557
- name: Stinking Bishop cheese
- description: washed rind cheese
- countries: GB
- kinds: food, washed-rind cheese, British cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q5726175
- name: Sohan asali
- description: Iranian honey confection
- countries: IR
- kinds: pastry, sohan
- ingredients: Prunus amygdalus, saffron, sugar, honey
- has Wikipedia article: en

## DISH Q57263988
- name: Tom kha
- description: Thai coconut soup
- countries: TH
- kinds: coconut soup

## DISH Q57264472
- name: Spanish Madeleine
- description: traditional cake from Spain in a paper mold
- countries: ES
- kinds: cake, muffin

## DISH Q5727337
- name: Namanare
- countries: (none)
- kinds: funazushi

## DISH Q5729035
- name: Birote salad
- description: a salted Mexican bread
- countries: (none)
- kinds: birote

## DISH Q5729169
- name: Bissara
- description: soup
- countries: EG
- kinds: soup, dish
- ingredients: Broad Bean, Anethum graveolens, parsley, onion
- has Wikipedia article: en

## DISH Q5729425
- name: Bizcochitos de grasa
- other names: {"es": "Bizcochitos de grasa"}
- countries: (none)
- kinds: cookie

## DISH Q5729428
- name: Borracho (cake)
- description: Cakes of Spain
- countries: ES
- kinds: dessert

## DISH Q57304501
- name: Aalsterse vlaai
- description: type of pie, typically from the Belgian town of Aalst
- countries: BE
- kinds: vlaai
- has Wikipedia article: en

## DISH Q5730660
- name: حلواشکری
- other names: {"fa": "حلواشکری"}
- countries: (none)
- kinds: pastry

## DISH Q5730960
- name: Bocadillo de chorizo
- description: chorizo sandwich
- countries: (none)
- kinds: bocadillo
- ingredients: chorizo, bread roll

## DISH Q5731555
- name: Bolla de chicharrones
- description: Sweet made with chicharrones
- countries: ES
- kinds: dessert, cake
- ingredients: chicharrón, flour, Pimpinella anisum, sugar

## DISH Q5731586
- name: Brioix suís
- other names: {"ca": "Brioix suís"}
- countries: ES
- kinds: dessert, viennoiserie

## DISH Q5731591
- name: Heong Peng
- other names: {"zh": "香餅"}
- description: Malaysian pastry dish
- countries: MY
- kinds: food, pastry
- ingredients: malt
- has Wikipedia article: en, zh

## DISH Q57328687
- name: Grilled tomato
- description: tomato cooked by grilling
- countries: (none)
- kinds: food, dish
- ingredients: tomato

## DISH Q5735843
- name: Burro percherón
- description: traditional Mexican dish
- countries: MX
- kinds: dish
- has Wikipedia article: en

## DISH Q5736147
- name: Butifarra
- description: Peruvian ham sandwich
- countries: PE
- kinds: ham sandwich, sandwich
- ingredients: jamón del país, salsa criolla, Marraqueta
- has Wikipedia article: en

## DISH Q57385880
- name: Silserkugel
- other names: {"de": "Silserkugel"}
- countries: (none)
- kinds: confectionery
- ingredients: chocolate

## DISH Q5738673
- name: Cachorreñas
- other names: {"es": "Cachorreñas"}
- countries: (none)
- kinds: soup
- ingredients: garlic, paprika, vinegar, bread, water

## DISH Q5739273
- name: Cagá de gato
- other names: {"es": "Cagá de gato"}
- countries: ES
- kinds: dessert

## DISH Q5739461
- name: Makizushi
- other names: {"zh": "寿司卷"}
- description: rolled sushi
- countries: JP
- cuisines: Japanese cuisine
- kinds: sushi, roll, type of food or dish
- ingredients: algae, rice
- has Wikipedia article: en, zh

## DISH Q5739698
- name: Chipirones en su tinta
- other names: {"de": "Chipirones en su tinta"}
- countries: ES
- kinds: squid dish
- ingredients: garlic, tomato, onion, cephalopod ink, olive oil, Teuthida, white wine

## DISH Q5739874
- name: Ŝafvianda raguo
- other names: {"eo": "Ŝafvianda raguo"}
- countries: (none)
- kinds: dish
- ingredients: garlic, onion, bell pepper, Pimiento, lamb meat, olive oil, white wine

## DISH Q5739890
- name: Caldillo de perro
- description: soup made with fish and oranges
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q5739896
- name: Caldo de bolas
- countries: EC
- kinds: soup, meal

## DISH Q5739900
- name: Caldo de castañas
- other names: {"es": "Caldo de castañas"}
- description: Galician chestnut soup
- countries: (none)
- cuisines: Galician cuisine
- kinds: broth, dish
- ingredients: garlic, pig fat, chestnut, drinking water

## DISH Q5739911
- name: Caldosa
- description: Cuban typical dish
- countries: (none)
- kinds: soup

## DISH Q5739984
- name: Calentita
- description: Gibraltarian pancake-like dish
- countries: (none)
- kinds: meal, farinata

## DISH Q5741634
- name: Calzón roto
- description: Chilean sweet
- countries: CL
- kinds: buñuelo, meal

## DISH Q5741731
- name: Camarones el mojo de ajo
- description: Mexican shrimp dish
- countries: MX
- kinds: shrimp dish
- ingredients: garlic, shrimp and prawn as food

## DISH Q574483
- name: Saumagen
- description: German stuffed dish of potatoes and pork with spices
- countries: DE
- kinds: dish
- ingredients: pig's stomach, potato, minced meat, leek, gammon, pork, egg as food
- has Wikipedia article: en

## DISH Q5748189
- name: Heugimja-juk
- description: Korean porridge
- countries: (none)
- kinds: juk
- ingredients: Sesamum indicum
- has Wikipedia article: en

## DISH Q5748887
- name: Carantanta
- other names: {"es": "Carantanta"}
- countries: (none)
- kinds: culinary speciality

## DISH Q5748955
- name: Carbonada
- description: dish of Argentina, Chile, and Bolivia
- countries: (none)
- kinds: type of food or dish, guiso

## DISH Q575069
- name: Blessed bread
- description: Eucharistic bread that has been blessed but not consecrated
- countries: (none)
- kinds: bread, religious object
- has Wikipedia article: en

## DISH Q5752977
- name: Carne con chile
- other names: {"es": "Carne con chile"}
- countries: MX
- kinds: dish

## DISH Q5753018
- name: Carne en su jugo
- description: dish from the state of Jalisco, Mexico
- countries: (none)
- kinds: soup, beef dish
- ingredients: cilantro, onion, beef, Phaseolus vulgaris, bacon

## DISH Q575329
- name: Kaminari-okoshi
- other names: {"zh": "雷粔籹"}
- countries: (none)
- kinds: Miyagegashi, okoshi

## DISH Q5754353
- name: Casa Mira
- countries: (none)
- kinds: pastry, pâtisserie

## DISH Q575506
- name: Imo yokan
- description: yokan made with sweet potatoes
- countries: JP
- kinds: Yōkan
- ingredients: Sweet potato

## DISH Q5758782
- name: Catuto
- description: traditional food of Mapuche cuisine
- countries: CL
- kinds: food

## DISH Q5759083
- name: Cayeye
- description: Colombian dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5759691
- name: Ceviche de chochos
- countries: (none)
- kinds: meal, ceviche
- ingredients: red onion, Lupinus mutabilis

## DISH Q5759904
- name: Cecina de León
- description: Smoked and dried beef from Spain
- countries: ES
- kinds: food, meat

## DISH Q57609453
- name: Tripe chorba
- countries: TR
- cuisines: Bulgarian cuisine, Turkish cuisine, Macedonian cuisine
- kinds: tripe soup

## DISH Q5764438
- name: Chanchamito
- description: Tamal from South of Veracruz and Tabasco
- countries: (none)
- kinds: dish, tamale

## DISH Q5764649
- name: Chaparrita
- description: sausage covered in melted cheese wrapped in baked dough
- countries: CL
- kinds: meal, bocadillo
- ingredients: processed cheese, dough, sausage

## DISH Q5765263
- name: Chaulafan
- other names: {"ca": "Chaulafan"}
- countries: CN
- kinds: food

## DISH Q57656613
- name: Dark chocolate chips
- description: chocolate chips made of dark chocolate
- countries: (none)
- kinds: dark chocolate, chocolate chip
- has Wikipedia article: en

## DISH Q57659729
- name: Candied orange peel
- description: confection, also used as ingredient
- countries: (none)
- kinds: candy, food ingredient
- ingredients: orange peel, orange zest, sugar

## DISH Q5766170
- name: Chifrijo
- description: Costa Rican dish
- countries: (none)
- kinds: dish
- ingredients: chicharrón, white rice, bean, pico de gallo, tortilla chip

## DISH Q5766593
- name: Chinguirito
- description: type of ceviche made with dried guitarfish
- countries: PE
- kinds: ceviche, meal
- ingredients: Rhinobatidae

## DISH Q5767217
- name: Chorizo a la sidra
- description: dish from Asturias, Spain
- countries: (none)
- kinds: dish

## DISH Q5768439
- name: Chula
- description: Spanish dessert
- countries: ES
- kinds: dessert

## DISH Q5768467
- name: Chuletón de Ávila
- description: T-bone steak prepared on the grill and generally served undercooked, in the province of Ávila, Spain
- countries: (none)
- kinds: T-bone steak
