# Review batch names-012

## DISH Q11481915
- name: Hibameshi
- countries: (none)
- kinds: takikomi gohan
- ingredients: leaf

## DISH Q114839857
- name: Tod man pla
- other names: {"nl": "Tod man pla"}
- countries: (none)
- kinds: street food

## DISH Q11484234
- name: Yūan-yaki
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q11484441
- name: Hiroshima ramen
- countries: (none)
- kinds: ramen

## DISH Q11486053
- name: 府中焼き
- other names: {"ja": "府中焼き"}
- countries: (none)
- kinds: okonomiyaki

## DISH Q11487140
- name: Hichigiri
- countries: (none)
- kinds: namagashi, Kyōgashi
- ingredients: red bean paste, mochi

## DISH Q114877024
- name: Cola-Fröschli
- description: Swiss hard candy with cola flavor shaped like a frog
- countries: (none)
- kinds: hard candy

## DISH Q1148776
- name: Duchess potatoes
- description: dish
- countries: FR
- kinds: potato dish
- ingredients: mashed potato
- has Wikipedia article: en

## DISH Q114888032
- name: Stelline
- description: type of pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q11489261
- name: 御膳味噌
- other names: {"ja": "御膳味噌"}
- countries: JP
- kinds: miso

## DISH Q11489657
- name: Tokushima ramen
- other names: {"zh": "德島拉麵"}
- description: Japanese ramen dish
- countries: JP
- kinds: ramen
- has Wikipedia article: zh

## DISH Q11489671
- name: 德島丼
- countries: (none)
- kinds: donburi

## DISH Q114905118
- name: Bisalto
- countries: (none)
- kinds: bread, human food

## DISH Q114924
- name: T-bone steak
- other names: {"zh": "T骨牛排"}
- description: beefsteak cut from the short loin, including a T-shaped bone with meat on each side
- countries: (none)
- kinds: short loin, beefsteak
- ingredients: beef
- has Wikipedia article: en

## DISH Q114932667
- name: Gevulde speculaas
- countries: (none)
- kinds: speculaas biscuit, human food

## DISH Q114962926
- name: Pizzetta cagliaritana
- other names: {"it": "pizzetta cagliaritana"}
- countries: IT
- kinds: dish
- ingredients: tomato sauce, caper, European anchovy, puff pastry

## DISH Q11496877
- name: Tekone-zushi
- description: style of sushi
- countries: JP
- kinds: chirashizushi, type of food or dish

## DISH Q11497126
- name: Tebasaki karaage
- other names: {"zh": "乾炸雞翅"}
- countries: (none)
- kinds: karaage, chicken dish

## DISH Q114971907
- name: Pani cunzatu
- other names: {"eu": "pani cunzatu"}
- countries: IT
- kinds: dish

## DISH Q11497260
- name: Uchimame
- countries: (none)
- kinds: soy food

## DISH Q11498654
- name: Geki
- description: Japanese confectionery
- countries: JP
- kinds: confectionery

## DISH Q11498707
- name: Banshū ramen
- description: a variety of soy sauce ramen from Nishiwaki, Hyogo prefecture, Japan
- countries: (none)
- kinds: shoyu ramen

## DISH Q11498791
- name: Gisei-dofu
- countries: (none)
- kinds: tofu

## DISH Q11499086
- name: 政岡豆
- other names: {"ja": "政岡豆"}
- countries: JP
- kinds: wagashi

## DISH Q11499534
- name: Tsuruga ramen
- countries: (none)
- kinds: ramen

## DISH Q1150150
- name: Taralli PAT
- other names: {"zh": "Taralli PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, cracker, baked good
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q115016178
- name: อัชบาน
- other names: {"th": "อัชบาน"}
- countries: TH
- kinds: human food
- ingredients: chili pepper, lime, table salt, sugar

## DISH Q115016236
- name: Labangalatika
- countries: (none)
- kinds: confectionery

## DISH Q11501703
- name: Shinkoyaki
- countries: (none)
- kinds: chicken dish

## DISH Q11502783
- name: Niigata asari shōyu ramen
- countries: (none)
- kinds: shoyu ramen, ramen in Niigata Prefecture

## DISH Q11502972
- name: Niigata nōkō miso ramen
- other names: {"zh": "新潟濃厚味噌拉麵"}
- countries: (none)
- kinds: miso ramen, ramen in Niigata Prefecture
- has Wikipedia article: zh

## DISH Q115033296
- name: Paturi
- countries: (none)
- kinds: dish, type of food or dish

## DISH Q115036294
- name: 小豆粥
- countries: (none)
- kinds: congee
- has Wikipedia article: zh

## DISH Q115038633
- name: Chicken Kabiraji
- countries: (none)
- kinds: Kabiraji, chicken dish

## DISH Q115039421
- name: Prawn Kabiraji
- countries: (none)
- kinds: Kabiraji, shrimp dish

## DISH Q115039569
- name: Fish Kabiraji
- countries: (none)
- kinds: Kabiraji, fish dish

## DISH Q115040383
- name: Kolkata chicken biryani
- description: rice dish
- countries: (none)
- kinds: Kolkata biryani, chicken biryani
- ingredients: potato, chicken as food, egg as food

## DISH Q115040524
- name: Kolkata mutton biryani
- description: rice dish
- countries: (none)
- kinds: Kolkata biryani, mutton biryani

## DISH Q11504931
- name: 日切焼
- other names: {"ja": "日切焼"}
- countries: (none)
- kinds: imagawayaki, confectionery

## DISH Q115049415
- name: Jhol
- countries: (none)
- kinds: soup, type of food or dish

## DISH Q115054519
- name: Schmalzkoch
- other names: {"de": "Schmalzkoch"}
- countries: (none)
- kinds: sweet dish

## DISH Q115055877
- name: Jhal
- countries: (none)
- kinds: dish, type of food or dish

## DISH Q115058597
- name: Longsheng Pastry
- other names: {"zh": "隆盛糕点"}
- countries: CN
- kinds: pastry

## DISH Q11507075
- name: 日本一きびだんご
- other names: {"ja": "日本一きびだんご"}
- countries: JP
- kinds: dagashi, mochi

## DISH Q115098530
- name: Żulik
- other names: {"pl": "żulik"}
- countries: PL
- cuisines: Polish cuisine
- kinds: bread, sweet bread
- ingredients: cow's milk, roasted cereal grain beverage, wheat flour, baker's yeast, molasses, raisin, honey

## DISH Q11509898
- name: Hita yakisoba
- countries: (none)
- kinds: Yakisoba

## DISH Q1151092
- name: Jingisukan
- other names: {"zh": "成吉思汗 (料理)"}
- description: lamb dish
- countries: JP
- cuisines: Japanese cuisine
- kinds: lamb dish
- ingredients: sheep meat, lamb meat, onion
- has Wikipedia article: en, zh

## DISH Q11511882
- name: Kobujime
- description: Japanese cooking technique
- countries: (none)
- kinds: dish, food preparation technique

## DISH Q11511884
- name: Kobumaki
- other names: {"zh": "昆布捲"}
- countries: JP
- kinds: nimono
- ingredients: kombu

## DISH Q11512091
- name: 明方ハム
- other names: {"ja": "明方ハム"}
- countries: (none)

## DISH Q11512298
- name: Meiji Probio Yogurt R-1
- countries: JP
- kinds: yogurt

## DISH Q115125851
- name: Kugini
- description: Japanese dish
- countries: JP
- kinds: Tsukudani, kanroni, fish dish
- ingredients: Ammodytes personatus

## DISH Q115131840
- name: Kkwabaegi
- other names: {"zh": "麻花捲"}
- description: Korean twisted doughnut
- countries: (none)
- kinds: twisted doughnut

## DISH Q11513842
- name: Harusame noodles
- description: Japanese instant soup with cellophane noodles
- countries: (none)
- kinds: instant soup, cellophane noodles, cup noodle, instant food

## DISH Q115141348
- name: Jallullo
- countries: ES
- cuisines: cuisine of the Region of Murcia
- kinds: dish, pork dish
- ingredients: onion, Longaniza, peppercorn, paprika, blood sausage, olive oil, flour, table salt

## DISH Q115142470
- name: Berlingot
- description: candy from France
- countries: FR
- kinds: food, candy

## DISH Q11514494
- name: Shigureni
- other names: {"zh": "时雨煮"}
- countries: (none)
- kinds: Tsukudani
- has Wikipedia article: zh

## DISH Q11514495
- name: Shigure hamaguri
- countries: (none)
- kinds: shigureni, clam dish
- ingredients: Meretrix lusoria

## DISH Q115147923
- name: Smoked herring
- description: herring conserved by smoking
- countries: (none)
- kinds: smoked fish, herring, preserved food

## DISH Q115149470
- name: Berlingot de Berck
- other names: {"fr": "berlingot de Berck"}
- countries: (none)
- kinds: Berlingot

## DISH Q115152134
- name: Havreflarn
- description: Norwegian oatmeal lace cookies
- countries: (none)
- kinds: food, pastry
- ingredients: brown sugar, rolled oats, nutmeg, flour, cinnamon
- has Wikipedia article: en

## DISH Q11516405
- name: Aruheitō
- other names: {"zh": "有平糖"}
- countries: (none)
- kinds: Nanbangashi, sugar candy
- has Wikipedia article: zh

## DISH Q115164521
- name: Sztufada
- countries: (none)
- kinds: meat dish

## DISH Q115164693
- name: Russian stew
- countries: (none)
- kinds: roast

## DISH Q115165283
- name: Pot roasting
- description: type of food
- countries: (none)
- kinds: roast, roasting

## DISH Q115166223
- name: Kartoffelklösse
- description: potato dumpling dish
- countries: (none)
- kinds: knödel, potato-dough dumpling, food
- ingredients: potato, potato starch
- has Wikipedia article: en

## DISH Q11517869
- name: Chōsen-ame
- other names: {"zh": "朝鲜糖"}
- countries: (none)
- kinds: ame

## DISH Q11517913
- name: Kinomedaki
- other names: {"zh": "木芽煮"}
- countries: (none)
- kinds: shigureni

## DISH Q11517915
- name: Kinome dengaku
- countries: (none)
- kinds: dengaku, Japanese cuisine

## DISH Q11517918
- name: Konohadon
- countries: JP
- kinds: tamagodon, egg dish
- ingredients: kamaboko, rice

## DISH Q115188364
- name: Been cin
- countries: (none)
- kinds: rice dish

## DISH Q115193624
- name: Hamsi balığı tavası
- other names: {"tr": "Hamsi balığı tavası"}
- countries: TR
- cuisines: cuisine of the Ottoman Empire
- kinds: human food

## DISH Q115193731
- name: Hamsi balığı kızartması
- other names: {"tr": "Hamsi balığı kızartması"}
- countries: TR
- cuisines: cuisine of the Ottoman Empire
- kinds: human food

## DISH Q115193750
- name: İskorpit çorbası
- other names: {"tr": "İskorpit çorbası"}
- countries: TR
- cuisines: cuisine of the Ottoman Empire
- kinds: human food

## DISH Q115202716
- name: Roasted Bhutta
- description: roasted corn on the cob
- countries: IN
- kinds: human food, corn on the cob

## DISH Q115205140
- name: كليچة
- other names: {"ar": "كليچة"}
- countries: IQ
- kinds: cookie
- ingredients: ginger, Sesamum indicum, date, oil, flour, butter, cinnamon, milk

## DISH Q115205825
- name: Schusterjunge
- other names: {"de": "Schusterjunge"}
- description: bread roll of wheat and rye flour mixture in Germany
- countries: (none)
- kinds: bread roll
- ingredients: rye flour, wheat flour

## DISH Q11521610
- name: Hōba miso
- description: Japanese dish
- countries: JP
- kinds: vegetable dish
- ingredients: miso, leaf

## DISH Q11521612
- name: Hōba-zushi
- description: sushi made with magnolia leaf
- countries: JP
- kinds: sushi
- ingredients: leaf

## DISH Q115217655
- name: Eggplant salad
- description: salad based on eggplant
- countries: (none)
- kinds: salad
- ingredients: Eggplant Caviar
- has Wikipedia article: en

## DISH Q115259290
- name: Maraş çöreği
- other names: {"tr": "Maraş çöreği"}
- countries: (none)
- kinds: çörek

## DISH Q11527297
- name: 東村山黒焼きそば
- other names: {"ja": "東村山黒焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q1152783
- name: Klenät
- description: nordic fried pastry
- countries: (none)
- kinds: dish, doughnut
- ingredients: flour
- has Wikipedia article: en

## DISH Q1152821
- name: Profiterole
- other names: {"zh": "泡芙"}
- description: choux pastry ball filled with whipped cream, pastry cream, or ice cream
- countries: FR
- cuisines: French cuisine
- kinds: dessert, pastry
- ingredients: vanilla ice cream, chouquette, ganache, choux pastry
- has Wikipedia article: en, zh

## DISH Q11528422
- name: Tundābun
- countries: (none)
- kinds: appetizer

## DISH Q115294063
- name: Zaanlander
- description: Dutch cheese
- countries: NL
- kinds: cheese

## DISH Q11529950
- name: Matsuyama-zushi
- description: style of sushi
- countries: (none)
- kinds: chirashizushi

## DISH Q115301187
- name: Düğün kızartması
- other names: {"tr": "Düğün kızartması"}
- countries: TR
- cuisines: cuisine of the Ottoman Empire
- kinds: human food

## DISH Q115304508
- name: Archipelago bread
- description: Finnish rye and malt bread
- countries: (none)
- kinds: bread
- ingredients: rye flour, syrup, malt, buttermilk

## DISH Q115315058
- name: Biscoito
- description: type of bread used in sea navigation, cooked two times
- countries: (none)
- kinds: bread, food

## DISH Q115353571
- name: Egg-coated bread
- description: salty version of French toast
- countries: (none)
- kinds: French toast
- has Wikipedia article: en

## DISH Q11535612
- name: Tochi mochi
- countries: (none)
- kinds: mochi
- ingredients: nut

## DISH Q115356237
- name: Huevos al albañil
- description: scrambled eggs drenched in hot sauce
- countries: MX
- kinds: scrambled eggs
- has Wikipedia article: en

## DISH Q11535786
- name: Kuri kinton
- other names: {"zh": "栗金飩"}
- description: traditional Japanese confectionery
- countries: JP
- kinds: wagashi
- ingredients: chestnut, sugar

## DISH Q11536097
- name: Kuri kinton (Osechi)
- other names: {"zh": "栗金團"}
- description: candied chestnuts with sweet potatoes
- countries: JP
- kinds: dish
- ingredients: mirin, chestnut, Sweet potato

## DISH Q11536098
- name: Kuri manjū
- other names: {"zh": "栗子饅頭"}
- countries: (none)
- kinds: manjū
- ingredients: chestnut
- has Wikipedia article: zh

## DISH Q11536457
- name: 根深汁
- other names: {"ja": "根深汁"}
- countries: (none)
- kinds: miso soup

## DISH Q11537649
- name: Kippan
- description: Okinawan confection
- countries: (none)
- kinds: confectionery
- ingredients: citrus fruit
- has Wikipedia article: en

## DISH Q11537667
- name: 桜えびやきそば
- other names: {"ja": "桜えびやきそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q115377291
- name: Omelette au thon
- other names: {"fr": "omelette au thon"}
- countries: (none)
- kinds: omelette, tuna dish, egg dish, type of food or dish
- ingredients: Thunnus, egg as food

## DISH Q115380402
- name: Kirstein Blockmalz Zuckerl
- description: Austrian candy made from milk, sugar and malted barely
- countries: (none)
- kinds: candy

## DISH Q11538228
- name: 桜鍋
- other names: {"ja": "桜鍋"}
- countries: (none)
- kinds: nabemono
- ingredients: horse meat

## DISH Q11538239
- name: Sakura meshi
- countries: (none)
- kinds: takikomi gohan

## DISH Q11538378
- name: Umegaemochi
- other names: {"zh": "梅枝餅"}
- description: Rice cake confection from Fukuoka, Japan
- countries: JP
- kinds: food, yakimochi
- has Wikipedia article: en, zh

## DISH Q11538653
- name: Bainiku ekisu
- description: ume plum extract
- countries: JP
- kinds: solution, food ingredient
- ingredients: Prunus mume

## DISH Q11538971
- name: Bon bon chicken
- other names: {"zh": "棒棒鸡"}
- description: Sichuan chicken dish
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q11540467
- name: Saogashi
- countries: (none)
- kinds: wagashi

## DISH Q1154164
- name: Dak-galbi
- other names: {"zh": "春川铁板鸡"}
- description: Korean spicy stir-fried chicken dish
- countries: KR
- cuisines: South Korean cuisine
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q11542213
- name: 標津羊羹
- other names: {"ja": "標津羊羹"}
- countries: (none)
- kinds: Yōkan

## DISH Q1154225
- name: Kopytka
- description: potato dish
- countries: PL
- kinds: potato-dough dumpling
- ingredients: potato
- has Wikipedia article: en

## DISH Q11542761
- name: Yokote yakisoba
- other names: {"zh": "橫手炒麵"}
- countries: (none)
- kinds: Yakisoba
- ingredients: fried egg

## DISH Q115450440
- name: Bettelsuppe
- other names: {"de": "Bettelsuppe"}
- countries: (none)
- kinds: soup

## DISH Q11547034
- name: Zankokuyaki
- countries: (none)
- kinds: seafood dish, yakimono

## DISH Q115474
- name: Tangyuan
- other names: {"zh": "汤圆"}
- description: Chinese dessert
- countries: CN
- kinds: dumpling, rice dish
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q11547523
- name: 毛利の殿さま巻
- other names: {"ja": "毛利の殿さま巻"}
- countries: (none)
- kinds: wagashi

## DISH Q11548023
- name: Kesennuma horumon
- countries: (none)
- kinds: horumonyaki

## DISH Q115483255
- name: おせき餅
- other names: {"ja": "おせき餅"}
- countries: (none)
- kinds: wagashi

## DISH Q11548572
- name: 水戸の梅
- other names: {"ja": "水戸の梅"}
- countries: JP
- kinds: wagashi

## DISH Q11548633
- name: Mito Natto
- description: brand in Mito, Ibaraki, Japan
- countries: JP
- kinds: nattō

## DISH Q11548637
- name: Mito clan ramen
- countries: (none)
- kinds: ramen

## DISH Q11548941
- name: Mizutaki
- other names: {"zh": "水炊鍋"}
- countries: JP
- kinds: nabemono

## DISH Q115490972
- name: 中日そば
- other names: {"ja": "中日そば"}
- countries: JP
- kinds: human food
- ingredients: chirimen jako, tororo kombu, Youmian, hōtō, Satsuma-age, narutomaki, Welsh onion

## DISH Q11549231
- name: Mizugai
- description: abalone sashimi
- countries: JP
- kinds: sashimi

## DISH Q11549267
- name: Suigun nabe
- countries: JP
- cuisines: Suigun cuisine
- kinds: nabemono

## DISH Q11549639
- name: 冰見咖哩
- countries: (none)
- kinds: Japanese curry

## DISH Q11549659
- name: Hizu namasu
- other names: {"zh": "冰头"}
- countries: (none)
- kinds: namasu, salmon dish
- has Wikipedia article: zh

## DISH Q11550577
- name: Enoshima-don
- countries: (none)
- kinds: donburi

## DISH Q11550988
- name: 江戸三鮨
- other names: {"ja": "江戸三鮨"}
- countries: (none)
- kinds: sushi, triad

## DISH Q11551104
- name: 江戸甘味噌
- other names: {"ja": "江戸甘味噌"}
- countries: JP
- kinds: miso

## DISH Q115512140
- name: Stuffed sweet peppers
- countries: (none)
- kinds: stuffed peppers

## DISH Q115515499
- name: Gâteau au vin
- description: Swiss tart filled with a mixture of sugar and reduced white wine
- countries: CH
- kinds: tart
- ingredients: white wine

## DISH Q115518680
- name: Mandorlato
- other names: {"it": "Mandorlato"}
- countries: IT
- kinds: human food
- ingredients: egg white, almond, honey

## DISH Q115519518
- name: Kebab pizza
- description: Swedish dish of pizza topped with kebab meat and other ingredients
- countries: SE
- cuisines: Swedish cuisine
- ingredients: kebab
- has Wikipedia article: en

## DISH Q11552547
- name: Okizuke
- description: seafood marinated in soy sauce
- countries: JP
- kinds: seafood dish

## DISH Q11554312
- name: Cracklings
- other names: {"zh": "油渣"}
- description: snack foods of various countries made of grilled scraps of fat and animal skin
- countries: (none)
- kinds: snack, meat dish
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q11554329
- name: 油味噌かつサンド
- other names: {"ja": "油味噌かつサンド"}
- countries: JP
- kinds: food, katsu sandwich

## DISH Q11554370
- name: You lin ji
- other names: {"zh": "油淋鸡"}
- description: fried chicken dish in Japanese-Chinese and Korean-Chinese cuisines
- countries: (none)
- kinds: chicken dish, fried chicken

## DISH Q115549260
- name: Galchi-jorim
- countries: KR
- kinds: jorim
- ingredients: Largehead hairtail

## DISH Q115549787
- name: Kongnamul-bap
- description: soybean sprout rice
- countries: (none)
- kinds: cooked rice
- ingredients: soybean sprout, rice

## DISH Q115550020
- name: Mabo nasu
- countries: JP
- cuisines: Japanese Chinese cuisine
- kinds: dish

## DISH Q11555357
- name: 法論味噌
- other names: {"ja": "法論味噌"}
- countries: (none)
- kinds: miso

## DISH Q11555424
- name: 波まくら
- other names: {"ja": "波まくら"}
- countries: JP
- kinds: wagashi
- ingredients: nama senbei, sweet bean paste

## DISH Q11556392
- name: Tsugaru ramen
- countries: (none)
- kinds: ramen

## DISH Q11556400
- name: 津軽味噌
- other names: {"ja": "津軽味噌"}
- countries: (none)
- kinds: miso

## DISH Q11559112
- name: Ebikatsu
- countries: (none)
- kinds: katsu

## DISH Q11559212
- name: Kaitōge
- description: octopus eggs
- countries: (none)
- kinds: octopus dish

## DISH Q11559234
- name: 海賊焼
- other names: {"ja": "海賊焼"}
- countries: (none)
- kinds: Yakisoba

## DISH Q11559814
- name: 淡路島ぬーどる
- other names: {"ja": "淡路島ぬーどる"}
- countries: (none)
- kinds: noodle dish

## DISH Q11559815
- name: Awajishima Burger
- countries: JP
- kinds: hamburger

## DISH Q11559819
- name: 淡路島牛丼
- other names: {"ja": "淡路島牛丼"}
- countries: (none)
- kinds: gyūdon

## DISH Q11559843
- name: Awayuki
- countries: (none)
- kinds: Yōkan
- ingredients: meringue, agar

## DISH Q115607763
- name: Bean paste
- description: paste made of beans
- countries: (none)
- kinds: food paste, legume dish

## DISH Q115607987
- name: Cutlet de volaille
- description: Russian chicken dish
- countries: RU
- cuisines: Russian cuisine, Soviet cuisine
- kinds: dish
- ingredients: chicken as food

## DISH Q115610227
- name: Novomikhailovsk cutlets
- description: forgotten dish of Russian cuisine
- countries: RU
- cuisines: Russian cuisine
- kinds: dish
- ingredients: white bread, chicken as food, butter, cream

## DISH Q115615436
- name: Qudrat qadir
- countries: PS
- kinds: type of food or dish, cake

## DISH Q115618304
- name: Cakes and dessert bar
- description: type of food
- countries: (none)
- kinds: dessert

## DISH Q115618375
- name: Tortilla and wrap bread
- description: product category
- countries: (none)
- kinds: flatbread

## DISH Q115618379
- name: Candy covered fruit
- description: type of product
- countries: (none)
- kinds: dessert, confectionery, product category

## DISH Q115619093
- name: Ice cream novelty
- description: type of dessert
- countries: (none)
- kinds: dessert

## DISH Q115619132
- name: Sticky rice cake
- description: type of product
- countries: (none)
- kinds: snack, rice cake

## DISH Q115619224
- name: Ice cream and frozen yogurt
- description: product category
- countries: (none)
- kinds: frozen dessert, product category
- ingredients: frozen yogurt, ice cream

## DISH Q115626192
- name: Oatmeal porridge
- other names: {"zh": "燕麦粥"}
- description: porridge from oat grains
- countries: (none)
- kinds: porridge, oatmeal
- ingredients: oatmeal, rolled oats, table salt, sugar, drinking water
- has Wikipedia article: en

## DISH Q11562894
- name: 温たまらん丼
- other names: {"ja": "温たまらん丼"}
- countries: JP
- kinds: donburi

## DISH Q11562975
- name: Onsen manjū
- countries: (none)
- kinds: manjū, Miyagegashi

## DISH Q11563737
- name: Yuzuke
- countries: (none)
- kinds: Japanese rice dish

## DISH Q11564080
- name: 源平鍋
- other names: {"ja": "源平鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q115641438
- name: Couvert
- description: in Portugal, appetizers placed on the table at the start of a meal
- countries: PT
- kinds: custom, appetizer

## DISH Q11564153
- name: 源氏巻
- other names: {"ja": "源氏巻"}
- countries: JP
- kinds: confectionery

## DISH Q11565590
- name: Tsukemono steak
- countries: (none)
- kinds: vegetable dish
- ingredients: tsukemono

## DISH Q11565716
- name: Ushio-jiru
- countries: JP
- kinds: shirumono, seafood dish

## DISH Q1156634
- name: Ice cream cone
- other names: {"zh": "蛋卷冰淇淋"}
- description: dry, cone-shaped pastry, which enables ice cream to be held in the hand
- countries: IT
- kinds: pastry, finger food
- ingredients: wafer cookie, dough, flour
- has Wikipedia article: en, zh

## DISH Q115663659
- name: French hotdog
- description: regional variation of hot dog
- countries: DK
- cuisines: Danish cuisine
- kinds: hot dog
- ingredients: condiment, sausage, bread

## DISH Q11566510
- name: 瀬戸しょうゆ焼きそば
- other names: {"ja": "瀬戸しょうゆ焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q1156703
- name: Dachhase
- other names: {"de": "Dachhase"}
- countries: (none)
- kinds: dish

## DISH Q11567137
- name: Tansan senbei
- countries: (none)
- kinds: senbei, Miyagegashi

## DISH Q11567617
- name: Grilled eggplant
- countries: (none)
- kinds: yakimono

## DISH Q11567618
- name: Yaki karē
- other names: {"zh": "烤咖哩"}
- description: Japanese dish
- countries: JP
- kinds: Japanese curry rice
- ingredients: Japanese curry rice, cheese

## DISH Q11567619
- name: Yakimanjū
- countries: JP
- kinds: manjū

## DISH Q11567620
- name: Yaki ramen
- countries: JP
- kinds: ramen, fried noodle

## DISH Q11567626
- name: Yakidofu
- description: Japanese food item
- countries: (none)
- kinds: tofu

## DISH Q11567674
- name: 焼肉さん太郎
- other names: {"ja": "焼肉さん太郎"}
- countries: JP
- kinds: dagashi

## DISH Q11567681
- name: Yakibuta tamago meshi
- countries: (none)
- kinds: Japanese rice dish, pork dish, egg dish
- ingredients: chāshū, cooked rice, fried egg

## DISH Q11567691
- name: Yakisaba-somen
- description: local cuisine in Nagahama, Shiga, Japan
- countries: (none)
- kinds: sōmen, dish

## DISH Q11567713
- name: Irizake
- countries: JP
- kinds: condiment
- ingredients: umeboshi, sake

## DISH Q11567797
- name: Nishime
- countries: (none)
- kinds: nimono

## DISH Q11567802
- name: 煮込みジンギスカン
- other names: {"ja": "煮込みジンギスカン"}
- countries: JP
- kinds: nabemono

## DISH Q11567803
- name: Nizakana
- description: Japanese poached fish dish
- countries: JP
- kinds: nimono, fish dish

## DISH Q115678396
- name: Buckwheat porridge
- description: type of porridge
- countries: RU, PL, UA, BY, SI, LT
- cuisines: Russian cuisine, Polish cuisine, Ukrainian cuisine, Belarusian cuisine, Slovenian cuisine, Lithuanian cuisine
- kinds: porridge, kasha
- ingredients: buckwheat seed

## DISH Q11567931
- name: Kumamoto ramen
- other names: {"zh": "熊本拉面"}
- description: Japanese noodle soup
- countries: JP
- kinds: dish, tonkotsu ramen
- has Wikipedia article: zh

## DISH Q115686593
- name: Tome de Bray
- countries: FR
- kinds: cheese
- ingredients: cow's milk

## DISH Q115686609
- name: Meule de Bray
- countries: FR
- kinds: cheese
- ingredients: cow's milk

## DISH Q115688586
- name: Pata negra
- countries: (none)
- kinds: ham

## DISH Q115690026
- name: Sfogliatine glassate
- countries: (none)
- kinds: pastry

## DISH Q11569253
- name: Tsubame seabura ramen
- other names: {"zh": "燕三條背脂拉麵"}
- countries: (none)
- kinds: ramen in Niigata Prefecture

## DISH Q11570019
- name: Gyūkatsu
- other names: {"zh": "吉列牛"}
- description: fried beef cutlet
- countries: JP
- kinds: yōshoku, beef dish, katsu
- ingredients: beef
- has Wikipedia article: en

## DISH Q115700524
- name: Зандкухен
- other names: {"ru": "зандкухен"}
- countries: RU
- cuisines: Russian cuisine
- kinds: dish, cookie
- ingredients: shortcrust pastry, almond

## DISH Q11570067
- name: Milk senbei
- countries: (none)
- kinds: dairy product, senbei
- ingredients: cow's milk

## DISH Q115702169
- name: Cucumber soup
- description: soup made of cucumbers
- countries: (none)
- kinds: vegetable soup
- ingredients: cucumber
- has Wikipedia article: en

## DISH Q11570229
- name: Gobōmochi
- countries: JP
- kinds: mochi

## DISH Q11570320
- name: Kaki no dotenabe
- description: Japanese oyster pot
- countries: JP
- kinds: nabemono, oyster dish
- ingredients: miso, oyster

## DISH Q11570322
- name: 牡蠣最中
- other names: {"ja": "牡蠣最中"}
- countries: JP
- kinds: monaka

## DISH Q115708671
- name: Mushroom omelette
- countries: (none)
- kinds: dish

## DISH Q115714347
- name: Zrazy à la Nelson
- countries: RU, PL
- cuisines: Russian cuisine, Polish cuisine
- kinds: dish, zrazy
- ingredients: dried mushrooms, onion, beef

## DISH Q115714743
- name: Blodpudding
- description: a type of food made out of pigs blood
- countries: SE, NO
- cuisines: Swedish cuisine, Norwegian cuisine
- kinds: food ingredient, savory pudding, blood as food
- ingredients: blood as food, majoram herb, pig blood, rye flour, syrup, svagdricka, allspice, blubber, ale, milk

## DISH Q115714993
- name: Herring salad
- countries: DE, PL
- cuisines: Polish cuisine
- kinds: salad, fish dish
- ingredients: Clupea

## DISH Q11572403
- name: Tamausagi
- countries: JP
- kinds: Miyagegashi, rakugan

## DISH Q11572418
- name: Tamana ramen
- countries: (none)
- kinds: tonkotsu ramen

## DISH Q11572492
- name: Tamagodon
- countries: JP
- kinds: donburi, egg dish
- ingredients: egg as food, rice

## DISH Q11572769
- name: Tama yokan
- description: ball-shaped yokan
- countries: (none)
- kinds: Yōkan

## DISH Q115732147
- name: Yangnyeom-gejang
- countries: (none)
- kinds: gejang

## DISH Q11573721
- name: Kingyoku-kan
- countries: (none)
- kinds: wagashi
- ingredients: agar

## DISH Q11574180
- name: Kawara senbei
- description: roof tile shaped wheat cracker
- countries: JP
- kinds: senbei

## DISH Q11574182
- name: Kawara soba
- other names: {"zh": "瓦蕎麥"}
- countries: JP
- kinds: soba, fried noodle

## DISH Q11574227
- name: Kankanbō
- countries: (none)
- kinds: ame
- ingredients: kinako

## DISH Q11574320
- name: Amashoku
- description: Japanese flat cake
- countries: JP
- kinds: bakers' confection

## DISH Q11574384
- name: Nama senbei
- countries: JP
- kinds: namagashi

## DISH Q11574395
- name: 生キャラメル
- other names: {"ja": "生キャラメル"}
- countries: (none)
- kinds: caramel

## DISH Q11574427
- name: Namaribushi
- description: Semi-dried steamed bonito fillets
- countries: JP
- kinds: katsuobushi
- ingredients: skipjack tuna

## DISH Q115754730
- name: Onze-Lieve-Vrouw guimauves
- other names: {"nl": "Onze-Lieve-Vrouw guimauves"}
- countries: (none)
- kinds: sweetmeat

## DISH Q115766697
- name: Vieta (dish)
- description: food produced from flax
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q11576725
- name: 田川ホルモン鍋
- other names: {"ja": "田川ホルモン鍋"}
- countries: (none)
- kinds: nabemono, offal dish

## DISH Q1157710
- name: Daitokuji nattō
- other names: {"zh": "大德寺納豆"}
- description: Japanese dish
- countries: (none)
- kinds: dish, nattō

## DISH Q1157769
- name: Daktyla
- description: food
- countries: GR
- kinds: food, bread
- ingredients: wheat
- has Wikipedia article: en

## DISH Q11577834
- name: Kōfu tori motsuni
- other names: {"zh": "甲府雞雜煮"}
- countries: JP
- kinds: motsuni, chicken dish
- ingredients: offal

## DISH Q11578189
- name: Oga Shottsuru Yakisoba
- description: regional yakisoba dish from Oga, Akita Prefecture, Japan
- countries: JP
- cuisines: Japanese cuisine
- kinds: dish, Yakisoba
- ingredients: Shottsuru

## DISH Q115791834
- name: Cassia leaves curry
- countries: TH
- cuisines: Thai cuisine
- kinds: Thai curry
- ingredients: curry paste, coconut milk, Senna siamea

## DISH Q11579290
- name: 白出汁
- countries: (none)
- kinds: dashi

## DISH Q11579516
- name: 白子流ブイヤベース
- other names: {"ja": "白子流ブイヤベース"}
- countries: (none)
- kinds: bouillabaisse

## DISH Q1157952
- name: Lívance
- countries: (none)
- kinds: viennoiserie

## DISH Q11579832
- name: 白松餡餅
- countries: (none)
- kinds: monaka

## DISH Q115798940
- name: Pan camaleón
- other names: {"es": "Pan camaleón"}
- countries: (none)
- kinds: bread, dish

## DISH Q11579948
- name: Shirakawa ramen
- other names: {"zh": "白河拉麵"}
- countries: (none)
- kinds: shoyu ramen
- has Wikipedia article: zh

## DISH Q115799674
- name: Rum raisin
- description: ice cream flavor
- countries: (none)
- kinds: food, ice cream
- has Wikipedia article: en

## DISH Q11580081
- name: Shiratama
- other names: {"zh": "白玉 (食物)"}
- countries: (none)
- kinds: dango
- has Wikipedia article: zh

## DISH Q115800879
- name: Pasta allo scarpariello
- description: Italian pasta dish
- countries: (none)
- kinds: pasta dish
- has Wikipedia article: en

## DISH Q115801829
- name: Balmoral chicken
- description: chicken dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q115801864
- name: Pasta â Paolina
- description: sicilian food
- countries: IT
- kinds: dish
- has Wikipedia article: en

## DISH Q115801972
- name: Possum pie
- description: type of American pie
- countries: (none)
- kinds: pie, dish
- has Wikipedia article: en

## DISH Q115802607
- name: Pasta chi Vrocculi Arriminati
- description: sicilian pasta dish
- countries: (none)
- kinds: pasta dish
- has Wikipedia article: en

## DISH Q115802819
- name: Estufao
- description: chamorro meat dish
- countries: (none)
- kinds: meat dish, stew
- has Wikipedia article: en

## DISH Q115802987
- name: Tinaktak
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q11580315
- name: Shiraoi seafood curry
- countries: (none)
- kinds: Japanese curry

## DISH Q115804031
- name: Latiya
- description: chamorro cake
- countries: GU
- cuisines: cuisine of the United States
- kinds: type of food or dish, confectionery
- ingredients: pastry cream, castella, cinnamon
- has Wikipedia article: en

## DISH Q115804147
- name: Kaddon pika
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q11580451
- name: White bean paste
- countries: (none)
- kinds: sweet bean paste
- ingredients: navy bean

## DISH Q11580511
- name: Shirauo kōbaini
- countries: JP
- kinds: shigureni, fish dish
- ingredients: Salangidae

## DISH Q11581336
- name: Morioka jajamen
- other names: {"zh": "盛岡炸醬麵"}
- description: Japanese noodle dish, originating from the Chinese zhajiangmian
- countries: JP
- kinds: noodle dish
- has Wikipedia article: en

## DISH Q115814329
- name: Milk Bar Pie
- description: Dessert
- countries: US
- kinds: pie
- has Wikipedia article: en

## DISH Q11581573
- name: Medamayakidon
- other names: {"zh": "煎蛋蓋飯"}
- description: Japanese rice dish of sunny-side up
- countries: (none)
- kinds: donburi, egg dish
- ingredients: fried egg

## DISH Q115816722
- name: Cereal Milk
- description: Milk flavored with breakfast cereal
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q115819779
- name: Boerenkool stamppot
- description: Dutch kale dish
- countries: NL
- cuisines: Dutch cuisine
- kinds: food, Grünkohlessen, Stamppot
- ingredients: rookworst, mashed potato, kale, bacon

## DISH Q115858747
- name: Polish Breton beans
- description: Polish bean stew/soup
- countries: (none)
- kinds: baked beans

## DISH Q115859451
- name: Hildaplätzchen
- other names: {"de": "Hildaplätzchen"}
- countries: (none)
- kinds: Plätzchen

## DISH Q11586488
- name: 石卷炒麵
- countries: (none)
- kinds: Yakisoba

## DISH Q11586883
- name: Ishikari-nabe
- other names: {"zh": "石狩鍋"}
- countries: JP
- kinds: nabemono, salmon dish
- has Wikipedia article: zh

## DISH Q11588062
- name: 磯部せんべい
- other names: {"ja": "磯部せんべい"}
- countries: (none)
- kinds: senbei

## DISH Q11588447
- name: Gion-dōfu
- countries: (none)
- kinds: tofu

## DISH Q11588682
- name: Jindai curry
- description: curry dish from Semboku, Akita Prefecture, Japan
- countries: (none)
- kinds: Japanese curry

## DISH Q115907596
- name: Pasta ca nunnata
- description: Sicilian pasta dish
- countries: (none)
- kinds: pasta dish
- has Wikipedia article: en

## DISH Q115908352
- name: Among Us chicken nugget
- description: chicken nugget and internet pareidolia
- countries: (none)
- kinds: Chicken McNuggets, chicken nugget

## DISH Q115917315
- name: Arbi (dish)
- description: South asian cuisine
- countries: IN
- cuisines: Indian cuisine

## DISH Q11592112
- name: Fukuyamasu
- countries: JP
- kinds: food, black vinegar

## DISH Q11593816
- name: Fukubiki senbei
- countries: (none)
- kinds: senbei

## DISH Q11593881
- name: Fukuume
- countries: (none)
- kinds: monaka, New Year's food

## DISH Q115940023
- name: Punyeta
- other names: {"ca": "Punyeta"}
- countries: (none)
- kinds: sweetmeat

## DISH Q115940142
- name: Pastís de Sant Bartomeu
- other names: {"ca": "Pastís de Sant Bartomeu"}
- countries: (none)
- kinds: cake

## DISH Q115941817
- name: Coquetes de Cacau
- other names: {"ca": "Coquetes de Cacau"}
- countries: ES
- kinds: snack, baked good
- ingredients: peanut, flour

## DISH Q11594880
- name: Sanma-zushi
- countries: JP
- kinds: oshizushi
- ingredients: Pacific saury

## DISH Q115959653
- name: Cuddureddi di Alcamo
- other names: {"it": "Cuddureddi di Alcamo"}
- countries: IT
- kinds: dish, Cuddureddi PAT
- ingredients: marmalade, sweetcrust pastry, almond, Ficus carica, raisin, nut, honey, chocolate

## DISH Q11596840
- name: Igamochi
- description: wagashi in Japan
- countries: (none)
- kinds: mochi, wagashi
- ingredients: jōshinko

## DISH Q11597028
- name: Kokusen
- countries: (none)
- kinds: okoshi

## DISH Q11598630
- name: 竹ちくわ
- other names: {"ja": "竹ちくわ"}
- countries: (none)
- kinds: Chikuwa

## DISH Q11599096
- name: Takeoka ramen
- other names: {"zh": "竹岡拉麵"}
- countries: (none)
- kinds: shoyu ramen

## DISH Q11599871
- name: Kasaoka ramen
- countries: (none)
- kinds: shoyu ramen, ramen in Okayama Prefecture, chicken dish

## DISH Q116007922
- name: Soupe de Chalet
- other names: {"ca": "Soupe de Chalet"}
- countries: (none)
- kinds: soup

## DISH Q116008541
- name: Semolino dolce
- other names: {"it": "semolino dolce"}
- countries: IT
- kinds: sweet dish

## DISH Q116009562
- name: Kaeng ranchuan
- description: Thai curry
- countries: (none)
- kinds: Thai curry

## DISH Q11602513
- name: Sasa dango
- other names: {"zh": "笹糰子"}
- description: Japanese dessert
- countries: JP
- kinds: dango
- has Wikipedia article: zh

## DISH Q11602530
- name: Sasa-zushi
- description: kind of sushi
- countries: JP
- kinds: oshizushi
- ingredients: leaf

## DISH Q11602532
- name: Nagano–Niigata sasazushi
- description: kind of sushi
- countries: JP
- kinds: sushi
- ingredients: leaf

## DISH Q11602756
- name: Suji kamaboko
- countries: JP
- kinds: fish surimi

## DISH Q11602975
- name: 筑豊とんちゃん
- other names: {"ja": "筑豊とんちゃん"}
- countries: (none)
- kinds: offal dish

## DISH Q116031902
- name: Pasta e patate
- other names: {"it": "pasta e patate"}
- description: Italian pasta dish
- countries: IT
- cuisines: cucina povera
- kinds: pasta dish
- ingredients: potato, pasta

## DISH Q116039190
- name: Солёные арбузы
- other names: {"ru": "солёные арбузы"}
- countries: RU
- cuisines: Russian cuisine
- kinds: dish, pickle
- ingredients: watermelon

## DISH Q11604251
- name: Yonezawa ramen
- other names: {"zh": "米澤拉麵"}
- countries: (none)
- kinds: shoyu ramen, Yamagata ramen

## DISH Q11604446
- name: 粉吹芋
- other names: {"ja": "粉吹芋"}
- countries: (none)
- kinds: potato dish

## DISH Q11604467
- name: 粉豆腐汁
- other names: {"ja": "粉豆腐汁"}
- countries: (none)
- kinds: miso soup

## DISH Q11604498
- name: Kasujiru
- description: sake lee soup
- countries: JP
- kinds: shirumono
- ingredients: Sake kasu

## DISH Q11604545
- name: Awa-okoshi
- countries: (none)
- kinds: okoshi
- ingredients: rice

## DISH Q11604648
- name: 粟飴
- other names: {"ja": "粟飴"}
- countries: (none)
- kinds: mizuame

## DISH Q11604650
- name: Awa mochi
- countries: (none)
- kinds: mochi
- ingredients: Setaria italica

## DISH Q11604652
- name: Awamanju
- countries: (none)
- kinds: manjū

## DISH Q11604874
- name: 糸魚川ブラック焼きそば
- other names: {"ja": "糸魚川ブラック焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q1160522
- name: Gumbo
- other names: {"zh": "秋葵汤饭"}
- description: Louisianan stew
- countries: US
- cuisines: cuisine of the United States, Cajun cuisine
- kinds: food, stew
- ingredients: celery, okra, onion, filé, bell pepper, roux, Abelmoschus esculentus, Brachyura, tomato, Ostreidae, Capsicum annuum
- has Wikipedia article: en, zh

## DISH Q11605373
- name: Natto-jiru
- other names: {"zh": "豆汁"}
- description: natto miso soup
- countries: JP
- kinds: miso soup
- ingredients: nattō

## DISH Q11605555
- name: Su ramen
- countries: (none)
- kinds: ramen

## DISH Q11605763
- name: 紫輝彩丼
- other names: {"ja": "紫輝彩丼"}
- countries: JP
- kinds: donburi

## DISH Q11608010
- name: Nerikiri
- other names: {"zh": "練切"}
- description: Japanese confection
- countries: JP
- kinds: wagashi, nerigashi
- has Wikipedia article: zh

## DISH Q11608013
- name: Nerigashi
- countries: (none)
- kinds: namagashi

## DISH Q11608826
- name: Umadare yakitori
- countries: (none)
- kinds: yakitori
