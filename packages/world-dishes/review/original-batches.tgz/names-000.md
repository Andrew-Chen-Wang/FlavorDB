# Review batch names-000

## DISH Q10000271
- name: Ice cream cup
- description: a small container to hold single servings of ice cream
- countries: (none)
- kinds: type of food or dish, frozen dessert

## DISH Q1000176
- name: Chaource cheese
- other names: {"zh": "沙乌斯奶酪"}
- description: French cheese
- countries: FR
- kinds: French cheese, cow's-milk cheese, dairy cheese, white mold-rind cheese, farmstead cheese, industrial cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q100136136
- name: Yasai Tappuri Tantan-men
- countries: (none)
- kinds: dandan noodles

## DISH Q100138568
- name: Tokusei Ramen
- countries: (none)
- kinds: ramen

## DISH Q100144799
- name: Kamalabhog
- description: sweet of Bengal
- countries: (none)
- kinds: dessert, confectionery
- ingredients: chhena, semolina, sugar

## DISH Q100148345
- name: Krakauer
- other names: {"de": "Krakauer"}
- countries: AT
- kinds: sausage

## DISH Q100151408
- name: Gomoku Gohan
- countries: (none)
- kinds: cooked rice

## DISH Q100153848
- name: Begun bhaja
- description: pan fried or shallow fried marinated slices of Aubergines/eggplant, a Bengali dish
- countries: (none)
- kinds: eggplant dish, Bhaja
- ingredients: turmeric, eggplant, mustard oil, garam masala, table salt

## DISH Q100235336
- name: Papasìn
- other names: {"it": "Papasìn"}
- countries: IT
- kinds: dessert

## DISH Q1002439
- name: Mandarin roll
- other names: {"zh": "花卷"}
- description: food
- countries: CN
- kinds: bread
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q100249834
- name: Frog frittata
- description: food dish
- countries: (none)
- kinds: frittata, dish

## DISH Q100255577
- name: Labra tarkari
- description: Bengali vegetarian dish
- countries: IN
- kinds: tarkari, dish
- ingredients: vegetable

## DISH Q100255672
- name: Moho
- countries: ID
- kinds: kue, snack
- ingredients: wheat flour, rice flour, coconut milk, sugar

## DISH Q100258323
- name: عقدة لحم
- other names: {"ar": "عقدة لحم"}
- countries: YE
- kinds: dish

## DISH Q100258324
- name: ذمول
- other names: {"ar": "ذمول"}
- countries: (none)
- kinds: dish

## DISH Q100258330
- name: كبانة
- other names: {"ar": "كبانة"}
- countries: (none)
- kinds: Kuchen

## DISH Q100258377
- name: Makhlama
- countries: IQ
- kinds: food, dish

## DISH Q100258624
- name: كنافة البوظة
- other names: {"ar": "كنافة البوظة"}
- countries: (none)
- kinds: confectionery

## DISH Q100258740
- name: Arook
- description: traditional Iraqi dish
- countries: IQ
- kinds: dish
- has Wikipedia article: en

## DISH Q100276607
- name: Riz Gaxuxa
- countries: ES, FR
- cuisines: Basque cuisine
- kinds: dish
- ingredients: green olive

## DISH Q100276703
- name: Potato casserole
- description: casserole made with potatoes
- countries: (none)
- kinds: casserole
- ingredients: potato

## DISH Q100276875
- name: Barley soup
- countries: (none)
- kinds: soup, type of food or dish

## DISH Q100281422
- name: Megono
- description: Indonesian traditional dish from pekalogan
- countries: ID
- cuisines: Javanese cuisine
- kinds: food, human food
- ingredients: jackfruit, grated coconut, spice, rice, onion, coconut, chili pepper
- has Wikipedia article: en

## DISH Q100285178
- name: Ofé Olugbo
- description: soup peculiar to Ndị Igbo
- countries: NG
- kinds: meat soup, type of food or dish, food
- ingredients: Gymnanthemum extensum, cocoyam, crayfish, palm oil, Capsicum, table salt, meat, water, fish
- has Wikipedia article: en

## DISH Q1002865
- name: Shimotsukare
- other names: {"zh": "下野家例"}
- description: Japanese vegetable dish
- countries: JP
- kinds: salmon dish
- ingredients: soy bean, aramaki, Sake kasu, root vegetable
- has Wikipedia article: en, zh

## DISH Q100287557
- name: Mushroom burger
- description: hamburger prepared with a portobello mushroom cap
- countries: (none)
- kinds: veggie burger, mushroom dish
- ingredients: Agaricus bisporus

## DISH Q100320697
- name: Margi special
- description: Nigerian cuisine made with fish, indigenous to the Margi people of the North eastern region of Nigeria
- countries: NG
- kinds: food, soup
- ingredients: spinach, Garlick, tomato, fish
- has Wikipedia article: en

## DISH Q100323254
- name: Fried tofu
- other names: {"zh": "油豆腐"}
- description: food
- countries: (none)
- kinds: tofu, Agemono, type of food or dish
- has Wikipedia article: zh

## DISH Q100327532
- name: Koekelaring
- other names: {"nl": "Koekelaring"}
- countries: BE
- kinds: bread, tradition, pastry
- ingredients: egg as food, flour, butter, cinnamon, sugar, milk

## DISH Q100331599
- name: き花
- other names: {"ja": "き花"}
- countries: (none)
- kinds: confectionery

## DISH Q1004735
- name: Bulz
- description: dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q100507578
- name: Grasshopper pie
- description: no- bake mousse pie
- countries: US
- cuisines: cuisine of the United States
- kinds: pie
- has Wikipedia article: en

## DISH Q100507813
- name: Butterscotch pie
- description: pie in American cuisine
- countries: (none)
- kinds: pie
- ingredients: brown sugar, cream, milk
- has Wikipedia article: en

## DISH Q100529246
- name: Punten
- description: traditional food from East Java, Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Javanese cuisine
- kinds: pecel, glutinous rice cake, dish, human food, traditional food, type of food or dish
- ingredients: coconut milk, glutinous rice, table salt

## DISH Q100533643
- name: Mi nyemek
- description: Nyemek noodle from Java
- countries: ID
- kinds: noodle dish
- ingredients: chicken as food, noodle, egg as food

## DISH Q100606305
- name: Bada reuteuk
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: cookie, dessert, dish, snack
- ingredients: Saccharum, rice flour, Vigna radiata, egg as food, table salt, water

## DISH Q1006977
- name: Zhangcha duck
- other names: {"zh": "樟茶鸭"}
- description: Sichuan dish, prepared by hot-smoking a marinated duck over tea leaves
- countries: CN
- kinds: dish
- ingredients: duck meat
- has Wikipedia article: en, zh

## DISH Q100701181
- name: Beras rendang
- other names: {"id": "Beras rendang"}
- countries: ID
- kinds: snack, food
- ingredients: rice flour, sugar

## DISH Q1007983
- name: Ganca
- description: Dish of corn
- countries: RO
- kinds: dish
- ingredients: maize

## DISH Q100892499
- name: Gelamai perentak
- description: Indonesian food
- countries: (none)
- kinds: Indonesian cuisine, Dodol, snack, sweet dish

## DISH Q100989033
- name: Scrambled eggs with char siu
- countries: HK
- cuisines: Hong Kong cuisine
- kinds: dish
- ingredients: char siu, scrambled eggs

## DISH Q101020313
- name: Caviadini
- other names: {"it": "Caviadini"}
- countries: IT
- kinds: food, cookie, biscuit
- ingredients: egg as food, flour, butter, sugar

## DISH Q101028555
- name: Melting moment
- description: biscuit popular in New Zealand
- countries: NZ
- kinds: cookie
- ingredients: corn starch, powdered sugar, flour, butter

## DISH Q101029041
- name: Yoyo
- description: type of biscuit popular in Australia
- countries: (none)
- kinds: cookie

## DISH Q101064564
- name: Teufelssalat
- other names: {"de": "Teufelssalat"}
- countries: (none)
- kinds: salad

## DISH Q101084341
- name: Game field pizza
- description: Argentine type of pizza
- countries: (none)
- kinds: fast food

## DISH Q101092304
- name: Grammelknödel
- description: dish from the Austrian cuisine
- countries: (none)
- kinds: knödel, Erdäpfelknödel

## DISH Q101093727
- name: Pork and sauerkraut casserole
- description: Austrian dish
- countries: AT
- cuisines: Austrian cuisine
- kinds: dish
- ingredients: pork, sauerkraut

## DISH Q101113014
- name: Сяртчынянь
- other names: {"be": "Сяртчынянь"}
- countries: (none)
- kinds: pie
- ingredients: Brassica napus subsp. rapifera

## DISH Q101115409
- name: Babi guling
- description: Indonesian roast pig
- countries: ID
- kinds: Roast pig
- ingredients: garlic, five-spice powder, soy sauce, pork, acetic acid, table salt, sugar

## DISH Q101121317
- name: Pfingststrudel
- countries: (none)
- kinds: pastry, sweet dish
- ingredients: yeast dough

## DISH Q101122441
- name: St. Martin's goose
- description: roasted goose - traditional meal in Europe on St. Martin's day, November 11.
- countries: AT
- cuisines: Austrian cuisine
- kinds: roast goose, dish, traditional food
- ingredients: red cabbage, domestic goose, knödel

## DISH Q101198711
- name: Erdäpfelknödel
- countries: AT
- kinds: raspeball, knödel, potato dish

## DISH Q101208157
- name: Dil peyniri
- description: Turkish cheese
- countries: TR
- kinds: cheese, food

## DISH Q101245132
- name: Kwikwi
- description: Surinamese fish and Surinamese fish dish
- countries: (none)
- kinds: fish dish

## DISH Q101440969
- name: Krokan
- description: traditional Swedish dessert
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q1014883
- name: Burger Brezel
- countries: DE
- kinds: pretzel, pastry

## DISH Q101516882
- name: Tiered-box (Jubako)
- description: item GL009 in the Khalili Collection of Japanese Art
- countries: JP
- kinds: Jūbako
- ingredients: lacquer

## DISH Q101564403
- name: Pan di sorc
- other names: {"it": "Pan di sorc"}
- countries: IT
- kinds: bread

## DISH Q101564443
- name: Pan de sòrc PAT
- other names: {"zh": "Pan de sòrc PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: bread, baked good

## DISH Q1016080
- name: Burgunderbraten
- other names: {"de": "Burgunderbraten"}
- countries: (none)
- kinds: Rinderbraten

## DISH Q101611276
- name: White pizza
- description: pizza style consisting of dough, olive oil, garlic, cheese, salt and vegetables but without tomato sauce
- countries: (none)
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q101643769
- name: كوزي
- other names: {"ar": "كوزي"}
- countries: SA
- cuisines: Saudi Arabian cuisine
- kinds: rice dish, type of food or dish

## DISH Q1017266
- name: Bush bread
- other names: {"zh": "澳洲土著麵包"}
- description: seedcakes baked by Aboriginal Australians
- countries: AU
- kinds: bread, dish
- has Wikipedia article: en, zh

## DISH Q101806128
- name: Chisulì
- other names: {"it": "Chisulì"}
- countries: IT
- kinds: dessert

## DISH Q1018075
- name: Butterbrot
- other names: {"zh": "奶油吐司"}
- description: buttered bread
- countries: DE
- kinds: type of food or dish, open sandwich, bread, dish, finger food, cold dishes
- ingredients: butter, bread
- has Wikipedia article: en

## DISH Q1018117
- name: Buttermilchbrei
- other names: {"de": "Buttermilchbrei"}
- description: soup
- countries: (none)
- kinds: soup, dish
- ingredients: pearl barley, buttermilk

## DISH Q1018138
- name: Butterschnitzel
- description: dish
- countries: (none)
- kinds: dish, Faschierte Laibchen
- ingredients: Faschierte Laibchen

## DISH Q1018934
- name: Bäckerkartoffel
- other names: {"de": "Bäckerkartoffel"}
- countries: (none)
- kinds: dish

## DISH Q101894969
- name: Zeama
- other names: {"sv": "Zeama"}
- countries: (none)
- kinds: soup

## DISH Q1019164
- name: Bärenschinken
- other names: {"de": "Bärenschinken"}
- countries: (none)
- kinds: ham

## DISH Q1019273
- name: Bätscher
- countries: (none)
- kinds: viennoiserie

## DISH Q1019927
- name: Burek
- description: Bosnian stuffed phyllo pastry
- countries: (none)
- kinds: börek

## DISH Q1020809
- name: Bündner Nusstorte
- other names: {"zh": "堅果餡餅"}
- description: Swiss cake with a filling of caramellized chopped walnuts
- countries: CH
- kinds: walnut pie
- ingredients: shortcrust pastry, walnut
- has Wikipedia article: en

## DISH Q1020812
- name: Pfirsichstein
- description: confection in the shape of a peach pit
- countries: CH
- kinds: confectionery

## DISH Q102121344
- name: Rahmschnitzel
- other names: {"de": "Rahmschnitzel"}
- countries: (none)
- kinds: escalope

## DISH Q102144885
- name: Carne fumada di Siror
- other names: {"it": "Carne fumada di Siror"}
- countries: IT
- kinds: charcuterie, appetizer

## DISH Q102151318
- name: Fränkische Bratwurst
- other names: {"de": "Fränkische Bratwurst"}
- countries: (none)
- kinds: Bratwurst

## DISH Q102158091
- name: Carne fumada della Val di Cembra
- other names: {"it": "Carne fumada della Val di Cembra"}
- countries: IT
- kinds: charcuterie

## DISH Q102163551
- name: Cat tongues
- description: tongue-shaped chocolate bar
- countries: AT
- kinds: chocolate bar

## DISH Q102172477
- name: Satu
- other names: {"id": "satu"}
- countries: ID
- kinds: cookie, jajan pasar
- ingredients: Vigna radiata, sugar

## DISH Q102172629
- name: Tempe orek
- description: traditional stir-fried tempeh from Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Javanese cuisine
- kinds: type of food or dish, dish, human food, Tempeh
- ingredients: table salt, Indonesian bay leaf, shallot, ginger, kecap manis, palm sugar, monosodium L-glutamate, chili pepper, Tempeh, Allium sativum

## DISH Q102172641
- name: Lamang baluo
- countries: ID
- kinds: kue, jajan pasar
- ingredients: coconut, palm sugar, glutinous rice

## DISH Q102172688
- name: Soto lenthok
- other names: {"id": "soto lenthok"}
- countries: (none)
- kinds: soto
- ingredients: cassava root, chicken as food, rice vermicelli

## DISH Q102172718
- name: Janggelut
- countries: ID
- cuisines: Indonesian cuisine
- kinds: youtiao, snack, dish, human food, type of food or dish
- ingredients: wheat flour, sodium bicarbonate, table salt

## DISH Q102173104
- name: Gulai tahu
- other names: {"id": "gulai tahu"}
- countries: ID
- kinds: gulai
- ingredients: coconut milk, tofu

## DISH Q102173115
- name: Tahu isi
- description: Indonesian dish, tofu filled with vegetables and/or meat
- countries: ID
- kinds: tahu goreng
- ingredients: shallot, celery, garlic, mung bean sprout, wheat flour, rice flour, scallion, tofu, Brassica oleracea var. capitata, table salt, carrot

## DISH Q102173245
- name: Getuk indri
- other names: {"id": "getuk indri"}
- countries: ID
- kinds: Getuk
- ingredients: coconut, tapioca, sugar

## DISH Q102173277
- name: Dendeng lambok
- other names: {"id": "dendeng lambok"}
- countries: ID
- kinds: beef dish
- ingredients: beef, chili pepper

## DISH Q102182275
- name: Pyongyang raengmyon
- description: North Korean dish
- countries: KP
- cuisines: North Korean cuisine
- kinds: naengmyeon
- has Wikipedia article: en

## DISH Q102184643
- name: Abdugh khiyar
- description: Azerbaijani cold soup
- countries: AZ
- kinds: cold sweet soup
- ingredients: cucumber, yogurt

## DISH Q102190284
- name: Gâteau invisible
- description: French apple dessert
- countries: (none)
- kinds: apple cake
- ingredients: apple

## DISH Q102195822
- name: Shinoda-don
- countries: (none)
- kinds: donburi

## DISH Q10220
- name: Coussin de Lyon
- description: sweet specialty of Lyon, France
- countries: FR
- kinds: food, pastry
- ingredients: marzipan, chocolate
- has Wikipedia article: en

## DISH Q1022124
- name: Beef bourguignon
- other names: {"zh": "红酒炖牛肉"}
- description: French wine-based beef stew
- countries: FR
- kinds: beef dish
- ingredients: broth, beef, red wine
- has Wikipedia article: en, zh

## DISH Q102214461
- name: Pepeto
- description: Mexican soup
- countries: MX
- kinds: soup

## DISH Q102297762
- name: Aschbacher magerkäse PAT
- other names: {"zh": "Aschbacher magerkäse PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q102352782
- name: Salame all'aglio PAT
- other names: {"zh": "Salame all'aglio PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: salami, meat product

## DISH Q102404539
- name: Poppy seed bun
- description: large hot dog buns for Chicago-style hot dogs, with a poppy seed topping
- countries: US
- kinds: hot dog bun, bread
- ingredients: poppy seed, bread roll

## DISH Q102417677
- name: Ttaro-gukbap
- countries: KR
- kinds: gukbap

## DISH Q102419432
- name: Yakki-udong
- description: Korean fried noodle dish
- countries: KR
- cuisines: Korean Chinese cuisine
- kinds: fried noodle

## DISH Q102428795
- name: Rice ball
- other names: {"zh": "飯糰"}
- description: generic food item shaped into a ball made primarily of rice
- countries: (none)
- kinds: rice dish
- has Wikipedia article: en, zh

## DISH Q1025010
- name: Cachapa
- description: food
- countries: VE
- kinds: food, pancake
- ingredients: maize
- has Wikipedia article: en

## DISH Q10261324
- name: Cozido de grão
- description: Portuguese chickpea stew
- countries: PT
- kinds: stew
- ingredients: chickpea

## DISH Q10262382
- name: Cupulate
- other names: {"es": "Cupulate"}
- countries: (none)
- kinds: confectionery

## DISH Q1026245
- name: Calandraca
- other names: {"de": "Calandraca"}
- countries: (none)
- kinds: dish

## DISH Q10262550
- name: Cuxá
- description: dish of the Maranhão cuisine
- countries: (none)
- kinds: dish

## DISH Q10263684
- name: Dadinho
- other names: {"de": "Dadinho"}
- countries: (none)
- kinds: confectionery

## DISH Q1026488
- name: Caldo galego
- description: food in Galicia, Spain
- countries: ES
- cuisines: Spanish cuisine, Galician cuisine
- kinds: dish, soup
- ingredients: potato, pig fat, Lacón Gallego, Brassica oleracea var. medullosa, Phaseolus vulgaris, Brassica oleracea var. capitata, chorizo, bacon
- has Wikipedia article: en

## DISH Q10267770
- name: Doce de abóbora
- other names: {"pt": "doce de abóbora"}
- countries: (none)
- kinds: confectionery

## DISH Q10267772
- name: Doce de espécie
- description: Brazilian dessert
- countries: (none)
- kinds: confectionery
- ingredients: sesame seed, panela, cassava flour, spice

## DISH Q10267774
- name: Doce de mocotó
- other names: {"pt": "doce de mocotó"}
- countries: (none)
- kinds: confectionery

## DISH Q10267781
- name: Doces do Brasil
- countries: (none)
- kinds: confectionery

## DISH Q10267967
- name: Dom Rodrigo
- description: Portuguese dessert
- countries: PT
- kinds: dessert
- ingredients: fios de ovos, almond, egg yolk, cinnamon, sugar
- has Wikipedia article: en

## DISH Q10268547
- name: Conventual sweets
- description: Portuguese sweets
- countries: (none)
- kinds: sweetmeat
- has Wikipedia article: en

## DISH Q1026857
- name: XO sauce
- other names: {"zh": "XO酱"}
- description: spicy seafood sauce from Hong Kong
- countries: HK
- kinds: fish sauce, condiment
- ingredients: conpoy
- has Wikipedia article: en, zh

## DISH Q10268731
- name: Draniki
- countries: (none)
- kinds: potato pancake
- ingredients: potato

## DISH Q1027031
- name: Calisson
- other names: {"zh": "卡利松糖"}
- description: Traditional Candy from Aix-en-Provence
- countries: FR
- cuisines: French cuisine
- kinds: type of food or dish, confectionery
- ingredients: syrup, melon, candied fruit, almond
- has Wikipedia article: en, zh

## DISH Q10271001
- name: Efó
- description: Dish of the Bahia cuisine
- countries: BR
- cuisines: cuisine of Bahia
- kinds: dish, soup
- ingredients: garlic, shrimp, chili powder

## DISH Q10271107
- name: Ekuru
- description: meal native to the Yoruba people in Nigeria, usually prepared with peeled beans
- countries: NG
- kinds: dish, cuisine, human food, food
- ingredients: onion, palm oil, Capsicum, table salt, vegetable oil, tomato soup, bouillon cube, bean, nutmeg
- has Wikipedia article: en

## DISH Q10272475
- name: Empadão goiano
- other names: {"pt": "empadão goiano"}
- countries: BR

## DISH Q10273175
- name: Entrevero de pinhão
- countries: (none)
- kinds: dish

## DISH Q10274705
- name: Escondidinho
- description: Brazilian dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q10274873
- name: Espada com banana
- description: Portuguese dish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q1027884
- name: Calçotada
- description: festive meal featuring calçots, usually accompanied by grilled meat
- countries: ES
- kinds: dish

## DISH Q10280099
- name: Farofa de içá
- other names: {"pt": "farofa de içá"}
- countries: (none)
- kinds: dish

## DISH Q10280224
- name: Fartura
- description: Portuguese doughnut
- countries: PT
- cuisines: Portuguese cuisine
- kinds: type of food or dish, fritter
- has Wikipedia article: en

## DISH Q10280270
- name: Fatias de Tomar
- description: Portuguese dessert
- countries: PT
- kinds: dessert
- has Wikipedia article: en

## DISH Q10280348
- name: Favas com chouriço
- other names: {"es": "Favas com chouriço"}
- countries: PT
- kinds: dish
- ingredients: blood sausage, Broad Bean, chorizo

## DISH Q10280820
- name: Feijoada à transmontana
- other names: {"eu": "Feijoada à transmontana"}
- countries: PT
- kinds: pork dish
- ingredients: pork, Brassica oleracea, Phaseolus vulgaris

## DISH Q10280830
- name: Beans with palm oil
- description: dish in Angolan cuisine
- countries: (none)
- kinds: dish

## DISH Q10281090
- name: Fenek
- description: Dining in Malta
- countries: MT
- kinds: dish

## DISH Q102819468
- name: Jjanji
- countries: (none)
- kinds: radish kimchi

## DISH Q10282138
- name: Figada
- other names: {"pt": "figada"}
- countries: (none)
- kinds: confectionery

## DISH Q10282399
- name: Filé à Osvaldo Aranha
- description: traditional Brazilian dish consisting of a beefsteak that's topped with large amounts of fried garlic and served with white rice, crunchy potato chips, and farofa on the side
- countries: BR
- kinds: dish, recipe

## DISH Q10283146
- name: Fogazza
- description: kind of Italian-Brazilian pastry
- countries: BR
- kinds: food

## DISH Q10283147
- name: Fogaça da Feira
- description: Portuguese sweet bread
- countries: PT
- kinds: sweet bread
- ingredients: wheat flour, lemon juice, baker's yeast, lemon zest, egg as food, butter, cinnamon, sugar

## DISH Q10285509
- name: Frango empanado
- other names: {"pt": "frango empanado"}
- countries: (none)
- kinds: dish

## DISH Q10285510
- name: Frango na púcara
- countries: PT
- kinds: culinary speciality

## DISH Q10285512
- name: Frango à passarinho
- countries: (none)
- kinds: dish

## DISH Q10286658
- name: Furrundu
- description: Brazilian papaya confectionary
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q1028754
- name: Wine gum
- description: gelatin-based chewy candy
- countries: GB
- kinds: gummy candy
- ingredients: gelatin, citric acid, sugar, water
- has Wikipedia article: en

## DISH Q10288102
- name: Galeto
- other names: {"pt": "galeto"}
- countries: (none)
- kinds: dish

## DISH Q102887302
- name: Algunder ziegenkäse PAT
- other names: {"zh": "Algunder ziegenkäse PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: goat cheese, cheese

## DISH Q10289673
- name: Ginga com tapioca
- other names: {"fr": "Ginga com tapioca"}
- countries: (none)
- kinds: dish

## DISH Q10296519
- name: Dezhou braised chicken
- other names: {"zh": "德州扒鸡"}
- description: Chinese dish from the city of Dezhou in Shandong Province, China
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en, zh

## DISH Q1029851
- name: Gyulai kolbász
- description: sausage from Hungary
- countries: HU
- kinds: food

## DISH Q10298718
- name: Huevos haminados
- other names: {"es": "huevos haminados"}
- countries: (none)
- kinds: egg dish

## DISH Q10299545
- name: 敲鱼
- countries: CN
- kinds: dish
- has Wikipedia article: zh

## DISH Q10303205
- name: Sin den ban
- other names: {"zh": "新丁粄"}
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q10303471
- name: Ipeté
- other names: {"pt": "ipeté"}
- countries: (none)
- kinds: dish

## DISH Q10303883
- name: Iscas
- description: Portuguese liver dish
- countries: PT
- kinds: dish
- ingredients: liver as food

## DISH Q10308013
- name: Jopara
- description: Paraguayan typical dish
- countries: PY
- kinds: dish
- ingredients: Locro, Phaseolus vulgaris

## DISH Q10313790
- name: Kappamaki
- description: makizushi made with cucumbers
- countries: JP
- kinds: makizushi
- ingredients: sumeshi, cucumber, nori
- has Wikipedia article: en

## DISH Q10314235
- name: Summer soup
- description: Finnish traditional soup
- countries: FI
- cuisines: Finnish cuisine
- kinds: soup, dish, vegetable soup
- ingredients: scallion, potato, milk, Brassica oleracea var. botrytis, carrot
- has Wikipedia article: en

## DISH Q10316276
- name: Grilled Lapas
- description: Typical dish from Madeira & Azores, Portugal
- countries: PT
- kinds: dish
- ingredients: Patella vulgata
- has Wikipedia article: en

## DISH Q10317113
- name: Leitão da Bairrada
- description: Portuguese dish of suckling pig
- countries: PT
- kinds: pork dish
- ingredients: suckling pig

## DISH Q10317115
- name: Leitão maturado
- other names: {"pt": "leitão maturado"}
- countries: (none)
- kinds: dish

## DISH Q1031787
- name: Gözleme
- description: Turkish cuisine dish
- countries: TR
- kinds: food, baked good
- has Wikipedia article: en

## DISH Q1032101
- name: Zampone Modena PGI
- other names: {"zh": "Zampone Modena IGP"}
- description: Italian PGI meat product
- countries: IT
- cuisines: cuisine of the province of Modena
- kinds: meat product, sausage

## DISH Q10323517
- name: Manuê
- other names: {"mul": "Manuê"}
- description: varieties of Brazilian cakes
- countries: BR
- cuisines: Brazilian cuisine
- kinds: cake
- has Wikipedia article: en

## DISH Q10323573
- name: Mandiopã
- other names: {"pt": "Mandiopã"}
- countries: BR
- kinds: food

## DISH Q10326489
- name: Mariola
- other names: {"pt": "mariola"}
- countries: (none)
- kinds: confectionery

## DISH Q10326759
- name: Marreco com repolho roxo
- other names: {"pt": "marreco com repolho roxo"}
- countries: (none)
- kinds: dish

## DISH Q1032806
- name: Canapé
- other names: {"zh": "开胃小菜"}
- description: snack
- countries: FR
- cuisines: French cuisine
- kinds: finger food, snack, open sandwich
- has Wikipedia article: en

## DISH Q10328276
- name: Meia-desfeita
- description: Portuguese cod dish
- countries: PT
- kinds: fish dish
- ingredients: chickpea, cod
- has Wikipedia article: en

## DISH Q10331615
- name: Momas
- description: Sausages of the Murça region, Portugal
- countries: PT
- kinds: meat product, sausage
- ingredients: parsley, onion, pork

## DISH Q10332079
- name: Monteiro Lopes
- countries: (none)
- kinds: food, cookie

## DISH Q10332768
- name: Passion fruit mousse
- description: Creamy passion fruit dessert
- countries: BR
- kinds: confectionery
- ingredients: gelatin, Passiflora edulis, milk
- has Wikipedia article: en

## DISH Q10333009
- name: Mufete
- other names: {"pt": "Mufete"}
- description: Mufete is a classic Angolan grilled fish dish
- countries: (none)
- cuisines: African cuisine
- kinds: fish dish, dish
- ingredients: white wine vinegar, olive oil, Allium, fish

## DISH Q10333224
- name: Munguzá
- description: Brazilian sweet porridge
- countries: BR
- kinds: jam
- ingredients: Canjica, cinnamon, sugar, milk
- has Wikipedia article: en

## DISH Q10335260
- name: Nabada
- description: Portuguese dish
- countries: (none)
- kinds: dish

## DISH Q10335890
- name: Nazook
- description: Armenian candy
- countries: (none)
- kinds: confectionery

## DISH Q10335970
- name: Nega-maluca
- other names: {"pt": "Nega-maluca"}
- countries: (none)
- kinds: confectionery

## DISH Q10335981
- name: Nego bom
- other names: {"pt": "nego bom"}
- countries: (none)
- kinds: confectionery

## DISH Q1033856
- name: St. Honoré cake
- other names: {"zh": "聖多諾黑"}
- description: French pastry dessert
- countries: FR
- kinds: cake
- ingredients: Chiboust cream, profiterole, puff pastry
- has Wikipedia article: en, zh

## DISH Q10338866
- name: Li Liangui Smoked Meat Flatbread
- other names: {"zh": "李连贵熏肉大饼"}
- countries: (none)
- kinds: dish
- ingredients: bing
- has Wikipedia article: zh

## DISH Q103409718
- name: Niku udon
- countries: (none)
- kinds: udon, meat dish

## DISH Q10343640
- name: Paiola
- description: Sausage from Portugal
- countries: PT
- kinds: sausage
- ingredients: pork

## DISH Q10344103
- name: Piracicaba pamonha
- description: traditional corn dish from the city of Piracicaba
- countries: BR
- kinds: Pamonha, maize-based food
- ingredients: maize, cow's milk, butter, sugar

## DISH Q103441166
- name: Desert lime
- description: fruit from Citrus glauca
- countries: AU
- kinds: citrus fruit

## DISH Q10344121
- name: Pampilho
- description: Portuguese filled pastry
- countries: PT
- kinds: pastry

## DISH Q10345683
- name: Squirrel fish
- other names: {"zh": "松鼠鳜鱼"}
- description: well-known dish in Jiangsu cuisine
- countries: CN
- kinds: fish dish
- has Wikipedia article: en, zh

## DISH Q10345989
- name: פסטל דה אנגו
- other names: {"he": "פסטל דה אנגו"}
- countries: (none)
- kinds: dish

## DISH Q10345990
- name: Pastel de feijão
- description: Portuguese bean tart
- countries: PT
- kinds: tart, confectionery
- ingredients: white bean, almond
- has Wikipedia article: en

## DISH Q10346967
- name: Pavê
- description: Brazilian layered cake
- countries: (none)
- kinds: dessert, layer cake
- ingredients: condensed milk, egg as food, cream, Savoiarde PAT, chocolate
- has Wikipedia article: en

## DISH Q10347939
- name: Peixada catarinense
- other names: {"pt": "peixada catarinense"}
- countries: (none)
- kinds: dish

## DISH Q1034869
- name: Cappelletti
- description: type of pasta
- countries: IT
- kinds: type of pasta, stuffed pasta
- has Wikipedia article: en

## DISH Q10348868
- name: Pescada à poveira
- other names: {"pt": "Pescada à poveira"}
- countries: (none)
- kinds: fish dish

## DISH Q10350144
- name: Pixé
- other names: {"pt": "pixé"}
- countries: (none)
- kinds: confectionery

## DISH Q10350703
- name: Podrão
- other names: {"pt": "podrão"}
- countries: (none)
- kinds: sandwich

## DISH Q10350921
- name: Polvo à lagareiro
- description: Portuguese octopus dish
- countries: PT
- cuisines: Portuguese cuisine
- kinds: potato dish, octopus dish
- ingredients: garlic, octopus as food, potato, onion, olive, olive oil, Coriandrum sativum
- has Wikipedia article: en

## DISH Q1035290
- name: Carac
- description: Swiss chocolate tartlet
- countries: CH
- cuisines: Swiss cuisine
- kinds: chocolate tart, tartlet
- ingredients: pâte sablée, fondant, ganache
- has Wikipedia article: en

## DISH Q10353556
- name: Prego
- description: Portuguese sandwich
- countries: PT
- cuisines: Portuguese cuisine
- kinds: sandwich
- ingredients: garlic, onion, beef, bread roll, wine
- has Wikipedia article: en

## DISH Q10353695
- name: Barrancos ham
- description: cured ham
- countries: (none)
- kinds: ham
- has Wikipedia article: en

## DISH Q10355424
- name: Pudim abade de priscos
- description: Portuguese caramel pudding
- countries: PT
- cuisines: Portuguese cuisine
- kinds: pudding
- ingredients: presunto, Port Wine, egg as food, sugar
- has Wikipedia article: en

## DISH Q10356075
- name: Queijada
- description: Portuguese sweet
- countries: PT
- kinds: confectionery
- ingredients: cheese
- has Wikipedia article: en

## DISH Q10356233
- name: Quiabada
- other names: {"pt": "quiabada"}
- countries: (none)
- kinds: dish

## DISH Q10356484
- name: Quirera com suã
- other names: {"pt": "quirera com suã"}
- countries: (none)
- kinds: dish

## DISH Q10364123
- name: Rojões
- description: Portuguese pork stew
- countries: PT
- kinds: stew, pork dish

## DISH Q10364125
- name: Rojões à moda do Minho
- description: Portuguese pork stew
- countries: (none)
- kinds: rojões, pork dish
- has Wikipedia article: en

## DISH Q10364735
- name: Roupa velha
- other names: {"pt": "Roupa velha"}
- countries: (none)
- kinds: fish dish

## DISH Q10365057
- name: Rubacão
- other names: {"pt": "rubacão"}
- countries: (none)
- kinds: dish

## DISH Q10367013
- name: Salmão com sidra
- other names: {"pt": "Salmão com sidra"}
- countries: (none)
- kinds: fish dish

## DISH Q10368446
- name: Grilled sardines
- countries: PT
- kinds: fish dish

## DISH Q10369989
- name: Khoresht mast
- description: Iranian side dish
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q10372000
- name: Sericaia
- description: Portuguese milk custard
- countries: PT
- cuisines: Portuguese cuisine
- kinds: food, dessert
- ingredients: lemon, egg as food, flour, cinnamon, milk
- has Wikipedia article: en

## DISH Q10373410
- name: Sopa de bacalhau dos campinos
- other names: {"pt": "Sopa de bacalhau dos campinos"}
- countries: (none)
- kinds: fish dish

## DISH Q10373413
- name: Sopa de cação
- description: Portuguese shark soup
- countries: PT
- kinds: soup
- ingredients: garlic, coriander seed, Squalidae

## DISH Q10373415
- name: Sopa de lacassá
- other names: {"zh": "鮮蝦濃湯"}
- description: Macanese soup
- countries: (none)
- kinds: soup
- has Wikipedia article: en, zh

## DISH Q10373448
- name: Sorda
- other names: {"pt": "sorda"}
- countries: (none)
- kinds: cookie

## DISH Q10374398
- name: Stuffat tal-qarnit
- description: Maltese octopus stew
- countries: MT
- kinds: stew
- ingredients: octopus as food

## DISH Q10377857
- name: Tainha na taquara
- other names: {"pt": "tainha na taquara"}
- countries: (none)
- kinds: dish

## DISH Q1037853
- name: Galbi-tang
- other names: {"zh": "韓式排骨湯"}
- description: Korean soup
- countries: (none)
- kinds: food, soup, guk
- ingredients: short ribs
- has Wikipedia article: en

## DISH Q1037909
- name: Gukbap
- other names: {"zh": "汤饭"}
- description: Korean rice soup category
- countries: (none)
- kinds: soup, rice dish
- ingredients: bap, guk
- has Wikipedia article: en

## DISH Q10379618
- name: Kasha
- other names: {"zh": "卡莎"}
- description: type of porridge
- countries: RU, PL, UA, BY, SI, LT
- cuisines: Russian cuisine, Polish cuisine, Ukrainian cuisine, Belarusian cuisine, Slovenian cuisine, Lithuanian cuisine
- kinds: food, dish
- has Wikipedia article: en, zh

## DISH Q10379641
- name: 沙拉船
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q10382382
- name: Tiborna (bacalhau)
- other names: {"pt": "Tiborna (bacalhau)"}
- countries: (none)
- kinds: fish dish

## DISH Q10382383
- name: Tiborna
- description: Portuguese and Spanish name for a bread toast with olice oil
- countries: (none)
- kinds: bread dish

## DISH Q10384855
- name: Tripas à moda do Porto
- description: traditional Portuguese dish
- countries: PT
- kinds: meat dish
- ingredients: tripe, bean, rice, carrot
- has Wikipedia article: en

## DISH Q1038537
- name: Butter cookie
- other names: {"zh": "黄油曲奇"}
- description: cookie originating in Denmark
- countries: DK
- kinds: cookie, biscuit
- ingredients: wheat flour, butter, sugar
- has Wikipedia article: en, zh

## DISH Q10388615
- name: Vaca atolada
- description: Brazilian beef dish
- countries: BR
- kinds: beef dish
- ingredients: beef, cassava
- has Wikipedia article: en

## DISH Q10391691
- name: Virado
- description: Brazilian dish
- countries: BR
- kinds: dish
- has Wikipedia article: en

## DISH Q10392333
- name: 清蒸鲥鱼
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q10394334
- name: Xerém
- description: traditional Portuguese dish with corn flour
- countries: PT
- kinds: dish
- ingredients: maize flour
- has Wikipedia article: en

## DISH Q10394373
- name: Ximango
- other names: {"pt": "ximango"}
- countries: (none)
- kinds: cake

## DISH Q10394386
- name: Xipa
- description: Biscuit based on cheese and sprinkles in Brazil
- countries: PY
- kinds: cookie, pastry
- ingredients: cheese

## DISH Q10395380
- name: Zuppa pavese
- description: Italian national dish, a kind of cheese soup
- countries: IT
- cuisines: Italian cuisine
- kinds: food, soup
- has Wikipedia article: en

## DISH Q10396701
- name: 滑炒
- description: dish
- countries: CN
- kinds: dish, food preparation technique
- has Wikipedia article: zh

## DISH Q10400401
- name: Stir-fried milk
- other names: {"zh": "炒牛奶"}
- description: dish from Shunde, Guangdong
- countries: CN
- kinds: dish
- has Wikipedia article: zh

## DISH Q10400494
- name: 炝虎尾
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q10403418
- name: 煨脐门
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q10403913
- name: Acacia honey
- description: Acacia honey stems from the nectar of the black locust tree and is said to offer various health benefits.
- countries: (none)
- kinds: monofloral honey

## DISH Q10404309
- name: Albert
- description: Swedish biscuit brand
- countries: (none)
- kinds: biscuit

## DISH Q10404947
- name: Bao du
- other names: {"zh": "爆肚"}
- description: Chinese halal tripe dish
- countries: CN
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q10405003
- name: Alexandertårta
- other names: {"sv": "Alexandertårta"}
- countries: (none)
- kinds: cake

## DISH Q104052947
- name: Kerutup ikan
- other names: {"id": "Kerutup ikan"}
- countries: (none)
- kinds: fish as food, dish, type of food or dish

## DISH Q10405688
- name: Pianerchuan
- other names: {"zh": "片儿川"}
- description: noodle dish from Hangzhou, China
- countries: CN
- cuisines: Chinese cuisine
- kinds: noodle soup
- has Wikipedia article: zh

## DISH Q104066676
- name: Liver stew
- countries: SE
- cuisines: Swedish cuisine
- kinds: dish
- ingredients: onion, liver as food, lingonberry jam

## DISH Q104092263
- name: Buddha's hand
- description: fruit of Citrus medica var. sarcodactylis
- countries: CN, IN
- kinds: citrus fruit

## DISH Q104093090
- name: Tajadin
- other names: {"lmo": "Tajadin"}
- countries: (none)
- kinds: egg pasta
- ingredients: common wheat flour, egg as food

## DISH Q104094239
- name: Pigs in blankets
- description: sausage and bacon dish of the United Kingdom
- countries: (none)
- kinds: sausage rolls, bacon-wrapped food
- ingredients: sausage, bacon
- has Wikipedia article: en

## DISH Q104119677
- name: 鸡豆花
- countries: CN
- kinds: soup, chicken dish
- has Wikipedia article: zh

## DISH Q1041222
- name: Gejang
- other names: {"zh": "酱油蟹"}
- description: Korean dish of fermented crabs
- countries: (none)
- kinds: crab dish
- has Wikipedia article: en, zh

## DISH Q104125992
- name: Carottes râpées
- description: French carrot salad
- countries: (none)
- kinds: salad

## DISH Q104126307
- name: Romerska bågar
- description: Swedish chocolate candy
- countries: (none)
- kinds: praline

## DISH Q104126397
- name: Pawpaw
- description: fruit from Asimina triloba
- countries: CA, US
- kinds: fruit

## DISH Q104150541
- name: Chicken stock powder
- other names: {"zh": "鸡精"}
- description: chicken-flavored condiment
- countries: (none)
- kinds: granular material, powder, instant stock
- has Wikipedia article: zh

## DISH Q104150562
- name: Mudhi Mansa
- description: Odia food
- countries: IN
- kinds: food

## DISH Q104153096
- name: Geschmink
- other names: {"de": "Geschmink"}
- countries: (none)
- kinds: dish

## DISH Q104157105
- name: Cosi di ficu PAT
- other names: {"zh": "Cosi di ficu PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, dessert, baked good

## DISH Q104162035
- name: Lapin chasseur
- countries: (none)
- kinds: rabbit dish

## DISH Q104177921
- name: Tacos de lengua
- description: dish
- countries: MX
- kinds: taco, dish
- ingredients: tortilla, beef tongue

## DISH Q104187885
- name: Rapeseed honey
- description: honey made by bees foraging on rapeseed
- countries: (none)
- kinds: honey

## DISH Q10421134
- name: 琵琶鴨
- countries: (none)
- kinds: roast duck
- has Wikipedia article: zh

## DISH Q104244533
- name: Persian sturgeon roe
- description: caviar from Acipenser persicus
- countries: (none)
- kinds: caviar

## DISH Q104250487
- name: Meyer lemon
- description: fruit from Citrus ×meyeri
- countries: CN
- kinds: citrus fruit

## DISH Q104250633
- name: Hamhung naengmyeon
- other names: {"zh": "咸兴冷面"}
- description: Cold noodle of Hamheung city
- countries: KP
- cuisines: North Korean cuisine
- kinds: naengmyeon

## DISH Q104251400
- name: Bean vermicelli
- other names: {"zh": "绿豆粉丝"}
- countries: (none)
- kinds: cellophane noodles

## DISH Q104252174
- name: Dangmyeon
- other names: {"zh": "红薯粉丝"}
- description: sweet potato starch noodles
- countries: (none)
- kinds: cellophane noodles

## DISH Q104252380
- name: Huo guo dun fen
- other names: {"zh": "火锅炖粉"}
- countries: CN
- kinds: cellophane noodles

## DISH Q10425800
- name: Banana skids
- other names: {"sv": "Banana skids"}
- countries: (none)
- kinds: candy

## DISH Q10429442
- name: Beef Rydberg
- description: Swedish beef dish
- countries: SE
- kinds: beef dish, meat dish
- ingredients: raw egg, fried potatoes, fried onion, beef

## DISH Q10429947
- name: Birkabulle
- other names: {"sv": "Birkabulle"}
- countries: (none)
- kinds: pastry

## DISH Q10431700
- name: Bilberry porridge
- countries: (none)
- kinds: porridge
- ingredients: bilberry

## DISH Q10433119
- name: Sawachiryōri
- other names: {"zh": "皿缽料理"}
- countries: JP
- kinds: food
- ingredients: sashimi
- has Wikipedia article: zh

## DISH Q10436964
- name: Brännesnuda
- other names: {"da": "brännesnuda"}
- countries: (none)
- kinds: dish

## DISH Q10437104
- name: Bröllopskonfekt
- other names: {"sv": "Bröllopskonfekt"}
- countries: (none)
- kinds: confectionery

## DISH Q10437228
- name: Budapestbakelse
- description: pastry
- countries: SE
- kinds: pastry
- has Wikipedia article: en

## DISH Q10438086
- name: Butterkaka
- description: Pastry composed of rolled buns
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q104381638
- name: Indian pizza
- countries: US

## DISH Q104383034
- name: Potato ropsu
- description: pancake of mashed potatoes
- countries: FI
- kinds: pancake
- ingredients: rye flour, golden syrup, wheat flour, mashed potato, cinnamon

## DISH Q10438666
- name: Böcklinglåda
- other names: {"sv": "böcklinglåda"}
- countries: (none)
- kinds: dish

## DISH Q10440715
- name: Calulu
- description: dish from Lusophone Africa with fish, chicken, palm oil and vegetables.
- countries: (none)
- kinds: food, dish, stew
- ingredients: fish as food, palm oil
- has Wikipedia article: en

## DISH Q1044101
- name: Carnixulla
- countries: (none)
- kinds: dish

## DISH Q104412527
- name: Mochar Paturi
- description: Indian food
- countries: (none)
- kinds: paturi

## DISH Q104413149
- name: Crab leg
- description: leg of any type of crab as a food ingredient
- countries: (none)
- kinds: dish, butchering, food ingredient

## DISH Q10442304
- name: Savory rice pudding
- other names: {"zh": "碗粿"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish
- has Wikipedia article: zh

## DISH Q1044246
- name: Furikake
- other names: {"zh": "拌飯素"}
- description: Japanese seasoning
- countries: JP
- kinds: seasoning, processed food, food
- ingredients: Sesamum indicum
- has Wikipedia article: en, zh

## DISH Q104424962
- name: Broodje Mario
- countries: (none)
- kinds: submarine sandwich

## DISH Q104504307
- name: Arròs del Senyoret
- countries: (none)
- kinds: rice dish, dish

## DISH Q104513412
- name: Visočka pečenica
- description: permanent charcuterie
- countries: BA
- kinds: dried meat
- has Wikipedia article: en

## DISH Q1045248
- name: Tendon
- other names: {"zh": "炸蝦蓋飯"}
- description: Japanese dish consisting of tempura on a bowl of rice
- countries: JP
- kinds: donburi
- ingredients: tempura, rice
- has Wikipedia article: en

## DISH Q104536222
- name: Weinbrandbohne
- other names: {"de": "Weinbrandbohne"}
- countries: (none)
- kinds: praline

## DISH Q104536560
- name: Pampepato di Ferrara PGI
- other names: {"zh": "Pampepato di Ferrara IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good, confectionery
- ingredients: chocolate

## DISH Q104547781
- name: Kroakemandel
- other names: {"nl": "kroakemandel"}
- countries: BE
- kinds: snack
- ingredients: pea

## DISH Q10455395
- name: Octopus-shaped sausages
- other names: {"zh": "章魚香腸"}
- description: Japanese snack
- countries: JP
- kinds: sausage, dish
- ingredients: sausage
- has Wikipedia article: zh

## DISH Q1046006
- name: Curry bread
- other names: {"zh": "咖哩麵包"}
- description: Japanese dish, consisting of Japanese curry, wrapped in a piece of dough, coated in bread crumbs, and deep fried
- countries: JP
- cuisines: Japanese cuisine
- kinds: bread, dish
- ingredients: Japanese curry, dough
- has Wikipedia article: en, zh

## DISH Q104604704
- name: Gulai rebung
- other names: {"id": "gulai rebung"}
- countries: ID
- kinds: gulai
- ingredients: bamboo shoots, coconut milk

## DISH Q104606037
- name: Laksa Betawi
- other names: {"id": "laksa Betawi"}
- countries: ID
- kinds: laksa
- ingredients: ketupat, coconut milk, dried shrimp

## DISH Q10461269
- name: Cremekex
- other names: {"sv": "Cremekex"}
- countries: (none)
- kinds: biscuit

## DISH Q104622206
- name: Гарбузок
- other names: {"ru": "гарбузок"}
- countries: BY
- cuisines: Belarusian cuisine
- kinds: soup

## DISH Q104622587
- name: Bika
- description: snacks from West Sumatra
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, dish, street food, human food, traditional food, type of food or dish
- ingredients: coconut, rice flour, coconut milk, sugar

## DISH Q104629646
- name: Fried Cassava Cake Crackers
- description: crackers filling with fermented cassava
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, dish, street food, human food, type of food or dish
- ingredients: Tapai, cracker, flour, milk, water

## DISH Q104629864
- name: Gulai tauco
- description: Indonesia cuisine
- countries: ID
- kinds: soup, dish
- ingredients: Tauco, green bean, coconut milk, tofu, chili pepper, Tempeh

## DISH Q104629902
- name: Karabu Baluik
- description: Indonesian cuisine
- countries: (none)
- kinds: fish curry, traditional food
- ingredients: eel as food, coconut milk, Allium ascalonicum, chili pepper, Allium sativum

## DISH Q104630996
- name: Peking-American fried chicken
- other names: {"zh": "老北京美式炸鸡"}
- description: fried chicken variant
- countries: CN
- kinds: fried chicken
- has Wikipedia article: zh

## DISH Q104631141
- name: Meihohamkatsu Curry
- countries: (none)
- kinds: Japanese curry rice

## DISH Q104634768
- name: Patso
- description: Turkish dog and fries sandwich
- countries: (none)
- kinds: sandwich, food

## DISH Q10463623
- name: 糖蔥
- countries: CN
- kinds: dish
- ingredients: sugar, water
