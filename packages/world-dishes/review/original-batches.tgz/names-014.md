# Review batch names-014

## DISH Q117467386
- name: Table syrup
- description: artificial syrup used as a topping on pancakes and waffles
- countries: US
- kinds: syrup, condiment, viscous liquid
- ingredients: high fructose corn syrup, corn syrup
- has Wikipedia article: en

## DISH Q117469478
- name: עוגיות יין
- other names: {"he": "עוגיות יין"}
- countries: (none)
- kinds: cookie, food, Jewish cuisine

## DISH Q117475843
- name: Quiaude
- description: Québécois fish soup
- countries: CA
- kinds: fish soup
- has Wikipedia article: en

## DISH Q117481518
- name: Fig-cake
- description: fig-based sweet
- countries: (none)
- kinds: food, confectionery, candy
- ingredients: fig
- has Wikipedia article: en

## DISH Q11751063
- name: Kumpiak
- description: raw, salted, dried ham
- countries: (none)
- kinds: food ingredient, ham

## DISH Q11753791
- name: Legumina
- description: various sweat dishes of Polish and Galician cuisine
- countries: PL
- kinds: dessert

## DISH Q117617502
- name: Aceite de Madrid
- description: Protected designation of origin
- countries: ES
- kinds: organization, olive oil, food, Protected designation of origin
- ingredients: olive

## DISH Q117662295
- name: Dolceriso del Moro
- countries: IT
- kinds: dessert

## DISH Q117662368
- name: Chocolate Easter egg
- countries: (none)
- kinds: easter egg, Easter food, chocolate egg

## DISH Q117708472
- name: Zelňák
- other names: {"cs": "Zelňák"}
- countries: (none)
- kinds: pastry
- ingredients: sauerkraut, lard, flour, table salt

## DISH Q117708479
- name: Štědrák
- other names: {"cs": "Štědrák"}
- countries: (none)
- kinds: kolach

## DISH Q1177538
- name: Minyon
- description: Hungarian cake
- countries: HU
- kinds: torte

## DISH Q117756407
- name: نورية (حلوى)
- other names: {"ar": "نورية (حلوى)"}
- countries: TR
- kinds: dessert

## DISH Q117767141
- name: Hjortetakk
- other names: {"nb": "hjortetakk"}
- countries: NO
- kinds: doughnut
- ingredients: ammonium hydrogen carbonate, flour, butter, Elettaria cardamomum, egg, cream, sugar

## DISH Q117803607
- name: Darnitsa bread
- description: type of rye-wheat bread
- countries: RU, SU, UA
- kinds: bread, dish
- ingredients: dough

## DISH Q117813607
- name: Cocaine Throat Pastilles
- description: pastilles that contained cocaine and tyrothricin
- countries: (none)
- kinds: pastille, Coca product

## DISH Q117813626
- name: Allenbury's Throat Pastilles
- countries: (none)
- kinds: pastille

## DISH Q117813664
- name: Coca-Bola
- description: type of chewing gum
- countries: (none)
- kinds: chewing gum, Coca product

## DISH Q117815182
- name: Slagroomtaart
- description: Dutch whipped cream and sponge cake
- countries: BE
- kinds: cake
- ingredients: sponge cake, whipped cream

## DISH Q117815327
- name: Apple crumble pie
- description: apple pie with a crumble top layer
- countries: (none)
- kinds: apple pie, crumble

## DISH Q117832690
- name: Beef Stroganoff
- countries: RU
- cuisines: Russian cuisine
- kinds: dish

## DISH Q117838275
- name: Buzynnyk
- description: Elderberry dessert
- countries: (none)
- kinds: dessert, Ukrainian cuisine
- ingredients: flour, Sambucus nigra, sugar

## DISH Q1178472
- name: Dawamesc
- description: type of cannabis edible in Algeria
- countries: (none)
- kinds: viennoiserie
- has Wikipedia article: en

## DISH Q117847811
- name: Cuccalar
- description: unleavened bread from Trentino, Italy
- countries: IT
- kinds: unleavened bread
- ingredients: rye flour, wheat flour, buttermilk, lard, table salt
- has Wikipedia article: en

## DISH Q11785734
- name: Moskole
- other names: {"pl": "Moskole"}
- countries: (none)
- kinds: potato dish

## DISH Q117861283
- name: Poké bowl
- description: originally Hawaiian fish dish served in a bowl
- countries: (none)
- kinds: poke
- ingredients: poke, bowl

## DISH Q117862884
- name: Khô nhái
- other names: {"vi": "Khô nhái"}
- countries: VN
- kinds: dish, dried meat
- ingredients: meat

## DISH Q117864981
- name: Misto-quente
- countries: PT
- kinds: ham and cheese sandwich

## DISH Q11794717
- name: Objabilmerguez
- other names: {"pl": "Objabilmerguez"}
- countries: (none)
- kinds: potato dish

## DISH Q11795305
- name: Адпустовыя абваранкі
- other names: {"be-tarask": "адпустовыя абваранкі"}
- countries: PL
- kinds: cookie
- ingredients: dough

## DISH Q117971950
- name: Peanut butter and pickle sandwich
- description: type of American sandwich
- countries: US
- kinds: sandwich
- ingredients: pickled cucumber, peanut butter, bread
- has Wikipedia article: en

## DISH Q11799388
- name: Orzechówka (napój alkoholowy)
- other names: {"pl": "Orzechówka (napój alkoholowy)"}
- countries: (none)
- kinds: dish

## DISH Q117997943
- name: Kasutera kamaboko
- countries: JP
- cuisines: Japanese cuisine
- kinds: type of food or dish, castella, kamaboko
- ingredients: fish as food, egg as food

## DISH Q11801186
- name: Ouarka
- description: Moroccan dish
- countries: MA
- kinds: dish

## DISH Q11802321
- name: Palcówka (kiełbasa)
- other names: {"pl": "Palcówka (kiełbasa)"}
- countries: (none)
- kinds: dish

## DISH Q11802933
- name: Paprykarz szczeciński
- description: Polish canned fish spread made from ground fish, rice, tomato paste and vegetable oil, seasoned with onion, salt and spices
- countries: (none)
- kinds: fish dish
- ingredients: fish
- has Wikipedia article: en

## DISH Q118082425
- name: Ijslam
- other names: {"nl": "ijslam"}
- countries: (none)
- kinds: ice cream

## DISH Q118115016
- name: বিলপাড়ার চমচম
- other names: {"bn": "বিলপাড়ার চমচম"}
- countries: (none)
- kinds: confectionery

## DISH Q118129319
- name: いも作くん
- other names: {"ja": "いも作くん"}
- countries: JP
- cuisines: Japanese cuisine
- kinds: type of food or dish, confectionery
- ingredients: cookie, chocolate

## DISH Q118139279
- name: Chicken feet
- other names: {"zh": "凤爪"}
- description: dim sum dish
- countries: (none)
- kinds: chicken foot as food, dim sum
- ingredients: chicken foot

## DISH Q11814703
- name: Pazibroda
- other names: {"pl": "Pazibroda"}
- countries: (none)
- kinds: potato dish

## DISH Q11816603
- name: Herbal pepper
- description: Polish spice mix
- countries: PL
- kinds: spice mix
- ingredients: marjoram, coriander seed, mustard seed, Sinapis alba, Carum carvi

## DISH Q11816618
- name: Pierogi leniwe
- description: Polish dumplings
- countries: PL
- kinds: dish, kluski
- has Wikipedia article: en

## DISH Q11816977
- name: Pigwówka
- other names: {"pl": "Pigwówka"}
- countries: (none)
- kinds: dish

## DISH Q118174174
- name: Romanitos
- other names: {"es": "Romanitos"}
- description: pasta food style
- countries: (none)
- kinds: stuffed pasta
- ingredients: potato, chicken egg, wheat flour, ham, mozzarella

## DISH Q118186220
- name: Danish varme hveder
- description: Danish wheat bun dish
- countries: (none)
- kinds: bread

## DISH Q118186787
- name: Okazi soup
- description: Nigerian dish prepared by Igbo people
- countries: NG
- kinds: soup, human food, vegetable

## DISH Q118189128
- name: Reviro
- other names: {"pt": "reviro"}
- countries: AR, BR, PY
- kinds: dish
- ingredients: flour, table salt, water

## DISH Q118189462
- name: Cuca
- description: Gingerbread cookie
- countries: CO
- kinds: type of food or dish, food, cookie
- ingredients: panela, wheat flour, Cinnamomum verum, egg as food, butter, clove

## DISH Q118189476
- name: Caranguejo ao molho de coco
- other names: {"pt": "caranguejo ao molho de coco"}
- countries: (none)
- kinds: dish
- ingredients: coconut milk, Brachyura

## DISH Q11819250
- name: Placek zbójnicki
- other names: {"pl": "placek zbójnicki"}
- countries: (none)
- kinds: potato dish

## DISH Q118198446
- name: Lumache alla casumarese
- other names: {"it": "Lumache alla casumarese"}
- countries: IT
- kinds: dish, main course

## DISH Q11820413
- name: Podkłótka
- other names: {"pl": "Podkłótka"}
- countries: (none)
- kinds: potato dish

## DISH Q118210896
- name: Moeche
- countries: IT
- kinds: dish
- ingredients: crab, egg as food, oil, flour, table salt, water

## DISH Q118234713
- name: Pane dell'Assedio
- description: Italian dessert
- countries: IT
- cuisines: Upper Mantua cuisine
- kinds: dessert
- ingredients: dried fig, farina, Saccharomyces cerevisiae, egg as food, butter, raisin, sugar, honey, water

## DISH Q11826942
- name: Prażonki
- description: Cuisine in Poland
- countries: PL
- kinds: potato dish, dish
- has Wikipedia article: en

## DISH Q11826943
- name: Prażucha ziemniaczana
- other names: {"pl": "Prażucha ziemniaczana"}
- countries: (none)
- kinds: potato dish

## DISH Q11826944
- name: Prażucha
- description: old Polish dish
- countries: PL
- kinds: knödel, dish
- ingredients: Crackling, buckwheat flour, wheat flour

## DISH Q118288330
- name: Chicken breast steak with peach
- description: typical 1990s dish in Slovakia
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q118288558
- name: Kropsu
- countries: FI
- kinds: pancake

## DISH Q118290778
- name: Beef patty
- description: serving of ground beef formed into a disc
- countries: (none)
- kinds: patty, type of food or dish
- ingredients: ground beef
- has Wikipedia article: en

## DISH Q118293921
- name: Shawarma
- countries: (none)
- kinds: food

## DISH Q118302751
- name: Hōraku-yaki
- countries: JP
- cuisines: Japanese cuisine
- kinds: type of food or dish, mushimono, yakimono
- ingredients: vegetable, fish

## DISH Q118304282
- name: Kluski żelazne
- other names: {"pl": "Kluski żelazne"}
- countries: PL
- kinds: dish, kluski

## DISH Q11832180
- name: Pyrka
- other names: {"pl": "Pyrka"}
- countries: (none)
- kinds: potato dish

## DISH Q11832183
- name: Pyry z gzikiem
- description: Polish potato and cheese dish
- countries: PL
- kinds: potato dish
- ingredients: potato, gzik

## DISH Q118323643
- name: レーンヌ・エリザベス
- other names: {"ja": "レーンヌ・エリザベス"}
- countries: JP
- cuisines: Japanese cuisine
- kinds: type of food or dish, fish dish
- ingredients: Mornay sauce, shrimp, fish

## DISH Q118331971
- name: Pasteli
- description: sesame and honey dessert
- countries: (none)
- kinds: sesame seed candy
- has Wikipedia article: en

## DISH Q118352184
- name: Frugtgrød
- countries: (none)
- kinds: fruit dish, food

## DISH Q11835420
- name: Rura
- description: a Polish confection, part of Greater Poland cuisine
- countries: (none)
- cuisines: cuisine of Greater Poland
- kinds: confectionery
- ingredients: pryanik, shortcrust pastry, honey

## DISH Q11837128
- name: Trenne
- description: type of pasta
- countries: IT
- kinds: pasta

## DISH Q118384286
- name: Chemin de fer
- other names: {"fr": "chemin de fer"}
- countries: FR
- cuisines: Réunionese cuisine
- kinds: Swiss roll

## DISH Q11838743
- name: Pirozhki
- other names: {"zh": "皮羅什基"}
- description: fried/baked filled bun common in Russian cuisine
- countries: RU, AM
- cuisines: Russian cuisine, Armenian cuisine
- kinds: food, dish, baked good
- ingredients: yeast dough, dough
- has Wikipedia article: en, zh

## DISH Q118390379
- name: 大王当て
- other names: {"ja": "大王当て"}
- countries: (none)
- kinds: nerikiri

## DISH Q11839576
- name: Bun nem
- description: specialty dish of Hanoi
- countries: (none)
- kinds: dish

## DISH Q118463799
- name: Cigánska pečienka
- description: typical Slovak fast food
- countries: SK
- kinds: food, fast food
- ingredients: onion, mustard, meat, pig

## DISH Q118470980
- name: Nabeyaki egg noodles
- other names: {"zh": "鍋燒意麵"}
- description: noodle soup in Taiwan
- countries: TW
- kinds: noodle soup
- ingredients: ì-mī
- has Wikipedia article: zh

## DISH Q118470982
- name: Ì-mī
- other names: {"zh": "台灣意麵"}
- countries: TW
- kinds: noodle, egg noodle
- has Wikipedia article: zh

## DISH Q118496624
- name: Umxhanxa
- description: Zimbabwean dish
- countries: ZW
- kinds: dish

## DISH Q11851150
- name: Amerikkalaiset pastillit
- other names: {"fi": "Amerikkalaiset pastillit"}
- countries: (none)
- kinds: candy

## DISH Q11853198
- name: Dishwasher salmon
- description: American fish dish
- countries: US
- kinds: dish
- ingredients: salmon
- has Wikipedia article: en

## DISH Q1185324
- name: Sanuki udon
- other names: {"zh": "赞岐乌冬面"}
- description: type of noodle
- countries: JP
- kinds: Japanese noodles, food
- ingredients: udon
- has Wikipedia article: en, zh

## DISH Q118556073
- name: Ambila
- description: Indian cooked food
- countries: IN
- kinds: human food

## DISH Q11855692
- name: Da-Capo
- description: Finnish chocolate bar
- countries: (none)
- kinds: chocolate bar
- has Wikipedia article: en

## DISH Q11855727
- name: Dallaspulla
- other names: {"fi": "Dallaspulla"}
- countries: (none)
- kinds: pastry

## DISH Q1185709
- name: Kushikatsu
- other names: {"zh": "炸串"}
- description: Japanese food
- countries: JP
- cuisines: Japanese cuisine
- kinds: kushiyaki, katsuretsu
- has Wikipedia article: en, zh

## DISH Q118574754
- name: Pundut nasi
- description: Banjarese rice dish
- countries: ID
- kinds: snack, dish
- ingredients: coconut milk, glutinous rice, grated coconut, banana leaf, palm sugar
- has Wikipedia article: en

## DISH Q118574815
- name: Victoria sponge
- countries: (none)
- kinds: sponge cake

## DISH Q11857503
- name: Ellen Svinhufvud cake
- description: Finnish cake
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q11859002
- name: Eucalyptus (makeinen)
- other names: {"fi": "Eucalyptus (makeinen)"}
- countries: (none)
- kinds: candy

## DISH Q11859360
- name: Fami
- other names: {"fi": "Fami"}
- countries: (none)
- kinds: chocolate bar

## DISH Q11859368
- name: Fanipala
- other names: {"fi": "Fanipala"}
- countries: (none)
- kinds: biscuit

## DISH Q11859426
- name: Fazerin lakritsi
- other names: {"fi": "Fazerin lakritsi"}
- countries: (none)
- kinds: candy

## DISH Q11859428
- name: Fazerina
- other names: {"fi": "Fazerina"}
- countries: (none)
- kinds: chocolate bar

## DISH Q118601096
- name: Magushapu peenleib
- other names: {"et": "magushapu peenleib"}
- description: type of rye bread
- countries: (none)
- kinds: rye bread

## DISH Q118601273
- name: Sour porridge
- description: Latvian dish
- countries: LV
- kinds: porridge, putra
- ingredients: barley, soured milk

## DISH Q118603440
- name: Fidés de Saboya
- other names: {"es": "Fidés de Saboya"}
- countries: (none)
- kinds: pasta

## DISH Q118610443
- name: MARRON CORON
- countries: (none)
- kinds: confectionery, type of food or dish
- ingredients: chicken egg, wheat flour, almond, Theobroma cacao, butter, cheese, chocolate

## DISH Q118610533
- name: トラピストクッキー
- other names: {"ja": "トラピストクッキー"}
- countries: (none)
- kinds: confectionery, type of food or dish

## DISH Q11861490
- name: Hapanlohko
- description: karelian dish
- countries: FI
- cuisines: Karelian cuisine
- kinds: dish
- ingredients: salt potatoes, sourdough, butter
- has Wikipedia article: en

## DISH Q11863553
- name: Hollolan näkkileipä
- other names: {"fi": "Hollolan näkkileipä"}
- countries: (none)
- kinds: bread

## DISH Q11863672
- name: Hotsi
- description: Finnish food
- countries: FI
- kinds: dish
- ingredients: onion, cucumber salad, meat

## DISH Q11866453
- name: Jim
- other names: {"fi": "Jim"}
- countries: (none)
- kinds: chocolate bar

## DISH Q11866932
- name: Jopa
- description: Lemonade with banana flavor
- countries: FI
- kinds: lemonade

## DISH Q11867533
- name: Juhannusjuusto
- description: Finnish cheese dish
- countries: FI
- kinds: dish
- has Wikipedia article: en

## DISH Q118677993
- name: Olio di Calabria PGI
- other names: {"zh": "Olio di Calabria IGP"}
- description: Italian PGI olive oil
- countries: IT
- kinds: olive oil, extra virgin olive oil

## DISH Q11870306
- name: Valašská kyselica
- other names: {"cs": "Valašská kyselica"}
- countries: (none)
- kinds: soup

## DISH Q11870615
- name: Valašský frgál
- description: Czech cake
- countries: CZ
- kinds: cake

## DISH Q11872145
- name: Kokkelipiimä
- description: Eastern Finnish lumpy soured milk
- countries: FI
- kinds: soured milk, dairy product, fermented milk product, traditional food

## DISH Q118725971
- name: Rustida
- other names: {"it": "Rustida"}
- countries: (none)
- kinds: mixed grill, dish

## DISH Q118726793
- name: Migliaccio di grano
- other names: {"it": "migliaccio di grano"}
- countries: IT
- kinds: dish, savoury pie

## DISH Q118726852
- name: Slof
- other names: {"nl": "slof"}
- countries: (none)
- kinds: cake

## DISH Q118727349
- name: Colorado-style pizza
- description: pizza served at the Beau Jo's pizza restaurant chain in Colorado, made with a braided crust topped with heavy amounts of sauce and cheese and served with honey
- countries: (none)
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q11874587
- name: Lankkupihvi
- other names: {"fi": "Lankkupihvi"}
- countries: (none)
- kinds: dish

## DISH Q11874595
- name: Lanttusupikas
- description: Finnish pie
- countries: FI
- kinds: traditional food
- has Wikipedia article: en

## DISH Q118746862
- name: White chocolate cake
- description: cake made with white chocolate
- countries: (none)
- kinds: cake, chocolate cake, dessert
- ingredients: white chocolate

## DISH Q118746882
- name: Ricotta cake
- description: cheesecake made with ricotta
- countries: (none)
- kinds: cheesecake
- ingredients: ricotta

## DISH Q11875764
- name: Meat soup
- description: soup with meat as a main or significant ingredient
- countries: (none)
- kinds: soup

## DISH Q11875926
- name: Limppu
- description: Finnish bread
- countries: FI
- kinds: Finnish bread

## DISH Q11876213
- name: London drops
- description: Swedish/Finnish sugar-coated licorice
- countries: FI
- kinds: candy
- has Wikipedia article: en

## DISH Q1187678
- name: Candied almonds
- description: sweet almond snack food
- countries: ES
- kinds: candy, snack
- ingredients: almond, sugar
- has Wikipedia article: en

## DISH Q1187846
- name: Farfel
- description: egg noodle
- countries: (none)
- kinds: pasta
- has Wikipedia article: en

## DISH Q1187912
- name: Yatsuhashi
- other names: {"zh": "八橋"}
- description: Japanese confection from Kyoto
- countries: JP
- kinds: Miyagegashi, Kyōgashi
- ingredients: glutinous rice flour, cinnamon, sugar
- has Wikipedia article: en, zh

## DISH Q1188066
- name: Mohinga
- other names: {"zh": "緬甸魚湯麵"}
- description: Burmese dish consisting of rice noodle and fish soup
- countries: MM
- cuisines: Burmese cuisine
- kinds: national dish, fish soup
- has Wikipedia article: en, zh

## DISH Q118818058
- name: Salmerino del Trentino PGI
- other names: {"zh": "Salmerino del Trentino IGP"}
- description: Italian PGI fish, mollusc or crustacean product
- countries: IT
- kinds: seafood, Arctic char, fish as food

## DISH Q118819064
- name: Crudo di Cuneo
- other names: {"it": "crudo di Cuneo"}
- countries: IT
- kinds: prosciutto

## DISH Q118819170
- name: Marche PGI
- other names: {"zh": "Marche IGP"}
- description: Italian PGI olive oil
- countries: IT
- kinds: extra virgin olive oil, olive oil

## DISH Q118819272
- name: Salame Piemonte PGI
- other names: {"zh": "Salame Piemonte IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: salami, meat product

## DISH Q118819277
- name: Sale Marino di Trapani PGI
- other names: {"zh": "Sale Marino di Trapani IGP"}
- description: Italian PGI salt
- countries: IT
- kinds: table salt

## DISH Q118819751
- name: Salame Cremona PGI
- other names: {"zh": "Salame Cremona IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: salami, meat product

## DISH Q118823515
- name: Torrone di Bagnara PGI
- other names: {"zh": "Torrone di Bagnara IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: nougat, baked good

## DISH Q118823521
- name: Trote del Trentino PGI
- other names: {"zh": "Trote del Trentino IGP"}
- description: Italian PGI fish, mollusc or crustacean product
- countries: IT
- kinds: fish, rainbow trout, seafood

## DISH Q118823573
- name: Vitelloni Piemontesi della coscia PGI
- other names: {"zh": "Vitelloni Piemontesi della coscia IGP"}
- description: Italian PGI fresh meat
- countries: IT
- kinds: meat

## DISH Q11883329
- name: Muikkuhyvä
- other names: {"fi": "Muikkuhyvä"}
- countries: FI
- kinds: traditional food

## DISH Q11883561
- name: Mustikkamöllö
- other names: {"fi": "Mustikkamöllö"}
- countries: (none)
- kinds: dessert

## DISH Q11883562
- name: Mustikkakukko
- other names: {"fi": "Mustikkakukko"}
- countries: (none)
- kinds: pastry

## DISH Q11883564
- name: Mustikkapöperö
- description: Finnish traditional food
- countries: FI
- kinds: traditional food
- ingredients: bilberry, kama
- has Wikipedia article: en

## DISH Q11883680
- name: Mynthon
- description: Finnish brand of pastilles
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q1188380
- name: Yaki udon
- other names: {"zh": "炒烏冬"}
- description: food
- countries: JP
- kinds: udon, fried noodle, itamemono
- ingredients: udon
- has Wikipedia article: en, zh

## DISH Q118847406
- name: Bacalao Club Ranero
- other names: {"es": "Bacalao Club Ranero"}
- countries: (none)
- kinds: fish dish
- ingredients: Choricero peppers, Bacalao al pil-pil

## DISH Q11886671
- name: Papurokka
- other names: {"fi": "papurokka"}
- countries: (none)
- kinds: soup, dish

## DISH Q118868071
- name: قطايف
- other names: {"ar": "قطايف"}
- countries: (none)
- kinds: dish

## DISH Q118868156
- name: ABC
- description: Malaysian dessert
- countries: MY
- kinds: shaved ice, human food
- ingredients: kidney bean, evaporated milk, rose syrup, basil seed, condensed milk, grass jelly, Pandanus amaryllifolius, agar, ice cream, maize

## DISH Q1188729
- name: Mie goreng
- other names: {"zh": "印度炒麵"}
- description: Indonesian and Malaysian dish
- countries: ID
- kinds: fried noodle
- ingredients: chicken egg, kecap manis, chicken as food, oyster sauce, noodle, Brassica rapa subsp. chinensis, onion, Allium sativum
- has Wikipedia article: en, zh

## DISH Q118874832
- name: Mokthuk
- description: soup of Tibetan origin
- countries: IN, CN, NP
- cuisines: Indian cuisine, Tibetan cuisine, Nepalese cuisine
- kinds: soup
- has Wikipedia article: en

## DISH Q11887574
- name: Perunavelli
- other names: {"fi": "Perunavelli"}
- countries: (none)
- kinds: dish

## DISH Q11888054
- name: Piimävelli
- other names: {"fi": "Piimävelli"}
- countries: (none)
- kinds: dessert

## DISH Q11888163
- name: Pinaattiohukainen
- other names: {"fi": "pinaattiohukainen"}
- countries: (none)
- kinds: dish

## DISH Q1188911
- name: Crab stick
- other names: {"zh": "蟹肉棒"}
- description: form of kamaboko, a processed seafood made of finely pulverized white fish flesh (surimi)
- countries: JP
- kinds: seafood dish, imitation food
- ingredients: vegetable oil, fish surimi, egg as food, starch, table salt, sugar, soy bean
- has Wikipedia article: en, zh

## DISH Q11889435
- name: Pätkis
- other names: {"fi": "Pätkis"}
- countries: (none)
- kinds: chocolate bar

## DISH Q118895947
- name: Bánh dày
- description: traditional Vietnamese glutinous rice cake
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q118901115
- name: Almond chicken
- description: American Chinese dish
- countries: (none)
- cuisines: American Chinese cuisine
- kinds: dish
- ingredients: chicken as food, almond
- has Wikipedia article: en

## DISH Q11891334
- name: Rye porridge
- description: porridge made from rye grains, typically from flakes or flour
- countries: (none)
- kinds: porridge
- ingredients: rye flour, rye flakes

## DISH Q11891335
- name: Ruislimppu
- other names: {"fi": "Ruislimppu"}
- description: Finnish rye bread
- countries: (none)
- kinds: limppu, ruisleipä

## DISH Q1189138
- name: Butter cake
- other names: {"zh": "牛油蛋糕"}
- description: Cake using butter as a main ingredient
- countries: US
- cuisines: cuisine of the United States
- kinds: cake
- ingredients: flour, butter, sugar, drinking water
- has Wikipedia article: en, zh

## DISH Q11891415
- name: Sugarcane honey
- other names: {"zh": "甘蔗糖漿"}
- description: syrup produced from sugar cane
- countries: (none)
- kinds: molasses, syrup
- ingredients: Saccharum officinarum, sugarcane juice

## DISH Q11892106
- name: Salmiakkijauhe
- other names: {"fi": "salmiakkijauhe"}
- countries: (none)
- kinds: salty licorice, powder

## DISH Q1189231
- name: Breaded cutlet
- other names: {"zh": "吉列"}
- description: dish made from coating a cutlet of meat with breading or batter and either frying or baking it
- countries: (none)
- kinds: cutlet
- ingredients: bread crumbs
- has Wikipedia article: en, zh

## DISH Q118929559
- name: Siyez ekmeği
- other names: {"tr": "Siyez ekmeği"}
- countries: (none)
- kinds: bread

## DISH Q11893103
- name: Setsuuri
- other names: {"fi": "setsuuri"}
- description: bread
- countries: (none)

## DISH Q118944641
- name: Chuối nếp nướng
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q118946248
- name: Çatal
- other names: {"it": "Çatal"}
- countries: TR
- kinds: çörek

## DISH Q11894632
- name: SukuLaku
- other names: {"fi": "SukuLaku"}
- countries: (none)
- kinds: candy

## DISH Q118947831
- name: Gülüt cake
- description: Turkish cake from Sivas
- countries: TR
- cuisines: Turkish cuisine
- kinds: cake, dessert, type of food or dish
- ingredients: maize flour, egg as food, sugar

## DISH Q118947848
- name: Helatiye
- description: Turkish dessert
- countries: (none)
- kinds: dessert, food
- ingredients: mastic, starch, sugar, milk, water

## DISH Q118956479
- name: Sivas Köfte
- description: Meat dish from Sivas, Turkey
- countries: TR
- kinds: meat dish, type of food or dish
- ingredients: table salt, meat

## DISH Q118956651
- name: Peynirli yumurta
- countries: (none)
- kinds: dish

## DISH Q118956765
- name: Kibbeh bil siniyeh
- description: dish of Levantine cuisine
- countries: LB, SY
- cuisines: Arab cuisine, Levantine cuisine, Lebanese cuisine, Middle Eastern cuisine, Syrian cuisine
- kinds: kibbeh, meat dish
- ingredients: cinnamon, table salt, cumin seed, onion, peppercorn, clarified butter, allspice, lamb meat, baharat, bulgur, pine nut, walnut, beef, olive oil

## DISH Q118956893
- name: Magarina bulli
- other names: {"tr": "Magarina bulli"}
- countries: (none)
- kinds: dish

## DISH Q118957941
- name: Pabuç köftesi
- other names: {"tr": "Pabuç köftesi"}
- countries: (none)
- kinds: dish
- ingredients: kebab

## DISH Q11896500
- name: Tappaiskeitto
- countries: (none)
- kinds: soup, dish

## DISH Q118980907
- name: Banane Melba
- other names: {"fr": "banane Melba"}
- countries: (none)
- kinds: dessert

## DISH Q1189869
- name: Cake pop
- description: cake on a stick similar to a lollipop
- countries: US
- kinds: cake, lollipop, dish
- ingredients: cake
- has Wikipedia article: en

## DISH Q118995991
- name: Camel rider
- description: Sandwich
- countries: US
- kinds: food, sandwich
- ingredients: Italian dressing, pita, cold cut
- has Wikipedia article: en

## DISH Q11900159
- name: Valkosipuliperunat
- other names: {"fi": "Valkosipuliperunat"}
- countries: (none)
- kinds: dish

## DISH Q11900702
- name: Vehnäpuuro
- other names: {"fi": "Vehnäpuuro"}
- countries: (none)
- kinds: dish

## DISH Q119010473
- name: Taco placero
- description: kind of taco
- countries: MX
- kinds: taco, food

## DISH Q11902383
- name: Viennese nougat
- description: Soft brown form of Central European nougat
- countries: (none)
- kinds: nougat, confectionery
- has Wikipedia article: en

## DISH Q11903272
- name: Ässä Mix
- other names: {"fi": "Ässä Mix"}
- countries: (none)
- kinds: candy

## DISH Q1190475
- name: Tteokbokki
- other names: {"zh": "辣炒年糕"}
- description: South Korean dish made from rice and flour cakes
- countries: KR
- cuisines: Korean cuisine
- kinds: dish, bunsik, bokkeum
- ingredients: tteokmyeon
- has Wikipedia article: en, zh

## DISH Q11905092
- name: Almoixàvena
- other names: {"ca": "almoixàvena"}
- countries: (none)
- kinds: dish

## DISH Q11905311
- name: Ametlla d'Arenys
- other names: {"ca": "Ametlla d'Arenys"}
- countries: (none)
- kinds: confectionery
- ingredients: almond

## DISH Q11906685
- name: Arròs de conill
- other names: {"ca": "arròs de conill"}
- countries: (none)
- kinds: dish
- ingredients: rabbit, rice

## DISH Q11906687
- name: Arròs a la bruta
- other names: {"ca": "Arròs a la bruta"}
- countries: (none)
- kinds: dish

## DISH Q11907443
- name: Azinat
- other names: {"ca": "Azinat"}
- countries: (none)
- kinds: soup

## DISH Q11907497
- name: Bacallà a la llauna
- countries: (none)
- kinds: dish
- ingredients: garlic, tomato, paprika, Gadus morhua

## DISH Q11907650
- name: Balandra (salsa)
- other names: {"ca": "Balandra (salsa)"}
- countries: (none)
- kinds: dish

## DISH Q1190838
- name: Pain au chocolat
- other names: {"zh": "法式巧克力面包"}
- description: viennoiserie sweet roll
- countries: FR
- kinds: type of food or dish, food, viennoiserie, sweet roll
- ingredients: wheat flour, yeast, butter, table salt, sugar, water, chocolate
- has Wikipedia article: en

## DISH Q11912257
- name: Carabassat
- other names: {"ca": "Carabassat"}
- countries: (none)
- kinds: confectionery

## DISH Q11912912
- name: Casca (dolç)
- other names: {"ca": "Casca (dolç)"}
- countries: (none)
- kinds: dessert

## DISH Q119139178
- name: Ji dan gao
- description: Taiwanese sponge cakes served as desserts
- countries: TW
- kinds: sponge cake
- has Wikipedia article: en

## DISH Q11914389
- name: Coca de quarto
- other names: {"ca": "coca de quarto"}
- countries: (none)
- kinds: viennoiserie, confectionery

## DISH Q11914391
- name: Coca de pèsols
- other names: {"ca": "Coca de pèsols"}
- countries: (none)
- kinds: dish

## DISH Q11914392
- name: Coca garlanda
- countries: (none)
- kinds: handicraft, coca, dish

## DISH Q11914394
- name: Coca de xulla
- other names: {"ca": "coca de xulla"}
- countries: (none)
- kinds: dish

## DISH Q11916030
- name: Crespells
- countries: (none)
- kinds: confectionery

## DISH Q11916033
- name: Crespell (Menorca)
- other names: {"ca": "Crespell (Menorca)"}
- countries: (none)
- kinds: confectionery

## DISH Q11916443
- name: Cóc borratxo
- other names: {"ca": "cóc borratxo"}
- countries: (none)
- kinds: cake

## DISH Q119166759
- name: Bostana
- description: traditional salad from Şanlıurfa, Turkey
- countries: TR
- cuisines: Şanlıurfa cuisine
- kinds: salad, food
- ingredients: pomegranate molasses, purslane herb, parsley, tomato, Urfa biber, onion, cucumber, lemon juice, table salt

## DISH Q119171326
- name: Cialdino dei tufi
- other names: {"it": "Cialdino dei tufi"}
- countries: IT
- kinds: dish

## DISH Q119198843
- name: Chicken and broccoli
- description: American Chinese dish
- countries: (none)
- cuisines: American Chinese cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q11921967
- name: Fideus a la cassola
- description: Catalan casserole
- countries: (none)
- kinds: casserole
- ingredients: macaroni

## DISH Q11922606
- name: Tupí
- description: Catalan cheese
- countries: ES
- kinds: cheese, sheep milk cheese, cow's-milk cheese, soft cheese
- ingredients: cow's milk, sheep milk, aguardiente, liqueur, olive oil
- has Wikipedia article: en

## DISH Q119230232
- name: Unha de caranguejo
- description: Brazilian fried snack stuffed with crab meat typical of Pará
- countries: BR
- kinds: crab dish, seafood-based food
- ingredients: crab meat

## DISH Q11923085
- name: Freginat
- description: Meat dish from France and Spain
- countries: ES, FR
- kinds: dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q11923789
- name: Gargulló
- other names: {"ca": "gargulló"}
- countries: (none)
- kinds: dessert

## DISH Q11923862
- name: Gató d'ametlla
- other names: {"ca": "Gató d'ametlla"}
- countries: (none)
- kinds: cake
- ingredients: almond

## DISH Q119267911
- name: Lumblija
- description: Pastry from Croatia
- countries: HR
- kinds: pastry

## DISH Q1193251
- name: Baked potato
- other names: {"zh": "烤马铃薯"}
- description: potato dish
- countries: GB
- kinds: dish, potato dish
- ingredients: potato
- has Wikipedia article: en, zh

## DISH Q11934496
- name: Macarrons de Sant Joan
- other names: {"ca": "Macarrons de Sant Joan"}
- countries: (none)
- kinds: dessert

## DISH Q119352364
- name: Conti roll
- description: popular sandwich in Perth, Western Australia
- countries: IT
- cuisines: Italian cuisine
- kinds: sandwich
- has Wikipedia article: en

## DISH Q11935404
- name: Vosí hnízdo
- countries: (none)
- kinds: Christmas cookies
- ingredients: cocoa powder, butter, Savoiarde PAT

## DISH Q1193612
- name: Nata de coco
- other names: {"zh": "椰果"}
- description: Chewy, translucent, jelly-like food produced by the fermentation of coconut water
- countries: PH
- kinds: confectionery
- has Wikipedia article: en, zh

## DISH Q119362260
- name: Pizzarelle
- other names: {"it": "Pizzarelle"}
- countries: IT
- cuisines: Italian cuisine
- kinds: pasta, type of pasta
- ingredients: maize flour, wheat flour, egg as food, water

## DISH Q11936373
- name: Mel i mató
- description: Catalan dessert
- countries: ES
- kinds: dessert
- ingredients: Mató, honey

## DISH Q11937087
- name: Mitja lluna
- other names: {"ca": "Mitja lluna"}
- countries: (none)
- kinds: dish

## DISH Q11937654
- name: Morralla
- other names: {"ca": "morralla"}
- countries: (none)
- kinds: fish dish

## DISH Q11939713
- name: Saint George bread
- description: Catalan bread
- countries: ES
- kinds: bread

## DISH Q11940467
- name: Pastissets menorquins
- countries: (none)
- kinds: confectionery

## DISH Q11940469
- name: Pastisset d'ametlla
- other names: {"ca": "pastisset d'ametlla"}
- countries: (none)
- kinds: confectionery

## DISH Q11941571
- name: Picadeta
- other names: {"ca": "picadeta"}
- countries: (none)
- kinds: entremet

## DISH Q11942732
- name: First course
- countries: (none)
- kinds: dish, course

## DISH Q119436029
- name: Petah
- description: variations of typical Indonesian food
- countries: ID
- kinds: food
- ingredients: rice flour, Pandanus amaryllifolius, Dracaena, table salt

## DISH Q119436208
- name: Soto Semarang
- other names: {"id": "Soto Semarang"}
- countries: (none)
- kinds: soto

## DISH Q119436877
- name: Ayam iloni
- description: traditional chicken dish from Gorontalo, Indonesia
- countries: ID
- cuisines: Gorontalese cuisine
- kinds: food, dish, human food, type of food or dish
- ingredients: chicken as food, coconut milk, spice

## DISH Q119441937
- name: Dalca
- description: traditional curry-like stew from Aceh, Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: Indonesian cuisine, soup, food, dish, type of food or dish
- ingredients: ghee, beef

## DISH Q119442209
- name: Gulai Balak
- description: Authentic Indonesian food from Lampung
- countries: ID
- cuisines: Indonesian cuisine
- kinds: side dish, dish
- ingredients: turmeric rhizome, fennel fruit, caraway seeds, clove, cardamom, star anise, coconut milk, goat meat, beef, nutmeg, cinnamon

## DISH Q119442468
- name: Sambal Batak
- other names: {"id": "Sambal Batak"}
- countries: (none)
- cuisines: Batak cuisine
- kinds: dish

## DISH Q119442645
- name: Brengkes tempoyak
- other names: {"id": "Brengkes tempoyak"}
- countries: (none)
- kinds: food, dish, type of food or dish

## DISH Q11946299
- name: Rosari ensucrat
- other names: {"ca": "rosari ensucrat"}
- countries: (none)
- kinds: confectionery

## DISH Q119496294
- name: 10 Won Bread
- other names: {"zh": "十元燒"}
- description: South Korean pancake
- countries: KR
- kinds: pancake
- has Wikipedia article: en, zh

## DISH Q11950904
- name: Taretes
- other names: {"ca": "taretes"}
- countries: (none)
- kinds: entrée

## DISH Q119520770
- name: Adjidjat
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: minced meat, fish as food, Brassica oleracea, egg as food, potato, cheese

## DISH Q119520979
- name: Hoi lai pad nam phrik phao
- other names: {"it": "Hoi lai pad nam phrik phao"}
- countries: TH
- cuisines: Thai cuisine
- kinds: dish
- ingredients: chili sauce, Thai basil, clam

## DISH Q119527495
- name: Yum yum
- description: glazed hand-twisted rope-shaped doughnut
- countries: (none)
- kinds: dessert, fried dough, deep-fried food

## DISH Q1195276
- name: Birthday cake
- other names: {"zh": "生日蛋糕"}
- description: dessert served to celebrate a birthday
- countries: (none)
- kinds: torte, dish
- has Wikipedia article: en, zh

## DISH Q1195290
- name: Korokke
- other names: {"zh": "可乐饼"}
- description: Japanese potato dish
- countries: JP
- kinds: food, potato dish, Agemono
- ingredients: potato
- has Wikipedia article: en, zh

## DISH Q11952927
- name: Toña de repulgo
- other names: {"ca": "toña de repulgo"}
- countries: (none)
- kinds: confectionery

## DISH Q119535389
- name: Malbi
- description: A beef dish from Palembang
- countries: ID
- cuisines: Palembang cuisine
- kinds: food
- ingredients: shallot, garlic, kecap manis, coconut milk, cooking oil, beef, table salt
- has Wikipedia article: en

## DISH Q119539370
- name: Sari pengantin
- description: traditional Banjarese cake from South Kalimantan, Indonesia
- countries: ID
- kinds: kue, dish, type of food or dish
- ingredients: condensed milk, wheat flour, rice flour, coconut milk, Pandanus amaryllifolius, egg as food, vanilla, table salt, sugar, water

## DISH Q119540225
- name: Kararaban
- description: one of Indonesian foods
- countries: ID
- kinds: food, traditional food, snack
- ingredients: chicken egg, coconut, wheat flour, palm sugar, rice flour, table salt

## DISH Q119540443
- name: Kokoleh
- description: traditional Banjarese dessert from South Kalimantan, Indonesia
- countries: ID
- kinds: traditional food, food, type of food or dish
- ingredients: palm sugar, rice flour, Pandanus amaryllifolius, water

## DISH Q119540614
- name: Rangai
- description: Specialty cuisine of South Kalimantan, Indonesia
- countries: ID
- kinds: kue, food
- ingredients: grated coconut, wheat flour, palm sugar, table salt

## DISH Q119540652
- name: Apam paranggi
- description: one of Indonesian foods
- countries: ID
- kinds: food, traditional food, snack, kue
- ingredients: coconut, wheat flour, rice flour, yeast, vanilla, table salt, sugar

## DISH Q119540715
- name: Lam Cake
- description: Specialty cuisine of South Kalimantan, Indonesia
- countries: (none)
- kinds: cake, food
- ingredients: condensed milk, wheat flour, coconut milk, egg as food, sugar

## DISH Q119541331
- name: Sagela
- description: traditional smoked fish dish from Gorontalo, Indonesia
- countries: ID
- kinds: dish, human food, type of food or dish
- ingredients: Hemiramphidae

## DISH Q119541430
- name: Satay Tuna
- description: Indonesian dish originally from Gorontalo
- countries: ID
- kinds: satay, dish
- has Wikipedia article: en

## DISH Q119541509
- name: Ilabulo
- other names: {"id": "Ilabulo"}
- countries: ID
- cuisines: Gorontalese cuisine
- kinds: food, cuisine, human food
- ingredients: sago flour, offal, egg as food, spice

## DISH Q119541807
- name: Koyabu
- description: variations of typical Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish
- ingredients: coconut, palm sugar

## DISH Q11954455
- name: Ventre farcit
- other names: {"ca": "ventre farcit"}
- countries: (none)
- kinds: dish

## DISH Q11955443
- name: Xurrasquera
- other names: {"ca": "xurrasquera"}
- countries: (none)
- kinds: dish

## DISH Q11957646
- name: Amagermad
- other names: {"da": "amagermad"}
- countries: (none)
- kinds: dish

## DISH Q119580643
- name: Gangan paliat
- other names: {"bjn": "Gangan paliat"}
- countries: ID
- kinds: soup, dish

## DISH Q119580769
- name: Smothered pork chops
- description: American recipe
- countries: (none)
- kinds: pork chop, dish

## DISH Q119605527
- name: New York roll
- description: Pastry made from croissant dough
- countries: (none)
- cuisines: cuisine of the Mid-Atlantic United States
- kinds: pastry
- has Wikipedia article: en

## DISH Q119608124
- name: Jyu cheung fun
- other names: {"zh": "猪肠粉"}
- description: plain rice noodle roll with no filling
- countries: CN
- kinds: dish
- has Wikipedia article: zh

## DISH Q1196125
- name: Almond biscuit
- other names: {"zh": "扁桃仁餅"}
- description: almond seed biscuit
- countries: CN
- cuisines: Chinese cuisine
- kinds: biscuit
- ingredients: apricot kernel
- has Wikipedia article: en

## DISH Q11961672
- name: Blueberry jam
- description: jam made from (North American) blueberries
- countries: (none)
- kinds: berry jam
- ingredients: blueberry
- has Wikipedia article: en

## DISH Q11962286
- name: Raspberry jam
- description: jam made from raspberries
- countries: (none)
- kinds: marmalade, berry jam
- ingredients: raspberry, sugar
- has Wikipedia article: en

## DISH Q1196289
- name: Doenjang
- other names: {"zh": "大酱"}
- description: Korean fermented soybean paste
- countries: KR
- cuisines: Korean cuisine
- kinds: meal, fermented bean paste
- ingredients: brine, meju
- has Wikipedia article: en, zh

## DISH Q11969230
- name: Fleskeball
- other names: {"nb": "Fleskeball"}
- countries: NO
- kinds: dish, dumpling
- ingredients: fatty pork, fish as food

## DISH Q1197104
- name: Koshari
- other names: {"zh": "苦沙利"}
- description: Egyptian dish
- countries: EG
- kinds: dish
- ingredients: lentil, chickpea, tomato sauce, fried onion, vermicelli, macaroni, rice
- has Wikipedia article: en, zh

## DISH Q119722087
- name: Harlequin
- description: Czech chocolate cake
- countries: FR
- kinds: cake, chocolate cake
- ingredients: cocoa, chocolate, whipped cream, chocolate cake

## DISH Q119724198
- name: Napoleonbakelse
- countries: SE
- kinds: mille-feuille, cake

## DISH Q1197400
- name: Crouton
- other names: {"zh": "麵包丁"}
- description: piece of sautéed or rebaked bread, often cubed and seasoned, added to salads, soups, stews, or eaten as a snack
- countries: (none)
- kinds: food, baked good
- ingredients: cooking oil, milk, bread
- has Wikipedia article: en

## DISH Q119778178
- name: Lechon
- other names: {"zh": "菲律賓燒乳豬"}
- description: Filipino pork dish
- countries: PH
- cuisines: Filipino cuisine
- kinds: rotisserie, pork dish, lechon
- has Wikipedia article: zh

## DISH Q119788537
- name: Siverek tava
- description: traditional meat dish from Şanlıurfa Province, Turkey
- countries: TR
- cuisines: Şanlıurfa cuisine
- kinds: dish

## DISH Q119788538
- name: Aya köftesi
- description: traditional meat and bulgur dish from Şanlıurfa, Turkey
- countries: TR
- cuisines: Şanlıurfa cuisine
- kinds: food

## DISH Q119793323
- name: Ullikkary
- description: Curry dish of Kerala
- countries: (none)
- kinds: Indian curry

## DISH Q119793523
- name: Thakkalikkary
- description: Curry dish of Kerala
- countries: (none)
- kinds: Indian curry

## DISH Q11979474
- name: Christmas candy
- description: candy for Christmas
- countries: (none)
- kinds: candy

## DISH Q119812449
- name: ארבעס
- other names: {"he": "ארבעס"}
- countries: IL
- cuisines: Jewish cuisine
- kinds: cicer arietinum, food

## DISH Q119819391
- name: Kulesha
- description: Ukrainian dish
- countries: UA
- kinds: dish
- ingredients: maize flour, boiling water, pork skin, fried onion, smetana, ham, fat, table salt, bacon

## DISH Q119820710
- name: Caribé porridge
- description: Amazon cuisine food
- countries: (none)
- kinds: porridge

## DISH Q119820716
- name: Unha de camarão
- other names: {"pt": "unha de camarão"}
- countries: (none)
- kinds: shrimp dish

## DISH Q119828752
- name: Babka
- description: Jewish sweet braided bread
- countries: (none)
- kinds: sweet bread
- has Wikipedia article: en

## DISH Q119863250
- name: Atakali
- description: one sweet dish from the Chhapan bhog of Lord Jagannath
- countries: IN
- kinds: confectionery, rice dish, food

## DISH Q119868237
- name: Gaja
- description: Indian dessert
- countries: IN
- kinds: dessert

## DISH Q119894990
- name: Ginger cake
- description: a cake variety spiced with ginger, originating in the British cuisine
- countries: (none)
- kinds: spice cake, dish
- ingredients: ginger, dough

## DISH Q119898571
- name: Chocolate drops
- description: small pieces or droplets of solid chocolate used in baking and confectionery
- countries: (none)
- kinds: chocolate
- ingredients: chocolate

## DISH Q119906402
- name: Patauá oil
- description: Type of essential oil
- countries: BR
- kinds: essential oil

## DISH Q119908354
- name: Babassu coconut oil
- description: Type of essential oil
- countries: BR
- kinds: essential oil

## DISH Q119909667
- name: Paraense Caldeirada
- description: Type of caldeirada typical of the North Region of Brazil
- countries: BR
- kinds: Caldeirada

## DISH Q11991266
- name: New York-style cheesecake
- description: rich, dense, smooth, and creamy cheesecake, containing heavy cream or sour cream
- countries: US
- kinds: cheesecake
- has Wikipedia article: en

## DISH Q119920352
- name: Buriti oil
- description: Type of essential oil
- countries: BR
- kinds: essential oil

## DISH Q11996671
- name: Pølse i lompe
- other names: {"nb": "pølse i lompe"}
- countries: (none)
- kinds: dish, fast food
- ingredients: lompe

## DISH Q11996674
- name: Hot dog in waffle
- description: fast food in some areas of Scandinavia
- countries: SE
- kinds: food, dish
- ingredients: Vienna sausage, waffle

## DISH Q11996678
- name: Pølsemix
- other names: {"da": "Pølsemix"}
- countries: (none)
- kinds: dish
- ingredients: fries, sausage

## DISH Q1199738
- name: Pandoro
- other names: {"zh": "潘多酪面包"}
- description: Italian food
- countries: IT
- kinds: brioche, Christmas dessert, sweet bread
- ingredients: flour, butter, sugar
- has Wikipedia article: en, zh

## DISH Q119983869
- name: Sonso de yuca
- other names: {"es": "Sonso de yuca"}
- countries: BO
- kinds: food
- ingredients: cassava

## DISH Q12001043
- name: Skjenning
- description: Norwegian flatbread
- countries: NO
- kinds: flatbread
- has Wikipedia article: en

## DISH Q120014728
- name: Chang-Wang noodles
- other names: {"zh": "肠旺面"}
- description: Chinese noodle soup dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q1200514
- name: Moules-frites
- other names: {"zh": "贻贝薯条"}
- description: dish of mussels and fries
- countries: BE
- cuisines: cuisine of Belgium
- kinds: dish, potato dish, seafood dish
- ingredients: Mussels marinière, fries, Mytilus edulis
- has Wikipedia article: en, zh

## DISH Q120069075
- name: Lemon pepper wings
- description: chicken wings dish from Atlanta, Georgia, US
- countries: (none)
- cuisines: cuisine of the Southern United States
- kinds: food, dish
- has Wikipedia article: en

## DISH Q12007500
- name: Trollkrem
- description: Norwegian dessert
- countries: NO
- cuisines: Norwegian cuisine
- kinds: dessert
- has Wikipedia article: en

## DISH Q1200915
- name: Sekihan
- other names: {"zh": "赤飯"}
- description: Japanese glutinous rice dish eaten for celebrations
- countries: JP
- kinds: okowa, cooked glutinous rice, red bean rice
- ingredients: Vigna angularis, glutinous rice
- has Wikipedia article: zh

## DISH Q120096
- name: Tempeh
- other names: {"zh": "丹貝"}
- description: Indonesian soy product originated from Java island, used as protein source
- countries: ID
- cuisines: Indonesian cuisine
- kinds: staple food, side dish, fermented food, type of food or dish, meat alternative, soy food, plant-based meat analogue
- ingredients: soy bean, Rhizopus oligosporus, acetic acid, soybean, water
- has Wikipedia article: en, zh

## DISH Q120174787
- name: Ant egg soup
- description: type of soup made with ant eggs
- countries: (none)
- kinds: soup, type of food or dish
- ingredients: ant eggs
- has Wikipedia article: en

## DISH Q120176394
- name: Peanuts and Coke
- description: popular snack from Southern United States
- countries: (none)
- kinds: dish
- ingredients: peanut, Coca-Cola
- has Wikipedia article: en

## DISH Q12017928
- name: Fyltur lundi
- other names: {"ca": "Fyltur lundi"}
- countries: FO
- kinds: dish
