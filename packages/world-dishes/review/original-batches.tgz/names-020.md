# Review batch names-020

## DISH Q13101370
- name: Aachtchen
- other names: {"lb": "Aachtchen"}
- countries: (none)
- kinds: cake

## DISH Q131015889
- name: Biscotto umberto
- countries: (none)
- kinds: biscuit

## DISH Q131036344
- name: Kati
- description: Kati is a tradional meal of southern Kaduna people. It is rich in nutrient and test
- countries: (none)
- cuisines: carbohydrate
- kinds: food

## DISH Q131048134
- name: Doghramaj
- description: Azerbaijani cold soup (different from Q611164)
- countries: AZ
- cuisines: Azerbaijani cuisine
- kinds: food, cold sweet soup
- has Wikipedia article: en

## DISH Q13105845
- name: Bononoka
- description: Malagasy food
- countries: (none)
- kinds: dish

## DISH Q13107858
- name: Papillote
- description: chocolate in shiny paper
- countries: (none)
- kinds: sweetmeat

## DISH Q13110362
- name: Ginger Curd
- description: Curry
- countries: (none)
- kinds: curry, curd

## DISH Q131104406
- name: Siddu
- description: type of wheat flour bread from India
- countries: (none)
- cuisines: North Indian cuisine
- kinds: bread

## DISH Q13110689
- name: Erissery
- description: Kerala side dish
- countries: (none)
- kinds: side dish, curry
- ingredients: coconut, pumpkin
- has Wikipedia article: en

## DISH Q13110866
- name: Olan
- description: Kerala dish
- countries: (none)
- kinds: side dish, curry, dish
- ingredients: coconut, Wax gourd
- has Wikipedia article: en

## DISH Q13111417
- name: Koovappodi payasam
- description: Sweet dish of Kerala
- countries: (none)
- kinds: pudding, payasam

## DISH Q131118490
- name: Chicken tuturuga
- description: traditional food from Manado
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, Indonesian cuisine, traditional food, type of food or dish, gulai

## DISH Q131124911
- name: Thiere
- description: Senegalese couscous dish originating from the Serer people
- countries: SN
- kinds: type of food or dish, food, dish
- ingredients: date pit, potato, meatball, bean, millet
- has Wikipedia article: en

## DISH Q131125406
- name: Bubur bodas
- other names: {"su": "Bubur bodas"}
- countries: ID
- kinds: porridge, human food
- ingredients: table salt, rice

## DISH Q13113101
- name: Paripuvada
- description: snack food of Kerala
- countries: (none)
- kinds: food, Vada
- ingredients: dal

## DISH Q13113392
- name: പുളിയിഞ്ചി
- other names: {"ml": "പുളിയിഞ്ചി"}
- countries: (none)
- kinds: dish

## DISH Q131141679
- name: High mountain honey
- countries: (none)
- kinds: mountain honey

## DISH Q131141698
- name: Rosemary honey
- countries: (none)
- kinds: monofloral honey

## DISH Q13114512
- name: Vattayappam
- countries: (none)
- kinds: appam

## DISH Q131145353
- name: Gangan Tatanding
- description: Indonesian food
- countries: ID
- kinds: dish, soup

## DISH Q131145392
- name: Tumis Kalakai
- description: Indonesian food
- countries: ID
- kinds: dish, soup

## DISH Q13114957
- name: Sharkarapuratti
- description: Banana based sweet snack from Kerala
- countries: IN
- kinds: snack
- ingredients: cooking banana
- has Wikipedia article: en

## DISH Q131151109
- name: Gangan Balamak
- other names: {"id": "Gangan Balamak"}
- countries: ID
- kinds: dish, soup

## DISH Q131152213
- name: Pane di Lentini
- other names: {"it": "Pane di Lentini"}
- countries: (none)
- kinds: bread

## DISH Q131181337
- name: Ramanonaka
- description: traditional Malagasy snack, typically sold as street food, made primarily from rice flour
- countries: MG
- kinds: dish
- ingredients: rice flour, salt, sugar

## DISH Q13120927
- name: Waran Phale
- description: Maharashtrian dish
- countries: IN
- cuisines: Maharashtrian cuisine
- kinds: food

## DISH Q13123554
- name: Kitawa
- description: dish
- countries: (none)
- kinds: dish
- ingredients: baking powder, milk, banana

## DISH Q13124305
- name: Mtori
- other names: {"zh": "香蕉汤"}
- description: Tanzanian stew
- countries: TZ
- kinds: food
- ingredients: potato, meat, milk, banana
- has Wikipedia article: en, zh

## DISH Q13125722
- name: Bara llaeth
- other names: {"cy": "bara llaeth"}
- countries: (none)
- kinds: bread dish

## DISH Q13126223
- name: Welsh breakfast
- description: traditional full breakfast in Wales
- countries: (none)
- kinds: full breakfast

## DISH Q13126300
- name: Brwchan
- other names: {"cy": "brwchan"}
- countries: (none)
- kinds: flummery

## DISH Q131286570
- name: Szczecin bread
- countries: PL
- kinds: bread

## DISH Q131291967
- name: Hmiss
- description: Food in Algeria
- countries: (none)
- cuisines: Algeria
- kinds: food

## DISH Q131304191
- name: Масляны баран
- other names: {"be": "Масляны баран"}
- countries: (none)
- kinds: dish

## DISH Q131307427
- name: Tuwon dankali
- description: food made from sweet potatoes
- countries: (none)
- kinds: dish

## DISH Q13131783
- name: Teisen Berffro
- description: shortbread pressed with scallop shell
- countries: (none)
- kinds: shortbread

## DISH Q131319334
- name: Mbongo Tchobi
- description: Cameroonian cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q131319336
- name: Tapalapa
- other names: {"fr": "tapalapa"}
- countries: (none)
- kinds: dish

## DISH Q131342981
- name: Agepan
- description: Japanese bread
- countries: JP
- kinds: sweet bread

## DISH Q131343036
- name: Mentai-france
- description: Japanese bread
- countries: JP
- kinds: bread
- ingredients: myeongnan-jeot

## DISH Q131345048
- name: Panianky
- description: Ukrainian christmas gingerbread
- countries: UA
- kinds: pryanik

## DISH Q131355057
- name: やたら
- other names: {"ja": "やたら"}
- countries: (none)
- kinds: dish

## DISH Q131361148
- name: Petoules
- description: The "petoules" of Messinia are a traditional delicacy traditionally prepared on Cheese Sunday. With just three basic ingredients – flour, water, and salt – and a touch of olive oil for frying, they are finished with a sprinkle of myzithra cheese.
- countries: GR
- kinds: pancake

## DISH Q13136566
- name: Keallepoat
- other names: {"fy": "keallepoat"}
- countries: (none)
- kinds: dish

## DISH Q13136655
- name: Koarstekoeke
- other names: {"fy": "koarstekoeke"}
- countries: (none)
- kinds: food, cookie

## DISH Q131367062
- name: Mortirigüelo
- other names: {"es": "Mortirigüelo"}
- countries: ES
- cuisines: cuisine of the Region of Murcia
- kinds: cocido

## DISH Q13136717
- name: Ontbijtkoek
- description: Dutch-Belgian spiced cake
- countries: BE
- kinds: food, sweet bread
- ingredients: high fructose corn syrup, rye flour, pudding spice
- has Wikipedia article: en

## DISH Q13137967
- name: Sopwigge
- other names: {"fy": "sopwigge"}
- countries: (none)
- kinds: Christmas food

## DISH Q131379933
- name: 蒜泥白肉
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q13138186
- name: Switsersk taartsje
- other names: {"fy": "Switsersk taartsje"}
- countries: (none)
- kinds: small pastry

## DISH Q13138254
- name: Sûkerlatte
- other names: {"fy": "sûkerlatte"}
- countries: (none)
- kinds: food, cookie

## DISH Q131384156
- name: Mahmoosa
- description: Syrian veggie dish
- countries: SY
- kinds: dish

## DISH Q131385265
- name: Horseradish soup
- description: traditional Romanian sour soup dish, made from poultry meat and bones
- countries: (none)
- kinds: soup, human food

## DISH Q131385357
- name: Silviakaka
- other names: {"sv": "silviakaka"}
- countries: (none)
- kinds: sponge cake

## DISH Q131385571
- name: Bertagnin
- other names: {"lmo": "Bertagnin"}
- countries: IT
- kinds: dish
- ingredients: cod

## DISH Q13138574
- name: Weakkewich
- other names: {"fy": "weakkewich"}
- countries: (none)
- kinds: dish
- ingredients: white bread, milk

## DISH Q131387128
- name: Bolas de Pedernales
- other names: {"es": "Bolas de Pedernales"}
- countries: MX
- kinds: meat dish, food, dish

## DISH Q131395421
- name: 尼亚格拉粑粑
- countries: MD
- cuisines: Moldovan cuisine
- kinds: dessert
- ingredients: kefir, sodium bicarbonate, oil, flour, sugar, milk, vodka

## DISH Q131400085
- name: Kuanfen noodles
- other names: {"zh": "宽粉"}
- description: Chinese potato noodles
- countries: CN
- cuisines: Sichuan cuisine
- kinds: noodle dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q131400142
- name: Suan la fen
- description: Chinese noodle stew
- countries: CN
- cuisines: Sichuan cuisine
- kinds: stew
- ingredients: Kuanfen noodles, chili oil
- has Wikipedia article: en

## DISH Q131404561
- name: Roasted sweet potatoes in Japan
- countries: (none)
- kinds: roasted sweet potatoes, potato dish

## DISH Q131413340
- name: Lamaniets
- description: Belarusian unleavened shortbread cookie
- countries: BY
- cuisines: Belarusian cuisine
- kinds: cookie, artificial object
- ingredients: vegetable oil, wheat flour, poppy seed, honey

## DISH Q13142576
- name: Fastenwähe
- description: Swiss pastry
- countries: CH
- cuisines: Swiss cuisine
- kinds: pastry
- ingredients: caraway seeds, yeast dough

## DISH Q13142671
- name: Holzofenbrot
- other names: {"de": "Holzofenbrot"}
- countries: (none)
- kinds: bread, pastry

## DISH Q13143933
- name: Shamēta
- description: Food produced in Ethiopia
- countries: ET
- cuisines: Ethiopian cuisine
- kinds: food product
- ingredients: soy bean

## DISH Q13144030
- name: K’urit’i
- description: food made from raw meat produced in Ethiopia
- countries: ET
- cuisines: Ethiopian cuisine
- kinds: human food
- ingredients: goat meat, mustard

## DISH Q13144066
- name: K’ik’ili
- description: meat-based food produced in Ethiopia
- countries: ET
- cuisines: Ethiopian cuisine
- kinds: human food, meat product

## DISH Q131440796
- name: Onsalakorv
- description: Swedish sausage
- countries: SE
- kinds: sausage

## DISH Q13144104
- name: ቋንጣ
- other names: {"am": "ቋንጣ"}
- description: Food usually made from minced meat and seasoned with vinegar or salt
- countries: ET
- cuisines: Ethiopian cuisine
- kinds: human food
- ingredients: minced meat

## DISH Q13144105
- name: Quanta firfir
- description: Ethiopian dish
- countries: ET
- kinds: dish
- ingredients: tomato, dried meat, injera, berbere

## DISH Q131441485
- name: Tajine jben
- other names: {"fr": "tajine jben"}
- countries: (none)
- kinds: dish

## DISH Q131443882
- name: Banana gummy
- description: banana-flavored foam candies
- countries: (none)
- kinds: foam candy
- ingredients: marshmallow

## DISH Q131445509
- name: برانية (طعام)
- other names: {"ar": "برانية (طعام)"}
- countries: (none)
- kinds: dish

## DISH Q131445533
- name: المشموم
- other names: {"ar": "المشموم"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: cake, Pastries of Algeria
- ingredients: pine nut, almond, Pistacia vera, sugar

## DISH Q131446222
- name: 南関あげ
- other names: {"ja": "南関あげ"}
- countries: (none)

## DISH Q131452143
- name: Coppa sabauda
- other names: {"it": "coppa sabauda"}
- countries: IT
- kinds: dessert

## DISH Q13145676
- name: Oat flour
- countries: (none)
- kinds: flour, oatmeal
- ingredients: oats

## DISH Q131457390
- name: Jhinuk pitho
- description: oyster pancake wrapped and roasted in leaf plate
- countries: (none)
- kinds: oyster dish
- ingredients: oyster as food

## DISH Q131457577
- name: Gudu lat
- description: rat meat wrapped and roasted in leaves
- countries: (none)
- kinds: rat dish

## DISH Q131459325
- name: Muri Ghanto
- countries: (none)
- kinds: Ghanto, fish curry
- ingredients: fish head

## DISH Q131470403
- name: Dresdner Christstollen
- other names: {"de": "Dresdner Christstollen"}
- countries: (none)
- kinds: stollen, protected geographical indication

## DISH Q13147186
- name: Fiyuela
- other names: {"ast": "Fiyuela"}
- description: Spanish dessert
- countries: ES
- kinds: dessert

## DISH Q13147213
- name: Varenyky
- other names: {"zh": "乌克兰饺子"}
- description: stuffed dumplings of unleavened dough
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: type of pasta, stuffed pasta
- ingredients: berry, fruit, edible mushroom, mashed potato, quark, meat
- has Wikipedia article: en, zh

## DISH Q13147842
- name: Panchón
- other names: {"ast": "Panchón"}
- countries: ES
- kinds: dessert

## DISH Q131515049
- name: Alung
- description: Indonesian food
- countries: ID
- kinds: traditional food, kue

## DISH Q131515348
- name: Apam hambuku
- description: Indonesian food
- countries: ID
- kinds: traditional food, kue

## DISH Q131515529
- name: Babantalan
- description: Indonesian food
- countries: ID
- kinds: traditional food, kue

## DISH Q131516414
- name: Bakak
- description: Indonesian food
- countries: ID
- kinds: traditional food, kue

## DISH Q131531475
- name: Orange givrée
- other names: {"fr": "orange givrée"}
- countries: (none)
- kinds: dish

## DISH Q131537686
- name: Rekesalat
- other names: {"nb": "rekesalat"}
- countries: (none)
- kinds: condiments and seasonings
- ingredients: lime juice, shrimp, boiled egg, mayonnaise

## DISH Q131540318
- name: Dobladillo
- other names: {"es": "Dobladillo"}
- countries: (none)
- kinds: bocadillo

## DISH Q131545921
- name: சீனி அரியாரம்
- other names: {"ta": "சீனி அரியாரம்"}
- countries: (none)
- cuisines: Tamil cuisine
- kinds: human food

## DISH Q131552735
- name: Shingen mochi
- countries: (none)
- kinds: mochi, Miyagegashi

## DISH Q131560883
- name: Anneau des Gors
- other names: {"fr": "Anneau des Gors"}
- countries: FR
- kinds: goat cheese, French cheese
- ingredients: goat milk, raw milk

## DISH Q131562730
- name: ثومة
- other names: {"ar": "ثومة"}
- countries: (none)
- kinds: dish

## DISH Q131564107
- name: ِAbbas bread
- description: type of Iraqi bread
- countries: IQ
- cuisines: Iraqi cuisine
- kinds: bread, human food
- ingredients: flour, table salt, vegetable, drinking water
- has Wikipedia article: en

## DISH Q131564939
- name: Schwowebredle
- other names: {"fr": "schwowebredle"}
- countries: (none)
- kinds: dish

## DISH Q131577417
- name: Prune porridge
- description: a type of porridge
- countries: (none)
- kinds: porridge
- ingredients: prune

## DISH Q131588338
- name: قبوط
- other names: {"ar": "قبوط"}
- countries: (none)
- kinds: dish

## DISH Q131589999
- name: Vitoulet
- other names: {"fr": "vitoulet"}
- countries: (none)
- kinds: dish

## DISH Q131591198
- name: جاري
- other names: {"ary": "جاري"}
- countries: MA
- kinds: pastry

## DISH Q131605468
- name: Surówka
- other names: {"pl": "surówka"}
- countries: PL
- kinds: salad, dish

## DISH Q131607
- name: 波伦塔
- description: corn meal boiled into a porridge
- countries: IT
- kinds: porridge, dish
- ingredients: maize flour, cornmeal
- has Wikipedia article: en, zh

## DISH Q131613108
- name: Almela farcida de torró
- other names: {"ca": "Almela farcida de torró"}
- countries: ES
- kinds: sweetmeat
- ingredients: jijona, Neula

## DISH Q13161952
- name: Shredded chicken
- other names: {"zh": "手撕雞"}
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: zh

## DISH Q131620445
- name: Golasy
- other names: {"pl": "Golasy"}
- countries: (none)
- kinds: dish

## DISH Q1316209
- name: Street food
- other names: {"zh": "街头食品"}
- description: ready-to-eat food or drink served on a street
- countries: (none)
- kinds: cuisine, fast food, prepared food
- has Wikipedia article: en, zh

## DISH Q131628439
- name: Bamboo Shoot Hot Pot
- other names: {"zh": "竹笋火锅"}
- description: variation of Sichuan hot pot
- countries: (none)
- kinds: hot pot
- ingredients: bamboo shoots

## DISH Q131630859
- name: Hajnowski marcinek
- description: cake from Poland
- countries: PL
- kinds: cake, traditional food, pastry
- ingredients: smetana, egg as food, flour, butter

## DISH Q13164441
- name: Steamed minced pork
- other names: {"zh": "蒸肉餅"}
- description: Chinese pork dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en, zh

## DISH Q13164446
- name: Ginger candy
- description: type of candy
- countries: (none)
- kinds: candy

## DISH Q131659212
- name: Pap en vleis
- other names: {"fr": "pap en vleis"}
- countries: (none)
- kinds: dish

## DISH Q131659239
- name: Pampoenkoekies
- description: South African pumpkin fritter
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q131660738
- name: Eggs and tomato
- countries: (none)
- kinds: dish

## DISH Q1316624
- name: Imagawayaki
- other names: {"zh": "今川烧"}
- description: Japanese dessert
- countries: JP
- kinds: type of food or dish, wagashi
- ingredients: red bean paste, batter
- has Wikipedia article: en, zh

## DISH Q131677489
- name: Gigot Brayaude
- other names: {"fr": "gigot Brayaude"}
- countries: (none)
- kinds: dish

## DISH Q131677556
- name: Jangui
- other names: {"fr": "jangui"}
- countries: (none)
- kinds: dish

## DISH Q131680354
- name: Falette
- other names: {"fr": "falette"}
- countries: (none)
- kinds: dish

## DISH Q131683895
- name: Jaffle
- description: toasted sandwich with sealed edges
- countries: (none)
- kinds: toasted sandwich, dish
- has Wikipedia article: zh

## DISH Q131684342
- name: Irú
- other names: {"fr": "Irú"}
- countries: (none)
- kinds: dish

## DISH Q131684959
- name: Lessove
- other names: {"fr": "lessove"}
- countries: (none)
- kinds: dish

## DISH Q131693461
- name: Makrout qalb elouz
- other names: {"fr": "Makrout qalb elouz"}
- countries: (none)
- kinds: dish

## DISH Q131693492
- name: Makrout el koucha
- other names: {"fr": "Makrout el koucha"}
- countries: (none)
- kinds: dish

## DISH Q131693559
- name: Maroudh twissate
- other names: {"fr": "Maroudh twissate"}
- countries: (none)
- kinds: dish

## DISH Q131693741
- name: Makrout prestige
- other names: {"fr": "Makrout prestige"}
- countries: (none)
- kinds: dish

## DISH Q131695736
- name: Lao Cassia Stew
- countries: LA
- kinds: human food
- ingredients: Padaek, chili pepper

## DISH Q131699735
- name: Moukhbaza
- other names: {"fr": "Moukhbaza"}
- countries: (none)
- kinds: dish

## DISH Q131700077
- name: Spantôle
- other names: {"fr": "Spantôle"}
- countries: (none)
- kinds: dish

## DISH Q131700098
- name: Serobe
- other names: {"fr": "serobe"}
- countries: (none)
- kinds: dish

## DISH Q131705474
- name: Scofa
- other names: {"fr": "Scofa"}
- countries: (none)
- kinds: pastry

## DISH Q131720008
- name: Csülök pékné módra
- countries: HU
- kinds: dish, golonka
- ingredients: garlic, potato, onion, ham hock

## DISH Q131720366
- name: Patia
- other names: {"fr": "Patia"}
- countries: (none)
- kinds: dish

## DISH Q131720377
- name: Fuczki
- other names: {"pl": "Fuczki"}
- countries: PL, UA
- kinds: dish, zrazy

## DISH Q131727424
- name: Пироги з калиною
- other names: {"uk": "Пироги з калиною"}
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: pirozhki, baking

## DISH Q131730781
- name: Kharkiv-style cutlets
- description: Ukrainian dish, cutlets with liver filling
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: nutriment, frying, meat dish
- ingredients: chicken as food, bread crumbs, egg as food, Allium, liver

## DISH Q131730836
- name: Львівський струдель
- other names: {"uk": "Львівський струдель"}
- countries: AT, HU
- cuisines: Austrian cuisine, Ukrainian cuisine
- kinds: food

## DISH Q131730920
- name: Язма
- other names: {"uk": "Язма"}
- countries: UA
- cuisines: Ukrainian cuisine, Crimean Tatar cuisine
- kinds: food
- ingredients: garlic, herb, kefir, Cucumis sativus, table salt

## DISH Q131735749
- name: Wheel Pie
- other names: {"zh": "紅豆餅"}
- description: Taiwanese pastry dessert
- countries: TW
- kinds: cake
- has Wikipedia article: en, zh

## DISH Q131736473
- name: Potato curls
- description: potato roll with various fillings
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: food, main course, potato dish
- ingredients: chicken egg, stuffing, potato

## DISH Q131737404
- name: Boerenkoolsoep
- other names: {"nl": "boerenkoolsoep"}
- countries: (none)
- kinds: soup
- ingredients: kale

## DISH Q131737431
- name: Scraps
- description: deep-fried batter often served with fish and chips
- countries: (none)
- kinds: dish
- ingredients: onion, viandel, mayonnaise, fries, carbonade flamande
- has Wikipedia article: en

## DISH Q131743103
- name: Plankstek
- other names: {"sv": "plankstek"}
- countries: (none)
- kinds: dish
- ingredients: meat

## DISH Q131747037
- name: Калатуша
- other names: {"uk": "Калатуша"}
- countries: UA
- cuisines: Ukrainian cuisine, Polesian cuisine
- kinds: course, soup
- ingredients: Daucus carota subsp. sativus, fish as food, herb, sunflower oil, tomato, onion, fungi

## DISH Q131749283
- name: Japonés (bollo)
- other names: {"es": "Japonés (bollo)"}
- countries: (none)
- kinds: confectionery
- ingredients: bun, grated coconut

## DISH Q131749285
- name: Бандуряники
- other names: {"uk": "Бандуряники"}
- countries: UA
- cuisines: Ukrainian cuisine, Lemko cuisine
- kinds: dish, potato dish
- ingredients: potato, smetana, egg as food, mushroom, onion

## DISH Q131749425
- name: 仿糕点奶油
- countries: (none)
- kinds: custard
- ingredients: corn starch, sugar, water

## DISH Q131749772
- name: Roomys
- other names: {"af": "roomys"}
- countries: (none)
- kinds: ice cream, human food
- ingredients: cream

## DISH Q13175502
- name: Avanît
- description: Kurdish food
- countries: (none)
- kinds: dish

## DISH Q1317552
- name: Orzo
- other names: {"zh": "米粒麵"}
- description: form of short-cut pasta which is shaped like a large grain of rice
- countries: IT
- kinds: type of pasta, pasta, şehriye
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q13175725
- name: Hesîde
- description: Kurdish dessert
- countries: (none)
- kinds: dessert

## DISH Q13175843
- name: Mertoxe
- description: Kurdish dish
- countries: (none)
- kinds: dish
- ingredients: kaymak, lard, flour

## DISH Q131758761
- name: Лежни картофельные
- other names: {"ru": "Лежни картофельные"}
- countries: (none)
- kinds: dish

## DISH Q13175914
- name: Panîrok
- description: food product
- countries: (none)
- kinds: food product

## DISH Q13175918
- name: Parêv
- description: Kurdish rice dish
- countries: (none)
- kinds: dish
- ingredients: rice

## DISH Q1317601
- name: Sata andagi
- other names: {"zh": "沙翁"}
- description: doughnut-like Okinawan dessert made from deep fried dough
- countries: JP
- kinds: fried dough, deep-fried confection
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q13176318
- name: Xîlok
- description: Kurdish dessert
- countries: (none)
- kinds: dessert
- ingredients: walnut, egg as food, cinnamon

## DISH Q13176778
- name: Şirdan
- description: Kurdish dish
- countries: (none)
- kinds: dish
- ingredients: minced meat, onion

## DISH Q1317802
- name: Gâche vendéenne
- description: French sweet bread
- countries: FR
- kinds: viennoiserie

## DISH Q13178400
- name: קוקייה
- other names: {"he": "קוקייה"}
- countries: (none)
- kinds: bread

## DISH Q1317898
- name: Ischoklad
- description: chocolate and coconut oil candy
- countries: DE
- kinds: confectionery
- ingredients: coconut oil, chocolate
- has Wikipedia article: en

## DISH Q1317958
- name: Pici
- description: a thick, hand-rolled pasta
- countries: IT
- kinds: type of pasta, pasta
- ingredients: flour
- has Wikipedia article: en

## DISH Q131819894
- name: Strawberry pasta
- description: Polish dessert
- countries: PL
- kinds: dessert
- ingredients: cream, sugar, Fragaria, pasta
- has Wikipedia article: en

## DISH Q131820017
- name: Борщ по-слобожанськи
- other names: {"uk": "Борщ по-слобожанськи"}
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: food, soup

## DISH Q131820065
- name: Kyiv Borscht
- description: Ukrainian cuisine
- countries: UA
- kinds: borscht

## DISH Q131824873
- name: Gilun
- description: stuffed dumplings of unleavened dough
- countries: UA
- kinds: type of pasta, stuffed pasta

## DISH Q131830407
- name: Zasypana kapusta
- description: cabbage and millet dish from Ukraine
- countries: (none)
- kinds: dish
- ingredients: millet, sunflower oil, spice, Brassica oleracea var. capitata, onion, egg, carrot

## DISH Q131834327
- name: Kuhwet
- description: fruit dish with the consistency of a thick gel
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: dish

## DISH Q131839491
- name: Кропивна помазка
- other names: {"uk": "Кропивна помазка"}
- countries: (none)
- kinds: dish, food
- ingredients: Urtica, egg as food, spice, butter, onion, milk

## DISH Q131839567
- name: Полтавські галушки
- other names: {"uk": "Полтавські галушки"}
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: food, dish
- ingredients: stuffing, dough

## DISH Q131839602
- name: Сичики (страва)
- other names: {"uk": "Сичики (страва)"}
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: food, dish
- ingredients: salo, Phaseolus, onion

## DISH Q131852182
- name: Zlijevka
- description: traditional Croatian dessert
- countries: HR, SI
- kinds: dessert, dish
- has Wikipedia article: en

## DISH Q13186
- name: Raisin
- other names: {"zh": "葡萄乾"}
- description: dried grape
- countries: CN, IR
- kinds: food ingredient, dried fruit
- ingredients: grape
- has Wikipedia article: en, zh

## DISH Q1318753
- name: Bubblegum
- other names: {"zh": "泡泡糖"}
- description: type of chewing gum
- countries: US
- kinds: chewing gum
- has Wikipedia article: en, zh

## DISH Q131902002
- name: 高浜とりめし
- other names: {"ja": "高浜とりめし"}
- countries: JP
- kinds: Japanese rice dish

## DISH Q131902005
- name: 熊谷ホルどん
- other names: {"ja": "熊谷ホルどん"}
- countries: JP
- kinds: yaki udon

## DISH Q131902007
- name: とん漬け
- other names: {"ja": "とん漬け"}
- countries: JP
- kinds: misozuke, pork dish

## DISH Q131902010
- name: チキンチキンごぼう
- other names: {"ja": "チキンチキンごぼう"}
- countries: JP
- kinds: chicken dish

## DISH Q131902012
- name: ちしゃなます
- other names: {"ja": "ちしゃなます"}
- countries: JP
- kinds: salad

## DISH Q131902015
- name: わかめむすび
- other names: {"ja": "わかめむすび"}
- description: type of onigiri
- countries: JP
- kinds: onigiri

## DISH Q131902016
- name: つしま
- other names: {"ja": "つしま"}
- countries: JP
- kinds: vegetable dish

## DISH Q131902017
- name: Kashamochi
- description: Japanese confectionery
- countries: JP
- kinds: yomogi mochi
- has Wikipedia article: en

## DISH Q131902018
- name: にいもじ
- other names: {"ja": "にいもじ"}
- countries: JP
- kinds: nimono

## DISH Q131902019
- name: ごさい漬け
- other names: {"ja": "ごさい漬け"}
- countries: JP
- kinds: tsukemono, seafood dish

## DISH Q131902021
- name: ぼうしパン
- other names: {"ja": "ぼうしパン"}
- countries: JP
- kinds: bread

## DISH Q131902022
- name: さよりめし
- other names: {"ja": "さよりめし"}
- countries: JP
- kinds: Japanese rice dish, seafood dish

## DISH Q131902023
- name: てんもんどう
- other names: {"ja": "てんもんどう"}
- countries: JP
- kinds: vegetable dish

## DISH Q131902024
- name: ばらっぱまんじゅう
- other names: {"ja": "ばらっぱまんじゅう"}
- countries: JP
- kinds: manjū

## DISH Q131902025
- name: ゆきのつゆ
- other names: {"ja": "ゆきのつゆ"}
- countries: JP
- kinds: mochi

## DISH Q131902026
- name: こっぱもち
- other names: {"ja": "こっぱもち"}
- countries: JP
- kinds: dish

## DISH Q131902027
- name: どんこ汁
- other names: {"ja": "どんこ汁"}
- countries: JP
- kinds: shirumono, seafood dish
- ingredients: Moridae

## DISH Q131902028
- name: あめのいおご飯
- other names: {"ja": "あめのいおご飯"}
- countries: JP
- kinds: Japanese rice dish
- ingredients: Biwa trout

## DISH Q131902032
- name: 煮たくもじ
- other names: {"ja": "煮たくもじ"}
- countries: JP
- kinds: nimono

## DISH Q131902035
- name: つぎ汁
- other names: {"ja": "つぎ汁"}
- countries: JP
- kinds: suimono

## DISH Q131902037
- name: もろこずし
- other names: {"ja": "もろこずし"}
- countries: JP
- kinds: oshizushi

## DISH Q131902039
- name: へぼ飯
- other names: {"ja": "へぼ飯"}
- countries: JP
- kinds: Japanese rice dish, insect as food
- ingredients: hachinoko

## DISH Q1319028
- name: Luzerner Chügelipastete
- description: meat dish from Lucerne, Switzerland
- countries: CH
- kinds: vol-au-vent, meat dish

## DISH Q131903294
- name: さつますもじ
- other names: {"ja": "さつますもじ"}
- countries: JP
- kinds: chirashizushi

## DISH Q131903295
- name: 紫錦梅
- other names: {"ja": "紫錦梅"}
- countries: JP
- kinds: dish
- ingredients: Prunus mume

## DISH Q131903296
- name: ぶたあえ
- other names: {"ja": "ぶたあえ"}
- countries: JP
- kinds: dish

## DISH Q131903298
- name: つぼん汁
- other names: {"ja": "つぼん汁"}
- countries: JP
- kinds: shirumono

## DISH Q131903300
- name: 煮ごみ
- other names: {"ja": "煮ごみ"}
- countries: JP
- kinds: nimono

## DISH Q131903301
- name: にごみ
- other names: {"ja": "にごみ"}
- countries: JP
- kinds: nimono

## DISH Q131903302
- name: ひきとおし
- other names: {"ja": "ひきとおし"}
- countries: JP
- kinds: nabemono

## DISH Q131903303
- name: みとり饅頭
- other names: {"ja": "みとり饅頭"}
- countries: JP
- kinds: manjū

## DISH Q131903305
- name: 鮎雑炊
- other names: {"ja": "鮎雑炊"}
- countries: JP
- kinds: Zosui
- ingredients: Plecoglossus altivelis

## DISH Q131903308
- name: 大平
- other names: {"ja": "大平"}
- countries: JP
- kinds: nimono

## DISH Q131903309
- name: 泥亀汁
- other names: {"ja": "泥亀汁"}
- countries: JP
- kinds: miso soup

## DISH Q131903448
- name: ふうかし
- other names: {"ja": "ふうかし"}
- countries: JP
- kinds: miso soup
- ingredients: Venerupis philippinarum

## DISH Q131903449
- name: ほや雑煮
- other names: {"ja": "ほや雑煮"}
- countries: JP
- kinds: zōni

## DISH Q131903450
- name: おしゃかこごり
- other names: {"ja": "おしゃかこごり"}
- countries: JP
- kinds: nigori
- ingredients: soybean

## DISH Q131903451
- name: うらじろまんじゅう
- other names: {"ja": "うらじろまんじゅう"}
- countries: JP
- kinds: manjū

## DISH Q131903452
- name: パイタ焼き
- other names: {"ja": "パイタ焼き"}
- countries: JP
- kinds: seafood dish

## DISH Q131903453
- name: べか鍋
- other names: {"ja": "べか鍋"}
- countries: JP
- kinds: nabemono

## DISH Q131903456
- name: てんころ料理
- other names: {"ja": "てんころ料理"}
- countries: JP
- kinds: potato dish

## DISH Q131907518
- name: Lent holubtsi with potatoes
- countries: (none)
- cuisines: Lemko cuisine
- kinds: course
- ingredients: potato, tomato paste, spice, Brassica oleracea var. capitata, onion, fungi

## DISH Q131912238
- name: チラガー
- other names: {"ja": "チラガー"}
- countries: JP
- kinds: pork dish

## DISH Q131912240
- name: 酢ずき
- other names: {"ja": "酢ずき"}
- countries: JP
- kinds: tsukemono, vegetable dish

## DISH Q131912242
- name: すったて汁
- other names: {"ja": "すったて汁"}
- countries: JP
- kinds: shirumono

## DISH Q131912243
- name: どんどろけ飯
- other names: {"ja": "どんどろけ飯"}
- countries: JP
- kinds: takikomi gohan

## DISH Q131912246
- name: とびつき団子
- other names: {"ja": "とびつき団子"}
- countries: JP
- kinds: dango

## DISH Q131912247
- name: エタリの塩辛
- other names: {"ja": "エタリの塩辛"}
- countries: JP
- kinds: shiokara
- ingredients: Engraulis japonicus

## DISH Q131912248
- name: はまなみそ
- other names: {"ja": "はまなみそ"}
- countries: JP
- kinds: miso

## DISH Q131912249
- name: 鶏雑炊
- other names: {"ja": "鶏雑炊"}
- countries: JP
- kinds: Zosui

## DISH Q131912250
- name: 鉄砲巻き
- other names: {"ja": "鉄砲巻き"}
- countries: JP
- kinds: makizushi

## DISH Q131917549
- name: Acwica
- description: Traditional vegetable in Northern Uganda
- countries: (none)
- kinds: vegetable dish

## DISH Q131919776
- name: Pizza in Brazil
- countries: (none)
- has Wikipedia article: en

## DISH Q131927111
- name: Sate klopo
- countries: ID
- kinds: dish, satay

## DISH Q131935021
- name: Ice cream flavor
- description: type of ice cream by added flavor ingredients
- countries: (none)
- kinds: ice cream

## DISH Q131940119
- name: 大沼だんご
- other names: {"ja": "大沼だんご"}
- countries: JP
- kinds: dango

## DISH Q131940120
- name: カネ餅
- other names: {"ja": "カネ餅"}
- countries: JP
- kinds: mochi

## DISH Q131940122
- name: 北上コロッケ
- other names: {"ja": "北上コロッケ"}
- countries: JP
- kinds: korokke

## DISH Q131940125
- name: あんびん
- other names: {"ja": "あんびん"}
- countries: JP
- kinds: dish

## DISH Q131940126
- name: ヤンゴメ
- other names: {"ja": "ヤンゴメ"}
- countries: JP
- kinds: Japanese rice dish
- ingredients: Vigna angularis, sugar, rice

## DISH Q131940127
- name: さつま雑煮
- other names: {"ja": "さつま雑煮"}
- countries: JP
- kinds: zōni

## DISH Q131940128
- name: 骨かじり
- other names: {"ja": "骨かじり"}
- countries: JP
- kinds: meat dish

## DISH Q131940129
- name: 堅豆腐
- other names: {"ja": "堅豆腐"}
- countries: JP
- kinds: tofu

## DISH Q131940130
- name: つと豆腐
- other names: {"ja": "つと豆腐"}
- countries: JP
- kinds: tofu

## DISH Q13195328
- name: Abbunata
- description: Italian food
- countries: IT
- cuisines: Italian cuisine
- kinds: human food
- ingredients: olive

## DISH Q13195586
- name: Bullitu
- description: Dish
- countries: IT
- cuisines: Italian cuisine
- kinds: dish

## DISH Q1319591
- name: Ice cream bar
- description: frozen dessert on a stick
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q13196928
- name: Mustazzola
- description: Sicilian cookie
- countries: IT
- kinds: cookie

## DISH Q13196930
- name: Mustata
- other names: {"scn": "Mustata"}
- countries: IT
- cuisines: Italian cuisine
- kinds: dish
- ingredients: almond

## DISH Q13197173
- name: Pastetta
- description: semi-liquid dough made from water, flour and other ingredients
- countries: IT
- cuisines: Italian cuisine
- kinds: food paste, dough
- ingredients: flour, water

## DISH Q13197224
- name: Pipareddi
- description: Sicilian cookies with almonds
- countries: IT
- cuisines: Italian cuisine
- kinds: baked good, cookie

## DISH Q13197885
- name: Spillonga
- description: Grape-based puree dish
- countries: IT
- cuisines: Italian cuisine
- kinds: dish, purée
- ingredients: grape

## DISH Q13198144
- name: Tunnina
- description: Sicilian dish
- countries: IT
- cuisines: Italian cuisine
- kinds: dish
- ingredients: Thunnini

## DISH Q13198152
- name: Tàfara
- description: plat de Vulanza
- countries: IT
- cuisines: Italian cuisine
- kinds: dish

## DISH Q131989100
- name: Queso Yamandú
- other names: {"es": "queso Yamandú"}
- countries: UY
- kinds: cheese, Gouda

## DISH Q13199157
- name: Dodol garut
- description: Sundanese confectionery from Garut, Indonesia
- countries: (none)
- kinds: food, traditional food, Dodol

## DISH Q13199292
- name: Géco
- description: Type of fermented bean paste
- countries: (none)
- kinds: food, Tauco

## DISH Q13199854
- name: Misro
- other names: {"id": "misro"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, fritter
- ingredients: cassava root, palm sugar

## DISH Q13202244
- name: Шакароб
- other names: {"tg": "шакароб"}
- countries: TJ
- kinds: food

## DISH Q13202368
- name: Qurutob
- description: dish of Tajik cuisine
- countries: TJ
- cuisines: Tajik cuisine
- kinds: dish
- ingredients: kurt
- has Wikipedia article: en

## DISH Q13205253
- name: Кош-теле
- other names: {"ru": "Кош-теле"}
- countries: (none)
- kinds: confectionery

## DISH Q1320701
- name: Ga'at
- description: porridge-like dish originated from Ethiopia and Eritrea
- countries: ET
- cuisines: Ethiopian cuisine, Eritrean cuisine
- kinds: porridge
- ingredients: barley
- has Wikipedia article: en

## DISH Q13212199
- name: Vezzena
- description: Italian cheese
- countries: IT
- kinds: cheese
- has Wikipedia article: en

## DISH Q13212234
- name: Kodinzòn
- description: apple sweet
- countries: IT
- cuisines: Italian cuisine
- kinds: sweetmeat
- ingredients: apple

## DISH Q13212340
- name: Rufioi
- description: Friuli dish
- countries: IT
- kinds: sweet dish, dish
- ingredients: cocoa powder, egg as food, flour, sugar

## DISH Q13212358
- name: Sbatudin
- description: Dessert made of sugar and eggs
- countries: IT
- kinds: dessert
- ingredients: cow's milk, egg as food, sugar, coffee

## DISH Q13212588
- name: Bounante
- description: Type of waffle
- countries: BE
- kinds: waffle, pastry

## DISH Q132126116
- name: ほやたまご
- other names: {"ja": "ほやたまご"}
- countries: JP
- kinds: dish
- ingredients: Ascidiacea

## DISH Q132126118
- name: おつぼ
- other names: {"ja": "おつぼ"}
- countries: JP
- kinds: dish

## DISH Q132126120
- name: おつぼ
- other names: {"ja": "おつぼ"}
- countries: JP
- kinds: nimono

## DISH Q132126121
- name: しぎ焼き
- other names: {"ja": "しぎ焼き"}
- countries: JP
- kinds: eggplant dish

## DISH Q132126122
- name: 初夢漬
- other names: {"ja": "初夢漬"}
- countries: JP
- kinds: wagashi

## DISH Q132126123
- name: ヒカド
- other names: {"ja": "ヒカド"}
- countries: JP
- kinds: nimono

## DISH Q132126124
- name: 大丸 (食品)
- other names: {"ja": "大丸 (食品)"}
- countries: JP
- kinds: kamaboko

## DISH Q132129903
- name: Uchucuta
- other names: {"es": "Uchucuta"}
- countries: PE
- kinds: sauce
- ingredients: Capsicum pubescens

## DISH Q132132567
- name: Maskurolhi
- countries: MV
- kinds: chutney, dish
- ingredients: coconut, Thunnus, chili pepper, Allium, black pepper, lime, table salt
- has Wikipedia article: en

## DISH Q132151523
- name: Cûtès Peûres
- other names: {"fr": "Cûtès Peûres"}
- description: cooking recipe for a pear-based dessert
- countries: (none)
- kinds: dessert, recipe
- ingredients: pear

## DISH Q132152948
- name: Baso aci
- description: soupy and spicy flour balls
- countries: ID
- kinds: food, human food, minced food ball
- ingredients: wheat, chili powder, tapioca, broth, flour, Welsh onion, table salt

## DISH Q132156532
- name: Ärter med fläsk
- description: Swedish pea soup dish with pork
- countries: DK, FI, NO, SE
- cuisines: Swedish cuisine
- kinds: soup, dish
- ingredients: pea soup, pork

## DISH Q132157934
- name: Ji Pai
- description: Taiwanese Fried Chicken Cutlet
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: street food, type of food or dish
- ingredients: chicken as food

## DISH Q13216848
- name: Rouyot
- description: type of baked goods
- countries: (none)
- kinds: cake, pastry, baked good

## DISH Q132172068
- name: Matambre arrollado
- countries: AR
- kinds: dish

## DISH Q132175543
- name: Dek Akeo
- description: Traditional vegetable meal in Northern Uganda prepared by boiling it in hot water mixed with groundnut paste
- countries: (none)
- kinds: vegetable dish
- has Wikipedia article: en

## DISH Q132176478
- name: Kourdass
- description: dried up, salted and seasoned sheep innards
- countries: DZ, MA
- cuisines: Moroccan cuisine, Algerian cuisine
- kinds: food, offal, salt-cured meat, dried meat
- has Wikipedia article: en

## DISH Q132178948
- name: Dek Boo
- description: Traditional vegetable meal in Northern Uganda
- countries: UG
- cuisines: Ugandan cuisine
- kinds: vegetable dish

## DISH Q132180497
- name: トンネル餅
- other names: {"ja": "トンネル餅"}
- countries: JP
- kinds: suama

## DISH Q132180498
- name: かましいりこ
- other names: {"ja": "かましいりこ"}
- countries: JP
- kinds: dish
- ingredients: Eleusine coracana

## DISH Q132188097
- name: Nyoyo
- description: Ugandan Traditional Meal
- countries: (none)
- cuisines: traditional food
- kinds: human food
- ingredients: maize

## DISH Q132190451
- name: Diavola pizza
- description: pizza variety, usually topped with spicy salami, tomato sauce, mozzarella cheese, chili pepper and olives
- countries: IT
- kinds: dish, type of pizza
- ingredients: tomato sauce, chili oil, salami, Ocimum, spice, mozzarella

## DISH Q132192780
- name: Rosquillas ciegas
- other names: {"es": "Rosquillas ciegas"}
- countries: (none)
- kinds: rosquilla
- ingredients: anise drink, aguardiente, meringue, egg as food, olive oil, wine

## DISH Q132197144
- name: Tankiri-ame, Toyohashi Oni Festival
- countries: (none)
- kinds: lucky symbol, ame

## DISH Q132200539
- name: Chällerhocker
- description: Swiss medium-hard Alpine cheese
- countries: CH
- kinds: raw-milk cheese, cow's-milk cheese, Swiss-type cheeses
- has Wikipedia article: en

## DISH Q132203185
- name: Pan con pejerrey
- other names: {"es": "pan con pejerrey"}
- countries: PE
- kinds: sandwich
- ingredients: salsa criolla, bread

## DISH Q1322549
- name: Butter chicken
- other names: {"zh": "奶油咖哩雞"}
- description: Indian curry dish
- countries: IN
- cuisines: Indian cuisine
- kinds: food, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q132300835
- name: Mu daeng
- countries: TH
- kinds: pork dish

## DISH Q1323044
- name: Rumbledethumps
- description: potato dish
- countries: GB
- cuisines: Scottish cuisine
- kinds: potato dish
- ingredients: cabbage, onion, potato
- has Wikipedia article: en

## DISH Q13231338
- name: Czech-style hot dog
- other names: {"zh": "捷克熱狗"}
- description: fast food dish
- countries: CZ
- kinds: hot dog, dish
- ingredients: kifli, Vienna sausage, ketchup, mustard
- has Wikipedia article: en

## DISH Q13233
- name: Ice cream
- other names: {"zh": "冰淇淋"}
- description: frozen dessert made from frozen milk or cream, sugar, and a flavour
- countries: (none)
- kinds: soft cow dairy product, frozen dessert, dessert with spoon
- ingredients: flavoring, cream, sugar, milk
- has Wikipedia article: en, zh

## DISH Q132348637
- name: Haarlmmer Halletjes
- other names: {"nl": "Haarlmmer Halletjes"}
- countries: (none)
- kinds: cookie

## DISH Q1324118
- name: Nước chấm
- other names: {"zh": "水蘸汁"}
- description: common name for a variety of Vietnamese dipping sauces
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: condiment, sauce, Vietnamese cuisine
- has Wikipedia article: en, zh

## DISH Q132459085
- name: Biékosseu
- other names: {"fr": "Biékosseu"}
- countries: CI
- kinds: hot sauce, sauce
- ingredients: tomato, eggplant, onion, chili pepper

## DISH Q132463338
- name: مدكوكة التمر
- other names: {"ar": "مدكوكة التمر"}
- countries: (none)
- kinds: dish
- ingredients: coconut, Sesamum indicum, date, animal fats and oils, walnut, almond

## DISH Q132494780
- name: Toasted marshmallow
- description: a marshmallow that is toasted
- countries: (none)
- kinds: confectionery
- ingredients: marshmallow

## DISH Q132527561
- name: Ganzuki
- description: local cuisine of Miyagi and Iwate Prefectures, Japan
- countries: JP
- kinds: steamed bread

## DISH Q132543024
- name: Hubník
- other names: {"cs": "Hubník"}
- countries: (none)
- kinds: dish
- ingredients: semolina, egg as food, bread roll, fungi

## DISH Q132544616
- name: Dulcia domestica
- description: Roman dessert of stuffed dates
- countries: (none)
- kinds: dessert

## DISH Q13266
- name: Cookie
- other names: {"zh": "曲奇"}
- description: baked treat
- countries: GB
- kinds: dessert, pastry, dish, snack, bánh, confectionery, shelf-stable food, cookies, biscuits, crackers
- ingredients: oats, chicken egg, flour, table salt, sugar, water
- has Wikipedia article: en, zh
