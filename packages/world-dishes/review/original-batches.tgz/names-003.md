# Review batch names-003

## DISH Q105882730
- name: Dheros er kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish

## DISH Q105882732
- name: Dal moshla kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish

## DISH Q105882734
- name: Begun methi kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish

## DISH Q105882735
- name: Lau beson kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish
- ingredients: besan

## DISH Q105882736
- name: Biuli dal methi kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish

## DISH Q105882738
- name: Doi chhatu kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish

## DISH Q105882739
- name: Bandhakopir moshla kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, cabbage dish

## DISH Q105882740
- name: Enchor doi kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish

## DISH Q105882741
- name: Alu uchchher kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, potato dish
- ingredients: potato

## DISH Q105882744
- name: Amchur korola dolma
- description: Bengali cuisine
- countries: (none)
- kinds: dolma, vegetable dish

## DISH Q105882745
- name: Chhana potol dolma
- description: Bengali cuisine
- countries: (none)
- kinds: dolma, vegetable dish

## DISH Q105882746
- name: Kachkola chal guror dolma
- description: Bengali cuisine
- countries: (none)
- kinds: dolma, vegetable dish

## DISH Q105882747
- name: Chhatu beguner dolma
- description: Bengali cuisine
- countries: (none)
- kinds: dolma, vegetable dish

## DISH Q105882748
- name: Doi kochur dolma
- description: Bengali cuisine
- countries: (none)
- kinds: dolma, vegetable dish

## DISH Q105882750
- name: Kankroler narkel korma
- description: Bengali cuisine
- countries: (none)
- kinds: korma, vegetable dish

## DISH Q105882752
- name: Posto deoa potoler paturi
- description: Bengali cuisine
- countries: (none)
- kinds: paturi

## DISH Q105882753
- name: Sorse deoa mochar paturi
- description: Bengali cuisine
- countries: (none)
- kinds: paturi

## DISH Q105882754
- name: Paneer paturi
- description: Bengali cuisine
- countries: (none)
- kinds: paturi

## DISH Q105882755
- name: Posto paturi
- description: bengali cuisine
- countries: (none)
- kinds: paturi

## DISH Q105882756
- name: Kankurer dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna, vegetable dish

## DISH Q105882758
- name: Lau diye koraisuntir dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna, vegetable dish

## DISH Q105882759
- name: Narkel diye kochu dantar ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q105882763
- name: Doi diye kumror ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q105882764
- name: Polta chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q105882765
- name: Gima shaker chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q105882766
- name: Lau shak chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q105882768
- name: Lebu polao
- description: Bengali cuisine
- countries: (none)
- kinds: pilaf, vegetable dish

## DISH Q105882774
- name: Bhaja muger dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q105882776
- name: Narkel diye chholar dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q105882778
- name: Biulir dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q105882782
- name: Musur dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q105884547
- name: Garbanzo de Escacena
- countries: ES
- kinds: food

## DISH Q105890425
- name: Crust
- countries: (none)
- kinds: flatbread, layer

## DISH Q10589180
- name: Mormors ringar
- other names: {"sv": "Mormors ringar"}
- countries: (none)
- kinds: biscuit

## DISH Q10589496
- name: Mosbricka
- other names: {"sv": "Mosbricka"}
- countries: (none)
- kinds: fast food

## DISH Q105913495
- name: Ilish jeere bhapa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhapa
- ingredients: Mustardseed Oil, cumin seed, turmeric, Tenualosa ilisha, chili pepper, table salt

## DISH Q10591747
- name: Mylta
- description: Dessert from cloudberry
- countries: SE
- kinds: dessert

## DISH Q105926041
- name: Basa
- description: type of cheese
- countries: BA, HR
- kinds: cheese
- has Wikipedia article: en

## DISH Q1059273
- name: Chakalaka
- other names: {"zh": "恰卡拉卡"}
- description: South African vegetable relish
- countries: ZA
- cuisines: African cuisine
- kinds: dish, side dish
- ingredients: tomato, onion, bean, vegetable
- has Wikipedia article: en, zh

## DISH Q10594193
- name: Nalle Puh-kex
- other names: {"sv": "Nalle Puh-kex"}
- countries: (none)
- kinds: biscuit

## DISH Q10594968
- name: Naturgodis
- other names: {"sv": "Naturgodis"}
- countries: (none)
- kinds: candy

## DISH Q105955583
- name: Amrar dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q105957927
- name: Pi Day pie
- description: pie served to celebrate pi day
- countries: (none)
- kinds: pie

## DISH Q1059643
- name: Ricciarelli
- description: Italian almond biscuits
- countries: IT
- kinds: biscuit, almond biscuit
- has Wikipedia article: en

## DISH Q105968553
- name: Aliments marinés à l’huile d’olive
- countries: (none)
- kinds: dish

## DISH Q105971300
- name: Bata machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105972418
- name: Bata machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q10600727
- name: Nikkaluoktasoppa
- other names: {"sv": "Nikkaluoktasoppa"}
- countries: SE
- kinds: soup

## DISH Q10601545
- name: Nobisbröd
- other names: {"sv": "Nobisbröd"}
- countries: (none)
- kinds: bread

## DISH Q10601745
- name: Noisette
- description: meat dish
- countries: (none)
- kinds: dish, meat dish

## DISH Q106020965
- name: Agoulou
- other names: {"fr": "agoulou"}
- countries: FR
- kinds: sandwich, dish

## DISH Q1060331
- name: Pastille
- description: type of candy
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q10605566
- name: Nöt-Crème
- other names: {"sv": "Nöt-Crème"}
- countries: (none)
- kinds: candy

## DISH Q106080324
- name: Fish cutlet
- description: Bengali cuisine
- countries: (none)
- kinds: cutlet, fish dish

## DISH Q106080365
- name: Bıçaq Qiymə
- other names: {"az": "Bıçaq Qiymə"}
- countries: IR
- kinds: dish

## DISH Q106080413
- name: Rosbora
- description: Bengali cuisine
- countries: (none)
- kinds: dessert, confectionery

## DISH Q106086854
- name: Pastel
- description: Indonesian pastry
- countries: ID
- kinds: food, human food
- has Wikipedia article: en

## DISH Q106090116
- name: Russischer Salat
- other names: {"de": "Russischer Salat"}
- description: type of salad
- countries: (none)
- kinds: salad
- ingredients: mayonnaise, vegetable, meat

## DISH Q106091180
- name: Tom som
- description: Thai soup
- countries: TH
- kinds: dish, food
- has Wikipedia article: en

## DISH Q106106021
- name: Alur chokha kathi roll
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106106046
- name: Hing koraisuntir tikki
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106106198
- name: Mochar pulao
- description: bengali cuisine
- countries: (none)
- kinds: pilaf, rice dish, vegetable dish

## DISH Q106106214
- name: Basanti pulao
- description: Bengali cuisine
- countries: (none)
- kinds: chronic obstructive pulmonary disease, rice dish

## DISH Q106106229
- name: Katla kalia
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q106106236
- name: Doi katla
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106106241
- name: Sorse katla
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106106258
- name: Panchforon bati chingri
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106106275
- name: Kosha aar machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106106566
- name: Gobindo bhoger bhaat
- description: Bengali cuisine
- countries: (none)
- kinds: rice dish

## DISH Q106106598
- name: Katla machher korma
- description: Bengali cuisine
- countries: (none)
- kinds: korma, fish dish

## DISH Q106111046
- name: Bursa cantık pide
- description: Turkish içli pide variety
- countries: TR
- kinds: food, pide
- has Wikipedia article: en

## DISH Q106113671
- name: 川通り餅
- other names: {"ja": "川通り餅"}
- countries: (none)
- kinds: Miyagegashi, wagashi

## DISH Q106114625
- name: Japadog
- description: variety of hotdog topped with Japanese ingredients
- countries: CA
- kinds: dish, hot dog
- ingredients: hot dog bun, sausage

## DISH Q106115046
- name: Queperí
- other names: {"es": "queperí"}
- description: dish of Bolivian cuisine
- countries: BO
- cuisines: Bolivian cuisine
- kinds: dish

## DISH Q106115437
- name: Ranga
- description: Bolivian dish
- countries: BO
- kinds: dish

## DISH Q106115457
- name: Rostro asado
- other names: {"es": "rostro asado"}
- countries: (none)
- kinds: dish, meal

## DISH Q106115460
- name: Caldo de cardán
- other names: {"es": "caldo de cardán"}
- countries: (none)
- kinds: soup, meal
- ingredients: meat

## DISH Q106115529
- name: Timpu
- other names: {"es": "timpu"}
- countries: (none)
- kinds: soup, meal

## DISH Q106124978
- name: Kancha amer sorbot
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106125630
- name: Gondhoraj cha er sorbot
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106125652
- name: Lichu lonkar sorbot
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106125775
- name: Bhetki Paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q106125990
- name: Bhetki kalia
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q106125994
- name: Doi bhetki
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106128066
- name: Masala pomfrat
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106128070
- name: Sorse pomfrat
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106128071
- name: Chitol peti
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106128073
- name: Jhal koi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q106128094
- name: Pabda begun jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q1061508
- name: Spressa delle Giudicarie PDO
- other names: {"zh": "Spressa delle Giudicarie DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, pressed half-cooked cheese, Italian cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q10615144
- name: Pain riche
- other names: {"sv": "pain riche"}
- countries: (none)
- kinds: bread

## DISH Q10615174
- name: Pajalagröt
- other names: {"nl": "pajalagröt"}
- countries: (none)
- kinds: porridge

## DISH Q106151773
- name: Koraishuntir Kochuri
- description: Bengali cuisine
- countries: (none)
- kinds: Kachori, pea dish

## DISH Q106151803
- name: Mourala machher charchari
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q106151849
- name: Moong Monohar
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106151877
- name: Kochur loti diye chingri machh
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q106151894
- name: Dim vapa
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q106152148
- name: Potoler dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna, vegetable dish

## DISH Q106152240
- name: Doi rui
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106152358
- name: Ilish machh bhaja tel
- description: bengali cuisine
- countries: (none)
- kinds: ilish dish

## DISH Q106152410
- name: Machher dimer borar jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q106152507
- name: Pomfret machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q106152526
- name: Tangra machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q106152532
- name: Telapia machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q106152606
- name: Boyal Machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q106152618
- name: Chitol Machher Kalia
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q1061532
- name: Chanpurū
- other names: {"zh": "炒麵線"}
- description: Japanese dish
- countries: JP
- kinds: yasai itame, pork dish
- ingredients: shimadōfu, cooking oil, vegetable
- has Wikipedia article: en, zh

## DISH Q10615421
- name: Palle Kuling
- other names: {"sv": "Palle Kuling"}
- countries: (none)
- kinds: candy

## DISH Q10615624
- name: Paltbröd
- other names: {"zh": "血麵包"}
- description: Swedish blood flatbread
- countries: SE
- kinds: bread, tunnbröd
- ingredients: blood
- has Wikipedia article: en

## DISH Q1061604
- name: Chana masala
- description: chickpea dish from the Indian subcontinent
- countries: IN
- kinds: dish, salan
- ingredients: chickpea, masala, sauce
- has Wikipedia article: en

## DISH Q106167194
- name: Ube
- description: vegetable commonly used in Filipino Dessert
- countries: PH
- kinds: vegetable, dessert
- ingredients: Dioscorea alata

## DISH Q106176265
- name: Chicken reshmi kebab
- description: type of kebab
- countries: (none)
- kinds: kebab

## DISH Q106176366
- name: Chingri Bhapa
- description: bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q1061824
- name: Chazuke
- other names: {"zh": "茶渍饭"}
- description: Japanese dish
- countries: JP
- kinds: Japanese rice dish
- ingredients: cooked rice, green tea, nori, rice
- has Wikipedia article: en, zh

## DISH Q1061842
- name: Donburi
- other names: {"zh": "丼物"}
- description: Japanese meals based on a rice bowl
- countries: JP
- cuisines: Japanese cuisine
- kinds: type of food or dish, Japanese rice dish
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q1061856
- name: Shabu-shabu
- other names: {"zh": "涮涮锅"}
- description: Japanese dish
- countries: JP
- kinds: food, nabemono, pork dish, beef dish
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q106194785
- name: Chashushuli
- description: dish of Georgian cuisine
- countries: GE
- cuisines: Georgian cuisine
- kinds: dish, veal dish
- ingredients: veal, acıka, tomato, onion, Allium sativum
- has Wikipedia article: en

## DISH Q1062035
- name: Toma Piemontese PDO
- other names: {"zh": "Toma Piemontese DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, cow's-milk cheese, Italian cheese
- ingredients: cow's milk

## DISH Q10620392
- name: Parisare
- other names: {"sv": "Parisare"}
- countries: (none)
- kinds: dish

## DISH Q10620400
- name: Pariservåfflor
- other names: {"sv": "Pariservåfflor"}
- countries: (none)
- kinds: pastry

## DISH Q106211393
- name: Stone soup
- description: Portuguese soup style based on the European fairytale
- countries: PT
- kinds: soup

## DISH Q10621411
- name: Party
- other names: {"sv": "Party"}
- countries: (none)
- kinds: biscuit

## DISH Q1062144
- name: Namul
- description: Korean vegetable dishes
- countries: (none)
- kinds: vegetable dish
- has Wikipedia article: en

## DISH Q10624825
- name: Pescado a la Veracruzana
- other names: {"sv": "Pescado a la Veracruzana"}
- countries: MX
- kinds: dish

## DISH Q10624827
- name: Pescado a la talla
- countries: (none)
- kinds: fish dish

## DISH Q1062483
- name: Jjigae
- other names: {"zh": "韓式燉湯"}
- description: thick soups or stew in Korean cuisine
- countries: (none)
- kinds: food, stew
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q106252
- name: Marzipan
- other names: {"zh": "扁桃仁膏"}
- description: confection consisting primarily of sugar or honey and almond meal (ground almonds)
- countries: DE, ES, FR
- kinds: confectionery
- ingredients: almond meal, sugar
- has Wikipedia article: en, zh

## DISH Q1062531
- name: Boiled egg
- other names: {"zh": "水煮蛋"}
- description: egg dish
- countries: (none)
- kinds: food ingredient, food, dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q106271597
- name: 中式糕点
- countries: (none)
- kinds: pastry
- has Wikipedia article: zh

## DISH Q106293566
- name: Escarole soup
- description: Escarole-based soup boiled in an almond and garlic broth from Granada (Spain)
- countries: (none)
- kinds: soup

## DISH Q106299589
- name: Khaira machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q106307339
- name: Springfield-style cashew chicken
- other names: {"zh": "春田式腰果鸡"}
- countries: US
- kinds: cashew chicken
- has Wikipedia article: en

## DISH Q1063096
- name: Wagashi
- other names: {"zh": "和果子"}
- description: traditional Japanese confectionery
- countries: JP
- cuisines: Japanese cuisine
- kinds: confectionery
- has Wikipedia article: en, zh

## DISH Q10631613
- name: Piggelin
- description: ice pop with pear flavor
- countries: (none)
- kinds: ice pop

## DISH Q10631922
- name: Pingvinstång
- other names: {"sv": "Pingvinstång"}
- countries: (none)
- kinds: candy

## DISH Q10632498
- name: Pizza salad
- description: Swedish salad made of cabbage, vinegar and pepper, served with pizza
- countries: SE
- cuisines: Swedish cuisine
- kinds: salad

## DISH Q106326673
- name: Cascatelli
- description: short pasta with a flat strip and ruffles that stick out at a 90-degree angle
- countries: US
- kinds: type of pasta, pasta
- has Wikipedia article: en

## DISH Q106352242
- name: Zeytinli açma
- description: Turkish bread with black olive paste filing
- countries: TR
- kinds: bread, Açma
- ingredients: olive paste, wheat flour, salt, milk, water

## DISH Q106355895
- name: Franciasaláta
- description: dish
- countries: HU, RU
- kinds: dish, salad
- ingredients: hard-boiled egg, pickled cucumber, smetana, mayonnaise, mustard, Pisum sativum, potato, apple, carrot

## DISH Q1063560
- name: Chocolate truffle
- other names: {"zh": "松露巧克力"}
- description: type of chocolate confectionery, traditionally made with a chocolate ganache centre coated in chocolate
- countries: GB
- kinds: Belgian praline, confectionery
- ingredients: ganache
- has Wikipedia article: en, zh

## DISH Q10636000
- name: Polhemsbakelse
- other names: {"mul": "Polhemsbakelse"}
- countries: SE
- kinds: bakelse
- ingredients: water, Danish pastry dough, dewberry jam, bilberry, chicken egg, strawberry, wheat flour, edible fats and oils, whipped cream, custard, yeast, table salt

## DISH Q1063736
- name: Penne
- other names: {"zh": "直通粉"}
- description: type of pasta
- countries: IT
- kinds: type of pasta, pasta
- ingredients: flour, water
- has Wikipedia article: en, zh

## DISH Q10638015
- name: Porterstek
- other names: {"sv": "Porterstek"}
- countries: (none)
- kinds: meat dish

## DISH Q10638199
- name: Potatisplättar
- other names: {"sv": "Potatisplättar"}
- countries: (none)
- kinds: potato dish

## DISH Q10638608
- name: Pressylta
- other names: {"sv": "pressylta"}
- countries: (none)
- kinds: dish

## DISH Q106395495
- name: Aji fry
- description: Japanese dish of deep-fried horse mackerel
- countries: JP
- cuisines: yōshoku
- kinds: fish dish, Crumbed deep-fry
- ingredients: panko, Japanese horse mackerel

## DISH Q106406706
- name: Kloppschinken
- countries: DE
- kinds: meat dish

## DISH Q106407627
- name: Chhoto alur niramish dom
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106415576
- name: Topshe Fry
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q106415582
- name: Begun diye Khoyra machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q106441623
- name: Pan Galo Plaza
- countries: (none)
- kinds: dish

## DISH Q10646420
- name: Puck
- other names: {"sv": "Puck"}
- countries: (none)
- kinds: ice cream

## DISH Q10646811
- name: Punschpraliner
- other names: {"sv": "Punschpraliner"}
- countries: (none)
- kinds: praline

## DISH Q106468666
- name: Machher dimer bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada, fish dish

## DISH Q106468669
- name: Pat sak diye motor dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q106468698
- name: Shiuli patar bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q10647781
- name: Päronsplitt
- other names: {"sv": "Päronsplitt"}
- countries: (none)
- kinds: ice cream bar

## DISH Q10647924
- name: Påskduva
- other names: {"sv": "Påskduva"}
- description: Easter bread in the shape of a pigeon
- countries: (none)
- kinds: bread

## DISH Q106491332
- name: Картофельные котлеты
- other names: {"ru": "картофельные котлеты"}
- countries: (none)
- kinds: dish

## DISH Q106497753
- name: Sfela
- description: Greek cheese
- countries: GR
- kinds: Greek cheese
- ingredients: sheep milk, goat milk

## DISH Q1065033
- name: Prosciutto
- other names: {"zh": "意大利生火腿"}
- description: Italian dry-cured ham
- countries: IT
- kinds: salume, raw ham
- ingredients: Dalmatian ham, Istarski pršut, Njeguška pršuta, pork
- has Wikipedia article: en

## DISH Q10650346
- name: Refreshers
- other names: {"sv": "Refreshers"}
- countries: (none)
- kinds: candy

## DISH Q10650830
- name: Remi
- other names: {"sv": "Remi"}
- countries: (none)
- kinds: biscuit

## DISH Q106513375
- name: Palong shak er bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q106517231
- name: Дроб по селски
- other names: {"bg": "Дроб по селски"}
- countries: BG
- kinds: dish

## DISH Q106519594
- name: Denizli kebab
- countries: TR
- kinds: food

## DISH Q106527709
- name: Achterhoeks theebeschuit
- other names: {"nl": "Achterhoeks theebeschuit"}
- countries: (none)
- kinds: regional product, Beschuit

## DISH Q106537056
- name: Kavala Almond Cookies
- description: Turkish culinary dish
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q106542762
- name: Bolo luiz felipe
- other names: {"pt": "bolo luiz felipe"}
- countries: (none)
- kinds: cake

## DISH Q106542819
- name: Camafeu de nozes
- other names: {"pt": "camafeu de nozes"}
- countries: (none)
- kinds: confectionery

## DISH Q106543283
- name: Chegadinho
- other names: {"pt": "chegadinho"}
- countries: (none)
- kinds: dessert

## DISH Q106543285
- name: Chico balanceado
- other names: {"pt": "chico balanceado"}
- countries: (none)
- kinds: dessert

## DISH Q106543803
- name: Doce de banana
- other names: {"pt": "doce de banana"}
- countries: (none)
- kinds: dessert

## DISH Q106543804
- name: Doce de caju
- description: dessert from Brazil
- countries: (none)
- kinds: dessert
- ingredients: cashew apple, sugar

## DISH Q106543805
- name: Doce de cidra
- other names: {"pt": "doce de cidra"}
- countries: BR
- kinds: jam, dessert

## DISH Q106543806
- name: Doce de cupuaçu
- other names: {"pt": "doce de cupuaçu"}
- countries: (none)
- kinds: dessert

## DISH Q106543808
- name: Doce de melancia
- other names: {"pt": "doce de melancia"}
- countries: (none)
- kinds: dessert

## DISH Q106543809
- name: Doce de pequi
- other names: {"pt": "doce de pequi"}
- countries: (none)
- kinds: dessert

## DISH Q106546888
- name: Muxá
- other names: {"pt": "muxá"}
- countries: (none)
- kinds: dessert

## DISH Q106548178
- name: Tripa de Aveiro
- other names: {"pt": "Tripa de Aveiro"}
- countries: (none)
- kinds: pastry

## DISH Q10655402
- name: Rimbobullar
- other names: {"sv": "Rimbobullar"}
- countries: (none)
- kinds: pastry

## DISH Q106555015
- name: Bolo de batata-doce
- description: Traditional Brazilian cake made with mashed sweet potatoes, popular during June Festivals
- countries: (none)
- kinds: cake
- ingredients: coconut milk, egg as food, Sweet potato, sugar

## DISH Q106578055
- name: Ice Kenkey
- description: chilled dessert from Ghana
- countries: GH
- kinds: food, dessert
- ingredients: Kenkey, ice cube, peanut, sugar, milk, water
- has Wikipedia article: en

## DISH Q10658425
- name: Shrimp salad
- description: kind of seafood salad
- countries: (none)
- kinds: food, seafood salad
- ingredients: shrimp and prawn as food

## DISH Q106589918
- name: Jambon
- other names: {"zh": "愛爾蘭酥皮火腿"}
- description: pastry snack filled with ham and cheese
- countries: FR, IE
- kinds: pastry, pork dish
- ingredients: ham, egg as food, puff pastry, cheese
- has Wikipedia article: en, zh

## DISH Q10659007
- name: Røget ål med røræg
- description: smoked eel and egg dish
- countries: (none)
- kinds: meat dish
- ingredients: smoked eel, egg as food

## DISH Q10659108
- name: Rörost
- description: cheese dish
- countries: SE
- kinds: dish
- ingredients: cardamom, syrup, cinnamon

## DISH Q106592235
- name: Ilish machher matha diye lau ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto, ilish dish

## DISH Q106592249
- name: Pabda machchher jhal posto
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q1065990
- name: Lingonberry jam
- other names: {"zh": "越橘果醬"}
- description: traditional fruit preserve in Scandinavian cuisine
- countries: (none)
- kinds: fruit jam
- ingredients: lingonberry, sugar
- has Wikipedia article: en

## DISH Q10659975
- name: Saffron bread
- description: pastry containing saffron
- countries: (none)
- kinds: pastry
- ingredients: saffron

## DISH Q10659978
- name: Saffron pancake
- description: pudding dessert from the island of Gotland, Sweden
- countries: SE
- kinds: dish, dessert
- ingredients: porridge rice, chicken egg, cow's milk, almond, saffron, cream, sugar
- has Wikipedia article: en

## DISH Q106601417
- name: Bredasalat
- other names: {"de": "Bredasalat"}
- countries: (none)
- kinds: salad

## DISH Q106611399
- name: Kajli Machher Jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q106611530
- name: Panthar mangser patla jhol
- description: Bengali cuisine
- countries: (none)
- kinds: goat meat dish, Jhol

## DISH Q106611744
- name: Parshe machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q106612056
- name: Hansher Dimer Dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna, egg dish

## DISH Q106612160
- name: Chitol Machher Jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q106612227
- name: Trenza de Almudévar
- description: sweet braided pastry from Almudévar, Huesca, Spain
- countries: (none)
- kinds: Trenza, bun
- ingredients: walnut, almond, puff pastry, raisin

## DISH Q106616113
- name: Shuidouchi
- other names: {"zh": "水豆豉"}
- description: fermented soybean product
- countries: (none)
- kinds: fermented food, soy food
- ingredients: soy bean

## DISH Q10662375
- name: Scampi
- other names: {"zh": "斯堪比虾"}
- description: edible lobster of the order Decapoda
- countries: (none)
- kinds: shrimp dish, food, seafood dish
- has Wikipedia article: en

## DISH Q1066251
- name: Ice cream cake
- other names: {"zh": "冰淇淋蛋糕"}
- description: cake filled with ice cream
- countries: (none)
- kinds: cake, ice cream-based dessert
- ingredients: cake, ice cream
- has Wikipedia article: en, zh

## DISH Q1066260
- name: Tomato soup
- other names: {"zh": "番茄湯"}
- description: soup with tomato pulp as a main ingredient
- countries: (none)
- kinds: soup, vegetable soup, tomato dish
- ingredients: tomato
- has Wikipedia article: en, zh

## DISH Q10663096
- name: Checkerboard Cookies
- description: Swedish checkerboard cookies
- countries: (none)
- kinds: black-and-white cookies

## DISH Q106639651
- name: Kumro Patay Ilish bhapa
- description: Bengali cuisine
- countries: (none)
- kinds: ilish dish, Bhapa

## DISH Q106639871
- name: Phulkopi posto
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106639921
- name: Pui metuli chingri diye
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106640602
- name: Jhinge narkoler torkari
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106640606
- name: Jhinger khosa bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106640622
- name: Koi machher horogouri
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106640666
- name: Macaron de Cormery
- countries: FR
- kinds: macaron

## DISH Q106641402
- name: Musur dal kathal er bij diye
- description: bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q106647459
- name: Pona machher jhol
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q106647501
- name: Begun basanti
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106647513
- name: Chichingar ghanto
- description: bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q10665037
- name: Big rats
- description: Swedish rat shaped gummy candy
- countries: (none)
- kinds: gummy candy

## DISH Q106653772
- name: Balparmak tatlısı
- description: Turkish dessert
- countries: (none)
- kinds: food, dish
- has Wikipedia article: en

## DISH Q106670608
- name: Bánh mì thịt nguội
- countries: (none)
- kinds: bánh mì
- ingredients: pickled carrot, cilantro, nước mắm, head cheese, onion, cucumber, chả lụa, ham, margarine

## DISH Q106678690
- name: Paofan
- other names: {"zh": "泡饭"}
- description: teochew rice dish
- countries: (none)
- kinds: rice dish, dish
- has Wikipedia article: en, zh

## DISH Q106680422
- name: Currant bun
- description: European sweet bun; Dutch snack
- countries: (none)
- kinds: bread roll, sweet roll
- ingredients: currant, dough, raisin
- has Wikipedia article: en

## DISH Q10668299
- name: Singoalla
- other names: {"sv": "Singoalla"}
- countries: (none)
- kinds: biscuit

## DISH Q106691833
- name: Dopp i kopp
- other names: {"sv": "Dopp i kopp"}
- countries: (none)
- kinds: dish

## DISH Q10669467
- name: Sjömansbiff
- other names: {"sv": "sjömansbiff"}
- countries: SE, NO, DK
- cuisines: Swedish cuisine, Norwegian cuisine, Danish cuisine
- kinds: dish
- ingredients: potato, yellow onion, beef, beer

## DISH Q10669558
- name: Kalafile Walewska
- other names: {"fi": "Kalafile Walewska"}
- countries: (none)
- kinds: dish

## DISH Q10669607
- name: Skagenröra
- other names: {"zh": "瑞典鸡尾酒虾"}
- description: Swedish prawn cocktail
- countries: SE
- kinds: condiment, shrimp salad
- ingredients: dill, shrimp and prawn as food, mayonnaise

## DISH Q106702187
- name: Seto dyed rice
- countries: (none)
- kinds: okowa, dish
- ingredients: gardenia yellow, glutinous rice

## DISH Q10670720
- name: Foam candy
- countries: (none)
- kinds: candy
- ingredients: foam

## DISH Q106707227
- name: Pat shak er jhol
- description: Bengali cuisine
- countries: (none)
- kinds: Jhol

## DISH Q106709225
- name: Pondkoek
- countries: BE
- kinds: pastry, delicacy, confectionery, shelf-stable food
- ingredients: dough, spice

## DISH Q10671706
- name: Sluring
- other names: {"sv": "sluring"}
- countries: (none)
- kinds: dish, soup, pork dish

## DISH Q10672403
- name: Smolanedi
- other names: {"sv": "Smolanedi"}
- countries: (none)
- kinds: dish

## DISH Q10672575
- name: Smörgåsrån
- other names: {"sv": "Smörgåsrån"}
- countries: (none)
- kinds: biscuit

## DISH Q1067261
- name: Ras el hanout
- other names: {"zh": "北非综合香料"}
- description: food spice
- countries: (none)
- kinds: food ingredient, spice mix
- ingredients: anise seed, turmeric, mace, nutmeg, spice, cinnamon
- has Wikipedia article: en, zh

## DISH Q10672689
- name: Snitte
- other names: {"nn": "Snitte"}
- countries: (none)
- kinds: open sandwich

## DISH Q10672787
- name: Snöripa
- other names: {"sv": "snöripa"}
- countries: (none)
- kinds: dish

## DISH Q10673363
- name: Solskenskaka
- other names: {"sv": "Solskenskaka"}
- countries: (none)
- kinds: sponge cake

## DISH Q10674099
- name: Sotare
- other names: {"sv": "Sotare"}
- countries: (none)
- kinds: fish dish

## DISH Q1067542
- name: Toriten
- other names: {"zh": "鸡肉天妇罗"}
- description: Japanese food
- countries: JP
- kinds: tempura, fried chicken
- ingredients: shōyu, chicken egg, wheat flour, karashi, chicken as food, oil, vinegar, Brassica oleracea var. capitata, water
- has Wikipedia article: en, zh

## DISH Q10675660
- name: Spickeskinka
- other names: {"sv": "Spickeskinka"}
- countries: (none)
- kinds: ham

## DISH Q1067646
- name: Charolais
- description: French soft natural-rind goat cheese
- countries: FR
- kinds: French cheese, goat cheese, raw-milk cheese, farmstead cheese, industrial cheese, natural-rind soft cheese
- ingredients: goat milk, raw milk
- has Wikipedia article: en

## DISH Q106765034
- name: K'allu
- other names: {"es": "k'allu"}
- countries: (none)
- kinds: salad, meal

## DISH Q106766133
- name: Ttungkarong
- countries: KR
- kinds: macaron

## DISH Q106768821
- name: Green papaya salad
- other names: {"zh": "青木瓜沙拉"}
- description: Southeast Asian salad of Southeast Asia origin made from shredded unripe papaya
- countries: (none)
- kinds: fruit salad
- ingredients: salted crab, tamarind paste, garlic, nam pu, papaya, Padaek, shrimp paste, fish sauce, bird's eye chili
- has Wikipedia article: en, zh

## DISH Q106769958
- name: Mountain honey
- description: type of honey
- countries: (none)
- kinds: polyfloral honey

## DISH Q1067842
- name: Daifuku
- other names: {"zh": "大福"}
- description: Japanese confection
- countries: JP
- kinds: mochi, wagashi
- ingredients: red bean paste, glutinous rice
- has Wikipedia article: en, zh

## DISH Q106786339
- name: Wine cream
- countries: (none)
- kinds: dessert
- ingredients: whipped cream, egg yolk, wine

## DISH Q1067884
- name: Chartreuse
- description: French dish of vegetables or meat tightly wrapped in vegetable leaves and cooked in a mould
- countries: FR
- kinds: dish
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q106804810
- name: Mashanza
- description: cheese of DR Congo
- countries: CD
- kinds: cheese, culinary speciality, fromage frais
- ingredients: cow's milk

## DISH Q106807449
- name: Kaseita
- countries: (none)
- kinds: Nanbangashi, food

## DISH Q10681399
- name: Storstrut
- other names: {"sv": "Storstrut"}
- countries: (none)

## DISH Q1068180
- name: Chateaubriand steak
- other names: {"zh": "夏多布里昂牛排"}
- description: meat dish cooked with a thick cut from the tenderloin filet
- countries: (none)
- kinds: sauce, cut of beef, beef dish
- ingredients: beef tenderloin
- has Wikipedia article: en, zh

## DISH Q10682066
- name: Strutar
- other names: {"sv": "Strutar"}
- countries: (none)
- kinds: bread

## DISH Q10682288
- name: Stubbe
- other names: {"sv": "Stubbe"}
- countries: (none)
- kinds: pastry

## DISH Q10682359
- name: Studentska
- other names: {"sv": "studentska"}
- countries: (none)
- kinds: bakelse

## DISH Q106827037
- name: Thayacha
- countries: (none)
- kinds: ice cream, meal

## DISH Q10683206
- name: Succarie bread
- description: Rusk squares made of rye sourdough
- countries: (none)
- kinds: bread

## DISH Q1068339
- name: Chaudfroid sauce
- description: French culinary sauce
- countries: FR
- kinds: sauce
- has Wikipedia article: en

## DISH Q1068341
- name: Chaud-froid
- description: French meat dish
- countries: FR
- kinds: meat dish
- ingredients: chaudfroid sauce

## DISH Q106840433
- name: Katsuretsu
- description: Japanese Yōshoku cutlet
- countries: (none)
- cuisines: yōshoku
- kinds: cutlet

## DISH Q10684425
- name: Svarta Sara (ost)
- other names: {"sv": "Svarta Sara (ost)"}
- countries: DK
- kinds: cheese

## DISH Q10684495
- name: Svartgröt
- other names: {"sv": "Svartgröt"}
- countries: (none)
- kinds: porridge

## DISH Q106854834
- name: Spinach cake
- description: dessert dish
- countries: (none)
- kinds: food, cake
- ingredients: spinach
- has Wikipedia article: en

## DISH Q106862786
- name: Lobster tail pastry
- description: Italian filled pastry
- countries: IT
- kinds: pastry
- ingredients: choux pastry

## DISH Q106867728
- name: Apple tart
- description: pastry made with apples
- countries: (none)
- kinds: tart
- ingredients: apple

## DISH Q10686809
- name: Syltmunk
- other names: {"sv": "Syltmunk"}
- countries: (none)
- kinds: pastry

## DISH Q106869679
- name: Fruit Bat Soup
- description: dish of Palau
- countries: PW
- kinds: dish
- ingredients: coconut, Pteropodidae, onion

## DISH Q10687668
- name: Syrat bröd
- other names: {"sv": "Syrat bröd"}
- countries: (none)
- kinds: bread

## DISH Q1068892
- name: Cheesesteak
- other names: {"zh": "費城牛肉芝士三明治"}
- description: steak and cheese sandwich from Philadelphia
- countries: US
- cuisines: cuisine of the United States
- kinds: sandwich
- ingredients: hoagie roll, beefsteak, processed cheese
- has Wikipedia article: en, zh

## DISH Q106898676
- name: モーローチキンライス
- other names: {"ja": "モーローチキンライス"}
- countries: (none)
- kinds: rice dish, chicken dish

## DISH Q106906025
- name: Pitaya bread
- description: Vietnamese bread made from pitaya
- countries: VN
- kinds: bánh mì

## DISH Q1069097
- name: Chelow kabab
- other names: {"zh": "伊朗烤肉飯"}
- description: Iranian dish of steamed rice and kabab
- countries: IR
- cuisines: Iranian cuisine
- kinds: dish, kebab
- has Wikipedia article: en

## DISH Q10691676
- name: Teaterkonfekt
- other names: {"sv": "Teaterkonfekt"}
- countries: (none)
- kinds: candy

## DISH Q106952818
- name: Linden honey
- description: type of honey
- countries: (none)
- kinds: monofloral honey

## DISH Q1069561
- name: Yukgaejang
- other names: {"zh": "韩国辣牛肉汤"}
- description: food
- countries: (none)
- kinds: food, soup, beef dish
- ingredients: beef
- has Wikipedia article: en

## DISH Q1069591
- name: Jeonbok-juk
- other names: {"zh": "鲍鱼粥"}
- description: Korean abalone rice porridge
- countries: (none)
- kinds: juk
- ingredients: abalone
- has Wikipedia article: en

## DISH Q1069603
- name: Rassolnik
- other names: {"zh": "酸黃瓜湯"}
- description: soup made from pickled cucumbers and other ingredients
- countries: RU
- cuisines: Russian cuisine
- kinds: soup, potato dish, pickle soup
- ingredients: brine, kidney as food, liver as food, Salzgurke, root vegetable
- has Wikipedia article: en, zh

## DISH Q106977722
- name: Quesabirria
- description: Mexican dish
- countries: MX
- cuisines: Mexican cuisine
- kinds: dish
- ingredients: tortilla, Consommé, beef, cheese
- has Wikipedia article: en

## DISH Q106980961
- name: Kheer Kamala
- description: Bengali cuisine
- countries: (none)
- kinds: dessert, confectionery

## DISH Q106980967
- name: Jhinge motor daaler borar Jhol
- description: Bengali cuisine
- countries: (none)
- kinds: Jhol

## DISH Q106980976
- name: Jhinge kumro paturi
- description: Bengali cuisine
- countries: (none)
- kinds: paturi

## DISH Q106980978
- name: Pui shaak kumro diye
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106980983
- name: Mouri potol
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106980987
- name: Begun borir tok
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106980997
- name: Narkel potol
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106981003
- name: Bhetki rongpuri
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106981005
- name: Potol rosha
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q106981007
- name: Doi mouri parshe
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106981009
- name: Mulo koraishutir ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q106981012
- name: Chingri begun er tel jhol
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q106981017
- name: Chal bandhakopir ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q106981031
- name: Telapia sorshe jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q106981036
- name: Dim shorshe
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q106981038
- name: Moong phulkopir ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q106981046
- name: Narkeler dudhe lau shak-chingri machh
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q106981048
- name: Beet gajor chechki
- description: Bengali cuisine
- countries: (none)
- kinds: chhenchki

## DISH Q106981058
- name: Katoya data chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q106981168
- name: Til rui
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106981174
- name: Lonka pora rui
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106981180
- name: Lal shak diye bele machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q106981184
- name: Uchchhe diye rui machher dim
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish
