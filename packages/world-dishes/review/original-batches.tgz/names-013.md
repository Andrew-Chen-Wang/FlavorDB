# Review batch names-013

## DISH Q11608881
- name: Bibai yakitori
- countries: JP
- kinds: yakitori

## DISH Q11609282
- name: 美瑛カレーうどん
- other names: {"ja": "美瑛カレーうどん"}
- countries: (none)
- kinds: noodle dish, curry udon

## DISH Q11609405
- name: 美酒鍋
- other names: {"ja": "美酒鍋"}
- countries: (none)
- kinds: dish, nabemono

## DISH Q11610025
- name: Habutae mochi
- description: Japanese confection
- countries: JP
- kinds: mochi, wagashi

## DISH Q11610715
- name: Mimi-udon
- countries: JP
- kinds: cuisine, noodle dish

## DISH Q11610952
- name: Nakatsu Karaage
- countries: (none)
- kinds: Agemono, karaage

## DISH Q11611432
- name: Niku sui
- description: Ōsaka's cuisine
- countries: JP
- kinds: dish, meat dish, suimono

## DISH Q11611438
- name: 肉末焼餅
- other names: {"ja": "肉末焼餅"}
- countries: (none)
- kinds: shaobing

## DISH Q11611494
- name: Kimosui
- description: eel tripe soup
- countries: (none)
- kinds: suimono
- ingredients: eel offal, eel intestine, unagi

## DISH Q11611501
- name: Unagi no kimoyaki
- countries: (none)
- kinds: unagi, offal dish
- ingredients: eel offal

## DISH Q11611812
- name: Sesame tofu
- description: tofu-like food made from sesame seeds and kudzu starch
- countries: JP
- kinds: pudding, dish, vegan food
- ingredients: sesame seed, kudzu powder

## DISH Q11611813
- name: Goma-saba
- countries: (none)
- kinds: goma-ae, raw fish dish
- ingredients: sesame seed, mackerel as food

## DISH Q11613282
- name: 臼杵煎餅
- other names: {"ja": "臼杵煎餅"}
- countries: JP
- kinds: senbei

## DISH Q11614016
- name: Senba-jiru
- countries: JP
- kinds: nabemono, shirumono, fish dish
- ingredients: Japanese radish, mackerel

## DISH Q11614558
- name: Imogaranawa
- description: dried sweet potato stems with miso
- countries: JP
- kinds: preserved food
- ingredients: Sweet potato

## DISH Q11614575
- name: 芋棒
- other names: {"ja": "芋棒"}
- countries: (none)
- kinds: dish
- ingredients: Colocasia antiquorum var. toonoimo

## DISH Q116146103
- name: Battercake
- description: baked goods made by pouring batter onto a hot griddle or iron
- countries: (none)
- kinds: baked good

## DISH Q116150719
- name: Praline
- other names: {"zh": "果仁糖"}
- description: confections made from nuts
- countries: FR
- kinds: candy, confectionery, praline
- ingredients: hazelnut, caramel
- has Wikipedia article: en

## DISH Q11615097
- name: Hanabōru
- other names: {"zh": "花芳露"}
- countries: (none)
- kinds: bolo

## DISH Q11616139
- name: Wakaayu
- other names: {"zh": "若香魚"}
- countries: (none)
- kinds: wagashi
- ingredients: gyūhi, castella
- has Wikipedia article: zh

## DISH Q11616677
- name: Wakatakeni
- other names: {"zh": "煮筍"}
- countries: (none)
- kinds: nimono
- ingredients: bamboo shoots, wakame

## DISH Q11616701
- name: Wakakusa
- description: Japanese confection
- countries: JP
- kinds: wagashi

## DISH Q116170384
- name: Doppelbürli
- countries: (none)
- kinds: Bürli

## DISH Q116170681
- name: Quittenpästli
- countries: CH
- kinds: confectionery
- ingredients: quince cheese, sugar

## DISH Q116172515
- name: Zhawruki
- description: ceremonial holiday cookies in the form of birds
- countries: (none)
- kinds: cookie, pastry
- ingredients: rye flour

## DISH Q116172687
- name: Sfințișori
- description: traditional pastries from Romania and Moldova
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q116177306
- name: Medivnyk
- description: Ukrainian Dessert
- countries: UA
- kinds: cake
- ingredients: orange peel, chicken egg, brown sugar, monofloral honey, flour
- has Wikipedia article: en

## DISH Q11618004
- name: Chabushi
- countries: (none)
- kinds: miso soup
- ingredients: miso, katsuobushi

## DISH Q11618006
- name: Chagayu
- description: green tea congee
- countries: JP
- kinds: congee
- ingredients: tea, rice

## DISH Q11618043
- name: Chameshi
- countries: (none)
- kinds: gohan

## DISH Q116180788
- name: Butter mochi
- description: Japanese mochi specialty from the Akita Prefecture
- countries: JP
- kinds: mochi
- ingredients: glutinous rice, butter

## DISH Q11618094
- name: Souka senbei
- other names: {"zh": "草加仙貝"}
- description: rice cracker
- countries: JP
- kinds: senbei, rice cracker
- has Wikipedia article: zh

## DISH Q11618150
- name: 草木饅頭
- other names: {"ja": "草木饅頭"}
- countries: JP
- kinds: manjū

## DISH Q116182117
- name: Injin
- countries: ID
- kinds: human food
- ingredients: coconut

## DISH Q11618421
- name: Kojo no Tsuki
- description: confectionery manufactured in Taketa, Oita, Japan
- countries: (none)
- kinds: Miyagegashi, wagashi
- ingredients: awayuki

## DISH Q116186231
- name: Empanada de lacayote
- other names: {"es": "empanada de lacayote"}
- countries: (none)
- kinds: empanada

## DISH Q116188846
- name: Salzwedeler Baumkuchen
- description: kind of Baumkuchen with protected geographical indication
- countries: DE
- kinds: Baumkuchen

## DISH Q11619010
- name: Ogikubo ramen
- other names: {"zh": "荻窪拉麵"}
- countries: (none)
- kinds: Tokyo ramen

## DISH Q116197926
- name: Masala bhat
- description: Rice dish from Maharashtra
- countries: IN
- cuisines: Maharashtrian cuisine
- kinds: rice dish

## DISH Q11619984
- name: Nameshi
- other names: {"zh": "菜飯"}
- description: rice with seasoned greens
- countries: JP
- kinds: Japanese rice dish
- has Wikipedia article: zh

## DISH Q116204985
- name: Soppressata del Vallo di Diano
- other names: {"it": "soppressata del Vallo di Diano"}
- countries: IT
- kinds: dish, soppressata

## DISH Q11620616
- name: 落合羊羹
- other names: {"ja": "落合羊羹"}
- countries: (none)
- kinds: Yōkan

## DISH Q11620703
- name: Rakugan
- other names: {"zh": "落雁"}
- description: Japanese confection
- countries: JP
- kinds: higashi
- ingredients: soy flour, sugar
- has Wikipedia article: zh

## DISH Q11621154
- name: Sōshiki manjū
- countries: (none)
- kinds: manjū

## DISH Q11621171
- name: Negima nabe
- countries: (none)
- kinds: nabemono, tuna dish

## DISH Q11621329
- name: 蒲焼さん太郎
- other names: {"ja": "蒲焼さん太郎"}
- countries: JP
- kinds: dagashi

## DISH Q11622155
- name: 薄墨羊羹
- other names: {"ja": "薄墨羊羹"}
- countries: (none)
- kinds: Yōkan

## DISH Q11622159
- name: 薄氷
- other names: {"ja": "薄氷"}
- countries: (none)
- kinds: higashi

## DISH Q11622161
- name: Usuyaki tamago
- countries: JP
- kinds: egg dish
- ingredients: chicken egg

## DISH Q11622168
- name: Usukawa Manju
- countries: JP
- kinds: wagashi, manjū
- has Wikipedia article: en

## DISH Q11622329
- name: 薩摩汁
- other names: {"ja": "薩摩汁"}
- countries: (none)
- kinds: miso soup

## DISH Q116233410
- name: Chicken karaage
- countries: (none)
- kinds: karaage

## DISH Q116235109
- name: Hurum
- description: traditional Assamese snacks typically served at breakfast
- countries: IN
- kinds: snack

## DISH Q116244942
- name: Yeast cake
- description: cake primarily leavened by yeast
- countries: (none)
- kinds: cake
- ingredients: yeast dough

## DISH Q11624558
- name: 藤沢炒麺
- other names: {"ja": "藤沢炒麺"}
- countries: (none)
- kinds: Yakisoba

## DISH Q116250424
- name: Cuscus di pesce
- other names: {"it": "Cuscus di pesce"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish, couscous

## DISH Q116250839
- name: Gachas tortas
- other names: {"es": "gachas tortas"}
- countries: ES
- cuisines: Mediterranean cuisine
- kinds: dish
- ingredients: parsley, garlic, tomato, Solanum lidii, flour, onion, table salt, potato

## DISH Q11625228
- name: Sotetsu miso
- countries: (none)
- kinds: miso
- ingredients: brown rice, seed

## DISH Q11625583
- name: 蛤志るこ
- other names: {"ja": "蛤志るこ"}
- countries: JP
- kinds: shiruko

## DISH Q11625632
- name: Tako senbei
- other names: {"zh": "章魚仙貝"}
- countries: (none)
- kinds: senbei, octopus dish

## DISH Q116256635
- name: Vongole pasta
- description: pasta dish
- countries: (none)
- kinds: pasta dish, clam dish

## DISH Q116259944
- name: Hash brownie
- description: brownie made using cannabis
- countries: (none)
- kinds: chocolate brownie, hash cookie

## DISH Q11626129
- name: 行方バーガー
- other names: {"ja": "行方バーガー"}
- countries: (none)
- kinds: hamburger

## DISH Q11626556
- name: Fukuromen
- other names: {"zh": "袋装麺"}
- countries: (none)
- kinds: instant noodles

## DISH Q116269610
- name: Omelette aux pommes de terre
- other names: {"fr": "omelette aux pommes de terre"}
- countries: (none)
- kinds: dish, potato dish, omelette
- ingredients: chicken egg, potato

## DISH Q116270157
- name: Imitation custard
- countries: (none)
- kinds: dessert with spoon
- ingredients: corn starch

## DISH Q116271874
- name: Yavoriv pie
- description: pie with potatoes and buckwheat
- countries: UA
- kinds: cuisine, pie
- ingredients: buckwheat seed, egg as food, yeast, flour, potato
- has Wikipedia article: en

## DISH Q11627190
- name: Saikyo miso
- countries: JP
- kinds: miso

## DISH Q116274066
- name: Loaf of Bread
- description: food, bread, human (?) at the Metropolitan Museum of Art (MET, 36.3.79a, b)
- countries: (none)
- kinds: bread

## DISH Q116285069
- name: Candy cane cookie
- countries: (none)
- kinds: cookie
- ingredients: candy cane

## DISH Q11630693
- name: Kakuzushi
- countries: (none)
- kinds: oshizushi

## DISH Q116307508
- name: Ice cream cup (Tasse à glace) (part of a service)
- description: ice cream cup at the Metropolitan Museum of Art (MET, 37.20.194)
- countries: (none)
- kinds: cup, Ice cream cup

## DISH Q1163138
- name: Candied fruit
- other names: {"zh": "蜜饯"}
- description: type of preserved fruit
- countries: (none)
- kinds: confit, preserved food, confectionery
- ingredients: fruit, sugar
- has Wikipedia article: en, zh

## DISH Q11631777
- name: Chōripan
- description: Japanese dish of buns with cooked food inside
- countries: (none)
- kinds: bread

## DISH Q116327
- name: Akashiyaki
- other names: {"zh": "明石燒"}
- description: Japanese dish
- countries: JP
- kinds: egg dish, octopus dish
- ingredients: batter
- has Wikipedia article: en, zh

## DISH Q11633146
- name: 豆パン
- other names: {"ja": "豆パン"}
- countries: (none)
- kinds: sweet bread

## DISH Q11633158
- name: Mametama
- countries: JP
- kinds: okonomiyaki

## DISH Q11633166
- name: Tofu misozuke
- countries: JP
- kinds: tofu, misozuke

## DISH Q11633167
- name: Tofu castella
- countries: (none)
- kinds: tofu, confectionery

## DISH Q11633169
- name: Tofu ramen
- countries: (none)
- kinds: shoyu ramen

## DISH Q11633170
- name: Tofu hanbāgu
- countries: JP
- kinds: hanbāgu
- ingredients: tofu

## DISH Q11633171
- name: Tofu sushi
- countries: JP
- kinds: makizushi
- ingredients: tofu

## DISH Q11633174
- name: Dougan
- other names: {"zh": "豆干"}
- description: firm variety of tofu
- countries: (none)
- kinds: tofu
- has Wikipedia article: en, zh

## DISH Q11633778
- name: Toyohashi curry noodles
- countries: JP
- kinds: Japanese curry, Japanese noodles, curry udon, noodle dish
- ingredients: tororo, brown rice, noodle

## DISH Q11634325
- name: Tonkotsu
- countries: (none)
- kinds: pork dish

## DISH Q11634490
- name: Kayakimiso
- countries: JP
- kinds: nabemono
- ingredients: Mizuhopecten yessoensis

## DISH Q11635249
- name: Akadashi
- description: Red miso soup
- countries: JP
- kinds: miso soup

## DISH Q11635274
- name: Akadozuke
- countries: JP
- kinds: tsukemono

## DISH Q11636404
- name: Echizen kanimeshi
- countries: JP
- kinds: Japanese rice dish, seafood dish
- ingredients: Brachyura

## DISH Q11637231
- name: Minobu manjū
- countries: (none)
- kinds: miso manjū

## DISH Q11637469
- name: 軍鶏鍋
- other names: {"ja": "軍鶏鍋"}
- countries: JP
- kinds: nabemono, chicken dish
- ingredients: Shamo

## DISH Q116376913
- name: Wet hamburger
- description: Turkish street food
- countries: TR
- kinds: food, hamburger
- has Wikipedia article: en

## DISH Q116376977
- name: Kuru dolma
- description: dried eggplant dish of Turkey
- countries: TR
- kinds: dolma, eggplant dish

## DISH Q11637813
- name: Karashirenkon
- description: food
- countries: (none)
- kinds: vegetable dish
- ingredients: karashi, Lotus rhizome

## DISH Q116390743
- name: Fırın kebabı
- other names: {"tr": "Fırın kebabı"}
- countries: (none)
- kinds: kebab

## DISH Q11642095
- name: 遠州焼き
- other names: {"ja": "遠州焼き"}
- countries: (none)
- kinds: okonomiyaki

## DISH Q11642789
- name: 那珂湊焼きそば
- other names: {"ja": "那珂湊焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q11643455
- name: Miyako manjū
- countries: (none)
- kinds: manjū

## DISH Q116438588
- name: Conical loaf of bread
- description: food, bread loaf at the Metropolitan Museum of Art (MET, 22.3.204)
- countries: (none)
- kinds: bread

## DISH Q116438594
- name: Circular loaf of bread
- description: food, bread loaf at the Metropolitan Museum of Art (MET, 22.3.198)
- countries: (none)
- kinds: bread

## DISH Q116438607
- name: Triangular loaf of bread
- description: food, bread loaf at the Metropolitan Museum of Art (MET, 25.3.230)
- countries: (none)
- kinds: bread

## DISH Q11644313
- name: Sakezushi
- countries: JP
- kinds: sushi
- ingredients: akumochizake

## DISH Q11644342
- name: Sakata ramen
- countries: JP
- kinds: Yamagata ramen, dish
- ingredients: chāshū, tonkotsu, wonton, noodle

## DISH Q11644451
- name: Suancaiyu
- other names: {"zh": "酸菜鱼"}
- description: dish
- countries: CN
- cuisines: Sichuan cuisine
- kinds: dish, type of food or dish
- ingredients: suan cai
- has Wikipedia article: en, zh

## DISH Q11644489
- name: Shōyu kake gohan
- countries: JP
- kinds: Japanese rice dish
- ingredients: gohan, soy sauce

## DISH Q11644490
- name: Shōyu dango
- countries: (none)
- kinds: dango, skewer
- ingredients: shōyu, dango

## DISH Q11644491
- name: Syoyu no mi
- description: Japanese fermented food
- countries: JP
- kinds: fermented food
- ingredients: soy bean

## DISH Q116444933
- name: Werdaer Zuckermännle
- other names: {"de": "Werdaer Zuckermännle"}
- countries: (none)
- kinds: pastry

## DISH Q11644495
- name: Shōyu mochi
- countries: (none)
- kinds: mochi

## DISH Q11644814
- name: Omoyu
- description: thin, filtered, Japanese rice congee
- countries: JP
- kinds: congee

## DISH Q116456367
- name: Chapa namak
- description: rolled dried apricots
- countries: AF
- kinds: dried fruit
- ingredients: apricot

## DISH Q11646473
- name: 金光饅頭
- other names: {"ja": "金光饅頭"}
- countries: (none)
- kinds: manjū

## DISH Q11646981
- name: Kinzanji miso
- countries: JP
- kinds: miso

## DISH Q11647361
- name: Kanazawa curry
- other names: {"zh": "金澤咖哩"}
- description: variety of Japanese curry from Kanazawa, Ishikawa Prefecture, Japan
- countries: (none)
- kinds: type of food or dish, Japanese curry

## DISH Q11647656
- name: 金生饅頭
- other names: {"ja": "金生饅頭"}
- countries: (none)
- kinds: wagashi, manjū

## DISH Q11647842
- name: 金華糖
- other names: {"ja": "金華糖"}
- countries: (none)
- kinds: confectionery

## DISH Q1164799
- name: Mattentaart
- description: Belgian pastry typical for the region of Geraardsbergen and Lierde
- countries: BE
- kinds: sweet pie, pastry

## DISH Q11648259
- name: Kushiro ramen
- other names: {"zh": "釧路拉麵"}
- countries: (none)
- kinds: ramen in Hokkaido, shoyu ramen
- has Wikipedia article: zh

## DISH Q116490628
- name: Masarykovo cukroví
- other names: {"cs": "Masarykovo cukroví"}
- countries: CZ
- kinds: Christmas dessert, confectionery

## DISH Q11649570
- name: Teppan-yakitori
- countries: (none)
- kinds: teppanyaki, yakitori

## DISH Q11650401
- name: Tablet candy
- countries: (none)
- kinds: candy

## DISH Q116506414
- name: Egg noodle
- other names: {"zh": "雞蛋麵"}
- countries: (none)
- kinds: noodle, flour-based food, egg pasta
- ingredients: chicken egg, wheat flour
- has Wikipedia article: zh

## DISH Q11650717
- name: Nabeyaki ramen
- countries: (none)
- kinds: shoyu ramen

## DISH Q11650870
- name: Kamakura-don
- countries: (none)
- kinds: donburi, shrimp dish

## DISH Q11652139
- name: Nagaoka shōga shōyu ramen
- countries: JP
- kinds: shoyu ramen, ramen in Niigata Prefecture

## DISH Q11652330
- name: 長崎サラダ
- other names: {"ja": "長崎サラダ"}
- countries: JP
- kinds: noodle dish

## DISH Q116528304
- name: Homemade potato salad
- countries: (none)
- kinds: potato salad

## DISH Q116528331
- name: Gratin de légumes
- other names: {"fr": "gratin de légumes"}
- countries: (none)
- kinds: dish, gratin
- ingredients: vegetable

## DISH Q116543927
- name: Espeto de rojão
- countries: (none)
- kinds: dish

## DISH Q11656558
- name: Yaminabe
- other names: {"zh": "闇鍋"}
- description: nabemono made by multiple people who bring one ingredient each, often of a barely edible nature
- countries: (none)
- kinds: nabemono
- has Wikipedia article: zh

## DISH Q11657492
- name: Awa uiro
- other names: {"zh": "阿波外郎餅"}
- countries: (none)
- kinds: mochi, uirō

## DISH Q11659802
- name: 雪熊
- countries: (none)
- kinds: kakigōri

## DISH Q116602313
- name: Pajarito
- other names: {"es": "Pajarito"}
- countries: CL
- kinds: bread roll

## DISH Q11660390
- name: Electric bread
- countries: (none)
- kinds: bread

## DISH Q11660771
- name: 霜ばしら
- other names: {"ja": "霜ばしら"}
- countries: (none)
- kinds: ame

## DISH Q116613910
- name: Preserved radish
- other names: {"zh": "蘿蔔乾"}
- description: Chinese fermented radish
- countries: (none)
- kinds: dried food
- ingredients: white radish
- has Wikipedia article: en, zh

## DISH Q11661478
- name: 青春のトマト焼きそば
- other names: {"ja": "青春のトマト焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q116620968
- name: Margot
- other names: {"cs": "Margot"}
- countries: (none)
- kinds: chocolate bar

## DISH Q116622800
- name: Quesillo nicaragüense
- other names: {"es": "quesillo nicaragüense"}
- description: Nicaraguan dish
- countries: NI
- kinds: dish
- ingredients: corn tortilla, onion, Quesillo

## DISH Q11662686
- name: 青竹鮨
- other names: {"ja": "青竹鮨"}
- countries: JP
- kinds: pickled fish

## DISH Q116638599
- name: Mingau pitinga
- other names: {"pt": "mingau pitinga"}
- countries: (none)
- kinds: dish

## DISH Q11664516
- name: Suko-zushi
- description: style of sushi
- countries: (none)
- kinds: oshizushi
- ingredients: kabayaki

## DISH Q11664945
- name: Atama ryori
- description: Dishes made from leftover fish parts
- countries: JP
- kinds: mizutaki
- ingredients: Ara

## DISH Q11664953
- name: 頭脳パン
- other names: {"ja": "頭脳パン"}
- countries: (none)
- kinds: bread

## DISH Q11665438
- name: Furofuki
- countries: JP
- kinds: vegetable dish

## DISH Q11665983
- name: 飛鳥鍋
- other names: {"ja": "飛鳥鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q11666106
- name: Obiten
- countries: JP
- kinds: agekamaboko, fish surimi

## DISH Q11666261
- name: I-zushi
- description: style of sushi
- countries: (none)
- kinds: narezushi

## DISH Q116681205
- name: Priazhenia
- description: Ukrainian type of omelette, scrambled eggs with flour and milk.
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: food, egg dish
- ingredients: egg as food, flour, milk

## DISH Q11668579
- name: Honetsukidori
- countries: JP
- kinds: meat dish

## DISH Q11668712
- name: Takaida ramen
- description: ramen in Osaka, Japan
- countries: (none)
- kinds: shoyu ramen

## DISH Q116689799
- name: Bebe
- description: Finnish pastry
- countries: FI
- kinds: pastry

## DISH Q11669310
- name: Takayama ramen
- other names: {"zh": "高山らーめん"}
- description: style of Japanese ramen
- countries: JP
- kinds: shoyu ramen, ramen
- has Wikipedia article: zh

## DISH Q116693687
- name: Śledź w oleju
- other names: {"pl": "Śledź w oleju"}
- countries: (none)
- kinds: fish dish, dish

## DISH Q11669466
- name: 高岡コロッケ
- other names: {"ja": "高岡コロッケ"}
- countries: (none)
- kinds: korokke

## DISH Q116698160
- name: Mistocchina
- other names: {"it": "Mistocchina"}
- countries: IT
- kinds: dessert, dish
- ingredients: chestnut flour, table salt, water

## DISH Q116698172
- name: Nevola
- other names: {"it": "Nevola"}
- countries: IT
- kinds: dessert, dish

## DISH Q116698305
- name: Souskluitjies
- description: South African dumpling
- countries: ZA
- kinds: dumpling

## DISH Q11670597
- name: 高校生のコメロンパン
- other names: {"ja": "高校生のコメロンパン"}
- countries: JP
- kinds: melonpan

## DISH Q11671983
- name: 高瀬舟羊羹
- other names: {"ja": "高瀬舟羊羹"}
- countries: (none)

## DISH Q11672762
- name: Takanamaki
- countries: (none)
- kinds: makizushi
- ingredients: Brassica juncea var. integrifolia

## DISH Q11672763
- name: Takana meshi
- countries: JP
- kinds: rice dish
- ingredients: Brassica juncea var. integrifolia

## DISH Q116728462
- name: Zaazaa
- description: Moroccan smoothie
- countries: MA
- cuisines: Moroccan cuisine
- kinds: parfait, milkshake
- ingredients: avocado, almond, raisin, nut, honey, milk, banana, chocolate
- has Wikipedia article: en

## DISH Q11673153
- name: Koya-dofu
- other names: {"zh": "冻豆腐"}
- description: type of tofu
- countries: JP
- kinds: tofu, dried food, type of food or dish
- has Wikipedia article: en

## DISH Q11673376
- name: 鬼の手こぼし
- other names: {"ja": "鬼の手こぼし"}
- countries: (none)
- kinds: zongzi

## DISH Q11673565
- name: Oni manjū
- countries: (none)
- kinds: manjū
- ingredients: Sweet potato

## DISH Q116739067
- name: Bingka Barandam
- description: traditional Indonesian cake from South Kalimantan, made from duck eggs, flour and bingka sauce
- countries: ID
- cuisines: Indonesian cuisine
- kinds: confectionery, traditional food, cookie, dish, snack
- ingredients: brown sugar, wheat flour, food coloring, Pandanus amaryllifolius, egg as food, cinnamon, table salt, sugar, water

## DISH Q116739072
- name: Amparan tatak
- description: variations of typical Indonesian food
- countries: ID
- kinds: dish
- ingredients: coconut, rice flour, sugar, banana

## DISH Q11673921
- name: 魚うどん
- other names: {"ja": "魚うどん"}
- countries: JP
- kinds: udon, fish dish

## DISH Q11673928
- name: 魚のはぶて焼き
- other names: {"ja": "魚のはぶて焼き"}
- countries: JP
- kinds: fish dish

## DISH Q11673934
- name: 魚ロッケ
- other names: {"ja": "魚ロッケ"}
- countries: (none)
- kinds: Agemono, fish dish

## DISH Q11674068
- name: Fish sausage
- description: Japanese fish sausage
- countries: (none)
- kinds: sausage, fish dish
- ingredients: fish surimi
- has Wikipedia article: en

## DISH Q11674158
- name: Ayu-zushi
- description: kind of sushi made with ayu (Plecoglossus altivelis)
- countries: JP
- kinds: sushi
- ingredients: ayu sweetfish as food

## DISH Q11674162
- name: Awabi no nigai
- description: simmered abalone
- countries: (none)
- kinds: seafood dish, nibitashi
- ingredients: Haliotis

## DISH Q11674166
- name: Funanoko-mabushi
- countries: (none)
- kinds: sashimi
- ingredients: crucian carp as food

## DISH Q11674167
- name: Funa miso
- countries: (none)
- kinds: nizakana
- ingredients: crucian carp as food, soy bean, miso

## DISH Q11674169
- name: Funameshi
- countries: JP
- kinds: Japanese rice dish, fish dish
- ingredients: minced meat

## DISH Q11674208
- name: Saketoba
- other names: {"zh": "鮭魚冬葉"}
- description: Salmon jerkey
- countries: JP
- kinds: jerky
- ingredients: chum salmon

## DISH Q11674229
- name: Koikoku
- countries: JP
- kinds: miso soup, fish dish
- ingredients: carp, miso soup

## DISH Q11674263
- name: Tai no karamushi
- countries: JP
- kinds: mushimono, fish dish
- ingredients: red seabream, soy pulp

## DISH Q11674265
- name: Taimeshi
- other names: {"zh": "鯛魚飯"}
- description: rice with seabream
- countries: JP
- cuisines: Japanese cuisine
- kinds: Japanese rice dish, fish dish
- ingredients: red seabream, cooked rice

## DISH Q11674289
- name: Kujira yōkan
- countries: JP
- kinds: Yōkan

## DISH Q11674303
- name: Nishin konbumaki
- countries: (none)
- kinds: kobumaki, fish dish
- ingredients: migaki nishin, kombu

## DISH Q11674307
- name: Nishinzuke
- other names: {"zh": "漬鯡魚"}
- countries: JP
- kinds: tsukemono, pickled fish
- ingredients: migaki nishin

## DISH Q11674330
- name: Nukadaki
- countries: JP
- kinds: nizakana

## DISH Q11674332
- name: Aji no oshizushi
- countries: (none)
- kinds: oshizushi
- ingredients: Caranginae

## DISH Q11674333
- name: Katsuo no tataki
- other names: {"zh": "鰹魚刺身"}
- description: Japanese fish dish
- countries: JP
- kinds: sashimi, tataki, food
- ingredients: skipjack tuna

## DISH Q11674342
- name: Unajū
- other names: {"zh": "鰻魚重箱"}
- description: unagi eel bowl in a square container
- countries: JP
- kinds: unadon
- ingredients: unagi

## DISH Q11674345
- name: Masuzushi
- other names: {"zh": "鱒壽司"}
- description: type of sushi from Toyama
- countries: (none)
- kinds: oshizushi
- ingredients: Oncorhynchus masou
- has Wikipedia article: en

## DISH Q11674350
- name: Hamo no kabayaki
- countries: (none)
- kinds: kabayaki
- ingredients: Daggertooth pike conger

## DISH Q11674361
- name: Tori ham
- description: Japanese ham-like chicken dish
- countries: JP
- kinds: chicken dish

## DISH Q11674519
- name: Tottori gyūkotsu ramen
- countries: (none)
- kinds: ramen
- ingredients: beef bones

## DISH Q116745706
- name: Finger food with stick
- countries: (none)
- kinds: finger food

## DISH Q11675518
- name: Kamonanban
- other names: {"zh": "鴨南蠻"}
- description: Japanese noodle dish
- countries: JP
- kinds: noodle soup
- ingredients: soba, duck meat
- has Wikipedia article: en

## DISH Q11675615
- name: Kamonabe
- other names: {"zh": "鸭锅"}
- countries: (none)
- kinds: nabemono, duck dish

## DISH Q11675813
- name: Keichan
- countries: JP
- kinds: itamemono, chicken dish, dish
- ingredients: chicken as food

## DISH Q11675821
- name: Torisashi
- other names: {"zh": "雞刺"}
- description: Japanese dish
- countries: JP
- kinds: sashimi, chicken dish, raw meat dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q11675829
- name: Chicken ham
- countries: (none)
- kinds: ham

## DISH Q11675857
- name: Uguisu mochi
- countries: (none)
- kinds: mochi, wagashi
- ingredients: uguisu an

## DISH Q11675921
- name: Tsuruko manjū
- countries: (none)
- kinds: manjū
- ingredients: muscovado, sweet bean paste

## DISH Q11676454
- name: Shika-senbei
- other names: {"zh": "鹿煎餅"}
- description: senbei to be fed to deer in Nara Park in Japan
- countries: (none)
- kinds: senbei, animal feed
- ingredients: rice bran, wheat flour
- has Wikipedia article: zh

## DISH Q11676485
- name: Kagoshima ramen
- description: ramen dish
- countries: JP
- kinds: ramen, dish
- ingredients: ramen
- has Wikipedia article: en

## DISH Q116765639
- name: Five-nut mooncake
- countries: (none)
- kinds: mooncake

## DISH Q116769615
- name: Swiss cheeses and dairy products
- description: cheeses and dairy products produced in Switzerland
- countries: CH
- kinds: dairy product
- has Wikipedia article: en

## DISH Q11677381
- name: Mugi senbei
- countries: (none)
- kinds: senbei
- ingredients: peanut, wheat flour

## DISH Q11677382
- name: Mugitoro
- other names: {"zh": "山药泥拌饭"}
- countries: JP
- kinds: Japanese rice dish
- ingredients: tororo, barley rice

## DISH Q11677407
- name: Funoyaki
- countries: (none)
- kinds: wagashi
- ingredients: wheat flour

## DISH Q11677410
- name: Fu manjū
- countries: (none)
- kinds: manjū
- ingredients: fu

## DISH Q11677711
- name: 黄そば
- other names: {"ja": "黄そば"}
- countries: JP
- kinds: Japanese noodles

## DISH Q11677820
- name: 黄身返し卵
- other names: {"ja": "黄身返し卵"}
- countries: (none)
- kinds: egg dish

## DISH Q11677821
- name: Kimi-shigure
- description: steamed bun
- countries: (none)
- kinds: wagashi
- ingredients: white bean paste, egg yolk

## DISH Q11677885
- name: Ōhan
- countries: (none)
- kinds: gohan
- ingredients: gardenia yellow, rice

## DISH Q116779502
- name: Buta Kara Jjigae Teishoku (Machikado-ya)
- countries: (none)
- kinds: dish

## DISH Q11677965
- name: Kurohampen
- other names: {"zh": "黑半片"}
- description: food in Japan
- countries: JP
- kinds: Hampen, fish dish, food
- ingredients: fish as food
- has Wikipedia article: zh

## DISH Q11678020
- name: Kuro zukuri
- description: salted squid with squid ink
- countries: JP
- kinds: shiokara
- ingredients: cephalopod ink

## DISH Q116785309
- name: Svenbo
- other names: {"da": "Svenbo"}
- countries: DK
- kinds: cow's-milk cheese, Danish cheese

## DISH Q116786071
- name: 85% Dark Chocolate
- description: dark chocolate legal standard and proper name for products using chocolate an 85% whole cocoa bean content
- countries: (none)
- kinds: types of chocolate, chocolate

## DISH Q116786436
- name: Dipping chocolate
- description: chocolate that is serve warm and diluted for dipping fruit and use in chocolate fountains
- countries: (none)
- kinds: chocolate

## DISH Q116787453
- name: Craft chocolate
- description: chocolate that is made in a batch by an experienced chocolate maker
- countries: (none)
- kinds: chocolate

## DISH Q11678836
- name: Kurobe Dam Curry
- description: Japanese rice curry with rice molded to mimic the Kurobe Dam
- countries: JP
- kinds: dam curry

## DISH Q116788485
- name: Sugo Marinetti
- description: sauce in Italian cuisine
- countries: (none)
- kinds: tomato sauce
- has Wikipedia article: en

## DISH Q11678910
- name: Kokuhan
- countries: (none)
- kinds: okowa
- ingredients: black soybean, glutinous rice

## DISH Q11678964
- name: Bekkō candy
- other names: {"zh": "鳖甲糖"}
- countries: JP
- kinds: candy, ame
- has Wikipedia article: en

## DISH Q116790224
- name: Escargots à la bordelaise
- countries: (none)
- kinds: dish

## DISH Q11679965
- name: Arròs al forn
- description: Rice dish made in the oven
- countries: ES
- cuisines: Valencian cuisine
- kinds: rice dish, dish
- ingredients: blood sausage, olive oil, saffron, table salt, rice, water, garlic, chickpea, tomato, potato, pork ribs

## DISH Q11680910
- name: Cotoletta
- description: Italian food item of meat , eggs and breadcrumbs
- countries: FR, IT
- kinds: veal dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q116814536
- name: Cake dress
- description: cake in the form of wearable dress
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q11681782
- name: Figatell
- description: dish consisting of a patty of ground pork
- countries: (none)
- cuisines: Valencian cuisine, Aragonese cuisine
- kinds: type of food or dish, pork dish
- ingredients: pork

## DISH Q11682627
- name: Huarache
- description: Mexican maize dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q116842438
- name: Amaretti di Sassello
- description: biscuit from Sassello, Italy
- countries: IT
- kinds: Amaretto macaron, biscuit
- ingredients: almond, egg as food, Prunus armeniaca, sugar

## DISH Q116859574
- name: Jønnbrød
- other names: {"nb": "Jønnbrød"}
- countries: NO
- kinds: cake

## DISH Q11686754
- name: Stortini
- description: type of pasta
- countries: (none)
- kinds: pasta

## DISH Q116897485
- name: Reichelsheimer Mäusekuchen
- other names: {"de": "Reichelsheimer Mäusekuchen"}
- countries: DE
- kinds: pastry

## DISH Q11690062
- name: Chodský koláč
- other names: {"cs": "chodský koláč"}
- countries: (none)
- kinds: kolach

## DISH Q116909753
- name: Kaeng khanun
- description: Northern Thai curry dish
- countries: TH
- kinds: Thai curry

## DISH Q116910905
- name: Canjica popcorn
- countries: BR
- kinds: snack
- ingredients: Canjica

## DISH Q11691713
- name: Mazapán de Toledo
- description: marzipan from Toledo
- countries: ES
- kinds: marzipan, dessert
- ingredients: almond

## DISH Q11694313
- name: Djamilah
- description: Type of cake
- countries: (none)
- kinds: type of food or dish, cake

## DISH Q116947279
- name: Bondiola sandwich
- description: Argentinian street food – bread with pork
- countries: AR
- cuisines: Argentine cuisine
- kinds: sandwich, street food
- ingredients: Bondiola, pork shoulder, lemon juice, brioche
- has Wikipedia article: en

## DISH Q11696257
- name: Nürnberger Rostbratwurst
- description: German sausage
- countries: DE
- kinds: Bratwurst, Brühwurst
- has Wikipedia article: en

## DISH Q116972170
- name: Sururu stew
- description: Brazilian dish
- countries: BR
- kinds: dish

## DISH Q116978915
- name: Patola de caranguejo
- description: traditional dish in Brazil
- countries: (none)
- kinds: dish

## DISH Q116984509
- name: Nail Pita
- countries: TR
- kinds: pide

## DISH Q116991
- name: Knäck
- description: Swedish confectionery
- countries: SE
- kinds: toffee
- ingredients: golden syrup, almond, cream, sugar
- has Wikipedia article: en

## DISH Q11699222
- name: Picatostes
- description: pieces of fried bread
- countries: ES
- cuisines: Spanish cuisine
- kinds: bread, deep-fried food, type of food or dish
- ingredients: olive oil, bread
- has Wikipedia article: en

## DISH Q116995647
- name: Salt and pepper pork chop with rice
- countries: (none)
- kinds: pork chop rice
- ingredients: salt and pepper pork chop, cooked rice

## DISH Q116995676
- name: Salt and pepper pork chop
- countries: CN
- cuisines: Cantonese cuisine
- kinds: dish
- ingredients: salt and pepper, pork chop

## DISH Q11700033
- name: Ponchik
- other names: {"es": "Ponchik"}
- countries: (none)
- kinds: doughnut

## DISH Q11700178
- name: Potica
- description: Slovenian walnut cake roll
- countries: SI
- kinds: pastry
- ingredients: chicken egg, walnut, dough, yeast, butter, cream, sugar, honey
- has Wikipedia article: en

## DISH Q11701172
- name: Goły
- other names: {"pl": "Goły"}
- countries: (none)
- kinds: potato dish

## DISH Q117011849
- name: Sakhnovshchyna korovai
- description: traditional ceremonial bread baked in Sakhnovshchyna
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: baking, korovai, bread, cuisine
- ingredients: baker's yeast, flour, sugar, water, yeast, butter, egg, milk

## DISH Q11701587
- name: Acehúche cheese
- description: Spanish cheese
- countries: ES
- kinds: Spanish cheese, cheese

## DISH Q11703047
- name: Revueltu de cogordes
- other names: {"ast": "Revueltu de cogordes"}
- countries: (none)
- kinds: egg dish, mushroom dish
- ingredients: parsley, egg as food, table salt

## DISH Q11704720
- name: Trempó
- other names: {"ca": "trempó"}
- countries: (none)
- kinds: salad
- ingredients: tomato, onion, Capsicum baccatum, olive oil, table salt

## DISH Q117051304
- name: Curzoli
- description: type of pasta of Romagna, Italy
- countries: IT
- kinds: egg pasta, type of pasta

## DISH Q11705466
- name: Zarajo
- countries: (none)
- kinds: dish
- ingredients: intestine

## DISH Q117061527
- name: Bourek
- description: Algerian savoury pastry
- countries: DZ
- kinds: dish
- ingredients: pastry, meat, cheese
- has Wikipedia article: en

## DISH Q117068284
- name: Reepkoeke
- other names: {"fy": "reepkoeke"}
- countries: (none)
- kinds: cookie

## DISH Q117072235
- name: Wafer
- other names: {"zh": "威化"}
- description: thin, crispy type of biscuit
- countries: (none)
- kinds: biscuit
- has Wikipedia article: en, zh

## DISH Q117084700
- name: Cuajitos
- other names: {"es": "Cuajitos"}
- countries: MX
- kinds: dish

## DISH Q117084707
- name: Chicharrón de la Ramos
- description: Mexican variant of pork dish
- countries: MX
- kinds: dish
- has Wikipedia article: en

## DISH Q117148246
- name: Samarkand non
- description: Uzbek bread
- countries: UZ
- cuisines: Cuisine of Uzbekistan
- kinds: bread
- has Wikipedia article: en

## DISH Q11715140
- name: Jabkanec
- other names: {"cs": "Jabkanec"}
- countries: CZ
- kinds: potato dish
- ingredients: potato, quark

## DISH Q11716143
- name: Jagnięcina
- other names: {"pl": "jagnięcina"}
- description: mutton meat obtained from lambs aged 6 to 12 months, ingredient in Polish cuisine
- countries: PL
- cuisines: Polish cuisine
- kinds: lamb meat, meat

## DISH Q11716216
- name: Soft-boiled egg
- description: boiled egg with liquid yolk
- countries: (none)
- kinds: boiled egg, coddled egg

## DISH Q117187798
- name: Pizza dolce di Beridde
- description: Italian yeasted cake
- countries: IT
- cuisines: Italian cuisine, Jewish cuisine
- kinds: sweet bread
- has Wikipedia article: en

## DISH Q117192636
- name: Krabbenbrötchen
- other names: {"de": "Krabbenbrötchen"}
- countries: (none)
- kinds: sandwich
- ingredients: german bread roll, brown shrimp as food

## DISH Q117195224
- name: Marinera
- description: traditional tapa from the Region of Murcia
- countries: ES
- cuisines: cuisine of the Region of Murcia, cuisine of Cartagena, Spain
- kinds: tapas
- ingredients: salt-cured anchovy, Olivier salad

## DISH Q117220543
- name: Dal curry
- description: Curry dish of India
- countries: (none)
- cuisines: South Asian cuisine
- kinds: curry, lentil soup
- ingredients: lentil, split pulse, liquid water, garlic, ginger, onion, masala

## DISH Q117234715
- name: Burger bun
- description: usually round sweet loaf of bread mostly used for burgers
- countries: (none)
- kinds: bread roll
- ingredients: sesame seed, sucrose, pastry flour, dough

## DISH Q117246552
- name: Béchi-panzalini
- other names: {"it": "Béchi-panzalini"}
- countries: IT
- kinds: bread

## DISH Q11725557
- name: Chléb ve starověkém Egyptě
- other names: {"cs": "Chléb ve starověkém Egyptě"}
- countries: (none)
- kinds: bread

## DISH Q11725980
- name: Chocodecor
- description: type of candy for decoration
- countries: (none)
- kinds: type of product, sweetmeat

## DISH Q117268856
- name: Inbriago
- description: Italian cheese
- countries: IT
- kinds: Italian cheese

## DISH Q117270376
- name: Barbusto
- description: Italian sausage
- countries: IT
- kinds: Italian sausage

## DISH Q11727138
- name: Jeżynówka
- other names: {"pl": "Jeżynówka"}
- countries: (none)
- kinds: dish

## DISH Q117275822
- name: Sujime
- description: Japanese fish cooking method
- countries: (none)
- kinds: pickled fish, food preparation technique

## DISH Q1172858
- name: Shelf-stable bread
- description: shelf-stable pastry
- countries: (none)
- kinds: bread, shelf-stable food

## DISH Q117306296
- name: Bacheschnette
- other names: {"de": "Bacheschnette"}
- countries: (none)
- kinds: pastry

## DISH Q117307020
- name: Leningradsky cake
- description: soviet pastry
- countries: (none)
- cuisines: Soviet cuisine
- kinds: cake
- ingredients: buttercream
- has Wikipedia article: en

## DISH Q117307294
- name: Schnittkäse Bela Badia PAT
- other names: {"zh": "Schnittkäse Bela Badia PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese
- has Wikipedia article: en

## DISH Q117307969
- name: Casàda PAT
- other names: {"zh": "Casàda PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese, dairy product, animal product
- has Wikipedia article: en

## DISH Q117310058
- name: Scifuloti
- other names: {"it": "Scifuloti"}
- countries: IT
- kinds: pasta, type of pasta
- ingredients: flour

## DISH Q117313316
- name: Šúľance
- description: a dish of Slovak cuisine prepared from eggs, flour, salt, boiled and grated potatoes
- countries: SK
- kinds: gnocchi
- ingredients: potato
- has Wikipedia article: en

## DISH Q117319691
- name: Canestrato
- other names: {"it": "Canestrato"}
- countries: IT
- kinds: cheese

## DISH Q117320002
- name: Iced almond
- countries: TR
- kinds: food

## DISH Q117353093
- name: Hash cookie
- countries: (none)
- kinds: cookie, cannabis edible

## DISH Q117353679
- name: Truite meunière
- countries: FR
- kinds: dish

## DISH Q117354285
- name: Pied de cochon grillé
- countries: (none)
- kinds: dish

## DISH Q117359905
- name: Schnittkäse Schlanderser leicht PAT
- other names: {"zh": "Schnittkäse Schlanderser leicht PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cow's-milk cheese, cheese
- ingredients: cow's milk, rennet, table salt

## DISH Q117378281
- name: Kohlpudding
- other names: {"de": "Kohlpudding"}
- countries: (none)
- kinds: dish

## DISH Q117382907
- name: Ingannapreti
- other names: {"it": "ingannapreti"}
- countries: IT
- kinds: egg pasta, type of pasta
- ingredients: egg as food, flour

## DISH Q11740164
- name: Klobásník
- description: American Czech savory food
- countries: US
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q11740317
- name: Kluchy połom bite
- countries: PL
- cuisines: Silesian cuisine
- kinds: potato dish
- has Wikipedia article: en

## DISH Q11744324
- name: Kotlet rzymski
- other names: {"pl": "Kotlet rzymski"}
- countries: (none)
- kinds: dish

## DISH Q11744325
- name: Kotlety ziemniaczane
- other names: {"pl": "Kotlety ziemniaczane"}
- countries: (none)
- kinds: potato dish

## DISH Q117450518
- name: Catalanet
- other names: {"ca": "catalanet"}
- countries: (none)
- kinds: ice cream
- ingredients: ratafia, turrón

## DISH Q117458486
- name: לחמניות כשרות לפסח
- other names: {"he": "לחמניות כשרות לפסח"}
- countries: (none)
- cuisines: tradition
- kinds: food

## DISH Q117459468
- name: Sweet corn arepa
- description: Typical food from Colombia, Costa Rica, Ecuador and Mexico
- countries: CO
- kinds: pancake, type of food or dish
- ingredients: cow's milk, panela, butter, table salt, cheese
- has Wikipedia article: en

## DISH Q117460089
- name: Strichetti
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: chicken egg, flour, water
