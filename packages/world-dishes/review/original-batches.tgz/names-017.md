# Review batch names-017

## DISH Q124417706
- name: Tomato bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q1244306
- name: Saint Agur Blue
- description: pasteurized blue cheese from central France
- countries: FR
- kinds: blue cheese, semi-hard cheese, industrial cheese, pasteurized milk cheese, French cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q12443146
- name: Broccoli curry
- description: Tamil dish
- countries: (none)
- kinds: Indian curry
- ingredients: broccoli

## DISH Q124434588
- name: Pukjai
- description: soybean stew in Koryo-saram cuisine
- countries: (none)
- cuisines: Koryo-saram cuisine
- kinds: jjigae, dish
- ingredients: fermented bean paste, doenjang
- has Wikipedia article: en

## DISH Q124434638
- name: Siryak-tyamuri
- description: soybean paste stew in Koryo-saram cuisine
- countries: (none)
- cuisines: Koryo-saram cuisine
- kinds: dish
- ingredients: siraegi, doenjang
- has Wikipedia article: en

## DISH Q124436851
- name: Carne de onça
- description: Brazilian dish
- countries: BR
- cuisines: Brazilian cuisine
- kinds: dish

## DISH Q124437025
- name: Chighitma
- description: Iranian breakfast dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1244380
- name: Schlosserbuben
- other names: {"de": "Schlosserbuben"}
- countries: (none)
- kinds: dish

## DISH Q124448968
- name: Sombe
- description: Ugandan stew made using pounded cassava leaves, palm oil and fish or meat
- countries: UG
- kinds: cuisine, stew
- ingredients: cassava root, palm oil, meat, fish
- has Wikipedia article: en

## DISH Q124459711
- name: Рыба в рассоле
- other names: {"ru": "Рыба в рассоле"}
- countries: RU
- cuisines: Russian cuisine
- kinds: dish, fish dish

## DISH Q124464108
- name: Goranski nadjev
- other names: {"hr": "Goranski nadjev"}
- countries: HR
- cuisines: Croatian cuisine
- kinds: food

## DISH Q12447286
- name: Murgh Musallam
- description: dish from the Indian subcontinent
- countries: (none)
- kinds: food, chicken dish
- has Wikipedia article: en

## DISH Q124477775
- name: Pirot
- other names: {"nl": "pirot"}
- countries: BE
- kinds: worstenbrood

## DISH Q124516027
- name: Cola de mono ice cream
- description: ice cream made with cola de mono
- countries: CL
- kinds: ice cream
- ingredients: Cola de mono

## DISH Q124519924
- name: Firinda
- description: Ugandan sauce made from peeled mashed beans
- countries: UG
- kinds: food, sauce
- ingredients: cooking oil, bean, ghee, tomato, table salt
- has Wikipedia article: en

## DISH Q124519996
- name: Akaro
- description: Ugandan cuisine made by mingling cassava and millet flours
- countries: UG
- kinds: food, African cuisine, type of food or dish
- ingredients: millet flour, cassava flour, water

## DISH Q124525332
- name: Torta de manjarate
- description: Chilean cake
- countries: CL
- kinds: cake, meal

## DISH Q124526401
- name: الحلوى الفيلالية
- other names: {"ar": "الحلوى الفيلالية"}
- countries: MA
- kinds: dessert

## DISH Q124536476
- name: Boldo ice cream
- description: ice cream with natural or artificial boldo flavoring
- countries: CL
- kinds: ice cream, meal
- ingredients: árnica, ice cream

## DISH Q124538359
- name: Pastel de jaiba
- description: Chilean crab pie
- countries: CL
- kinds: pie, meal
- has Wikipedia article: en

## DISH Q124542509
- name: Alcayota jam with walnuts
- description: traditional fruit preserve in Chilean cuisine
- countries: CL
- kinds: jam, fruit preserves, meal
- ingredients: Cucurbita ficifolia

## DISH Q1245441
- name: Fourme de Montbrison
- other names: {"zh": "蒙布里松奶酪"}
- description: French cheese
- countries: FR
- kinds: blue cheese, French cheese, cow's-milk cheese, farmstead cheese, dairy cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q124544722
- name: Maqui jam
- description: traditional fruit preserve from southern Chile
- countries: CL
- kinds: jam, fruit preserves, meal
- ingredients: Aristotelia chilensis

## DISH Q124545544
- name: Pasta al zozzona
- countries: IT
- kinds: pasta

## DISH Q1245530
- name: Fourme d'Ambert
- other names: {"zh": "昂贝尔奶酪"}
- description: semi-hard French AOC blue cheese, made from raw cow's milk from the Auvergne region of France
- countries: FR
- kinds: blue cheese, French cheese, cow's-milk cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q1245627
- name: Salers
- description: French semi-hard com milk cheese originating from Salers, located in the Massif Central, central France
- countries: FR
- kinds: raw-milk cheese, pressed uncooked cheese, French cheese, cow's-milk cheese, farmstead cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q124574877
- name: Katla Komola
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q1246024
- name: Pecorino Romano PDO
- other names: {"zh": "Pecorino Romano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: pecorino, pressed cooked cheese, cheese
- ingredients: sheep milk
- has Wikipedia article: en

## DISH Q1246101
- name: Dorome
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q124610247
- name: Saucisse de Magland
- other names: {"fr": "Saucisse de Magland"}
- countries: FR
- kinds: sausage

## DISH Q124611159
- name: Macho ruso
- description: Chilean dessert
- countries: CL
- kinds: dessert, meal
- ingredients: orange peel, vanilla extract, corn starch, flour, cinnamon, sugar, milk

## DISH Q124613458
- name: Cha kroeung
- description: Cambodian stir fry dish
- countries: KH
- cuisines: Cambodian cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q124617888
- name: Piada dei morti
- description: sweet bread from Rimini, Italy
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q124620814
- name: Dek Ngor
- description: Ugandan traditional sauce made from split yellow peas and peanut butter
- countries: UG
- kinds: food, sauce
- ingredients: pigeon pea, shea butter, sodium bicarbonate, table salt
- has Wikipedia article: en

## DISH Q124633909
- name: Nepečený dezert
- other names: {"cs": "nepečený dezert"}
- countries: (none)
- kinds: dessert

## DISH Q124637275
- name: Eggs royale
- description: variation of eggs Benedict that uses smoked salmon instead of ham
- countries: (none)
- kinds: dish, open sandwich
- ingredients: smoked salmon, English muffin, egg as food, hollandaise sauce

## DISH Q124637801
- name: Eggs Florentine
- description: eggs Benedict with an addition of spinach
- countries: (none)
- kinds: dish, open sandwich, egg dish
- ingredients: spinach, English muffin, egg as food, hollandaise sauce

## DISH Q124647471
- name: Křenová omáčka
- other names: {"cs": "Křenová omáčka"}
- countries: (none)
- kinds: dish

## DISH Q1246542
- name: Knabbeln
- other names: {"de": "Knabbeln"}
- countries: (none)
- kinds: viennoiserie

## DISH Q124655829
- name: Fried onion burger
- description: burger originated in Oklahoma, United States during the Great Depression
- countries: US
- kinds: hamburger
- ingredients: ground beef, onion
- has Wikipedia article: en

## DISH Q124657230
- name: Torta merengada de frambuesa
- description: Chilean raspberry meringue cake
- countries: CL
- kinds: meal, cake, torte, dessert
- ingredients: egg as food, cream, raspberry, sugar, powdered sugar

## DISH Q1246619
- name: Wickelkloß
- other names: {"de": "Wickelkloß"}
- countries: (none)
- cuisines: cuisine of Thuringia, Ore Mountain cuisine
- kinds: dish

## DISH Q124666564
- name: Queijo cabacinha
- other names: {"pt": "queijo cabacinha"}
- countries: BR
- kinds: food, cheese

## DISH Q1246721
- name: Tarama
- other names: {"zh": "塔拉馬沙律"}
- description: roe-based meze common to Turkey and Greece
- countries: GR, TR
- cuisines: Greek cuisine, Romanian cuisine, Turkish cuisine
- kinds: food, meze, fish dish
- ingredients: olive oil, table salt, roe
- has Wikipedia article: en, zh

## DISH Q124672790
- name: Pickled Atlantic herring
- description: traditional way of preserving Clupea harengus as food
- countries: (none)
- kinds: pickled herring, fish dish
- ingredients: Clupea harengus

## DISH Q1246933
- name: Holsteiner Sauerfleisch
- other names: {"de": "Holsteiner Sauerfleisch"}
- countries: (none)
- kinds: meat dish

## DISH Q124695103
- name: Bothok Mlanding
- description: Indonesian dish
- countries: (none)
- kinds: food, vegetable, dish, Indonesian cuisine, traditional food, type of food or dish

## DISH Q124695139
- name: Fuyunghai
- description: Indonesian dish
- countries: CN
- kinds: food, Indonesian cuisine, side dish, Chinese Indonesian cuisine
- ingredients: egg as food, vegetable, meat

## DISH Q1247120
- name: Digestive biscuit
- other names: {"zh": "消化饼干"}
- description: Scottish semi-sweet biscuit
- countries: GB
- cuisines: British cuisine
- kinds: food, biscuit
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q124714020
- name: Roat
- description: Indian confectionery dish
- countries: (none)
- cuisines: Hyderabadi cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q124715774
- name: とうへい鍋
- other names: {"ja": "とうへい鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q12472602
- name: Asam sunti
- other names: {"id": "Asam sunti"}
- countries: ID
- kinds: food ingredient
- ingredients: Averrhoa bilimbi

## DISH Q124727156
- name: Plum butter
- description: fruit butter made of plums
- countries: (none)
- kinds: fruit butter, spread
- ingredients: Prunus domestica
- has Wikipedia article: en

## DISH Q12472901
- name: Ayam tangkap
- description: Acehnese cuisine made from chicken
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: chicken dish, type of food or dish, food, dish, human food, traditional food
- ingredients: turmeric leaf, shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, ginger, chicken as food, coconut water, cooking oil, Pandanus amaryllifolius, Murraya koenigii, chili pepper, Tamarindus indica, black pepper, table salt

## DISH Q12473144
- name: Bacem
- description: Indonesian kind of dish and also the method to prepare it by adding coconut water and palm sugar to the ingredients
- countries: ID
- kinds: dish, food preparation technique
- ingredients: palm sugar, coconut water

## DISH Q124735765
- name: Kalbsbries Rumohr
- other names: {"de": "Kalbsbries Rumohr"}
- countries: (none)
- kinds: dish

## DISH Q12473632
- name: Yellow tail fish balls
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish
- ingredients: Caesionidae, tapioca, rice vermicelli, Allium ascalonicum, noodle, Allium sativum, table salt, vegetable

## DISH Q12473662
- name: Balado
- description: Indonesian type of hot and spicy spice mixture originating from West Sumatra in Sumatra island
- countries: ID
- cuisines: Padang cuisine
- kinds: dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q124737619
- name: Krabbelurer
- other names: {"sv": "krabbelurer"}
- countries: SE
- kinds: pastry, dessert, sweet dish

## DISH Q124738108
- name: Czech honey standard
- description: Czech honey standard no. CSV 1/1999
- countries: (none)
- kinds: honey, organic matter, food ingredient
- ingredients: nectar, water

## DISH Q124739102
- name: Ampas Tarigu
- description: Traditional sweet bread originating from Maluku mixed with brown sugar and coconut.
- countries: ID
- cuisines: Indonesian cuisine
- kinds: traditional food, type of food or dish, bread, snack, dish, human food
- ingredients: coconut, wheat flour, fermentation starter, margarine, brown sugar

## DISH Q124739175
- name: Bagea
- description: Traditional Indonesian cookies made from sago and mixed with nuts
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, Kuih, traditional food, snack, Cookies
- ingredients: granulated sugar, sago flour, chicken egg, coconut oil, walnut, sodium bicarbonate, peanut, table salt

## DISH Q124739975
- name: Baixaria
- description: Brazilian meal popular in Acre
- countries: (none)
- kinds: dish
- ingredients: cuscuz nordestino, cornmeal, ground beef, fried egg
- has Wikipedia article: en

## DISH Q124744092
- name: Zozulia
- description: sweet millet dish with poppy seeds from Ukraine
- countries: UA
- kinds: porridge, cuisine, legumina, course
- ingredients: butter, sugar, millet porridge, Papaver, egg as food
- has Wikipedia article: en

## DISH Q12475492
- name: Bebek goreng
- description: Indonesian fried duck
- countries: ID
- kinds: duck dish
- ingredients: duck meat

## DISH Q124756658
- name: Thengamuri
- description: Snack food of Kerala
- countries: IN
- kinds: snack

## DISH Q12476145
- name: Bibim naengmyeon
- other names: {"zh": "拌冷面"}
- description: naengmyeon eaten mixed
- countries: (none)
- kinds: naengmyeon
- has Wikipedia article: en

## DISH Q12476646
- name: Tempong
- description: Indonesian food
- countries: ID
- kinds: dish

## DISH Q124768373
- name: Focaccetta quilianese di patate
- other names: {"it": "Focaccetta quilianese di patate"}
- countries: IT
- kinds: focaccia

## DISH Q12476958
- name: Bongko mento
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: cake, food, dish, human food, type of food or dish

## DISH Q12477242
- name: Brayo
- description: Central Javanese traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, food, dish, human food, type of food or dish

## DISH Q12477251
- name: Brenebon
- description: Indonesian traditional soup
- countries: ID
- kinds: soup, steaming, side dish
- ingredients: kidney bean
- has Wikipedia article: en

## DISH Q12478
- name: Macaron
- other names: {"zh": "馬卡龍"}
- description: sweet meringue-based confectionery
- countries: FR
- kinds: sandwich cookie
- ingredients: almond meal, meringue, table salt
- has Wikipedia article: en, zh

## DISH Q12478002
- name: Burasa
- description: Indonesian rice dumpling originally from Sulawesi
- countries: ID
- kinds: snack, side dish, rice dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q12478448
- name: Celimpungan
- description: Indonesian speciality food
- countries: ID
- cuisines: Indonesian cuisine, traditional food
- kinds: soup, fish dish, dish, human food, traditional food, type of food or dish
- ingredients: shallot, tapioca flour, garlic, coconut milk, fish as food, table salt, sugar

## DISH Q12479417
- name: Colenak
- description: a typical Sundanese snack made from tapai that is burned
- countries: ID
- cuisines: Indonesian cuisine
- kinds: cassava-based food, food, dish, snack, human food, type of food or dish
- ingredients: granulated sugar, grated coconut, Tapai, palm sugar, Pandanus amaryllifolius, vanilla, table salt, margarine

## DISH Q124807379
- name: Zigouille-moustique
- other names: {"fr": "zigouille-moustique"}
- countries: (none)
- kinds: French toast, dish

## DISH Q12481242
- name: Dendeng batokok
- other names: {"id": "dendeng batokok"}
- countries: ID
- kinds: beef dish, food
- ingredients: beef, chili pepper

## DISH Q12481254
- name: Dengke Mas Naniura
- description: Indonesian traditional dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fish dish, traditional food, type of food or dish, food, dish, human food
- ingredients: shallot, garlic, turmeric, ginger, Andaliman, peanut, Etlingera elatior, Aleurites moluccanus, chili powder, red onion, Alpinia galanga, chili pepper, Cyprinus carpio, lime, table salt
- has Wikipedia article: en

## DISH Q12481775
- name: Doclang
- description: Indonesian traditional rice cake with peanut sauce dish from Bogor
- countries: ID
- cuisines: Indonesian cuisine
- kinds: rice dish, dish, human food, traditional food, type of food or dish
- ingredients: Indonesian peanut sauces, ketupat

## DISH Q12481779
- name: دودول كاندانجان
- other names: {"ar": "دودول كاندانجان"}
- countries: ID
- kinds: candy
- ingredients: glutinous rice

## DISH Q12483254
- name: Gagodoh
- description: Indonesian traditional filled cake
- countries: ID
- kinds: cake, snack

## DISH Q12483284
- name: Galamai
- description: Indonesian traditional rice flour cake
- countries: (none)
- kinds: dessert, Dodol, confectionery, jajan pasar
- ingredients: palm sugar, coconut milk, glutinous rice

## DISH Q12483520
- name: Garang Asem
- other names: {"jv": "Garang Asem"}
- description: traditional Indonesian food from Central Java, featuring chicken wrapped in banana leaf
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, chicken dish, traditional food, marinating
- ingredients: Indonesian bay leaf, Kaffir Lime Leaf, banana leaf, chicken as food, coconut milk, bird's eye chili, Alpinia galanga, Averrhoa bilimbi, Allium ascalonicum, chili pepper, Cymbopogon citratus, tomato, Allium sativum, table salt, sugar

## DISH Q12484053
- name: Getuk pero
- description: Indonesian traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: cassava, jaggery, Cocos nucifera, table salt

## DISH Q12484057
- name: Getuk Goreng
- countries: ID
- cuisines: Indonesian cuisine, Javanese cuisine
- kinds: dish, human food, type of food or dish
- ingredients: palm sugar, rice flour, coconut milk, cooking oil, cassava, vanilla
- has Wikipedia article: en

## DISH Q12484569
- name: Gulai otak
- description: Indonesian curry-like dish originating from West Sumatra
- countries: ID
- kinds: food, gulai, beef dish, soup
- ingredients: turmeric leaf, Kaffir Lime Leaf, Coconut Cream, garlic, coriander seed, ginger, coconut milk, brain as food, Alpinia galanga, Allium ascalonicum, chili pepper, Curcuma longa, Cymbopogon citratus
- has Wikipedia article: en

## DISH Q12484574
- name: Kuwah itek
- description: Indonesian curry-like dish originating from Aceh
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: food, dish, type of food or dish
- ingredients: caraway seeds, coriander seed, duck meat, Pandanus amaryllifolius, Murraya koenigii

## DISH Q12484575
- name: Kuwah eungkôt yèe
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: food, dish, gulai
- ingredients: shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, coriander seed, coconut, Alpinia galanga, Murraya koenigii, chili pepper, Cymbopogon citratus, shark

## DISH Q124846713
- name: Guiso de Hallaca
- other names: {"es": "Guiso de Hallaca"}
- countries: VE
- kinds: salad, meal, ingredient
- ingredients: cultivated edible plant, meat

## DISH Q124853013
- name: Hot and sour soup noodles
- countries: (none)
- cuisines: Japanese Chinese cuisine
- kinds: noodle dish

## DISH Q12486
- name: Buckwheat pancake
- description: pancake made with buckwheat flour
- countries: (none)
- kinds: crêpe, pancake
- ingredients: buckwheat flour
- has Wikipedia article: en

## DISH Q124861530
- name: Ain sbaniouria
- other names: {"fr": "Ain sbaniouria"}
- countries: (none)
- kinds: dish

## DISH Q12486868
- name: Itak Gurgur
- description: Traditional Batak food
- countries: ID
- cuisines: Indonesian cuisine, Batak cuisine
- kinds: dish, human food, type of food or dish, Kuih
- ingredients: lampet, Cocos nucifera, sugar, rice
- has Wikipedia article: en

## DISH Q124882180
- name: WikiKuharica/Recepti/Soljanka
- other names: {"hr": "WikiKuharica/Recepti/Soljanka"}
- countries: (none)
- kinds: solyanka, recipe

## DISH Q12488280
- name: Kaasstengels
- description: Dutch and Indonesian cheese cookie
- countries: (none)
- kinds: cookie, cheese stick
- ingredients: flour
- has Wikipedia article: en

## DISH Q12489250
- name: Kapurung
- description: a type of soup made from sago starch originated from Palopo in South Sulawesi
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, soup
- ingredients: sago flour, Asparagus bean, maize
- has Wikipedia article: en

## DISH Q12490514
- name: Kelan Antep
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, salad, soup
- ingredients: celery, beef
- has Wikipedia article: en

## DISH Q12491
- name: Mille-feuille
- other names: {"zh": "法式千层酥"}
- description: French pastry
- countries: FR
- cuisines: French cuisine
- kinds: dish, cake
- ingredients: pastry cream, fondant, powdered sugar, puff pastry
- has Wikipedia article: en, zh

## DISH Q12491347
- name: Skin Crackers
- description: traditional Indonesian crackers made of cattle skin
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, snack
- ingredients: cowhide, table salt
- has Wikipedia article: en

## DISH Q12491487
- name: Ketupat kandangan
- description: A coconut sauce ketupat dish with added fish pieces
- countries: ID
- kinds: main course, opor, rice cake

## DISH Q12491642
- name: Getuk kicak
- description: Indonesian traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, jajan pasar
- ingredients: cassava root, brown sugar

## DISH Q1249172
- name: Selles-sur-Cher cheese
- other names: {"zh": "谢尔河畔塞勒奶酪"}
- description: goat-milk cheese from Loir-et-Cher, France
- countries: FR
- kinds: French cheese, goat cheese, raw-milk cheese, farmstead cheese, industrial cheese, natural-rind soft cheese, dairy cheese
- ingredients: goat milk
- has Wikipedia article: en

## DISH Q12491862
- name: Klenyem
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: cassava root, brown sugar

## DISH Q12492558
- name: Krecek
- description: processed dried cowhide food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, traditional food, type of food or dish, sauce
- ingredients: cowhide
- has Wikipedia article: en

## DISH Q12492690
- name: Kuah beulangong
- description: Acehnese goat curry
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, soup, gulai
- ingredients: shallot, turmeric rhizome, garlic, coriander seed, jackfruit, ginger, cardamom, Saba banana, coconut, star anise, Aleurites moluccanus, goat meat, bird's eye chili, Murraya koenigii, chili pepper, nutmeg, Artocarpus heterophyllus, Cymbopogon citratus, cinnamon, table salt

## DISH Q12492824
- name: Pohulpohul
- description: Batak traditional snack
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, snack
- ingredients: brown sugar, coconut, rice flour, Pandanus amaryllifolius
- has Wikipedia article: en

## DISH Q12492825
- name: Lampet
- description: Batak traditional rice cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, snack, rice cake, jajan pasar
- ingredients: glutinous rice flour, grated coconut, banana leaf, palm sugar, rice flour, table salt, sugar, water
- has Wikipedia article: en

## DISH Q12492826
- name: Ombus ombus
- description: traditional Batak culinary
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, jajan pasar, confectionery, kue
- ingredients: brown sugar, rice flour, Cocos nucifera
- has Wikipedia article: en

## DISH Q12492829
- name: Kuping gajah
- description: Indonesian snack with characteristic spiral pattern
- countries: ID
- kinds: snack, jajan pasar
- ingredients: wheat flour, egg as food, sugar

## DISH Q12492830
- name: Kue lumpur
- description: cake of Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, jajan pasar, kue
- ingredients: potato, coconut milk, egg as food, flour, vanilla, sugar, margarine

## DISH Q12492887
- name: Kuluban
- description: Indonesian traditional salad dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, traditional food, type of food or dish, salad, urap
- ingredients: water spinach, potato, carrot
- has Wikipedia article: en

## DISH Q12493188
- name: Kuwah Pliëk U
- description: achenese cuisine from Indonesia
- countries: ID
- cuisines: Acehnese cuisine, Indonesian cuisine
- kinds: dish
- ingredients: chili pepper, Gnetum gnemon, black pepper, peanut, Cymbopogon citratus, table salt, shallot, turmeric rhizome, garlic, coriander seed, jackfruit, ginger, grated coconut, Etlingera elatior, coconut, bamboo shoots, Asparagus bean, bird's eye chili, water spinach, coconut oil

## DISH Q12493538
- name: Laksan
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, soup, fish dish
- ingredients: fish

## DISH Q12493646
- name: Lamang tapai
- other names: {"id": "Lamang tapai"}
- description: Tradisional Minangkabau Dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, glutinous rice, dessert, Tapai
- ingredients: fermentation starter, brown rice, coconut milk, glutinous rice, sugar

## DISH Q12494
- name: Savoiarde PAT
- other names: {"zh": "Savoiarde PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good, biscuit
- ingredients: sponge cake
- has Wikipedia article: en, zh

## DISH Q12494048
- name: Green Caviar
- description: a type of green seaweed from the Caulerpa genus (often called seaweed)
- countries: (none)
- kinds: food, dish, traditional food

## DISH Q12494333
- name: Lema
- description: fermented bamboo shoot dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, side dish, fermented food, fish dish
- ingredients: bamboo shoots, fish as food, chili pepper, table salt

## DISH Q12494522
- name: Lentog
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, lontong
- ingredients: Oryza molida, table salt

## DISH Q12494545
- name: Lepat jagung
- other names: {"ms": "Lepat jagung"}
- description: Javanese snack
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, snack, human food, traditional food, type of food or dish, confectionery
- ingredients: granulated sugar, cassava root, husk, grated coconut, corn starch, maize, table salt

## DISH Q12495289
- name: Lontong kikil
- description: Indonesian cuisine
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish
- ingredients: granulated sugar, Indonesian bay leaf, shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, ginger, cow's trotters, lontong, Aleurites moluccanus, Kaempferia galanga, bird's eye chili, broth, palm oil, chili pepper, wrench, black pepper, Coriandrum sativum, Cymbopogon citratus, Carum carvi, table salt, water

## DISH Q12495292
- name: Lontong kupang
- description: food from East Java
- countries: (none)
- kinds: food, dish, traditional food, meal
- ingredients: petis, lontong, Mytilus edulis

## DISH Q124954605
- name: Kismur
- description: Goan prawns dish
- countries: IN
- kinds: side dish, salad
- ingredients: dried shrimp, vegetable

## DISH Q12496028
- name: Madumongso
- description: Indonesian sweet snack
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, snack, confectionery, human food, traditional food, type of food or dish, jajan pasar
- ingredients: palm sugar, coconut milk, glutinous rice, table salt, water
- has Wikipedia article: en

## DISH Q124963159
- name: Vulve de truie
- other names: {"fr": "vulve de truie"}
- countries: (none)
- kinds: dish

## DISH Q12496728
- name: Mangut Lele
- description: Indonesian fish soup
- countries: ID
- kinds: ikan bakar
- ingredients: Clarias

## DISH Q12496810
- name: Manuk Napinadar
- description: Bataknese dish from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, chicken dish
- ingredients: shallot, Kaffir Lime Leaf, Ayam Kampong, Andaliman, coconut, Aleurites moluccanus, bird's eye chili, Alpinia galanga, Citrus × aurantiifolia, Curcuma longa, ginger, Cymbopogon citratus, Allium sativum, table salt
- has Wikipedia article: en

## DISH Q124971399
- name: Torta de Guimarães
- description: Typical tart of Guimarães, Portugal
- countries: PT
- kinds: pastry

## DISH Q12497149
- name: Acehnese Murtabak
- description: A dish that has a savory taste and is rich in spices
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: food, dish, snack, human food, type of food or dish, Mutabak, Egg martabak
- ingredients: cabbage, roti canai, scallion, cooking oil, broth, chili pepper, egg as food, black pepper, table salt, margarine

## DISH Q12497220
- name: Masam keueueng
- description: soup dish from Aceh, Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, type of food or dish, soup
- ingredients: shallot, turmeric rhizome, garlic, ginger, Spanish mackerel, Thunnus tonggol, Lutjanidae, Chanos chanos, Averrhoa bilimbi, chili pepper, orange

## DISH Q12498026
- name: Mendol
- description: processed tempeh
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, traditional food, type of food or dish, Tempeh
- ingredients: coriander seed, galangal, Tempeh, table salt, soybean

## DISH Q12498031
- name: Mendoan
- description: Indonesian fritter made of tempeh
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, traditional food, fried tempeh
- ingredients: Tempeh, Allium tuberosum
- has Wikipedia article: en

## DISH Q12498071
- name: Menjes
- description: Indonesian traditional food made of beans, originating in Malang, East Java
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, fritter, dish, human food, traditional food, type of food or dish

## DISH Q124984623
- name: Mousse cake
- description: type of cake
- countries: (none)
- kinds: cake

## DISH Q12498465
- name: Mi ongklok
- countries: ID
- kinds: food, dish, traditional food

## DISH Q12498712
- name: Model (food)
- description: traditional dish food from Palembang
- countries: ID
- cuisines: Indonesian cuisine, Palembang cuisine
- kinds: food, dish, human food, traditional food, type of food or dish, soup, fish dish

## DISH Q12498863
- name: Moka (makanan)
- other names: {"id": "Moka (makanan)"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, traditional food, type of food or dish
- ingredients: rice flour, tapioca

## DISH Q12499048
- name: Moto Belong
- other names: {"id": "Moto Belong"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, traditional food, type of food or dish
- ingredients: cassava

## DISH Q12500148
- name: Ambeng Rice
- description: Javanese rice dish originating from Malaysia
- countries: ID
- cuisines: Javanese cuisine
- kinds: food, dish
- has Wikipedia article: en

## DISH Q12500149
- name: Nasi boranan
- other names: {"id": "Nasi boranan"}
- countries: ID
- kinds: food, dish, traditional food

## DISH Q12500151
- name: Nasi gandul
- description: Indonesian soup
- countries: ID
- cuisines: Indonesian cuisine, Javanese cuisine
- kinds: food, dish, human food, traditional food, type of food or dish
- ingredients: Aleurites moluccanus, shrimp paste, Kaempferia galanga, Kaffir Lime Leaf, garlic, caraway seeds, ginger, kecap manis, palm sugar, coconut milk, beef, chili pepper, nutmeg, Coriandrum sativum, Cymbopogon citratus, table salt, water, Indonesian bay leaf, shallot
- has Wikipedia article: en

## DISH Q12500153
- name: Nasi jagung
- description: Indonesian maize dish
- countries: ID
- kinds: food, dish, traditional food

## DISH Q12500155
- name: Nasi tempong
- description: Indonesian rice dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, traditional food, type of food or dish, rice dish
- ingredients: fried tempeh, Fried fish, tahu goreng, bakwan, Indonesian peanut sauces, Holy Basil, cooked rice, Cosmos, bird's eye chili, Amaranthus, tomato
- has Wikipedia article: en

## DISH Q125002715
- name: Konnyaku
- description: food made from the corm of konjac
- countries: JP
- kinds: processed food
- ingredients: konjac flour, sodium carbonate, calcium hydroxide, glucomannan

## DISH Q12500903
- name: Nopia
- description: Indonesian snack from Purbalinga
- countries: ID
- cuisines: snack, Indonesian cuisine
- kinds: dish, snack, human food, traditional food, type of food or dish
- ingredients: brown sugar, wheat flour, table salt, sugar

## DISH Q12501427
- name: Jepara grilled opor
- description: Jepara style grilled opor
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish
- ingredients: granulated sugar, Indonesian bay leaf, shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, ginger, palm sugar, Aleurites moluccanus, chicken as food, coconut milk, cooking oil, Alpinia galanga, black pepper, Coriandrum sativum, table salt, water

## DISH Q12501711
- name: Pacco'
- description: Indonesian traditional raw fish dish
- countries: ID
- kinds: food, raw fish dish

## DISH Q12502
- name: Charlotte
- other names: {"zh": "夏洛緹"}
- description: dessert
- countries: FR
- kinds: dessert
- ingredients: sponge cake, custard, egg as food, bread
- has Wikipedia article: en, zh

## DISH Q125030544
- name: Cream of sorrel soup
- description: traditional French springtime food
- countries: FR
- cuisines: French cuisine
- kinds: dish, vegetable soup
- has Wikipedia article: en

## DISH Q125042945
- name: Andijviestamppot
- other names: {"nl": "andijviestamppot"}
- countries: NL
- cuisines: Dutch cuisine
- kinds: food, potato, Stamppot, endive
- ingredients: endive, potato

## DISH Q12505357
- name: Petis runting
- description: Central Javanese food
- countries: (none)
- kinds: food, goat meat dish

## DISH Q12505590
- name: Pindang Serani
- description: Indonesian traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: seafood, dish, human food, type of food or dish
- ingredients: tamarind juice, saltwater fish, Holy Basil, Pangasiidae, Chanos chanos, Citrus × aurantiifolia, table salt

## DISH Q125055902
- name: Sweet tart
- description: open pie which is not salty
- countries: (none)
- kinds: tart, sweet pie

## DISH Q12505591
- name: Water buffalo pindang
- description: Water buffalo pindang dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish

## DISH Q125056425
- name: Custard dessert
- countries: (none)
- kinds: dessert
- ingredients: custard

## DISH Q12505887
- name: Poci (makanan)
- other names: {"id": "Poci (makanan)"}
- countries: ID
- kinds: dish

## DISH Q125059439
- name: Walnut cake with egg yolk glaze
- description: Czech and Slovak festive cake
- countries: (none)
- kinds: cake
- ingredients: chicken egg, walnut, butter, sugar
- has Wikipedia article: en

## DISH Q12507089
- name: Pulut kuning
- description: yellow glutinous rice dish
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: food, sweetmeat, human food, rice dish
- ingredients: turmeric leaf, shallot, Kaffir Lime Leaf, vegetable oil, banana leaf, Thunnus tonggol, Aleurites moluccanus, Holy Basil, coconut milk, bird's eye chili, Pandanus amaryllifolius, chili pepper, glutinous rice, Cymbopogon citratus, Allium sativum, table salt, banana

## DISH Q125072181
- name: Sweet potato ball
- other names: {"zh": "地瓜球"}
- description: Taiwanese snack
- countries: TW
- kinds: snack
- has Wikipedia article: en

## DISH Q12507469
- name: Putu sagu
- other names: {"id": "Putu sagu"}
- countries: ID
- cuisines: Indonesian cuisine, Javanese cuisine
- kinds: dish, snack, human food, type of food or dish, jajan pasar
- ingredients: granulated sugar, sago flour, palm sugar, rice flour, coconut milk, Pandanus amaryllifolius, table salt

## DISH Q12507493
- name: Pyeonsu
- description: Korean dumpling
- countries: KP
- cuisines: North Korean cuisine
- kinds: cold dishes, dumpling
- has Wikipedia article: en

## DISH Q125075048
- name: Savoury tart
- description: open pie which is not sweet
- countries: (none)
- kinds: tart, savoury pie

## DISH Q12508407
- name: Rempah Jepara
- description: Indonesian traditional dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: egg as food

## DISH Q12508588
- name: Rica-rica
- description: Indonesian type of hot and spicy spice mixture
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, bumbu
- ingredients: shallot, Kaffir Lime Leaf, garlic, bird's eye chili, chili pepper, black pepper, Cymbopogon citratus, tomato, table salt, sugar
- has Wikipedia article: en

## DISH Q12508894
- name: Rondho royal
- description: a traditional dish from Jepara made from fermented cassava (tapai), coated in wheat flour batter, and deep-fried
- countries: ID
- cuisines: Indonesian cuisine
- kinds: cookie, dish, snack, human food, type of food or dish
- ingredients: Tapai, rice flour

## DISH Q12509008
- name: Rujak kuah pindang
- description: Indonesian traditional cuisine
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, rojak
- ingredients: Indonesian bay leaf, Euthynnus affinis, palm sugar, shrimp paste, Pachyrhizus erosus, Spondias dulcis, Alpinia galanga, chili pepper, Tamarindus indica, Carica papaya, Cymbopogon citratus, Syzygium malaccense, table salt, Ananas comosus, mango

## DISH Q12509009
- name: Rujak manis
- description: Indonesian traditional cuisine made from various tropical fruit and use sweet peanut sauce
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, confectionery, human food, type of food or dish
- ingredients: brown sugar, pineapple, coconut sugar, Mangifera indica, peanut, cucumber, shrimp paste, mineral water, beet, chili pepper, Cucumis melo, Syzygium aqueum, table salt, Ananas comosus, mango

## DISH Q12509010
- name: Rujak soto
- description: Indonesian traditional cuisine
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish
- ingredients: Kaffir Lime Leaf, celery, garlic, petis, peanut, lontong, palm sugar, scallion, tripe, Alpinia galanga, beef, tofu, Curcuma longa, ginger, Cymbopogon citratus, table salt, sugar, banana
- has Wikipedia article: en

## DISH Q1250997
- name: Pretzel sticks
- description: food
- countries: (none)
- kinds: snack, baked good
- ingredients: wheat flour, lye, baker's yeast, sodium chloride
- has Wikipedia article: en

## DISH Q125101000
- name: Gan Guê To
- other names: {"zh": "酵粿桃"}
- description: snack of Chaoshan
- countries: (none)
- kinds: xiaochi
- ingredients: syrup, rice milk, peanut
- has Wikipedia article: en, zh

## DISH Q12511758
- name: Sambal goreng
- description: Indonesian dish
- countries: ID
- kinds: dish, side dish
- ingredients: Indonesian bay leaf, shallot, garlic, shrimp paste, chili pepper, sambal

## DISH Q12511759
- name: Sambal tuktuk
- description: Indonesian spicy sauce with andaliman seasoning
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, sambal
- ingredients: shallot, garlic, tomato, Andaliman, Aleurites moluccanus, bird's eye chili, cooking oil, Engraulidae, table salt, sugar
- has Wikipedia article: en

## DISH Q12512184
- name: Sarang madu
- other names: {"id": "Sarang madu"}
- countries: ID
- kinds: dish, confectionery, fried food
- ingredients: glutinous rice flour, coconut milk, sugar

## DISH Q12512314
- name: Buffalo satay, kudus
- description: dish from Kudus, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay
- ingredients: satay sauce, bison meat, coriander seed, coconut, palm sugar

## DISH Q12512315
- name: Ponorogo satay
- description: traditional food from Ponorogo, Indonesia
- countries: (none)
- kinds: food, dish, Indonesian cuisine, human food, satay
- ingredients: shallot, caraway seeds, coriander seed, peanut, kecap manis, palm sugar, Aleurites moluccanus, chicken as food, Allium sativum, table salt, sugar

## DISH Q12512316
- name: Tegal satay
- description: Indonesian food from Tegal and Slawi
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay
- ingredients: shallot, tomato, peanut, kecap manis, goat meat, chili pepper, Ananas comosus

## DISH Q12512317
- name: Sate buntel
- description: Food from Surakarta made by meat
- countries: ID
- cuisines: Javanese cuisine
- kinds: dish, satay
- ingredients: kecap manis, palm sugar, caul fat, goat meat, Allium ascalonicum, black pepper, Allium sativum

## DISH Q12512318
- name: Satay kalong
- description: buffalo meat satay dish from Cirebon
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay, grilling
- ingredients: bison meat, garlic, coriander seed, peanut, kecap manis, palm sugar, Allium ascalonicum, Citrus × aurantiifolia, chili pepper, table salt

## DISH Q12512320
- name: Penyu satay
- description: Indonesian dish from Bali
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, satay

## DISH Q12512533
- name: Sayur asam Jepara
- other names: {"id": "Sayur asam Jepara"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish
- ingredients: Luffa acutangula, Asparagus bean, maize

## DISH Q12512535
- name: Sayur kangkung santan
- other names: {"id": "Sayur kangkung santan"}
- countries: ID
- kinds: dish

## DISH Q12512536
- name: Buah keluak
- other names: {"zh": "黑果"}
- description: seed of Pangium edule
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, seed
- ingredients: onion, Parkia speciosa, sauce, tomato, hydrogen cyanide
- has Wikipedia article: en

## DISH Q125132141
- name: Stuffed dessert
- countries: (none)
- kinds: dessert, stuffed food

## DISH Q125132965
- name: Buchweizentorte
- other names: {"de": "Buchweizentorte"}
- countries: (none)
- cuisines: Lower Saxon cuisine
- kinds: dish, cake

## DISH Q12513509
- name: Semur Jepara
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: onion, chili pepper, ginger, meat

## DISH Q125144495
- name: Frühlingsquark
- other names: {"de": "Frühlingsquark"}
- countries: (none)
- kinds: dish

## DISH Q12515251
- name: Singit
- other names: {"id": "Singit"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: Aspergillus wentii, onion, coconut milk, meat

## DISH Q12515321
- name: Siomay tongkol
- other names: {"id": "siomay tongkol"}
- description: Indonesian cuisine
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: Maizena, Euthynnus affinis, tapioca, table salt

## DISH Q12516001
- name: Soto Banjar
- description: Banjarmasin typical dishes
- countries: ID
- cuisines: Indonesian cuisine
- kinds: type of food or dish, soto
- ingredients: shallot, garlic, Ayam Kampong, ginger, Illicium verum, cellophane noodles, scallion, walnut, Elettaria cardamomum, clove, onion, lime, table salt, sugar, carrot

## DISH Q12516002
- name: Soto Jepara
- description: Indonesian chicken soup dish that contain beef
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, soup, soto
- ingredients: kecap, shallot, Kaffir Lime Leaf, celery, garlic, mung bean sprout, chicken as food, Citrus × aurantiifolia, Allium tuberosum, table salt, sugar

## DISH Q12516003
- name: Soto Kediri
- description: Chicken soup with coconut milk sauce
- countries: (none)
- kinds: food, soup, soto

## DISH Q12516004
- name: Soto Betawi
- description: Indonesian soup containing beef and offal
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, soto
- ingredients: coconut milk, Citrus hystrix, Alpinia galanga, herb, beef, chili pepper, nutmeg, Gnetum gnemon, emping, Cymbopogon citratus, cinnamon, meat, carrot, garlic, tomato, potato, salt and pepper, palm sugar

## DISH Q12516005
- name: Candlenut soup
- description: Soto from Pati Regency, Central Java, with yellow broth seasoned with candlenut, coconut milk, and chicken
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, soto
- ingredients: cabbage, seedling, cooked rice, Citrus × aurantiifolia, Apium graveolens, tomato

## DISH Q12516006
- name: Soto Kudus
- description: clear soup with shredded chicken or buffalo meat
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, soto, meal
- ingredients: Indonesian bay leaf, kecap, shallot, buffalo meat, garlic, ginger, mung bean sprout, Cymbopogon, Aleurites moluccanus, Alpinia galanga, Allium ascalonicum, Curcuma longa, Cymbopogon citratus, Allium sativum, table salt

## DISH Q12516007
- name: Soto Lamongan
- description: Indonesian chicken dish
- countries: ID
- cuisines: Javanese cuisine
- kinds: soto, chicken dish
- ingredients: Kaffir Lime Leaf, garlic, tomato, chicken egg, ginger, Aleurites moluccanus, chicken as food, cellophane noodles, Curcuma longa, Brassica oleracea var. capitata, Cymbopogon citratus, table salt

## DISH Q12516008
- name: Soto Sokaraja
- description: Type of traditional soup dish from Banyumas, Indonesia
- countries: (none)
- kinds: food, soup, soto

## DISH Q12516009
- name: Seasoning soup
- description: Jepara's signature soup made with beef offal and meat without coconut milk
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, soto
- ingredients: Çeker, Indonesian bay leaf, Kaffir Lime Leaf, tomato, chicken

## DISH Q12516011
- name: Soup manggala
- description: Soto dish with basic ingredients of cassava and chicken feet
- countries: ID
- kinds: food, soup, boiling
- ingredients: shallot, cassava root, garlic, ginger, chicken as food, cellophane noodles, scallion, egg as food, Apium graveolens, cinnamon, carrot

## DISH Q12516012
- name: Pangkong squid
- description: a typical Pontianak snack, consisting of dried squid that has been roasted
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, seafood
- ingredients: onion, Teuthida

## DISH Q125167827
- name: Frozen pizza
- description: pizza stored at a low temperature
- countries: (none)
- kinds: frozen food
- has Wikipedia article: en

## DISH Q125169624
- name: Šumienkový zákusok
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q12518255
- name: Suwar-suwir
- description: snacks originating from Jember made from fermented cassava
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, confectionery, kue
- ingredients: Tapai, coconut milk, flour, sugar

## DISH Q12518570
- name: Tahu kecap
- other names: {"id": "Tahu kecap"}
- countries: ID
- kinds: dish

## DISH Q12518573
- name: Tahu petis
- description: Tofu patis from Indonesia
- countries: (none)
- kinds: food, dish, traditional food

## DISH Q12518675
- name: Kue talam
- description: Indonesian coconut tray cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, kue, Kuih
- ingredients: wheat flour, rice flour, tapioca, coconut milk, table salt, sugar
- has Wikipedia article: en

## DISH Q125195655
- name: Blauwe hap
- other names: {"nl": "Blauwe hap"}
- countries: ID
- kinds: Indonesian-Dutch cuisine, food, meal

## DISH Q125199752
- name: Espumilla
- description: Ecuadorian whipped dessert
- countries: EC
- kinds: dessert
- ingredients: fruit, egg, sugar
- has Wikipedia article: en

## DISH Q12520827
- name: Tengkleng
- description: Surakarta's goat stew
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, stew, goat meat dish
- ingredients: Tilia leaf, bay leaf, coconut milk, goat meat, Cymbopogon citratus

## DISH Q12520862
- name: Tenteng Malino
- other names: {"id": "Tenteng Malino"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, snack
- ingredients: palm sugar, peanut

## DISH Q12521504
- name: Timlo
- description: traditional soup dish from Surakarta, Central Java, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, soup, soto
- ingredients: Kaffir Lime Leaf, garlic, chicken egg, ginger, onion, chicken as food, cellophane noodles, scallion, soy sauce, sausage, table salt, carrot

## DISH Q12522064
- name: Squid Tongseng
- description: Indonesian traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish

## DISH Q12522244
- name: Trancam
- description: typical dish of Central Java
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q12522818
- name: Tutug oncom rice
- description: Sundanese rice dish from Indonesia
- countries: (none)
- kinds: food, dish, traditional food, rice dish
- has Wikipedia article: en

## DISH Q12523907
- name: Wajik
- other names: {"zh": "黑糯米糕"}
- description: Javanese traditional cake from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, meal, human food, type of food or dish, snack, jajan pasar
- ingredients: white sugar, palm sugar, coconut milk, Pandanus amaryllifolius, glutinous rice, table salt, brown sugar
- has Wikipedia article: en

## DISH Q12524380
- name: Wedang blung
- other names: {"id": "Wedang blung"}
- countries: ID
- kinds: dish

## DISH Q12525027
- name: Sweet Peanut sticky rice
- description: Indonesian snack made of glutinous rice flour
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, glutinous rice cake
- ingredients: glutinous rice flour, sugar, water

## DISH Q12526065
- name: Kazakh kurt
- description: Type of yogurt made from raw or boiled milk
- countries: KZ
- cuisines: Kazakh cuisine
- kinds: dairy product, yogurt
- ingredients: cow's milk

## DISH Q125276782
- name: Honigkuchen
- description: German gingerbread with more than 50 % honey
- countries: (none)
- kinds: gingerbread
- ingredients: honey

## DISH Q125289631
- name: Tikin Xic
- description: Mexican style of fish preparation from the Yucatan
- countries: MX
- kinds: fish dish
- ingredients: banana leaf, European seabass, chili pepper, Bixa orellana
- has Wikipedia article: en

## DISH Q125300992
- name: Sträselkucha
- other names: {"de": "Sträselkucha"}
- countries: (none)
- kinds: streuselkuchen, literary work

## DISH Q125317286
- name: Kamiyo ame
- countries: (none)
- kinds: Miyagegashi, bekkō candy

## DISH Q12531830
- name: Ақлақ
- other names: {"kk": "Ақлақ"}
- description: Milk dish
- countries: KZ
- kinds: dish
- ingredients: cow's milk, sheep milk cheese

## DISH Q12532132
- name: Aqta
- description: Kazakh dish
- countries: KZ
- kinds: dish
- ingredients: cow's milk

## DISH Q125338768
- name: Corn dough
- description: dough made from maize in Ghana
- countries: GH
- kinds: food, dough
- ingredients: maize

## DISH Q125338821
- name: Cassava dough
- description: dough made from cassava
- countries: GH
- kinds: food, dough
- ingredients: cassava root

## DISH Q125345402
- name: Minestra maritata
- other names: {"it": "minestra maritata"}
- countries: (none)
- cuisines: cuisine of Piedmont
- kinds: minestra

## DISH Q12535119
- name: Sauce bercy
- description: French sauce
- countries: FR
- kinds: sauce
- ingredients: fish stock, Allium ascalonicum, velouté sauce, butter, white wine
- has Wikipedia article: en

## DISH Q125357007
- name: Cheese zombie
- description: baked breadroll filled with melted cheese
- countries: US
- kinds: baked good
- has Wikipedia article: en

## DISH Q12535788
- name: Bodyk
- description: Kazakh meat dish
- countries: KZ
- cuisines: Kazakh cuisine
- kinds: meat dish

## DISH Q125360394
- name: Five-spice powder flavored minced pork spicy curry
- countries: (none)
- kinds: Japanese curry rice

## DISH Q12536087
- name: Борканник
- other names: {"kk": "Борканник"}
- countries: RU
- cuisines: Russian cuisine
- kinds: pie
- ingredients: rye flour, wheat flour, boiled egg, carrot

## DISH Q125362154
- name: Taiwan Mince
- countries: (none)
- kinds: minced food ball

## DISH Q125362207
- name: Sara Taiwan
- countries: (none)
- kinds: dish

## DISH Q125372014
- name: Cheese ball
- description: American hors d'oeuvre
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q125372981
- name: Pasta del cornuto
- other names: {"it": "pasta del cornuto"}
- countries: IT
- kinds: dish
- ingredients: peppercorn, butter, spaghetti

## DISH Q12537353
- name: Bokpe
- description: Kazakh national dish
- countries: KZ
- cuisines: Kazakh cuisine
- kinds: dish
- ingredients: cow's milk, flour

## DISH Q125376017
- name: Œufs Polignac
- other names: {"fr": "œufs Polignac"}
- countries: (none)
- kinds: egg dish

## DISH Q125376078
- name: Œufs à l'oseille
- other names: {"fr": "œufs à l'oseille"}
- countries: (none)
- kinds: egg dish

## DISH Q125390344
- name: Ensopado uruguayo
- other names: {"es": "Ensopado uruguayo"}
- countries: (none)
- kinds: dish
- ingredients: noodle, vegetable, meat

## DISH Q12539537
- name: Граус
- other names: {"kk": "Граус"}
- description: English cuisine dish
- countries: GB
- cuisines: English cuisine
- kinds: dish, meat dish
- ingredients: quail meat

## DISH Q12539586
- name: Grechanyky
- description: Ukrainian dish
- countries: BY, UA
- kinds: dish, cutlet
- ingredients: buckwheat seed
- has Wikipedia article: en

## DISH Q12539685
- name: Гурули
- other names: {"kk": "Гурули"}
- countries: (none)
- kinds: dish

## DISH Q12539849
- name: Дадли
- other names: {"kk": "Дадли"}
- description: Sweets
- countries: (none)
- kinds: sweet dish, sweetmeat

## DISH Q12539904
- name: Dalan
- description: Buryat and Kalmyk dish
- countries: MN
- cuisines: Mongolian cuisine, Kalmyk cuisine
- kinds: dish
- ingredients: Horse fat, bone

## DISH Q12542057
- name: Yerma
- description: Uzbek soup made from lamb, wheat and onions
- countries: UZ
- kinds: soup
- ingredients: wheat, onion, lamb meat

## DISH Q125421625
- name: Calleiro
- other names: {"es": "calleiro"}
- countries: (none)
- cuisines: Galician cuisine
- kinds: human food

## DISH Q125427837
- name: Tokyo Dome Monaka Ice
- countries: (none)
- kinds: ice cream, monaka, diet

## DISH Q12544534
- name: Zhent
- description: national dish of Kazakhs and Bashkirs
- countries: (none)
- kinds: dish
- ingredients: white sugar, clarified butter, quark, millet, raisin, honey

## DISH Q125451968
- name: Viennese
- description: sicilian dessert
- countries: IT
- kinds: dessert, confectionery

## DISH Q1254524
- name: Gentian
- description: distilled alcoholic beverage made with the gentian flower
- countries: AT, CH, DE, FR, IT
- kinds: digestif, liquor
- has Wikipedia article: en

## DISH Q125457823
- name: Kampot Pepper Crab
- description: Cambodian stir fry seafood dish
- countries: KH
- cuisines: Cambodian cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q12545958
- name: Жұмыр
- other names: {"kk": "Жұмыр"}
- description: Traditional Kazakh dish
- countries: KZ
- cuisines: Kazakh cuisine
- kinds: dish
- ingredients: garlic, peppercorn, rice, carrot

## DISH Q12546221
- name: Sulze
- description: meat dish
- countries: RU
- kinds: dish, food, Sülzwurst

## DISH Q125475914
- name: Banana cream pie
- description: American dessert pie
- countries: (none)
- kinds: pie
- has Wikipedia article: en

## DISH Q125480948
- name: Cheese dessert of Biga
- description: Turkish dessert
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q125486982
- name: 薄皮包子
- countries: (none)
- kinds: baozi
- has Wikipedia article: zh

## DISH Q125491052
- name: Ofe Uda
- description: an igbo native soup
- countries: (none)
- kinds: soup

## DISH Q125495960
- name: دجاج محمر
- other names: {"ar": "دجاج محمر"}
- countries: MA
- kinds: type of food or dish, roast chicken

## DISH Q125501509
- name: Euneobap
- description: Korean sweetfish rice dish
- countries: KR
- kinds: fish dish, rice dish, bap
- ingredients: Plecoglossus altivelis, rice

## DISH Q12550178
- name: Кулис
- other names: {"kk": "Кулис"}
- description: seasoning sauce
- countries: KZ
- kinds: condiment, seasoning sauce

## DISH Q125508762
- name: Ofe Ujuju (Anima)
- description: an Igbo soup from the south eastern part of Nigeria
- countries: NG
- kinds: soup

## DISH Q125520577
- name: Maâjoune tbassa
- other names: {"fr": "maâjoune tbassa"}
- countries: (none)
- kinds: confiture, dish

## DISH Q125523765
- name: Ofé Ọgbọnọ
- description: a soup of the Igbo people.
- countries: NG
- kinds: soup

## DISH Q12552639
- name: Малма
- other names: {"kk": "Малма"}
- description: ingredient
- countries: KZ
- cuisines: Kazakh cuisine
- kinds: food ingredient
- ingredients: ayran, bran, egg yolk, flour

## DISH Q125526587
- name: Melezitose honey
- countries: (none)
- kinds: honey, organic matter
- ingredients: honeydew, melezitose, water

## DISH Q12553023
- name: Mastava
- description: Central Asian dish
- countries: TJ
- cuisines: Cuisine of Uzbekistan, Tajik cuisine
- kinds: dish
- ingredients: Oryza
- has Wikipedia article: en

## DISH Q1255306
- name: Dragée
- other names: {"zh": "喬丹杏仁"}
- description: Confectionery
- countries: (none)
- kinds: candy
- ingredients: almond
- has Wikipedia article: en

## DISH Q125531354
- name: Double ice pops
- description: ice pop with two sticks
- countries: (none)
- kinds: ice pop

## DISH Q125534940
- name: 馬肉ラーメン
- other names: {"ja": "馬肉ラーメン"}
- countries: JP
- kinds: ramen
- ingredients: horse meat

## DISH Q125549453
- name: Zajiangmian
- other names: {"zh": "杂酱面"}
- description: Sichuanese noodle dish
- countries: (none)
- kinds: noodle dish
- has Wikipedia article: en, zh

## DISH Q125549954
- name: Leg soup
- description: Yemenite dish
- countries: YE
- kinds: soup
- ingredients: beef

## DISH Q125552052
- name: Mderbel
- other names: {"fr": "Mderbel"}
- description: Traditional Algerian dish
- countries: MA
- cuisines: Moroccan cuisine
- kinds: dish

## DISH Q125552121
- name: Stingless bees honey
- description: animal product
- countries: (none)
- kinds: honey, animal product
- ingredients: nectar

## DISH Q12555946
- name: Nawat
- description: Type of candy
- countries: (none)
- kinds: sweetmeat
- ingredients: sugar

## DISH Q12555954
- name: Nauryz kozhe
- other names: {"zh": "冲克缺"}
- description: Uyghur/Kazakh/Kyrgyz congee
- countries: KG, KZ
- kinds: dish, soup, Köje
- has Wikipedia article: en

## DISH Q12556365
- name: Nisholda
- description: sweet food native to Central Asia
- countries: AF, IR
- cuisines: Iranian cuisine, Afghan cuisine, Cuisine of Uzbekistan, Tajik cuisine
- kinds: sweetmeat
- ingredients: sugar, water, soap root, citric acid, egg as food
- has Wikipedia article: en

## DISH Q125563966
- name: Piedrazo
- other names: {"fr": "piedrazo"}
- countries: (none)
- kinds: dish

## DISH Q125564202
- name: بنيون
- other names: {"ar": "بنيون"}
- countries: (none)
- kinds: dish

## DISH Q125564344
- name: سكباج سردين
- other names: {"ar": "سكباج سردين"}
- countries: (none)
- kinds: dish

## DISH Q125565576
- name: Judru
- other names: {"fr": "Judru"}
- countries: (none)
- kinds: dish

## DISH Q12556938
- name: Ovdukh
- description: Yogurt soup with vegetables in Azerbaijani cuisine
- countries: AZ
- cuisines: Azerbaijani cuisine
- kinds: dish, soup, fermented milk products, other than sour cream and cottage cheese
- ingredients: chicken egg, onion, yogurt

## DISH Q125570447
- name: Salade parisienne
- countries: (none)
- kinds: dish

## DISH Q125573160
- name: Kpogilo
- description: Food for Dagaaba's
- countries: GH
- kinds: food, human food
- ingredients: complementary feeding

## DISH Q125575991
- name: Lunette de Verviers
- other names: {"fr": "lunette de Verviers"}
- countries: (none)
- kinds: dish

## DISH Q125582095
- name: Psari plaki
- countries: GR
- cuisines: Greek cuisine
- kinds: dish

## DISH Q125584438
- name: Salade alsacienne
- countries: (none)
- kinds: composed salad

## DISH Q125590895
- name: Sii
- other names: {"fr": "sii"}
- countries: (none)
- kinds: dish

## DISH Q125591430
- name: Podingue dunkerquois
- other names: {"fr": "podingue dunkerquois"}
- countries: (none)
- kinds: pudding

## DISH Q125591448
- name: Polenta e crauti
- other names: {"fr": "polenta e crauti"}
- countries: (none)
- kinds: choucroute garnie, dish

## DISH Q125591596
- name: Cooked apple
- countries: (none)
- kinds: dish
- ingredients: cooking apple
- has Wikipedia article: en

## DISH Q125600660
- name: Salade aveyronnaise
- countries: (none)
- kinds: composed salad

## DISH Q12560709
- name: Салма
- other names: {"kk": "Салма"}
- description: Tatar dish
- countries: (none)
- cuisines: Tatarstan cuisine
- kinds: dish, pasta dish

## DISH Q125612873
- name: Bouchon au marc de Champagne
- other names: {"fr": "Bouchon au marc de Champagne"}
- countries: (none)
- kinds: sweetmeat

## DISH Q125619299
- name: صخرة الجوز
- other names: {"ar": "صخرة الجوز"}
- countries: (none)
- kinds: pastry

## DISH Q125625897
- name: Push-up ice cream
- description: type of ice cream that can be pushed up using a cylinder mechanism
- countries: (none)
- kinds: food, gelato

## DISH Q125625919
- name: フランスパン
- other names: {"ja": "フランスパン"}
- countries: (none)
- kinds: bread

## DISH Q125625960
- name: フランスのパン
- other names: {"ja": "フランスのパン"}
- countries: (none)
- kinds: bread

## DISH Q12562815
- name: Sauté
- description: dish
- countries: (none)
- kinds: dish

## DISH Q125634678
- name: レモン料理
- other names: {"ja": "レモン料理"}
- countries: (none)
- kinds: dish

## DISH Q125635868
- name: Mishṭāʿ al-ǧrīsh
- description: Lebanese flatbread
- countries: LB
- kinds: bread, flatbread
