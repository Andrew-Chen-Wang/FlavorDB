# Review batch names-002

## DISH Q105658946
- name: Nimpatar shukto
- description: Bengali cuisine
- countries: (none)
- kinds: Shukto, vegetable dish

## DISH Q105658947
- name: Korolar shukto
- description: bengali cuisine
- countries: (none)
- kinds: Shukto, vegetable dish

## DISH Q105658948
- name: Mulor shukto
- description: Bengali cuisine
- countries: (none)
- kinds: Shukto, vegetable dish

## DISH Q105658949
- name: Peper shukto
- description: Bengali cuisine
- countries: (none)
- kinds: Shukto, vegetable dish

## DISH Q105658950
- name: Sojne fuler sukto
- description: Bengali cuisine
- countries: (none)
- kinds: Shukto, vegetable dish

## DISH Q105658951
- name: Shoshar shukto
- description: Bengali cuisine
- countries: (none)
- kinds: Shukto, vegetable dish

## DISH Q105658952
- name: Chhanchi kumror shukto
- description: Bengali cuisine
- countries: (none)
- kinds: Shukto, vegetable dish

## DISH Q105658953
- name: Jhinge shukto
- description: Bengali cuisine
- countries: (none)
- kinds: Shukto, vegetable dish

## DISH Q105658954
- name: Panchmishali shukto
- description: Bengali cuisine
- countries: (none)
- kinds: Shukto, vegetable dish

## DISH Q105658955
- name: Gota muger dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q105658956
- name: Tomato diye muger dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q105658957
- name: Motor dal er torkari
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658958
- name: Chholar dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q105658959
- name: Alur dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q105658960
- name: Palong o methi dal
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, lentil soup

## DISH Q105658961
- name: Chalkumro narkel
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658962
- name: Mug daler papad
- description: Bengali cuisine
- countries: (none)
- kinds: papad, vegetable dish

## DISH Q105658963
- name: Saboor papad
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, papad

## DISH Q105658964
- name: Alur papad
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, papad

## DISH Q105658965
- name: Chaler papad
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, papad

## DISH Q105658966
- name: Monohar bori
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658967
- name: Chhanchi kumror bichir bori
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658968
- name: Vaja bori
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658969
- name: Motor dal er bori
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658970
- name: Chhanar payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658971
- name: Semai er payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658972
- name: Chirer payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658973
- name: Sujir payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658974
- name: Luchir payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658975
- name: Apple er payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658976
- name: Bandhakopir payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658977
- name: Mulor payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658978
- name: Gajor er payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658979
- name: Komolalebur payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658980
- name: Kheer payesh
- description: Bengali cuisine
- countries: (none)
- kinds: confectionery

## DISH Q105658981
- name: Panifoler payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658982
- name: Shankalur payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658983
- name: Lau er payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: gourd, sugar, milk

## DISH Q105658984
- name: Bonder payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658985
- name: Anarosher payesh
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658986
- name: Kaon payesh
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105659028
- name: Shim Chhenchki
- countries: (none)
- kinds: chhenchki

## DISH Q105659032
- name: Lau-Bhadale Chhenchki
- countries: (none)
- kinds: chhenchki

## DISH Q105659035
- name: Peyanj-koli Chhenchki
- countries: (none)
- kinds: chhenchki

## DISH Q105659038
- name: Fulkopi patar Chhenchki
- countries: (none)
- kinds: chhenchki

## DISH Q105659040
- name: Shasha Chhenchki
- countries: (none)
- kinds: chhenchki

## DISH Q105659044
- name: Kharkhari
- countries: (none)
- kinds: chhenchki

## DISH Q105659047
- name: Aalu Chhenchki
- countries: (none)
- kinds: chhenchki

## DISH Q105659354
- name: Geflochtener Gipfel
- countries: (none)
- kinds: bread

## DISH Q105659501
- name: Chapla bread
- countries: PE
- kinds: food, bread
- ingredients: wheat

## DISH Q105660619
- name: Oat pulp cookie
- description: type of cookie
- countries: (none)
- kinds: cookie
- ingredients: oat pulp

## DISH Q10566528
- name: Kahk
- description: small circular biscuit that originated in Egypt
- countries: EG
- kinds: human food, Ka'ak
- has Wikipedia article: en

## DISH Q10567040
- name: Gaizai crackers
- other names: {"zh": "鸡仔饼"}
- countries: (none)
- kinds: biscuit
- ingredients: wheat flour, five-spice powder, white pepper, Terminalia catappa, table salt, sugar
- has Wikipedia article: zh

## DISH Q10567075
- name: 鹽水雞
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q10567133
- name: Sesame oil chicken
- other names: {"zh": "麻油雞"}
- description: Taiwanese chicken dish cooked with sesame oil and rice wine
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q105671386
- name: Macher shukto
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Shukto

## DISH Q105671387
- name: Kucho chingrir bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada, fish dish

## DISH Q105671389
- name: Macher jhuri vaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q105671391
- name: Chingrir dalna
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, dalna

## DISH Q105671394
- name: Palongshak macher kanta diye torkari
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671395
- name: Pona macher kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, fish dish

## DISH Q105671397
- name: Macher muro diye khichudi
- description: Bengali cuisine
- countries: (none)
- kinds: khichri, fish dish

## DISH Q105671398
- name: Chingri fulkopir kalia
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q105671400
- name: Macher dim er kalia
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q105671402
- name: Chingrir kebab
- description: Bengali cuisine
- countries: (none)
- kinds: kebab, fish dish

## DISH Q105671405
- name: Koi macher paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q105671406
- name: Chingri paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q105671408
- name: Bhetki macher khichudi
- description: Bengali cuisine
- countries: (none)
- kinds: khichri, fish dish

## DISH Q105671411
- name: Macher moul
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671412
- name: Ilisher doi korma
- description: Bengali cuisine
- countries: (none)
- kinds: korma, fish dish

## DISH Q105671415
- name: Tomato diye magur machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671417
- name: Aarh macher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671418
- name: Chingrir jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671420
- name: Moshola chingri
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671422
- name: Koi machher ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Ghanto

## DISH Q105671423
- name: Koi machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671425
- name: Koi machh vaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q105671426
- name: Chingri machher polau
- description: Bengali cuisine
- countries: (none)
- kinds: pilaf, shrimp dish

## DISH Q105671428
- name: Jyanto rui machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671429
- name: Shol macher chhain
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671431
- name: Rosun o longkar achare chingri machh
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671433
- name: Magur machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671434
- name: Singi machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671438
- name: Koi machher tok jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q105671440
- name: Koi macher korma
- description: Bengali cuisine
- countries: (none)
- kinds: korma, fish dish

## DISH Q105671441
- name: Koi macher dalna
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, dalna

## DISH Q105671443
- name: Tel koi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671445
- name: Koi pathri
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671448
- name: Pona macher alugoppa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671450
- name: Kumro chingri machher botti
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671452
- name: Topse machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q105671454
- name: Macher dim diye ombol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Ambal

## DISH Q105671455
- name: Chingri fry
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671457
- name: Chingri machher cutlet
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671459
- name: Chingri posto
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671461
- name: Chingri bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada, shrimp dish

## DISH Q105671463
- name: Chingri machh vate
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671466
- name: Chingri machher jhuro
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671468
- name: Chingri pokora
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671470
- name: Chingrir porota
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671473
- name: Chingri kochuri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671474
- name: Ilish macher dom
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671475
- name: Parse machher paturi
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q105671477
- name: Ilish machher korma
- description: Bengali cuisine
- countries: (none)
- kinds: korma, fish dish

## DISH Q105671479
- name: Tyangra machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671547
- name: Bhadal chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671549
- name: Chingri machher salad
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671552
- name: Pona machher vapa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhapa

## DISH Q105671553
- name: Narkel chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671555
- name: Moshla chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671556
- name: Pomflate machh vaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q105671558
- name: Bhetki machher moul
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671559
- name: Bhetki machher fry
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q105671561
- name: Tomato bhetki
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671562
- name: Chitol macher kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, fish dish

## DISH Q105671563
- name: Ilish machh vaja
- description: Bengali cuisine
- countries: (none)
- kinds: ilish dish, Bhaja

## DISH Q105671564
- name: Mourola macher bati chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q105671565
- name: Bhetki machher stew
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671566
- name: Bhetki machel jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671568
- name: Pona macher kalia
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q105671569
- name: Koi machh o sorse bata
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671571
- name: Doi bele machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671573
- name: Bhetki machher ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Ghanto

## DISH Q105671574
- name: Daler muri ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Muri Ghanto

## DISH Q105671575
- name: Piyajkoli chingri machh
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671576
- name: Enchor chingri
- description: bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671577
- name: Bhetki macher malaikari
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671578
- name: Bhetki macher dimer jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671579
- name: Chitol macher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q105671580
- name: Topse machh vaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q105671581
- name: Chingri machh diye chholar dal
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671582
- name: Aam diye chingri curry
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671583
- name: Chingrir khichudi
- description: Bengali cuisine
- countries: (none)
- kinds: khichri, shrimp dish

## DISH Q105671584
- name: Bansh er thor diye chingri machh
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671585
- name: Machher dim er dhoka
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671586
- name: Macher pur diye begun korma
- description: Bengali cuisine
- countries: (none)
- kinds: korma, fish dish

## DISH Q105671587
- name: Chingri machher muri ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671588
- name: Chingri machher bol
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671589
- name: Chingri machher kalia
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671590
- name: Jhor jhore chingrir matha
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671591
- name: Mulo diye Bhetki machher chhenchki
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, chhenchki

## DISH Q105671593
- name: Pona machh diye bandhakopi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671595
- name: Koraishunti diye bhetki machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671597
- name: Jhinge diye telapia machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671598
- name: Rithe machher kalia
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q105671599
- name: Boyal paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q105671600
- name: Chitol machher muithya
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671601
- name: Pabda machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q105671602
- name: Amudi machh vaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q105671604
- name: Chingrir rosa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671605
- name: Fulkopi diye bhetki machher jhol
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671606
- name: Bori diye boyal machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671614
- name: Chingrir machher chop
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671615
- name: Bhetki machher chop
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671616
- name: Bhetki machher kanta chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q105671617
- name: Katla machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q105671618
- name: Pomfret jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q105671619
- name: Parshe jhal
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q105671620
- name: Pabda sorse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671621
- name: Lau patai chingri vapa
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671623
- name: Lote paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q105671624
- name: Begun diye ilish jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671627
- name: Lote machher jhuri
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671628
- name: Loitta shutki jhal
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q105671629
- name: Mourala machh vaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q105671630
- name: Parse begun diye jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105671631
- name: Lote machh fry
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q105671632
- name: Gondhoraj rui machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671634
- name: Rui posto
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671635
- name: Machher matha diye muger dal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671636
- name: Rui machher tok
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671638
- name: Aam kasundi chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105671639
- name: Deshi sorpunti dopeyanja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q105671772
- name: Machher dim bhapa
- description: Bengali Cuisine
- countries: (none)
- kinds: fish dish, Bhapa

## DISH Q105671817
- name: Chingri Kobiraji
- description: Bengali Cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q10567313
- name: Oo-pe̍h-tshiat
- other names: {"zh": "黑白切"}
- description: Taiwanese street food
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q10567403
- name: 龍鳳腿
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q105674767
- name: Thalassery chicken biriyani
- description: Thalassery biriyani
- countries: (none)
- kinds: Thalassery biryani, chicken biryani, dish
- ingredients: Wayanad Jeerakasala rice, mint leaf, garlic, tomato, Kaima, ginger, onion, lemon juice, garam masala, chicken

## DISH Q105674909
- name: Kaliya
- countries: (none)
- kinds: dish, type of food or dish

## DISH Q105675486
- name: Tiroler Schinkenkruste
- countries: (none)
- kinds: bread
- ingredients: beacon, Bergkäse

## DISH Q105675701
- name: Mohn-Käse-Stange
- countries: (none)
- kinds: pastry

## DISH Q1056769
- name: Colby cheese
- other names: {"zh": "考尔比芝士"}
- description: Type of semi-hard cheese
- countries: US
- kinds: cow's-milk cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q105685268
- name: Kochu patai Chingri vapa
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105685290
- name: Mocha chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105685335
- name: Potol chingri bharta
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q105685638
- name: Alu posto
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685639
- name: Jhinge alu posto
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685640
- name: Peyanj posto
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685641
- name: Potol posto
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685642
- name: Potol er dolma
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685643
- name: Bhendi posto
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685644
- name: Sim posto
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685645
- name: Til er bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q105685646
- name: Kumro fuler bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada, vegetable dish

## DISH Q105685647
- name: Pat shak er bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q105685648
- name: Pui patar bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q105685649
- name: Polta patar bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q105685650
- name: Dhone patar bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q105685651
- name: Posto bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685652
- name: Man kochu bata narkel diye
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685653
- name: Kharkol pata bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685654
- name: Dhone pata bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685655
- name: Vegetable chop
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685656
- name: Mochar chop
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685657
- name: Misti kumror chop
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685658
- name: Lonkar chop
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685659
- name: Capsicum er chop
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685660
- name: Alur chop
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685661
- name: Kasmiri alur chop
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105685662
- name: Uchchhe patar bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q105685663
- name: Tal er bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q105685664
- name: Sojne data alu posto
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105686321
- name: Refrigerator cookie
- description: type of cookie
- countries: (none)
- kinds: cookie

## DISH Q105686326
- name: Pinwheel cookie
- description: type of ice box cookie
- countries: (none)
- kinds: Refrigerator cookie

## DISH Q105687149
- name: Senfzwirbel
- countries: (none)
- kinds: bread
- ingredients: mustard

## DISH Q105687297
- name: Ungarisches Teebrot
- countries: HU
- kinds: bread

## DISH Q105688475
- name: Sonnenblumenkernbrot
- other names: {"de": "Sonnenblumenkernbrot"}
- countries: (none)
- kinds: bread
- ingredients: sunflower seed

## DISH Q105700896
- name: Blaukrautschnecke
- countries: (none)
- kinds: bread
- ingredients: red cabbage

## DISH Q10570326
- name: Luad ål
- other names: {"sv": "Luad ål"}
- countries: (none)
- kinds: fish dish

## DISH Q105709751
- name: Bel er sarbat
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q10571218
- name: Lyckebär
- other names: {"sv": "Lyckebär"}
- countries: (none)
- kinds: candy

## DISH Q105720218
- name: Chocolate cheese tart
- description: type of cheese tart
- countries: (none)
- kinds: cheese tart

## DISH Q105721637
- name: Kabli chholar ghugni
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105721780
- name: Dhokar dalna
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105721866
- name: Pumpkin tart
- description: tarte with punkin pulp
- countries: (none)
- kinds: tart
- ingredients: pumpkin

## DISH Q105722416
- name: Muesli roll
- description: type of roll
- countries: (none)
- kinds: bread roll
- ingredients: muesli

## DISH Q105724270
- name: Perpeq pite
- description: traditional Albanian pie dish, baked with cheese, milk and eggs
- countries: (none)
- kinds: dish, food

## DISH Q105724774
- name: Almond tart
- description: tart with almond
- countries: (none)
- kinds: tart
- ingredients: almond

## DISH Q105724832
- name: Schweizer Zeilenbrot
- other names: {"de": "Schweizer Zeilenbrot"}
- countries: CH
- kinds: bread roll

## DISH Q105727877
- name: Alleppey fish curry
- description: Indian fish curry
- countries: IN
- kinds: fish dish
- ingredients: sardine

## DISH Q105742167
- name: Laccha paratha
- description: Indian flat bread
- countries: IN
- kinds: food, utensil, paratha
- ingredients: wheat flour

## DISH Q105742190
- name: Mutton rogan josh
- description: Indian dish
- countries: (none)
- kinds: Rogan josh
- ingredients: garlic, ginger, goat meat

## DISH Q105742759
- name: Moravský vrabec
- countries: CZ
- kinds: pork dish
- ingredients: pork, knödel, sauerkraut

## DISH Q105747930
- name: Hanbāgu
- description: Japanese-style Hamburg steak
- countries: JP
- kinds: type of food or dish, Hamburg steak

## DISH Q105754046
- name: Enchor Alur Torkari
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105754056
- name: Katla machher jhol alu potol diye
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q105754070
- name: Katla machher tel bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q105754147
- name: Mourala Machher Tok
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q10575585
- name: Swedish mackerel soup
- countries: SE
- cuisines: Swedish cuisine
- kinds: dish, fish soup
- ingredients: potato, Atlantic mackerel, cream, vegetable, wine

## DISH Q105761964
- name: Kaiserschnitzel
- countries: (none)
- ingredients: knuckle

## DISH Q105761993
- name: Potol alur torkari
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q1057649
- name: Tandoori chicken
- other names: {"zh": "印度烤鸡"}
- description: Indian subcontinent chicken dish
- countries: IN
- cuisines: Indian cuisine
- kinds: tandoori, chicken dish
- ingredients: chicken as food, yogurt
- has Wikipedia article: en, zh

## DISH Q10578820
- name: Mazarin
- description: A glazed shortcrust pastry with almond
- countries: SE
- kinds: tart, small pastry
- ingredients: Pasta di mandorle PAT, shortcrust pastry

## DISH Q1057953
- name: Ceviche
- other names: {"zh": "柠汁醃鱼生"}
- description: traditional dish in Peru prepared with raw fish marinated
- countries: PE
- kinds: raw fish dish, meal
- ingredients: shellfish, peppercorn, lemon juice, fish as food, Coriandrum sativum, maize
- has Wikipedia article: en, zh

## DISH Q1057975
- name: Gemelli
- other names: {"zh": "双子面"}
- description: pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en, zh

## DISH Q105809316
- name: Salată de icre
- description: Romanian dish
- countries: RO
- kinds: dish
- ingredients: fish as food

## DISH Q105812795
- name: Mextlapique
- description: plato mexicano de origen prehispánico
- countries: MX
- kinds: dish

## DISH Q105819446
- name: Lonkar Dolma
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105822342
- name: Mashi rice
- countries: (none)
- kinds: dish

## DISH Q105847250
- name: Fruit pizza
- description: circular tart featuring multiple fruit toppings
- countries: (none)
- kinds: food, dessert, fruit tart
- has Wikipedia article: en

## DISH Q10585216
- name: Milanopinne
- other names: {"sv": "Milanopinne"}
- countries: (none)
- kinds: pastry

## DISH Q10585919
- name: Mintkyssar
- other names: {"sv": "Mintkyssar"}
- countries: (none)
- kinds: candy

## DISH Q10586818
- name: Soft gingerbread
- countries: (none)
- kinds: gingerbread, sponge cake
- ingredients: chicken egg, wheat flour, ginger bread spice, edible fats and oils, sodium bicarbonate, sugar

## DISH Q105882584
- name: Chaltar achar
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882587
- name: Aamer achar
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882588
- name: Kuler achar
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882589
- name: Aam tel
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882590
- name: Tentuler achar
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882591
- name: Jolpai er achar
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882592
- name: Kancha lonkar achar
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882593
- name: Panchmishali achar
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882594
- name: Aamsottwo khenjur er achar
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882595
- name: Chal kumror chenchki
- description: Bengali cuisine
- countries: (none)
- kinds: chhenchki

## DISH Q105882596
- name: Alu kumror chenchki
- description: Bengali cuisine
- countries: (none)
- kinds: chhenchki

## DISH Q105882598
- name: Bori diye thor chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q105882599
- name: Kumro shaker chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q105882601
- name: Pui shaker chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q105882602
- name: Shaplar ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q105882603
- name: Pepe muger ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q105882604
- name: Bata mulo shaker ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q105882605
- name: Panifol er dalna
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, dalna

## DISH Q105882606
- name: Kumro bij er dalna
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, dalna

## DISH Q105882607
- name: Kanch kolar dalna
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, dalna

## DISH Q105882608
- name: Kochu patar dalna
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, dalna

## DISH Q105882609
- name: Bandhakopir dalna
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, dalna

## DISH Q105882610
- name: Bandhakopir ghi paturi
- description: Bengali cuisine
- countries: (none)
- kinds: paturi

## DISH Q105882611
- name: Til paturi
- description: bengali cuisine
- countries: (none)
- kinds: paturi

## DISH Q105882612
- name: Narker korma
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish, korma

## DISH Q105882613
- name: Doi paneer korma
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, korma

## DISH Q105882615
- name: Soyabean er korma
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, korma

## DISH Q105882617
- name: Alur korma
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, korma

## DISH Q105882618
- name: Thor sorse
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882619
- name: Alu motor
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882620
- name: Bori tomator torkari
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882623
- name: Jhinge narkel
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882624
- name: Gajor o ranga alur bahar
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882625
- name: Begun sorse
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882626
- name: Purvora lau
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882627
- name: Nobabi motorshunti
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882632
- name: Dal dhokali
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882634
- name: Dhirbalar potol
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105882637
- name: Enchor er kalia
- description: Bengali cuisine
- countries: (none)
- kinds: kaliya

## DISH Q105882639
- name: Alu beguner kalia
- description: Bengali cuisine
- countries: (none)
- kinds: kaliya

## DISH Q105882642
- name: Gajor er moshola kalia
- description: bengali cuisine
- countries: (none)
- kinds: kaliya

## DISH Q105882645
- name: Fulkopir doi kalia
- description: Bengali cuisine
- countries: (none)
- kinds: kaliya

## DISH Q105882647
- name: Paporer kalia
- description: Bengali cuisine
- countries: (none)
- kinds: kaliya

## DISH Q105882650
- name: Postor kalia
- description: Bengali cuisine
- countries: (none)
- kinds: kaliya

## DISH Q105882725
- name: Dhokar kalia
- description: Bengali cuisine
- countries: (none)
- kinds: kaliya

## DISH Q105882726
- name: Panong kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish

## DISH Q105882728
- name: Chhirer kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish
