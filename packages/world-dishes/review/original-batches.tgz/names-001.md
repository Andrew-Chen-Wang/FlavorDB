# Review batch names-001

## DISH Q104640127
- name: Karupuak lento
- description: Indonesia tradiotional dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: krupuk, dish, street food, human food, type of food or dish
- ingredients: tapioca, palm oil, cassava

## DISH Q104640148
- name: Ketan sarikaya
- description: Indonesia cuisine
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, dish
- ingredients: chicken egg, coconut, palm sugar, coconut milk, Pandanus amaryllifolius, glutinous rice, table salt

## DISH Q104641121
- name: Lapek sagan
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, dish, street food, human food, traditional food, type of food or dish
- ingredients: cassava root, banana leaf, coconut, palm sugar, Pandanus amaryllifolius, glutinous rice, banana

## DISH Q104641161
- name: Lopis ubi
- other names: {"id": "Lopis ubi"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, dish, human food, traditional food, type of food or dish
- ingredients: cassava root, palm sugar, Sweet potato, Cocos nucifera

## DISH Q104641191
- name: Palai balado
- description: Traditional Minangkabau dish of fish mixed with balado chili paste, wrapped in banana leaves and grilled
- countries: (none)
- kinds: pepes, fish dish
- ingredients: fish as food, cassava

## DISH Q104650713
- name: Kardemummabulle
- description: sweet roll prepared with cardamom
- countries: (none)
- kinds: sweet roll
- ingredients: cardamom, wheat flour, baker's yeast, sugar

## DISH Q10465999
- name: Daimstrut
- other names: {"sv": "Daimstrut"}
- countries: (none)

## DISH Q104668032
- name: Cured pork
- other names: {"zh": "腊肉"}
- countries: (none)
- kinds: meat dish
- has Wikipedia article: zh

## DISH Q104691076
- name: Indigirka salad
- description: Yakut fish salad
- countries: RU
- kinds: salad, dish
- ingredients: black pepper, vegetable oil, onion, fish as food, table salt

## DISH Q104698217
- name: Mebos
- description: traditional South African candy made from apricots
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q10472376
- name: Dietorelle
- other names: {"sv": "Dietorelle"}
- countries: (none)
- kinds: candy

## DISH Q10472675
- name: Tilliliha
- other names: {"fi": "tilliliha"}
- countries: (none)
- kinds: dish

## DISH Q104727207
- name: Rambutan
- description: fruit of Nephelium lappaceum
- countries: MY
- kinds: fruit

## DISH Q1047392
- name: Hot dog bun
- other names: {"zh": "熱狗麵包"}
- description: type of bread roll
- countries: US
- kinds: bun
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q10477006
- name: Queen's jam
- description: jam made of raspberry and bilberry
- countries: (none)
- kinds: berry jam
- ingredients: bilberry, raspberry, sugar

## DISH Q10477229
- name: Dream
- description: Swedish cookie
- countries: (none)
- kinds: cookie
- ingredients: vanilla sugar, shortcrust pastry, baker's ammonia

## DISH Q104783428
- name: Spakenburgs hart
- other names: {"nl": "Spakenburgs hart"}
- countries: (none)
- kinds: Boterkoek

## DISH Q104792798
- name: Tjvjik
- description: Armenian liver dish
- countries: AM
- cuisines: Armenian cuisine
- kinds: dish
- ingredients: liver as food, offal
- has Wikipedia article: en

## DISH Q1047978
- name: Chakhokhbili
- other names: {"zh": "查科比利"}
- description: Georgian dish
- countries: GE
- cuisines: Georgian cuisine
- kinds: dish, stew
- ingredients: poultry meat, Allium, spice, tomato, meat
- has Wikipedia article: en, zh

## DISH Q1048130
- name: Oromo
- description: Central Asian steamed pie
- countries: KG
- cuisines: Kazakh cuisine, Cuisine of Uzbekistan, Kyrgyz cuisine
- kinds: dish, pie
- ingredients: potato, Cucurbita, onion, herb, dough, Brassica, meat
- has Wikipedia article: en

## DISH Q1048282
- name: Cassata siciliana PAT
- other names: {"zh": "Cassata siciliana PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good, cake
- ingredients: sponge cake
- has Wikipedia article: en

## DISH Q104829714
- name: Putugal
- description: dessert
- countries: (none)
- kinds: rice cake
- has Wikipedia article: en

## DISH Q104829719
- name: Sugee cake
- description: type of cake
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q104829802
- name: Tigelada
- description: Portuguese dessert
- countries: PT
- kinds: dessert
- ingredients: flour, egg, table salt, sugar, milk, Citrus × limon
- has Wikipedia article: en

## DISH Q104830799
- name: Pittsburgh salad
- description: salad containing french fries
- countries: US
- kinds: salad
- has Wikipedia article: en

## DISH Q104834952
- name: Ravikos
- description: sephardic spinach dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q104836072
- name: Shucky beans
- description: appalachian bean dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q104842957
- name: Bittergarnituur
- countries: (none)
- kinds: food, fast food

## DISH Q104844158
- name: Sushi burrito
- description: type of Japanese-American fusion cuisine
- countries: US
- kinds: sushi, burrito, dish
- ingredients: raw fish, sumeshi, burrito, nori, sushi
- has Wikipedia article: en

## DISH Q104849442
- name: Kola kanda
- description: traditional herbal congee or gruel
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1048496
- name: Botvinia
- description: chilled beet soup of Russian origin
- countries: (none)
- kinds: dish, first course, cold sweet soup, beetroot soup
- ingredients: young beets, kvass, Beta vulgaris, leaf vegetable

## DISH Q104852303
- name: Spicy tuna roll
- description: sushi roll
- countries: US
- kinds: food, uramakizushi
- has Wikipedia article: en

## DISH Q104853749
- name: Wigg
- description: type of cake in English cuisine
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q104853763
- name: Watermelon salad
- description: summer salad
- countries: (none)
- kinds: fruit salad
- ingredients: watermelon
- has Wikipedia article: en

## DISH Q104855730
- name: China chilo
- description: mutton dish from Victorian cuisine
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q104856047
- name: Pone
- description: bread from American cuisine
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q104856718
- name: Lavariya
- countries: (none)
- kinds: dish
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q104857695
- name: Love in disguise
- description: British dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q104858644
- name: Porcupine meatballs
- description: American rice meatballs
- countries: (none)
- kinds: dish
- ingredients: rice as food, tomato sauce, ground beef
- has Wikipedia article: en

## DISH Q104858815
- name: White cake
- description: cake made without egg yolks
- countries: (none)
- kinds: cake
- ingredients: white sugar, egg white, pastry flour, sodium bicarbonate, baking powder
- has Wikipedia article: en

## DISH Q104862279
- name: Pie in American cuisine
- description: history and cultural significance of pies in American cuisine
- countries: US
- cuisines: cuisine of the United States
- kinds: pie
- has Wikipedia article: en

## DISH Q104864044
- name: Desperation pie
- description: thrifty pie from American cuisine
- countries: US
- cuisines: cuisine of the United States
- kinds: pie, dish
- ingredients: flour, butter, egg, sugar
- has Wikipedia article: en

## DISH Q104881657
- name: King's Hand
- description: surrealist meal in the shape of a hand
- countries: (none)
- kinds: food, dessert, recipe, human food, creative work
- ingredients: cookie dough, M&M's, Greek salad
- has Wikipedia article: en

## DISH Q104887477
- name: Babbeler
- other names: {"de": "Babbeler"}
- countries: (none)
- kinds: lollipop

## DISH Q1049425
- name: Kısır
- other names: {"zh": "克色尔"}
- description: meze and teatime dish from the Turkish cuisine
- countries: TR
- cuisines: Kurdish cuisine
- kinds: food, salad, meze
- ingredients: bulgur
- has Wikipedia article: en, zh

## DISH Q10495802
- name: Fiskpanetter
- other names: {"sv": "Fiskpanetter"}
- countries: (none)
- kinds: fish dish

## DISH Q104960372
- name: Malaxlimpa
- countries: FI
- kinds: bread
- ingredients: rye flour

## DISH Q10497217
- name: Fläskkorv
- description: Swedish sausage made largely or entirely from pork
- countries: SE
- kinds: sausage
- ingredients: pork
- has Wikipedia article: en

## DISH Q104974761
- name: Rådjurssadel
- other names: {"sv": "rådjurssadel"}
- countries: (none)
- kinds: dish

## DISH Q1049852
- name: Sponge cake
- other names: {"zh": "海绵蛋糕"}
- description: type of cake
- countries: IT
- kinds: foam cake
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q10498613
- name: French roll
- other names: {"zh": "短法包"}
- description: type of bread
- countries: (none)
- kinds: bread roll
- has Wikipedia article: en

## DISH Q10499378
- name: Taro purée
- other names: {"zh": "芋泥"}
- description: Chinese dessert
- countries: CN, TW
- kinds: dessert
- ingredients: Colocasia esculenta
- has Wikipedia article: en, zh

## DISH Q10499831
- name: Fugazza
- description: Argentine pizza variety
- countries: AR
- cuisines: Argentine cuisine
- kinds: dish, type of pizza
- has Wikipedia article: en

## DISH Q10500003
- name: Cuttlefish geng
- other names: {"zh": "花枝羹"}
- description: Taiwanese signature thick soup dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q10500606
- name: Fyra små rätter
- other names: {"sv": "Fyra små rätter"}
- countries: (none)
- kinds: dish

## DISH Q105006109
- name: Zhavoronki
- description: ceremonial holiday cookies in the form of birds
- countries: BY, RU, UA
- kinds: cookie, baked good
- ingredients: rye flour, vegetable oil, yeast, sugar, water

## DISH Q10500884
- name: Färsbiff
- other names: {"sv": "Färsbiff"}
- countries: (none)
- kinds: dish

## DISH Q10501315
- name: Suzhou-style noodles
- other names: {"zh": "苏式汤面"}
- description: noodle soup originated from Suzhou
- countries: CN
- cuisines: Chinese cuisine
- kinds: noodle soup
- has Wikipedia article: en, zh

## DISH Q105015387
- name: Pastina
- description: Italian small pasta type for soup
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q10501568
- name: Šunka od kosti
- other names: {"cs": "šunka od kosti"}
- countries: (none)
- kinds: ham

## DISH Q10501838
- name: Ga Xao Gung
- other names: {"sv": "Ga Xao Gung"}
- countries: (none)
- kinds: dish

## DISH Q10502922
- name: Švejkovská topinka
- other names: {"cs": "švejkovská topinka"}
- countries: (none)
- kinds: fried bread

## DISH Q10503582
- name: Geisha
- description: chocolate bar made by the Finnish company Fazer
- countries: (none)
- kinds: chocolate bar
- has Wikipedia article: en

## DISH Q105045810
- name: Soy burger
- description: burger-like soy patty
- countries: (none)
- kinds: veggie burger, food product, type of food or dish
- ingredients: soy bean

## DISH Q105045860
- name: Vegan chicken noodle soup
- description: Soup made with pieces of vegan simulated chicken, designed to represent the flavor and components of traditional meat-based chicken noodle soup.
- countries: (none)
- kinds: soup, vegan product, type of food or dish
- ingredients: simulated chicken, broth, noodle

## DISH Q10505302
- name: Popsicle stick
- description: small piece of elongated flat wood used in frozen deserts to make it easy to carry
- countries: (none)
- kinds: ice cream, structure
- has Wikipedia article: en

## DISH Q105064017
- name: Laputabröd
- other names: {"sv": "laputabröd"}
- countries: SE
- kinds: bread

## DISH Q10506671
- name: Godterismokk
- other names: {"nb": "godterismokk"}
- description: type of candy
- countries: (none)
- kinds: candy

## DISH Q105077405
- name: Otellotårta
- other names: {"sv": "Otellotårta"}
- countries: (none)
- kinds: torte

## DISH Q105094284
- name: Horácká polévka
- other names: {"cs": "Horácká polévka"}
- countries: (none)
- kinds: soup

## DISH Q10509612
- name: Grynkaka
- description: semolina cake
- countries: (none)
- kinds: cake, rice pudding
- ingredients: semolina, saffron

## DISH Q10509650
- name: Grytbit
- description: Stew with meat
- countries: SE
- kinds: dish
- ingredients: meat

## DISH Q105097825
- name: Rubinsteintårta
- other names: {"sv": "Rubinsteintårta"}
- countries: (none)
- kinds: torte

## DISH Q105098362
- name: Sans rival-tårta
- other names: {"sv": "Sans rival-tårta"}
- countries: (none)
- kinds: torte

## DISH Q105100449
- name: Casablancatårta
- other names: {"sv": "Casablancatårta"}
- countries: (none)
- kinds: torte

## DISH Q10510197
- name: Egg–anchovy salad
- other names: {"zh": "鸡蛋凤尾鱼沙拉"}
- description: Swedish dish
- countries: SE
- kinds: salad, type of food or dish
- ingredients: chives, dill, chicken egg, anchovy

## DISH Q1051155
- name: Frittata
- other names: {"zh": "义大利式菠菜烘蛋"}
- description: dish
- countries: IT
- cuisines: Italian cuisine
- kinds: omelette, egg dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q1051265
- name: Instant noodles
- other names: {"zh": "方便面"}
- description: noodles sold in a precooked and dried block with flavoring
- countries: JP
- kinds: type of food or dish, instant food, noodle dish
- ingredients: wheat flour, noodle, soup, water
- has Wikipedia article: en, zh

## DISH Q10514423
- name: Milkfish congee
- other names: {"zh": "虱目魚肚粥"}
- description: Taiwanese congee
- countries: (none)
- kinds: congee, fish dish
- ingredients: Chanos chanos
- has Wikipedia article: en, zh

## DISH Q10514464
- name: Chengdu egg pancake
- other names: {"zh": "蛋烘糕"}
- countries: CN
- kinds: pancake
- has Wikipedia article: zh

## DISH Q10514546
- name: 蝦仁羹
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q1051460
- name: Cotechino Modena PGI
- other names: {"zh": "Cotechino Modena IGP"}
- description: Italian PGI meat product
- countries: IT
- cuisines: cuisine of the province of Modena
- kinds: meat product, cotechino
- has Wikipedia article: en

## DISH Q10515472
- name: Hackkorv
- other names: {"sv": "Hackkorv"}
- countries: (none)
- kinds: dish

## DISH Q10516404
- name: Hallonbåt
- other names: {"sv": "hallonbåt"}
- countries: (none)
- kinds: candy

## DISH Q10516678
- name: Halvtjockkakor
- other names: {"sv": "halvtjockkakor"}
- countries: SE
- kinds: flatbread
- ingredients: golden syrup

## DISH Q10518439
- name: Hasselback potatoes
- other names: {"zh": "風琴馬鈴薯"}
- description: Swedish potato dish
- countries: SE
- cuisines: Swedish cuisine
- kinds: potato dish
- ingredients: potato, bread crumbs, butter
- has Wikipedia article: en, zh

## DISH Q1051852
- name: Sōki
- description: Japanese pork dish
- countries: JP
- cuisines: Okinawan cuisine
- kinds: dish, pork dish
- has Wikipedia article: en

## DISH Q1051861
- name: Corzetti
- description: type of pasta
- countries: IT
- kinds: type of pasta, pasta
- has Wikipedia article: en

## DISH Q10519406
- name: Hel special
- other names: {"sv": "hel special"}
- countries: (none)
- kinds: potato dish

## DISH Q1051978
- name: Katsukarē
- other names: {"zh": "吉列豬排咖喱飯"}
- description: Japanese pork and rice curry dish
- countries: JP
- kinds: pork dish, Japanese curry rice
- ingredients: tonkatsu, cooked rice
- has Wikipedia article: en

## DISH Q10520838
- name: West Lake Fish in Vinegar Gravy
- other names: {"zh": "西湖醋鱼"}
- description: Chinese fish dish
- countries: (none)
- kinds: Hangzhou cuisine, fish dish
- ingredients: ginger, white sugar, rice vinegar, Grass Carp
- has Wikipedia article: en, zh

## DISH Q1052204
- name: Shengjian mantou
- other names: {"zh": "生煎馒头"}
- description: A type of small, pan-fried baozi (steamed buns) which is a specialty of Shanghai
- countries: CN
- cuisines: Chinese cuisine
- kinds: baozi, pork dish
- has Wikipedia article: en, zh

## DISH Q1052236
- name: Pasta salad
- description: salad containing pasta
- countries: IT
- kinds: dish, salad, pasta dish
- ingredients: pasta
- has Wikipedia article: en

## DISH Q10523680
- name: Se-lóo-bah
- other names: {"zh": "西魯肉"}
- description: yilan, Taiwan specialty thick soup with shredded pork and vegetables
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish
- has Wikipedia article: zh

## DISH Q1052461
- name: Cecina
- description: cured meat (beef, goat…, but not porc)
- countries: ES
- kinds: dried meat
- ingredients: beef
- has Wikipedia article: en

## DISH Q1052469
- name: Tom yum
- other names: {"zh": "冬荫"}
- description: hot and sour Thai soup
- countries: TH
- cuisines: Thai cuisine
- kinds: hot and sour soup
- ingredients: Kaffir Lime Leaf, nam phrik phao, stock, galangal, chili pepper, Cymbopogon citratus
- has Wikipedia article: en, zh

## DISH Q10525017
- name: Hockeypulver
- other names: {"sv": "Hockeypulver"}
- description: Swedish salty liquorice candy
- countries: (none)
- kinds: candy, salty licorice

## DISH Q105264416
- name: San Blas
- countries: (none)
- kinds: cake
- ingredients: egg as food, yeast, flour, Pimpinella anisum, sugar

## DISH Q1052815
- name: Spumoni
- description: ice cream
- countries: IT
- cuisines: Italian cuisine
- kinds: ice cream
- has Wikipedia article: en

## DISH Q105288154
- name: Purple Bread
- description: Filipino Bread Rolls
- countries: PH
- kinds: food, bread, breakfast
- ingredients: Ube, Pandesal

## DISH Q1053103
- name: Pumpkin bread
- description: food
- countries: (none)
- kinds: food, quick bread
- ingredients: pumpkin
- has Wikipedia article: en

## DISH Q105318869
- name: Hot dish
- other names: {"zh": "熱葷"}
- description: food dish that is typically served hot or warm
- countries: (none)
- kinds: dish, fare
- has Wikipedia article: zh

## DISH Q105322599
- name: Energy gum
- countries: (none)
- kinds: chewing gum

## DISH Q10532369
- name: 豆簽羹
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q10532500
- name: Hökarpanna
- other names: {"sv": "Hökarpanna"}
- countries: (none)
- kinds: dish

## DISH Q10532570
- name: Hönökaka
- description: Swedish flat bread
- countries: SE
- kinds: bread
- ingredients: rye flour, wheat flour, baker's yeast
- has Wikipedia article: en

## DISH Q105333550
- name: Poireaux vinaigrette
- description: marinated leek dish from French cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q10533638
- name: Niau-chhu noodles
- other names: {"zh": "貓鼠麵"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: Ta-a noodles, flour-based food
- has Wikipedia article: zh

## DISH Q105337075
- name: Soetpatats
- description: sweet potato dish
- countries: ZA
- kinds: sweet potato dish
- ingredients: Sweet potato
- has Wikipedia article: en

## DISH Q105337443
- name: Nasi lemuni
- description: rice dish in Malaysia
- countries: MY
- kinds: food, rice dish
- ingredients: Vitex trifolia, rice
- has Wikipedia article: en

## DISH Q10535460
- name: Ingefärspäron
- other names: {"sv": "ingefärspäron"}
- countries: (none)
- kinds: dessert

## DISH Q10535659
- name: Fried and pickled herring
- description: Swedish dish featuring Baltic herring
- countries: (none)
- kinds: fish dish
- ingredients: Baltic herring

## DISH Q105359471
- name: Boeuf à la moelle
- countries: (none)
- kinds: beef dish

## DISH Q105361351
- name: Salted herring
- description: fish dish
- countries: (none)
- kinds: fish dish

## DISH Q105396963
- name: Göttinger Stracke
- other names: {"de": "Göttinger Stracke"}
- description: Air-dried, long, and thin raw sausage
- countries: DE
- kinds: sausage, protected geographical indication
- ingredients: pork

## DISH Q10540862
- name: Strawberry cake
- other names: {"zh": "草莓蛋糕"}
- description: cake typically made with strawberries and cream
- countries: (none)
- kinds: cake, torte, tart
- ingredients: sponge cake, cream, strawberry
- has Wikipedia article: en, zh

## DISH Q105411167
- name: Vålåloffen
- other names: {"sv": "Vålåloffen"}
- countries: SE
- kinds: cheese

## DISH Q10541947
- name: Järpe
- other names: {"sv": "Järpe"}
- countries: (none)
- kinds: dish

## DISH Q10542015
- name: Jästa pannkakor
- other names: {"sv": "Jästa pannkakor"}
- countries: (none)
- kinds: pancake

## DISH Q10542033
- name: Jätten
- other names: {"sv": "Jätten"}
- countries: (none)
- kinds: biscuit

## DISH Q10542408
- name: Coffee bread
- description: pastry eaten during coffee breaks
- countries: (none)
- kinds: pastry

## DISH Q10542917
- name: Kalops
- description: Swedish beef stew
- countries: SE
- kinds: stew, beef dish
- has Wikipedia article: en

## DISH Q105429471
- name: Chogyetang
- countries: (none)
- cuisines: North Korean cuisine
- kinds: guk, chicken dish
- ingredients: rice vinegar, chicken as food

## DISH Q10543810
- name: Karlsbaderbröd
- other names: {"sv": "Karlsbaderbröd"}
- countries: (none)
- kinds: bread

## DISH Q10544140
- name: Karuselli
- description: Finnish candy
- countries: (none)
- kinds: candy

## DISH Q1054430
- name: Gianchetti
- description: fish
- countries: (none)
- cuisines: cuisine niçoise
- kinds: fish dish
- has Wikipedia article: en

## DISH Q10544495
- name: Kavelgris
- other names: {"sv": "Kavelgris"}
- countries: SE
- kinds: bread
- ingredients: anise seed, fennel fruit, potato, wheat flour

## DISH Q10545209
- name: Kexchoklad
- other names: {"sv": "kexchoklad"}
- description: chocolate-covered wafer bar
- countries: (none)
- kinds: chocolate bar

## DISH Q10546582
- name: Knake
- description: Kind of sausage
- countries: SE
- kinds: Knackwurst, food

## DISH Q10546944
- name: Koggost
- other names: {"sv": "Koggost"}
- countries: SE
- kinds: cow's-milk cheese, Swedish cheese
- ingredients: cow's milk

## DISH Q10547054
- name: Kolbotten
- other names: {"sv": "kolbotten"}
- countries: SE
- kinds: dish

## DISH Q10547680
- name: Konstgjord kaviar
- other names: {"sv": "konstgjord kaviar"}
- countries: (none)
- kinds: caviar

## DISH Q105480600
- name: Dekke na niarsik
- other names: {"id": "dekke na niarsik"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: type of food or dish, dish, human food, meal
- ingredients: Curcuma longa, Cymbopogon citratus, Andaliman, Etlingera elatior, fish as food, Allium schoenoprasum

## DISH Q105480717
- name: Dodol Gorontalo
- other names: {"id": "dodol Gorontalo"}
- countries: ID
- kinds: Dodol, confectionery
- ingredients: glutinous rice flour, palm sugar, coconut milk, peanut

## DISH Q105481008
- name: Katrisolo
- description: a traditional cake with the main ingredient in the form of glutinous rice and using brown sugar
- countries: ID
- kinds: pastry, kue
- ingredients: palm sugar, coconut milk, glutinous rice, egg as food, table salt, sugar

## DISH Q10548291
- name: Sausage stroganoff
- description: Swedish version of beef Stroganoff
- countries: SE
- cuisines: Swedish cuisine
- kinds: meat dish, type of food or dish
- ingredients: falukorv
- has Wikipedia article: en

## DISH Q10548294
- name: Korvkaka
- other names: {"sv": "Korvkaka"}
- countries: (none)
- kinds: dish

## DISH Q105485736
- name: Bubur sada
- description: Gorontalo typical porridge prepared from mashed corn
- countries: ID
- cuisines: Indonesian cuisine
- kinds: congee, dish, human food, traditional food, type of food or dish
- ingredients: coconut milk, maize

## DISH Q105489284
- name: Pempek panggang
- countries: ID
- cuisines: Indonesian cuisine
- kinds: Pempek, dish, human food, traditional food, type of food or dish
- ingredients: vegetable oil, tapioca, dried shrimp, soy sauce, table salt, water, fish

## DISH Q105490097
- name: Apang colo
- description: one of the typical Gorontalo cakes made from a mixture of wheat flour and rice flour, yeast, and coconut milk
- countries: ID
- kinds: pastry, snack

## DISH Q105492043
- name: Caramel de Dijous Gras
- other names: {"ca": "Caramel de Dijous Gras"}
- countries: (none)
- kinds: caramel

## DISH Q10549373
- name: Krokofant
- other names: {"mul": "Krokofant"}
- description: Swedish candy brand
- countries: (none)
- kinds: candy

## DISH Q10549595
- name: Kruska
- description: type of porridge
- countries: (none)
- kinds: porridge
- ingredients: rolled oats, bran, raisin

## DISH Q10549681
- name: Krämbulle
- other names: {"sv": "Krämbulle"}
- countries: (none)
- kinds: pastry

## DISH Q105499976
- name: Bulung putih
- description: Bali's famous "bulung" or seaweed salad, served with spicy fish stock, shredded coconut, and chopped chili.
- countries: ID
- kinds: salad
- ingredients: seaweed

## DISH Q105501273
- name: Sengkuang
- description: typical Palembang food
- countries: ID
- kinds: soup, cuisine
- ingredients: turmeric, cabbage, eggplant, grated coconut, ground beef, onion, Tamarindus indica, leek, Aleurites moluccanus, coconut milk, galangal, bean, chili pepper, table salt, sugar

## DISH Q105502227
- name: Kerupuk jengkol
- description: Traditional Indonesian deep-fried crackers flavored with jengkol
- countries: ID
- kinds: cookie, krupuk
- ingredients: tapioca flour, Archidendron pauciflorum

## DISH Q105502704
- name: Roasted corn
- description: Traditional Southeast Asian street food consisting of grilled or roasted corn on the cob
- countries: (none)
- kinds: street food
- ingredients: sauce, maize, margarine

## DISH Q105508520
- name: Bubur bongkol
- description: traditional porridge from Bengkulu
- countries: ID
- kinds: porridge
- ingredients: rice flour, sugar, water

## DISH Q10551237
- name: Kvæfjord cake
- other names: {"zh": "克韦菲尤尔蛋糕"}
- description: Norwegian sponge cake baked with meringue, vanilla cream and almonds
- countries: NO
- kinds: sponge cake
- ingredients: whipped cream, meringue, Prunus dulcis, vanilla
- has Wikipedia article: en

## DISH Q105513845
- name: Campur lorjuk
- other names: {"id": "campur lorjuk"}
- countries: ID
- kinds: soto

## DISH Q105513896
- name: Pengkang
- other names: {"id": "pengkang"}
- countries: ID
- kinds: lemper
- ingredients: banana leaf, glutinous rice

## DISH Q105514497
- name: Soto tauco
- other names: {"id": "soto tauco"}
- countries: ID
- kinds: soto
- ingredients: Tauco

## DISH Q10551845
- name: Mokkapalat
- other names: {"fi": "Mokkapalat"}
- countries: (none)
- kinds: cake

## DISH Q10552022
- name: Kålpudding
- other names: {"sv": "kålpudding"}
- countries: (none)
- kinds: dish

## DISH Q10552252
- name: Köttfärsfrestelse
- other names: {"sv": "Köttfärsfrestelse"}
- countries: (none)
- kinds: dish

## DISH Q105528156
- name: Cara isi
- description: a type of cake from Gorontalo made from a mixture containing tuna
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, kue, type of food or dish
- ingredients: garlic, Euthynnus affinis, wheat flour, coconut milk, egg as food, sugar

## DISH Q105528183
- name: Selada bangka
- description: a typical Bangka dish made from tofu with a splash of peanut sauce
- countries: ID
- kinds: food, salad, dish

## DISH Q105528306
- name: Kue muso
- description: traditional food from Jambi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, traditional food, type of food or dish, kue
- ingredients: sweetened cocoa powder, glutinous rice flour, wheat flour, coconut milk, Pandanus amaryllifolius, egg as food, vanilla, table salt, sugar

## DISH Q105528411
- name: Padamaran
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, kue
- ingredients: palm sugar, rice flour, coconut milk, table salt

## DISH Q105529039
- name: Pia pica
- other names: {"id": "pia pica"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: human food, traditional food, type of food or dish, dish, kue
- ingredients: wheat flour, egg as food, butter

## DISH Q105529161
- name: Bola Ubi
- description: sweet potato dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, kue
- ingredients: vegetable oil, palm sugar, rice flour, Sweet potato, table salt

## DISH Q10553438
- name: Licorice pipe
- description: licorice candy shaped like a tobacco pipe
- countries: (none)
- kinds: candy
- ingredients: licorice candy
- has Wikipedia article: en

## DISH Q105535583
- name: Rendang maco
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, rendang

## DISH Q105535632
- name: Rendang jariang
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, rendang
- ingredients: Archidendron pauciflorum

## DISH Q1055395
- name: Trofie
- description: type of pasta
- countries: IT
- kinds: pasta
- ingredients: durum wheat semolina
- has Wikipedia article: en

## DISH Q105542530
- name: Kerupuk puli
- description: rice cracker from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, krupuk, cracker
- ingredients: garlic, cooked rice, palm oil, table salt

## DISH Q105543455
- name: Dumbleng
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, rice dish
- ingredients: glutinous rice flour, brown sugar, coconut milk

## DISH Q105544074
- name: Kubang boyo
- description: Indonesian cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, sweet dish, kue
- ingredients: brown sugar, coconut, glutinous rice

## DISH Q105550816
- name: Pigs in a blanket
- description: savory pastry of the United States
- countries: (none)
- kinds: sausage rolls
- ingredients: Vienna sausage, dough
- has Wikipedia article: en

## DISH Q105556658
- name: Encacahuatado
- description: Mexican dish with meat and peanuts
- countries: MX
- kinds: dish
- has Wikipedia article: en

## DISH Q105561074
- name: Putu Ayu
- description: Traditional wet cake from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish, kue
- ingredients: wheat flour, rice flour, coconut milk, egg as food, table salt, sugar

## DISH Q105578604
- name: Efterrätter i Sverige
- other names: {"sv": "efterrätter i Sverige"}
- countries: (none)
- kinds: dessert

## DISH Q105588044
- name: Sausage roll
- other names: {"zh": "英式豬肉卷"}
- description: pastry snack popular in current and former Commonwealth nations
- countries: GB, IE
- cuisines: British cuisine, Irish cuisine
- kinds: pastry, sausage rolls
- ingredients: sausage meat, puff pastry
- has Wikipedia article: en, zh

## DISH Q105590538
- name: Huevo chimbo
- other names: {"es": "huevo chimbo"}
- countries: (none)
- kinds: dessert, meal

## DISH Q1055940
- name: Mozzarella stick
- other names: {"zh": "奶酪条"}
- description: U.S. dish of elongated pieces of deep-fried battered or breaded mozzarella
- countries: US
- cuisines: cuisine of the United States
- kinds: fried cheese, cheese stick
- ingredients: mozzarella
- has Wikipedia article: en

## DISH Q105594480
- name: Ceremito
- other names: {"it": "Ceremito"}
- countries: IT
- kinds: sweet bread

## DISH Q105616883
- name: Kue rambut
- description: traditional snack from East Nusa Tenggara, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, kue
- ingredients: palm sugar

## DISH Q105626150
- name: Kadyos, baboy, kag langka
- description: Filipino pork soup
- countries: PH
- cuisines: Filipino cuisine
- kinds: dish, soup
- ingredients: pork
- has Wikipedia article: en

## DISH Q105628576
- name: Kadyos, manok, kag ubad
- description: Filipino chicken soup
- countries: PH
- cuisines: Filipino cuisine
- kinds: dish, chicken soup
- has Wikipedia article: en

## DISH Q10563342
- name: Chabichou du Poitou
- other names: {"zh": "普瓦图沙比舒奶酪"}
- description: soft, unpasteurized, natural-rind French goat cheese
- countries: FR
- kinds: French cheese, chabichou
- ingredients: goat milk

## DISH Q105635905
- name: Tacos gobernador
- description: Mexican dish
- countries: MX
- kinds: taco
- ingredients: poblano, wheat tortilla, tomato, onion, cheese

## DISH Q1056366
- name: Soprèssa Vicentina PDO
- other names: {"zh": "Soprèssa Vicentina DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, salume
- ingredients: pork
- has Wikipedia article: en

## DISH Q10564295
- name: Tongshao cake
- other names: {"zh": "铜勺饼"}
- description: Chinese snack
- countries: CN
- kinds: cake
- has Wikipedia article: zh

## DISH Q105643832
- name: Chiabattini
- countries: (none)
- kinds: bread roll, ciabatta

## DISH Q10564512
- name: 长鱼面
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q105646100
- name: Rotweinbrot
- countries: (none)
- kinds: bread
- ingredients: red wine

## DISH Q105647365
- name: Muyuchi
- description: Peruvian dessert
- countries: PE
- kinds: meal, dessert

## DISH Q10564738
- name: Mending roubing
- other names: {"zh": "门钉肉饼"}
- description: beef pie of Beijing
- countries: CN
- kinds: meat pie
- has Wikipedia article: zh

## DISH Q105653979
- name: Boondi laddu
- countries: (none)
- kinds: laddu, dessert
- ingredients: besan, sugar, water

## DISH Q105654014
- name: Besan laddu
- countries: (none)
- kinds: laddu, dessert
- ingredients: besan, ghee, sugar

## DISH Q105654181
- name: Hyderabadi chicken biryani
- countries: (none)
- kinds: Hyderabadi biryani, chicken biryani, biryani
- ingredients: black cumin, clove, cardamom, onion, bay leaf, star anise, basmati, lemon, curd, nutmeg, cinnamon, saffron, chicken

## DISH Q105654208
- name: Hyderabadi mutton biryani
- countries: (none)
- kinds: mutton biryani, Hyderabadi biryani, biryani
- ingredients: nutmeg, cinnamon, saffron, black cumin, clove, cardamom, onion, bay leaf, star anise, basmati, lemon, curd, goat meat

## DISH Q105654264
- name: Hyderabadi beef biryani
- countries: (none)
- kinds: Hyderabadi biryani, beef biryani, biryani
- ingredients: black cumin, clove, cardamom, onion, bay leaf, star anise, basmati, lemon, curd, beef, nutmeg, cinnamon, saffron

## DISH Q105656628
- name: Mochar Chhenchki
- countries: (none)
- kinds: chhenchki
- ingredients: Plantain flower, fenugreek leaf, Mustardseed Oil, coconut, chili pepper, table salt

## DISH Q105656952
- name: Mochar borar dalna
- countries: (none)
- kinds: dalna, vegetable dish
- ingredients: Plantain flower, cumin seed, turmeric, potato, ginger, bay leaf, besan, chili pepper, table salt, sugar

## DISH Q105657097
- name: Dumurer Chhenchki
- countries: (none)
- kinds: chhenchki
- ingredients: Mustardseed Oil, turmeric, chili pepper, Ficus, table salt, sugar

## DISH Q105657270
- name: Kumro Chhenchki
- description: Bengali Cuisine
- countries: (none)
- kinds: chhenchki
- ingredients: black cumin, Mustardseed Oil, pumpkin, chili pepper, table salt

## DISH Q105657352
- name: Lau Chhenchki
- description: Bengali Cuisine
- countries: (none)
- kinds: chhenchki

## DISH Q10565830
- name: Ke-kńg
- other names: {"zh": "雞捲"}
- countries: TW
- cuisines: Taiwanese cuisine, Fujian cuisine
- kinds: dish
- has Wikipedia article: zh

## DISH Q105658458
- name: Mulo Chhenchki
- description: Bengali cuisine
- countries: (none)
- kinds: chhenchki
- ingredients: table salt

## DISH Q105658460
- name: Postor bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada
- ingredients: table salt

## DISH Q105658461
- name: Badhakopir bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada
- ingredients: table salt

## DISH Q105658462
- name: Khasta bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada
- ingredients: table salt

## DISH Q105658463
- name: Moong daler bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada
- ingredients: table salt

## DISH Q105658464
- name: Chholar irani dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish
- ingredients: table salt

## DISH Q105658465
- name: Enchor diye chholar dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish
- ingredients: table salt

## DISH Q105658467
- name: Mocha diye kolaier dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish
- ingredients: table salt

## DISH Q105658468
- name: Khesarir teto dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish
- ingredients: table salt

## DISH Q105658469
- name: Sobji Dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish
- ingredients: dal, table salt

## DISH Q105658470
- name: Aam diye motor dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish
- ingredients: table salt

## DISH Q105658471
- name: Jhinge diye muger dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish
- ingredients: table salt

## DISH Q105658472
- name: Jhinge posto chorchori
- description: bengali cuisine
- countries: (none)
- kinds: charchari
- ingredients: table salt

## DISH Q105658473
- name: Danta chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari
- ingredients: Mustardseed Oil, turmeric, mustard seed, chili pepper, table salt

## DISH Q105658475
- name: Dhenros chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari
- ingredients: Mustardseed Oil, okra, onion, chili pepper, table salt

## DISH Q105658476
- name: Begun chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari
- ingredients: Mustardseed Oil, turmeric, eggplant, onion, bay leaf, mustard seed, chili pepper, table salt

## DISH Q105658477
- name: Potol alu chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari
- ingredients: table salt

## DISH Q105658478
- name: Thor Chhenchki
- description: Bengali cuisine
- countries: (none)
- kinds: chhenchki
- ingredients: table salt

## DISH Q105658479
- name: Koraisuntir dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna, vegetable dish
- ingredients: table salt

## DISH Q105658480
- name: Chhanar dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna, vegetable dish
- ingredients: table salt

## DISH Q105658481
- name: Enchorer dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna, vegetable dish
- ingredients: table salt

## DISH Q105658482
- name: Fulkopir dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna, vegetable dish
- ingredients: table salt

## DISH Q105658483
- name: Peper dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna, vegetable dish
- ingredients: table salt

## DISH Q105658484
- name: Palong saker ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: table salt

## DISH Q105658485
- name: Mochar ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: table salt

## DISH Q105658486
- name: Mulor ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: table salt

## DISH Q105658487
- name: Lauer ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: table salt

## DISH Q105658488
- name: Fulkopir ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: table salt

## DISH Q105658489
- name: Badhakopir ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: table salt

## DISH Q105658490
- name: Potoler ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: table salt

## DISH Q105658492
- name: Chhanchi kumror ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: table salt

## DISH Q105658493
- name: Kochushaker ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: table salt

## DISH Q105658494
- name: Panchmishali ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: table salt

## DISH Q105658495
- name: Alur dom
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658496
- name: Enchorer kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish
- ingredients: table salt

## DISH Q105658497
- name: Badhakopir kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish
- ingredients: table salt

## DISH Q105658498
- name: Alu kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, potato dish
- ingredients: table salt, potato

## DISH Q105658499
- name: Kanchakolar kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish
- ingredients: table salt

## DISH Q105658500
- name: Mochar kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish
- ingredients: table salt

## DISH Q105658501
- name: Dhonkar kaliya
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish
- ingredients: table salt

## DISH Q105658502
- name: Chhanar kaliya
- description: Bengali cuisine
- countries: (none)
- kinds: kaliya
- ingredients: table salt

## DISH Q105658503
- name: Postor kaliya
- description: Bengali cuisine
- countries: (none)
- kinds: kaliya, vegetable dish
- ingredients: table salt

## DISH Q105658504
- name: Sada polau
- description: Bengali cuisine
- countries: (none)
- kinds: pilaf
- ingredients: table salt

## DISH Q105658505
- name: Sobji polau
- description: Bengali cuisine
- countries: (none)
- kinds: pilaf
- ingredients: table salt

## DISH Q105658506
- name: Misti kumror polau
- description: Bengali cuisine
- countries: (none)
- kinds: pilaf
- ingredients: table salt

## DISH Q105658507
- name: Anaroser polau
- description: Bengali cuisine
- countries: (none)
- kinds: pilaf, vegetable dish
- ingredients: table salt

## DISH Q105658508
- name: Nonta dalia
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658509
- name: Niramish korma
- description: Bengali cuisine
- countries: (none)
- kinds: korma, vegetable dish
- ingredients: table salt

## DISH Q105658510
- name: Chhanar chop
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658517
- name: Niramish sombol
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658518
- name: Khasta patabahar
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658519
- name: Fulkopir anondivog
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658520
- name: Chholar shami kebab
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658522
- name: Aam pulao
- description: Bengali cuisine
- countries: (none)
- kinds: pilaf, rice dish
- ingredients: table salt

## DISH Q105658523
- name: Thorer dhoka
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658524
- name: Chhanar koptakari
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish
- ingredients: table salt

## DISH Q105658525
- name: Doi fulkopi
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658526
- name: Potoler paturi
- description: Bengali cuisine
- countries: (none)
- kinds: paturi
- ingredients: table salt

## DISH Q105658527
- name: Vapa doi
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658528
- name: Lebupatar ghee bhat
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658529
- name: Alur malai dom
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658530
- name: Malai kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish
- ingredients: table salt

## DISH Q105658531
- name: Khoyar polau
- description: Bengali cuisine
- countries: (none)
- kinds: pilaf
- ingredients: table salt

## DISH Q105658532
- name: Narkeler korma
- description: Bengali cuisine
- countries: (none)
- kinds: korma
- ingredients: table salt

## DISH Q105658533
- name: Nobabi motorsunti
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658534
- name: Nabaratna korma
- description: Bengali cuisine
- countries: (none)
- kinds: korma, vegetable dish
- ingredients: table salt

## DISH Q105658535
- name: Enchorer kima
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658536
- name: Makhani dal kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta
- ingredients: table salt

## DISH Q105658537
- name: Gota seddho
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658538
- name: Mulo shaker chhenchki
- description: Bengali cuisine
- countries: (none)
- kinds: chhenchki
- ingredients: table salt

## DISH Q105658540
- name: Sojne dantar chhechki
- description: Bengali cuisine
- countries: (none)
- kinds: chhenchki
- ingredients: table salt

## DISH Q105658541
- name: Sojne fuler chhechki
- description: Bengali cuisine
- countries: (none)
- kinds: chhenchki
- ingredients: table salt

## DISH Q105658542
- name: Sojne dantar chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari
- ingredients: table salt

## DISH Q105658544
- name: Dumurer kopta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, vegetable dish
- ingredients: table salt

## DISH Q105658545
- name: Sorse begun
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658546
- name: Olkopir dalna
- description: Bengali cuisine
- countries: (none)
- kinds: dalna
- ingredients: table salt

## DISH Q105658547
- name: Jafrani fulkopi
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658548
- name: Musur dal er cutlet
- description: Bengali cuisine
- countries: (none)
- kinds: cutlet
- ingredients: table salt

## DISH Q105658549
- name: Begun bahari
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658550
- name: Beguner vorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta
- ingredients: table salt

## DISH Q105658551
- name: Kashmiri begun
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658552
- name: Sorse kochu
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658553
- name: Kumror kopta
- description: bengali cuisine
- countries: (none)
- kinds: kofta
- ingredients: table salt

## DISH Q105658554
- name: Bokful ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto
- ingredients: Mustardseed Oil, cumin seed, coriander seed, potato, coconut, wheat flour, Sesbania grandiflora, table salt, sugar

## DISH Q105658555
- name: Bokfuler bora
- description: bengali cuisine
- countries: (none)
- kinds: Vada
- ingredients: Mustardseed Oil, poppy seed, Sesbania grandiflora, besan, chili pepper, table salt

## DISH Q105658556
- name: Dana methir torokari
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658558
- name: Fulkopir porota
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658559
- name: Alur rosa
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658561
- name: Beguner cutlet
- description: Bengali cuisine
- countries: (none)
- kinds: cutlet
- ingredients: table salt

## DISH Q105658569
- name: Aamer morobba
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658574
- name: Kuler ombol
- description: Bengali cuisine
- countries: (none)
- kinds: Ambal
- ingredients: table salt

## DISH Q105658575
- name: Amrar ombol
- description: Bengali cuisine
- countries: (none)
- kinds: Ambal
- ingredients: table salt

## DISH Q105658576
- name: Kochi aamer ombol
- description: bengali cuisine
- countries: (none)
- kinds: Ambal
- ingredients: table salt

## DISH Q105658578
- name: Kancha aamer sorbot
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
- ingredients: table salt

## DISH Q105658939
- name: Koraishunti vate
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658941
- name: Alu dal vate
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658942
- name: Lau shak posto vate
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658943
- name: Kumro vate
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658944
- name: Motor dal vate
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q105658945
- name: Muger dal o kanthal bichi vate
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
