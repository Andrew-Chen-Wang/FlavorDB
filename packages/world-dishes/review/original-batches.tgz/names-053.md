# Review batch names-053

## DISH Q721181
- name: German chocolate cake
- other names: {"zh": "德式巧克力蛋糕"}
- description: layer cake with chocolate and a coconut-pecan frosting
- countries: US
- kinds: chocolate cake, layer cake
- ingredients: coconut, pecan nut, chocolate
- has Wikipedia article: en, zh

## DISH Q7212290
- name: Wanluan pork knuckle
- other names: {"zh": "萬巒豬腳"}
- description: traditional Taiwanese ham hock dish
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q7212637
- name: Sampan congee
- other names: {"zh": "艇仔粥"}
- description: congee of Guangdong
- countries: CN
- kinds: congee
- has Wikipedia article: en, zh

## DISH Q7212709
- name: Iahnie
- description: Romanian bean stew
- countries: (none)
- kinds: ragout, dish
- ingredients: bean

## DISH Q7212986
- name: Cantonese slow-cooked soup
- other names: {"zh": "老火汤"}
- description: Cantonese soup
- countries: CN
- kinds: soup
- has Wikipedia article: en, zh

## DISH Q7214426
- name: Frybread
- other names: {"zh": "炸麵包"}
- description: flat bread, fried or deep-fried in oil, shortening, or lard; dish of the U.S. indigenous people
- countries: US
- kinds: flatbread
- has Wikipedia article: en, zh

## DISH Q7215544
- name: Tube rice pudding
- other names: {"zh": "筒仔米糕"}
- description: Taiwanese rice dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: rice pudding, rice dish
- has Wikipedia article: en, zh

## DISH Q7216960
- name: Shaguo
- other names: {"zh": "砂锅"}
- description: Chinese clay pots and dishes
- countries: (none)
- kinds: cookware and bakeware, dish
- has Wikipedia article: zh

## DISH Q7217773
- name: Pomana porcului
- description: Romanian meat dish
- countries: (none)
- kinds: meat dish

## DISH Q722002
- name: Paprikash
- description: Hungarian dish
- countries: HU
- cuisines: Hungarian cuisine
- kinds: ragout, dish
- ingredients: paprika, smetana, Allium, meat

## DISH Q7220505
- name: Hong Kong Style Beef Entrails
- other names: {"zh": "牛杂"}
- description: cantonese beef dish
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en, zh

## DISH Q7220675
- name: Nutritious sandwich
- other names: {"zh": "營養三明治"}
- description: type of sandwich originating from Taiwan
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q7220724
- name: Roast duck
- other names: {"zh": "烧鸭"}
- description: roast duck in Nanjing and Guangdong
- countries: CN
- kinds: roast duck
- has Wikipedia article: zh

## DISH Q7220887
- name: Baked pork chop rice
- other names: {"zh": "焗猪扒饭"}
- description: rice dish of Hong Kong
- countries: HK
- cuisines: Hong Kong cuisine
- kinds: rice dish
- ingredients: pork chop, rice
- has Wikipedia article: en, zh

## DISH Q7224024
- name: Shanghai fried noodles
- other names: {"zh": "上海粗炒"}
- description: type of fried thick noodles originating from Shanghai
- countries: CN
- kinds: dish
- ingredients: beef
- has Wikipedia article: en, zh

## DISH Q7225702
- name: Pollo motuleños
- description: Mexican chicken dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q722595
- name: Quiche
- other names: {"zh": "法式咸派"}
- description: savoury open pastry tart with a filling of egg, dairy and other ingredients
- countries: FR
- cuisines: French cuisine
- kinds: tart, meat pastry, egg dish, savoury pie
- ingredients: migaine, shortcrust pastry, egg as food
- has Wikipedia article: en, zh

## DISH Q7227262
- name: Pomegranate soup
- description: Iranian and Iraqi dish
- countries: IR
- kinds: food, fruit soup
- ingredients: pomegranate
- has Wikipedia article: en

## DISH Q7227449
- name: Pompano en Papillote
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q7228182
- name: Pontefract cake
- other names: {"zh": "甘草甜餅"}
- description: type of liquorice candy
- countries: (none)
- kinds: confectionery
- ingredients: liquorice
- has Wikipedia article: en, zh

## DISH Q7228599
- name: Poolaki
- description: certain sort of candy typically made in Iran
- countries: IR
- kinds: food, pastry
- ingredients: sugar
- has Wikipedia article: en

## DISH Q7228863
- name: Poornalu
- description: sweet snack food
- countries: IN
- kinds: sweet dish, snack
- ingredients: rice flour, jaggery, legume
- has Wikipedia article: en

## DISH Q7228884
- name: Pootharekulu
- description: popular Indian sweet from Atreyapuram, East Godavari
- countries: IN
- kinds: food, dessert, dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q7230141
- name: Pork tenderloin sandwich
- description: Type of sandwich originating from the United States
- countries: US
- cuisines: cuisine of the Midwestern United States
- kinds: food, pork dish
- ingredients: breaded cutlet
- has Wikipedia article: en

## DISH Q7230368
- name: Porra antequerana
- description: Spanish cold soup
- countries: ES
- cuisines: Andalusian cuisine
- kinds: soup, gazpacho, bread dish
- ingredients: garlic, tomato, bread
- has Wikipedia article: en

## DISH Q7231310
- name: Port sausage
- description: Iranian dish
- countries: IR
- kinds: fast food, dish, sausage sandwich
- ingredients: tomato, onion, tomato paste, sausage, spice
- has Wikipedia article: en

## DISH Q7232139
- name: Lörtsy
- description: Finnish pastry
- countries: FI
- cuisines: Finnish cuisine
- kinds: food, pie
- has Wikipedia article: en

## DISH Q7232702
- name: Portuguese asado
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q7232800
- name: Portuguese sauce
- other names: {"zh": "葡汁"}
- description: Macanese sauce or curry
- countries: MO
- kinds: curry
- ingredients: curry powder
- has Wikipedia article: en, zh

## DISH Q7234749
- name: Lompe
- description: Norwegian flat potato bread
- countries: (none)
- kinds: potato dish
- ingredients: flour, table salt, potato

## DISH Q7234785
- name: Potbrood
- description: bread made by Boer settlers (South Africa)
- countries: ZA
- kinds: food, bread
- has Wikipedia article: en

## DISH Q7235555
- name: Poularde Albufera
- description: chicken dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q7235559
- name: Poulet au fromage
- description: French chicken and cheese dish
- countries: FR
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q7238914
- name: Prawn roll
- description: Australian foodstuff
- countries: AU
- kinds: food, sandwich
- ingredients: white bread
- has Wikipedia article: en

## DISH Q7238917
- name: Prawn soup
- description: soup dish prepared using freshwater or saltwater prawns as a primary ingredient
- countries: CA
- kinds: food, soup
- ingredients: prawn
- has Wikipedia article: en

## DISH Q7242496
- name: Prežganka
- description: Slovenian national soup
- countries: SI
- kinds: food, soup
- ingredients: flour
- has Wikipedia article: en

## DISH Q7246164
- name: 大菜糕
- countries: CN
- kinds: dessert
- ingredients: agar
- has Wikipedia article: zh

## DISH Q72473439
- name: Creamed Turkish Delights
- description: dessert
- countries: TR
- kinds: dessert, mehallabiyya

## DISH Q72474549
- name: Muhallebi with kadayıf
- description: dessert
- countries: TR
- kinds: dessert, mehallabiyya

## DISH Q724855
- name: Brillat-Savarin cheese
- other names: {"zh": "布里亚-萨瓦兰奶酪"}
- description: French soft cheese
- countries: FR
- kinds: white mold-rind cheese, French cheese, cow's-milk cheese, protected geographical indication
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q7248936
- name: Proja
- description: type of cornbread
- countries: RS
- kinds: food, cornbread
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q7249903
- name: Chiayi turkey rice
- other names: {"zh": "嘉義火雞肉飯"}
- description: Taiwanese rice and turkey dish
- countries: TW
- kinds: type of food or dish, rice dish
- ingredients: turkey meat
- has Wikipedia article: en, zh

## DISH Q725125
- name: Ma'amoul
- description: Arabic shortbread cookies made of semolina and butter
- countries: SA
- cuisines: Arab cuisine
- kinds: food, dessert
- has Wikipedia article: en

## DISH Q7254007
- name: Psarosoupa
- description: Greek fish soup
- countries: GR
- cuisines: Greek cuisine
- kinds: soup, fish soup, fish dish
- has Wikipedia article: en

## DISH Q7257218
- name: Pu pu platter
- description: tray of American Chinese cuisine
- countries: (none)
- kinds: platter
- ingredients: meat
- has Wikipedia article: en

## DISH Q7258416
- name: 例湯
- description: soup of the day served in Hong Kong restaurants
- countries: CN
- cuisines: Hong Kong cuisine
- kinds: soup, dish
- has Wikipedia article: zh

## DISH Q7258891
- name: Puftaloon
- description: Australian fried scone
- countries: AU
- kinds: pastry, scone
- ingredients: flour
- has Wikipedia article: en

## DISH Q7259285
- name: Pule cheese
- description: Serbian donkey and goat's milk cheese
- countries: RS
- kinds: cheese
- ingredients: goat milk, donkey milk
- has Wikipedia article: en

## DISH Q7260511
- name: Kalya
- description: soup (Russian cuisine)
- countries: RU
- cuisines: Russian cuisine
- kinds: soup
- ingredients: brine, Salzgurke, meat, fish

## DISH Q7261610
- name: Purtumute
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q7261960
- name: Pustakari
- description: Nepali candy
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q7262811
- name: Pyaaj Kachori
- description: Indian fried pastry
- countries: IN
- kinds: snack, Kachori, deep-fried food
- ingredients: all-purpose flour, Allium
- has Wikipedia article: en

## DISH Q7264577
- name: Pâté chaud
- description: Vietnamese savory puff pastry
- countries: VN
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q7264950
- name: One bite sausage
- other names: {"zh": "一口香腸"}
- countries: CN
- kinds: mini sausage
- has Wikipedia article: zh

## DISH Q726570
- name: Torta pasqualina
- countries: IT
- cuisines: Italian cuisine
- kinds: Easter food, savoury pie
- ingredients: spinach, ricotta, olive oil, cheese

## DISH Q7268152
- name: Qottab
- other names: {"zh": "伊朗油炸饼"}
- description: deep-fried Iranian almond pastry
- countries: IR
- kinds: food, pastry
- ingredients: cardamom, almond, flour
- has Wikipedia article: en, zh

## DISH Q7268264
- name: Quad City-style pizza
- description: pizza style originating from Quad Cities, US, characterized by a malt crust, tomato sauce with chili flakes, toppings placed under cheese, and being cut into strips
- countries: US
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q7271180
- name: Queijadinha
- description: Brazilian dessert made of eggs and cheese
- countries: BR
- kinds: jam, confectionery
- ingredients: coconut, egg, cheese
- has Wikipedia article: en

## DISH Q7271398
- name: Quesito
- description: pastry from Puerto Rico
- countries: PR
- kinds: food, pastry
- ingredients: puff pastry
- has Wikipedia article: en

## DISH Q727198
- name: Sinseollo
- other names: {"zh": "神仙炉"}
- description: Korean food
- countries: (none)
- kinds: food, soup
- ingredients: meatball
- has Wikipedia article: en, zh

## DISH Q7272094
- name: Quince dessert
- description: Turkish dessert made with quince fruits
- countries: TR
- kinds: dish, dessert
- ingredients: quince
- has Wikipedia article: en

## DISH Q727210
- name: Asiago PDO
- other names: {"zh": "Asiago DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cow's-milk cheese, pressed cooked cheese, Italian cheese, cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q7273069
- name: Quzi
- other names: {"zh": "庫奇"}
- description: roasted goat or lamb dish popular in Oman and the UAE
- countries: (none)
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q7278468
- name: Rab cake
- description: dessert from Rab, Croatia
- countries: HR
- kinds: food, pastry
- ingredients: Prunus dulcis
- has Wikipedia article: en

## DISH Q7278638
- name: Rabbit pie
- description: pie consisting of rabbit meat in a gravy
- countries: GB
- kinds: food, pie
- ingredients: rabbit meat
- has Wikipedia article: en

## DISH Q72817580
- name: Bürli
- description: A type of breadroll from Switzerland.
- countries: (none)
- kinds: bread roll

## DISH Q7283353
- name: Raheb
- description: Lebanese Food
- countries: (none)
- kinds: salad
- ingredients: eggplant
- has Wikipedia article: en

## DISH Q7285800
- name: Rajas con crema
- description: typical Mexican dish
- countries: MX
- kinds: dish
- has Wikipedia article: en

## DISH Q72886132
- name: Plombières kremasi
- other names: {"tr": "Plombières kremasi"}
- countries: FR
- kinds: dessert, custard

## DISH Q7289179
- name: Rambak petis
- description: Javanese snack
- countries: (none)
- kinds: food, beef dish
- has Wikipedia article: en

## DISH Q729292
- name: Pretuziano delle Colline Teramane PDO
- other names: {"zh": "Pretuziano delle Colline Teramane DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q7295192
- name: Raspberry Ripple
- other names: {"zh": "樹莓漩渦冰淇淋"}
- description: flavour of ice-cream
- countries: GB
- kinds: ice cream
- ingredients: raspberry
- has Wikipedia article: en, zh

## DISH Q7296297
- name: Rava idli
- description: Semolina idli of Karnataka
- countries: IN
- kinds: idli, semolina
- ingredients: semolina
- has Wikipedia article: en

## DISH Q7299696
- name: Razzleberry pie
- description: type of pie
- countries: (none)
- kinds: food, pie

## DISH Q73021048
- name: Bread cubes
- countries: (none)
- kinds: baked good, food ingredient
- ingredients: white bread

## DISH Q7304713
- name: Red Peas Soup
- description: Jamaican soup
- countries: JM
- kinds: soup, stew
- ingredients: Sweet potato, kidney bean, yam, onion, dumpling, beef
- has Wikipedia article: en

## DISH Q7305283
- name: Red bean cake
- other names: {"zh": "红豆糕"}
- description: dessert made with red bean paste
- countries: CN
- kinds: cake
- ingredients: red bean paste
- has Wikipedia article: en, zh

## DISH Q7305369
- name: Red pudding
- description: meat dish served mainly at chip shops in Scotland; made with beef, pork, pork rind or bacon, suet, rusk, wheat flour, spices, salt, beef fat and colouring, formed into a sausage shape, coated in a batter, deep fried, and served hot
- countries: GB
- kinds: savory pudding
- ingredients: bacon
- has Wikipedia article: en

## DISH Q7305387
- name: Red slaw
- description: Condiment
- countries: US
- kinds: salad
- ingredients: Brassica oleracea var. capitata
- has Wikipedia article: en

## DISH Q7306192
- name: Redonkadonk
- description: Portland sandwich variety
- countries: US
- kinds: food, sandwich
- ingredients: grilled cheese, Spam, ham, egg as food, bacon, cheese
- has Wikipedia article: en

## DISH Q7307455
- name: Uih sepit
- other names: {"zh": "扇饼"}
- description: Indonesian traditional cookies
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack, kue, Kuih
- ingredients: wheat flour, coconut milk, flour, sugar
- has Wikipedia article: en

## DISH Q7308233
- name: Asam rong
- description: fermented durian paste
- countries: MY
- cuisines: Malaysian cuisine, Malay cuisine
- kinds: condiment
- ingredients: Elateriospermum tapos, Hevea brasiliensis, durian, table salt

## DISH Q7309235
- name: Ayam pansuh
- other names: {"zh": "砂拉越竹筒鸡"}
- description: Indonesian and Malaysian chicken dish
- countries: MY
- kinds: chicken dish, dish
- ingredients: chicken
- has Wikipedia article: en

## DISH Q7309432
- name: Açorda
- description: Portuguese bread soup
- countries: PT
- kinds: dish, soup
- ingredients: garlic, broth, olive oil, Allium sativum, bread
- has Wikipedia article: en

## DISH Q7312056
- name: Remonce
- description: Traditional Danish pastry filling
- countries: DK
- kinds: pastry
- ingredients: butter
- has Wikipedia article: en

## DISH Q7313383
- name: Bepang
- description: sweet dish in Malaysia
- countries: MY
- cuisines: Malay cuisine
- kinds: brittle, Kuih
- ingredients: sesame seed, peanut, sugar

## DISH Q7315388
- name: Reshteh khoshkar
- description: Iranian cookie
- countries: IR
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q7318504
- name: Revithia
- countries: GR
- kinds: food, soup
- ingredients: chickpea

## DISH Q731971
- name: Békési Szilvapálinka
- countries: HU
- kinds: Pálinka

## DISH Q732
- name: Francesinha
- other names: {"zh": "葡式三明治"}
- description: Portuguese sandwich
- countries: PT
- cuisines: Portuguese cuisine
- kinds: sandwich
- ingredients: bread
- has Wikipedia article: en, zh

## DISH Q7321536
- name: Rhubarb tart
- description: food
- countries: (none)
- kinds: tart
- ingredients: rhubarb
- has Wikipedia article: en

## DISH Q7322232
- name: Ribberull
- description: Norwegian seasoned meat roll
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q7323065
- name: Rice and curry
- description: popular dish in South Asia
- countries: (none)
- kinds: rice dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q7323066
- name: Rice and peas
- other names: {"zh": "豌豆飯"}
- description: traditional food within the West Indian Caribbean islands
- countries: (none)
- kinds: traditional food, rice and beans
- ingredients: rice
- has Wikipedia article: en

## DISH Q7323073
- name: Rice cracker
- other names: {"zh": "米果"}
- description: cracker made from rice
- countries: (none)
- kinds: food, cracker
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q7324076
- name: Daen semur
- description: Bajau traditional cuisine
- countries: (none)
- kinds: dish

## DISH Q733196
- name: Bollito misto
- description: Italian stew
- countries: IT
- kinds: stew
- ingredients: beef
- has Wikipedia article: en

## DISH Q73337
- name: Dong'an chicken
- other names: {"zh": "东安子鸡"}
- description: Chinese chicken dish
- countries: CN
- cuisines: Chinese cuisine
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q7334640
- name: Rinderbraten
- description: dish of German origin whose name means "beef roast"
- countries: DE
- kinds: roast, beef dish
- ingredients: round steak, beef
- has Wikipedia article: en

## DISH Q733844
- name: Narutomaki
- other names: {"zh": "鳴門卷"}
- description: Japanese dish
- countries: JP
- cuisines: Japanese Chinese cuisine
- kinds: kamaboko
- ingredients: fish surimi
- has Wikipedia article: en, zh

## DISH Q733855
- name: Torma
- other names: {"zh": "朵玛"}
- description: figures made of flour and butter used as offerings in Tibetan Buddhism
- countries: (none)
- kinds: pound cake
- has Wikipedia article: en, zh

## DISH Q7339905
- name: Roast lamb with laver sauce
- description: Welsh lamb dish
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q7339907
- name: Roast pig
- other names: {"zh": "烤猪"}
- description: roasted whole pig
- countries: (none)
- kinds: type of cooked meat, roast, pork dish
- has Wikipedia article: en, zh

## DISH Q7339908
- name: Roasted piglet
- description: Serbian dish of roast meat
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q734527
- name: Svartsoppa
- other names: {"zh": "斯堪尼黑湯"}
- description: traditional Swedish dish
- countries: SE
- kinds: soup
- ingredients: blood as food
- has Wikipedia article: en

## DISH Q7346087
- name: Peshte Zik
- countries: (none)
- kinds: pastry

## DISH Q7348639
- name: Hinava
- other names: {"zh": "卡达山腌鱼"}
- description: Kadazandusun cuisine in Sabah
- countries: MY
- kinds: raw fish dish
- ingredients: fish
- has Wikipedia article: en

## DISH Q734978
- name: Maroilles
- other names: {"zh": "玛瑞里斯芝士"}
- description: cow's-milk cheese made in the regions of Picardy and Nord-Pas-de-Calais in northern France
- countries: FR
- kinds: French cheese, cow's-milk cheese, washed-rind cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q7354260
- name: Rock
- other names: {"zh": "切糖"}
- description: type of hard stick-shaped boiled sugar confectionery
- countries: GB
- kinds: hard candy
- ingredients: sugar
- has Wikipedia article: en

## DISH Q7354783
- name: Rock cake
- description: small fruit cake resembling a rock
- countries: GB
- kinds: food, fruitcake
- ingredients: flour
- has Wikipedia article: en

## DISH Q7360977
- name: Rollatini
- description: Italian-style dish
- countries: IT
- cuisines: Italian-American cuisine
- kinds: food, chicken dish, beef dish, eggplant rolls
- ingredients: eggplant
- has Wikipedia article: en

## DISH Q7360993
- name: Rolled oyster
- description: seafood dish from Louisville, Kentucky, U.S. consisting of three oysters dipped in an egg-milk cornmeal batter (pastinga), rolled in cracker crumbs, and deep-fried
- countries: US
- kinds: oyster dish
- ingredients: cornmeal, oyster
- has Wikipedia article: en

## DISH Q7363037
- name: Ketupat sotong
- countries: MY, TH
- kinds: ketupat, squid dish

## DISH Q7367025
- name: Rosa Camuna
- description: Italian cheese
- countries: IT
- kinds: cheese
- has Wikipedia article: en

## DISH Q7367472
- name: Rosca
- description: Spanish bread dish
- countries: ES
- kinds: bread
- has Wikipedia article: en

## DISH Q7367597
- name: Roscón
- description: Bread
- countries: CO, ES
- kinds: bread
- has Wikipedia article: en

## DISH Q7367928
- name: Kuih hasidah
- other names: {"ms": "Kuih hasidah"}
- countries: (none)
- kinds: food, Kuih

## DISH Q7367945
- name: Karas
- description: traditional food in Kedah
- countries: MY
- cuisines: Malay cuisine
- kinds: food, Kuih
- has Wikipedia article: en

## DISH Q7367950
- name: Kuih kasturi
- countries: (none)
- kinds: Kuih

## DISH Q7367962
- name: Kuih keria
- description: Indian-style of doughnut
- countries: MY
- kinds: doughnut, kue
- ingredients: wheat flour, Sweet potato, sugar

## DISH Q7367965
- name: Lepat
- other names: {"id": "Lepat"}
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, human food, type of food or dish, dessert
- ingredients: banana leaf, cooking oil, glutinous rice

## DISH Q7369003
- name: Roskette
- description: traditional Chamorro cornstarch cookies
- countries: GU
- kinds: cookie
- ingredients: corn starch, shortening, egg as food, flour, butter, baking powder, vanilla, cream, sugar, milk
- has Wikipedia article: en

## DISH Q7370092
- name: Rosvopaisti
- description: type of roast meat
- countries: FI
- kinds: dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q7370536
- name: Roti buaya
- description: Betawi traditional bread
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: wheat flour, baker's yeast, egg yolk, egg as food, flour, butter, table salt, sugar, milk, water
- has Wikipedia article: en

## DISH Q7370537
- name: Roti john
- other names: {"zh": "羅地藏"}
- description: Malay traditional sandwich, popular in Indonesia, Malaysia and Singapore
- countries: SG
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q7370546
- name: Roti tissue
- description: Malay sweet flatbread
- countries: MY
- kinds: food, dessert
- has Wikipedia article: en

## DISH Q7371070
- name: Penang laksa
- other names: {"zh": "亞參叻沙"}
- description: traditional noodle dish from Penang, Malaysia.
- countries: (none)
- kinds: laksa
- has Wikipedia article: zh

## DISH Q73738953
- name: Apple fritter
- countries: (none)
- kinds: fritter
- ingredients: apple

## DISH Q73740055
- name: Appelbeignet
- countries: (none)
- kinds: beignet, apple fritter, holiday dish
- ingredients: oil, flour, apple

## DISH Q73740415
- name: Beignets aux pommes
- description: fried traditional dish
- countries: (none)
- kinds: beignet

## DISH Q73755
- name: Melba toast
- description: dry, crisp, thinly sliced toast, often served with soup and salad or topped with either melted cheese or pâté, named after Nellie Melba, invented by Auguste Escoffier
- countries: GB
- cuisines: British cuisine
- kinds: dish
- ingredients: toast
- has Wikipedia article: en

## DISH Q7375707
- name: Ruan zha li ji
- description: Chinese pork dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q7377183
- name: Leker Cake
- description: banana cake Surabaya
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: sago flour, wheat flour, rice flour, baking powder, vanilla, sugar, cheese, milk, banana
- has Wikipedia article: en

## DISH Q7377378
- name: Lempuk
- description: Food made from durian
- countries: ID, MY
- cuisines: dessert
- kinds: snack, Dodol, kue
- ingredients: sugar, palm sugar, Durio zibethinus, durian

## DISH Q7378690
- name: Rui-be
- description: Japanese frozen raw salmon dish
- countries: JP
- cuisines: Ainu cuisine
- kinds: sashimi, frozen food, preserved fish, salmon dish
- has Wikipedia article: en

## DISH Q7379736
- name: Lontong Mi
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: soup, noodle dish
- ingredients: mung bean sprout, lontong, noodle

## DISH Q7380415
- name: Layered Rye Bread
- other names: {"zh": "分層黑麥麵包"}
- description: traditional Latvian dessert
- countries: LV
- kinds: dessert
- ingredients: rupjmaize, varenye, whipped cream
- has Wikipedia article: en

## DISH Q7380416
- name: Rupjmaize
- other names: {"zh": "拉脱维亚黑麦面包"}
- description: Latvian rye bread
- countries: LV
- kinds: baked good, rye bread
- ingredients: caraway seeds, rye flour, malt, table salt, water
- has Wikipedia article: en, zh

## DISH Q7382526
- name: Rustlers
- description: hamburgers and sandwiches made by Kepak
- countries: (none)
- kinds: hamburger
- has Wikipedia article: en

## DISH Q7386700
- name: Rössypottu
- description: traditional Finnish dish
- countries: FI
- kinds: soup, stew, pork dish
- has Wikipedia article: en

## DISH Q7386960
- name: Rượu thuốc
- description: Vietnamese distilled liquor (rượu) with herbs and medical animals
- countries: VN
- kinds: Medicinal liquor
- has Wikipedia article: en

## DISH Q7386961
- name: Rượu đế
- other names: {"zh": "越南燒酒"}
- description: distilled liquor from Vietnam
- countries: VN
- kinds: liquor
- has Wikipedia article: en

## DISH Q7386962
- name: Rượu nếp
- other names: {"zh": "越南糯米酒"}
- description: Mildly alcoholic Vietnamese pudding or wine made from fermented glutinous rice
- countries: VN
- kinds: rice pudding
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q7387254
- name: S.O.S.
- other names: {"zh": "S.O.S."}
- description: traditional Swedish appetizer
- countries: SE
- kinds: appetizer
- ingredients: herring
- has Wikipedia article: en, zh

## DISH Q739276
- name: Suquet de peix
- description: Catalan seafood potato stew
- countries: (none)
- kinds: fish soup, potato dish

## DISH Q7395354
- name: Nasi tumpang
- other names: {"zh": "隆帮饭"}
- description: Rice dish originating from Kelantanese
- countries: MY
- cuisines: Malay cuisine
- kinds: food, egg dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q7395368
- name: Nasi goreng kampung
- other names: {"ms": "Nasi goreng kampung"}
- countries: (none)
- kinds: food, fried rice

## DISH Q7395374
- name: Rice himpit
- other names: {"zh": "马来方块饭"}
- countries: MY
- cuisines: Malay cuisine
- kinds: rice dish
- ingredients: Oryza, cooked rice

## DISH Q7395806
- name: Sabaayad
- description: Meal in Somalia and Djibouti
- countries: SO
- kinds: food, flatbread
- ingredients: flour
- has Wikipedia article: en

## DISH Q7396316
- name: Sabounee
- description: pasta
- countries: (none)
- kinds: pasta dish
- ingredients: meat

## DISH Q7396619
- name: Sacchettoni
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q7398299
- name: Saengchae
- description: Korean salad
- countries: (none)
- kinds: salad, Kimchi, namul
- has Wikipedia article: en

## DISH Q7399325
- name: Sagnarelli
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q7402697
- name: Sajji
- description: foodstuff
- countries: (none)
- kinds: lamb dish, chicken dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q7404293
- name: Pelara
- description: Traditional Malaysian heritage fermented fish condiment from Terengganu made of shortfin scad
- countries: MY
- cuisines: Malay cuisine
- kinds: condiment, fish dish
- ingredients: fish, grated coconut, Tamarindus indica, Decapterus, table salt

## DISH Q7405551
- name: Salmon burger
- description: fishcake made from salmon in the style of a hamburger
- countries: (none)
- kinds: fishcake, salmon dish, fish sandwich
- ingredients: salmon
- has Wikipedia article: en

## DISH Q7405554
- name: Salmon pie
- description: savoury fish pie
- countries: (none)
- kinds: food, salmon dish
- ingredients: salmon
- has Wikipedia article: en

## DISH Q7405557
- name: Salmon tartare
- other names: {"zh": "韃靼三文魚"}
- description: raw fish dish
- countries: (none)
- kinds: dish, salmon dish, raw fish dish, tartare
- has Wikipedia article: en, zh

## DISH Q7405791
- name: Salt-rising bread
- description: Style of bacteria-risen bread
- countries: (none)
- kinds: bread, baked good
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q7406015
- name: Salt water taffy
- other names: {"zh": "鹽水太妃糖"}
- description: type of soft candy
- countries: US
- kinds: food, candy
- ingredients: sugar
- has Wikipedia article: en

## DISH Q7409623
- name: Samlar machu
- description: Cambodian category of sour soups
- countries: KH
- kinds: sour soup
- ingredients: fruit, herb, Tamarindus indica, vegetable
- has Wikipedia article: en

## DISH Q7413072
- name: Pulut lepa
- description: Sticky rice dish with fish filling
- countries: MY
- cuisines: Asian cuisine, Malay cuisine
- kinds: Kuih, fish dish
- ingredients: paprika fruit, onion, glutinous rice, fish

## DISH Q741389
- name: Mesir macunu
- other names: {"zh": "梅西尔节"}
- description: Turkish confectionery
- countries: TR
- cuisines: Turkish cuisine
- kinds: macun şekeri
- has Wikipedia article: en

## DISH Q7414148
- name: San Francisco burrito
- other names: {"zh": "麦西恩卷饼"}
- description: San Francisco food
- countries: (none)
- kinds: burrito
- has Wikipedia article: en, zh

## DISH Q7415642
- name: Sanchuisanda
- description: Chinese flatbread
- countries: CN
- kinds: food, flatbread
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q7417786
- name: Sangak
- other names: {"zh": "桑嘎克"}
- description: Iranian whole wheat leavened flatbread
- countries: IR
- kinds: food, flatbread
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q7418536
- name: Sanjeok
- description: beef and vegetable skewers
- countries: (none)
- kinds: jeok
- has Wikipedia article: en

## DISH Q7418601
- name: Rujak cingur
- description: Indonesian salad
- countries: ID
- cuisines: Indonesian cuisine
- kinds: salad, rojak, dish, Indonesian cuisine, human food, traditional food, type of food or dish
- ingredients: Java tamarin, garlic, petis, mung bean sprout, peanut, lontong, cooking oil, water spinach, tofu, chili pepper, Tempeh, Cucumis sativus, table salt, water

## DISH Q7418805
- name: Sanna
- description: spongy steamed savoury rice cake
- countries: IN
- kinds: bread
- has Wikipedia article: en

## DISH Q7420724
- name: Santula
- description: vegetable dish from Odisha
- countries: IN
- kinds: potato dish, Indian curry, food
- ingredients: panch phoron, potato, tomato, eggplant, papaya, onion
- has Wikipedia article: en

## DISH Q74213459
- name: Omelette Arnold Bennett
- description: fish and egg dish
- countries: (none)
- kinds: omelette
- ingredients: chicken egg, smoked haddock, Parmesan, cream

## DISH Q742173
- name: Peixinhos da horta
- other names: {"zh": "花園魚"}
- description: Portuguese fried vegetable-based dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q742186
- name: Yassa (edziban)
- other names: {"zh": "亞薩"}
- description: Senegalese spicy marinated poultry, lamb or fish dish
- countries: SN
- cuisines: Senegalese cuisine
- kinds: meat dish, fish dish, chicken dish, food
- ingredients: onion, lemon, lamb meat, fish
- has Wikipedia article: en, zh

## DISH Q742224
- name: Pressed duck
- other names: {"zh": "法國血鴨"}
- description: traditional French duck dish
- countries: FR
- kinds: dish
- ingredients: duck meat
- has Wikipedia article: en, zh

## DISH Q7423529
- name: Sarburma
- description: Crimean Tatar meat pie
- countries: PL, TR
- kinds: food, dish, lamb dish
- ingredients: lamb meat, dough, butter
- has Wikipedia article: en

## DISH Q742385
- name: White chocolate
- other names: {"zh": "白巧克力"}
- description: confection based on cocoa butter extracted from cacao
- countries: (none)
- kinds: food product, types of chocolate, chocolate
- ingredients: cocoa butter
- has Wikipedia article: en, zh

## DISH Q7424615
- name: Sarson da saag
- description: vegetarian dish from the Indian subcontinent
- countries: IN, PK
- cuisines: Punjabi cuisine
- kinds: saag
- has Wikipedia article: en

## DISH Q7425852
- name: Sata
- other names: {"zh": "登嘉楼沙爹"}
- description: Malaysian dish
- countries: MY
- cuisines: Malay cuisine
- kinds: fish dish
- ingredients: Cocos nucifera
- has Wikipedia article: en

## DISH Q7425966
- name: Satay bee hoon
- description: Singaporean satay dish
- countries: SG
- kinds: dish
- has Wikipedia article: en

## DISH Q7425996
- name: Padang satay
- description: satay variant with yellow sauce
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fast food, satay, street food, jajan pasar, dish, human food
- ingredients: coriander seed, ginger, onion, peppercorn, rice flour, bird's eye chili, Alpinia galanga, peanut, table salt, sugar, meat
- has Wikipedia article: en

## DISH Q7427591
- name: Sausage bread
- description: American food using sausage
- countries: US
- kinds: bread, pastry
- ingredients: sausage
- has Wikipedia article: en

## DISH Q7427595
- name: Sausage sandwich
- description: type of sandwich
- countries: (none)
- kinds: sandwich
- ingredients: sausage, bread
- has Wikipedia article: en

## DISH Q7431773
- name: Schmaltz herring
- description: Type of herring
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q7433929
- name: Carrilleras
- countries: (none)
- kinds: dish

## DISH Q7434366
- name: Scooby Snack
- description: hamburger sold primarily in Glasgow, Scotland
- countries: GB
- kinds: hamburger
- has Wikipedia article: en

## DISH Q7435554
- name: Scotch woodcock
- description: British savoury dish
- countries: GB
- kinds: fish dish, egg dish
- ingredients: anchovy, egg as food, toast, anchovy paste
- has Wikipedia article: en

## DISH Q743714
- name: Catànies
- description: Spanish chocolate almond sweet
- countries: ES
- kinds: confectionery, technique, sweetmeat
- ingredients: Prunus dulcis
- has Wikipedia article: en

## DISH Q7438301
- name: Scouse
- other names: {"zh": "史高斯燉菜"}
- description: Lamb or beef stew
- countries: GB, NO
- kinds: stew, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q7438660
- name: Scovardă
- description: Romanian pastry
- countries: RO
- kinds: food, pastry
- ingredients: dough
- has Wikipedia article: en

## DISH Q7438806
- name: Slemang
- description: Dish in the Malaysian kitchen
- countries: MY
- kinds: dish
- ingredients: flour, sugar

## DISH Q7439103
- name: Screwball
- description: type of frozen confection that first appeared in the 1970s
- countries: (none)
- kinds: food, ice cream
- has Wikipedia article: en

## DISH Q7439403
- name: Scuffler
- description: Type of Traditional West Riding of Yorkshire Bread Roll
- countries: (none)
- kinds: food, bread roll
- has Wikipedia article: en

## DISH Q7439696
- name: Soto Ayam Ambengan
- other names: {"ms": "Soto Ayam Ambengan"}
- countries: (none)
- kinds: soto

## DISH Q7439701
- name: Soto Madura
- other names: {"id": "Soto Madura"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: soto, meal, dish, human food, type of food or dish
- ingredients: boiled egg, scallion, Alpinia galanga, Allium ascalonicum, beef, Curcuma longa, ginger, Apium graveolens, Allium sativum, table salt, potato

## DISH Q7440353
- name: Seafoam salad
- description: US dessert salad made of lime-flavored gelatin
- countries: US
- kinds: fruit salad
- has Wikipedia article: en

## DISH Q7440367
- name: Seafood birdsnest
- other names: {"zh": "海鮮雀巢"}
- description: Chinese cuisine dish
- countries: (none)
- kinds: seafood dish, fish dish
- has Wikipedia article: en, zh

## DISH Q7440625
- name: Sealed crustless sandwich
- description: mass produced sandwich foodstuff
- countries: US
- kinds: flatbread
- ingredients: bread
- has Wikipedia article: en

## DISH Q7442044
- name: Seattle-style hot dog
- description: hot dog topped with cream cheese and sauteed onions
- countries: US
- cuisines: cuisine of the Western United States, Pacific Northwest cuisine
- kinds: hot dog
- ingredients: sauteed onions, bialy, hot dog bun, cream cheese
- has Wikipedia article: en

## DISH Q7443933
- name: Kinoring bakas
- countries: (none)
- kinds: soup

## DISH Q74441736
- name: Frollino
- other names: {"it": "frollino"}
- countries: IT
- kinds: biscuit
- ingredients: pâte sablée

## DISH Q7446149
- name: Rice Jamblang
- description: Indonesian rice dish originating from Java island
- countries: ID
- cuisines: Indonesian cuisine
- kinds: rice dish, dish
- ingredients: garlic, tomato, onion, teak, shrimp paste, hot sauce, cooking oil, table salt, sugar, rice
- has Wikipedia article: en

## DISH Q74462045
- name: Panada
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, dish
- ingredients: wheat flour, fermentation starter, Aleurites moluccanus, lemon, coconut milk, fish as food, Allium ascalonicum, chili pepper, egg as food, Allium sativum, table salt, sugar, water

## DISH Q74465700
- name: Karupuak jariang
- description: a type of cracker from the Minangkabau region made from jengkol beans
- countries: ID
- cuisines: Indonesian cuisine
- kinds: krupuk, dish, human food, type of food or dish
- ingredients: Archidendron pauciflorum

## DISH Q7447375
- name: Sel roti
- description: Nepalese ring-shaped sweet rice bread
- countries: NP
- cuisines: Nepalese cuisine
- kinds: bread, food
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q7448729
- name: Tepek
- description: traditional Malay cake
- countries: MY
- kinds: cake
- ingredients: coconut, wheat flour, sugar, banana

## DISH Q7448821
- name: Selsko meso
- description: Balkan pork and mushroom stew
- countries: (none)
- kinds: stew, pork dish, mushroom dish
- ingredients: edible mushroom, pork
- has Wikipedia article: en

## DISH Q74495320
- name: Mohanthal
- description: sweet dish from India
- countries: IN
- kinds: food
- has Wikipedia article: en

## DISH Q7450022
- name: Senate bean soup
- other names: {"zh": "參議院豆湯"}
- description: soup made with navy beans, ham hocks, and onion, served in the dining room of the United States Senate
- countries: US
- kinds: bean soup, pork dish
- ingredients: navy bean, onion, ham hock, butter
- has Wikipedia article: en, zh

## DISH Q7452135
- name: Tuhau
- description: Kadazandusun cuisine in Sabah, Malaysia
- countries: MY
- kinds: condiment
- ingredients: Etlingera coccinea
- has Wikipedia article: en

## DISH Q7456013
- name: Sesame seed cake
- description: dessert cake made with sesame seeds
- countries: (none)
- kinds: food, cake
- ingredients: sesame seed
- has Wikipedia article: en

## DISH Q7456014
- name: Sesame chicken
- other names: {"zh": "芝麻鸡"}
- description: chicken dish
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q7457147
- name: Seven-layer salad
- description: American salad dish
- countries: US
- kinds: salad
- ingredients: Lactuca sativa, tomato, hard-boiled egg, onion, cucumber, iceberg lettuce, Cheddar cheese, sweet pea, bacon
- has Wikipedia article: en

## DISH Q7458108
- name: Sevpuri
- description: Indian snack food
- countries: IN
- kinds: chaat, snack
- ingredients: sev, puri
- has Wikipedia article: en

## DISH Q7458111
- name: Sevruga caviar
- other names: {"zh": "塞夫鲁加鱼子酱"}
- description: eggs from starry sturgeon (Acipenser stellatus)
- countries: (none)
- kinds: caviar
- has Wikipedia article: en

## DISH Q7459736
- name: Sfouf
- description: cake from Lebanon
- countries: LB
- kinds: cake, human food
- ingredients: semolina
- has Wikipedia article: en

## DISH Q7459894
- name: Sha cha beef
- description: Chinese dish made of shacha sauce and beef strips
- countries: (none)
- kinds: beef dish
- ingredients: shacha sauce
- has Wikipedia article: en

## DISH Q7462729
- name: Shaker Lemon Pie
- description: fruit pie typical of the Midwestern United States
- countries: US
- kinds: food, pie
- ingredients: lemon
- has Wikipedia article: en

## DISH Q747119
- name: Galotyri
- description: type of Greek cheese
- countries: GR
- kinds: cheese, type of cheese

## DISH Q747302
- name: Tamagoyaki
- other names: {"zh": "玉子燒"}
- description: Japanese rolled omelettes
- countries: JP
- kinds: egg dish
- ingredients: chicken egg
- has Wikipedia article: en, zh

## DISH Q747457
- name: Empanada
- other names: {"zh": "恩潘納達"}
- description: baked or fried turnover consisting of pastry and filling
- countries: (none)
- kinds: dish, stuffed pasta
- ingredients: flour, vegetable, meat
- has Wikipedia article: en, zh

## DISH Q747543
- name: Rioja style potatoes
- description: Spanish potato dish
- countries: (none)
- kinds: potato dish
- ingredients: potato, Choricero peppers, paprika, Laurus nobilis, onion, Allium sativum, chorizo
- has Wikipedia article: en

## DISH Q7476075
- name: Tahu sumedang
- description: Indonesian fried tofu
- countries: ID
- kinds: tahu goreng, dish
- ingredients: soy bean
- has Wikipedia article: en

## DISH Q74829570
- name: Timbal
- other names: {"sv": "timbal"}
- countries: (none)
- kinds: dish

## DISH Q7487184
- name: Shalgam
- other names: {"zh": "哈薩克蘿蔔沙拉"}
- description: Kazakhstan salad
- countries: KZ
- cuisines: Kazakh cuisine
- kinds: salad
- ingredients: garlic, Raphanus sativus, onion, Capsicum, carrot
- has Wikipedia article: en

## DISH Q7487537
- name: Shami kebab
- description: variety of kebab, originating from the Indian subcontinent; consists of a small patty of minced meat (often lamb or mutton, occasionally chicken), with ground chickpeas, egg to hold it together, and spices
- countries: (none)
- kinds: kebab
- ingredients: chickpea, ground beef
- has Wikipedia article: en

## DISH Q7489821
- name: Shark chutney
- description: Seychelles dish
- countries: SC
- kinds: fish dish, dish
- ingredients: turmeric, onion, Capsicum, lime, table salt, shark
- has Wikipedia article: en

## DISH Q7491078
- name: Shaved ice
- other names: {"zh": "刨冰"}
- description: ice-based dessert
- countries: (none)
- kinds: frozen dessert
- ingredients: crushed ice, ice
- has Wikipedia article: en, zh

## DISH Q7492817
- name: Sheftalia
- other names: {"zh": "塞浦路斯烤香腸"}
- description: Traditional Cypriot food
- countries: CY
- kinds: food, meat dish
- ingredients: minced meat, onion, parsley, table salt, bread, Capsicum annuum
- has Wikipedia article: en, zh

## DISH Q749378
- name: Brie de Meaux
- other names: {"zh": "莫城布里"}
- description: unpasteurized brie manufactured in the town of Meaux in the Brie region of northern France since the 8th century
- countries: FR
- kinds: white mold-rind cheese, raw-milk cheese, French cheese, farmstead cheese, industrial cheese, dairy cheese
- ingredients: cow's milk, raw milk
- has Wikipedia article: en

## DISH Q74957013
- name: Chestnut soup
- description: soup
- countries: (none)
- kinds: soup

## DISH Q7496557
- name: Shikashika
- description: shaved ice drink
- countries: PE
- kinds: ice cream, meal
- ingredients: ice
- has Wikipedia article: en

## DISH Q7498930
- name: Shirokuma
- countries: JP
- kinds: kakigōri, dessert
- ingredients: ice
- has Wikipedia article: en

## DISH Q7504005
- name: Shrimp DeJonghe
- description: Food dish of Chicago, Illinois, US
- countries: (none)
- kinds: shrimp dish
- has Wikipedia article: en

## DISH Q7504007
- name: Shrimp Creole
- description: Spicy rice dish with shrimp
- countries: US
- kinds: food, shrimp dish, dish
- ingredients: shrimp, celery, tomato, onion, bell pepper, spice, rice
- has Wikipedia article: en

## DISH Q7504010
- name: Shrimp ball
- countries: (none)
- kinds: shrimp dish
- has Wikipedia article: en

## DISH Q7504448
- name: Shuangbaotai
- other names: {"zh": "兩相好"}
- description: Deep-fried dough from Taiwanese and Chinese cuisine
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: doughnut
- ingredients: dough
- has Wikipedia article: en, zh

## DISH Q7505632
- name: Shuto
- description: Japanese dish
- countries: JP
- kinds: shiokara
- has Wikipedia article: en

## DISH Q75110171
- name: Ambrosia and nectar
- countries: (none)
- kinds: medication, dish, mythical object
- ingredients: nectar, ambrosia

## DISH Q7518047
- name: Simnel cake
- other names: {"zh": "重油水果蛋糕"}
- description: Light fruit cake with two layers of almond paste or marzipan, one in the middle and one on top, that is toasted and eaten during the Easter period
- countries: GB
- kinds: fruitcake
- ingredients: marzipan
- has Wikipedia article: en

## DISH Q7522199
- name: Sindhi biryani
- description: variety of biryani
- countries: PK
- kinds: biryani, rice dish, dish
- has Wikipedia article: en

## DISH Q7523638
- name: Singing hinny
- description: type of bannock, griddle cake or scone
- countries: GB
- kinds: food, bannock, scone
- ingredients: flour
- has Wikipedia article: en

## DISH Q752388
- name: Kofta
- other names: {"zh": "柯福塔"}
- description: Middle Eastern and South Asian meatballs
- countries: EG
- kinds: meat, minced food ball, meat dish, type of food or dish
- ingredients: minced meat
- has Wikipedia article: en, zh

## DISH Q7524569
- name: Sinki
- description: Nepalese dish
- countries: NP
- kinds: fermented food
- ingredients: radish
- has Wikipedia article: en

## DISH Q7525342
- name: Siomay
- description: Indonesian cuisine
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fish dish, dish, human food, type of food or dish
- ingredients: shallot, nut, palm sugar, tapioca, cooking oil, chili pepper, egg as food, Allium sativum, table salt
- has Wikipedia article: en

## DISH Q7530248
- name: Paya
- description: South Asian spicy meat soup or curry
- countries: (none)
- kinds: soup, stew, Indian curry
- has Wikipedia article: en

## DISH Q7535269
- name: Skilpadjies
- other names: {"zh": "小陸龜"}
- description: South African lamb's liver dish
- countries: ZA
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q7535893
- name: Skirlie
- description: traditional Scottish dish
- countries: GB
- cuisines: Scottish cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q7535940
- name: Skirts and kidneys
- description: Irish stew
- countries: (none)
- kinds: food, pork dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q7536227
- name: Skomakarlåda
- description: Swedish meat dish
- countries: SE
- kinds: food, beef dish
- ingredients: mashed potato
- has Wikipedia article: en

## DISH Q7540240
- name: Sliced fish soup
- description: Singaporean soup
- countries: SG
- kinds: fish soup, fish dish
- ingredients: fish
- has Wikipedia article: en

## DISH Q7541332
- name: Sloosh
- description: variety of cornbread popular during the American Civil War
- countries: US
- kinds: food, cornbread
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q7541369
- name: Slopper
- description: Colorado burger dish
- countries: (none)
- kinds: hamburger
- has Wikipedia article: en

## DISH Q7541951
- name: Slow Bread
- description: type of bread made using very little yeast
- countries: (none)
- kinds: food, bread
- has Wikipedia article: en

## DISH Q7542234
- name: Slugburger
- description: southern United States food
- countries: US
- kinds: food, hamburger
- has Wikipedia article: en

## DISH Q7545525
- name: Smithfield ham
- other names: {"zh": "斯密斯菲爾德火腿"}
- description: specific form of the country ham
- countries: US
- kinds: country ham
- has Wikipedia article: en

## DISH Q7545923
- name: Smoked salmon cheesecake
- description: Savoury cheesecake
- countries: (none)
- kinds: cheesecake, salmon dish
- ingredients: salmon
- has Wikipedia article: en

## DISH Q7546879
- name: Snack cake
- other names: {"zh": "小吃蛋糕"}
- description: type of food
- countries: (none)
- kinds: cake, snack, confectionery
- has Wikipedia article: en, zh

## DISH Q7547731
- name: Snickerdoodle
- other names: {"zh": "肉桂饼"}
- description: type of cookie
- countries: US
- kinds: cookie
- ingredients: white sugar, sodium bicarbonate, egg as food, vinegar, flour, butter, potassium hydrogen tartrate, vanilla
- has Wikipedia article: en

## DISH Q7547736
- name: Snickers pie
- description: chocolate dessert
- countries: (none)
- kinds: food, pie
- has Wikipedia article: en

## DISH Q7548366
- name: Snow White salad
- description: Bulgarian yogurt salad
- countries: BG
- kinds: salad, dish
- ingredients: garlic, cucumber, drill, yogurt
- has Wikipedia article: en

## DISH Q7548429
- name: Snow skin mooncake
- other names: {"zh": "冰皮月餅"}
- description: mooncake with a glutinous rice crust invented in Hong Kong, which is eaten during the Mid-Autumn Festival
- countries: CN, HK
- kinds: mooncake, dessert
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q755372
- name: Makowiec
- description: dough layered with ground poppy seed, sugar and dried fruit
- countries: (none)
- kinds: poppy seed roll
- ingredients: poppy seed, rum, raisin, sugar

## DISH Q7554467
- name: Stuffed onions
- description: Traditional dish with stuffed onions
- countries: TR
- kinds: dish
- ingredients: onion
- has Wikipedia article: en

## DISH Q7554655
- name: Sohan
- description: Iranian confectionery
- countries: (none)
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q7557379
- name: Soldiers
- description: thin strip of bread
- countries: GB
- cuisines: British cuisine
- kinds: toast, bread
- has Wikipedia article: en

## DISH Q7562723
- name: Soor ploom
- description: British confection
- countries: (none)
- kinds: food, confectionery
- has Wikipedia article: en

## DISH Q7562813
- name: Sopa teologa
- description: Peruvian soup
- countries: PE
- kinds: food, soup
- ingredients: white bread
- has Wikipedia article: en

## DISH Q7563795
- name: Sorullos
- description: Puerto Rican fried cornmeal dish
- countries: (none)
- kinds: food, bread
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q7564033
- name: Sottocenere al tartufo
- description: Italian cheese
- countries: IT
- kinds: Italian cheese
- has Wikipedia article: en

## DISH Q7564388
- name: Soul cake
- description: religious cake to commemorate the dead
- countries: (none)
- kinds: viennoiserie
- has Wikipedia article: en

## DISH Q7565043
- name: Soup joumou
- other names: {"zh": "珠穆湯"}
- description: Haitian soup
- countries: HT
- cuisines: Haitian cuisine
- kinds: soup, dish
- has Wikipedia article: en, zh

## DISH Q7565044
- name: Soup Number Five
- description: Filipino soup dish made from bull's testes and/or penises
- countries: PH
- kinds: food, soup
- ingredients: bull
- has Wikipedia article: en

## DISH Q7565048
- name: Soup beans
- description: Southern United States bean dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q7565056
- name: Soup with risotto
- description: Italian-American dish
- countries: (none)
- kinds: food, soup
- ingredients: risotto
- has Wikipedia article: en

## DISH Q7565082
- name: Sour cream doughnut
- description: doughnut made from sour cream batter
- countries: CA
- kinds: doughnut
- ingredients: sour cream
- has Wikipedia article: en

## DISH Q756800
- name: Sichuan pepper
- other names: {"zh": "四川花椒"}
- description: spice, crude drug
- countries: JP, CN, NP
- cuisines: Japanese cuisine, Tibetan cuisine, Nepalese cuisine, Chinese cuisine
- kinds: spice, peppercorn, food ingredient
- has Wikipedia article: en, zh

## DISH Q7570025
- name: Southern Illinois chowder
- other names: {"zh": "南伊利諾巧達湯"}
- description: American chowder
- countries: US
- kinds: food, soup
- ingredients: beef
- has Wikipedia article: en

## DISH Q7570647
- name: Southern chicken stew
- description: American regional chicken stew
- countries: US
- kinds: stew, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q7571549
- name: Souvla
- other names: {"zh": "Souvla"}
- description: Cyprus skewered barbecue meat
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q7571846
- name: Sowans
- description: Scottish dish
- countries: (none)
- kinds: porridge, oatmeal, food
- has Wikipedia article: en

## DISH Q7572829
- name: Spaghetti with meatballs
- other names: {"zh": "肉丸義大利麵"}
- description: Italian first course consisting of spaghetti, tomato sauce and meatballs
- countries: US
- cuisines: Italian-American cuisine
- kinds: spaghetti, dish
- ingredients: meatball, tomato sauce, frikadeller, spaghetti
- has Wikipedia article: en, zh

## DISH Q7573059
- name: Spanakorizo
- description: Greek food
- countries: GR
- cuisines: Greek cuisine
- kinds: vegetarian cuisine, dish
- ingredients: dill, spinach, onion, peppercorn, lemon, feta, olive oil
- has Wikipedia article: en

## DISH Q75761914
- name: Toros salad
- description: Eggplant-based salad
- countries: TR
- cuisines: Turkish cuisine
- kinds: salad
- ingredients: eggplant

## DISH Q7576924
- name: Spiced beef
- other names: {"zh": "醬牛肉"}
- description: form of salt beef
- countries: (none)
- kinds: dish, beef dish
- has Wikipedia article: en, zh

## DISH Q7576925
- name: Spiced bun
- countries: (none)
- kinds: food, sweet roll

## DISH Q7577066
- name: Spider roll
- description: sushi roll
- countries: US
- kinds: makizushi
- ingredients: soft-shell crab
- has Wikipedia article: en

## DISH Q7580785
- name: Spring soup
- description: soup made with ingredients that are only in season for a short period during spring
- countries: (none)
- kinds: food, soup
- ingredients: asparagus, Morchella
- has Wikipedia article: en

## DISH Q7581885
- name: Squab pie
- description: English meat pie
- countries: GB
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q7582255
- name: Squid cocktail
- description: Seafood dish
- countries: (none)
- kinds: food, squid dish
- ingredients: squid as food
- has Wikipedia article: en

## DISH Q75842745
- name: Pastís de pobre
- other names: {"ca": "Pastís de pobre"}
- countries: (none)
- kinds: cake

## DISH Q7587445
- name: St. Catherine's taffy
- description: french-Canadian taffy
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q7589550
- name: St. Louis-style pizza
- description: type of pizza originating from St. Louis, Missouri, US, characterized by thin cracker-like crust without yeast, use of Provel cheese, and being cut into squares/rectangles
- countries: US
- kinds: type of pizza
- ingredients: Provel cheese
- has Wikipedia article: en

## DISH Q7589551
- name: St. Louis-style barbecue
- description: dish associated with St. Louis, Missouri, U.S., consisting of spare ribs slow- smoked in a barbecue pit or barbecue grill fueled by wood, charcoal, or both
- countries: (none)
- kinds: barbecue in the United States, pork dish
- has Wikipedia article: en

## DISH Q7591284
- name: St. Paul sandwich
- description: sandwich
- countries: US
- kinds: food, egg dish
- ingredients: white bread
- has Wikipedia article: en

## DISH Q759180
- name: 会津カレー焼きそば
- other names: {"ja": "会津カレー焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q7597455
- name: Stamp and Go
- description: Jamaican fritter
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q7601283
- name: Star rock
- description: British confection
- countries: (none)
- kinds: rock
- has Wikipedia article: en

## DISH Q7605234
- name: Steak Diane
- other names: {"zh": "女神牛扒"}
- description: English dish of pan-fried beefsteak with a sauce made from the seasoned pan juices, generally prepared tableside, and flambéed
- countries: US
- kinds: beef dish
- ingredients: beefsteak
- has Wikipedia article: en, zh

## DISH Q7605240
- name: Steak pie
- description: British meat pie
- countries: GB
- kinds: food, meat pie
- ingredients: steak
- has Wikipedia article: en

## DISH Q7605242
- name: Steak sandwich
- description: type of sandwich
- countries: US
- kinds: submarine sandwich
- ingredients: steak
- has Wikipedia article: en
