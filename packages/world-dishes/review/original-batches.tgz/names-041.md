# Review batch names-041

## DISH Q3678805
- name: Civraxiu
- description: Sardinian round bread
- countries: IT
- kinds: bread

## DISH Q3678813
- name: Cjarsons
- description: Italian pasta dish
- countries: IT
- kinds: type of pasta
- has Wikipedia article: en

## DISH Q36808801
- name: Spinach noodles
- countries: (none)
- kinds: pasta
- ingredients: spinach

## DISH Q3683263
- name: Colline Salernitane PDO
- other names: {"zh": "Colline Salernitane DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3683268
- name: Colline Teatine PDO
- other names: {"zh": "Colline Teatine DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3683276
- name: Colline di Romagna PDO
- other names: {"zh": "Colline di Romagna DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3686985
- name: Coniglio alla sanremese
- description: ligurian rabbit meat dish
- countries: IT
- cuisines: cuisine of Liguria
- kinds: dish
- has Wikipedia article: en

## DISH Q3686991
- name: Coniglio veneto PAT
- other names: {"zh": "Coniglio veneto PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- cuisines: cuisine of Veneto
- kinds: dish, meat product

## DISH Q3691827
- name: Coppa Piacentina PDO
- other names: {"zh": "Coppa Piacentina DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, Capicola

## DISH Q3693169
- name: Coppetta
- description: Italian sweet
- countries: IT
- cuisines: cuisine of Valtellina
- kinds: food, dish

## DISH Q3694877
- name: Corunda
- description: Mexican type of tamale
- countries: MX
- kinds: stuffed pasta
- has Wikipedia article: en

## DISH Q3695900
- name: Pork skin
- other names: {"zh": "豬皮"}
- description: skin of a pig
- countries: (none)
- kinds: food, appetizer, skin, pork, adipose tissue
- has Wikipedia article: en, zh

## DISH Q3696330
- name: Coviglie
- countries: (none)
- kinds: dessert with spoon

## DISH Q3696937
- name: Crema bruciata
- countries: IT
- kinds: dessert

## DISH Q3696938
- name: Mille-feuille Carsolina
- description: pastry from Trieste, Italy
- countries: IT
- kinds: dessert

## DISH Q3696942
- name: Crème diplomate
- other names: {"fr": "Crème diplomate"}
- countries: IT
- kinds: custard
- ingredients: chantilly cream, pastry cream

## DISH Q3696944
- name: Hazelnut spread
- countries: (none)
- kinds: spread, confectionery, chocolate dish
- ingredients: hazelnut

## DISH Q3696945
- name: Crema reggina
- other names: {"it": "Crema reggina"}
- description: Italian dessert
- countries: IT
- kinds: dessert

## DISH Q3696961
- name: Cremino
- description: Italian layered chocolate
- countries: IT
- kinds: bonbon
- ingredients: Gianduja
- has Wikipedia article: en

## DISH Q3696962
- name: Cremino
- other names: {"it": "Cremino"}
- countries: IT
- kinds: ice cream bar

## DISH Q3697035
- name: Tigella
- description: type of Italian bread
- countries: IT
- cuisines: cuisine of the province of Modena
- kinds: dish
- has Wikipedia article: en

## DISH Q3697331
- name: Rice crispies
- description: typical Sicilian product made from rice
- countries: IT
- kinds: food, dessert, rice dish
- ingredients: rice

## DISH Q3699362
- name: Culurgiones
- description: type of stuffed pasta
- countries: IT
- kinds: type of pasta, stuffed pasta
- has Wikipedia article: en

## DISH Q3699400
- name: Cuneese al rum
- other names: {"it": "cuneese al rum"}
- countries: IT
- kinds: bonbon
- ingredients: rum, chocolate

## DISH Q3699535
- name: Cupeta
- description: Italian dessert
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q3699636
- name: Macaroon
- other names: {"zh": "果仁蛋白餅"}
- description: type of cookie
- countries: FR
- kinds: biscuit
- has Wikipedia article: en, zh

## DISH Q3699808
- name: Cuzzupa
- other names: {"es": "Cuzzupa"}
- countries: IT
- kinds: dessert

## DISH Q3704951
- name: Nanjing Salted Duck
- other names: {"zh": "盐水鸭"}
- description: Chinese duck dish
- countries: (none)
- kinds: duck dish
- ingredients: duck meat
- has Wikipedia article: en, zh

## DISH Q370637
- name: Lecsó
- other names: {"zh": "紅椒燉菜"}
- description: pepper-based vegetable dish of Hungarian origin
- countries: HU
- cuisines: Hungarian cuisine, Central European cuisine
- kinds: food, stew
- ingredients: paprika, tomato, onion
- has Wikipedia article: en

## DISH Q370799
- name: Freeze-dried ice cream
- description: ice cream that has had most of the water removed from it by a freeze-drying process
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q3708874
- name: Diples
- description: Greek dessert
- countries: GR
- cuisines: Greek cuisine
- kinds: dessert
- ingredients: dough
- has Wikipedia article: en

## DISH Q3711859
- name: Ditalini
- description: type of pasta
- countries: IT
- kinds: type of pasta, pasta
- ingredients: flour
- has Wikipedia article: en

## DISH Q3712593
- name: Dolce di San Michele
- other names: {"it": "Dolce di San Michele"}
- countries: IT
- kinds: dessert

## DISH Q3712594
- name: Dolce pan ducale
- other names: {"it": "Dolce pan ducale"}
- countries: IT
- kinds: dessert

## DISH Q3712597
- name: Dessert with spoon
- countries: (none)
- kinds: dessert

## DISH Q3712615
- name: Christmas dessert
- countries: (none)
- kinds: dessert, confectionery, Christmas food
- ingredients: Genoa cake, Christmas pudding, Christmas cake

## DISH Q3723098
- name: Elioconcentrato
- other names: {"it": "Elioconcentrato"}
- countries: IT
- kinds: tomato dish

## DISH Q3723728
- name: Torta Elvezia
- description: Italian cake
- countries: IT
- kinds: cake

## DISH Q37258522
- name: Twisted doughnut
- other names: {"zh": "麻花捲"}
- description: Types of bread
- countries: PH
- kinds: doughnut
- has Wikipedia article: en

## DISH Q3739612
- name: Farinata di zucca
- other names: {"it": "Farinata di zucca"}
- description: Italian cake
- countries: IT
- kinds: cake

## DISH Q3739616
- name: Farinella PAT
- other names: {"zh": "Farinella PAT"}
- description: traditional Italian fruit, vegetable or cereal product (PAT)
- countries: IT
- kinds: food product, agricultural product, flour

## DISH Q3740034
- name: Fatayer
- description: filled savory pie from Arab and Levantine cuisine
- countries: LB
- kinds: food, dish, pie
- has Wikipedia article: en

## DISH Q3743152
- name: Pizelle
- other names: {"zh": "義式芝麻薄餅"}
- description: Italian waffle cookie
- countries: IT
- kinds: food, biscuit
- has Wikipedia article: en, zh

## DISH Q374381
- name: Crème caramel
- other names: {"zh": "焦糖布丁"}
- description: custard dessert with soft caramel on top
- countries: (none)
- kinds: bánh, custard pudding
- ingredients: egg as food, sugar, milk
- has Wikipedia article: en, zh

## DISH Q3744332
- name: Fiambre
- description: traditional Guatemalan dish
- countries: GT
- kinds: salad
- has Wikipedia article: en

## DISH Q3746933
- name: Focaccia barese
- countries: IT
- kinds: dish, focaccia
- ingredients: tomato, potato, olive, Origanum, yeast, oil, flour, table salt, sugar, water

## DISH Q3746935
- name: Focaccia di Recco col formaggio PGI
- other names: {"zh": "Focaccia di Recco col formaggio IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good, focaccia

## DISH Q3746939
- name: Fugassa veneta PAT
- other names: {"zh": "Fugassa veneta PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good, confectionery, yeast bread, sweet bread

## DISH Q3748120
- name: Formaggio agordino di malga
- other names: {"it": "Formaggio agordino di malga"}
- countries: IT
- kinds: cheese, Italian cheese

## DISH Q3748124
- name: Formaggio di malga dei sette comuni
- description: Italian cheese
- countries: IT
- kinds: cheese, Italian cheese

## DISH Q3748126
- name: Soy cheese
- countries: (none)
- kinds: cheese analogue, soy food
- ingredients: soy milk

## DISH Q3748739
- name: Amaretto macaron
- description: Italian biscuit
- countries: IT
- kinds: biscuit
- ingredients: Pasta di mandorle PAT, egg white, sugar

## DISH Q375
- name: Waffle
- other names: {"zh": "华夫饼"}
- description: batter- or dough-based food cooked between two patterned, shaped plates
- countries: FR
- kinds: pastry, finger food, battercake, dish
- ingredients: batter
- has Wikipedia article: en, zh

## DISH Q3751036
- name: Esgarrat
- description: valencian cod dish
- countries: ES
- cuisines: Valencian cuisine
- kinds: salad, dish, fish dish
- ingredients: bacalhau, bell pepper
- has Wikipedia article: en

## DISH Q3752306
- name: Frascarelli
- description: Italian dish
- countries: IT
- kinds: dish

## DISH Q3752314
- name: Frascatula
- other names: {"it": "Frascatula"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish

## DISH Q3753348
- name: Friselle
- description: Pugliese rusk bread
- countries: IT
- kinds: bread

## DISH Q3753375
- name: Santelli-rántotta
- other names: {"hu": "Santelli-rántotta"}
- countries: HU
- kinds: dish
- ingredients: egg as food

## DISH Q3753384
- name: Frittelle di riso di san Giuseppe
- other names: {"it": "Frittelle di riso di san Giuseppe"}
- countries: IT
- kinds: dessert
- ingredients: Oryza molida

## DISH Q3753410
- name: Empedrat
- other names: {"ca": "empedrat"}
- countries: (none)
- kinds: salad

## DISH Q3753798
- name: Frustingo
- description: Italian dessert
- countries: IT
- kinds: dessert
- ingredients: Ficus carica

## DISH Q3753920
- name: Malaq salatı
- other names: {"az": "Malaq salatı"}
- countries: ES
- cuisines: Andalusian cuisine
- kinds: potato salad

## DISH Q3753984
- name: Tacu-tacu
- description: Peruvian rice and bean dish
- countries: PE
- kinds: rice dish, meal
- has Wikipedia article: en

## DISH Q3754904
- name: Fusilli bucati
- description: hollow fusilli pasta
- countries: IT
- kinds: fusilli, type of pasta

## DISH Q3758209
- name: Garda PDO
- other names: {"zh": "Garda DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: extra virgin olive oil, olive oil

## DISH Q3759296
- name: Gelo di melone PAT
- other names: {"zh": "Gelo di melone PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: pudding, food, baked good
- has Wikipedia article: en

## DISH Q37620661
- name: Markschöberlsuppe
- other names: {"de": "Markschöberlsuppe"}
- countries: (none)
- kinds: dish

## DISH Q3772617
- name: Gnocchi alla sorrentina
- description: Gnocchi dish with tomato sauce and cheese
- countries: IT
- kinds: gnocchi, first course, dish
- ingredients: potato gnocchi, tomato sauce, fior di latte

## DISH Q3772619
- name: Gnocchi ricci
- other names: {"it": "Gnocchi ricci"}
- countries: IT
- kinds: dumpling

## DISH Q3772620
- name: Gnocco fritto
- description: bread from the Emilia region of Italy, also called a crescentina
- countries: IT
- cuisines: Emilian cuisine, cuisine of the province of Modena
- kinds: bread, dumpling
- ingredients: pork skin, lard, flour, water
- has Wikipedia article: en

## DISH Q3772644
- name: Roze koek
- description: small flat cake with a layer of pink fondant icing popular in the Netherlands
- countries: (none)
- kinds: food, pastry
- ingredients: cake
- has Wikipedia article: en

## DISH Q3773300
- name: Steamed meatball
- other names: {"zh": "山竹牛肉球"}
- description: Cantonese dim sum dish
- countries: HK
- kinds: beef dish
- ingredients: beef
- has Wikipedia article: en, zh

## DISH Q3773688
- name: Hae mee
- other names: {"zh": "虾面"}
- description: prawn noodle soup of Penang
- countries: (none)
- kinds: Hokkien mee, noodle soup
- ingredients: prawn

## DISH Q3774491
- name: Alicot
- countries: FR
- kinds: food, soup
- ingredients: poultry
- has Wikipedia article: en

## DISH Q3775525
- name: Motsunabe
- other names: {"zh": "腸鍋"}
- description: Japanese hot pot dish
- countries: JP
- kinds: nabemono, offal dish
- ingredients: miso, offal
- has Wikipedia article: en, zh

## DISH Q377570
- name: Arare
- other names: {"zh": "霰餅"}
- description: Japanese cracker
- countries: JP
- kinds: Beika, rice cracker
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q3775751
- name: Granone lodigiano PAT
- other names: {"zh": "Granone lodigiano PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: Grana Cheese, cheese

## DISH Q3776096
- name: Scaloppine
- other names: {"zh": "小牛肉片"}
- description: Italian meat dish
- countries: IT
- kinds: chicken dish, beef dish, veal dish
- has Wikipedia article: en

## DISH Q3776580
- name: Monofloral honey
- description: type of honey
- countries: (none)
- kinds: honey
- has Wikipedia article: en

## DISH Q3776725
- name: Blaa
- description: doughy, white bread bun particular to Waterford City and County, Ireland
- countries: IE
- kinds: bun
- ingredients: flour
- has Wikipedia article: en

## DISH Q3776982
- name: Prawn cocktail
- other names: {"zh": "大蝦冷盤"}
- description: dish of prawns
- countries: (none)
- kinds: salad, shrimp dish
- ingredients: shrimp and prawn as food, cocktail sauce
- has Wikipedia article: en

## DISH Q3778015
- name: Blöta
- other names: {"zh": "麵包片"}
- description: dish of crisp flatbread soaked in a hot meat broth or milk, originating in northern Sweden
- countries: (none)
- kinds: food, bread, rieska, nalisniki
- ingredients: bread, liquid
- has Wikipedia article: en

## DISH Q3778467
- name: Gubana
- description: Frioulian dessert
- countries: IT
- kinds: pastry
- ingredients: flour

## DISH Q3782694
- name: Ham and cheese sandwich
- other names: {"zh": "火腿芝士三明治"}
- description: common type of sandwich
- countries: (none)
- kinds: ham sandwich, cheese sandwich
- ingredients: ham, pan loaf, cheese

## DISH Q378283
- name: Acıka
- other names: {"zh": "阿吉卡"}
- description: Georgian condiment
- countries: GE
- cuisines: Georgian cuisine, Abkhazian cuisine
- kinds: condiment, sauce, dip, human food
- ingredients: paprika, Khmeli suneli, Capsicum, vinegar, tomato, Allium sativum, table salt, onion, chili pepper, Coriandrum sativum
- has Wikipedia article: en, zh

## DISH Q37833204
- name: Deopbap
- description: Korean dish of cooked rice and topping
- countries: (none)
- kinds: dish

## DISH Q378341
- name: Macaroni and cheese
- other names: {"zh": "起司通心麵"}
- description: pasta dish
- countries: GB
- cuisines: cuisine of the United States, English cuisine, Canadian cuisine
- kinds: pasta dish
- ingredients: cheddar sauce, wheat flour, Cheddar cheese, butter, macaroni
- has Wikipedia article: en, zh

## DISH Q3784816
- name: Tartiflette au fromage de Herve
- other names: {"fr": "tartiflette au fromage de Herve"}
- countries: (none)
- kinds: dish, potato dish, Tartiflette variant

## DISH Q3785698
- name: Himbasha
- other names: {"zh": "辛巴夏"}
- description: indigenous bread of Ethiopia and Eritrea
- countries: ER, ET
- kinds: food, flatbread
- ingredients: cardamom
- has Wikipedia article: en

## DISH Q3799069
- name: Seafood salad
- countries: (none)
- kinds: seafood dish, single course

## DISH Q3802110
- name: Irpinia - Colline dell'Ufita PDO
- other names: {"zh": "Irpinia - Colline dell'Ufita DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3807565
- name: Meatloaf
- other names: {"zh": "肉卷"}
- description: dish of ground meat formed into a loaf shape
- countries: CZ, DE
- kinds: roast, rolled roast
- ingredients: minced meat, meat
- has Wikipedia article: en, zh

## DISH Q3814037
- name: Buko pie
- description: Filipino coconut custard pie
- countries: PH
- kinds: custard pie
- ingredients: pie crust, coconut
- has Wikipedia article: en

## DISH Q3815036
- name: Kiachln
- other names: {"it": "Kiachln"}
- countries: IT
- kinds: dessert

## DISH Q3815416
- name: King Kong milk candy
- description: Peruvian cuisine dessert
- countries: PE
- kinds: confectionery, meal
- has Wikipedia article: en

## DISH Q3815714
- name: Kitcha
- other names: {"zh": "基查 (食物)"}
- description: unleavened bread in Ethiopian and Eritrean culinary tradition
- countries: ET
- kinds: bread, pancake
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q3816919
- name: Mucenici
- description: Christian feast day in Romania and Moldova
- countries: RO
- kinds: Christian holy day, human food
- has Wikipedia article: en

## DISH Q38180229
- name: Torta nera di San Secondo
- countries: IT
- kinds: dessert

## DISH Q3820622
- name: Paris ham
- other names: {"zh": "巴黎火腿"}
- description: cooked ham from France
- countries: FR
- kinds: cooked ham

## DISH Q3822761
- name: Pansotti
- description: Italian stuffed pasta
- countries: IT
- kinds: stuffed pasta, type of pasta

## DISH Q3823327
- name: Country ham
- description: American cured and smoked ham
- countries: US
- kinds: ham
- has Wikipedia article: en

## DISH Q3823549
- name: Suspiro de limeña
- description: dessert of Peruvian gastronomy
- countries: PE
- kinds: dessert
- ingredients: Manjar blanco
- has Wikipedia article: en

## DISH Q3823969
- name: Caldoso
- description: Spanish rice dish
- countries: (none)
- kinds: dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q38247716
- name: Lotus root patties
- countries: (none)
- kinds: dish
- ingredients: Lotus rhizome

## DISH Q38247865
- name: Fried rice with salted fish and chicken
- other names: {"zh": "鹹魚雞粒炒飯"}
- countries: HK
- kinds: fried rice, food
- has Wikipedia article: zh

## DISH Q3825241
- name: Laciada
- other names: {"it": "laciada"}
- countries: IT
- cuisines: cuisine of the province of Como
- kinds: dessert

## DISH Q3825584
- name: Laghi Lombardi PDO
- other names: {"zh": "Laghi Lombardi DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: extra virgin olive oil, olive oil

## DISH Q3826092
- name: Rossejat
- countries: ES
- kinds: dish, rice dish
- ingredients: rice

## DISH Q3826183
- name: Laina
- countries: IT
- kinds: type of pasta

## DISH Q3826403
- name: Turrolate
- other names: {"ast": "Turrolate"}
- countries: ES
- kinds: dessert

## DISH Q3826447
- name: Lametia PDO
- other names: {"zh": "Lametia DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q382655
- name: Tantouni
- description: Turkey Dish
- countries: TR
- kinds: meat dish, dürüm
- ingredients: tomato, sumac, onion, paprika, cottonseed oil, lamb meat, beef, parsley
- has Wikipedia article: en

## DISH Q38266921
- name: Kajika no aburi
- countries: (none)
- kinds: smoked fish

## DISH Q3827309
- name: Lasagne sheet
- description: flat rectangle-shaped pasta
- countries: IT
- kinds: pasta, type of pasta

## DISH Q38276179
- name: 牧場しぼり
- other names: {"ja": "牧場しぼり"}
- countries: (none)
- kinds: ice cream, product

## DISH Q38277888
- name: はしもとオムレツ
- other names: {"ja": "はしもとオムレツ"}
- countries: (none)
- kinds: omelette

## DISH Q3827928
- name: Gogoşi
- description: Romanian deep-fried pastry
- countries: RO
- kinds: food, cookie
- ingredients: dough
- has Wikipedia article: en

## DISH Q383284
- name: Afikoman
- description: portion of matza set aside during the Passover meal
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q38412534
- name: Fryske krûdkoeke
- other names: {"fy": "Fryske krûdkoeke"}
- countries: (none)
- kinds: pryanik

## DISH Q3841974
- name: Maccaronara
- other names: {"it": "maccaronara"}
- countries: IT
- kinds: type of pasta

## DISH Q3841977
- name: Maccheroncini di Campofilone PGI
- other names: {"zh": "Maccheroncini di Campofilone IGP"}
- description: Italian PGI pasta
- countries: IT
- cuisines: cuisine of Marche
- kinds: pasta, egg pasta, type of pasta
- ingredients: durum flour, egg as food

## DISH Q3841979
- name: Maccheroni con la trippa
- other names: {"it": "Maccheroni con la trippa"}
- countries: IT
- kinds: soup
- ingredients: Italian sausage, tripe, macaroni

## DISH Q3841980
- name: Maccheroni con le noci
- countries: IT
- kinds: confectionery, pasta dish

## DISH Q3842043
- name: Maccu
- description: sicilian soup
- countries: IT
- cuisines: Sicilian cuisine
- kinds: soup
- has Wikipedia article: en

## DISH Q3844010
- name: Maltagliati
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q3844419
- name: Mandorla riccia di Francavilla Fontana
- other names: {"it": "Mandorla riccia di Francavilla Fontana"}
- countries: IT
- kinds: dessert

## DISH Q3844897
- name: Manteca
- description: type of Italian cheese
- countries: IT
- kinds: Italian cheese, dairy product

## DISH Q3844992
- name: New York-style pizza
- other names: {"zh": "纽约披萨"}
- description: large hand-tossed thin crust pizza
- countries: US
- kinds: type of pizza
- has Wikipedia article: en, zh

## DISH Q3847001
- name: Margheritine di Stresa
- other names: {"it": "Margheritine di Stresa"}
- countries: IT
- kinds: dessert

## DISH Q3847402
- name: Hanabiramochi
- description: Japanese sweet
- countries: JP
- kinds: mochi, wagashi, New Year's food
- ingredients: mochi, miso, Arctium lappa
- has Wikipedia article: en

## DISH Q3847429
- name: Higashi
- other names: {"zh": "乾糕點"}
- description: traditional Japanese confectionery with very little moisture
- countries: JP
- kinds: wagashi
- has Wikipedia article: en, zh

## DISH Q3847532
- name: Cuchifritos
- description: various fried foods prepared principally of pork
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q3848094
- name: Bap
- other names: {"zh": "韓式飯"}
- description: cooked rice and/or other cereal dish in Korean cuisine
- countries: KR
- cuisines: Korean cuisine
- kinds: cooked grain
- ingredients: Oryza sativa japonica
- has Wikipedia article: en

## DISH Q3848112
- name: Carcamusa
- description: traditional Spanish dish
- countries: ES
- kinds: dish, stew
- ingredients: pork, vegetable
- has Wikipedia article: en

## DISH Q3848253
- name: Stroganina
- other names: {"zh": "刮魚"}
- description: Siberian dish
- countries: RU
- kinds: meat dish, raw fish dish, dish
- has Wikipedia article: en, zh

## DISH Q3849360
- name: Maritozzo
- other names: {"zh": "马里托佐"}
- description: Italian dessert
- countries: IT
- kinds: viennoiserie, sweet bread, confectionery
- has Wikipedia article: en

## DISH Q3851549
- name: Mastazzoli
- other names: {"it": "mastazzoli"}
- countries: IT
- kinds: dessert
- ingredients: Opuntia ficus-indica

## DISH Q3852961
- name: Mauru
- other names: {"it": "Mauru"}
- countries: IT
- kinds: dish

## DISH Q3853270
- name: Mazzerelle
- description: Italian skewered lamb dish
- countries: IT
- kinds: dish
- has Wikipedia article: en

## DISH Q3853320
- name: Mbriulata
- other names: {"it": "Mbriulata"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: food
- ingredients: potato, onion, olive, pecorino, pork, bread

## DISH Q3853746
- name: Eggah
- other names: {"zh": "阿拉伯煎蛋"}
- description: Arab egg dish of eggs cooked in a pancake, bound to fillings (vegetable or meat) with spices, similar to a frittata
- countries: (none)
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q3855995
- name: Miacetto
- other names: {"it": "Miacetto"}
- countries: IT
- kinds: dessert

## DISH Q3857102
- name: Miele della Lunigiana PDO
- other names: {"zh": "Miele della Lunigiana DOP"}
- description: Italian PDO animal product
- countries: IT
- kinds: honey, animal product

## DISH Q385808
- name: Hornazo
- other names: {"zh": "小肉饼"}
- description: Spanish baked meat
- countries: ES
- kinds: Easter bread, confectionery, pie
- ingredients: hard-boiled egg, Serrano ham, pork, flour, chorizo
- has Wikipedia article: en

## DISH Q3858380
- name: Wedding soup
- other names: {"zh": "義大利式婚禮湯"}
- description: Italian soup consisting of green vegetables and meat
- countries: IT, US
- cuisines: Italian cuisine
- kinds: food, soup
- has Wikipedia article: en, zh

## DISH Q3858564
- name: Minna di Virgini PAT
- other names: {"zh": "Minna di Virgini PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: dessert, baked good

## DISH Q3859384
- name: Misoltin
- countries: IT
- cuisines: cuisine of the province of Como
- kinds: main course, dried fish
- ingredients: Alosa agone

## DISH Q38595513
- name: Cabeza
- description: Mexican dish of beef head
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q38595678
- name: Cabeza guateada
- description: Northeastern Argentina dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q3860244
- name: Molise PDO
- other names: {"zh": "Molise DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3860889
- name: Monk's
- description: Balsamic sweet brand
- countries: IT
- kinds: candy, product

## DISH Q3862441
- name: Monti Iblei PDO
- other names: {"zh": "Monti Iblei DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3866878
- name: Muccunetti
- other names: {"it": "Muccunetti"}
- countries: IT
- kinds: dessert

## DISH Q3866940
- name: Muhammara
- description: Red pepper dip from Syrian cuisine
- countries: SY
- kinds: food, spread, human food
- ingredients: bell pepper, Aleppo pepper, walnut, pomegranate
- has Wikipedia article: en

## DISH Q3867478
- name: Muscisca
- description: Abruzzo and Puglia agri-food product
- countries: IT
- kinds: meat

## DISH Q3868691
- name: Mustacciuoli
- description: traditional pastry from Campania, Italy
- countries: IT
- kinds: confectionery, food
- ingredients: flour
- has Wikipedia article: en

## DISH Q3868710
- name: Mustazzoli
- other names: {"it": "mustazzoli"}
- countries: IT
- kinds: dessert

## DISH Q3869300
- name: 'Nzuddi
- description: Italian cookies
- countries: IT
- kinds: biscuit, dessert
- has Wikipedia article: en

## DISH Q3869796
- name: Nacatole
- other names: {"it": "Nacatole"}
- countries: IT
- kinds: dessert

## DISH Q3869817
- name: Надалін
- other names: {"uk": "Надалін"}
- countries: IT
- kinds: dessert

## DISH Q387235
- name: Asazuke
- other names: {"zh": "淺漬"}
- description: Japanese tsukemono, or pickled food
- countries: JP
- kinds: food, tsukemono
- ingredients: vegetable, vinegar, table salt
- has Wikipedia article: en, zh

## DISH Q3874120
- name: Neccio
- description: Chestnut Flour Cake
- countries: IT
- kinds: dessert
- ingredients: chestnut flour
- has Wikipedia article: en

## DISH Q387673
- name: Pignolata di Messina PAT
- other names: {"zh": "Pignolata di Messina PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good, pastry
- has Wikipedia article: en

## DISH Q3877638
- name: Bottom sirloin
- description: animal meat used in restaurants in steaks and hamburgers
- countries: (none)
- kinds: cut of beef, beefsteak
- has Wikipedia article: en

## DISH Q3878649
- name: Nostrano Valtrompia PDO
- other names: {"zh": "Nostrano Valtrompia DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, Italian cheese

## DISH Q3879239
- name: Nucàtuli PAT
- other names: {"zh": "Nucàtuli PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, dessert, baked good

## DISH Q3881002
- name: Offella di Parona
- other names: {"it": "Offella di Parona"}
- countries: IT
- kinds: dessert

## DISH Q3881759
- name: Collina di Brindisi PDO
- other names: {"zh": "Collina di Brindisi DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3881817
- name: Olivette de Sant'Agata
- other names: {"fr": "Olivette de Sant'Agata"}
- countries: IT
- kinds: dessert
- ingredients: marzipan

## DISH Q3885871
- name: Orilletas
- other names: {"it": "Orilletas"}
- countries: IT
- kinds: dessert

## DISH Q3886850
- name: Ossolano PDO
- other names: {"zh": "Ossolano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, Italian cheese

## DISH Q3886934
- name: Silesian dumplings
- description: type of Polish potato dumplings
- countries: (none)
- kinds: potato-dough dumpling
- ingredients: wheat flour, mashed potato
- has Wikipedia article: en

## DISH Q3888994
- name: Naporitan
- other names: {"zh": "拿坡里麵"}
- description: Japanese pasta dish, consisting of spaghetti, tomato ketchup, sausage, mushrooms, onions, and green peppers
- countries: JP
- cuisines: yōshoku
- kinds: type of food or dish, pasta dish
- ingredients: ketchup, spaghetti, green pepper, onion, Tabasco sauce, Agaricus bisporus, sausage, bacon
- has Wikipedia article: en, zh

## DISH Q388983
- name: Takikomi gohan
- other names: {"zh": "蒸飯"}
- description: Japanese rice dish
- countries: CN, JP
- kinds: rice dish
- ingredients: Oryza molida
- has Wikipedia article: en, zh

## DISH Q3892904
- name: Pampanella
- description: Italian pork dish
- countries: IT
- kinds: street food, pork dish

## DISH Q3892932
- name: Pan dell'orso
- other names: {"it": "Pan dell'orso"}
- description: Italian dessert
- countries: IT
- kinds: dessert

## DISH Q3892935
- name: Pan di ramerino
- description: sweet Tuscan rosemary bread
- countries: IT
- kinds: sweet bread
- ingredients: rosemary

## DISH Q3892955
- name: Panada
- description: stale bread boiled to a porridge in water or stock
- countries: IT
- kinds: soup
- ingredients: Grana Cheese, broth, olive oil, table salt, bread
- has Wikipedia article: en

## DISH Q3893083
- name: Pancetta Piacentina PDO
- other names: {"zh": "Pancetta Piacentina DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, pancetta

## DISH Q3893086
- name: Pancetta di Calabria PDO
- other names: {"zh": "Pancetta di Calabria DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, pancetta

## DISH Q3893172
- name: Pane casareccio di Genzano PGI
- other names: {"zh": "Pane casareccio di Genzano IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good, bread

## DISH Q3893173
- name: Pane cotto
- other names: {"it": "Pane cotto"}
- countries: IT
- kinds: bread

## DISH Q3893182
- name: Pane di Matera PGI
- other names: {"zh": "Pane di Matera IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good, sourdough bread

## DISH Q3893185
- name: Pane di Altamura PDO
- other names: {"zh": "Pane di Altamura DOP"}
- description: Italian PDO bakery product
- countries: IT
- kinds: baked good, food, bread
- ingredients: durum wheat semolina
- has Wikipedia article: en

## DISH Q3893188
- name: Pane di cena
- other names: {"it": "Pane di cena"}
- countries: (none)
- kinds: bread

## DISH Q3893200
- name: Pane frattau
- description: Sardinian dish
- countries: IT
- kinds: dish
- ingredients: tomato sauce, Pane carasau, cheese
- has Wikipedia article: en

## DISH Q3893202
- name: Pane nero di Castelvetrano
- countries: IT
- kinds: rye bread

## DISH Q3893215
- name: Panera (dessert)
- description: semifreddo (semi-frozen dessert) specialty of Genoa
- countries: IT
- kinds: Semifreddo

## DISH Q3893227
- name: Panficato
- other names: {"it": "Panficato"}
- countries: IT
- kinds: dessert

## DISH Q3893250
- name: Pangiallo
- description: traditional sweet bread of Italy
- countries: IT
- cuisines: Italian cuisine
- kinds: dish

## DISH Q3893291
- name: Panigaccio
- description: Italian flatbread
- countries: IT
- kinds: flatbread
- has Wikipedia article: en

## DISH Q3893310
- name: Paniscedda
- other names: {"it": "Paniscedda"}
- countries: IT
- kinds: dessert

## DISH Q3893318
- name: Panissa
- description: Italian dish of risotto and beans
- countries: IT
- kinds: risotto
- ingredients: cranberry bean, rice

## DISH Q3893374
- name: Panone
- description: Italian Christmas Cake
- countries: IT
- kinds: Christmas dessert
- has Wikipedia article: en

## DISH Q3893492
- name: Panuozzo
- description: Italian sandwich of pizza bread stuffed with fillings of meat and vegetables
- countries: IT
- kinds: food, Italian cuisine, campanian cuisine, street food
- has Wikipedia article: en

## DISH Q3894691
- name: Papassino
- description: typical sweet from Sardinia produced for the religious recurrence of All Saints
- countries: IT
- kinds: dessert

## DISH Q3894895
- name: Pappa
- other names: {"zh": "番茄麵包粥"}
- description: Italian soup dish
- countries: IT
- kinds: food, soup
- ingredients: tomato
- has Wikipedia article: en

## DISH Q3895102
- name: Paradello
- description: cake of Lake Como
- countries: (none)
- cuisines: cuisine of the province of Como
- kinds: dessert, frittelle

## DISH Q389574
- name: Backhendl
- description: Austrian fried chicken dish
- countries: (none)
- kinds: dish, fried chicken
- has Wikipedia article: en

## DISH Q3895789
- name: Pardulas
- description: small Italian ricotta-based pies
- countries: IT
- kinds: tart, sweet pie
- ingredients: fresh cheese, ricotta, lemon zest, egg as food, sugar

## DISH Q3895837
- name: Jalea
- description: Peruvian seafood dish
- countries: PE
- kinds: meal, frying, ceviche
- ingredients: aji amarillo, salsa criolla, fish as food, seafood, cassava
- has Wikipedia article: en

## DISH Q3896505
- name: Parrozzo
- description: traditional cake from the Abruzzo region of Italy
- countries: IT
- kinds: dish, confectionery
- has Wikipedia article: en

## DISH Q3896960
- name: Pasimata
- other names: {"fr": "pasimata"}
- countries: IT
- kinds: dessert

## DISH Q389727
- name: Huaxmole
- other names: {"ca": "Huaxmole"}
- countries: (none)
- kinds: dish

## DISH Q3897472
- name: Pasta 'ncasciata
- description: Sicilian food
- countries: (none)
- kinds: timballo, pasta al forno
- has Wikipedia article: en

## DISH Q3897489
- name: Pasta mollicata
- description: Italian pasta dish
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish, pasta
- has Wikipedia article: en

## DISH Q3897490
- name: Pasta trita
- other names: {"it": "pasta trita"}
- countries: IT
- kinds: dish
- ingredients: broth, pasta

## DISH Q3897491
- name: Stuffed pasta
- description: food that consists of a thin layer of dough wrapped around a filling
- countries: GR, IT
- kinds: pasta, dish, stuffed food
- ingredients: rolled dough, stuffing
- has Wikipedia article: en

## DISH Q3897492
- name: Paste di meliga
- description: Italian cookie
- countries: IT
- kinds: cookie
- ingredients: cornmeal

## DISH Q3897499
- name: Bakelse
- description: sweet pastry
- countries: (none)
- kinds: sweet pastry

## DISH Q3897500
- name: Pasticciotto
- other names: {"zh": "義式乳酪塔"}
- description: type of filled Italian pastry
- countries: IT
- kinds: pastry, confectionery, sweet pie
- has Wikipedia article: en, zh

## DISH Q3897506
- name: Pastin
- description: Italian typical cured meat product made of pork and beef mince
- countries: IT
- kinds: salume
- ingredients: pork mince, ground beef

## DISH Q3897559
- name: Patacia
- other names: {"it": "Patacia"}
- countries: IT
- kinds: dessert

## DISH Q3898528
- name: Pecora alla callara
- description: main course typical of Abruzzo
- countries: IT
- cuisines: Abruzzese cuisine
- kinds: meat dish, stew
- ingredients: mutton
- has Wikipedia article: en

## DISH Q3898541
- name: Pecorino Crotonese PDO
- other names: {"zh": "Pecorino Crotonese DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, pecorino

## DISH Q3898544
- name: Pecorino di Carmasciano PAT
- other names: {"zh": "Pecorino di Carmasciano PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese, pecorino, sheep milk cheese, raw-milk cheese, Italian cheese, hard cheese
- ingredients: lamb rennet, calf rennet, sheep milk
- has Wikipedia article: en

## DISH Q3898549
- name: Pecorino di Filiano PDO
- other names: {"zh": "Pecorino di Filiano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, pecorino
- ingredients: sheep milk
- has Wikipedia article: en

## DISH Q3899061
- name: Penisola Sorrentina PDO
- other names: {"zh": "Penisola Sorrentina DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3899347
- name: Pepatelli
- other names: {"it": "pepatelli"}
- countries: IT
- kinds: dish, biscuit

## DISH Q3900707
- name: Pesca
- other names: {"it": "pesca"}
- countries: IT
- kinds: dessert

## DISH Q3900767
- name: Pesto modenese
- other names: {"it": "pesto modenese"}
- countries: IT
- cuisines: cuisine of the province of Modena
- kinds: condiment

## DISH Q3900768
- name: Pestèda
- description: Italian seasoning blend
- countries: IT
- cuisines: cuisine of Valtellina
- kinds: spice mix
- ingredients: garlic, peppercorn, Achillea nana, Thymus serpyllum, table salt

## DISH Q3901032
- name: Petrafennula PAT
- other names: {"zh": "Petrafennula PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, dessert, baked good

## DISH Q3901812
- name: Piacentinu Ennese PDO
- other names: {"zh": "Piacentinu Ennese DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, sheep milk cheese, raw-milk cheese, pressed uncooked cheese, Italian cheese
- ingredients: sheep milk, raw milk

## DISH Q3902716
- name: Pidono
- other names: {"eo": "Pidono"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: rustico

## DISH Q39034868
- name: Yellow Soup
- description: Banquet of the city council and city councillors in Leipzig from around 1853, first course of the meal
- countries: (none)
- kinds: tradition, dish, festive meal

## DISH Q39045630
- name: Stemmelkort
- description: German carrot patty
- countries: DE
- kinds: patty, food
- ingredients: stock, egg as food, nutmeg, black pepper, flour, table salt, carrot
- has Wikipedia article: en

## DISH Q39046153
- name: Rat-on-a-stick
- other names: {"zh": "鼠肉串"}
- description: Dish of roasted rat on a skewer
- countries: (none)
- kinds: rat dish
- has Wikipedia article: en, zh

## DISH Q3904920
- name: Pignoccata PAT
- other names: {"zh": "Pignoccata PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good, dessert

## DISH Q3904921
- name: Pignolata al miele
- other names: {"es": "Pignolata al miele"}
- countries: IT
- kinds: dessert

## DISH Q3905339
- name: Pinza
- description: Italian dessert
- countries: IT
- kinds: confectionery
- has Wikipedia article: en

## DISH Q39053773
- name: NY Dosas
- description: Food cart in New York City
- countries: (none)
- kinds: street food
- has Wikipedia article: en

## DISH Q39055774
- name: Cherry ice cream
- other names: {"zh": "櫻桃冰淇淋"}
- description: ice cream with natural or artificial cherry flavoring
- countries: (none)
- kinds: ice cream, cherry based food
- ingredients: ice cream, cherry
- has Wikipedia article: en

## DISH Q3905622
- name: Pitilla
- description: Italian flatbread
- countries: IT
- kinds: flatbread

## DISH Q39056765
- name: Cola chicken
- other names: {"zh": "可乐鸡"}
- description: dish
- countries: (none)
- kinds: type of food or dish, chicken dish
- ingredients: chicken as food, cola
- has Wikipedia article: en, zh

## DISH Q39057643
- name: Roust
- description: Bengali dish
- countries: BD
- kinds: dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q3905790
- name: Pistiddu
- description: sweet pastry from Nuoro, Italy
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q3905837
- name: Pitina
- description: Italian goat meat salume
- countries: IT
- kinds: minced food ball, salume
- ingredients: chamois meat, goat meat
- has Wikipedia article: en

## DISH Q3905848
- name: Pitta 'mpigliata
- other names: {"es": "Pitta 'mpigliata"}
- countries: IT
- kinds: dessert

## DISH Q3905851
- name: Pitta di San Martino
- other names: {"it": "Pitta di San Martino"}
- countries: IT
- kinds: dessert

## DISH Q3905854
- name: Pitteddhre
- other names: {"it": "Pitteddhre"}
- countries: IT
- kinds: dessert

## DISH Q3905960
- name: Pizza al metro
- countries: IT

## DISH Q3905962
- name: Deep-fried pizza
- description: dish originating from central and southern Italy
- countries: IT
- kinds: fried food

## DISH Q3905963
- name: Pizza di Pasqua
- description: easter cake
- countries: IT
- kinds: cake, Easter bread
- has Wikipedia article: en

## DISH Q3905969
- name: Carne pizzaiola
- other names: {"zh": "披薩肉"}
- description: Italian meat dish
- countries: IT
- kinds: meal, dish
- ingredients: basil, garlic, tomato, tomato paste, olive oil, meat, white wine
- has Wikipedia article: en, zh

## DISH Q3906050
- name: Pizzolo
- description: type of pizza from Sicily
- countries: IT

## DISH Q39069945
- name: Zabala
- description: brand of confectionery
- countries: UY
- kinds: candy
- ingredients: caramel
- has Wikipedia article: en

## DISH Q3907227
- name: Polenta dolce
- other names: {"it": "polenta dolce"}
- countries: IT
- kinds: first course
- ingredients: chestnut flour, table salt, water

## DISH Q3907228
- name: Polenta e osei
- description: dish
- countries: IT
- kinds: main course

## DISH Q3907609
- name: Pollo a la Brasa
- description: common Peruvian rotisserie chicken dish, originating in Lima in the 1950s
- countries: PE
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q3907811
- name: Banana ketchup
- other names: {"zh": "香蕉番茄醬"}
- description: sauce made from bananas
- countries: PH
- cuisines: Filipino cuisine
- kinds: condiment, fruit ketchup, banana dish
- ingredients: banana
- has Wikipedia article: en, zh

## DISH Q39082052
- name: Tortilla
- other names: {"zh": "玉米饼"}
- description: Panamanian traditional food
- countries: (none)
- kinds: tortilla, dish

## DISH Q39086082
- name: Street food in South Korea
- description: traditional Korean cuisine
- countries: (none)
- kinds: street food
- has Wikipedia article: en

## DISH Q39087079
- name: Salted squid
- description: Type of preserved seafood
- countries: (none)
- kinds: squid dish
- has Wikipedia article: en

## DISH Q39087817
- name: Beer ice cream
- description: Ice cream made with beer
- countries: (none)
- kinds: ice cream
- ingredients: beer
- has Wikipedia article: en

## DISH Q391082
- name: Curry noodle
- other names: {"zh": "咖哩面"}
- description: Malaysian noodle dish
- countries: MY
- kinds: noodle dish
- ingredients: tofu puff, bean sprout, curry powder, coconut milk, noodle
- has Wikipedia article: en, zh

## DISH Q391086
- name: Frittelle
- description: Italian deep-fried sweet
- countries: IT
- kinds: sweet dish, deep-fried food
- ingredients: cow's milk, wheat flour, shortening, egg as food, baking powder, sugar

## DISH Q391179
- name: Pain de Sainte-Agathe
- countries: (none)
- kinds: pastry
- ingredients: wheat flour, baker's yeast, table salt, water

## DISH Q3914983
- name: Sharkfin and prawn dumpling in superior soup
- other names: {"zh": "鱼翅饺"}
- description: superior of Soup
- countries: CN
- kinds: dim sum
- has Wikipedia article: en, zh

## DISH Q3917542
- name: Builbrood
- other names: {"nl": "builbrood"}
- countries: (none)
- kinds: bread

## DISH Q3920699
- name: Półgęsek
- other names: {"pl": "Półgęsek"}
- countries: (none)
- kinds: dish
- ingredients: goose meat

## DISH Q3920714
- name: Wereszczaka
- countries: (none)
- kinds: dish
- ingredients: onion sauce, salo, sausage, beer

## DISH Q3920731
- name: Polewka
- other names: {"pl": "Polewka"}
- countries: (none)
- kinds: dish
- ingredients: kvass, table salt, beer

## DISH Q3920738
- name: Gramatka
- other names: {"pl": "Gramatka"}
- description: dish
- countries: BY
- cuisines: Belarusian cuisine
- kinds: dish
- ingredients: smetana, quark, egg yolk, beer

## DISH Q392172
- name: Tortas de Aceite
- description: trademark
- countries: ES
- kinds: type of food or dish, biscuit
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q3924065
- name: Prosciutto Toscano PDO
- other names: {"zh": "Prosciutto Toscano DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, prosciutto

## DISH Q3924066
- name: Prosciutto Veneto Berico-Euganeo PDO
- other names: {"zh": "Prosciutto Veneto Berico-Euganeo DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, prosciutto

## DISH Q3924067
- name: Prosciutto di Carpegna PDO
- other names: {"zh": "Prosciutto di Carpegna DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, prosciutto

## DISH Q3924068
- name: Prosciutto di Sauris
- countries: IT
- kinds: prosciutto

## DISH Q3924070
- name: Prosciutto di Modena PDO
- other names: {"zh": "Prosciutto di Modena DOP"}
- description: Italian PDO meat product
- countries: IT
- cuisines: cuisine of the province of Modena
- kinds: meat product, prosciutto

## DISH Q3924731
- name: Provolone del Monaco PDO
- other names: {"zh": "Provolone del Monaco DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, Provolone

## DISH Q3925900
- name: Purceddhruzzi
- other names: {"es": "Purceddhruzzi"}
- countries: IT
- kinds: dessert

## DISH Q3926046
- name: Puzzone di Moena
- description: type of Italian cheese
- countries: IT
- kinds: cheese, type of cheese, Italian cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q39262547
- name: Fruit tart
- description: tart with fruits
- countries: (none)
- kinds: pastry, finger food, tart

## DISH Q3927078
- name: Quaresimali
- description: Italian Lent cookies
- countries: IT
- kinds: dessert

## DISH Q3929288
- name: Raffiuoli
- other names: {"ga": "raffiuoli"}
- countries: IT
- kinds: dessert

## DISH Q392935
- name: Akara
- other names: {"de": "Akara"}
- description: peeled beans formed into a ball and deep-fried in palm oil
- countries: BR, GH, NG
- kinds: type of food or dish, food, dish, street food, human food
- ingredients: onion, black-eyed pea, palm oil, Capsicum, table salt
- has Wikipedia article: en

## DISH Q39297005
- name: Migliatello
- other names: {"it": "Migliatello"}
- countries: (none)
- kinds: dish

## DISH Q3929866
- name: Rame di Napoli
- description: typical sweet from Catania, Italy
- countries: IT
- kinds: dessert

## DISH Q3930586
- name: Ravioli dolci
- countries: IT
- kinds: dessert

## DISH Q3934685
- name: Ricciolino
- other names: {"it": "Ricciolino"}
- countries: IT
- kinds: dessert

## DISH Q3934686
- name: Ricciolina
- other names: {"it": "ricciolina"}
- countries: IT
- kinds: dessert

## DISH Q393573
- name: Basler Brot
- description: bread traditionally made in the Swiss cantons of Basel-Stadt and Basel-Landschaft
- countries: CH
- kinds: bread
- ingredients: pre-ferment
- has Wikipedia article: en

## DISH Q3937014
- name: Risino
- other names: {"it": "Risino"}
- countries: IT
- kinds: dessert

## DISH Q3937015
- name: Risiny
- other names: {"it": "Risiny"}
- countries: IT
- kinds: dessert

## DISH Q3937030
- name: Tiella barese
- other names: {"it": "tiella barese"}
- countries: IT
- kinds: potato dish, seafood dish, rice dish, single course
- ingredients: potato, rice

## DISH Q3939546
- name: Rocciata
- other names: {"it": "Rocciata"}
- countries: IT
- kinds: dessert

## DISH Q3941284
- name: Rosacatarre
- other names: {"it": "Rosacatarre"}
- countries: IT
- kinds: dessert

## DISH Q3941718
- name: Rosticciana
- description: Italian pork dish
- countries: IT
- kinds: pork dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q3941930
- name: Roventino
- other names: {"it": "Roventino"}
- countries: IT
- kinds: main course

## DISH Q3942939
- name: Rustici di Montalcino
- other names: {"it": "Rustici di Montalcino"}
- countries: IT
- kinds: dessert

## DISH Q3944193
- name: Sabadone
- other names: {"it": "Sabadone"}
- countries: IT
- kinds: dessert

## DISH Q3944659
- name: Sacripantina
- description: Italian cake
- countries: IT
- kinds: cake

## DISH Q3945298
- name: Salama da sugo PGI
- other names: {"zh": "Salama da sugo IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product, Rohwurst, dry sausage
- has Wikipedia article: en

## DISH Q3945308
- name: Salame Brianza PDO
- other names: {"zh": "Salame Brianza DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, dry sausage

## DISH Q3945312
- name: Salame Piacentino PDO
- other names: {"zh": "Salame Piacentino DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: charcuterie, meat product, salami

## DISH Q3945316
- name: Salame d'oca di Mortara PGI
- other names: {"zh": "Salame d'oca di Mortara IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product, Brühwurst

## DISH Q3945323
- name: Salame di Varzi PDO
- other names: {"zh": "Salame di Varzi DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, salami

## DISH Q3945334
- name: Salamini italiani alla cacciatora PDO
- other names: {"zh": "Salamini italiani alla cacciatora DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, salami

## DISH Q3945602
- name: Mehari-zushi
- description: rice wrapped in takana leaf
- countries: JP
- kinds: sushi
- ingredients: asazuke
