# Review batch names-033

## DISH Q21428030
- name: Tarte Bourdaloue
- description: French pear tarte
- countries: FR
- kinds: sweet pie
- ingredients: pear

## DISH Q2142880
- name: Rump steak
- other names: {"zh": "後腿肉牛排"}
- description: beef steak cut from the rear of a cow
- countries: (none)
- kinds: cut of beef, dish
- ingredients: black pepper, beef, table salt
- has Wikipedia article: en

## DISH Q2143166
- name: Rømmegrøt
- description: sweet Norwegian porridge made with sour cream
- countries: NO
- kinds: pudding, traditional food
- ingredients: sour cream
- has Wikipedia article: en

## DISH Q2144948
- name: Holahola
- other names: {"es": "holahola"}
- countries: BE
- kinds: cake, type of food or dish

## DISH Q21479763
- name: Pirzola
- description: Turkish style lamb chops
- countries: TR
- kinds: food, Lamb chops

## DISH Q21480617
- name: Enjambre de chocolate
- other names: {"es": "Enjambre de chocolate"}
- countries: MX
- kinds: dessert

## DISH Q21481853
- name: Coconut macaroon
- countries: (none)
- kinds: macaroon
- ingredients: coconut, egg as food, flour, sugar

## DISH Q2148550
- name: Riblji paprikaš
- countries: HR
- kinds: fish dish

## DISH Q21492280
- name: Grouta
- description: type of Cypriot soup
- countries: CY
- kinds: food, soup
- ingredients: flour, drinking water

## DISH Q21493763
- name: Millopita
- description: Pork-fat pie
- countries: CY
- kinds: dish
- ingredients: table salt, drinking water, Xynisteri, Mavro, semolina, lard, flour

## DISH Q21503602
- name: Patates antinahtes
- description: tossed potatoes dish of Cypriot cuisine
- countries: CY
- kinds: food, potato dish
- ingredients: coriander seed, potato, lemon juice, corn oil, table salt, red wine

## DISH Q21503631
- name: Xiniatopita
- description: traditional Cypriot greenpie
- countries: CY
- kinds: food, pie
- ingredients: coriander seed, leaf vegetable, bread

## DISH Q21503641
- name: Fig pie
- description: food
- countries: (none)
- kinds: food, pie
- ingredients: anise seed, fig, rose water, almond, drinking water

## DISH Q21503823
- name: Apohtin
- description: Traditional Cypriot meat dish
- countries: CY
- kinds: food, dish, meat dish, dried meat, goat meat dish
- ingredients: goat meat, Mentha spicata, table salt
- has Wikipedia article: en

## DISH Q21503862
- name: Pishes
- description: traditional Cypriot savoury
- countries: CY
- kinds: food, pancake, dish, pie
- ingredients: almond, oil, flour, cinnamon, table salt, sugar

## DISH Q21513463
- name: Zambousies
- description: traditional Cypriot dish
- countries: (none)
- kinds: börek
- ingredients: onion, oil, flour, cinnamon, table salt, sugar, rice, Capsicum annuum

## DISH Q21515489
- name: Muhammar
- description: traditional dish from Bahrain
- countries: (none)
- kinds: Rice, dish
- has Wikipedia article: en

## DISH Q21517662
- name: Kaikanas
- description: traditional Cypriot pancake
- countries: CY
- kinds: food, pancake, dish
- ingredients: grape syrup, halloumi, Mentha spicata, egg as food, oil

## DISH Q21517908
- name: Psefkia
- description: Cypriot croquette
- countries: CY
- kinds: croquette, potato dish
- ingredients: potato, onion, halloumi, Mentha spicata, oil

## DISH Q21518276
- name: Shamishi
- description: Traditional Cypriot delicacy
- countries: (none)
- kinds: food, delicacy, pie
- ingredients: corn oil, semolina, mastic, flour, table salt, sugar, drinking water
- has Wikipedia article: en

## DISH Q2151924
- name: Riebel
- description: Austrian porridge
- countries: AT
- kinds: porridge, dish

## DISH Q2153114
- name: Mueslibol
- other names: {"nl": "mueslibol"}
- countries: (none)
- kinds: bread roll, type of food or dish
- ingredients: cereal flakes, whole-wheat flour, raisin, nut

## DISH Q21532114
- name: Kattimeri
- description: Traditional Cypriot delicacy
- countries: CY
- kinds: food, dish, pie
- ingredients: oil, flour, cinnamon, table salt, sugar, honey, drinking water

## DISH Q21533302
- name: Poulles
- description: Traditional Cypriot pies with sugar
- countries: CY
- kinds: food, dish, pie
- ingredients: oil, flour, cinnamon, table salt, sugar, drinking water

## DISH Q21534410
- name: Žahour
- description: sweet sauce
- countries: (none)
- kinds: sauce, dish

## DISH Q21575383
- name: German bread
- countries: DE
- kinds: bread

## DISH Q2157889
- name: Potato waffle
- description: mashed potato in grill shape
- countries: GB
- kinds: waffle, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q21588272
- name: Krantz cake
- description: Ashkenazi Jewish cake
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q21595102
- name: Yeast bread
- description: bread made with yeast as an ingredient
- countries: (none)
- kinds: bread
- ingredients: wheat flour, yeast dough

## DISH Q21596812
- name: Sweet bread
- description: bread with a sweet flavor
- countries: (none)
- kinds: type of food or dish, bread, bakers' confection

## DISH Q21597557
- name: Fruit bread
- description: bread that includes fruit as an ingredient
- countries: (none)
- kinds: bread, convenience food

## DISH Q21605556
- name: Thattai (Indian food)
- description: South Indian snack
- countries: IN
- kinds: snack, deep-fried food
- ingredients: wheat flour, lentil, rice flour
- has Wikipedia article: en

## DISH Q2164820
- name: Milk chocolate
- other names: {"zh": "牛奶巧克力"}
- description: type of chocolate
- countries: (none)
- kinds: chocolate, chocolate and sugar confectionery, types of chocolate
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q2165047
- name: Jamón
- other names: {"zh": "塞拉诺火腿"}
- description: dry-cured ham from Spain
- countries: ES
- cuisines: Spanish cuisine
- kinds: raw ham
- has Wikipedia article: en

## DISH Q21651195
- name: Poule au riz
- description: French chicken dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q21652972
- name: 国見バーガー
- other names: {"ja": "国見バーガー"}
- countries: JP
- kinds: hamburger

## DISH Q21653450
- name: 高崎オランダコロッケ
- other names: {"ja": "高崎オランダコロッケ"}
- countries: (none)
- kinds: korokke

## DISH Q21653592
- name: Chanpon-yaki
- countries: (none)
- kinds: fried noodle, Japanese noodles
- ingredients: yaki udon, Yakisoba

## DISH Q21653851
- name: 鳥モツ
- other names: {"ja": "鳥モツ"}
- countries: (none)
- kinds: chicken dish
- ingredients: chicken skin

## DISH Q21654139
- name: 登別閻魔やきそば
- other names: {"ja": "登別閻魔やきそば"}
- countries: JP
- kinds: Yakisoba

## DISH Q21654952
- name: Mobil tempura
- other names: {"zh": "机油天妇罗"}
- description: tempura fried in machine lubricant oil, eaten in Okinawa after WWII
- countries: (none)
- kinds: tempura
- ingredients: motor oil
- has Wikipedia article: zh

## DISH Q21658410
- name: Tsuivan
- description: Mongolian noodle dish with meat and vegetables
- countries: MN
- cuisines: Mongolian cuisine
- kinds: dish
- ingredients: sheep meat, beef, onion, carrot
- has Wikipedia article: en

## DISH Q21662263
- name: Koktal (dish)
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q2167413
- name: Fleur de sel
- other names: {"zh": "盐之花"}
- description: hand-harvested sea salt
- countries: FR
- kinds: sea salt
- has Wikipedia article: en

## DISH Q21707374
- name: Catxipanda
- other names: {"ca": "catxipanda"}
- countries: (none)
- kinds: dish

## DISH Q2170924
- name: Karnemelkse bloempap
- other names: {"nl": "karnemelkse bloempap"}
- countries: (none)
- kinds: porridge, type of food or dish
- ingredients: cereals' and pseudocereals' flour, buttermilk

## DISH Q21709993
- name: Yam kai yang
- countries: (none)
- kinds: Thai salads, yam
- ingredients: kai yang

## DISH Q217446
- name: Lollipop
- other names: {"zh": "棒棒糖"}
- description: candy on a stick
- countries: (none)
- kinds: candy, hard candy
- ingredients: sucrose
- has Wikipedia article: en, zh

## DISH Q21781581
- name: Peruvian pollada
- description: traditional food from Peru
- countries: PE
- kinds: chicken dish, dish
- has Wikipedia article: en

## DISH Q2178599
- name: Räucheraal
- other names: {"de": "Räucheraal"}
- countries: (none)
- kinds: smoked fish, fish dish
- ingredients: European eel

## DISH Q21809695
- name: Russisch ei
- description: type of stuffed eggs
- countries: DE
- kinds: deviled egg, dish, appetizer
- ingredients: egg

## DISH Q21810151
- name: Grießnockerlsuppe
- countries: (none)
- kinds: soup

## DISH Q21816983
- name: Flødekage
- other names: {"da": "flødekage"}
- countries: (none)
- kinds: cake

## DISH Q21831213
- name: Beer cake
- description: cake prepared using beer as a primary ingredient
- countries: US
- cuisines: cuisine of the United States
- kinds: cake
- ingredients: beer
- has Wikipedia article: en

## DISH Q2184029
- name: Eierkoek
- description: soft, airy Dutch egg cake
- countries: (none)
- kinds: food, cookie
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q21862877
- name: Vaniljekranse
- countries: (none)
- kinds: cookie
- ingredients: tonsil, flour, butter, vanilla, sugar

## DISH Q21888014
- name: Carrot soup
- other names: {"zh": "胡萝卜汤"}
- description: soup
- countries: (none)
- kinds: vegetable soup
- ingredients: carrot
- has Wikipedia article: en, zh

## DISH Q2189995
- name: Entremet
- other names: {"zh": "飯間甜點"}
- description: small dish served between courses
- countries: (none)
- kinds: dish, course
- has Wikipedia article: en

## DISH Q219123
- name: Knafeh
- other names: {"zh": "库纳法"}
- description: Eastern dessert
- countries: (none)
- cuisines: Middle Eastern cuisine
- kinds: dessert, pastry, food
- ingredients: sugar, cheese
- has Wikipedia article: en, zh

## DISH Q2191247
- name: Kortrijkse peperbollen
- other names: {"nl": "Kortrijkse peperbollen"}
- countries: (none)
- kinds: cookie, food

## DISH Q2196880
- name: Giri choco
- other names: {"zh": "义理巧克力"}
- description: chocolate
- countries: JP
- kinds: chocolate, communication
- ingredients: chocolate
- has Wikipedia article: en, zh

## DISH Q21976352
- name: Capunti
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q2198556
- name: Tiel carnival cake
- description: Traditional Dutch cake
- countries: (none)
- kinds: ontbijtkoek, food, cookie
- has Wikipedia article: en

## DISH Q21994744
- name: Delimanjoo
- description: South Korean confectionery
- countries: KR
- cuisines: Seoul cuisine
- kinds: snack cake
- has Wikipedia article: en

## DISH Q2201017
- name: Meal soup
- description: soup that is equivalent to a hot meal
- countries: (none)
- kinds: food, soup

## DISH Q2202018
- name: Jengyal bread
- description: Karabakhian dish
- countries: (none)
- kinds: flatbread
- ingredients: herb, flour
- has Wikipedia article: en

## DISH Q220406
- name: Zopf
- other names: {"zh": "辫子面包"}
- description: type of Swiss, Austrian, German or Bavarian bread
- countries: CH
- cuisines: Swiss cuisine, Austrian cuisine, German cuisine
- kinds: white bread, yeast bread
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q2204257
- name: Liege waffle
- other names: {"zh": "列日华夫饼"}
- description: dense, sweet, chewy waffle, native to Wallonia, made with brioche dough with chunks of sugar which caramelize on the outside
- countries: BE
- cuisines: cuisine of Belgium
- kinds: waffle, food
- ingredients: dough
- has Wikipedia article: en, zh

## DISH Q2204450
- name: Roti
- other names: {"zh": "印度麵包"}
- description: South Asian rounded flatbread, characteristically unleavened
- countries: IN, BD
- cuisines: Bengali cuisine, South Asian cuisine
- kinds: Indian bread, South Asian bread
- ingredients: atta
- has Wikipedia article: en

## DISH Q22074473
- name: Vinschgauer struzn PAT
- other names: {"zh": "Vinschgauer struzn PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: bread, baked good

## DISH Q22077768
- name: Joe's Special
- description: American egg, spinach and beef dish
- countries: US
- kinds: egg dish
- has Wikipedia article: en

## DISH Q220964
- name: Tapas
- other names: {"zh": "塔帕斯"}
- description: appetizer or snack in Spanish cuisine
- countries: ES
- cuisines: Spanish cuisine
- kinds: appetizer, cuisine
- has Wikipedia article: en, zh

## DISH Q22099232
- name: 薑汁番茄
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q22099375
- name: Milkfish belly
- other names: {"zh": "虱目魚肚"}
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q22099440
- name: Har cheong gai
- other names: {"zh": "蝦醬雞"}
- description: Singaporean fried chicken
- countries: SG
- kinds: chicken dish
- ingredients: chicken wing
- has Wikipedia article: en, zh

## DISH Q22101093
- name: Bí-láu
- other names: {"zh": "米粩"}
- countries: (none)
- kinds: confectionery
- ingredients: Oryza molida, puffed rice
- has Wikipedia article: zh

## DISH Q22107361
- name: Maasstroompje
- other names: {"nl": "Maasstroompje"}
- countries: (none)
- kinds: food, pastry

## DISH Q22115527
- name: Sailor sandwich
- description: sandwich with hot meat and cheese
- countries: US
- kinds: sandwich
- ingredients: hot mustard, Swiss cheese, rye bread, pastrami, Knackwurst
- has Wikipedia article: en

## DISH Q2211605
- name: Strooigoed
- countries: (none)
- kinds: Sinterklaas candy, food
- ingredients: Kruidnoten, pepernoot

## DISH Q22122965
- name: Ikanago shoyu
- countries: (none)
- kinds: fish sauce
- ingredients: Ammodytes personatus

## DISH Q22123108
- name: 秋田味噌
- other names: {"ja": "秋田味噌"}
- countries: (none)
- kinds: miso

## DISH Q22123615
- name: Daikon-zushi
- countries: (none)
- kinds: narezushi
- ingredients: Japanese radish, migaki nishin

## DISH Q22123729
- name: Katahira akane
- countries: JP
- kinds: Brassicaceae, Yamato yasai

## DISH Q22123780
- name: Ishiru
- countries: (none)
- kinds: fish sauce

## DISH Q22123918
- name: カップヌードル トムヤムクンヌードル
- other names: {"ja": "カップヌードル トムヤムクンヌードル"}
- countries: (none)
- kinds: Cup Noodles

## DISH Q22124115
- name: Azumadon
- countries: JP
- kinds: Kaisen-don, dish
- ingredients: Thunnus, rice

## DISH Q22125126
- name: ベジポタラーメン
- other names: {"ja": "ベジポタラーメン"}
- countries: (none)
- kinds: ramen

## DISH Q22125806
- name: Sado miso
- other names: {"zh": "佐渡味噌"}
- countries: JP
- kinds: miso

## DISH Q22126085
- name: 讃岐味噌
- other names: {"ja": "讃岐味噌"}
- countries: (none)
- kinds: Shiromiso

## DISH Q22126223
- name: 鮎魚醤
- other names: {"ja": "鮎魚醤"}
- countries: JP
- kinds: fish sauce
- ingredients: ayu sweetfish as food

## DISH Q22126455
- name: Takiawase
- countries: (none)
- kinds: nimono

## DISH Q22126547
- name: Kuzugashi
- description: Japanese confection
- countries: (none)
- kinds: rakugan
- ingredients: kudzu powder

## DISH Q22126842
- name: Dolphin sukiyaki
- countries: JP
- kinds: sukiyaki
- ingredients: meat

## DISH Q22127118
- name: Hōhan
- countries: (none)
- kinds: Japanese rice dish

## DISH Q22127654
- name: Tataki gobō
- description: Japanese condiment made with burdock root
- countries: JP
- kinds: Arctium, spice, vegetable dish, gastronomy
- ingredients: Arctium lappa
- has Wikipedia article: en

## DISH Q22127767
- name: Fuchū miso
- countries: JP
- kinds: miso

## DISH Q22128352
- name: とうきびチョコ
- other names: {"ja": "とうきびチョコ"}
- countries: (none)
- kinds: chocolate

## DISH Q22128778
- name: いかり豆
- other names: {"ja": "いかり豆"}
- description: deep-fried broad beans, eaten as a snack
- countries: (none)
- kinds: confectionery

## DISH Q22128780
- name: Sukugurasu
- countries: (none)
- kinds: shiokara
- ingredients: juvenile fish

## DISH Q22129329
- name: Kinako zōni
- countries: (none)
- kinds: zōni
- ingredients: kinako, mochi

## DISH Q22129368
- name: おのまち小町アイスバーガー
- other names: {"ja": "おのまち小町アイスバーガー"}
- countries: JP
- kinds: sweet bread

## DISH Q22129478
- name: Miso kanpura
- countries: (none)
- kinds: dish

## DISH Q22129488
- name: Tarajiru
- description: Japanese pollock soup
- countries: JP
- kinds: shirumono
- ingredients: Theragra chalcogramma

## DISH Q22130080
- name: 相白味噌
- other names: {"ja": "相白味噌"}
- countries: (none)
- kinds: Shiromiso

## DISH Q22130346
- name: キャベツ餅
- other names: {"ja": "キャベツ餅"}
- countries: JP
- kinds: mochi, vegetable dish

## DISH Q22130819
- name: Surinagashi
- countries: JP
- cuisines: Japanese cuisine
- kinds: soup

## DISH Q22131080
- name: 紅葉漬
- other names: {"ja": "紅葉漬"}
- countries: JP
- kinds: fish dish

## DISH Q22131161
- name: Kōriyama black ramen
- countries: (none)
- kinds: shoyu ramen

## DISH Q2213650
- name: Kuy teav
- other names: {"zh": "金边粿条"}
- description: Cambodian noodle soup
- countries: KH
- kinds: food, noodle soup
- ingredients: rice noodle
- has Wikipedia article: en

## DISH Q2214748
- name: Salmagundi
- description: cold dish or salad
- countries: GB
- kinds: salad
- ingredients: meat
- has Wikipedia article: en

## DISH Q2215889
- name: Fun guo
- other names: {"zh": "潮州粉粿"}
- description: Chinese steamed dumplings
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en, zh

## DISH Q2216156
- name: Salt potatoes
- other names: {"zh": "鹽煮馬鈴薯"}
- description: dish from Syracuse, New York, consisting of potatoes boiled in brine
- countries: DE, US
- kinds: boiled potatoes, dish
- has Wikipedia article: en, zh

## DISH Q2216200
- name: Салёныя грыбы
- other names: {"be": "Салёныя грыбы"}
- countries: RU
- cuisines: Russian cuisine
- kinds: dish
- ingredients: edible mushroom, table salt

## DISH Q2216731
- name: Samanu
- other names: {"zh": "苏麦莱克甜粥"}
- description: wheat dish from Iran and Central Asia
- countries: IR
- kinds: dessert, type of food or dish
- has Wikipedia article: en

## DISH Q2217953
- name: Oranĝa vlao
- other names: {"eo": "oranĝa vlao"}
- countries: (none)

## DISH Q2220865
- name: Sand cake
- description: type of cake
- countries: (none)
- kinds: cake

## DISH Q2220900
- name: Ham sandwich
- other names: {"zh": "火腿三明治"}
- description: common type of sandwich containing ham
- countries: GB
- kinds: meat sandwich
- ingredients: ham, bread
- has Wikipedia article: en

## DISH Q2221627
- name: Fried noodle
- other names: {"zh": "炒麵"}
- description: stir-fried noodle
- countries: (none)
- kinds: noodle dish
- ingredients: noodle
- has Wikipedia article: en, zh

## DISH Q22230854
- name: Lakh
- description: millet porridge
- countries: (none)
- kinds: porridge
- ingredients: millet
- has Wikipedia article: en

## DISH Q22230906
- name: Žemaičių blynai
- description: Lithuanian potato and meat dish
- countries: LT
- kinds: potato dish
- ingredients: potato, minced meat, onion

## DISH Q2223254
- name: Amandine
- other names: {"zh": "阿曼达蛋糕"}
- description: Romanian prepared dessert
- countries: RO
- kinds: cake
- has Wikipedia article: en, zh

## DISH Q222463
- name: Prahok
- description: crushed, salted and fermented fish paste used in Cambodian cuisine
- countries: KH
- kinds: fermented fish, fish paste
- ingredients: fermented fish, salted fish
- has Wikipedia article: en

## DISH Q2224749
- name: Beccafico sardines
- description: typical Sicilian dish made with sardines
- countries: IT
- cuisines: Sicilian cuisine
- kinds: fish dish
- ingredients: Sardina, sultana, pine nut, bread

## DISH Q22249532
- name: Vôte
- other names: {"fr": "vôte"}
- countries: (none)
- kinds: dish
- ingredients: egg as food

## DISH Q2227032
- name: Mojo
- description: several types of sauces
- countries: ES
- cuisines: Canarian cuisine, Spanish cuisine
- kinds: hot sauce, sauce
- ingredients: garlic, Capsicum, chili pepper, Carum, olive oil, Coriandrum sativum, vinegar, table salt
- has Wikipedia article: en

## DISH Q2227296
- name: Pestiños
- description: Andalusian sweet pastry
- countries: ES
- kinds: doughnut, fritter
- ingredients: dough
- has Wikipedia article: en

## DISH Q2227693
- name: Saure Nieren
- other names: {"de": "Saure Nieren"}
- countries: DE
- cuisines: German cuisine
- kinds: dish

## DISH Q22328037
- name: Nyama choma
- description: grilled goat meat
- countries: KE, TZ
- kinds: dish
- ingredients: mutton
- has Wikipedia article: en

## DISH Q22328802
- name: Turrón de Agramunt
- description: nougat made in the municipality of Agramunt
- countries: (none)
- kinds: turrón

## DISH Q2234053
- name: Moorkop
- description: pastry
- countries: (none)
- kinds: pastry
- ingredients: profiterole, whipped cream, icing
- has Wikipedia article: en

## DISH Q2234318
- name: Schiebewurst
- other names: {"de": "Schiebewurst"}
- countries: (none)
- kinds: Wurstbrot, idiom

## DISH Q22348764
- name: Filet américain
- description: Brussels meat dish of raw lean beef
- countries: BE
- kinds: spread, raw beef dish, dish
- ingredients: peppercorn, beef, egg as food
- has Wikipedia article: en

## DISH Q2236189
- name: Schinkenbrot
- other names: {"de": "Schinkenbrot"}
- countries: (none)
- kinds: dish

## DISH Q2236199
- name: Schinkenfleckerl
- other names: {"de": "Schinkenfleckerl"}
- countries: (none)
- kinds: dish

## DISH Q2236643
- name: Schlabberkappes
- other names: {"de": "Schlabberkappes"}
- countries: (none)
- kinds: dish

## DISH Q2236849
- name: Puntbrood
- other names: {"nl": "puntbrood"}
- countries: (none)
- kinds: food, bread

## DISH Q2239048
- name: Schlemmerfilet
- other names: {"de": "Schlemmerfilet"}
- countries: (none)
- kinds: fish dish

## DISH Q22404
- name: Egg tart
- other names: {"zh": "蛋撻"}
- description: type of dessert consisting of an outer pastry crust filled with egg custard
- countries: GB
- kinds: dim sum, pastry, dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q22442810
- name: Tomme du Nevet
- description: French cheese
- countries: FR
- kinds: raw-milk cheese, pressed uncooked cheese, French cheese, cow's-milk cheese, farmstead cheese
- ingredients: cow's milk

## DISH Q22442935
- name: Bastognekoek
- other names: {"nl": "bastognekoek"}
- countries: (none)
- kinds: cookie, baked good
- ingredients: candi syrup, self-raising flour, egg yolk, butter, cinnamon, clove, sugar

## DISH Q2244571
- name: Baby potato
- description: dish of small potatoes
- countries: FR
- kinds: potato dish, food

## DISH Q2247208
- name: Schneeball
- description: German dessert
- countries: DE
- kinds: food, pastry, type of food or dish
- ingredients: shortcrust pastry, cookie, sugar
- has Wikipedia article: en

## DISH Q2247910
- name: Schnepfendreck
- description: forgotten dish made from the entrails of a snipe and its contents
- countries: (none)
- kinds: offal, dish, game meat

## DISH Q2248563
- name: Schoggitaler
- other names: {"zh": "Schoggitaler"}
- countries: (none)
- kinds: chocolate coins
- has Wikipedia article: zh

## DISH Q2248655
- name: Scholle Finkenwerder Art
- other names: {"de": "Scholle Finkenwerder Art"}
- countries: (none)
- kinds: fish dish
- ingredients: onion, Pleuronectes platessa, bacon

## DISH Q2250838
- name: Schulbrezel
- other names: {"de": "Schulbrezel"}
- countries: (none)
- kinds: viennoiserie

## DISH Q2251212
- name: Brudet
- description: fish stew from Croatia
- countries: IT
- kinds: fish dish
- ingredients: fish as food
- has Wikipedia article: en

## DISH Q2251745
- name: Baked good
- other names: {"zh": "烘培食品"}
- description: foods made from dough or batter (cereals or cereal products) that are cooked by baking
- countries: (none)
- kinds: skill, type of food or dish, food, dish, bakery products, pastry, cakes and long-term cakes
- ingredients: dough, flour

## DISH Q2252452
- name: Schuxen
- description: German pastry
- countries: DE
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q2253377
- name: Black-and-white cookies
- description: cookies made from two kinds of dough, one containing cocoa
- countries: (none)
- kinds: cookie

## DISH Q2253902
- name: Punsch-roll
- description: Swedish pastry
- countries: SE
- kinds: pastry
- ingredients: punsch, Pasta di mandorle PAT, arrack, sponge cake, sugar paste, butter, chocolate
- has Wikipedia article: en

## DISH Q2254128
- name: Puddingbroodje
- description: Dutch pastry consisting of a sweet bread roll filled with pastry cream
- countries: (none)
- kinds: pastry, food
- ingredients: pastry cream, powdered sugar

## DISH Q2255016
- name: Lapin à la Tournaisienne
- description: Belgian rabbit dish
- countries: BE
- kinds: stew, rabbit dish
- ingredients: rabbit meat

## DISH Q2255682
- name: Schweinepfeffer
- other names: {"de": "Schweinepfeffer"}
- countries: (none)
- kinds: dish

## DISH Q2255703
- name: Pork tail
- description: dish made from pig's tail
- countries: (none)
- kinds: dish, butchering, pork
- ingredients: pig's tail, tail
- has Wikipedia article: en

## DISH Q2255787
- name: Pig head
- other names: {"zh": "猪头肉"}
- description: type of offal
- countries: (none)
- kinds: offal, dish, pièce montée, cuts of pork, food ingredient
- has Wikipedia article: en, zh

## DISH Q2255814
- name: Pig's ear
- other names: {"zh": "豬耳"}
- description: cooked ear of pig for human food consumption
- countries: (none)
- kinds: food product, pork dish
- ingredients: pork
- has Wikipedia article: en, zh

## DISH Q2256739
- name: Zure mat
- other names: {"nl": "Zure mat"}
- countries: (none)
- kinds: candy

## DISH Q22570090
- name: Mathura Peda
- description: Indian Sweet dish
- countries: IN
- kinds: sweet dish
- ingredients: khoa
- has Wikipedia article: en

## DISH Q2258011
- name: Seele
- other names: {"de": "Seele"}
- countries: (none)
- kinds: pastry

## DISH Q2258053
- name: Samurai sauce
- description: Franco-Belgian condiment for fried potatoes, made from mayonnaise, ketchup, and harissa or sambal oelek
- countries: BE
- cuisines: cuisine of Belgium
- kinds: condiment, hot sauce
- ingredients: Sambal oelek, ketchup, mayonnaise
- has Wikipedia article: en

## DISH Q22583433
- name: Beef kway teow
- description: Indonesian flat rice noodle dish
- countries: SG
- kinds: dish
- has Wikipedia article: en

## DISH Q2259868
- name: Schuettelbrot
- description: Flatbread from South Tyrol
- countries: IT
- kinds: flatbread

## DISH Q22620
- name: Sausage soup broth
- description: broth made from cooking sausage
- countries: (none)
- kinds: soup, broth

## DISH Q2265797
- name: Seezunge Adlon
- other names: {"de": "Seezunge Adlon"}
- countries: DE
- kinds: fish dish
- ingredients: scampi, truffle, Agaricus bisporus, common sole, white wine

## DISH Q22666192
- name: Asuškys
- other names: {"ltg": "Asuškys"}
- countries: LV
- kinds: dish
- ingredients: quark, egg as food, yeast, flour, table salt, sugar

## DISH Q22666199
- name: Batveņa
- other names: {"ltg": "Batveņa"}
- countries: (none)
- kinds: dish

## DISH Q22666202
- name: Boltuos dasys
- other names: {"ltg": "Boltuos dasys"}
- countries: (none)
- kinds: dish

## DISH Q22666206
- name: Buļbešnīki
- other names: {"ltg": "Buļbešnīki"}
- countries: (none)
- kinds: dish

## DISH Q22666207
- name: Buļbis ar katuku
- other names: {"ltg": "Buļbis ar katuku"}
- countries: (none)
- kinds: dish

## DISH Q22666208
- name: Buļbu dasys
- other names: {"ltg": "Buļbu dasys"}
- countries: (none)
- kinds: dish

## DISH Q22666209
- name: Buļbu meiceknis
- other names: {"ltg": "Buļbu meiceknis"}
- countries: (none)
- kinds: dish

## DISH Q22666210
- name: Bygucs
- other names: {"ltg": "Bygucs"}
- countries: (none)
- kinds: dish

## DISH Q22666214
- name: Cureite
- other names: {"ltg": "Cureite"}
- countries: (none)
- kinds: dish

## DISH Q22666215
- name: Cymuss
- other names: {"ltg": "Cymuss"}
- countries: (none)
- kinds: dish

## DISH Q22666221
- name: Dzjupka
- other names: {"ltg": "Dzjupka"}
- countries: (none)
- kinds: dish

## DISH Q22666229
- name: Gryuslis
- other names: {"ltg": "gryuslis"}
- countries: (none)
- kinds: dish

## DISH Q22666233
- name: Iz ūgļu capta siļče
- other names: {"ltg": "Iz ūgļu capta siļče"}
- countries: (none)
- kinds: dish

## DISH Q22666237
- name: Juknova
- other names: {"ltg": "Juknova"}
- countries: (none)
- kinds: dish

## DISH Q22666242
- name: Kanepīns
- other names: {"ltg": "Kanepīns"}
- countries: (none)
- kinds: dish

## DISH Q22666244
- name: Karseknis
- other names: {"ltg": "Karseknis"}
- countries: (none)
- kinds: dish

## DISH Q22666249
- name: Komys
- other names: {"ltg": "Komys"}
- countries: (none)
- kinds: dish

## DISH Q22666252
- name: Krapanīks
- other names: {"ltg": "Krapanīks"}
- countries: (none)
- kinds: dish

## DISH Q22666253
- name: Krupnīks
- other names: {"ltg": "Krupnīks"}
- countries: (none)
- kinds: dish

## DISH Q22666255
- name: Kukuleiši
- other names: {"ltg": "Kukuleiši"}
- countries: (none)
- kinds: dish

## DISH Q22666260
- name: Kūčys
- other names: {"ltg": "Kūčys"}
- countries: (none)
- kinds: dish

## DISH Q22666265
- name: Latgaļu iedīni
- other names: {"ltg": "Latgaļu iedīni"}
- countries: (none)
- kinds: dish

## DISH Q22666288
- name: Latgolys rysa
- other names: {"ltg": "Latgolys rysa"}
- countries: (none)
- kinds: dish

## DISH Q22666316
- name: Miļtinīks
- other names: {"ltg": "Miļtinīks"}
- countries: (none)
- kinds: dish

## DISH Q22666319
- name: Murcauka
- other names: {"ltg": "Murcauka"}
- countries: (none)
- kinds: dish

## DISH Q22666322
- name: Oknu sīrs
- other names: {"ltg": "Oknu sīrs"}
- countries: (none)
- kinds: dish

## DISH Q22666336
- name: Pancaks
- other names: {"ltg": "Pancaks"}
- countries: (none)
- kinds: dish

## DISH Q22666337
- name: Paneju keisieļs
- other names: {"ltg": "Paneju keisieļs"}
- countries: (none)
- kinds: dish

## DISH Q22666338
- name: Paneju peirāgi
- other names: {"ltg": "Paneju peirāgi"}
- countries: (none)
- kinds: dish

## DISH Q22666345
- name: Ramans
- other names: {"ltg": "Ramans"}
- countries: (none)
- kinds: dish

## DISH Q22666346
- name: Раўгеня
- other names: {"be": "раўгеня"}
- countries: BY
- cuisines: Belarusian cuisine
- kinds: dish
- ingredients: water, rye flour

## DISH Q22666350
- name: Ruļads
- other names: {"ltg": "Ruļads"}
- countries: (none)
- kinds: dish

## DISH Q22666352
- name: Saladuks
- other names: {"ltg": "Saladuks"}
- countries: (none)
- kinds: dish

## DISH Q22666358
- name: Skuobuļs
- other names: {"ltg": "Skuobuļs"}
- countries: (none)
- kinds: dish

## DISH Q22666359
- name: Stakaņs
- other names: {"ltg": "Stakaņs"}
- countries: (none)
- kinds: dish

## DISH Q22666363
- name: Studiņs
- other names: {"ltg": "Studiņs"}
- countries: (none)
- kinds: dish

## DISH Q22666365
- name: Stuļčs
- other names: {"ltg": "Stuļčs"}
- countries: (none)
- kinds: dish

## DISH Q22666366
- name: Sutnis
- other names: {"ltg": "Sutnis"}
- countries: (none)
- kinds: dish

## DISH Q22666368
- name: Tatarvans
- other names: {"ltg": "Tatarvans"}
- countries: (none)
- kinds: dish

## DISH Q22666371
- name: Trombelis
- other names: {"ltg": "Trombelis"}
- countries: (none)
- kinds: dish

## DISH Q22666378
- name: Veisteknis
- other names: {"ltg": "Veisteknis"}
- countries: (none)
- kinds: dish

## DISH Q22666380
- name: Virtiņs
- other names: {"ltg": "Virtiņs"}
- countries: (none)
- kinds: dish

## DISH Q22666384
- name: Škvarkys
- other names: {"ltg": "Škvarkys"}
- countries: (none)
- kinds: dish

## DISH Q22666385
- name: Ūlukne
- other names: {"ltg": "Ūlukne"}
- countries: (none)
- kinds: dish

## DISH Q22669970
- name: Vyborg Kringle
- countries: (none)
- kinds: kringle

## DISH Q2267393
- name: Mola salsa
- description: Ancient roman ritual food
- countries: (none)
- cuisines: Ancient Roman cuisine
- kinds: recipe, flatbread
- ingredients: farro, table salt
- has Wikipedia article: en

## DISH Q22689325
- name: Kahi
- description: Iraqi sweet breakfast dish
- countries: IQ
- kinds: pastry
- ingredients: phyllo
- has Wikipedia article: en

## DISH Q22689348
- name: Orange cake
- countries: (none)
- kinds: type of food or dish, cake

## DISH Q22689366
- name: كنافة مبرومة
- other names: {"ar": "كنافة مبرومة"}
- countries: (none)
- kinds: confectionery

## DISH Q2269366
- name: Semmelkren
- other names: {"de": "Semmelkren"}
- description: dish in Austrian cuisine
- countries: (none)
- kinds: dish

## DISH Q2273698
- name: Serikaya
- other names: {"de": "Serikaya"}
- countries: (none)
- kinds: dish

## DISH Q2274269
- name: Serviettenknödel
- description: German bread dumpling
- countries: AT, CZ, DE
- kinds: dish, Semmelknödel
- ingredients: onion, egg as food, butter, parsley, table salt, milk, bread
- has Wikipedia article: en

## DISH Q227658
- name: Zuccotto
- other names: {"zh": "義大利圓頂蛋糕"}
- description: Italian cuisine dessert made using a pumpkin shaped mold
- countries: IT
- kinds: dessert
- ingredients: cake
- has Wikipedia article: en

## DISH Q2277500
- name: Piave PDO
- other names: {"zh": "Piave DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, cow's-milk cheese, Italian cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q2279804
- name: Shoofly pie
- description: molasses pie
- countries: US
- kinds: sweet pie
- has Wikipedia article: en

## DISH Q227999
- name: Zuckerrenkerl
- description: Carinthian specialty, sweet pastry
- countries: (none)
- kinds: sweet dish, pastry

## DISH Q2281241
- name: Bokkenpootje
- description: type of meringue cookie in the Netherlands
- countries: (none)
- kinds: food, cookie
- has Wikipedia article: en

## DISH Q2282540
- name: Cruller
- other names: {"zh": "油炸麻花"}
- description: fried pastry food item
- countries: (none)
- kinds: type of food or dish, pastry, viennoiserie, deep-fried food
- has Wikipedia article: en

## DISH Q228373
- name: Zuger Kirschtorte
- description: Swiss cake
- countries: CH
- cuisines: Swiss cuisine
- kinds: torte, foam cake
- ingredients: sponge cake, kirsch
- has Wikipedia article: en

## DISH Q2284641
- name: Sig (Milchprodukt)
- other names: {"de": "Sig (Milchprodukt)"}
- countries: (none)
- kinds: dish

## DISH Q2284646
- name: Sigara böreği
- description: fried "börek" from the Turkish cuisine shaped like a cigar or cigarette
- countries: TR
- kinds: entrée, börek

## DISH Q2286933
- name: Amsterdam ossenworst
- description: Dutch sausage
- countries: (none)
- kinds: raw beef dish
- has Wikipedia article: en

## DISH Q2290274
- name: Belgian praline
- other names: {"zh": "果仁糖"}
- description: chocolate shell with a softer, sometimes liquid, filling
- countries: BE
- kinds: praline, Belgian chocolate, bonbon, confectionery
- has Wikipedia article: en

## DISH Q22907126
- name: Mutton flaps
- description: cut of meat from a domestic sheep
- countries: (none)
- kinds: lamb dish
- has Wikipedia article: en

## DISH Q22907436
- name: Confiture
- description: fruit jam in thick syrup
- countries: FR
- kinds: jam, food
- has Wikipedia article: en

## DISH Q22914816
- name: Yam khai dao
- description: Thai dish made from fried chicken or duck eggs
- countries: TH
- kinds: yam
- has Wikipedia article: en

## DISH Q2291684
- name: Bundt cake
- other names: {"zh": "圓環蛋糕"}
- description: donut-shaped cake
- countries: US
- kinds: cake
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q2291748
- name: Mostbröckli
- countries: CH
- kinds: meat dish, Rohwurst, dry sausage
- ingredients: garlic, juniper berry, peppercorn, bay leaf, beef, table salt, sugar

## DISH Q22928569
- name: Qrishlat
- description: Moroccan sweets
- countries: MA
- kinds: candy, human food
- ingredients: anise seed, sesame seed, baker's yeast, egg as food, olive oil, butter, table salt, sugar

## DISH Q22929033
- name: Market jelbana
- description: Tunisian traditional stew, composed of beef or chicken and peas
- countries: TN
- kinds: stew
- ingredients: Pisum sativum, meat

## DISH Q22929120
- name: Tajine Lham-Lahlou
- description: Algerian food
- countries: DZ, MA
- cuisines: Moroccan cuisine, Algerian cuisine
- kinds: cooking, dish
- ingredients: food, meat
- has Wikipedia article: en

## DISH Q22929166
- name: Bajjaria
- description: Lamb dish popular in Syria
- countries: SY
- kinds: dish
- ingredients: lamb meat, ghee
- has Wikipedia article: en

## DISH Q22931404
- name: الفورة
- other names: {"ar": "الفورة"}
- description: Wikimedia list article
- countries: (none)
- kinds: dish

## DISH Q2293198
- name: Pano kun lienaĵo
- other names: {"eo": "Pano kun lienaĵo"}
- description: type of Sicilian street food
- countries: IT
- cuisines: Sicilian cuisine
- kinds: street food, meat sandwich
- ingredients: spleen, lung, bread
- has Wikipedia article: en

## DISH Q22934387
- name: كنافة بالجبن
- other names: {"ar": "كنافة بالجبن"}
- countries: (none)
- kinds: confectionery

## DISH Q2293551
- name: Sabzi polo
- description: Iranian rice and herb dish
- countries: IR
- kinds: rice dish
- ingredients: herb
- has Wikipedia article: en

## DISH Q22936428
- name: Calamarata
- description: type of pasta
- countries: (none)
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q229385
- name: Soy sauce
- other names: {"zh": "酱油"}
- description: liquid seasoning
- countries: JP, CN
- cuisines: Japanese cuisine, Chinese cuisine
- kinds: sauce, fermented food, soy food
- ingredients: soy bean
- has Wikipedia article: en, zh

## DISH Q2294743
- name: Barbajuan
- description: southern European appetizer
- countries: MC
- kinds: culinary speciality, rissole
- ingredients: chard
- has Wikipedia article: en

## DISH Q22949248
- name: Mughlai paratha
- description: popular street food originated in Bengal
- countries: (none)
- kinds: paratha
- has Wikipedia article: en

## DISH Q22971811
- name: Pork cutlet
- countries: (none)
- kinds: breaded cutlet, pork dish
- has Wikipedia article: en

## DISH Q2297499
- name: Sofrito (stew)
- countries: GR
- kinds: dish, traditional food

## DISH Q22976
- name: Dampfnudel
- other names: {"zh": "德式饅頭"}
- description: German steamed and pan-fried dumpling
- countries: DE, FR
- cuisines: Austrian cuisine, German cuisine, Alsatian cuisine
- kinds: dish, dumpling
- ingredients: flour, jam
- has Wikipedia article: en, zh

## DISH Q229777
- name: Zundamochi
- other names: {"zh": "毛豆麻糬"}
- description: soy-based Japanese sweet
- countries: JP
- kinds: mochi, wagashi
- ingredients: zunda
- has Wikipedia article: en, zh

## DISH Q2297811
- name: Succade
- description: candied citrus peel
- countries: (none)
- kinds: candied fruit
- ingredients: Citrus, sugar
- has Wikipedia article: en

## DISH Q22984333
- name: Busti
- other names: {"ca": "Busti"}
- countries: (none)
- kinds: guiso
- ingredients: onion, Allium sativum, bread, cattle, carrot

## DISH Q23000048
- name: Clementine cake
- description: cake
- countries: (none)
- kinds: cake
- ingredients: Citrinos × clementina
- has Wikipedia article: en

## DISH Q23004
- name: Bread roll
- other names: {"zh": "圆面包"}
- description: small, usually round or oblong individual loaf of bread served as a meal accompaniment
- countries: AT, DE, IT, RU
- kinds: bread, type of food or dish
- ingredients: dough, yeast
- has Wikipedia article: en, zh

## DISH Q23005886
- name: Hernhutter
- description: cookie
- countries: (none)
- kinds: cookie

## DISH Q23007309
- name: Solina Weizen
- other names: {"de": "Solina Weizen"}
- countries: IT
- kinds: Abruzzo's traditional food products, wheat

## DISH Q23008804
- name: Oubliehoorn
- other names: {"nl": "oubliehoorn"}
- countries: (none)
- kinds: Oblietjie

## DISH Q23015
- name: Suckling pig
- other names: {"zh": "葡萄牙仔猪肉"}
- description: piglet fed on its mother's milk
- countries: (none)
- kinds: piglet, suckling animals, pork dish
- ingredients: suckling pig meat
- has Wikipedia article: en

## DISH Q23019214
- name: Basashi
- other names: {"zh": "生馬肉"}
- description: raw horse meat
- countries: JP
- kinds: sashimi, raw meat dish
- ingredients: horse meat

## DISH Q23020291
- name: Tiparos
- description: food brand and company
- countries: (none)
- kinds: fish sauce
- has Wikipedia article: en

## DISH Q23021894
- name: Ciorbă de burtă
- description: Rumanian tripe soup
- countries: RO
- kinds: dish, tripe soup
- ingredients: tripe

## DISH Q2302413
- name: Smoked salmon
- other names: {"zh": "燻鮭魚"}
- description: smoked food
- countries: (none)
- kinds: smoked fish, cured salmon, salmon dish
- ingredients: salmon
- has Wikipedia article: en, zh

## DISH Q230246
- name: Zuppa Romana
- description: German variation of the Italian dessert zuppa inglese
- countries: (none)
- kinds: cake, variation
- has Wikipedia article: en

## DISH Q2303056
- name: Shepherd's pie
- other names: {"zh": "牧羊人派"}
- description: meat pie with a crust or topping of mashed potato
- countries: GB, IE
- cuisines: British cuisine
- kinds: meat pie, potato dish
- ingredients: potato, mashed potato, meat
- has Wikipedia article: en, zh

## DISH Q2303453
- name: Sulguni
- other names: {"zh": "蘇爾古尼"}
- description: Georgian сheese
- countries: GE
- kinds: Georgian cheese
- ingredients: cow's milk, raw milk
- has Wikipedia article: en, zh

## DISH Q23034858
- name: Türlü
- description: Turkish vegetable stew
- countries: TR
- kinds: stew, vegetable dish, food
- ingredients: tomato, potato, mutton, okra, green bean, lamb meat, beef, zucchini, carrot
- has Wikipedia article: en

## DISH Q2303610
- name: Tournedos Rossini
- other names: {"zh": "羅西尼牛排"}
- description: French steak dish
- countries: FR
- kinds: beef dish
- ingredients: crouton, Tuber melanosporum, filet mignon, foie gras
- has Wikipedia article: en

## DISH Q2304005
- name: Uszka
- description: small dumplings
- countries: PL
- cuisines: Polish cuisine, Ukrainian cuisine, Lithuanian cuisine, Russian cuisine
- kinds: dish, stuffed pasta
- ingredients: minced meat, edible mushroom, dough
- has Wikipedia article: en

## DISH Q2304082
- name: Soumaintrain
- description: French cheese
- countries: FR
- kinds: French cheese, farmstead cheese, industrial cheese, washed-rind cheese, dairy cheese
- ingredients: cow's milk

## DISH Q2306472
- name: Neapolitan ragù
- other names: {"zh": "拿坡里肉醬"}
- description: Italian meat sauce
- countries: IT
- kinds: ragù
- ingredients: mirepoix
- has Wikipedia article: en, zh

## DISH Q2306704
- name: Spanisch-Suppe
- other names: {"de": "Spanisch-Suppe"}
- countries: (none)
- kinds: dish

## DISH Q2306706
- name: Spanish fricco
- description: Westphalian beef, potato and onion stew
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q2307239
- name: Custard tart
- other names: {"zh": "蛋挞"}
- description: baked dessert consisting of an egg custard-filled pastry crust
- countries: FR
- kinds: finger food, sweet tart
- ingredients: dough, egg as food
- has Wikipedia article: en

## DISH Q23074345
- name: Bah-sò
- other names: {"zh": "肉燥"}
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q2308008
- name: Itala bulko
- other names: {"eo": "Itala bulko"}
- countries: (none)
- kinds: bread roll

## DISH Q2308313
- name: Bacon dumplings
- description: bacon dumpling
- countries: (none)
- kinds: knödel, dish, pork dish
- ingredients: onion, egg as food, bacon, bread

## DISH Q2308332
- name: Speckkuchen
- description: Flatbread with a topping of crushed bacon
- countries: DE, HU
- cuisines: German cuisine, Hungarian cuisine
- kinds: sheet cake
- has Wikipedia article: en

## DISH Q2311032
- name: Spirgel
- other names: {"de": "Spirgel"}
- countries: (none)
- kinds: dish

## DISH Q2311837
- name: Splitterbrötchen
- countries: DE
- kinds: pastry

## DISH Q2315099
- name: Matbucha
- description: cooked tomato and roasted bell pepper salad
- countries: (none)
- kinds: salad
- ingredients: chili pepper, tomato, Allium sativum, Capsicum annuum
- has Wikipedia article: en

## DISH Q2317875
- name: Basbousa
- description: semolina or farina cake soaked in simple syrup, it was invented in the 12-16 century
- countries: EG
- kinds: dish, cake
- ingredients: semolina
- has Wikipedia article: en

## DISH Q2330776
- name: Stangenei
- other names: {"de": "Stangenei"}
- countries: (none)
- kinds: dish

## DISH Q2330783
- name: Angel cake
- description: British layer cake
- countries: GB
- kinds: butter cake, layer cake
- ingredients: flour
- has Wikipedia article: en

## DISH Q2333140
- name: Oberlander
- description: bread
- countries: (none)
- kinds: bread

## DISH Q2334489
- name: Marron glacé
- other names: {"zh": "糖渍栗子"}
- description: candied chestnut
- countries: IT
- kinds: confectionery
- ingredients: chestnut, sugar
- has Wikipedia article: en, zh

## DISH Q2334705
- name: Boranije
- other names: {"nl": "Boranije"}
- countries: (none)
- kinds: dish

## DISH Q2336063
- name: Soda bread
- other names: {"zh": "愛爾蘭小麥蘇打麵包"}
- description: wheat bread leavened with baking soda
- countries: (none)
- kinds: quick bread
- ingredients: sodium bicarbonate, flour
- has Wikipedia article: en

## DISH Q2338350
- name: Cezerye
- description: semi-gelatinous Turkish confectionery made from caramelised carrots
- countries: TR
- kinds: confectionery
- ingredients: carrot
- has Wikipedia article: en

## DISH Q2338530
- name: Cuban bread
- other names: {"zh": "古巴麵包"}
- description: Cuban-American bread recipe
- countries: US
- kinds: yeast bread
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q2339814
- name: S'more
- other names: {"zh": "烤棉花糖"}
- description: North American dessert
- countries: US
- kinds: dish
- ingredients: graham cracker, marshmallow, chocolate
- has Wikipedia article: en

## DISH Q23417616
- name: Puntas (Mexican dish)
- description: Culinary dish in Mexico
- countries: MX
- kinds: beef dish
- has Wikipedia article: en

## DISH Q23461006
- name: Halloween cake
- other names: {"zh": "萬聖夜蛋糕"}
- description: Cake prepared for holiday
- countries: (none)
- kinds: cake
- has Wikipedia article: en, zh

## DISH Q23461031
- name: Kit Kats in Japan
- other names: {"zh": "日本的奇巧巧克力"}
- description: seasonal and regional flavors of Kit Kat chocolate bars produced in Japan
- countries: (none)
- kinds: Kit Kat
- has Wikipedia article: en

## DISH Q23461185
- name: Organic chocolate
- description: chocolate that is made from certified organic cocoa beans and organic ingredients
- countries: (none)
- kinds: chocolate, functional food, organic food, types of chocolate
- has Wikipedia article: en

## DISH Q23461193
- name: Raw chocolate
- other names: {"zh": "纯巧克力"}
- description: chocolate products not subjected to temperatures above 118F during manufacturing
- countries: (none)
- kinds: chocolate
- has Wikipedia article: en

## DISH Q2346339
- name: Pasztecik szczeciński
- description: Deep-fried stuffed yeast dough from Szczecin, Poland.
- countries: (none)
- kinds: food, pie
- has Wikipedia article: en

## DISH Q234646
- name: Ramen
- other names: {"zh": "日本拉面"}
- description: Japanese noodle soup of Chinese origin
- countries: CN
- cuisines: Japanese cuisine
- kinds: noodle soup, soup
- ingredients: Japanese noodles, Youmian, broth, noodle
- has Wikipedia article: en, zh

## DISH Q2350308
- name: Stippgrütze
- other names: {"zh": "稀饭香肠"}
- description: German barley and sausage dish
- countries: DE
- cuisines: German cuisine
- kinds: kaszanka
- has Wikipedia article: en, zh

## DISH Q2351313
- name: Tarwebrood
- other names: {"nl": "tarwebrood"}
- countries: (none)
- kinds: bread

## DISH Q235169
- name: Miso
- other names: {"zh": "味噌"}
- description: fermented soybean paste
- countries: JP
- cuisines: Japanese cuisine
- kinds: condiment, fermented bean paste, soy food
- ingredients: soy bean, Aspergillus flavus var. oryzae, table salt, soybean
- has Wikipedia article: en, zh

## DISH Q2353020
- name: Rainbow cookie
- other names: {"zh": "彩虹蛋糕"}
- description: Italian-American cookie
- countries: (none)
- kinds: cookie
- ingredients: sponge cake
- has Wikipedia article: en, zh
