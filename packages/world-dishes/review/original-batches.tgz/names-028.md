# Review batch names-028

## DISH Q16706914
- name: Mett
- other names: {"zh": "生豬肉沫"}
- description: preparation of minced raw pork
- countries: DE
- cuisines: German cuisine
- kinds: pork dish, raw meat dish, pork mince, dish
- has Wikipedia article: en, zh

## DISH Q1671107
- name: Mad honey
- description: psychoactive type of honey containing grayanotoxins
- countries: (none)
- kinds: honey, hallucinogen
- ingredients: grayanotoxins
- has Wikipedia article: en

## DISH Q1671818
- name: Involtini siciliana
- countries: (none)
- kinds: dish

## DISH Q16724480
- name: Prawn cake
- other names: {"zh": "虾饼"}
- description: deep-fried dish
- countries: (none)
- kinds: dish

## DISH Q16726108
- name: Pastrami on rye
- description: classic sandwich made famous in the Jewish kosher delicatessens of New York City
- countries: US
- kinds: sandwich, beef dish
- ingredients: rye bread, pastrami, Brassica juncea
- has Wikipedia article: en

## DISH Q16726459
- name: 불낙볶음면
- other names: {"ko": "불낙볶음면"}
- countries: (none)
- kinds: ramyeon, fried ramyeon

## DISH Q167309
- name: Battenberg cake
- other names: {"zh": "巴滕伯格蛋糕"}
- description: sponge cake
- countries: GB
- cuisines: British cuisine
- kinds: sponge cake
- ingredients: marzipan, flour, jam
- has Wikipedia article: en, zh

## DISH Q16735597
- name: Sablé Breton
- other names: {"zh": "布列塔尼酥餅"}
- countries: (none)
- kinds: Sablé
- ingredients: butter
- has Wikipedia article: zh

## DISH Q16738075
- name: Lontong dekem
- description: Indonesian spicy rice cake dish originating from Dekem region in Central Java
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: duck, fried onion, Serundeng, lontong, coconut milk, krupuk, chili pepper
- has Wikipedia article: en

## DISH Q1674567
- name: Kipferlkoch
- other names: {"de": "Kipferlkoch"}
- countries: AT
- kinds: dish

## DISH Q16761486
- name: Hurmašica
- description: pastry
- countries: (none)
- kinds: dessert, pastry

## DISH Q16763507
- name: Feiersténgszalot
- description: Luxembourgish meat salad
- countries: LU
- kinds: salad, beef dish, type of food or dish

## DISH Q16764515
- name: Rieslingspaschtéit
- countries: LU
- kinds: meat pastry

## DISH Q16765345
- name: Mie ayam
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: chicken dish, noodle dish, dish
- ingredients: Indonesian bay leaf, shallot, spinach, garlic, coriander seed, ginger, peppercorn, kecap manis, chicken as food, scallion, Agaricus bisporus, noodle, Curcuma longa, Cymbopogon citratus
- has Wikipedia article: en

## DISH Q167692
- name: Monjayaki
- other names: {"zh": "文字燒"}
- description: Japanese savory pancake
- countries: JP
- cuisines: Japanese cuisine
- kinds: food, teppanyaki
- ingredients: wheat flour, Worcestershire sauce, soy sauce, sauce, water
- has Wikipedia article: en, zh

## DISH Q16773140
- name: Putri salju cake
- description: Indonesian traditional cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: cake, confectionery, dish, human food, type of food or dish
- ingredients: wheat flour, egg yolk, flour, butter, sugar, cheese, milk, margarine
- has Wikipedia article: en

## DISH Q16773515
- name: Bubur ketan hitam
- description: Indonesian dessert
- countries: ID
- cuisines: Indonesian cuisine
- kinds: pudding, porridge, dish, human food, type of food or dish
- ingredients: palm sugar, coconut milk, Pandanus amaryllifolius, glutinous rice, table salt, water
- has Wikipedia article: en

## DISH Q16780
- name: Sicilian orange salad
- description: salad dish of orange slices with olive oil, salt and black pepper
- countries: (none)
- kinds: fruit salad
- ingredients: Citrus sinensis, olive oil, black pepper, orange, table salt
- has Wikipedia article: en

## DISH Q167893
- name: Mayonnaise
- other names: {"zh": "蛋黄酱"}
- description: thick, creamy sauce often used as a condiment, composed primarily of egg yolks and oil
- countries: FR
- kinds: condiment, sauce, emulsion
- ingredients: chicken egg, mustard, oil, vinegar, cooking oil, egg yolk
- has Wikipedia article: en, zh

## DISH Q16797858
- name: Shab Tra
- description: Tibetan savoury dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16800965
- name: Thong yot
- description: Thai egg dessert
- countries: TH
- kinds: dessert, egg dish
- ingredients: egg as food, sugar
- has Wikipedia article: en

## DISH Q16802048
- name: Mouskoutchou
- description: cake from Algeria
- countries: DZ
- kinds: pastry

## DISH Q16814592
- name: Oyster stew
- other names: {"zh": "牡蠣濃湯"}
- description: stew made with oyster
- countries: (none)
- kinds: oyster dish
- ingredients: oyster
- has Wikipedia article: en, zh

## DISH Q16823983
- name: 50/50 burger
- description: Hamburger patty
- countries: US
- kinds: food, hamburger
- has Wikipedia article: en

## DISH Q168263
- name: Tortell
- description: Catalan/Occitan O-shaped pastry
- countries: ES
- kinds: food, king cake, brioche
- ingredients: brioche

## DISH Q16826630
- name: Chocolate-covered prune
- description: Polish confectionery
- countries: (none)
- kinds: sweetmeat
- ingredients: prune, chocolate
- has Wikipedia article: en

## DISH Q16828019
- name: Corn poppy with lamb
- description: dish common in the Aegean coast and islands
- countries: (none)
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q16834113
- name: Dürüm
- description: Turkish cuisine fast food, similar to "wrap"
- countries: TR
- kinds: fast food, food
- ingredients: flatbread
- has Wikipedia article: en

## DISH Q16834380
- name: Aseed
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q16834748
- name: Eggplant papoutsaki
- description: an eggplant dish from the Turkish cuisine
- countries: (none)
- kinds: dish
- ingredients: eggplant
- has Wikipedia article: en

## DISH Q16836241
- name: Grilled chicken
- other names: {"zh": "馬來烤雞"}
- description: chicken dish prepared by grilling
- countries: ID
- kinds: chicken dish
- ingredients: Indonesian bay leaf, kecap, shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, ginger, Aleurites moluccanus, chicken as food, chili pepper, Cymbopogon citratus, table salt, sugar
- has Wikipedia article: en, zh

## DISH Q16836245
- name: Ayam goreng
- description: Indonesian and Malaysian fried chicken
- countries: ID
- cuisines: Indonesian cuisine
- kinds: chicken dish, dish, human food, type of food or dish
- ingredients: Indonesian bay leaf, shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, ginger, Aleurites moluccanus, chicken as food, coconut water, Alpinia galanga, table salt
- has Wikipedia article: en

## DISH Q16836532
- name: Fennel with lamb
- countries: (none)
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q1683716
- name: Lontong
- description: Indonesian traditional rice cake originally from Java island
- countries: ID
- kinds: dish, fast food, rice cake
- ingredients: rice cake, banana leaf, cooked rice, water
- has Wikipedia article: en

## DISH Q16837973
- name: Funeral biscuit
- description: type of biscuit traditionally served at funerals in England and North America
- countries: (none)
- kinds: biscuit, tradition
- has Wikipedia article: en

## DISH Q16839272
- name: Glasswort salad
- description: a salad made commonly in Turkey
- countries: (none)
- kinds: salad
- ingredients: glasswort
- has Wikipedia article: en

## DISH Q16840771
- name: Berwick cockle
- description: British confection
- countries: GB
- kinds: confectionery
- has Wikipedia article: en

## DISH Q16841290
- name: Harput meatballs
- description: Turkish meatball dish
- countries: TR
- kinds: meatball, sour soup
- has Wikipedia article: en

## DISH Q16843658
- name: Shaking beef
- other names: {"zh": "法式牛柳粒"}
- description: French-inspired Vietnamese dish
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: beef dish, lok lak
- ingredients: tomato, peppercorn, cucumber, red onion, soy sauce, beef, Lactuca sativa
- has Wikipedia article: en

## DISH Q16844050
- name: Bogeo
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q16845173
- name: Houska
- description: traditional Czech bread roll
- countries: CZ
- kinds: food, bread roll
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q16847095
- name: Broccoli slaw
- countries: (none)
- kinds: coleslaw
- ingredients: broccoli
- has Wikipedia article: en

## DISH Q1684741
- name: Träsch
- countries: CH
- kinds: schnapps

## DISH Q16847884
- name: Spicy porridge
- description: Indonesian porridge dish from Sambas
- countries: ID
- cuisines: Indonesian cuisine
- kinds: congee, dish, human food, type of food or dish
- ingredients: asparagus bean, shallot, garlic, caraway seeds, coriander seed, peanut, coconut, bamboo shoots, Engraulidae, chili pepper, Sweet potato, Cymbopogon citratus, table salt, rice
- has Wikipedia article: en

## DISH Q1684997
- name: Lemang
- other names: {"zh": "竹筒飯"}
- description: Indonesian and Malaysian traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, sticky rice in bamboo, human food, traditional food, type of food or dish, rice dish
- ingredients: banana leaf, coconut milk, Bambusoideae, glutinous rice, table salt
- has Wikipedia article: en, zh

## DISH Q16850213
- name: Cactus fries
- description: Southwestern United States side dish
- countries: (none)
- kinds: dish, side dish
- ingredients: nopal
- has Wikipedia article: en

## DISH Q16852074
- name: Ka'ak
- description: cake from Arab World
- countries: IR, PK
- kinds: pastry, human food, flatbread
- has Wikipedia article: en

## DISH Q16852388
- name: Kars gravyer cheese
- description: Turkish cheese similar to Emmental although its name suggests Gruyère
- countries: TR
- kinds: cheese
- has Wikipedia article: en

## DISH Q16852506
- name: Kebapche
- description: Bulgarian dish of grilled minced meat with spices
- countries: BG
- kinds: dish
- ingredients: beef, pork
- has Wikipedia article: en

## DISH Q16855480
- name: Ostersuppe
- other names: {"de": "Ostersuppe"}
- countries: (none)
- kinds: dish

## DISH Q16858629
- name: Cencioni
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q16858710
- name: Krofne
- description: Balkan pastry
- countries: (none)
- kinds: doughnut
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q16860933
- name: Placki
- other names: {"fr": "Placki"}
- countries: (none)
- kinds: potato dish

## DISH Q16861024
- name: Rappie pie
- description: Canadian potato dish
- countries: CA
- kinds: potato casserole
- ingredients: potato
- has Wikipedia article: en

## DISH Q16861033
- name: Triple-cooked chips
- description: type of chips or deep-fried potato
- countries: (none)
- kinds: fries
- ingredients: potato
- has Wikipedia article: en

## DISH Q16861199
- name: Fugu chiri
- description: Japanese pufferfish soup
- countries: JP
- kinds: soup, chirinabe
- has Wikipedia article: en

## DISH Q16861482
- name: Potée
- description: preparation historically cooked in an earthenware pot
- countries: FR
- kinds: food, soup, stew
- ingredients: pork
- has Wikipedia article: en

## DISH Q16864399
- name: Georgian bread
- description: Bread from the country of Georgia
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q16868214
- name: Gâteau de Sirop
- description: American cake
- countries: US
- kinds: cake
- ingredients: Cajun cuisine
- has Wikipedia article: en

## DISH Q16868423
- name: Sha Phaley
- description: Tibetan dish made of bread, beef, and vegetables
- countries: (none)
- kinds: food, beef dish
- has Wikipedia article: en

## DISH Q16873575
- name: De-Thuk
- description: Soup in Tibetan cuisine
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q16873700
- name: Lowa Khatsa
- description: Tibetan fried animal lung
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16873967
- name: The Dodol Depok
- description: Indonesian rice cake
- countries: ID
- kinds: Dodol
- ingredients: palm sugar, coconut milk, Pandanus amaryllifolius, glutinous rice
- has Wikipedia article: en

## DISH Q16874222
- name: Boli
- description: roasted plantain dish in Nigeria
- countries: NG
- kinds: food
- ingredients: cooking banana
- has Wikipedia article: en

## DISH Q16874582
- name: Cochonnaille
- description: pork product
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q16874762
- name: Dre-si
- description: Sweet dish in Tibetan cuisine
- countries: CN
- cuisines: Tibetan cuisine
- kinds: dessert, rice dish
- has Wikipedia article: en

## DISH Q1687766
- name: Klitscher
- other names: {"de": "Klitscher"}
- countries: (none)
- kinds: potato dish

## DISH Q16877934
- name: Sayur Babanci
- other names: {"id": "Sayur Babanci"}
- countries: (none)
- kinds: curry, ketupat, gulai, soto, food, dish, type of food or dish
- ingredients: Parkia timoriana, ketupat, Psophocarpus tetragonolobus, edible mushroom, Zingiber zerumbet

## DISH Q16878589
- name: Rice-stuffed artichoke
- description: rice-stuffed artichoke, from the Turkish cuisine
- countries: TR
- kinds: dolma, food
- ingredients: globe artichoke, rice

## DISH Q16878826
- name: Snail satay
- description: East Java food made from snail
- countries: ID
- cuisines: Indonesian cuisine
- kinds: satay, dish, Indonesian cuisine, human food, type of food or dish, food
- ingredients: satay sauce, Indonesian bay leaf, garlic, coriander seed, kecap manis, Aleurites moluccanus, Kaempferia galanga, cooking oil, Averrhoa bilimbi, Allium ascalonicum, Citrus × aurantiifolia, chili pepper, black pepper, Cymbopogon citratus, Achatina fulica, table salt

## DISH Q16879307
- name: Bekasang
- description: fermented food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish
- ingredients: skipjack tuna
- has Wikipedia article: en

## DISH Q16879510
- name: Mie letheg
- description: A noodle dish from Indonesia
- countries: (none)
- kinds: noodle dish
- has Wikipedia article: en

## DISH Q16880089
- name: Nga thalaut paung
- description: Freshwater hilsa fish dish from Burma
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q16880108
- name: Conch soup
- description: Soup eaten in the Florida Keys and the Caribbean
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q16882435
- name: Mực rang muối
- description: Vietnamese five-spice squid dish
- countries: VN
- kinds: food, squid dish
- ingredients: Teuthida
- has Wikipedia article: en

## DISH Q16882443
- name: Frijoles Puercos
- description: Mexican dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16886629
- name: Maquée
- other names: {"es": "Maquée"}
- countries: BE
- kinds: list of Belgian cheeses, cheese
- ingredients: cow's milk

## DISH Q16886847
- name: Hornado
- description: whole roast pig from Ecuadorian cuisine
- countries: ES
- kinds: dish
- has Wikipedia article: en

## DISH Q16887568
- name: Seafood cocktail
- description: food recipe
- countries: (none)
- kinds: seafood dish
- has Wikipedia article: en

## DISH Q16888187
- name: Maboké
- description: dish in Central African Republic
- countries: CF
- kinds: dish
- ingredients: spice, fish
- has Wikipedia article: en

## DISH Q16888499
- name: Frikkadel
- description: South African dish
- countries: ZA
- kinds: meatball, food
- has Wikipedia article: en

## DISH Q16894181
- name: Shottsuru
- description: Japanese fish sauce
- countries: JP
- kinds: fish sauce
- has Wikipedia article: en

## DISH Q1689540
- name: Krokiet
- other names: {"de": "Krokiet"}
- description: dish
- countries: (none)
- kinds: dish

## DISH Q16896963
- name: Five-nuts pastry
- countries: (none)
- kinds: pastry, dish, marry girl cake

## DISH Q1689772
- name: Stuck
- other names: {"de": "Stuck"}
- countries: (none)
- kinds: viennoiserie

## DISH Q16897790
- name: Meat jun
- description: Korean dish
- countries: KR
- cuisines: Korean cuisine
- kinds: jeon, beef dish
- ingredients: marinade, egg wash, soy sauce, beef, flour
- has Wikipedia article: en

## DISH Q16900667
- name: Salbut
- description: Tortilla dish from the Yucatán peninsula
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16901399
- name: Tembleque
- description: coconut dessert pudding from Puerto Rico
- countries: US
- kinds: pudding
- ingredients: coconut milk
- has Wikipedia article: en

## DISH Q1690265
- name: Kugelis
- other names: {"zh": "立陶宛馬鈴薯布丁"}
- description: Lithuanian potato dish
- countries: LT
- kinds: pudding, potato dish
- ingredients: potato
- has Wikipedia article: en, zh

## DISH Q16902896
- name: Platter
- other names: {"zh": "拼盘"}
- description: dish or a meal served on a platter
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q16903587
- name: Manicotti
- description: type of tube pasta
- countries: (none)
- kinds: pasta
- has Wikipedia article: en

## DISH Q16906849
- name: Kuru fasulye
- other names: {"zh": "土耳其牛肉燉豆"}
- description: Turkish bean stew
- countries: TR
- cuisines: Turkish cuisine
- kinds: stew, bean soup
- has Wikipedia article: en

## DISH Q16909052
- name: Lobiani
- description: traditional Georgian dish
- countries: GE
- cuisines: Georgian cuisine
- kinds: food, cake
- ingredients: lobio, Phaseolus, flour, table salt, water
- has Wikipedia article: en

## DISH Q16910416
- name: Pârjoale
- description: Romanian and Moldovan meatballs
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16910822
- name: Moro de guandules
- description: dish from the Dominican Republic
- countries: DO
- kinds: rice and beans
- has Wikipedia article: en

## DISH Q16911615
- name: Palate cleanser
- description: dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16911670
- name: Jhunka
- description: vegetarian traditional dish of India
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16913644
- name: Mi Kocok
- description: Indonesia traditional noodle
- countries: ID
- cuisines: Indonesian cuisine
- kinds: noodle, food, dish, human food, type of food or dish
- ingredients: beef, Cymbopogon citratus, mustard plant, Apium graveolens, Indonesian bay leaf, shallot, garlic, ginger, mung bean sprout, meatball, fried onion, scallion, noodle
- has Wikipedia article: en

## DISH Q1691624
- name: Piernik of Nysa
- countries: (none)
- cuisines: Silesian cuisine, Slavic cuisine
- kinds: viennoiserie

## DISH Q16916781
- name: Shrimp Louie
- description: salad dish from California, United States
- countries: US
- kinds: salad, shrimp dish
- has Wikipedia article: en

## DISH Q16917396
- name: Vaca frita
- description: Cuban steak dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16917687
- name: Sans rival
- description: Filipino layer cake
- countries: PH
- kinds: torte
- ingredients: meringue
- has Wikipedia article: en

## DISH Q16917893
- name: Poutchine au sac
- description: métis bag pudding
- countries: CA
- kinds: pudding
- ingredients: wheat flour, tallow, raisin, milk
- has Wikipedia article: en

## DISH Q16918839
- name: Duff
- description: dessert
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q16926259
- name: Snake soup
- other names: {"zh": "蛇羹"}
- description: Cantonese soup, consisting of the meats of multiple types of snakes, chrysanthemum leaves and spices
- countries: CN
- kinds: soup
- has Wikipedia article: en, zh

## DISH Q16926266
- name: Tong Sui Shop
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q16926310
- name: Chutney de bacalhau
- description: Luso-Indian and Macanese dish
- countries: (none)
- kinds: chutney, fish dish
- ingredients: bacalhau

## DISH Q16927617
- name: Oysters Bienville
- description: Seafood recipe
- countries: (none)
- cuisines: Louisiana Creole cuisine
- kinds: oyster dish
- ingredients: shrimp, Parmesan, oyster, mushroom
- has Wikipedia article: en

## DISH Q16929887
- name: Fläsklägg med rotmos
- description: Swedish pork dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16930441
- name: Şakşuka
- description: Turkish meze made with eggplant and other veggies fried in olive oil and covered with a tomato-garlic sauce
- countries: TR
- kinds: salad, meze
- ingredients: garlic, tomato, eggplant
- has Wikipedia article: en

## DISH Q16930486
- name: Gōyā chanpurū
- countries: (none)
- kinds: chanpurū
- ingredients: bitter melon
- has Wikipedia article: en

## DISH Q16931986
- name: Şöbiyet
- description: a yufka-based dessert from the Turkish cuisine
- countries: TR
- kinds: dish, dessert
- ingredients: phyllo
- has Wikipedia article: en

## DISH Q16933312
- name: Stuffed squid
- description: squid dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16934063
- name: Mirik meatball
- description: Turkish Food
- countries: TR
- kinds: type of food or dish, dumpling, meatball
- has Wikipedia article: en

## DISH Q16934214
- name: Sheep's sorrel soup
- countries: (none)
- kinds: soup
- ingredients: water
- has Wikipedia article: en

## DISH Q16934667
- name: Zeroa
- description: shankbone on Passover Seder plate
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16934675
- name: Ayam penyet
- description: Indonesian fried chicken tendered using pestle
- countries: ID
- kinds: food, fried chicken
- ingredients: Indonesian bay leaf, shallot, Kaffir Lime Leaf, garlic, tomato, ginger, shrimp paste, chicken as food, chili pepper, Cymbopogon citratus, table salt, sugar
- has Wikipedia article: en

## DISH Q16935343
- name: Modjeska
- description: caramel and marshmallow candy named for Helena Modjeska
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q16935381
- name: Thiakry
- other names: {"zh": "查基里"}
- description: West African sweet millet couscous dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16937065
- name: Kashk e badamjan
- description: Persian eggplant dish
- countries: IR
- kinds: dish, sauce, appetizer, eggplant dish
- ingredients: eggplant, kurt, olive oil, onion, Allium sativum
- has Wikipedia article: en

## DISH Q16938296
- name: Lufu
- other names: {"zh": "卤腐"}
- description: type of fermented bean curd
- countries: CN
- kinds: food, fermented food, soy food
- ingredients: soy bean
- has Wikipedia article: en

## DISH Q16941232
- name: Steak de Burgo
- description: beef dish from the Midwestern United States
- countries: US
- kinds: beef dish
- ingredients: beef tenderloin
- has Wikipedia article: en

## DISH Q16943229
- name: Salprieta
- description: Ecuadorian side dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16943314
- name: Scali bread
- description: braided Italian bread from Boston
- countries: IT, US
- kinds: food, bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q16943688
- name: Pio Quinto
- other names: {"zh": "Pio Quinto"}
- description: desert in Nicaragua
- countries: NI
- kinds: dessert
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q16945693
- name: Lunggoi Katsa
- description: Stewed sheep's head
- countries: (none)
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q16946787
- name: Majjige huli
- description: Vegetable curry from Karnataka
- countries: IN
- cuisines: Karnataka cuisine
- kinds: Indian curry, vegetable curry
- ingredients: curd, vegetable
- has Wikipedia article: en

## DISH Q16947964
- name: Lamb's fry
- description: lamb offal served as food
- countries: (none)
- kinds: offal, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q16949628
- name: Coconut drop
- description: Jamaican cuisine dessert
- countries: (none)
- kinds: dessert
- ingredients: coconut
- has Wikipedia article: en

## DISH Q16951552
- name: Stuffed mallow
- description: Stuffed leaves dish made from malva
- countries: TR
- cuisines: Turkish people
- kinds: dish
- has Wikipedia article: en

## DISH Q16952139
- name: Cougar Gold cheese
- description: canned Cheddar-style cheese made in Washington state
- countries: US
- kinds: cheese, dairy product
- has Wikipedia article: en

## DISH Q16952446
- name: Crab puff
- description: ball of crab meat deep-fried in batter
- countries: US
- kinds: food, crab dish
- ingredients: crab meat
- has Wikipedia article: en

## DISH Q16956515
- name: Kaledo
- description: Indonesian dish
- countries: ID
- kinds: food, soup
- ingredients: cow's trotters, bone marrow
- has Wikipedia article: en

## DISH Q16957893
- name: Choc ice
- description: Frozen dessert
- countries: (none)
- kinds: food, frozen dessert
- ingredients: ice cream
- has Wikipedia article: en

## DISH Q16961496
- name: Maxwell Street Polish
- description: Sausage from Chicago
- countries: US
- kinds: food, sandwich
- ingredients: bun
- has Wikipedia article: en

## DISH Q16962929
- name: Patoleo
- description: sweet food from Goa
- countries: IN
- kinds: sweet dish, rice
- ingredients: coconut, jaggery, rice
- has Wikipedia article: en

## DISH Q16963428
- name: Sulu köfte
- description: Turkish "köfte" dish with its own soup or broth, or better a Turkish stew with meatballs
- countries: TR
- kinds: dish, food, Köftes in the Turkish cuisine
- ingredients: minced meat
- has Wikipedia article: en

## DISH Q16963468
- name: Mu kratha
- other names: {"zh": "泰式火锅"}
- description: Thai Table-cooked dish
- countries: TH
- kinds: pork dish
- has Wikipedia article: en, zh

## DISH Q16965840
- name: Clear toy candy
- description: traditional variety of boiled sweet (hard candy), often red green or yellow in colour, that is made in molds using sugar, cream of tartar or corn syrup and pure water as ingredients
- countries: (none)
- kinds: hard candy
- ingredients: corn syrup, dipotassium L-tartrate, sugar, water
- has Wikipedia article: en

## DISH Q16966417
- name: Wedding cabbage
- description: traditional Serbian dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16969131
- name: Cochinito de Piloncillo
- description: traditional Mexican pig-shaped pastry
- countries: MX
- kinds: dessert, Mexican bread
- ingredients: panela, sodium bicarbonate, egg as food, flour, butter, Pimpinella anisum, cinnamon, water
- has Wikipedia article: en

## DISH Q16969652
- name: Shrimp and grits
- description: dish
- countries: US
- kinds: shrimp dish
- has Wikipedia article: en

## DISH Q16971704
- name: Bookbinder Soup
- description: type of seafood soup originating in the USA
- countries: US
- kinds: food, soup
- has Wikipedia article: en

## DISH Q16973089
- name: Cueritos
- description: pig skin, usually pickled in vinegar, and can be made with a spicy sauce
- countries: MX
- kinds: pork dish
- has Wikipedia article: en

## DISH Q16973768
- name: Walnut and coffee cake
- description: spongecake made with coffee and walnuts
- countries: GB
- kinds: cake
- ingredients: sponge cake
- has Wikipedia article: en

## DISH Q16975807
- name: Cheese slaw
- description: Salad
- countries: AU
- kinds: coleslaw
- ingredients: grated cheese
- has Wikipedia article: en

## DISH Q16975890
- name: Es buah
- description: Indonesian iced fruit cocktail dessert
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, dessert
- ingredients: Pachyrhizus erosus, Pandanus amaryllifolius, Cucumis melo, Carica papaya, cinnamon, sugar, Ananas comosus
- has Wikipedia article: en

## DISH Q16976976
- name: Haitian patty
- description: baked puff pastry
- countries: HT
- cuisines: Haitian cuisine
- kinds: pastry
- ingredients: puff pastry
- has Wikipedia article: en

## DISH Q16979517
- name: Umai
- description: Dish of sliced raw fish with vegetables
- countries: MY
- kinds: raw fish dish
- ingredients: fish
- has Wikipedia article: en

## DISH Q16979788
- name: Musk stick
- description: type of confection
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q16982762
- name: Traditional Grimsby smoked fish
- description: regionally processed fish food products from the British fishing town of Grimsby, England
- countries: (none)
- kinds: smoked fish
- has Wikipedia article: en

## DISH Q16983167
- name: Hamburg steak
- other names: {"zh": "漢堡排"}
- description: dish consisting of a patty of ground beef
- countries: DE
- cuisines: cuisine of the United States, German cuisine
- kinds: patty, beef dish
- ingredients: beefsteak, beef
- has Wikipedia article: en, zh

## DISH Q16984727
- name: Sno-ball
- description: shaved-ice dessert
- countries: US
- kinds: frozen dessert, food
- ingredients: water
- has Wikipedia article: en

## DISH Q16984961
- name: Hot chicken sandwich
- description: type of chicken sandwich covered with gravy eaten with utensils, popular in Quebec
- countries: CA
- kinds: meat sandwich
- has Wikipedia article: en

## DISH Q16997205
- name: Maids of honour tart
- other names: {"zh": "荣誉女仆蛋挞"}
- description: traditional English baked tart
- countries: GB
- cuisines: English cuisine
- kinds: sweet tart
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q16997256
- name: Malvern pudding
- description: Fruit and custard pudding
- countries: GB
- kinds: pudding
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q16999470
- name: Shizuoka oden
- description: food in Japan
- countries: JP
- cuisines: Japanese cuisine
- kinds: oden, food
- has Wikipedia article: en

## DISH Q16999502
- name: Mami soup
- description: type of noodle soup
- countries: PH
- kinds: soup, dish
- ingredients: noodle
- has Wikipedia article: en

## DISH Q1699954
- name: Käsetaler
- other names: {"de": "Käsetaler"}
- countries: (none)
- kinds: viennoiserie

## DISH Q16999914
- name: Jenny Lind Soup
- description: Type of soup
- countries: (none)
- kinds: food, soup
- ingredients: Brassica napus subsp. rapifera
- has Wikipedia article: en

## DISH Q17000111
- name: Khanom thuai
- description: traditional Thai dessert
- countries: TH
- cuisines: Thai cuisine
- kinds: dish
- ingredients: rice flour, coconut milk, table salt, sugar
- has Wikipedia article: en

## DISH Q170014
- name: Wedang secang
- other names: {"id": "Wedang secang"}
- countries: (none)
- kinds: dish

## DISH Q17002268
- name: Berner Haselnusslebkuchen
- description: Swiss gingerbread specialty
- countries: CH
- kinds: lebkuchen
- ingredients: hazelnut
- has Wikipedia article: en

## DISH Q170037
- name: Balsamic vinegar
- other names: {"zh": "意大利香醋"}
- description: type of vinegar
- countries: IT
- kinds: condiment, vinegar
- has Wikipedia article: en, zh

## DISH Q17003794
- name: Amiedi
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q17003967
- name: Guthuk
- other names: {"zh": "古突"}
- description: Tibetan noodle soup
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en, zh

## DISH Q170049
- name: Reggianito
- description: Argentine cheese
- countries: AR
- kinds: cheese
- has Wikipedia article: en

## DISH Q17005230
- name: Palm nut soup
- description: soup made from palm fruit
- countries: NG
- cuisines: Cameroonian cuisine, Nigerian cuisine
- kinds: fruit soup, dish, human food
- ingredients: Palm fruit, fresh fish, crayfish, chicken as food, seasoning, table salt
- has Wikipedia article: en

## DISH Q17005444
- name: Imqaret
- description: Maltese date pastry
- countries: MT
- cuisines: Maltese cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q17006531
- name: Cherry kebab
- description: kebab made with minced lamb and cherry
- countries: (none)
- kinds: meat, dish
- ingredients: kebab, cherry
- has Wikipedia article: en

## DISH Q17006976
- name: Shanghai pork chop
- other names: {"zh": "上海炸猪排"}
- countries: (none)
- kinds: pork chop
- has Wikipedia article: zh

## DISH Q17008466
- name: Pea flour cake
- other names: {"zh": "豌豆黄"}
- countries: CN
- kinds: dessert
- has Wikipedia article: zh

## DISH Q17009101
- name: Lung fung soup
- description: soup made with snake, chicken, and vegetables
- countries: CN
- kinds: soup, dish
- ingredients: seafood
- has Wikipedia article: en

## DISH Q17009305
- name: 鞋底烧饼
- countries: CN
- kinds: snack
- has Wikipedia article: zh

## DISH Q17009352
- name: Maltese bread
- description: sourdough bread from Malta
- countries: MT
- cuisines: Maltese cuisine
- kinds: food, bread
- has Wikipedia article: en

## DISH Q17009401
- name: Pork mooncake
- other names: {"zh": "鲜肉月饼"}
- countries: CN
- kinds: Suzhou-style mooncake
- has Wikipedia article: zh

## DISH Q17010544
- name: Burmese salad
- description: category of dishes in Burmese cuisine, made of cooked and raw ingredients mixed by hand
- countries: MM
- cuisines: Burmese cuisine
- kinds: salad
- has Wikipedia article: en

## DISH Q17011735
- name: Pearl meatballs
- other names: {"zh": "珍珠肉丸"}
- description: Steamed pork meatballs in sticky rice
- countries: CN
- kinds: meat dish
- has Wikipedia article: zh

## DISH Q17012850
- name: Apple cider cookie
- description: cookie made with apple cider
- countries: (none)
- kinds: cookie
- ingredients: apple cider
- has Wikipedia article: en

## DISH Q17013971
- name: Tiger penis soup
- other names: {"zh": "虎鞭汤"}
- description: soup made from a tiger's penis
- countries: (none)
- kinds: food, soup
- ingredients: tiger penis
- has Wikipedia article: en

## DISH Q17016362
- name: Sabich salad
- countries: IL
- kinds: salad
- ingredients: eggplant
- has Wikipedia article: en

## DISH Q17017114
- name: Samay Baji
- description: Newar dish of Nepal
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q17017948
- name: Schmoo torte
- description: Canadian dessert
- countries: CA
- kinds: dessert
- has Wikipedia article: en

## DISH Q17018846
- name: Potted shrimps
- description: traditional Lancashire dish of brown shrimp in nutmeg-flavoured butter, which has set in a small pot, the butter acting as a preservative; traditionally eaten with bread.
- countries: GB
- cuisines: British cuisine
- kinds: shrimp dish
- ingredients: Crangon crangon
- has Wikipedia article: en

## DISH Q17019149
- name: Eight treasure rice
- other names: {"zh": "八宝饭"}
- description: Chinese rice dish
- countries: CN
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q17020260
- name: Peanut ice cream roll
- other names: {"zh": "花生卷加冰淇淋"}
- description: traditional Taiwanese vegetarian dessert
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: human food
- has Wikipedia article: en, zh

## DISH Q17022289
- name: Staffordshire oatcake
- description: savoury pancake
- countries: GB
- kinds: food, pancake
- ingredients: oatmeal
- has Wikipedia article: en

## DISH Q17023137
- name: Sugar painting
- other names: {"zh": "糖畫"}
- description: form of Chinese folk art
- countries: CN
- kinds: art of sculpture, candy, profession
- ingredients: Chinese culture
- has Wikipedia article: en, zh

## DISH Q17023464
- name: Shredded eel in sizzling oil
- other names: {"zh": "响油鳝糊"}
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q17023518
- name: Tsoureki
- description: pastry known under various names in the Balkans
- countries: AM, GR, TR
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q17026363
- name: Pixian doubanjiang
- other names: {"zh": "郫县豆瓣"}
- description: Chinese cuisine
- countries: CN
- kinds: doubanjiang, Sichuan cuisine, Chinese cuisine, type of food or dish
- has Wikipedia article: zh

## DISH Q17026621
- name: Guodanpi
- other names: {"zh": "果丹皮"}
- description: fruit leather food
- countries: CN
- kinds: snack, candied fruit, type of food or dish
- ingredients: Crataegus pinnatifida, sugar
- has Wikipedia article: zh

## DISH Q17027457
- name: Brown stew chicken
- description: Caribbean dish
- countries: AG, BB, DM, GD, JM, LC, TT
- kinds: stew, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q17027492
- name: Clorot
- description: Indonesian traditional snack
- countries: BN
- kinds: Kuih
- ingredients: rice flour, coconut milk
- has Wikipedia article: en

## DISH Q17028021
- name: Jinan roast duck
- other names: {"zh": "济南烤鸭"}
- countries: (none)
- kinds: roast duck
- has Wikipedia article: zh

## DISH Q17029057
- name: Youbing
- other names: {"zh": "油饼"}
- description: fried dough flatbread of China
- countries: CN
- kinds: flatbread
- has Wikipedia article: zh

## DISH Q17029217
- name: Hualien Sweet Potato
- other names: {"zh": "花蓮薯"}
- description: dessert from Hualien, Taiwan
- countries: TW
- kinds: confectionery
- has Wikipedia article: zh

## DISH Q17030355
- name: Garlic chives pocket
- other names: {"zh": "韭菜盒"}
- description: type of Chinese savory pocket pie
- countries: (none)
- kinds: dish, stuffed pasta, type of food or dish
- ingredients: Allium tuberosum, flour
- has Wikipedia article: en, zh

## DISH Q17031556
- name: 藥燉土虱
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q17031582
- name: Salty biscuit
- other names: {"zh": "澎湖鹹餅"}
- description: Taiwanese salty biscuit
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: cookie
- has Wikipedia article: en, zh

## DISH Q17031594
- name: Belly button pastry
- other names: {"zh": "肚臍餅"}
- description: traditional Hakka pastry from Miaoli, Taiwan
- countries: TW
- kinds: pastry
- has Wikipedia article: en, zh

## DISH Q17031604
- name: Spiral Cookies
- other names: {"zh": "螺仔餅"}
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q17031681
- name: Ersi
- other names: {"zh": "饵丝"}
- countries: CN
- kinds: Chinese noodles
- has Wikipedia article: zh

## DISH Q17032101
- name: Baba
- other names: {"zh": "粑粑"}
- description: type of bread made by the Naxi people of Yunnan, China
- countries: (none)
- kinds: bread
- has Wikipedia article: en, zh

## DISH Q17032204
- name: Ko-cha
- other names: {"zh": "糕渣"}
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q1703243
- name: Kreplach
- other names: {"zh": "犹太馄饨"}
- description: dumplings of Jewish cuisine
- countries: (none)
- kinds: stuffed pasta
- has Wikipedia article: en, zh

## DISH Q17033067
- name: 陆记烫面炸糕
- countries: CN
- kinds: snack
- has Wikipedia article: zh

## DISH Q1703334
- name: Schaumbrot
- other names: {"de": "Schaumbrot"}
- countries: (none)
- kinds: fish dish

## DISH Q17033393
- name: Thukpa bhatuk
- description: Tibetan cuisine noodle soup
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q17034005
- name: Fish Hiding in Mutton
- other names: {"zh": "羊方藏鱼"}
- description: Chinese dish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q17034032
- name: 羊肉羹
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q17034242
- name: Wantuo
- other names: {"zh": "碗托"}
- description: buckwheat-based food in North China
- countries: CN
- kinds: appetizer
- has Wikipedia article: zh

## DISH Q1703431
- name: Korovai
- other names: {"zh": "科罗伐叶面包"}
- description: wedding bread traditional to East Slavic cuisines
- countries: (none)
- cuisines: Slavic cuisine
- kinds: bread, baked good
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q17034623
- name: Dengzhangao
- other names: {"zh": "灯盏糕"}
- description: Chinese cake
- countries: CN
- kinds: snack
- has Wikipedia article: zh

## DISH Q1703515
- name: Pie and mash
- description: traditional London working-class food consisting of a minced beef pie, mashed potato and parsley sauce
- countries: GB
- cuisines: English cuisine
- kinds: food, potato dish
- has Wikipedia article: en

## DISH Q17035169
- name: 炸蚵仔
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q17035180
- name: 炸𩵚魠魚
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q17035434
- name: 烤全羊
- countries: CN
- kinds: meat dish
- has Wikipedia article: zh

## DISH Q17035461
- name: 烤鳥蛋
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q17035616
- name: Cong zhua bing
- other names: {"zh": "蔥抓餅"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish
- has Wikipedia article: zh

## DISH Q17035622
- name: 蔥餅
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q1703574
- name: Pinnekjøtt
- other names: {"zh": "挪威风干羊肋排"}
- description: traditional Norwegian Christmas lamb dish
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en, zh

## DISH Q17035779
- name: Stuffed dace
- other names: {"zh": "煎釀鯪魚"}
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q17035821
- name: Ginger duck
- other names: {"zh": "姜母鸭"}
- description: duck dish originated from Quanzhou and surroundings
- countries: (none)
- kinds: dish, duck dish
- has Wikipedia article: zh

## DISH Q17035957
- name: Sio-chiu-le
- other names: {"zh": "燒酒螺"}
- description: Batillaria zonalis cuisine in Taiwan
- countries: (none)
- kinds: dish
- ingredients: Batillaria zonalis
- has Wikipedia article: zh

## DISH Q17037938
- name: Nargesi Kebab
- description: South Asian meat dish with an egg in the middle
- countries: (none)
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q1703796
- name: Hákarl
- other names: {"zh": "冰島發酵鯊魚肉"}
- description: national dish of Iceland consisting of fermented shark
- countries: IS
- cuisines: Icelandic cuisine
- kinds: dish, fermented fish, fish dish
- ingredients: shark as food
- has Wikipedia article: en, zh

## DISH Q17038368
- name: Fried noodle with supreme soy sauce
- other names: {"zh": "豉油皇炒麵"}
- countries: CN
- kinds: fried noodle, Chinese noodles
- has Wikipedia article: zh

## DISH Q17038483
- name: Steak and oyster pie
- description: victorian English pie dish
- countries: (none)
- kinds: meat pie, oyster dish
- ingredients: beef, oyster
- has Wikipedia article: en

## DISH Q17038642
- name: Rice with lard
- other names: {"zh": "豬油拌飯"}
- countries: (none)
- kinds: rice dish
- has Wikipedia article: zh

## DISH Q17039515
- name: 炭烤三明治
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q17040557
- name: Manggong Cake
- other names: {"zh": "盲公餅"}
- description: Chinese dessert
- countries: CN
- kinds: cake
- has Wikipedia article: en, zh

## DISH Q17040892
- name: Sticky rice meatballs
- other names: {"zh": "糯米丸子"}
- description: meatballs coated with sticky rice
- countries: CN
- kinds: meatball
- has Wikipedia article: en, zh

## DISH Q17040910
- name: Guokui
- other names: {"zh": "鍋盔"}
- description: Chinese flatbread
- countries: CN
- cuisines: Shaanxi cuisine
- kinds: flatbread
- has Wikipedia article: en, zh

## DISH Q17044047
- name: Plantain soup
- description: soup made of plantains, eaten in various cultures
- countries: (none)
- kinds: food, soup
- ingredients: cooking banana
- has Wikipedia article: en

## DISH Q17044517
- name: Utan
- description: Filipino vegetable soup
- countries: PH
- kinds: soup
- has Wikipedia article: en

## DISH Q17047960
- name: Maraca pie
- description: pie dessert originating from Florida
- countries: US
- kinds: food, pie
- ingredients: rice pudding, banana
- has Wikipedia article: en

## DISH Q17048447
- name: Yellow rice
- description: rice dish made yellow with spices
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q170486
- name: Ham
- other names: {"zh": "火腿"}
- description: processed pork leg foodstuff
- countries: (none)
- kinds: food ingredient, cold cut, pork, pork dish, whole-muscle cut
- ingredients: pork thigh
- has Wikipedia article: en, zh

## DISH Q17048976
- name: Crab ice cream
- description: ice cream made with crabmeat
- countries: (none)
- kinds: ice cream, crab dish
- ingredients: Brachyura
- has Wikipedia article: en

## DISH Q17049500
- name: Colaci
- countries: RO
- kinds: bread, food
- has Wikipedia article: en

## DISH Q17049518
- name: Crab in oyster sauce
- description: Chinese-Indonesian dish
- countries: CN
- kinds: food, crab dish, oyster dish
- ingredients: Brachyura
- has Wikipedia article: en

## DISH Q17049555
- name: Chicken porridge
- description: Indonesian porridge
- countries: ID
- kinds: dish, street food, jajan pasar, chicken dish, food
- ingredients: shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, ginger, Aleurites moluccanus, chicken as food, krupuk, Alpinia galanga, egg as food, Cymbopogon citratus, Apium graveolens, rice
- has Wikipedia article: en

## DISH Q1704982
- name: Qurabiya
- description: shortbread-like cookies found in the cuisines of Greece and Tatarstan
- countries: (none)
- kinds: cookie, pastry, shortbread
- ingredients: almond meal
- has Wikipedia article: en

## DISH Q17050214
- name: Fish soup bee hoon
- description: Singaporean and Indonesian soup dish
- countries: SG
- kinds: food, soup, fish soup, seafood dish
- ingredients: fish as food
- has Wikipedia article: en

## DISH Q17050490
- name: Empal gepuk
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: beef dish, dish
- ingredients: Indonesian bay leaf, shallot, garlic, coriander seed, condiment, Aleurites moluccanus, coconut milk, Alpinia galanga, beef, Cymbopogon citratus, table salt, sugar
- has Wikipedia article: en

## DISH Q17050599
- name: Israeli eggplant salad
- countries: IL
- kinds: salad
- ingredients: eggplant
- has Wikipedia article: en

## DISH Q17050727
- name: Kołacz
- description: Polish cake
- countries: PL
- kinds: food, pastry
- ingredients: dough
- has Wikipedia article: en

## DISH Q17051280
- name: Dalia seera
- description: Indian sweet dish prepared with wheat
- countries: (none)
- kinds: sweet dish

## DISH Q17051646
- name: P'tcha
- description: Ashkenazi Jewish aspic
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q17051739
- name: Pfeffernusse
- other names: {"zh": "薑堅果"}
- description: spice cookies
- countries: (none)
- kinds: cookie
- ingredients: black pepper, flour
- has Wikipedia article: en

## DISH Q17052123
- name: Schnecken
- description: type of sweet bun of German Jewish origin
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q17052769
- name: Noodle with tomato egg sauce
- description: noodles with tomato egg sauce
- countries: (none)
- kinds: dish
- ingredients: tomato
- has Wikipedia article: en

## DISH Q17052971
- name: Pig fallopian tubes
- description: Malaysian stir-fry dish
- countries: SG
- kinds: soup
- has Wikipedia article: en

## DISH Q17053386
- name: Presunto
- description: Portuguese dry-cured ham
- countries: PT
- kinds: raw ham, bacon
- has Wikipedia article: en

## DISH Q17053542
- name: Sambal stingray
- description: seafood dish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q17053738
- name: Noodles stirred
- description: Indonesian chicken noodle food
- countries: ID
- kinds: boiling, food, main course
- ingredients: chicken as food, coconut milk, noodle, egg as food, Brassica oleracea var. capitata, table salt, sugar, shallot, garlic, mung bean sprout
- has Wikipedia article: en

## DISH Q17054040
- name: Nasi padang
- description: Indonesian cuisine originating from West Sumatra
- countries: ID
- cuisines: Indonesian cuisine, Padang cuisine
- kinds: dish
- ingredients: rice, Kari, chicken as food, Alpinia galanga, Cymbopogon citratus
- has Wikipedia article: en

## DISH Q17054148
- name: Gulha
- description: Tuna and coconut dumplings
- countries: MV
- kinds: fish dish, tuna dish
- ingredients: flour
- has Wikipedia article: en

## DISH Q17055540
- name: Bandeng satay
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: satay, fish dish, food, type of food or dish
- ingredients: shallot, turmeric rhizome, garlic, caraway seeds, coriander seed, ginger, banana leaf, coconut, skewer, coconut milk, Chanos chanos, Alpinia galanga, chili pepper, egg as food, Tamarindus indica, oil, spice, table salt
- has Wikipedia article: en

## DISH Q17056750
- name: Telur pindang
- description: Indonesian hard boiled eggs
- countries: ID
- kinds: food, egg dish
- ingredients: Indonesian bay leaf, kecap, shallot, Kaffir Lime Leaf, garlic, chicken egg, palm sugar, egg as food, Cymbopogon citratus, table salt, tea
- has Wikipedia article: en

## DISH Q17059019
- name: Tshài-póo-nn̄g
- other names: {"zh": "菜脯蛋"}
- description: dried radish omelet
- countries: CN, TW
- kinds: omelette
- ingredients: preserved radish, egg as food
- has Wikipedia article: zh

## DISH Q17061273
- name: Kachumber
- description: Indian salad dish
- countries: IN
- cuisines: Indian cuisine
- kinds: salad, human food
- ingredients: onion, tomato, Cucumis sativus
- has Wikipedia article: en

## DISH Q17063016
- name: Jjamppong
- other names: {"zh": "炒码面"}
- description: Korean Chinese noodle soup
- countries: KR
- cuisines: Korean Chinese cuisine
- kinds: Korean noodles, noodle soup
- has Wikipedia article: en, zh

## DISH Q17063384
- name: Nam kaeng hua chai thao
- description: Thai-Chinese radish soup
- countries: (none)
- kinds: food, soup
- has Wikipedia article: en

## DISH Q17063709
- name: Nam tok mu
- description: Thai pork salad
- countries: (none)
- kinds: nam tok, salad
- ingredients: shallot, lime juice, chili powder, pork, rice
- has Wikipedia article: en

## DISH Q17063877
- name: Bagoong monamon
- description: philppine food ingredient made by fermenting salted anchovies
- countries: (none)
- kinds: fish sauce
- has Wikipedia article: en

## DISH Q17064154
- name: Bionico
- description: Mexican dessert
- countries: MX
- kinds: fruit salad
- has Wikipedia article: en

## DISH Q17064469
- name: Čvarci
- description: Southeastern European pork rind
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q17064971
- name: Cong you ji
- other names: {"zh": "霸王雞"}
- description: Chinese dish of chicken
- countries: CN
- cuisines: Hakka cuisine
- kinds: chicken dish
- has Wikipedia article: zh

## DISH Q17065342
- name: Chicken Chettinad
- description: chicken curry dish from South India
- countries: IN
- cuisines: Indian cuisine
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q17065965
- name: 當歸鴨
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q17066200
- name: 软兜长鱼
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q17067155
- name: Balkánský sýr
- description: type of white brined cheese produced in Czech Republic and Slovakia
- countries: CZ, SK
- kinds: brined cheese, cheese
- has Wikipedia article: en

## DISH Q17067218
- name: Cockentrice
- description: Pig and chicken dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q17068380
- name: Labanga latika
- description: traditional Indian sweet
- countries: (none)
- kinds: snack
- has Wikipedia article: en

## DISH Q17068746
- name: Le petit pâté de Pézenas
- countries: FR
- kinds: culinary speciality
- has Wikipedia article: en

## DISH Q17071807
- name: Molagoottal
- description: South Indian dish
- countries: IN
- kinds: food, soup
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q17072135
- name: Charlotte's Web
- description: strain of medical marijuana
- countries: US
- kinds: light cannabis, strain of cannabis
- has Wikipedia article: en

## DISH Q17072386
- name: Chimole
- other names: {"zh": "奇莫利"}
- description: soup
- countries: BZ
- kinds: dish
- has Wikipedia article: en

## DISH Q17073167
- name: Huachinango a la Veracruzana
- description: fish dish from Veracruz, Mexico
- countries: MX
- kinds: fish dish
- ingredients: Red snapper
- has Wikipedia article: en

## DISH Q1707616
- name: Biber salçası
- description: bell pepper paste
- countries: TR
- kinds: sweet pepper paste, food, spread, salça
- ingredients: chili pepper

## DISH Q17077846
- name: Maja blanca
- description: Filipino dessert
- countries: PH
- kinds: coconut bar
- ingredients: coconut milk
- has Wikipedia article: en

## DISH Q17079448
- name: Keshi yena
- description: Aruban and Curaçaoan main course dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q17081227
- name: Pachadi
- description: South Indian pickle side dish
- countries: (none)
- kinds: Indian curry
- has Wikipedia article: en

## DISH Q17081569
- name: Shorwa
- description: traditional Afghan soup
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q17082973
- name: Marzipan pig
- description: marzipan candy in the shape of a pig
- countries: (none)
- kinds: marzipan
- ingredients: marzipan
- has Wikipedia article: en

## DISH Q17083201
- name: New Haven-style pizza
- description: style coal-fired pizza originating in New Haven, CT, US, with thin, oblong crust, characteristic charring, chewy texture, and limited use of melting cheeses, sometimes topped with clams
- countries: US
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q17083249
- name: Olluquito
- description: Peruvian stew
- countries: PE
- kinds: dish
- ingredients: Ullucus tuberosus, Charqui
- has Wikipedia article: en

## DISH Q17084248
- name: Pastelón
- description: Puerto Rican casserole
- countries: PR
- kinds: dish
- has Wikipedia article: en

## DISH Q17085540
- name: Pichi-pichi
- description: Filipino cassava dessert
- countries: PH
- kinds: dessert
- ingredients: grated coconut, lye, cassava, sugar
- has Wikipedia article: en

## DISH Q17088676
- name: Sorbetes
- description: Filipino ice cream, made from either milk or coconut milk, usually served with small wafer or sugar cones or bread buns
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q17090617
- name: Tinga
- description: Mexican chicken dish
- countries: MX
- kinds: chicken dish, beef dish
- has Wikipedia article: en

## DISH Q17090951
- name: Pastrama
- description: Romanian cured meat
- countries: (none)
- kinds: raw meat dish
- has Wikipedia article: en

## DISH Q1709220
- name: Blondie
- other names: {"zh": "布朗迪"}
- description: rich, sweet dessert bar
- countries: US
- kinds: dessert bar
- ingredients: flour, vanilla, egg as food, butter, baking powder, sugar
- has Wikipedia article: en

## DISH Q17092221
- name: Tameletjie
- description: homemade toffee confection
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q17099188
- name: Rosół
- description: traditional Polish meat soup
- countries: PL
- cuisines: Polish cuisine
- kinds: food, soup
- ingredients: chicken
- has Wikipedia article: en

## DISH Q17101058
- name: Orzotto
- description: Italian dish made with pearl barley
- countries: IT
- kinds: dish
- ingredients: pearl barley
- has Wikipedia article: en

## DISH Q17102940
- name: Tarta de seso
- description: beef brain pie in Colombian cuisine
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q17103487
- name: Mjukkaka
- description: Swedish flatbread
- countries: SE
- kinds: food, flatbread
- ingredients: rye flour, baker's yeast, table salt, sugar
- has Wikipedia article: en
