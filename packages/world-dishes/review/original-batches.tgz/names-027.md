# Review batch names-027

## DISH Q16051009
- name: بژی برساق
- other names: {"fa": "بژی برساق"}
- countries: (none)
- kinds: pastry

## DISH Q16051229
- name: سنگاسین حلوا
- other names: {"fa": "سنگاسین حلوا"}
- countries: (none)
- kinds: pastry

## DISH Q16051532
- name: حلوا پسکی
- other names: {"fa": "حلوا پسکی"}
- countries: (none)
- kinds: pastry

## DISH Q16051547
- name: حلوای انگشتپیچ
- other names: {"fa": "حلوای انگشتپیچ"}
- countries: (none)
- kinds: pastry

## DISH Q16051557
- name: حلوای بندووا
- other names: {"fa": "حلوای بندووا"}
- countries: (none)
- kinds: pastry

## DISH Q16051575
- name: حلوای بگل
- other names: {"fa": "حلوای بگل"}
- countries: (none)
- kinds: pastry

## DISH Q16051582
- name: حلوای راشی
- other names: {"fa": "حلوای راشی"}
- countries: (none)
- kinds: pastry

## DISH Q16051589
- name: حلوای زنجبیلی
- other names: {"fa": "حلوای زنجبیلی"}
- countries: (none)
- kinds: pastry

## DISH Q16051596
- name: حلوای سنگک
- other names: {"fa": "حلوای سنگک"}
- countries: (none)
- kinds: pastry

## DISH Q16051656
- name: سوهان کنجدی
- other names: {"fa": "سوهان کنجدی"}
- countries: (none)
- kinds: pastry

## DISH Q16051701
- name: Anar bij
- description: stew from Gilan province, Iran
- countries: IR
- kinds: dish, Khoresht

## DISH Q16051902
- name: Çay çörəyi
- other names: {"az": "Çay çörəyi"}
- countries: (none)
- kinds: pastry

## DISH Q16052123
- name: حلوای به
- other names: {"fa": "حلوای به"}
- countries: (none)
- kinds: pastry

## DISH Q16052433
- name: Koleh konji
- description: Iranian sweet
- countries: (none)
- kinds: pastry

## DISH Q16052560
- name: عسلی حلوا
- other names: {"fa": "عسلی حلوا"}
- countries: (none)
- kinds: pastry

## DISH Q16052884
- name: کوئی کاکا
- other names: {"fa": "کوئی کاکا"}
- countries: (none)
- kinds: pastry

## DISH Q16069258
- name: BB met R
- other names: {"eo": "BB met R"}
- countries: SR
- kinds: dish
- ingredients: celery, tomato, Capsicum chinense ʽMadame Jeanette’, onion, peppercorn, chicken as food, salt-cured meat, Phaseolus vulgaris, sugar, rice

## DISH Q16069669
- name: Hennepot
- other names: {"nl": "hennepot"}
- countries: (none)
- kinds: dish

## DISH Q16073623
- name: دوشاب بج
- other names: {"fa": "دوشاب بج"}
- countries: (none)
- kinds: pastry

## DISH Q16074240
- name: لوز گل به
- other names: {"fa": "لوز گل به"}
- countries: (none)
- kinds: pastry

## DISH Q16074822
- name: کشکول
- other names: {"fa": "کشکول"}
- countries: (none)
- kinds: pastry

## DISH Q16078622
- name: Guanchang
- other names: {"zh": "灌肠"}
- description: pan-fried starch sausage slices
- countries: CN
- kinds: fried food
- has Wikipedia article: zh

## DISH Q16088653
- name: Врањска самса
- other names: {"sr": "Врањска самса"}
- countries: (none)
- kinds: dish

## DISH Q16089496
- name: Komplet lepinja
- description: Serbian breakfast dish
- countries: RS
- kinds: dish
- ingredients: chicken egg, kaymak

## DISH Q1609997
- name: Sahnehering
- description: German fish salad
- countries: (none)
- kinds: salad, fish dish
- ingredients: herring, yogurt, cream

## DISH Q16114172
- name: Meso z tiblice
- description: meat dish from the Međimurje region in Croatia
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q16117045
- name: Samoborska kremšnita
- description: Croatian cake
- countries: HR
- kinds: cake, cremeschnitte

## DISH Q16118267
- name: الباطرش الحموي
- other names: {"ar": "الباطرش الحموي"}
- countries: SY
- kinds: dish

## DISH Q1611906
- name: Lacabòn
- description: hand-crafted Italian candy
- countries: IT
- kinds: confectionery
- ingredients: sugar, honey
- has Wikipedia article: en

## DISH Q16131115
- name: اللوز والزبيب
- other names: {"ar": "اللوز والزبيب"}
- countries: MA
- kinds: dish
- ingredients: almond, raisin, sugar

## DISH Q16133717
- name: Ada pradhaman
- description: A sweet dish of Kerala
- countries: (none)
- kinds: food, Pradhaman
- has Wikipedia article: en

## DISH Q16134337
- name: Ullivada
- description: snack food of Kerala
- countries: (none)
- kinds: snack, fritter

## DISH Q16135411
- name: Pulissery
- description: curry of Kerala, India, made from buttermilk, usually sweetish
- countries: IN
- kinds: side dish, curry, Buttermilk curry
- has Wikipedia article: en

## DISH Q16136789
- name: Pradhaman
- description: Sweet dish of Kerala
- countries: (none)
- kinds: rice pudding, confectionery, pudding

## DISH Q16137389
- name: Pappada vada
- description: South Indian snack made from papadum
- countries: IN
- kinds: food
- ingredients: papad

## DISH Q16137545
- name: Kappa biriyani
- description: Biriyani dish of Kerala
- countries: (none)
- kinds: food, biryani

## DISH Q16137567
- name: Thuramanga
- countries: IN
- kinds: dish
- ingredients: mango

## DISH Q16137627
- name: Thuvarappayasam
- countries: (none)
- kinds: sweet dish, payasam

## DISH Q16137720
- name: Mezhukkupuratti
- description: Vegetable side dish
- countries: (none)
- kinds: vegetable curry
- has Wikipedia article: en

## DISH Q16137937
- name: Pazham Pradhaman
- description: Traditional sweet dish of Kerala with  Nendran Banana
- countries: IN
- kinds: pudding, food, Pradhaman

## DISH Q16138245
- name: 炒浇面
- countries: CN
- kinds: noodle soup
- has Wikipedia article: zh

## DISH Q1614159
- name: Herrentorte
- other names: {"de": "Herrentorte"}
- countries: (none)
- kinds: torte

## DISH Q16142176
- name: Afogado
- other names: {"pt": "afogado"}
- countries: BR
- kinds: stew

## DISH Q1614358
- name: Khustonig
- description: food
- countries: (none)
- kinds: food, Ersatz good, confectionery, syrup
- ingredients: invert sugar

## DISH Q16145431
- name: Alfajor of Chile
- countries: CL
- kinds: confectionery

## DISH Q16147704
- name: Hungarian sausages
- description: sausages of Hungarian cuisine
- countries: HU
- kinds: sausage
- has Wikipedia article: en

## DISH Q16159647
- name: Neobiani
- description: thinly sliced, marinated, and grilled beef
- countries: (none)
- kinds: meat dish
- ingredients: beef
- has Wikipedia article: en

## DISH Q16162787
- name: 뉴면
- other names: {"ko": "뉴면"}
- countries: (none)
- kinds: ramyeon

## DISH Q16164832
- name: Ssuktteok
- description: Korean mugwort rice cake
- countries: (none)
- kinds: tteok
- ingredients: Artemisia princeps

## DISH Q16164947
- name: Dakgaejang
- description: Korean chicken soup
- countries: (none)
- kinds: chicken soup

## DISH Q1616787
- name: Hexenkerze
- other names: {"de": "Hexenkerze"}
- countries: (none)
- kinds: dish

## DISH Q16172410
- name: Seokbakji
- countries: (none)
- kinds: Kimchi

## DISH Q16174915
- name: Bidos
- description: traditional Sámi stew
- countries: (none)
- kinds: meat dish, stew
- ingredients: potato, reindeer meat, onion, carrot

## DISH Q161755
- name: 1.-August-Weggen
- description: Bread roll eaten around the Swiss national holiday
- countries: (none)
- kinds: Weggli

## DISH Q16176340
- name: Ganjang kimchi
- countries: (none)
- kinds: Kimchi

## DISH Q16180568
- name: Hongtak samhap
- other names: {"zh": "洪濁三合"}
- description: South Korean dish of fermented skate, boiled pork and kimchi
- countries: KR
- kinds: Triada, fish dish, pork dish
- ingredients: bossam, hongeohoe, makgeolli, Kimchi

## DISH Q16182271
- name: I fu mie
- description: Indonesian dish
- countries: ID
- kinds: dish
- ingredients: garlic, chicken egg, mie kering
- has Wikipedia article: en

## DISH Q16183127
- name: Ojingeo-bokkeum
- description: Korean dish of spicy stir-fried squid
- countries: (none)
- kinds: squid dish
- ingredients: squid as food

## DISH Q16184176
- name: Duruchigi
- description: South Korean dish
- countries: KR
- kinds: pork dish
- ingredients: tofu

## DISH Q16191528
- name: Pulppang
- countries: (none)
- kinds: bread

## DISH Q16191619
- name: プンチョンチャンオ
- other names: {"ja": "プンチョンチャンオ"}
- countries: KR
- kinds: fish dish
- ingredients: unagi

## DISH Q1620456
- name: Hirschhornkuchen
- other names: {"de": "Hirschhornkuchen"}
- countries: (none)
- kinds: cake

## DISH Q1621290
- name: Hiyamugi
- description: thin noodles, served chilled
- countries: JP
- kinds: cold noodle, Japanese noodles
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q1621633
- name: Schinkenröllchen
- other names: {"de": "Schinkenröllchen"}
- countries: (none)
- kinds: dish

## DISH Q16230436
- name: Traditional Rice of Sri Lanka
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16241452
- name: Bakpia
- other names: {"zh": "侯皮亞"}
- description: traditional Indonesian pastry filled with various nuts
- countries: CN, ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, pastry, snack
- ingredients: black turtle bean, vegetable fat, corn starch, wheat flour, coconut milk, Vigna radiata, Vigna angularis, Pandanus amaryllifolius, egg yolk, vanilla, sugar, margarine, chocolate
- has Wikipedia article: en, zh

## DISH Q16241584
- name: Duck rice
- other names: {"zh": "鴨飯"}
- description: Duck dish
- countries: SG
- kinds: dish
- ingredients: white rice, duck meat
- has Wikipedia article: en

## DISH Q16242003
- name: Hedgehog slice
- description: no-bake fridge cake dessert
- countries: DE
- cuisines: German cuisine
- kinds: dessert, pastry
- ingredients: almond, butter, biscuit, cookie, chocolate
- has Wikipedia article: en

## DISH Q16242013
- name: Church window
- description: multicolored dessert confection
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q16242089
- name: Pig's blood cake
- other names: {"zh": "米血糕"}
- description: Traditional cuisine in Taiwan
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: blood sausage, pork dish
- has Wikipedia article: en, zh

## DISH Q16242644
- name: Mayordomo
- description: Mexican chocolate brand
- countries: (none)
- kinds: product, chocolate
- has Wikipedia article: en

## DISH Q16243133
- name: Texas caviar
- description: salad of black-eyed peas lightly pickled in a vinaigrette-style dressing, often eaten as a dip accompaniment to tortilla chips
- countries: US
- kinds: human food, salad
- has Wikipedia article: en

## DISH Q16247382
- name: Chakkavaratti
- description: Jackfruit based sweet snack from Kerala
- countries: IN
- kinds: snack
- ingredients: jackfruit
- has Wikipedia article: en

## DISH Q16247693
- name: Ciambella PAT
- other names: {"zh": "Ciambella PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good, cake
- has Wikipedia article: en

## DISH Q16248468
- name: Kabkabou
- description: Tunisian fish stew
- countries: TN
- kinds: ragout
- ingredients: olive, tomato paste, olive oil, saffron, onion, Allium sativum
- has Wikipedia article: en

## DISH Q16248794
- name: Lardy cake
- description: English form of sweet spiced bread
- countries: GB
- kinds: pastry, dish
- ingredients: rendering
- has Wikipedia article: en

## DISH Q1625130
- name: Cottage ham
- countries: (none)
- kinds: cold cut, ham

## DISH Q1625491
- name: Holzfällersteak
- other names: {"de": "Holzfällersteak"}
- countries: (none)
- kinds: dish

## DISH Q16258710
- name: Trenza
- description: Spanish pastry
- countries: (none)
- kinds: food, bread
- has Wikipedia article: en

## DISH Q162592
- name: Die Plinse, Plinze
- countries: (none)
- kinds: pastry, blini

## DISH Q16261384
- name: Dolsot-bibimbap
- other names: {"zh": "石锅拌饭"}
- countries: KR
- kinds: bibimbap
- ingredients: dolsot

## DISH Q16261564
- name: Bapburger
- countries: KR
- kinds: rice burger

## DISH Q16262179
- name: Chueo-tang
- other names: {"zh": "泥鳅汤"}
- description: loach soup
- countries: (none)
- kinds: fish dish
- ingredients: Pond loach
- has Wikipedia article: en

## DISH Q16269628
- name: Rocky Mountain oysters
- other names: {"zh": "落基山脉蚝"}
- description: dish made of bovine testicles
- countries: CA
- kinds: food, beef dish
- ingredients: testicle as food
- has Wikipedia article: en, zh

## DISH Q1627087
- name: Saumaise
- countries: AT
- kinds: meat dish, meat product
- ingredients: pork

## DISH Q1627095
- name: Honigkuchenpferd
- countries: DE
- kinds: redewendung, ontbijtkoek
- ingredients: flour, honey

## DISH Q16301690
- name: Angus burger
- other names: {"zh": "安格斯漢堡"}
- description: hamburger made using Angus beef
- countries: (none)
- kinds: hamburger
- has Wikipedia article: en, zh

## DISH Q16302027
- name: Borrachuelo
- other names: {"es": "borrachuelo"}
- countries: ES
- kinds: dessert, fritter

## DISH Q16304057
- name: Sarim (dessert)
- other names: {"zh": "Sarim"}
- description: Thai pink and green thin noodle desert
- countries: (none)
- kinds: dessert
- has Wikipedia article: en, zh

## DISH Q16305809
- name: Prawn cracker
- other names: {"zh": "蝦餅"}
- description: prawn-flavored cracker
- countries: (none)
- kinds: food, krupuk, shrimp dish, bánh phồng
- ingredients: tapioca, egg as food, Allium sativum, table salt, sugar
- has Wikipedia article: en, zh

## DISH Q1630666
- name: Mämmi
- other names: {"zh": "曼米"}
- description: Finnish Easter dessert
- countries: FI
- kinds: Easter, dessert
- ingredients: rye flour, malt, water
- has Wikipedia article: en, zh

## DISH Q16307825
- name: Roti sai mai
- description: Sweet roti with cotton candy
- countries: TH
- kinds: dish
- has Wikipedia article: en

## DISH Q16307923
- name: O-tao
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16308022
- name: ไข่ป่าม
- other names: {"th": "ไข่ป่าม"}
- countries: (none)
- kinds: egg dish

## DISH Q1632545
- name: Karelian hot pot
- other names: {"zh": "卡累利阿炖肉"}
- description: dish
- countries: FI
- cuisines: Finnish cuisine
- kinds: dish
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q16328551
- name: Σουτζούκ λουκούμ
- other names: {"el": "Σουτζούκ λουκούμ"}
- countries: (none)
- kinds: Turkish delight

## DISH Q16329451
- name: Gogges
- description: type of pasta from the Peloponnese, Greece
- countries: GR
- kinds: type of pasta, pasta
- has Wikipedia article: en

## DISH Q16330184
- name: Riganada
- description: Greek dish
- countries: GR
- kinds: appetizer

## DISH Q16331672
- name: Lagana
- description: type of Greek flat bread
- countries: GR
- kinds: flatbread
- has Wikipedia article: en

## DISH Q16332019
- name: Fanouropita
- description: traditional sweet cake from Greek/Cypriot cuisine
- countries: (none)
- kinds: sweet pie
- has Wikipedia article: en

## DISH Q16345325
- name: Gaja
- description: Bengali sweet
- countries: (none)
- kinds: confectionery

## DISH Q16345347
- name: Gujia
- countries: IN
- kinds: confectionery

## DISH Q16345446
- name: Chhanamukhi
- description: Bangladeshi sweet
- countries: BD
- cuisines: Bangladeshi cuisine
- kinds: confectionery
- has Wikipedia article: en

## DISH Q16345986
- name: Batasa
- description: type of sweet
- countries: (none)
- kinds: confectionery
- ingredients: jaggery, sugar

## DISH Q16346869
- name: Sitabhog
- description: Indian sweet
- countries: (none)
- kinds: confectionery
- ingredients: cow's milk, chhena, rice flour, sugar
- has Wikipedia article: en

## DISH Q16350217
- name: Bathë të njoma jahni
- other names: {"sq": "Bathë të njoma jahni"}
- countries: (none)
- kinds: dish

## DISH Q16351737
- name: Pasta derri kanadeze
- other names: {"sq": "Pasta derri kanadeze"}
- countries: (none)
- kinds: dish

## DISH Q16351793
- name: Patlıcan dolma turşusu
- countries: (none)
- kinds: dish

## DISH Q16359149
- name: Jāņi cheese
- other names: {"zh": "亞尼奶酪"}
- description: type of cheese
- countries: LV
- kinds: cheese, acid-set cheese, cow's-milk cheese, type of cheese
- ingredients: caraway seeds, cow's milk, quark
- has Wikipedia article: en, zh

## DISH Q16359321
- name: Onion casserole from Gjakova
- description: Baked dish consisting mainly of roasted onions, and meat
- countries: XK
- cuisines: Albanian cuisine
- kinds: dish, casserole
- ingredients: onion

## DISH Q16369889
- name: Tashmijabi
- description: Georgian dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1637445
- name: Dog biscuit
- other names: {"zh": "狗干粮"}
- description: nutritional supplement for dogs
- countries: (none)
- kinds: biscuit, dog food
- has Wikipedia article: en, zh

## DISH Q1638936
- name: Hushpuppy
- other names: {"zh": "炸玉米球"}
- description: savory food made from cornmeal batter
- countries: US
- cuisines: cuisine of the United States
- kinds: fritter, dish
- ingredients: cornmeal, egg as food, onion
- has Wikipedia article: en

## DISH Q16391650
- name: Carp soup
- description: traditional Czech fish soup
- countries: (none)
- kinds: fish soup

## DISH Q1639560
- name: Hverabrauð
- other names: {"pl": "Hverabrauð"}
- countries: (none)
- kinds: Rúgbrauð

## DISH Q1639853
- name: Moros y Cristianos
- description: Cuban dish
- countries: ES
- cuisines: Cuban cuisine
- kinds: dish, rice and beans
- has Wikipedia article: en

## DISH Q1640426
- name: Popover
- other names: {"zh": "淡烤酥餅"}
- description: light, hollow roll made from an egg batter
- countries: US
- kinds: baked good
- ingredients: batter
- has Wikipedia article: en

## DISH Q16411925
- name: Mulgikapsad
- description: cabbage-based dish in Estonian cuisine
- countries: EE
- kinds: dish
- ingredients: Piper, Brassica, table salt, bacon, water
- has Wikipedia article: en

## DISH Q16414158
- name: Balıq kebab
- description: Azerbaijani fish kebab
- countries: (none)
- kinds: fish dish, kebab

## DISH Q16414783
- name: Shorgoghal
- other names: {"zh": "阿塞拜疆卷面包"}
- description: traditional Azerbaijani pastry
- countries: AZ
- cuisines: Azerbaijani cuisine
- kinds: pastry
- has Wikipedia article: en

## DISH Q16414997
- name: Şəki pitisi
- other names: {"az": "Şəki pitisi"}
- countries: (none)
- kinds: soup

## DISH Q1641858
- name: Häckerle
- countries: DE, PL
- kinds: dish, fish dish
- ingredients: Spekesild

## DISH Q16419632
- name: Kúlusúkk
- other names: {"is": "Kúlusúkk"}
- countries: (none)
- kinds: candy

## DISH Q16420039
- name: Kjötsúpa
- other names: {"fr": "kjötsúpa"}
- countries: (none)
- kinds: meat soup

## DISH Q1642089
- name: Wedding cake of Prince William and Kate Middleton
- description: wedding cake
- countries: (none)
- kinds: wedding cake

## DISH Q16421026
- name: Lumma
- other names: {"de": "Lumma"}
- countries: (none)
- kinds: dish

## DISH Q1642148
- name: Thali
- other names: {"zh": "塔利"}
- description: South and Southeast Asian-style meal made up of various dishes which are served on a platter
- countries: SG, KH, IN, AF, MY, ID, TH, PK, MM, NP, LA, JM, TT, BB, LK, MU, BD
- cuisines: Singaporean cuisine, Cambodian cuisine, Indian cuisine, Afghan cuisine, Malaysian cuisine, Indonesian cuisine, Thai cuisine, Pakistani cuisine, Burmese cuisine, Nepalese cuisine, Lao cuisine, Caribbean cuisine, Sri Lankan cuisine, Bruneian cuisine, Mauritian cuisine, Bangladeshi cuisine, Maldivian cuisine, Fijian cuisine
- kinds: platter
- ingredients: condiment, groat, seafood, vegetable, meat, rice
- has Wikipedia article: en, zh

## DISH Q16422576
- name: Dillkartöflur
- other names: {"is": "Dillkartöflur"}
- countries: (none)
- kinds: potato dish

## DISH Q16430337
- name: Vínarterta
- other names: {"zh": "維也納蛋糕"}
- description: cake
- countries: IS
- kinds: torte
- ingredients: dough, jam
- has Wikipedia article: en, zh

## DISH Q1643361
- name: Kibbeh nayeh
- description: Levantine dish made of raw meat
- countries: (none)
- kinds: food, lamb dish, beef dish, raw meat dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q16449385
- name: Daujenu namine duona
- description: Lithuanian rye bread
- countries: LT
- kinds: rye bread

## DISH Q164606
- name: Curry
- other names: {"zh": "咖哩"}
- description: dish whose origins are in South Asian, Southeast Asian and British cuisines
- countries: IN
- cuisines: United Kingdom
- kinds: viand, dish
- ingredients: culinary herb, curry powder, herb, spice
- has Wikipedia article: en, zh

## DISH Q16466775
- name: Muhallabia
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q1647985
- name: Savarin
- description: French cake
- countries: FR
- kinds: cake

## DISH Q16480251
- name: Bo ne
- countries: VN
- kinds: steak, dish

## DISH Q16480434
- name: Snakehead paste
- description: Vietnamese fermented fish paste
- countries: VN
- cuisines: Southern Vietnamese cuisine
- kinds: fermented fish
- ingredients: Channa striata

## DISH Q16480438
- name: Mắm còng
- other names: {"vi": "mắm còng"}
- countries: VN
- kinds: fermented seafood

## DISH Q16480444
- name: Mắm ruột An Giang
- other names: {"vi": "mắm ruột An Giang"}
- countries: VN
- cuisines: An Giang cuisine
- kinds: designation of origin, snakehead paste
- ingredients: toasted rice powder, Giant snakehead

## DISH Q16480872
- name: Thit Kho Tau
- description: southeast Asian dish
- countries: VN
- kinds: food, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q16481294
- name: Xôi gấc
- description: Vietnamese rice dish
- countries: VN
- kinds: xôi, rice dish
- ingredients: gac melon

## DISH Q16481351
- name: Mắm tép chưng thịt
- other names: {"vi": "mắm tép chưng thịt"}
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: dish

## DISH Q16481902
- name: Pepita con tasajo
- description: Mexican beef dish
- countries: MX
- kinds: beef dish
- ingredients: tasajo, pumpkin seed

## DISH Q16484916
- name: Arkas
- other names: {"pl": "Arkas"}
- countries: (none)
- kinds: dish

## DISH Q16488884
- name: Artaquitón
- other names: {"es": "Artaquitón"}
- countries: (none)
- kinds: guiso
- ingredients: parsley, Allium sativum, table salt, bread

## DISH Q16489179
- name: Sand tuna
- description: tuna recipe from Alicante
- countries: (none)
- kinds: dish
- ingredients: Thunnus

## DISH Q16489181
- name: Atún encebollado
- other names: {"es": "Atún encebollado"}
- countries: (none)
- kinds: dish
- ingredients: onion, albacore

## DISH Q16489885
- name: Cabrito al pastor
- other names: {"es": "Cabrito al pastor"}
- countries: (none)
- kinds: dish

## DISH Q16490638
- name: Angu
- description: Brazilian food item
- countries: (none)
- kinds: dish

## DISH Q16490881
- name: Chipilín con bolitas
- other names: {"es": "Chipilín con bolitas"}
- countries: MX
- kinds: dish

## DISH Q16491100
- name: Cochito
- description: traditional dish from Chiapas
- countries: MX
- kinds: dish

## DISH Q16492670
- name: Apa
- other names: {"pt": "Apa"}
- countries: (none)
- kinds: food

## DISH Q16493207
- name: Arabu
- description: indigenous Brazilian egg dish
- countries: BR
- cuisines: Brazilian cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q16494096
- name: Arroz de hauçá
- other names: {"pt": "arroz de hauçá"}
- countries: (none)
- kinds: dish

## DISH Q16494100
- name: Arrumadinho
- description: Brazilian dish
- countries: BR
- kinds: dish, bean-based food

## DISH Q16495993
- name: Baba-de-moça
- description: Brazilian dessert
- countries: (none)
- kinds: custard, confectionery

## DISH Q16496019
- name: Bacalhau à Narcisa
- description: typical fish from Braga, Portugal
- countries: PT
- cuisines: Portuguese cuisine
- kinds: potato dish, bacalhau, fish dish
- ingredients: onion, dried and salted cod, olive, fries, olive oil, parsley
- has Wikipedia article: en

## DISH Q16496021
- name: Bacalhau albardado
- other names: {"pt": "Bacalhau albardado"}
- countries: (none)
- kinds: fish dish

## DISH Q16496023
- name: バカリャウ・アサード・コン・バタータス・ア・ムーロ
- other names: {"ja": "バカリャウ・アサード・コン・バタータス・ア・ムーロ"}
- countries: (none)
- kinds: potato dish, fish dish

## DISH Q16496166
- name: Baião de dois
- description: Brazilian rice dish
- countries: (none)
- kinds: rice dish, bean-based food
- ingredients: common bean, rice
- has Wikipedia article: en

## DISH Q16496347
- name: Balichão
- other names: {"zh": "鹹蝦醬"}
- description: sauce or paste made from krill, bay leaves, chili, clove, lime, peppercorn, and fortified wine, used in Macanese cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16496413
- name: Bananinha
- other names: {"pt": "bananinha"}
- countries: BR
- kinds: confectionery

## DISH Q16497397
- name: Beijos de dona dondon
- other names: {"pt": "beijos de dona dondon"}
- countries: (none)
- kinds: confectionery

## DISH Q16498169
- name: Bibikkan
- description: Sri Lankan coconut cake
- countries: LK
- kinds: dish, cake
- has Wikipedia article: en

## DISH Q16498322
- name: Biju
- description: Brazilian biscuit
- countries: (none)
- kinds: food, biscuit

## DISH Q1650008
- name: Quarkspeise
- description: German trifle dessert
- countries: (none)
- kinds: trifle, dish

## DISH Q1650115
- name: Sprouted bread
- description: type of bread
- countries: (none)
- kinds: food, bread
- ingredients: whole grain
- has Wikipedia article: en

## DISH Q16501664
- name: Galleta de goma
- other names: {"es": "Galleta de goma"}
- description: cookie
- countries: (none)
- kinds: cookie

## DISH Q16501935
- name: Boi no rolete
- other names: {"pt": "boi no rolete"}
- countries: (none)
- kinds: dish

## DISH Q16501985
- name: Bolo de santo antônio
- other names: {"pt": "bolo de santo antônio"}
- countries: (none)
- kinds: confectionery

## DISH Q16521494
- name: Lebbencs
- description: pasta
- countries: (none)
- kinds: pasta

## DISH Q16522806
- name: Sport slice
- description: Hungarian chocolate bar
- countries: (none)
- kinds: chocolate bar
- has Wikipedia article: en

## DISH Q16525191
- name: Acewwaḍ
- countries: DZ
- cuisines: Berber (Amazigh) cuisine, Algerian cuisine
- kinds: dish
- ingredients: dough, olive oil, milk

## DISH Q16525262
- name: Adghess
- countries: DZ
- cuisines: Berber (Amazigh) cuisine
- kinds: recipe, dish
- ingredients: egg as food, olive oil, milk

## DISH Q16525342
- name: Aemono
- other names: {"zh": "和物"}
- description: Dressed dishes in Japanese cuisine
- countries: JP
- kinds: salad

## DISH Q16525446
- name: أغروم
- other names: {"ar": "أغروم"}
- countries: (none)
- kinds: bread

## DISH Q16525449
- name: Aghroum akouran
- other names: {"fr": "Aghroum akouran"}
- countries: (none)
- kinds: galette

## DISH Q16531859
- name: Batata kbab
- countries: (none)
- kinds: dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q16532708
- name: Biscotto salute
- countries: IT
- kinds: dessert

## DISH Q16533506
- name: Bouchee a la reine
- countries: FR
- kinds: vol-au-vent, meat pastry
- ingredients: white sauce, croustade, chicken as food, mushroom, sweetbread, puff pastry, Quenelle

## DISH Q16533662
- name: Bounarine
- other names: {"fr": "bounarine"}
- countries: (none)
- kinds: dish

## DISH Q16533749
- name: Boussou la tmessou
- countries: DZ
- kinds: pastry, cake
- ingredients: sesame seed, lemon, orange flower water, powdered sugar, vanilla

## DISH Q16533773
- name: Brioscia
- description: brioche of Sicily
- countries: IT
- kinds: dessert, brioche

## DISH Q16534180
- name: Brotgrompern
- other names: {"fr": "Brotgrompern"}
- countries: (none)
- kinds: dish
- ingredients: potato, fromage blanc, ham

## DISH Q16534530
- name: Caccavelle
- description: type of pasta
- countries: IT
- kinds: type of pasta, pasta

## DISH Q16536282
- name: Carré de Liège
- other names: {"fr": "Carré de Liège"}
- countries: BE
- kinds: cheese, white mold-rind cheese, list of Belgian cheeses
- ingredients: cow's milk

## DISH Q16536473
- name: Castel
- description: Cake of Algeria
- countries: DZ
- kinds: cake

## DISH Q16537284
- name: Chahda
- countries: DZ
- kinds: confectionery

## DISH Q16537387
- name: Carsenta
- other names: {"it": "Carsenta"}
- countries: IT
- kinds: dessert

## DISH Q16538363
- name: Bollo de mantequilla
- other names: {"es": "Bollo de mantequilla"}
- countries: (none)
- ingredients: butter

## DISH Q16540061
- name: Civet de chevreuil
- description: traditional French dish of stewed venison
- countries: FR
- kinds: dish, venison dish

## DISH Q16540064
- name: Civet de lapin
- description: traditional French rabbit stew
- countries: FR
- kinds: rabbit dish
- ingredients: rabbit meat

## DISH Q16541197
- name: Ciaramicola
- other names: {"it": "Ciaramicola"}
- countries: IT
- kinds: dessert

## DISH Q16541457
- name: Cipolla rossa di Acquaviva delle Fonti
- countries: IT
- kinds: red onion, onion

## DISH Q16543639
- name: Condiglione
- other names: {"it": "Condiglione"}
- countries: IT
- kinds: salad
- ingredients: basil, garlic, tomato, cucumber, bell pepper, Botargo, hardtack, Lactuca sativa, oil, vinegar

## DISH Q16545117
- name: Crêpe dentelle
- other names: {"fr": "Crêpe dentelle"}
- countries: (none)
- kinds: recipe, crêpe

## DISH Q16545592
- name: Cri cri
- description: Traditional Italian chocolate confection
- countries: IT
- kinds: bonbon
- ingredients: hazelnut, chocolate

## DISH Q16545967
- name: Crustuli
- other names: {"es": "Crustuli"}
- countries: IT
- kinds: dessert

## DISH Q16548795
- name: Chocotorta
- description: no-bake dessert of Argentina
- countries: AR
- kinds: chocolate cake
- ingredients: dulce de leche, cream cheese, chocolate biscuit
- has Wikipedia article: en

## DISH Q16550306
- name: Easter cake
- description: cakes prepared for Easter
- countries: (none)
- kinds: confectionery, Easter food
- has Wikipedia article: en

## DISH Q16555942
- name: Fichi impaccati
- other names: {"it": "Fichi impaccati"}
- countries: IT
- kinds: dessert

## DISH Q16556351
- name: Focaccia di Susa
- countries: IT
- kinds: confectionery

## DISH Q16561874
- name: Grano cotto
- other names: {"it": "Grano cotto"}
- countries: IT
- kinds: dessert

## DISH Q16562242
- name: Gueffus
- description: Typical desert from Sardinia produced on holidays and festivities
- countries: IT
- kinds: dessert

## DISH Q16564781
- name: Ministeriale
- other names: {"it": "ministeriale"}
- countries: IT
- kinds: bonbon

## DISH Q16565420
- name: קפוסטה גרוכם
- other names: {"he": "קפוסטה גרוכם"}
- countries: PL
- cuisines: Polish cuisine
- kinds: dish
- ingredients: sauerkraut, Pisum, spice

## DISH Q16565718
- name: Karpatka
- other names: {"zh": "卡帕特卡"}
- description: Polish cream pie
- countries: (none)
- kinds: cream pie
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q16566432
- name: Iris (pastry)
- description: Italian ricotta-filled pastry
- countries: IT
- cuisines: Sicilian cuisine
- kinds: pastry
- has Wikipedia article: en

## DISH Q16566703
- name: Kiszka ziemniaczana
- other names: {"pl": "Kiszka ziemniaczana"}
- countries: (none)
- kinds: potato dish

## DISH Q16566892
- name: Бульбяныя клёцкі
- other names: {"be-tarask": "бульбяныя клёцкі"}
- countries: (none)
- kinds: potato dish

## DISH Q16567475
- name: Kompot z suszu
- other names: {"pl": "Kompot z suszu"}
- countries: (none)
- kinds: dish

## DISH Q16567691
- name: Fideos con caballa
- description: Mackerel noodle soup
- countries: (none)
- kinds: dish
- ingredients: Caballa de Andalucía, garlic, tomato, Pimiento, noodle, olive oil

## DISH Q16570609
- name: Gambas à la plancha
- description: Spanish shrimp dish
- countries: (none)
- kinds: shrimp dish

## DISH Q16570892
- name: Gaspatxos alacantins
- other names: {"ca": "Gaspatxos alacantins"}
- description: type of gazpacho from the province of Alicante
- countries: (none)
- kinds: gazpacho

## DISH Q16571645
- name: Ginestada
- other names: {"es": "Ginestada"}
- countries: ES
- kinds: dessert, sauce
- ingredients: cow's milk, rice flour

## DISH Q16573458
- name: Lonzino di fico
- other names: {"it": "Lonzino di fico"}
- countries: IT
- kinds: dessert

## DISH Q16573500
- name: Gushtab
- description: Meat balls dish of Kashmir
- countries: IN
- cuisines: Kashmiri cuisine
- kinds: lamb dish, dish
- ingredients: mutton
- has Wikipedia article: en

## DISH Q16573798
- name: Lu serpe
- other names: {"it": "Lu serpe"}
- countries: IT
- kinds: dessert

## DISH Q16574675
- name: Macafame
- other names: {"it": "Macafame"}
- countries: IT
- kinds: dessert

## DISH Q16575455
- name: Manna
- description: plant sap extracted from certain species of Fraxinus trees
- countries: IT
- kinds: food, plant sap, medication, food ingredient

## DISH Q16578397
- name: Miele delle Dolomiti Bellunesi PDO
- other names: {"zh": "Miele delle Dolomiti Bellunesi DOP"}
- description: Italian PDO animal product
- countries: IT
- kinds: honey, animal product

## DISH Q16580654
- name: Musetto
- description: type of Italian sausage
- countries: IT
- kinds: charcuterie, sausage

## DISH Q16586408
- name: Kaviar
- countries: (none)
- kinds: dish

## DISH Q16586707
- name: Pane di Monte Sant'Angelo
- other names: {"it": "Pane di Monte Sant'Angelo"}
- countries: IT
- kinds: bread

## DISH Q16587862
- name: Peposo
- description: Tuscan meat stew
- countries: IT
- kinds: stew, beef dish, type of food or dish
- ingredients: beef, black pepper, red wine

## DISH Q16590111
- name: Lentils with chorizo
- description: stew
- countries: ES
- kinds: guiso, meal
- ingredients: lentil, bay leaf, chorizo

## DISH Q16590829
- name: Pissarei e fasö
- description: Tipical Italian dish
- countries: IT
- kinds: first course, bean dish
- has Wikipedia article: en

## DISH Q16590870
- name: Pistum
- other names: {"it": "Pistum"}
- countries: IT
- kinds: velouté sauce

## DISH Q16592556
- name: Saint-Oyen grilled Jambon
- description: Traditional Italian ham
- countries: IT
- kinds: fiambre, food

## DISH Q16596895
- name: Risotto al nero di seppia
- countries: HR
- kinds: risotto
- ingredients: Sepia, rice

## DISH Q1660010
- name: Christmas cookies
- other names: {"zh": "圣诞饼干"}
- description: sweet pastries that are eaten during the Christmas season
- countries: (none)
- kinds: pastry, Plätzchen, Christmas dessert, seasonal food
- has Wikipedia article: en, zh

## DISH Q16607686
- name: Soppressata di Calabria PDO
- other names: {"zh": "Soppressata di Calabria DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: soppressata, meat product
- ingredients: Calabrian chili pepper, pork, Foeniculum vulgare, black pepper

## DISH Q16608468
- name: Mole de olla
- description: traditional Mexican soup
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q16610775
- name: Naranjas picadas
- description: chopped sweet orange without skin, olive oil ..
- countries: ES
- kinds: salad, dish
- ingredients: Gadus morhua, olive oil, vinegar, Atlantic mackerel, onion, orange, table salt

## DISH Q16612124
- name: Nochebueno
- countries: ES
- kinds: dessert

## DISH Q166128
- name: Picadillo
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q16613521
- name: Olla segorbina
- other names: {"es": "Olla segorbina"}
- countries: (none)
- kinds: gastronomy, guiso

## DISH Q16614903
- name: Paches
- other names: {"es": "Paches"}
- countries: (none)
- kinds: dish

## DISH Q16616890
- name: Pastel de arroz
- other names: {"es": "Pastel de arroz"}
- countries: ES
- kinds: dessert

## DISH Q16617059
- name: Tortelli alla piacentina
- other names: {"it": "tortelli alla piacentina"}
- countries: IT
- kinds: Tortelli, type of pasta

## DISH Q16619629
- name: Plato alpujarreño
- countries: (none)
- kinds: type of food or dish, potato dish, egg dish
- ingredients: fried egg, fries

## DISH Q166204
- name: Kamaboko
- other names: {"zh": "蒲鉾"}
- description: Japanese fish cake
- countries: JP
- cuisines: Japanese cuisine
- kinds: type of food or dish, fishcake, fish dish
- ingredients: fish surimi
- has Wikipedia article: en, zh

## DISH Q16620452
- name: Vastedda cu sammucu PAT
- other names: {"zh": "Vastedda cu sammucu PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q16621176
- name: Potaje de farro
- other names: {"es": "potaje de farro"}
- countries: ES
- cuisines: Spanish cuisine
- kinds: potage, type of food or dish

## DISH Q16627769
- name: Citronfromage
- description: Danish dessert
- countries: DK
- kinds: mousse
- ingredients: lemon

## DISH Q16628274
- name: دار_عمي
- other names: {"ar": "دار_عمي"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: white sauce, kofta, cinnamon, cheese, bread

## DISH Q16631717
- name: الباي وديارتو
- other names: {"ar": "الباي وديارتو"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: egg as food, chicken

## DISH Q16634750
- name: Żymlok
- description: traditional Silesian offal sausage
- countries: PL
- cuisines: Silesian cuisine
- kinds: sausage, cold cut
- ingredients: pork, spice, bread roll, table salt, blood

## DISH Q16635690
- name: Sopa de calducho
- description: broth to cook the blood sausages and bread
- countries: (none)
- kinds: soup

## DISH Q16635693
- name: Broad bean soup
- countries: (none)
- kinds: bean soup
- ingredients: broad bean

## DISH Q16635695
- name: Sopa de picadillo
- description: Spanish soup
- countries: (none)
- kinds: soup
- ingredients: Serrano ham, vermicelli

## DISH Q16636380
- name: Flan
- description: dessert
- countries: (none)
- kinds: confectionery
- ingredients: egg as food, vanilla, sugar, milk

## DISH Q16637933
- name: Tarta xixonesa
- other names: {"ast": "tarta xixonesa"}
- countries: (none)
- kinds: tart

## DISH Q16638414
- name: Charente galette
- countries: (none)
- kinds: cake, galette
- ingredients: angélique, flour, butter, baking powder, egg, sugar

## DISH Q16639817
- name: Grands-pères
- description: Traditional pastry in Québécois cuisine
- countries: CA
- cuisines: Acadian cuisine, cuisine of Quebec
- kinds: pastry
- has Wikipedia article: en

## DISH Q16640148
- name: قريتلية
- other names: {"ar": "قريتلية"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: cicer arietinum, meat, pasta

## DISH Q16640733
- name: Gâteau breton
- description: cake from Brittany
- countries: (none)
- kinds: cake

## DISH Q16641169
- name: Halwat el lambout
- countries: DZ
- cuisines: Algerian cuisine
- kinds: cake, Pastries of Algeria
- ingredients: egg as food, flour, butter, sugar

## DISH Q1664301
- name: Mädchenröte
- other names: {"de": "Mädchenröte"}
- countries: (none)
- kinds: dish

## DISH Q16643224
- name: Turrón de Soconusco
- other names: {"es": "Turrón de Soconusco"}
- countries: ES
- kinds: nougat
- ingredients: cocoa bean, almond, sugar, milk

## DISH Q1664470
- name: Luntza
- other names: {"de": "Luntza"}
- countries: (none)
- kinds: dish

## DISH Q16648183
- name: كفتة (حلوى)
- other names: {"ar": "كفتة (حلوى)"}
- countries: (none)
- kinds: dish

## DISH Q16648323
- name: Khobz tounes
- description: type of tunisian cake
- countries: DZ
- kinds: cake
- ingredients: almond meal
- has Wikipedia article: en

## DISH Q16648860
- name: Kouign
- other names: {"fr": "kouign"}
- countries: (none)
- kinds: dish

## DISH Q16653183
- name: Lapin au cidre
- countries: (none)
- kinds: dish
- ingredients: Allium ascalonicum, cider, butter, rabbit, jam

## DISH Q16655180
- name: Изделия из рубленого мяса
- other names: {"ru": "Изделия из рубленого мяса"}
- countries: (none)
- kinds: meat dish
- ingredients: minced meat

## DISH Q16655572
- name: Levrette
- other names: {"fr": "Levrette"}
- countries: (none)
- kinds: confectionery
- ingredients: stuffing, chocolate

## DISH Q16663715
- name: Кислопряженец
- other names: {"ru": "Кислопряженец"}
- countries: (none)
- kinds: dish

## DISH Q16663938
- name: Mbaxal
- other names: {"fr": "Mbaxal"}
- countries: SN
- kinds: dish

## DISH Q16663951
- name: Mchekek
- countries: DZ
- kinds: pastry, human food

## DISH Q16664041
- name: Melon du Haut-Poitou
- countries: FR
- kinds: muskmelon, fruit

## DISH Q16664232
- name: M'hancha
- description: North African Almond Snake Pastry Recipe
- countries: DZ, MA
- cuisines: Moroccan cuisine, Algerian cuisine
- kinds: pastry
- ingredients: almond, puff pastry, honey
- has Wikipedia article: en

## DISH Q16664355
- name: Коврига
- other names: {"ru": "Коврига"}
- countries: (none)
- kinds: food, bread

## DISH Q16664587
- name: Minerve
- other names: {"fr": "Minerve"}
- countries: (none)
- kinds: pastry

## DISH Q16666411
- name: Ngalakh
- description: Senegalese millet porridge
- countries: (none)
- kinds: lakh
- ingredients: peanut paste, bouye, pulp, millet

## DISH Q16668793
- name: 阿诺奈蛋糕
- countries: FR
- kinds: cake

## DISH Q16669050
- name: Kurnik
- description: gourmet chicken-filled pirog in Russian cuisine
- countries: RU
- kinds: food, pastry
- ingredients: chicken as food, dough
- has Wikipedia article: en

## DISH Q16670586
- name: Polka
- other names: {"fr": "polka"}
- countries: (none)
- kinds: cake

## DISH Q16672252
- name: Raviole du Champsaur
- other names: {"fr": "Raviole du Champsaur"}
- countries: (none)
- kinds: dish
- ingredients: fresh Tomme, baker's yeast, egg as food, Quenelle, potato, beignet

## DISH Q16672649
- name: Retortillat
- other names: {"fr": "Retortillat"}
- countries: (none)
- kinds: potato dish
- ingredients: potato

## DISH Q16672930
- name: Riz à l'impératrice
- description: elaborate molded version of rice pudding in French haute cuisine
- countries: FR
- kinds: dessert
- ingredients: Bavarian cream, rice
- has Wikipedia article: en

## DISH Q16673189
- name: Ros bratel
- description: traditional Algerian Jewish tagine dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q16675328
- name: California salad
- countries: (none)
- kinds: dish, salad
- ingredients: salad

## DISH Q16677060
- name: Skendriette
- countries: DZ
- cuisines: Algerian cuisine
- kinds: cake, Pastries of Algeria
- ingredients: orange flower water, almond, flour, sugar

## DISH Q16677070
- name: Skikrate
- countries: DZ
- cuisines: Algerian cuisine
- kinds: cake, Pastries of Algeria
- ingredients: coconut, butter, sugar

## DISH Q16677587
- name: Soupe aux truffes noires VGE
- countries: FR
- kinds: soup, dish
- ingredients: Tuber melanosporum, foie gras, puff pastry, vegetable

## DISH Q16678141
- name: Succès
- other names: {"fr": "Succès"}
- countries: (none)
- kinds: pastry

## DISH Q16679109
- name: Tarta de papin
- other names: {"es": "Tarta de papin"}
- countries: (none)
- kinds: sweet pie

## DISH Q16679171
- name: تشيشة
- other names: {"arq": "تشيشة"}
- countries: (none)
- kinds: soup
- ingredients: za'atar

## DISH Q16680140
- name: تيفتين
- other names: {"ar": "تيفتين"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: Red sauce, date, meat, pasta

## DISH Q16680161
- name: تيكربابين
- other names: {"ar": "تيكربابين"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: vegetable oil, condiment, semolina, sauce, Mentha × piperita, Coriandrum sativum, onion

## DISH Q16680163
- name: كويرات
- other names: {"ar": "كويرات"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: garlic, semolina, chili pepper, Mentha pulegium, Thymus vulgaris, Apium graveolens, Anethum graveolens

## DISH Q16680390
- name: Tonburi
- other names: {"zh": "地膚子"}
- description: fruit of Bassia scoparia
- countries: JP
- kinds: fruit
- has Wikipedia article: en, zh

## DISH Q16681961
- name: Nyanya
- description: ancient Russia dish
- countries: RU
- kinds: offal dish
- has Wikipedia article: en

## DISH Q16682389
- name: Oatmeal cookie
- description: drop cookie with oatmeal and raisins mixed into the dough
- countries: (none)
- kinds: cookie
- ingredients: rolled oats

## DISH Q16683197
- name: Oudnin el kadhi
- description: a type of Maghrebian pastry
- countries: (none)
- kinds: pastry
- ingredients: vegetable oil, orange flower water, egg as food, flour, sugar
- has Wikipedia article: en

## DISH Q16683598
- name: Yakimono
- description: Japanese grilled or pan-fried dish
- countries: JP
- kinds: dish

## DISH Q16683902
- name: زاليقو
- other names: {"ar": "زاليقو"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: tomato sauce, green bean, leek, Allium sativum

## DISH Q16686834
- name: Polędwica
- description: Polish pork product
- countries: PL
- kinds: pork dish

## DISH Q16689976
- name: Пьяный хлеб
- other names: {"ru": "пьяный хлеб"}
- countries: (none)
- kinds: bread

## DISH Q16693052
- name: Oat kissel
- description: very much boiled oats
- countries: (none)
- kinds: fermented food, traditional food, kissel
- ingredients: oat flour, rolled oats, sourdough, yeast, drinking water
