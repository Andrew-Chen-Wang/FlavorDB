# Review batch names-038

## DISH Q3007979
- name: Cuñapé
- description: cheese bread from eastern Bolivia
- countries: BO
- kinds: bread, dish, meal
- ingredients: tapioca, cheese

## DISH Q300828
- name: Aal grün
- description: German term: Fish dish of cooked eel with Spreewaldsoße, a light herb sauce
- countries: (none)
- kinds: fish dish
- ingredients: Spreewaldsauce, European eel

## DISH Q30089578
- name: Michałki
- description: Polish peanut pralines
- countries: PL
- kinds: confectionery
- ingredients: peanut, milk powder, rectified spirit, coconut oil, cocoa bean, whey, sugar, chocolate

## DISH Q30090683
- name: Japanese curry rice
- other names: {"zh": "日式咖喱飯"}
- description: Japanese plate dish
- countries: (none)
- kinds: rice and curry, Japanese curry
- ingredients: potato, carrot, cooked rice, beef, curry, onion
- has Wikipedia article: zh

## DISH Q300959
- name: Eel soup
- description: regional food, mainly cooked and ate in East Asia
- countries: DE
- cuisines: German cuisine
- kinds: fish soup, fish dish, dish
- ingredients: eel as food, European eel
- has Wikipedia article: en

## DISH Q3009948
- name: Polkabrokken
- other names: {"nl": "Polkabrokken"}
- countries: (none)
- kinds: candy

## DISH Q30114244
- name: Coconut soup
- description: fruit soup prepared using coconut milk or coconut fruit as a main ingredient
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q3013199
- name: Chocolate ice cream
- other names: {"zh": "巧克力冰淇淋"}
- description: ice cream with natural or artificial chocolate flavoring
- countries: (none)
- kinds: ice cream, chocolate dish
- ingredients: cocoa powder, ice cream
- has Wikipedia article: en, zh

## DISH Q3013426
- name: Dandan noodles
- other names: {"zh": "担担面"}
- description: noodles from Sichuan, China
- countries: CN
- cuisines: Chinese cuisine
- kinds: food, pasta dish
- ingredients: mala, Sesamum indicum, noodle, chili pepper, Coriandrum sativum
- has Wikipedia article: en, zh

## DISH Q30156774
- name: Tornado potato
- other names: {"zh": "龍捲風洋芋片"}
- description: popular street food in South Korea
- countries: KR
- cuisines: South Korean cuisine
- kinds: street food, potato dish
- has Wikipedia article: en, zh

## DISH Q301587
- name: Massaman curry
- other names: {"zh": "瑪莎曼咖哩"}
- description: mild Thai curry
- countries: TH
- kinds: Thai curry
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q3016983
- name: Daube niçoise
- other names: {"fr": "Daube niçoise"}
- countries: (none)
- cuisines: cuisine niçoise
- kinds: dish

## DISH Q3017018
- name: Olio Dauno
- description: extra virgin olive oil from the province of Foggia, Italy
- countries: IT
- kinds: olive oil

## DISH Q30186
- name: Chocolate cake
- other names: {"zh": "巧克力蛋糕"}
- description: cake flavored with chocolate
- countries: (none)
- kinds: dish, cake, dessert
- ingredients: flour, sugar, chocolate
- has Wikipedia article: en, zh

## DISH Q3019074
- name: Wellington
- other names: {"nl": "Wellington"}
- countries: (none)
- kinds: food, cookie

## DISH Q3019208
- name: Dawama
- description: Tunisian pastry
- countries: TN
- kinds: pastry

## DISH Q302169
- name: Balut
- other names: {"zh": "鴨仔蛋"}
- description: developing poultry embryo boiled and eaten
- countries: (none)
- kinds: food, dish
- ingredients: embryo
- has Wikipedia article: en, zh

## DISH Q3026484
- name: Dibi
- description: Senegalese dish
- countries: SN
- kinds: dish, human food
- ingredients: meat, grilled meat, mutton, roast, peanut oil, grilling, Capsicum, Allium, table salt
- has Wikipedia article: en

## DISH Q3028160
- name: Picada
- description: sauce in catalan cuisine
- countries: ES
- kinds: food, mixture, sauce
- has Wikipedia article: en

## DISH Q3028275
- name: Dinde aux marrons
- description: dish
- countries: FR
- kinds: main course

## DISH Q3028666
- name: Neula
- description: Catalan biscuit eaten traditionally in Christmas
- countries: ES
- kinds: biscuit
- ingredients: flour
- has Wikipedia article: en

## DISH Q3028820
- name: Diot
- description: type of sausage
- countries: FR
- kinds: sausage
- has Wikipedia article: en

## DISH Q30312707
- name: Candel
- description: Toffie Caramel with 74 years of History in Uruguay
- countries: UY
- kinds: candy

## DISH Q3031313
- name: Vienna bread
- description: type of bread
- countries: AT
- kinds: food, bread
- ingredients: flour, butter, sugar, water
- has Wikipedia article: en

## DISH Q30314348
- name: Banana pasta
- description: type of pasta made from banana fruit
- countries: (none)
- kinds: pasta, banana dish
- has Wikipedia article: en

## DISH Q3032267
- name: Sirop de Liège
- other names: {"zh": "列日糖浆"}
- description: Belgian jam or jelly-like spread made of evaporated fruit juices
- countries: (none)
- kinds: culinary speciality, spread
- has Wikipedia article: en

## DISH Q3032281
- name: Raisin bread
- description: sweet bread made with raisins and flavored with cinnamon
- countries: (none)
- kinds: sweet bread
- ingredients: grain, raisin
- has Wikipedia article: en

## DISH Q30324437
- name: Hunter's chicken
- other names: {"zh": "猎人炖鸡"}
- description: French chicken dish
- countries: FR
- kinds: dish
- ingredients: chicken as food, sauce chasseur
- has Wikipedia article: en, zh

## DISH Q30324814
- name: Avocado soup
- description: soup prepared using avocados as a primary ingredient
- countries: (none)
- kinds: fruit soup
- ingredients: avocado
- has Wikipedia article: en

## DISH Q30324930
- name: Coventry Godcakes
- description: English pastry
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q30325089
- name: Deep-fried avocado
- description: dish type
- countries: (none)
- kinds: dish, deep-fried food
- ingredients: avocado
- has Wikipedia article: en

## DISH Q30326666
- name: Milanesa
- other names: {"zh": "阿根廷炸肉排"}
- description: a South American variation of an Italian dish
- countries: (none)
- kinds: dish
- ingredients: chicken egg, bread crumbs, meat
- has Wikipedia article: en

## DISH Q3032887
- name: Djenkoume
- description: Togolese tomato cornmeal fritters
- countries: TG
- cuisines: African cuisine
- kinds: dish, side dish
- ingredients: garlic, tomato, ginger, cornmeal, onion, palm oil

## DISH Q3033269
- name: Dobara (Algerian dish)
- countries: DZ
- kinds: dish
- ingredients: cicer arietinum
- has Wikipedia article: en

## DISH Q3034906
- name: Mona de Pascua
- description: Spanish afters
- countries: ES
- kinds: tradition, cake, Easter bread
- ingredients: dough, egg as food
- has Wikipedia article: en

## DISH Q3039538
- name: Drob
- description: Traditional Romanian dish
- countries: RO
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q303956
- name: Zakuski
- other names: {"zh": "凉菜"}
- description: Russian term for hors d'oeuvres/appetizers served before meals
- countries: RU
- kinds: appetizer, meal
- ingredients: cold cut
- has Wikipedia article: en

## DISH Q3041144
- name: Dum Aloo
- description: potato dish
- countries: (none)
- kinds: potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q3041147
- name: Pommes soufflées
- description: dish
- countries: FR
- kinds: potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q3042221
- name: دزيريات
- other names: {"ar": "دزيريات"}
- countries: (none)
- kinds: dish

## DISH Q3042471
- name: Patatnik
- description: Bulgarian potato dish
- countries: BG
- cuisines: Bulgarian cuisine
- kinds: potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q3043512
- name: Kalamay
- description: Filipino sweet delicacy
- countries: PH
- kinds: dish
- ingredients: coconut milk
- has Wikipedia article: en

## DISH Q3044475
- name: Mizuame
- other names: {"zh": "水飴"}
- description: sweetener
- countries: JP
- kinds: syrup, ame
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q3044741
- name: Esqueixada
- description: Catalan fish salad
- countries: ES
- kinds: dish, salad
- ingredients: tomato, olive, salad dressing, Gadus morhua, Welsh onion, Capsicum annuum
- has Wikipedia article: en

## DISH Q3045372
- name: Détrempe
- description: pastry cream
- countries: (none)
- kinds: pastry cream

## DISH Q3046837
- name: Ebi senbei
- countries: JP
- kinds: senbei, prawn cracker

## DISH Q304868
- name: Vol-au-vent
- other names: {"zh": "香菇肉餡奶油酥盒"}
- description: puff pastry
- countries: FR
- kinds: food, pastry, meat pastry
- ingredients: puff pastry
- has Wikipedia article: en

## DISH Q3051278
- name: Potato scone
- other names: {"zh": "土豆司康"}
- description: Scottish potato dish
- countries: (none)
- kinds: griddle scone, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q3051500
- name: Sticky rice in bamboo
- description: Southeast Asian sticky rice dish
- countries: (none)
- kinds: rice dish, rice in bamboo
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q3051726
- name: Usban
- other names: {"zh": "烏斯班腸"}
- description: North African dish of sausage stuffed with rice, herbs, lamb, chopped liver and heart
- countries: DZ, LY
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q3052288
- name: Larb
- other names: {"zh": "生肉沙拉"}
- description: national dish of Laos
- countries: LA
- kinds: salad
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q30524428
- name: Kushiyaki
- description: poultry and non-poultry items, skewered and grilled, in Japanese cuisine
- countries: JP
- kinds: yakimono, skewer
- has Wikipedia article: en

## DISH Q3053172
- name: Empadão
- description: Portuguese traditional dish
- countries: PT
- kinds: potato dish
- has Wikipedia article: en

## DISH Q305329
- name: Stoemp
- description: Dish with stomped potatoes and vegetables
- countries: BE, FR
- kinds: purée, potée, dish
- ingredients: vegetable, potato
- has Wikipedia article: en

## DISH Q3053734
- name: Encebollado nació en Guayaquil, en los astilleros y puertos de la ciudad de Guayaquil.
- description: Enrollado
- countries: EC
- kinds: meal, soup, fish dish
- has Wikipedia article: en

## DISH Q3054106
- name: Hardbrood
- other names: {"fr": "Hardbrood"}
- countries: (none)
- kinds: food, bread roll, hardtack

## DISH Q3054613
- name: Chinese bakery product
- other names: {"zh": "中式糕点"}
- countries: (none)
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q3056003
- name: Erbazzone
- description: Italian savory pie
- countries: IT
- kinds: savoury pie

## DISH Q3057882
- name: Escargots à la provençale
- countries: (none)
- cuisines: cuisine of Provence
- kinds: dish
- ingredients: Helix aspersa aspersa

## DISH Q30587715
- name: Bubur cha cha
- other names: {"zh": "摩摩喳喳"}
- description: Betawi and Malay dessert and breakfast dish
- countries: ID, MY
- kinds: dessert
- has Wikipedia article: en, zh

## DISH Q30587986
- name: Lamprais
- description: Sri Lankan rice dish
- countries: LK
- kinds: dish
- has Wikipedia article: en

## DISH Q3059025
- name: Estocafic
- other names: {"fr": "Estocafic"}
- countries: FR
- kinds: dish
- ingredients: garlic, onion, olive, bell pepper, haddock, potato

## DISH Q3059027
- name: Estofinade
- countries: (none)
- kinds: dish, potato dish
- ingredients: cod

## DISH Q30591503
- name: Hamloaf
- description: baked meat dish
- countries: (none)
- kinds: pork dish
- ingredients: ground pork
- has Wikipedia article: en

## DISH Q30593259
- name: Avocado toast
- other names: {"zh": "鳄梨吐司"}
- description: type of open sandwich consisting of toast with mashed avocado
- countries: US
- kinds: open sandwich
- ingredients: avocado, toast
- has Wikipedia article: en, zh

## DISH Q3059368
- name: Eton mess
- other names: {"zh": "伊頓混亂"}
- description: English dessert
- countries: GB
- kinds: dessert
- ingredients: strawberry, whipped cream, meringue
- has Wikipedia article: en, zh

## DISH Q30594208
- name: Cabbage stew
- description: dish
- countries: (none)
- kinds: guiso
- has Wikipedia article: en

## DISH Q30599640
- name: Roscas
- description: type of pastry
- countries: PH
- kinds: pastry
- ingredients: cereals' and pseudocereals' flour, egg as food, lard, Pimpinella anisum, sugar
- has Wikipedia article: en

## DISH Q30599785
- name: Afang
- description: vegetable-based delicacy originating from South-South Nigeria, usually eaten with starch
- countries: NG
- cuisines: African people
- kinds: dish, human food, soup
- ingredients: Okazi soup, onion, waterleaf, crayfish, palm oil, beef, water, fish
- has Wikipedia article: en

## DISH Q30599933
- name: Editan
- description: vegetable soup that originates from the Efik People
- countries: NG
- kinds: soup
- ingredients: Catharanthus roseus, meat, waterleaf, crayfish, palm oil, stockfish, Capsicum
- has Wikipedia article: en

## DISH Q30607840
- name: Gulgula
- description: traditional sweet snack in north India
- countries: IN
- kinds: sweet dish, snack
- ingredients: wheat flour, jaggery
- has Wikipedia article: en

## DISH Q30612547
- name: Sandie
- description: type of sugar cookie; shortbread cookie
- countries: (none)
- kinds: shortbread, sugar cookie
- has Wikipedia article: en

## DISH Q3062329
- name: Hampen
- other names: {"zh": "半片"}
- description: food in Japan
- countries: JP
- kinds: fish surimi
- ingredients: fish
- has Wikipedia article: en

## DISH Q30634372
- name: Baechu-kimchi
- other names: {"zh": "辣白菜泡菜"}
- description: napa cabbage kimchi
- countries: (none)
- kinds: Kimchi
- has Wikipedia article: en

## DISH Q30635290
- name: Chopped cheese
- description: sandwich
- countries: US
- kinds: sandwich
- ingredients: hoagie roll, American cheese, beef
- has Wikipedia article: en

## DISH Q30635685
- name: Malfouf salad
- description: Lebanese cabbage salad
- countries: (none)
- kinds: cabbage salad
- has Wikipedia article: en

## DISH Q30635944
- name: Sweet potato salad
- description: Arab salad
- countries: (none)
- kinds: salad, potato dish
- has Wikipedia article: en

## DISH Q30636888
- name: Ojingeo-jeot
- description: jeotgal made by salting and fermenting thinly sliced squid
- countries: (none)
- kinds: jeotgal, salted squid
- has Wikipedia article: en

## DISH Q30637566
- name: Omegi-tteok
- description: Korean rice cake variety
- countries: (none)
- kinds: tteok
- ingredients: Setaria italica
- has Wikipedia article: en

## DISH Q3064423
- name: Fafaru
- description: Polynesian fermented fish dish
- countries: (none)
- kinds: fermented food, fish dish
- ingredients: tuna, shrimp and prawn as food

## DISH Q3064595
- name: Faisan aux chicons
- other names: {"fr": "Faisan aux chicons"}
- countries: (none)
- kinds: dish
- ingredients: peanut oil, pheasant, parsley, Belgian endive

## DISH Q30646347
- name: Ugeoji
- description: trimmed outer leaves or stems of cabbage, radish, and other greens
- countries: (none)
- kinds: food ingredient
- has Wikipedia article: en

## DISH Q30646348
- name: Doenjang-guk
- description: soybean paste soup
- countries: (none)
- kinds: guk
- has Wikipedia article: en

## DISH Q3064798
- name: Fallue
- description: culinary specialty of Normandy
- countries: FR
- kinds: pastry, brioche

## DISH Q3064828
- name: Faluche
- description: Typical bread of Nord-Pas de Calais
- countries: FR
- kinds: bread, white bread
- ingredients: olive oil, flour, milk, baker's yeast
- has Wikipedia article: en

## DISH Q3065399
- name: Fanesca
- other names: {"zh": "圣周春汤"}
- description: Ecuadorian soup
- countries: EC
- kinds: fish soup
- ingredients: Cucurbita ficifolia
- has Wikipedia article: en, zh

## DISH Q3065492
- name: Maafe
- other names: {"zh": "Maafe"}
- description: staple stew or sauce, originating from Mali and popular in West Africa, consisting of meat, tomatoes, onions, garlic, cabbage, leaf or root vegetables, and peanuts
- countries: ML
- kinds: peanut stew, stew
- ingredients: meat

## DISH Q3066793
- name: Farcement
- countries: FR
- kinds: culinary speciality, potato dish

## DISH Q3066795
- name: Farci poitevin
- other names: {"fr": "farci poitevin"}
- countries: FR
- kinds: food
- ingredients: cabbage, pork belly, Spinacia oleracea

## DISH Q3066798
- name: Stuffed vegetable
- description: stuffed vegetable dish
- countries: (none)
- kinds: food, stuffed food, vegetable dish
- ingredients: stuffing, Brassica oleracea var. capitata, leaf, vegetable, rice, flower
- has Wikipedia article: en

## DISH Q3066802
- name: Farcidure
- description: French savory tart
- countries: (none)
- kinds: potato dish

## DISH Q3066921
- name: Farinade
- other names: {"fr": "Farinade"}
- countries: (none)
- kinds: potato dish

## DISH Q30671978
- name: Java Rice
- description: fried rice dish from the Philippines
- countries: PH
- kinds: dish, fried rice
- has Wikipedia article: en

## DISH Q30672119
- name: Mee Siput
- description: Malaysian snack
- countries: MY
- cuisines: Malay cuisine
- kinds: cookie, snack
- has Wikipedia article: en

## DISH Q30672242
- name: Phá lấu
- other names: {"zh": "拍滷"}
- description: Vietnamese snack of braised pork offal
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q30673009
- name: Mihidana
- description: Indian sweet
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q30680430
- name: Ghandi Bread
- description: traditional Iranian bread
- countries: IR
- kinds: bread
- has Wikipedia article: en

## DISH Q3068074
- name: Felfel mehchi
- description: North African version of stuffed peppers
- countries: LY, TN
- kinds: stuffed peppers

## DISH Q30681252
- name: Khao khluk kapi
- description: Thai cuisine
- countries: TH
- kinds: Thai cuisine, human food, rice dish, à la carte, list of Thai dishes
- ingredients: Phaseolus vulgaris, Allium sativum, lime, table salt, sugar, mango, black pepper, onion, jasmine rice, palm sugar, shrimp paste, fish sauce, dried shrimp, pork, chili pepper, egg as food, olive oil
- has Wikipedia article: en

## DISH Q30682135
- name: Stew peas
- description: Jamaican dish
- countries: JM
- cuisines: Jamaican cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q3068450
- name: Feqqas
- countries: MA
- kinds: human food, cookie
- ingredients: egg as food, yeast, flour, sugar

## DISH Q30687433
- name: Steamed cheeseburger
- description: type of hamburger originating in central Connecticut, U.S.
- countries: US
- kinds: cheeseburger
- has Wikipedia article: en

## DISH Q3068890
- name: Licitar
- other names: {"zh": "克罗地亚姜饼"}
- description: richly decorated gingerbread cookies traditional for Central and South-Eastern Europe
- countries: HR
- kinds: pastry, Slovenian cuisine
- has Wikipedia article: en

## DISH Q30692629
- name: Alu tama
- description: Nepali soup
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q30698
- name: Sour cherry soup
- description: slightly sweet soup made with sour cream, sugar, and whole fresh sour cherries, and served chilled
- countries: HU
- cuisines: Hungarian cuisine
- kinds: soup
- has Wikipedia article: en

## DISH Q3070462
- name: Rasol
- description: Romanian stew
- countries: RO
- kinds: stew
- ingredients: meat
- has Wikipedia article: en

## DISH Q30715784
- name: Napham
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q3072703
- name: Fion
- other names: {"fr": "fion"}
- countries: (none)
- kinds: custard tart

## DISH Q3073449
- name: Flasona
- other names: {"ca": "flasona"}
- countries: (none)
- kinds: sweet pie

## DISH Q30737424
- name: Trulle
- description: black pudding from Nice, France stuffed with chard
- countries: FR
- cuisines: cuisine niçoise
- kinds: blood sausage

## DISH Q30737843
- name: French tacos
- other names: {"zh": "法国塔可"}
- description: fast food recipe created in France
- countries: FR
- kinds: dish
- ingredients: tortilla, fries
- has Wikipedia article: en

## DISH Q30738187
- name: Salade piémontaise
- other names: {"fr": "salade piémontaise"}
- countries: (none)
- kinds: dish

## DISH Q30738781
- name: Potée berrichonne
- other names: {"zh": "贝里大杂烩"}
- countries: FR
- kinds: dish
- ingredients: pork

## DISH Q30738882
- name: Potée savoyarde
- countries: (none)
- kinds: dish
- ingredients: pork, potato

## DISH Q30739481
- name: Macarons de Nancy
- countries: (none)
- kinds: macaron

## DISH Q30739641
- name: Aubergines à la bonifacienne
- description: an aubergine-based dish from Corsica
- countries: FR
- kinds: eggplant dish
- ingredients: eggplant

## DISH Q30739675
- name: Aubergines à la sarde
- other names: {"fr": "aubergines à la sarde"}
- description: an aubergine-based dish from Sardinia
- countries: (none)
- kinds: eggplant dish

## DISH Q30739922
- name: Macarons des Dominicains
- other names: {"fr": "Macarons des Dominicains"}
- countries: (none)
- kinds: macaron

## DISH Q3074271
- name: Scotch pie
- description: type of meat pie
- countries: (none)
- kinds: meat pie, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q30744378
- name: Ñaari cin
- countries: (none)
- kinds: rice dish

## DISH Q30745703
- name: Akpan
- description: type of yogurt
- countries: BJ, TG
- kinds: yogurt
- ingredients: maize, milk
- has Wikipedia article: en

## DISH Q3074713
- name: Flûte
- other names: {"fr": "flûte"}
- countries: FR
- kinds: white bread

## DISH Q30748759
- name: Feuillantine
- other names: {"ca": "feuillantine"}
- countries: (none)
- kinds: dish
- ingredients: puff pastry

## DISH Q30749722
- name: Tennis cake
- other names: {"fr": "Tennis cake"}
- countries: (none)
- kinds: cake

## DISH Q3075310
- name: Stock
- other names: {"zh": "高湯"}
- description: flavored liquid extracted from ingredients and used as a base in cooking
- countries: (none)
- kinds: dish, broth
- ingredients: water
- has Wikipedia article: en, zh

## DISH Q3075365
- name: Molten chocolate cake
- other names: {"zh": "熔岩巧克力蛋糕"}
- description: chocolate cake with a liquid chocolate center
- countries: (none)
- kinds: chocolate cake, dessert
- ingredients: sponge cake, chocolate cake, chocolate
- has Wikipedia article: en, zh

## DISH Q30765642
- name: Kalou
- other names: {"fr": "kalou"}
- countries: (none)
- kinds: pastry

## DISH Q3077413
- name: Loukaniko
- description: type of Greek sausage
- countries: GR
- kinds: sausage
- has Wikipedia article: en

## DISH Q3080069
- name: Fourme de Rochefort
- countries: FR
- kinds: cheese, pressed uncooked cheese, French cheese, farmstead cheese
- ingredients: cow's milk

## DISH Q3080161
- name: Foutou banane
- countries: CI
- kinds: culinary speciality
- ingredients: cooking banana, cassava

## DISH Q3080398
- name: Fraise Melba
- other names: {"fr": "fraise Melba"}
- countries: (none)
- kinds: dessert
- ingredients: strawberry, vanilla ice cream, chantilly cream

## DISH Q3080422
- name: Framboisier
- description: French dessert
- countries: FR
- kinds: cake
- ingredients: raspberry

## DISH Q3080606
- name: Pescado frito
- other names: {"zh": "西班牙炸魚"}
- description: traditional dish from the Southern coasts of Spain
- countries: (none)
- kinds: fried fish, fish dish
- ingredients: common cuttlefish, Merluccius merluccius, Galeorhinus galeus, European anchovy, Wedge sole, Teuthida
- has Wikipedia article: en

## DISH Q3081857
- name: Tatws Pum Munud
- description: Welsh stew with smoked bacon, stock, potatoes and other vegetables
- countries: (none)
- kinds: potato dish
- has Wikipedia article: en

## DISH Q3082973
- name: Mesclun
- description: salad mix
- countries: FR
- cuisines: cuisine niçoise
- kinds: dish, salad
- ingredients: Cichorium intybus, radicchio, garden chervil, Cichorium endivia, corn salad, Portulaca oleracea, Eruca vesicaria subsp. sativa, Lactuca sativa, Spinacia oleracea
- has Wikipedia article: en

## DISH Q3087517
- name: Frescati
- other names: {"fr": "frescati"}
- countries: (none)
- kinds: entremet

## DISH Q3087607
- name: Sweetmeat
- other names: {"zh": "甜品"}
- description: sweet food or confection with a high sugar content, including candies, chocolates, and other sugar-based treats
- countries: (none)
- kinds: junk food, confectionery
- ingredients: sugar candy
- has Wikipedia article: en

## DISH Q3087626
- name: Fricandeau
- description: traditional French meat dish
- countries: (none)
- kinds: dish, pork, cut of beef
- ingredients: pork
- has Wikipedia article: en

## DISH Q3087627
- name: Fricassée au tourain
- other names: {"zh": "盖浇汤"}
- countries: (none)
- kinds: dish

## DISH Q3087634
- name: Mud pie
- description: chocolate-based dessert pie
- countries: US
- cuisines: cuisine of the Southern United States
- kinds: sweet pie
- ingredients: chocolate
- has Wikipedia article: en

## DISH Q30880380
- name: Polenta d'Ivrea
- other names: {"it": "Polenta d'Ivrea"}
- countries: IT
- kinds: dessert

## DISH Q30881075
- name: Charlotte alla milanese
- other names: {"it": "Charlotte alla milanese"}
- countries: IT
- kinds: dessert
- ingredients: candied fruit, raisin, apple

## DISH Q30888235
- name: Coniglio all’ischitana
- description: Italian rabbit dish
- countries: IT
- kinds: rabbit dish
- ingredients: rabbit meat

## DISH Q30888642
- name: Carnikava lamprey
- countries: LV
- kinds: national dish

## DISH Q30889177
- name: Strufoli di carnevale
- other names: {"it": "Strufoli di carnevale"}
- countries: IT
- kinds: dessert

## DISH Q3088941
- name: Tiropita
- description: Greek layered pastry food
- countries: GR
- kinds: food, pastry, pie
- ingredients: phyllo
- has Wikipedia article: en

## DISH Q30889458
- name: Torta di fioretto
- description: Italian dessert flavored with fioretto
- countries: IT
- cuisines: cuisine of Valtellina
- kinds: cake

## DISH Q30890348
- name: Amich
- description: Armenian traditional dish
- countries: AM
- kinds: dish, prepared food
- ingredients: turkey meat, chicken as food, dried fruit, rice

## DISH Q30891233
- name: Kyur
- description: national dish of Kalmyks
- countries: (none)
- kinds: national dish

## DISH Q30897054
- name: Dragée
- countries: (none)
- kinds: dosage form, dragée

## DISH Q30901851
- name: Campero malagueño
- description: food
- countries: ES
- kinds: meal, bocadillo

## DISH Q3090471
- name: Sfenj
- description: bakery Product
- countries: (none)
- kinds: baked good, doughnut
- ingredients: oil, flour
- has Wikipedia article: en

## DISH Q3090473
- name: Ftira
- other names: {"zh": "伊阿弗提亚"}
- description: small sourdough bread integral to Maltese culture
- countries: MT
- kinds: flatbread, sourdough bread
- has Wikipedia article: en

## DISH Q30908893
- name: Carrot gingerbread
- countries: (none)
- kinds: Ersatz good, carrot cake

## DISH Q30912986
- name: Domtorentje
- other names: {"pl": "Domtorentje"}
- countries: (none)
- kinds: pastry

## DISH Q3091352
- name: Pastéis de Belém
- description: confectionery store in Belém, Lisbon, Portugal
- countries: (none)
- kinds: cultural heritage, pastry, confectionery store

## DISH Q3091371
- name: Fèves au lard
- description: traditional Québécois dish
- countries: (none)
- kinds: recipe, baked beans
- ingredients: white bean, fatback, Red bean, maple syrup, molasses, mustard
- has Wikipedia article: en

## DISH Q30918987
- name: Abisinios
- countries: ES
- kinds: dessert, frying
- ingredients: pastry cream

## DISH Q30919660
- name: Cửa Khe fish sauce
- other names: {"zh": "溪門魚露"}
- countries: VN
- cuisines: Central Vietnamese cuisine
- kinds: designation of origin, nước mắm, fish sauce
- has Wikipedia article: zh

## DISH Q30921814
- name: Xiaorou
- other names: {"zh": "水晶肴肉"}
- countries: CN
- cuisines: Chinese cuisine
- kinds: aspic
- has Wikipedia article: zh

## DISH Q30922465
- name: 八事五寸人参
- other names: {"ja": "八事五寸人参"}
- countries: (none)
- kinds: carrot

## DISH Q30923003
- name: Shark burger
- countries: (none)
- ingredients: shark as food

## DISH Q30924177
- name: ムンティギ
- other names: {"ja": "ムンティギ"}
- countries: KR
- kinds: saeng-yukhoe

## DISH Q30925424
- name: Kameyama ramen
- countries: (none)
- kinds: miso ramen

## DISH Q30926481
- name: Otchahoi
- description: Japanese noodle dish
- countries: JP
- kinds: noodle dish
- has Wikipedia article: en

## DISH Q30926611
- name: Kizaca
- other names: {"pt": "Kizaca"}
- description: Traditional Angolan dish
- countries: (none)
- cuisines: African cuisine
- kinds: dish, vegetable
- ingredients: peanut

## DISH Q3092677
- name: Popiah
- other names: {"zh": "润饼卷"}
- description: A Chinese food often eaten at Ching Ming Festival; known as lumpia in the Philippines and Indonesia
- countries: (none)
- kinds: wrap
- has Wikipedia article: en, zh

## DISH Q30927500
- name: Shirunashi tantanmen
- countries: (none)
- kinds: dandan noodles

## DISH Q30927733
- name: Slöngukaka
- other names: {"pt": "Slöngukaka"}
- countries: (none)
- kinds: Swiss roll

## DISH Q3094706
- name: Tarte au sucre de Pérouges
- countries: FR
- kinds: dessert, sweet pie

## DISH Q3094707
- name: Tarte Bressane
- countries: FR
- kinds: tart
- ingredients: egg as food, flour, cream, sugar, milk

## DISH Q3094709
- name: Bánh tráng
- other names: {"zh": "餅𣴣"}
- description: rice paper wrappers used in Vietnamese cuisine
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: food ingredient, bánh, wafer paper
- ingredients: rice flour
- has Wikipedia article: en, zh

## DISH Q3094712
- name: Galette-saucisse
- other names: {"zh": "烤肠煎饼"}
- description: French Foods
- countries: FR
- kinds: buckwheat pancake
- ingredients: sausage, buckwheat pancake
- has Wikipedia article: en

## DISH Q30947497
- name: Goubangzi smoked chicken
- other names: {"zh": "沟帮子熏鸡"}
- description: chicken dish originated from Goubangzi, Beizhen, Jinzhou, Liaoning, China
- countries: (none)
- kinds: smoked chicken
- has Wikipedia article: zh

## DISH Q3095008
- name: Gamja-ongsimi
- description: Korean dough soup
- countries: (none)
- kinds: sujebi, potato dish
- ingredients: dumpling
- has Wikipedia article: en

## DISH Q3095449
- name: Gardiane de taureau
- description: dish from Camargue
- countries: FR
- kinds: dish, stew
- ingredients: Camargue cattle, red wine

## DISH Q30957511
- name: Логаза
- other names: {"ru": "логаза"}
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: porridge

## DISH Q30957551
- name: Gombovtsi
- description: Ukrainian dessert
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q3097864
- name: Espetada
- description: technique of cooking food on skewers
- countries: PT
- kinds: dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q3098712
- name: Gazpachos extremeños
- countries: (none)
- cuisines: Extremaduran cuisine
- kinds: gazpacho
- ingredients: tomato, Pimentón de la Vera, egg yolk, bread

## DISH Q3099247
- name: Sole-cake
- description: traditional Mongolian biscuit
- countries: MN
- kinds: cake
- ingredients: fat
- has Wikipedia article: en

## DISH Q3099350
- name: L'Étivaz
- description: Swiss alp cheese
- countries: CH
- kinds: Swiss cheeses, pressed cooked cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q3099408
- name: Gaufre aux fruits
- description: style of waffle from Liège, Belgium
- countries: BE
- kinds: waffle, dish, fruit
- ingredients: dough

## DISH Q3099411
- name: Dunkirk waffle
- description: round hard waffle
- countries: (none)
- kinds: waffle

## DISH Q3099412
- name: Lille filled waffle
- countries: (none)
- kinds: food, cookie

## DISH Q3099553
- name: Mrouzia
- description: Prunes sour sweet tajine
- countries: MA
- kinds: dish
- ingredients: ras el hanout, lamb meat, almond, cinnamon, honey
- has Wikipedia article: en

## DISH Q3104721
- name: Cioppino
- other names: {"zh": "意式雜錦海鮮湯"}
- description: fish stew originating in San Francisco
- countries: US
- cuisines: cuisine of the United States, Italian cuisine
- kinds: seafood dish, fish dish
- ingredients: tomato, seafood, wine, olive oil, onion, Allium sativum, bread
- has Wikipedia article: en, zh

## DISH Q3104777
- name: Ghapama
- other names: {"zh": "南瓜焗飯"}
- description: Armenian stuffed pumpkin dish
- countries: AM
- kinds: dish, stew
- ingredients: pumpkin, rice
- has Wikipedia article: en, zh

## DISH Q3104906
- name: Ghiveci
- description: Romanian vegetable stew
- countries: RO
- kinds: stew
- ingredients: garlic, tomato, onion

## DISH Q3105960
- name: Gilda
- description: kind of pincho (northern Spanish snack)
- countries: ES, FR
- cuisines: Basque cuisine
- kinds: dish, appetizer
- ingredients: olive, European anchovy, chili pepper, vinegar
- has Wikipedia article: en

## DISH Q3106401
- name: Tripoux
- description: French sheep tripe dish
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q31073311
- name: Flam d'oli
- other names: {"ca": "flam d'oli"}
- countries: (none)
- kinds: food, dessert
- ingredients: olive oil

## DISH Q31076296
- name: Sikbāj
- description: Arab dish
- countries: SA
- cuisines: Arab cuisine
- kinds: dish

## DISH Q31077566
- name: إبراهيمية
- other names: {"ar": "إبراهيمية"}
- countries: (none)
- kinds: dish

## DISH Q31077570
- name: جرجانية
- other names: {"ar": "جرجانية"}
- countries: (none)
- kinds: dish

## DISH Q31077574
- name: حماضية
- other names: {"ar": "حماضية"}
- countries: (none)
- kinds: dish

## DISH Q31078296
- name: Oreokake
- other names: {"nb": "Oreokake"}
- countries: (none)
- kinds: cake
- ingredients: whipped cream, Oreo

## DISH Q3108252
- name: Plombières
- other names: {"zh": "普隆比耶尔冰淇淋"}
- description: style of ice cream
- countries: FR
- kinds: ice cream
- has Wikipedia article: en

## DISH Q3108258
- name: Hawaian shave ice
- other names: {"zh": "剉冰 (冰品)"}
- description: Ice-based dessert
- countries: (none)
- kinds: shaved ice
- ingredients: ice
- has Wikipedia article: en

## DISH Q31086812
- name: Puruvesi vendace
- description: Vendace caught in the Puruvesi lake, Finland
- countries: FI
- kinds: dish
- ingredients: Coregonus albula

## DISH Q3108857
- name: قلوب
- other names: {"ar": "قلوب"}
- countries: TN
- kinds: dish
- ingredients: pumpkin seed, sunflower seed

## DISH Q3108889
- name: Kusa mochi
- other names: {"zh": "草餅"}
- description: type of mochi
- countries: JP
- cuisines: Japanese cuisine
- kinds: mochi, wagashi
- ingredients: Helichrysum luteoalbum, mochi
- has Wikipedia article: en, zh

## DISH Q3109041
- name: Kaki no tane
- other names: {"zh": "柿種"}
- description: Japanese snack food
- countries: JP
- kinds: snack, Beika, rice cracker
- ingredients: peanut
- has Wikipedia article: en, zh

## DISH Q31092813
- name: Kakaós csiga
- other names: {"hu": "kakaós csiga"}
- countries: HU
- kinds: pastry

## DISH Q31093402
- name: Kapusznyíka
- other names: {"hu": "kapusznyíka"}
- countries: SK
- kinds: food

## DISH Q3111664
- name: Goumo
- other names: {"de": "Goumo"}
- countries: (none)
- kinds: dish

## DISH Q3116770
- name: Griouech
- description: Griwech is a popular Algerian dessert that reflects the country's appreciation of elaborate and savory sweets. This dish consists of fried pastry that has been carefully formed into a flower or knot.
- countries: DZ
- kinds: pastry

## DISH Q3116870
- name: Groaty pudding
- description: Traditional English food
- countries: GB
- kinds: savory pudding
- ingredients: groat
- has Wikipedia article: en

## DISH Q31172805
- name: Kacimuih
- description: Indonesia traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack
- ingredients: cassava, Cocos nucifera, sugar

## DISH Q31173018
- name: Sapo tahu
- description: Tionghoa tofu dish
- countries: ID
- kinds: dish
- ingredients: chicken as food, seafood, tofu, vegetable, garlic, vegetable oil, oyster sauce, cooking oil, soy sauce, sesame oil, Brassica rapa subsp. chinensis, onion, table salt, Brassica oleracea var. botrytis, carrot
- has Wikipedia article: en

## DISH Q31173190
- name: Jengkol stew
- description: Indonesian dish
- countries: ID
- kinds: dish
- ingredients: nutmeg, table salt, garlic, clove, Archidendron pauciflorum, peppercorn, palm sugar, Aleurites moluccanus, red onion, soy sauce

## DISH Q31173193
- name: Sparrow satay
- description: types of satay from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay
- ingredients: Estrildidae

## DISH Q31173369
- name: Gulai taboh
- other names: {"id": "gulai taboh"}
- countries: ID
- kinds: gulai
- ingredients: coconut milk, maize

## DISH Q31173508
- name: Taichan satay
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, satay
- ingredients: chicken as food, Allium ascalonicum, Citrus × aurantiifolia, chili pepper, peanut, table salt
- has Wikipedia article: en

## DISH Q31173765
- name: Tauto Pekalongan
- description: Type of soto dish with a tauco mixture
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, soup, soto

## DISH Q31177479
- name: Saeng-yukhoe
- countries: (none)
- kinds: hoe
- ingredients: raw meat

## DISH Q31178619
- name: Geonjin noodles
- description: noodles (South Korean dish)
- countries: (none)
- kinds: dish
- ingredients: soy bean, wheat flour

## DISH Q31179347
- name: Yangnyeom chicken
- other names: {"zh": "韩式辣酱炸鸡"}
- description: Korean fried chicken with spicy sauce
- countries: KR
- cuisines: South Korean cuisine
- kinds: Korean fried chicken
- ingredients: roast chicken
- has Wikipedia article: en

## DISH Q31180459
- name: Eoriguljeot
- description: jeotgal made from oysters
- countries: (none)
- kinds: jeotgal

## DISH Q31181574
- name: Vanilice
- other names: {"fr": "vanilice"}
- countries: (none)
- kinds: dessert

## DISH Q31185698
- name: Sinalau
- description: smoked meat dish of the indigenous people in Sabah, Malaysia
- countries: MY
- kinds: meat dish, smoked meat
- has Wikipedia article: en

## DISH Q31186302
- name: Jabukovača
- description: alcohol spirit made of apples
- countries: BA, HR, ME, RS
- kinds: liquor
- ingredients: apple

## DISH Q31198650
- name: Osijek knödel
- description: type of knödel
- countries: HR
- cuisines: Croatian cuisine
- kinds: knödel

## DISH Q31203818
- name: Bhoi
- countries: ID
- cuisines: Acehnese cuisine, Indonesian cuisine
- kinds: cookie, dessert, dish
- ingredients: egg as food, vanilla, white sugar, wheat flour, sodium bicarbonate

## DISH Q3120724
- name: Gulas
- description: dish
- countries: (none)
- kinds: dish

## DISH Q31213279
- name: Лямешка
- other names: {"be": "Лямешка"}
- countries: (none)
- kinds: dish

## DISH Q3122402
- name: Lobster roll
- other names: {"zh": "龙虾卷"}
- description: Made of lobster meat served on a grilled hot dog-style bun. The filling may also contain butter, lemon juice, salt, black pepper, mayonnaise, diced celery or scallion.
- countries: US
- kinds: sandwich
- ingredients: lobster, hot dog bun
- has Wikipedia article: en, zh

## DISH Q3122799
- name: Saint-Epvre
- description: French cake
- countries: FR
- kinds: cake

## DISH Q3122800
- name: White wine cookies
- countries: (none)
- kinds: Gâteau au vin

## DISH Q3122805
- name: Walnut cake
- other names: {"zh": "格勒诺布尔核桃蛋糕"}
- description: cake made of walnuts
- countries: (none)
- kinds: cake

## DISH Q3122808
- name: Gâteau de Saint-Genix
- countries: (none)
- kinds: cake

## DISH Q3122810
- name: Cake Creusois
- description: French cake from Creuse
- countries: (none)
- kinds: cake

## DISH Q3122812
- name: Gâteau de Verviers
- other names: {"fr": "Gâteau de Verviers"}
- countries: (none)
- kinds: cake
- ingredients: dough

## DISH Q3122815
- name: Gâteau patate
- other names: {"es": "Gâteau patate"}
- countries: (none)
- kinds: cake
- ingredients: Sweet potato

## DISH Q3122937
- name: Kakuni
- other names: {"zh": "角煮"}
- description: Japanese braised pork dish
- countries: JP
- kinds: nimono, pork dish
- ingredients: bacon
- has Wikipedia article: en, zh

## DISH Q3123047
- name: Smörgåstårta
- other names: {"zh": "三明治蛋糕"}
- description: Swedish dish made of bread and creamy fillings
- countries: US
- cuisines: Swedish cuisine, Finnish cuisine, Icelandic cuisine, Estonian cuisine
- kinds: sandwich
- ingredients: open sandwich
- has Wikipedia article: en

## DISH Q3125478
- name: Jodenkoek
- description: Dutch big, flat, round shortbread cookie
- countries: (none)
- kinds: food, cookie
- has Wikipedia article: en

## DISH Q3125526
- name: Smoked haddock
- description: Food preparation of the fish haddock
- countries: (none)
- kinds: smoked fish, fish dish

## DISH Q3126044
- name: Boiled sweet
- countries: (none)
- kinds: candy

## DISH Q312766
- name: Alaskan ice cream
- other names: {"zh": "愛斯基摩冰淇淋"}
- description: Athabaskan dessert
- countries: US
- kinds: ice cream-based dessert
- ingredients: berry, fish
- has Wikipedia article: en, zh

## DISH Q31281129
- name: Vassgraut
- other names: {"nn": "vassgraut"}
- countries: (none)
- kinds: porridge

## DISH Q3129784
- name: Salchipapa
- description: fast food from South America
- countries: PE
- kinds: meal, fast food, street food, potato dish
- ingredients: sauce, chili pepper, fries, sausage
- has Wikipedia article: en

## DISH Q3133335
- name: Tombet
- description: vegetable dish from Majorca
- countries: ES
- kinds: potato dish
- ingredients: eggplant, bell pepper, fries, tomato
- has Wikipedia article: en

## DISH Q3133597
- name: Sosatie
- description: traditional South African dish of meat cooked on skewers
- countries: ZA
- kinds: skewer, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q31352561
- name: Tom yum kung
- other names: {"zh": "冬阴功"}
- description: Thai soup cooked with prawn
- countries: TH
- kinds: soup, tom yum
- has Wikipedia article: en, zh

## DISH Q3135358
- name: Black sesame soup
- other names: {"zh": "黑芝麻糊"}
- description: Chinese dessert
- countries: CN
- kinds: soup, dish
- has Wikipedia article: en, zh

## DISH Q3136951
- name: Sobao
- description: Spanish delicacy
- countries: ES
- kinds: sponge cake
- ingredients: sugar
- has Wikipedia article: en

## DISH Q3138826
- name: Hmiss
- description: Algerian salad of peppers
- countries: DZ
- kinds: salad
- has Wikipedia article: en

## DISH Q3139573
- name: Homard à l'américaine
- other names: {"zh": "美國龍蝦 (餐點)"}
- description: French lobster dish
- countries: FR
- kinds: seafood dish
- ingredients: lobster
- has Wikipedia article: zh

## DISH Q3141050
- name: Chicago-style hot dog
- other names: {"zh": "芝加哥式热狗"}
- description: regional variation of hot dog
- countries: US
- cuisines: cuisine of the United States
- kinds: hot dog
- ingredients: sport pepper, poppy seed bun, Chicago-style relish, tomato, Vienna Beef, celery salt, onion, pickled cucumber, Vienna sausage, mustard
- has Wikipedia article: en, zh

## DISH Q3141053
- name: Michigan hot dog
- description: steamed beef hot dog on a steamed bun topped with a meaty sauce, originating from Plattsburgh, New York, US
- countries: US
- kinds: hot dog
- ingredients: hot dog bun, hot dog
- has Wikipedia article: en

## DISH Q3141360
- name: Kashiwa mochi
- other names: {"zh": "柏饼"}
- description: mochi wrapped in kashiwa (Japanese emperor oak, Quercus dentata) leaves
- countries: (none)
- kinds: mochi, wagashi
- ingredients: jōshinko, leaf
- has Wikipedia article: en, zh

## DISH Q3141745
- name: Hrous
- description: Tunisian spicy pepper condiment
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q3142820
- name: Huile d'olive de Nice
- other names: {"fr": "Huile d'olive de Nice"}
- countries: FR
- kinds: olive oil

## DISH Q3142822
- name: Huile d'Olive de Nîmes
- countries: FR
- kinds: olive oil

## DISH Q3142823
- name: Huile d'olive de Nyons
- description: an olive oil from Nyons protected by a registered designation of origin
- countries: FR
- kinds: olive oil

## DISH Q3142980
- name: Huitres creuses de Denneville grillées
- other names: {"fr": "Huitres creuses de Denneville grillées"}
- countries: (none)
- kinds: dish, oyster dish

## DISH Q3143540
- name: Huîtres chaudes au champagne
- other names: {"fr": "huîtres chaudes au champagne"}
- countries: FR
- kinds: dish

## DISH Q314489
- name: Thüringer Klöße
- description: potato dish
- countries: (none)
- kinds: raspeball, potato dish

## DISH Q314491
- name: Franzbrötchen
- description: food
- countries: DE
- kinds: pastry, viennoiserie
- ingredients: butter, cinnamon
- has Wikipedia article: en

## DISH Q314500
- name: Ragout fin
- description: food
- countries: FR
- kinds: food, soup, veal dish
- ingredients: veal
- has Wikipedia article: en

## DISH Q314529
- name: Hasenpfeffer
- other names: {"zh": "德国炖菜"}
- description: stew of hare with blood
- countries: DE
- kinds: stew
- ingredients: hare, rabbit
- has Wikipedia article: en

## DISH Q314588
- name: Erbswurst
- other names: {"de": "Erbswurst"}
- description: Processed pea-based food product
- countries: (none)
- kinds: pea soup, food preserve
- ingredients: pea soup
- has Wikipedia article: en

## DISH Q31459063
- name: Парварда
- other names: {"ru": "Парварда"}
- countries: (none)
- kinds: confectionery
- ingredients: lemon juice, flour, sugar, water

## DISH Q314612
- name: Schläsches Himmelreich
- countries: (none)
- cuisines: Silesian cuisine
- kinds: dish, meat dish
- ingredients: pork belly, raspeball, dried fruit, lemon zest, cinnamon

## DISH Q3146449
- name: Steak au poivre
- description: French dish
- countries: FR
- kinds: beef dish
- ingredients: filet mignon, black pepper
- has Wikipedia article: en

## DISH Q315295
- name: Eierschecke
- description: confectionery speciality from Saxony and Thuringia
- countries: (none)
- kinds: sheet cake, Kuchen
- ingredients: quark, flour, butter, sugar, milk
- has Wikipedia article: en

## DISH Q315508
- name: Wurstsalat
- description: sausage salad
- countries: DE
- kinds: salad
- ingredients: onion, cooking oil, sausage, vinegar
- has Wikipedia article: en

## DISH Q3160836
- name: Jambon-beurre
- other names: {"zh": "火腿黄油三明治"}
- description: French sandwich made of a baguette sliced open, spread with butter, and filled with slices of ham
- countries: FR
- kinds: ham sandwich
- ingredients: ham, butter
- has Wikipedia article: en, zh

## DISH Q3160837
- name: Ardennes ham
- countries: BE
- kinds: ham

## DISH Q3160840
- name: Jambon de Luxeuil
- countries: (none)
- kinds: ham
- ingredients: pork

## DISH Q3160843
- name: Jambon de Reims
- other names: {"fr": "Jambon de Reims"}
- countries: (none)
- kinds: ham

## DISH Q3160844
- name: Njeguška pršuta
- description: dry-cured ham from Njeguši
- countries: ME
- kinds: ham, prosciutto
- has Wikipedia article: en

## DISH Q3160845
- name: Jambon de Vendée
- other names: {"fr": "Jambon de Vendée"}
- countries: FR
- kinds: salting, ham

## DISH Q3160846
- name: Jambon de l'Ardèche
- other names: {"fr": "Jambon de l'Ardèche"}
- countries: FR
- kinds: certification mark, ham
- ingredients: ham

## DISH Q3160847
- name: Jambon persillé
- description: Burgundian charcuterie
- countries: (none)
- kinds: ham
- ingredients: ham

## DISH Q3160848
- name: Jambon sec des Ardennes
- description: French ham
- countries: FR
- kinds: certification mark, raw ham
- has Wikipedia article: en

## DISH Q3160850
- name: Baked ham with wine
- description: ham dish, invented at Chez Panisse in California
- countries: (none)
- kinds: pork dish
- ingredients: Smithfield ham, white wine

## DISH Q316244
- name: Pickert
- description: potato dish
- countries: DE
- kinds: potato-dough dumpling
- ingredients: potato
- has Wikipedia article: en

## DISH Q316561
- name: Nonpareils
- other names: {"zh": "糖丸"}
- description: slightly different decorative candy
- countries: (none)
- kinds: hagelslag, confectionery
- ingredients: food coloring, sugar
- has Wikipedia article: en

## DISH Q31724514
- name: Ghanto
- description: Bengali dish with multiple vegetables
- countries: (none)
- kinds: type of food or dish, dish

## DISH Q31724928
- name: Chhenchki
- countries: (none)
- kinds: dish

## DISH Q31727595
- name: পেলকা
- other names: {"bn": "পেলকা"}
- countries: (none)
- kinds: tarkari

## DISH Q31739973
- name: Mosbolletjies
- description: South African sweet bread
- countries: ZA
- kinds: bread
- has Wikipedia article: en

## DISH Q31740176
- name: Braaibroodjie
- description: South African cuisine
- countries: ZA
- kinds: dish, bread roll
- has Wikipedia article: en

## DISH Q31752653
- name: Kitumbua
- description: type of rice fritter
- countries: (none)
- kinds: fritter

## DISH Q31754646
- name: Ngachin
- description: fermented fish product used in Burmese cuisine
- countries: (none)
- kinds: pickled fish
- has Wikipedia article: en

## DISH Q3177408
- name: Talo
- description: typical food of the Basque Country, similar to the corn tortilla of Mesoamerica, made of corn flour
- countries: FR
- kinds: food, bread
- ingredients: maize flour, cornmeal
- has Wikipedia article: en

## DISH Q317872
- name: Haddekuche
- description: spice cake from Frankfurt and South Hesse
- countries: DE
- kinds: food, gingerbread
- has Wikipedia article: en

## DISH Q31801023
- name: Gaintha
- description: Odia cuisine
- countries: IN
- kinds: food, confectionery, rice dish

## DISH Q31801072
- name: Jagannath Ballabha
- description: Indian dessert
- countries: IN
- kinds: dessert

## DISH Q31801073
- name: Chhena Tadia
- description: Indian dessert
- countries: IN
- kinds: dessert

## DISH Q3180338
- name: Joffre cake
- other names: {"zh": "霍夫蛋糕"}
- description: chocolate buttermilk layer cake filled with chocolate ganache and frosted with chocolate buttercream
- countries: RO
- kinds: cake
- ingredients: buttermilk
- has Wikipedia article: en, zh

## DISH Q3180750
- name: Ćwikła
- description: food
- countries: IL, PL, SK, UA
- cuisines: Jewish cuisine, Polish cuisine, Slovak cuisine, Ukrainian cuisine
- kinds: dish
- ingredients: Beta vulgaris, Armoracia rusticana
- has Wikipedia article: en

## DISH Q31822160
- name: Dograma
- description: Turkmen dish
- countries: TM
- kinds: meat dish
- ingredients: çörek, onion, meat

## DISH Q31830105
- name: Dosa
- countries: IN
- cuisines: Indian cuisine
- kinds: human food
- ingredients: rice

## DISH Q31830399
- name: Banana flower
- description: a flower from the banana plant, widely used in South Indian cooking and medicine, and in perfumery
- countries: IN
- cuisines: Telugu cuisine
- kinds: edible flower, food ingredient
- has Wikipedia article: en

## DISH Q3183248
- name: Malay sponge cake
- other names: {"zh": "马拉糕"}
- description: Chinese dessert cake
- countries: CN
- kinds: cake
- has Wikipedia article: en, zh

## DISH Q3183441
- name: Rushan cheese
- other names: {"zh": "乳扇"}
- description: cheese from cow milk
- countries: (none)
- kinds: cow's-milk cheese
- has Wikipedia article: en, zh

## DISH Q31835050
- name: Тост
- other names: {"ru": "тост"}
- countries: (none)
- kinds: pastry, baked good
- ingredients: toast
