# Review batch names-009

## DISH Q11174860
- name: Meat rice dumpling
- other names: {"zh": "鹹肉粽"}
- countries: (none)
- kinds: zongzi
- has Wikipedia article: zh

## DISH Q11174861
- name: 束脩
- countries: (none)
- kinds: dish

## DISH Q11174862
- name: Taiwan fried chicken
- other names: {"zh": "鹹酥雞"}
- description: dish in Taiwanese cuisine
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q11174939
- name: Salt-baked chicken
- other names: {"zh": "鹽焗雞"}
- countries: CN
- kinds: chicken dish
- ingredients: chicken as food, table salt
- has Wikipedia article: zh

## DISH Q111753184
- name: חלת מפתח
- other names: {"he": "חלת מפתח"}
- countries: (none)
- kinds: challah, Minhag, Judaism

## DISH Q11175394
- name: Maltose with biscuits
- other names: {"zh": "麥芽糖夾餅"}
- description: saltine crackers with maltose syrup
- countries: CN
- kinds: food, cracker
- has Wikipedia article: en, zh

## DISH Q111755418
- name: Sushi bake
- description: Baked deconstructed sushi roll
- countries: PH
- cuisines: California cuisine, Filipino cuisine
- kinds: sushi
- has Wikipedia article: en

## DISH Q11175566
- name: Mī-hún-kóe-á
- other names: {"zh": "麵粉粿"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: flour-based food
- has Wikipedia article: zh

## DISH Q11175878
- name: Madoufu
- other names: {"zh": "麻豆腐"}
- description: mung bean dish of China
- countries: CN
- kinds: legume dish
- has Wikipedia article: zh

## DISH Q11175898
- name: 麻辣鴨血
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q111781427
- name: Kiriboshiimo
- description: dried food in Japan
- countries: JP
- kinds: dried food
- ingredients: sweet potato

## DISH Q111784605
- name: Kinko
- description: dried food of sweet potato in Japan
- countries: JP
- kinds: hoshiimo, dried food
- ingredients: sweet potato

## DISH Q111792931
- name: Tahiti Plage
- other names: {"fr": "Tahiti Plage"}
- countries: (none)
- kinds: fast food, bar

## DISH Q111794245
- name: 行事食
- other names: {"ja": "行事食"}
- countries: (none)
- kinds: dish

## DISH Q11179944
- name: Stewed dog meat with soft-shelled turtle
- other names: {"zh": "鼋汁狗肉"}
- countries: CN
- kinds: soup, stew
- ingredients: turtle, dog meat
- has Wikipedia article: zh

## DISH Q11179980
- name: Tiánn-pinn-sô
- other names: {"zh": "鼎邊趖"}
- description: Taiwanese soup
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: soup, meat dish, seafood dish
- ingredients: rice flour
- has Wikipedia article: zh

## DISH Q111804862
- name: Ödemiş köfte
- countries: TR
- kinds: Köftes in the Turkish cuisine
- ingredients: meat

## DISH Q11180598
- name: 龍珠 (食物)
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q111817407
- name: Зелёные щи
- other names: {"ru": "Зелёные щи"}
- countries: RU
- cuisines: Russian cuisine
- kinds: dish
- ingredients: Aegopodium, boiled egg, smetana, Urtica urens, Spinacia oleracea, potato

## DISH Q1118196
- name: Kondosouvli
- description: Greek dish which includes meat grilled on skewers
- countries: (none)
- kinds: meat dish

## DISH Q111834905
- name: Liver cake
- other names: {"zh": "鸡肝蛋糕"}
- description: Russian delicacy made of chicken liver
- countries: (none)
- kinds: layer cake
- ingredients: chicken liver
- has Wikipedia article: en, zh

## DISH Q111835885
- name: Argentine cheese
- description: Cheese of Argentina
- countries: AR
- kinds: cheese
- has Wikipedia article: en

## DISH Q111836983
- name: Sandwich
- other names: {"zh": "三明治"}
- description: two pieces of sliced baked bread with filling in between them; not to be confused with Q28803 (the broader sense of "sandwich")
- countries: (none)
- kinds: sandwich

## DISH Q111844932
- name: Kansōimo
- description: dried food in Japan
- countries: JP
- kinds: dried food
- ingredients: sweet potato

## DISH Q11190199
- name: Roscos de Semana Santa
- other names: {"es": "Roscos de Semana Santa"}
- countries: ES
- kinds: dessert, baked good, sweet bread
- ingredients: wheat flour, lemon, sunflower oil, egg as food, Pimpinella anisum, cinnamon, clove, sugar, milk

## DISH Q111904334
- name: Phở không người lái
- other names: {"vi": "phở không người lái"}
- countries: VN
- kinds: food, dish, noodle soup
- ingredients: rice noodle

## DISH Q111907435
- name: Belegtes Brot
- other names: {"de": "belegtes Brot"}
- countries: (none)
- kinds: cold dishes, open sandwich

## DISH Q111913166
- name: Stefanie-Torte
- other names: {"de": "Stefanie-Torte"}
- countries: AT
- cuisines: Austrian cuisine, Hungarian cuisine
- kinds: cake, dish
- ingredients: buttercream, biscuit

## DISH Q111913468
- name: Apple crumble
- description: British apple dessert with streusel topping
- countries: GB
- kinds: crumble, dessert
- ingredients: streusel, apple
- has Wikipedia article: en

## DISH Q111914087
- name: Kissuto rombo
- description: goat meat dish from Angola
- countries: AO
- kinds: goat meat, dish
- ingredients: garlic, lemon juice, goat meat, table salt
- has Wikipedia article: en

## DISH Q111917546
- name: Bolo de noiva
- other names: {"pt": "bolo de noiva"}
- countries: (none)
- kinds: cake, Brazilian cuisine

## DISH Q111917727
- name: Ambrosia
- other names: {"pt": "ambrosia"}
- countries: (none)
- kinds: dessert

## DISH Q111919719
- name: Schenkele
- description: Small finger shaped sweet fritter
- countries: CH
- cuisines: Swiss cuisine
- kinds: fritter, cruller
- has Wikipedia article: en

## DISH Q111934811
- name: Posekunchiks
- countries: (none)
- kinds: baked good

## DISH Q111938080
- name: Happy pizza
- description: pizza with cannabis-infused ingredients
- countries: KH
- kinds: dish
- has Wikipedia article: en

## DISH Q111940065
- name: Sinaloan sushi
- description: Mexican-American/Japanese fusion cuisine
- countries: MX
- kinds: sushi, food
- has Wikipedia article: en

## DISH Q1119435
- name: Carcerato
- description: dish
- countries: IT
- kinds: dish

## DISH Q111971806
- name: Moqueca baiana
- countries: BR
- kinds: moqueca
- ingredients: palm oil, seafood

## DISH Q111981894
- name: Burger
- other names: {"zh": "汉堡"}
- description: bread bun with a filling
- countries: (none)
- kinds: dish, type of food or dish, sandwich
- ingredients: burger bun, patty, vegetable

## DISH Q111981908
- name: Jiamo
- other names: {"zh": "夾饃"}
- description: two pieces of momos (a subclass of flat mantou) with fillings in it
- countries: CN
- kinds: sandwich

## DISH Q111981913
- name: Veggie jiamo
- other names: {"zh": "菜夹饃"}
- description: jiamo with fresh vegetables in it
- countries: CN
- kinds: jiamo

## DISH Q111986756
- name: Pintera bread
- description: Spanish bread
- countries: ES
- kinds: bread

## DISH Q111993743
- name: Pan de codos
- description: Spanish bread
- countries: ES
- kinds: bread

## DISH Q111995448
- name: Panzaje
- description: Mexican dish
- countries: MX
- kinds: dish

## DISH Q112036371
- name: Стерляжья уха
- other names: {"ru": "стерляжья уха"}
- countries: RU
- cuisines: Russian cuisine
- kinds: ukha, dish
- ingredients: fish stock, sterlet

## DISH Q112042016
- name: Pizza Eschoise (Escher Pizza)
- other names: {"fr": "Pizza Eschoise (Escher Pizza)"}
- countries: (none)

## DISH Q112073818
- name: Saealsim
- other names: {"zh": "汤丸"}
- description: Korean rice ball
- countries: (none)
- kinds: rice dish
- has Wikipedia article: zh

## DISH Q112073845
- name: Борщок
- other names: {"ru": "Борщок"}
- countries: RU
- cuisines: Russian cuisine
- kinds: Consommé, dish
- ingredients: crouton, broth

## DISH Q112075398
- name: Обертух
- other names: {"ru": "Обертух"}
- countries: RU
- cuisines: Russian cuisine
- kinds: dish
- ingredients: yeast dough

## DISH Q112117050
- name: Otona-sama Lunch
- countries: (none)
- kinds: dish

## DISH Q112118165
- name: Schnittkäse Malga Gardena PAT
- other names: {"zh": "Schnittkäse Malga Gardena PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: Italian cheese, cheese
- ingredients: cow's milk, rennet, table salt

## DISH Q112136957
- name: Ham rice
- description: Japanese rice dish
- countries: JP
- kinds: dish
- ingredients: fried rice

## DISH Q112156900
- name: Vegan burger
- description: burger without any animal products
- countries: (none)
- kinds: veggie burger
- ingredients: vegan burger patty product, bread roll
- has Wikipedia article: en

## DISH Q112167282
- name: Limber
- description: Puerto Rican ice pop
- countries: (none)
- kinds: ice pop
- has Wikipedia article: en

## DISH Q112173562
- name: Риплянка
- other names: {"ru": "Риплянка"}
- countries: UA
- kinds: savoury pie, dish
- ingredients: maize flour, potato

## DISH Q112176644
- name: Samsa dessert
- description: North African pastry
- countries: DZ
- kinds: dessert

## DISH Q112176713
- name: Gelin helvası
- other names: {"tr": "Gelin helvası"}
- countries: (none)
- kinds: halva

## DISH Q112182363
- name: Sroto Kriyik
- description: traditional soto dish from Purbalingga, Central Java, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: soto, food, dish, type of food or dish
- ingredients: chicken

## DISH Q112182375
- name: Sroto Bancar
- description: Indonesian cuisine
- countries: (none)
- kinds: soto

## DISH Q112184857
- name: Esterházy-Rostbraten
- other names: {"de": "Esterházy-Rostbraten"}
- countries: HU
- cuisines: Austrian cuisine, Hungarian cuisine
- kinds: meat dish
- ingredients: entrecôte

## DISH Q112185001
- name: Tortilla paraguaya
- description: Paraguayan tortilla
- countries: (none)
- kinds: pancake
- ingredients: Paraguay cheese, wheat flour, egg as food, table salt, milk, water

## DISH Q112230094
- name: Kétoun
- other names: {"fr": "kétoun"}
- countries: (none)
- kinds: food, soup
- ingredients: tuber

## DISH Q112230360
- name: Malé gâteau
- description: Guinean rice donut
- countries: (none)
- kinds: beignet
- ingredients: rice flour

## DISH Q112230389
- name: Kabissé
- description: dessert made with curdled milk and wheat semolina
- countries: GN
- kinds: dessert

## DISH Q112232699
- name: Takoula Guinée
- other names: {"fr": "Takoula Guinée"}
- countries: GN
- kinds: bread

## DISH Q112233469
- name: Tadai bontai
- description: cassava leaf sauce with palm nuts
- countries: GN
- kinds: sauce

## DISH Q112233566
- name: Salade boré
- description: lettuce sauce
- countries: GN
- kinds: sauce

## DISH Q112233617
- name: Chou Boré
- other names: {"fr": "chou Boré"}
- countries: GN
- kinds: sauce

## DISH Q112233896
- name: Santoungni boré
- other names: {"fr": "santoungni boré"}
- countries: GN
- kinds: sauce

## DISH Q112243720
- name: Madoukoui
- other names: {"fr": "Madoukoui"}
- countries: GN
- kinds: sauce

## DISH Q112243884
- name: Yée gâteaux
- other names: {"fr": "yée gâteaux"}
- countries: GN
- kinds: beignet

## DISH Q112243913
- name: Yaihai cake
- description: filled fish doughnut from Guinea
- countries: GN
- kinds: beignet
- ingredients: fish

## DISH Q112247828
- name: Saffron bun
- other names: {"zh": "藏紅花包"}
- description: spiced yeast-leavened sweet bun with saffron and currants from Southern England
- countries: GB
- kinds: saffron bread
- ingredients: wheat flour, currant, yeast, saffron, sugar
- has Wikipedia article: en

## DISH Q112256513
- name: Albuquerque turkey
- description: grilled sandwich topped with turkey, cheese, and New Mexico chile sauce (usually green)
- countries: US
- kinds: sandwich
- ingredients: New Mexico chile, turkey meat, cheese

## DISH Q112261855
- name: Goyang
- description: fermented vegetable food of the Sherpa
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q11229708
- name: Kamir
- description: Javanese traditional bread
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, traditional food
- has Wikipedia article: en

## DISH Q112325694
- name: Torta de cañamones
- description: flatbread from Spain
- countries: ES
- kinds: flatbread, torta

## DISH Q112338749
- name: Txuri ta beltz
- other names: {"eu": "txuri ta beltz"}
- countries: (none)
- kinds: dish
- ingredients: parsley, garlic, tomato sauce, onion, blood sausage, egg as food, small intestine

## DISH Q112339256
- name: Water pie
- description: food
- countries: (none)
- kinds: pastry, pie
- ingredients: flour, butter, sugar, water
- has Wikipedia article: en

## DISH Q11235217
- name: Tokyo ramen
- countries: (none)
- kinds: shoyu ramen

## DISH Q11235970
- name: Dry curry
- other names: {"zh": "乾咖喱飯"}
- description: form of Japanese curry cooked without roux
- countries: (none)
- kinds: dish, Japanese curry

## DISH Q11236775
- name: Laputa bread
- other names: {"zh": "拉普達麵包"}
- countries: (none)
- kinds: bread dish
- ingredients: fried egg, toast
- has Wikipedia article: zh

## DISH Q11238659
- name: Linguettine
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q11239619
- name: Pino
- other names: {"zh": "PINO (冰淇淋)"}
- description: ice cream
- countries: (none)
- kinds: ice cream

## DISH Q112404922
- name: Brie de Saint-Raymond
- other names: {"fr": "brie de Saint-Raymond"}
- countries: CA
- kinds: brie, cheese from Quebec

## DISH Q11242256
- name: Miso ramen
- other names: {"zh": "味噌拉麵"}
- countries: (none)
- kinds: ramen
- ingredients: miso
- has Wikipedia article: zh

## DISH Q11242258
- name: Soto mie
- description: Indonesian noodle soup dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: soup, soto, human food, type of food or dish
- has Wikipedia article: en

## DISH Q11243779
- name: 栗子飯
- description: chestnut rice
- countries: (none)
- kinds: rice dish
- ingredients: Castanea crenata, rice

## DISH Q11243809
- name: Бульбяная аладка
- other names: {"be-tarask": "бульбяная аладка"}
- countries: (none)
- kinds: potato dish
- ingredients: potato

## DISH Q11244057
- name: SOYJOY
- other names: {"zh": "SOYJOY クリスピー"}
- description: Japanese snack bar bland
- countries: JP
- kinds: food
- ingredients: soybean

## DISH Q11245715
- name: Tumpang
- description: Authentic Indonesian food from West Sumatra
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food

## DISH Q1124753
- name: Cicerata
- countries: IT
- kinds: dish, Christmas dessert

## DISH Q1124761
- name: Mazurek
- description: traditional Polish Easter cake
- countries: PL
- kinds: pastry, Easter food
- has Wikipedia article: en

## DISH Q1124851
- name: Käsespätzle
- other names: {"zh": "乳酪麵"}
- description: Dish of egg noodles with cheese
- countries: DE
- kinds: pasta dish
- ingredients: fried onion, spätzle, cheese
- has Wikipedia article: en, zh

## DISH Q1125112
- name: Carota novella di Ispica
- countries: IT
- kinds: carrot

## DISH Q11252514
- name: Shoyu ramen
- other names: {"zh": "醬油拉麵"}
- description: Japanese noodle dish
- countries: (none)
- kinds: ramen
- ingredients: shōyu, noodle
- has Wikipedia article: zh

## DISH Q11252676
- name: 水刺床
- countries: (none)
- cuisines: Korean royal court cuisine, Seoul cuisine
- kinds: dish

## DISH Q1125542
- name: Allerheiligenstriezel
- description: Geflochtenes Hefegebäck
- countries: AT
- kinds: food, pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q112568435
- name: Boulfaf
- description: Moroccan liver kebab
- countries: (none)
- kinds: kebab
- ingredients: liver as food, caul fat
- has Wikipedia article: en

## DISH Q11256851
- name: あかだ・くつわ
- other names: {"ja": "あかだ・くつわ"}
- countries: JP
- kinds: confectionery

## DISH Q11256912
- name: Akamaki
- countries: (none)
- kinds: saogashi

## DISH Q11256939
- name: あがら丼
- other names: {"ja": "あがら丼"}
- countries: (none)
- kinds: donburi

## DISH Q11257088
- name: Ageimo
- description: Hokkaido dish of fried potatoes
- countries: JP
- kinds: fries

## DISH Q11257243
- name: Asari senbei
- other names: {"cs": "asari senbei"}
- countries: JP
- kinds: wagashi, food
- ingredients: Venerupis philippinarum, Decapodiformes, starch

## DISH Q11257281
- name: Azara
- countries: JP
- kinds: stew, shirumono
- ingredients: Ara, tsukemono, Sake kasu

## DISH Q11257507
- name: Azuma-zushi
- description: style of sushi
- countries: (none)
- kinds: sushi
- ingredients: soy pulp

## DISH Q11257745
- name: Atsumeshi
- countries: JP
- kinds: donburi, fish dish

## DISH Q11257796
- name: Anagomeshi
- description: Japanese rice dish
- countries: (none)
- kinds: Japanese rice dish, fish dish
- ingredients: anago

## DISH Q11258023
- name: Anekaeshi
- countries: (none)
- kinds: mochi
- ingredients: rice flour, red bean paste, Artemisia princeps

## DISH Q11258240
- name: Abuttekamo
- description: Japanese regional cuisine; grilled damselfish
- countries: JP
- kinds: fish dish
- ingredients: Chromis notata

## DISH Q11258259
- name: Aburi-mochi
- countries: (none)
- kinds: mochi, wagashi

## DISH Q11258393
- name: Yanagawa nabe
- description: Dojo loach pot
- countries: JP
- kinds: nabemono, nimono
- ingredients: Pond loach, Arctium lappa

## DISH Q11258602
- name: Arajiru
- countries: JP
- kinds: fish soup, shirumono, type of food or dish
- ingredients: Ara

## DISH Q11258799
- name: Ankake spaghetti
- other names: {"zh": "燴義大利麵"}
- countries: JP
- kinds: spaghetti, food

## DISH Q11258806
- name: Anko nabe
- other names: {"zh": "鮟鱇鍋"}
- countries: JP
- kinds: nabemono
- ingredients: Lophiidae

## DISH Q11258809
- name: Ankoro mochi
- description: Japanese confection
- countries: JP
- kinds: mochi, wagashi
- ingredients: red bean paste

## DISH Q11258834
- name: 杏飴
- countries: (none)
- kinds: confectionery

## DISH Q11258867
- name: あんばやし
- other names: {"ja": "あんばやし"}
- countries: JP
- kinds: dengaku, dish

## DISH Q11258884
- name: Anmaki
- description: Japanese sweets from the Mikawa region of Aichi Prefecture
- countries: JP
- kinds: food, wagashi
- ingredients: sweet bean paste

## DISH Q11258896
- name: An-doughnut
- description: Japanese doughnut filled with red bean paste
- countries: JP
- kinds: doughnut
- ingredients: red bean paste
- has Wikipedia article: en

## DISH Q11258904
- name: Andama
- countries: (none)
- kinds: dagashi

## DISH Q11258929
- name: Āsa-jiru
- countries: (none)
- kinds: type of food or dish, shirumono
- ingredients: shimadōfu, Monostroma nitidum

## DISH Q11259037
- name: Ika ninjin
- countries: JP
- kinds: squid dish, vegetable dish
- ingredients: dried shredded squid, carrot

## DISH Q11259057
- name: Igai meshi
- description: rice mixed with Japanese mussels
- countries: JP
- kinds: takikomi gohan, clam dish
- ingredients: Mytilus coruscus

## DISH Q11259060
- name: Iga manjū
- other names: {"zh": "伊賀饅頭"}
- countries: (none)
- kinds: manjū
- ingredients: sekihan

## DISH Q11259099
- name: Ikinaridango
- other names: {"zh": "即時團子"}
- description: Japanese confectionery
- countries: JP
- kinds: pastry
- ingredients: mochi, Sweet potato, sweet bean paste
- has Wikipedia article: en, zh

## DISH Q11259116
- name: Igirisu
- countries: (none)
- kinds: dish
- ingredients: seaweed

## DISH Q11259182
- name: Igoneri
- countries: JP
- kinds: edible seaweed, seafood dish
- ingredients: Campylaephora hypnaeoides

## DISH Q11259489
- name: いちきポンカレー
- other names: {"ja": "いちきポンカレー"}
- countries: (none)
- kinds: Japanese curry rice

## DISH Q11259528
- name: Ichigo daifuku
- description: strawberry mochi dessert
- countries: JP
- kinds: dessert, daifuku, manjū
- ingredients: strawberry, red bean paste, mochi

## DISH Q11259811
- name: Itoko-ni
- other names: {"zh": "從兄弟煮"}
- countries: JP
- kinds: dish
- has Wikipedia article: zh

## DISH Q11259841
- name: Inago no tsukudani
- other names: {"zh": "蝗虫佃煮"}
- description: Japanese dish
- countries: JP
- cuisines: Japanese cuisine
- kinds: Tsukudani, insect as food
- ingredients: grasshopper
- has Wikipedia article: en

## DISH Q11259955
- name: Iburi-zuke
- countries: JP
- kinds: smoking, tsukemono

## DISH Q11260024
- name: Imonamasu
- countries: (none)
- kinds: potato dish

## DISH Q11260025
- name: Imomochi
- countries: JP
- cuisines: Japanese cuisine
- kinds: dish

## DISH Q11260027
- name: いもフライ
- other names: {"ja": "いもフライ"}
- countries: JP
- kinds: fries, deep frying

## DISH Q11260315
- name: Uguisu an
- description: sweet green peas paste
- countries: JP
- kinds: food ingredient, bean paste
- ingredients: Green pea

## DISH Q11260432
- name: Uzumi
- countries: (none)
- kinds: Japanese rice dish

## DISH Q11260433
- name: Uzume meshi
- description: Japanese rice dish
- countries: JP
- kinds: Japanese rice dish
- ingredients: wasabi, Koya-dofu, Cryptotaenia japonica, cooked rice, Lentinula edodes, soy sauce, nori, kamaboko, carrot

## DISH Q11260435
- name: Uzumaki
- countries: JP
- kinds: wagashi

## DISH Q112605733
- name: Vitamin salad
- countries: SU
- cuisines: Soviet cuisine
- kinds: salad, dish
- ingredients: cucumber, smetana, Apium graveolens, apple, carrot

## DISH Q112606123
- name: Капуста провансаль
- other names: {"ru": "капуста провансаль"}
- countries: SU
- cuisines: Soviet cuisine
- kinds: coleslaw
- ingredients: cranberry, lingonberry, sauerkraut

## DISH Q11260635
- name: うなぎボーン
- other names: {"ja": "うなぎボーン"}
- description: eel bone cracker
- countries: JP
- kinds: senbei, food product, unagi
- ingredients: bone

## DISH Q11260648
- name: Unari-zushi
- countries: (none)
- kinds: inarizushi

## DISH Q11260815
- name: Uruka
- other names: {"zh": "鱁鮧"}
- countries: JP
- kinds: shiokara, fermented food
- ingredients: ayu sweetfish as food

## DISH Q11260930
- name: ええじゃん鍋
- other names: {"ja": "ええじゃん鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q11260995
- name: Enokoro meshi
- other names: {"zh": "狗兒飯"}
- countries: JP
- cuisines: Japanese cuisine
- kinds: rice, dish
- ingredients: dog meat

## DISH Q112610072
- name: Okpa
- description: delicacy prepared in Nigeria
- countries: NG
- kinds: pudding, food
- has Wikipedia article: en

## DISH Q11261020
- name: Ebisu
- countries: (none)
- kinds: egg dish
- ingredients: agar, egg as food

## DISH Q11261069
- name: Ebimeshi
- other names: {"zh": "蝦飯"}
- countries: JP
- kinds: chāhan, shrimp dish

## DISH Q11261071
- name: Shrimp ball
- countries: (none)
- kinds: fish ball

## DISH Q11261190
- name: Oiri
- countries: (none)
- kinds: arare

## DISH Q11261191
- name: Oiri
- countries: (none)
- kinds: wagashi

## DISH Q11261365
- name: Okaki
- other names: {"zh": "御欠"}
- countries: (none)
- kinds: Beika
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q11261398
- name: おかべ焼きそば
- other names: {"ja": "おかべ焼きそば"}
- countries: (none)
- kinds: fried noodle, Yakisoba

## DISH Q11261467
- name: おくずかけ
- other names: {"ja": "おくずかけ"}
- countries: JP
- kinds: shirumono

## DISH Q11261489
- name: Okoshi
- countries: (none)
- kinds: puffed rice cake, higashi

## DISH Q11261499
- name: Okowa
- other names: {"zh": "御強妹妹"}
- description: Japanese steamed rice dish
- countries: JP
- kinds: gohan
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q11261779
- name: Occhi di lupo
- description: type of tubular pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q11261791
- name: Okkirikomi
- description: Japanese noodle dish
- countries: (none)
- kinds: nabemono, nikomi udon
- has Wikipedia article: en

## DISH Q11261814
- name: おっぱいアイス
- other names: {"ja": "おっぱいアイス"}
- countries: (none)
- kinds: ice cream

## DISH Q11261837
- name: おつけだんご
- other names: {"ja": "おつけだんご"}
- countries: JP
- kinds: dish

## DISH Q11261883
- name: Oden cans
- countries: JP
- kinds: oden, canned food

## DISH Q11262341
- name: Ohitashi
- countries: JP
- kinds: vegetable dish, food preparation technique

## DISH Q11262545
- name: おもろカレー
- other names: {"ja": "おもろカレー"}
- countries: (none)
- kinds: Japanese curry rice

## DISH Q11262599
- name: Oyabe White Ramen
- countries: (none)
- kinds: tonkotsu ramen

## DISH Q11263059
- name: Okosama lunch
- description: menu in Japanese restaurants
- countries: JP
- cuisines: yōshoku
- kinds: dish

## DISH Q11263421
- name: お茶餅
- other names: {"ja": "お茶餅"}
- countries: (none)
- kinds: mochi

## DISH Q11263584
- name: Kakaran dango
- countries: (none)
- kinds: dango, Kusa mochi

## DISH Q11263604
- name: Oyster rice
- countries: (none)
- kinds: takikomi gohan, oyster dish

## DISH Q11263643
- name: Kake soba
- other names: {"zh": "蕎麥湯麵"}
- description: Japanese dish
- countries: JP
- kinds: soba, noodle soup
- ingredients: mirin, dashi, soba, soy sauce

## DISH Q11263764
- name: Kashimin-yaki
- countries: (none)
- kinds: issen yōshoku, chicken dish

## DISH Q11263791
- name: かじか汁
- other names: {"ja": "かじか汁"}
- countries: (none)
- kinds: nabemono

## DISH Q11263802
- name: かすてら饅頭
- other names: {"ja": "かすてら饅頭"}
- countries: JP
- kinds: manjū, wagashi

## DISH Q11263819
- name: Kasumaki
- countries: (none)
- kinds: saogashi
- ingredients: castella

## DISH Q11263884
- name: Katayaki
- countries: JP
- kinds: senbei

## DISH Q11263925
- name: Katsuo Ramen
- countries: (none)
- kinds: ramen

## DISH Q11263945
- name: Katsumeshi
- countries: (none)
- kinds: katsu rice
- ingredients: pork

## DISH Q11264066
- name: Kani-meshi
- countries: JP
- kinds: Japanese rice dish, crab dish

## DISH Q11264120
- name: Kabura-zushi
- description: style of sushi made with turnip
- countries: JP
- kinds: narezushi
- ingredients: turnip, Seriola quinqueradiata

## DISH Q11264154
- name: Kamasu-zushi
- description: style of sushi, made with barracuda
- countries: (none)
- kinds: sushi
- ingredients: Sphyraena

## DISH Q11264215
- name: かめそば
- other names: {"ja": "かめそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q11264256
- name: Kamome no tamago
- description: Japanese confection
- countries: JP
- kinds: confectionery
- ingredients: white bean, sponge cake, white chocolate

## DISH Q11264277
- name: Kayaki
- description: grilled scallops
- countries: JP
- kinds: nabemono

## DISH Q11264297
- name: Karakara senbei
- countries: (none)
- kinds: senbei, shokugan

## DISH Q11264310
- name: Karashi tōfu
- countries: (none)
- kinds: tofu

## DISH Q11264314
- name: Karasumi
- countries: (none)
- kinds: saogashi
- ingredients: rice flour

## DISH Q11264339
- name: からつバーガー
- other names: {"ja": "からつバーガー"}
- countries: JP
- kinds: hamburger

## DISH Q11264362
- name: Karazushi
- countries: (none)
- kinds: sushi
- ingredients: soy pulp

## DISH Q11264372
- name: Yudofu
- description: Japanese tofu dish
- countries: JP
- kinds: appetizer, nabemono
- ingredients: tofu

## DISH Q11264386
- name: Karintō manjū
- countries: (none)
- kinds: manjū
- ingredients: non-centrifugal cane sugar

## DISH Q11264397
- name: かれい最中
- other names: {"ja": "かれい最中"}
- countries: (none)
- kinds: monaka

## DISH Q11264521
- name: Kankoromochi
- description: confection from Nagasaki Prefecture
- countries: JP
- kinds: mochi, saogashi
- ingredients: Sweet potato
- has Wikipedia article: en

## DISH Q11264587
- name: Gajamame
- countries: (none)
- kinds: confectionery
- ingredients: peanut

## DISH Q11264695
- name: Ganjiru
- description: Japanese regional soup made from crab
- countries: JP
- kinds: shirumono, crab dish
- ingredients: Brachyura

## DISH Q11264697
- name: Ganzuke
- countries: JP
- kinds: shiokara, crab dish
- ingredients: Brachyura

## DISH Q11264794
- name: 雪うさぎ
- other names: {"ja": "雪うさぎ"}
- countries: (none)
- kinds: Miyagegashi

## DISH Q11264807
- name: Kizushi
- description: vinegared mackerel
- countries: JP
- kinds: fish dish, pickled fish

## DISH Q11264879
- name: Kinako nejiri
- countries: (none)
- kinds: Kyōgashi, nerigashi
- ingredients: mizuame, kinako

## DISH Q11264882
- name: Kinako stick
- countries: (none)
- kinds: dagashi
- ingredients: kinako

## DISH Q11265074
- name: Kiyomemochi
- countries: (none)
- kinds: wagashi

## DISH Q11265229
- name: Kinshidon
- countries: (none)
- kinds: unadon, egg dish
- ingredients: usuyaki tamago, egg garnish, unadon

## DISH Q11265405
- name: Kuchiko
- description: Japanese food
- countries: JP
- kinds: shiokara, sea cucumber as food, dried food
- ingredients: gonad

## DISH Q11265425
- name: Kujira Mochi
- other names: {"zh": "久慈良餅"}
- countries: JP
- kinds: mochi
- ingredients: rice flour, flour

## DISH Q11265542
- name: 亥の子餅
- other names: {"ja": "亥の子餅"}
- countries: JP
- kinds: mochi

## DISH Q112656147
- name: Dibbehas
- other names: {"de": "Dibbehas"}
- countries: (none)
- kinds: dish
- ingredients: hare meat

## DISH Q11265742
- name: Iri-tamago
- description: Japanese scrambled eggs
- countries: JP
- kinds: egg dish
- ingredients: chicken egg

## DISH Q11265921
- name: けいらん
- other names: {"ja": "けいらん"}
- countries: JP
- kinds: shirumono

## DISH Q11265923
- name: けえらん
- other names: {"ja": "けえらん"}
- countries: JP
- kinds: wagashi

## DISH Q11265947
- name: Kenoshiru
- other names: {"zh": "粥湯"}
- description: soup specialty of Aomori, Japan
- countries: JP
- kinds: soup
- ingredients: konnyaku, Koya-dofu, white radish, dashi, Pteridium aquilinum, Arctium lappa, carrot

## DISH Q11266026
- name: Kenchō
- countries: (none)
- kinds: vegetable dish
- ingredients: Japanese radish, tofu, carrot

## DISH Q11266028
- name: Kenchinjiru
- other names: {"zh": "卷纖汁"}
- description: Japanese soup
- countries: JP
- kinds: soup, dish
- has Wikipedia article: en

## DISH Q11266096
- name: Genkotsu ame
- description: Japanese confection
- countries: (none)
- kinds: ame
- ingredients: mizuame, kinako

## DISH Q112661135
- name: Konkanastha matarchi usal
- description: marathi cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q112661348
- name: Hojas de parra
- description: Spanish dessert
- countries: ES
- cuisines: Basque cuisine
- kinds: dish, fritter
- ingredients: egg as food, wheat flour, lemon juice, anisette, cinnamon

## DISH Q11266228
- name: Ishigoromo
- other names: {"zh": "石衣"}
- countries: (none)
- kinds: wagashi
- ingredients: mizuame, red bean paste
- has Wikipedia article: zh

## DISH Q11266618
- name: こねり
- other names: {"ja": "こねり"}
- countries: (none)
- kinds: dish

## DISH Q11266889
- name: Komochi
- countries: (none)
- kinds: mochi
- ingredients: sweet potato

## DISH Q112669702
- name: Pepperoni pizza
- description: pizza with pepperoni toppings
- countries: (none)
- kinds: dish
- ingredients: tomato, mozzarella, salami
- has Wikipedia article: en

## DISH Q11267061
- name: Konjac jelly
- countries: (none)
- kinds: Amorphophallus konjac, gelatin dessert
- ingredients: Amorphophallus konjac

## DISH Q11267063
- name: Konnyaku moti
- countries: (none)
- kinds: wagashi

## DISH Q112671980
- name: Bawin sauce
- description: traditional dish from western Côte d'Ivoire
- countries: CI
- kinds: dish
- ingredients: cassava root

## DISH Q11267199
- name: Godōfu
- countries: JP
- kinds: tofu

## DISH Q11267209
- name: 牛蒡捲
- countries: (none)
- kinds: dish
- ingredients: burdock root

## DISH Q11267210
- name: ごぼとん丼
- other names: {"ja": "ごぼとん丼"}
- countries: JP
- kinds: donburi

## DISH Q11267212
- name: ごまだし
- other names: {"ja": "ごまだし"}
- countries: JP
- kinds: udon, condiment

## DISH Q11267216
- name: Gomazuke
- countries: (none)
- kinds: fish dish
- ingredients: sesame seed, anchovy

## DISH Q11267298
- name: ご当地バーガー
- other names: {"ja": "ご当地バーガー"}
- countries: (none)
- kinds: hamburger

## DISH Q112673003
- name: Mutschli
- description: Swiss cheese
- countries: CH
- kinds: cheese
- ingredients: cow's-milk cheese, sheep milk cheese, goat cheese

## DISH Q11267327
- name: ご飯パン
- other names: {"ja": "ご飯パン"}
- countries: (none)
- kinds: bread

## DISH Q11267563
- name: Saiboshi
- countries: JP
- kinds: raw meat dish
- ingredients: horse meat

## DISH Q11267836
- name: さくら棒
- other names: {"ja": "さくら棒"}
- countries: JP
- kinds: fugashi

## DISH Q11267876
- name: Sake chazuke
- countries: (none)
- kinds: chazuke, salmon dish

## DISH Q11268153
- name: さなづら
- other names: {"ja": "さなづら"}
- countries: JP
- kinds: wagashi

## DISH Q11268641
- name: Zazamushi no tsukudani
- countries: JP
- kinds: Tsukudani, insect as food
- ingredients: zazamushi

## DISH Q11268667
- name: Zaru chūka
- countries: (none)
- kinds: noodle dish

## DISH Q11268809
- name: しぐれ焼き
- other names: {"ja": "しぐれ焼き"}
- countries: (none)
- kinds: okonomiyaki

## DISH Q11268811
- name: しぐれ肉巻きおにぎり
- other names: {"ja": "しぐれ肉巻きおにぎり"}
- countries: JP
- kinds: Nikumaki onigiri

## DISH Q11268875
- name: しそ巻き
- other names: {"ja": "しそ巻き"}
- countries: JP
- kinds: dish
- ingredients: Perilla frutescens var. crispa

## DISH Q11268882
- name: しっちょる鍋
- other names: {"ja": "しっちょる鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q11269155
- name: Shoyumame
- countries: JP
- kinds: dish
- ingredients: broad bean
- has Wikipedia article: en

## DISH Q11269157
- name: Shōmiso
- countries: (none)
- kinds: miso

## DISH Q11269205
- name: Shirasudon
- description: rice bowl topped with small fish
- countries: JP
- kinds: donburi, dish
- ingredients: shirasu

## DISH Q11269303
- name: Shingorō
- countries: JP
- kinds: Japanese rice dish

## DISH Q11269366
- name: Yakisoba with potato
- countries: (none)
- kinds: Yakisoba

## DISH Q11269369
- name: Jagabē
- countries: JP
- kinds: fries

## DISH Q11269375
- name: Jaga butter
- other names: {"zh": "馬鈴薯奶油"}
- countries: JP
- kinds: potato dish
- ingredients: potato, butter

## DISH Q11269408
- name: Jappa jiru
- description: Japanese regional cuisine
- countries: JP
- kinds: shirumono, arajiru
- ingredients: Ara

## DISH Q11269413
- name: じゃりパン
- other names: {"ja": "じゃりパン"}
- countries: (none)
- kinds: sweet bread

## DISH Q11269739
- name: すだちくんアイス
- other names: {"ja": "すだちくんアイス"}
- countries: (none)
- kinds: ice cream

## DISH Q11269851
- name: すまし
- other names: {"ja": "すまし"}
- countries: JP
- kinds: condiment

## DISH Q11269912
- name: Surimi
- other names: {"zh": "擂身"}
- countries: JP
- kinds: food paste, minced meat, food ingredient
- has Wikipedia article: en

## DISH Q11270152
- name: Senzanki
- countries: (none)
- kinds: fried chicken

## DISH Q11270205
- name: Senbei-jiru
- other names: {"zh": "煎餅湯"}
- countries: (none)
- kinds: nabemono, shirumono
- ingredients: Nambu sembei

## DISH Q11270244
- name: Zenzai
- other names: {"zh": "善哉 (食品)"}
- description: Japanese food
- countries: JP
- kinds: wagashi, cuisine, azuki bean based food
- has Wikipedia article: zh

## DISH Q11270472
- name: Sobameshi
- description: Fried noodles and rice
- countries: JP
- kinds: Japanese rice dish, fried noodle, chāhan

## DISH Q11270879
- name: たくあんの煮物
- other names: {"ja": "たくあんの煮物"}
- countries: (none)
- kinds: nimono
- ingredients: takuan

## DISH Q11270967
- name: Takomanma
- description: Octopus roe
- countries: JP
- kinds: roe-based food
- ingredients: octopus as food

## DISH Q11270968
- name: Takomeshi
- other names: {"zh": "章魚飯"}
- countries: (none)
- kinds: takikomi gohan, octopus dish

## DISH Q11271334
- name: たまごふわふわ
- other names: {"ja": "たまごふわふわ"}
- countries: JP
- kinds: egg dish

## DISH Q11271361
- name: たまの温玉めし
- other names: {"ja": "たまの温玉めし"}
- countries: JP
- kinds: chāhan, dish

## DISH Q11271421
- name: Tarako spaghetti
- countries: JP
- kinds: pasta dish, spaghetti, dish
- ingredients: tarako, spaghetti

## DISH Q11271477
- name: Pot roast
- other names: {"zh": "烧牛肉"}
- description: American roasted beef dish
- countries: (none)
- kinds: roast, beef dish
- has Wikipedia article: en

## DISH Q11271556
- name: Dashimaki tamago
- other names: {"zh": "出汁蛋卷"}
- description: savory rolled egg omelette
- countries: (none)
- kinds: tamagoyaki
- ingredients: dashi

## DISH Q11271585
- name: Damako mochi
- countries: (none)
- kinds: Japanese rice dish, nabemono

## DISH Q11271624
- name: Dango-jiru
- countries: JP
- kinds: shirumono, Japanese noodles

## DISH Q11271682
- name: Chīrunkō
- other names: {"zh": "雞卵糕"}
- countries: (none)
- kinds: confectionery, egg dish

## DISH Q11271920
- name: Chan Chan Yaki
- description: simmered salmon and vegitable
- countries: JP
- kinds: salmon dish
- ingredients: chum salmon, miso, vegetable

## DISH Q11272076
- name: Chirimen sanshō
- description: Japanese dish
- countries: (none)
- kinds: kanroni, fish dish
- ingredients: sansho pepper, chirimen jako

## DISH Q11272080
- name: Chirinabe
- description: Japanese dish
- countries: JP
- kinds: nabemono
- ingredients: tofu

## DISH Q11272101
- name: Chinbin
- other names: {"zh": "琉球卷餅"}
- countries: (none)
- kinds: confectionery

## DISH Q11272188
- name: つくし飴
- other names: {"ja": "つくし飴"}
- countries: (none)
- kinds: ame
- ingredients: Equisetum arvense

## DISH Q11272312
- name: 拿玻里意粉沾麵
- countries: JP
- kinds: pasta dish

## DISH Q11272509
- name: Tsuyu-yakisoba
- description: local cuisine in Aomori prefecture, Japan
- countries: JP
- kinds: Yakisoba, noodle soup

## DISH Q11272796
- name: Dekomawashi
- countries: JP
- kinds: potato dish, dengaku

## DISH Q11272875
- name: Denpun dango
- description: sweet Japanese snack
- countries: JP
- kinds: dessert, dango
- ingredients: potato flour

## DISH Q11272914
- name: Tofu chikuwa
- countries: JP
- kinds: Chikuwa, fish surimi
- ingredients: Surimi, tofu

## DISH Q11272921
- name: Tōman
- countries: (none)
- kinds: Miyagegashi, tōmanjū

## DISH Q112730001
- name: Сайка
- other names: {"ru": "сайка"}
- countries: AT
- cuisines: Austrian cuisine
- kinds: bread roll
- ingredients: baker's yeast, flour, butter, table salt, water

## DISH Q11273150
- name: Tokoroten
- other names: {"zh": "心太"}
- description: Japanese dish
- countries: JP
- kinds: wagashi
- has Wikipedia article: en

## DISH Q11273229
- name: Charcoal biscuit
- description: type of biscuit
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q11273314
- name: とびっきりおうどん
- other names: {"ja": "とびっきりおうどん"}
- countries: (none)
- kinds: cup noodle

## DISH Q11273473
- name: とらや饅頭
- other names: {"ja": "とらや饅頭"}
- countries: JP
- kinds: manjū

## DISH Q11273516
- name: Torimotsu ramen
- countries: (none)
- kinds: Yamagata ramen, offal dish

## DISH Q11273518
- name: とり野菜味噌
- countries: (none)
- kinds: nabemono

## DISH Q11273547
- name: Torosababō-zushi
- countries: (none)
- kinds: sabazushi

## DISH Q11273560
- name: とんかつパフェ
- other names: {"ja": "とんかつパフェ"}
- countries: (none)
- kinds: parfait
- ingredients: tonkatsu

## DISH Q11273633
- name: Tonpeiyaki
- other names: {"zh": "豚平烧"}
- description: dish of Osaka
- countries: JP
- kinds: snack, teppanyaki

## DISH Q11273790
- name: Dojo doufu
- description: pond loach in tofu
- countries: JP
- kinds: dish
- ingredients: Pond loach, tofu

## DISH Q11273798
- name: Dojō nabe
- description: Japanese dish
- countries: JP
- kinds: nabemono, fish dish
- ingredients: Pond loach
- has Wikipedia article: en

## DISH Q11273846
- name: Doteyaki
- description: simmered beef tendon
- countries: JP
- kinds: type of food or dish, nimono, beef dish
- ingredients: tendon as food

## DISH Q11273854
- name: どぶ汁
- other names: {"ja": "どぶ汁"}
- countries: (none)
- kinds: nabemono

## DISH Q11273893
- name: Doro sauce
- description: Japanese sauce
- countries: (none)
- kinds: Worcestershire sauce

## DISH Q11273899
- name: Dongara-jiru
- countries: JP
- kinds: arajiru
- ingredients: cod as food

## DISH Q11273957
- name: Dondon-yaki
- countries: JP
- kinds: teppanyaki

## DISH Q11274144
- name: Nagasaki
- countries: (none)
- kinds: rakugan

## DISH Q11274474
- name: なまこ餅
- other names: {"ja": "なまこ餅"}
- countries: (none)
- kinds: mochi

## DISH Q11274488
- name: Namie yakisoba
- other names: {"zh": "浪江炒麵"}
- description: local fried noodles
- countries: JP
- kinds: fried noodle, Yakisoba

## DISH Q11274510
- name: Namerō
- description: raw meat dish
- countries: (none)
- kinds: food, raw meat dish
- ingredients: Caranginae, ginger, miso
- has Wikipedia article: en

## DISH Q11274596
- name: Nanko nabe
- countries: JP
- kinds: nabemono
- ingredients: horse meat, offal
