# Review batch names-032

## DISH Q20113734
- name: Ciğer kebap
- description: Pieces of lamb liver and tail fat on a scewer, from the Turkish cuisine, especially southern taste
- countries: TR
- kinds: kebab
- ingredients: liver as food
- has Wikipedia article: en

## DISH Q20113920
- name: Sermale
- other names: {"nb": "Sermale"}
- countries: RO
- kinds: dish

## DISH Q20128299
- name: Manis
- description: Indonesian fried potato patties originating from Java island
- countries: ID
- kinds: potato dish
- ingredients: garlic, scallion, egg as food, black pepper, flour, Apium graveolens, maize, potato
- has Wikipedia article: en

## DISH Q2013640
- name: Oxmouth Salad
- description: Beef muzzle meat salad
- countries: (none)
- kinds: salad

## DISH Q2013754
- name: Pane ticinese
- description: white bread traditionally made in the Swiss canton of Ticino
- countries: CH
- kinds: white bread
- has Wikipedia article: en

## DISH Q2014760
- name: Odori ebi
- other names: {"zh": "活蝦刺身"}
- description: Japanese sushi delicacy
- countries: JP
- kinds: live food for humans, sashimi, shrimp dish
- ingredients: shrimp and prawn as food, sake
- has Wikipedia article: en, zh

## DISH Q20162674
- name: Pineapple marmalade
- description: marmalade made from pineapple
- countries: (none)
- kinds: food, marmalade
- ingredients: pineapple

## DISH Q20162694
- name: Apricot marmalade
- description: marmalade made from apricots
- countries: (none)
- kinds: marmalade
- ingredients: apricot

## DISH Q20165873
- name: Kue mangkok
- description: Indonesian dessert
- countries: ID
- kinds: cupcake, kue
- ingredients: tapai singkong, wheat flour, rice flour, baker's yeast, coconut water, flour, sugar
- has Wikipedia article: en

## DISH Q2016856
- name: Kikkers en muizen
- other names: {"nl": "Kikkers en muizen"}
- countries: (none)
- kinds: candy

## DISH Q20182339
- name: Eiweißbrot
- other names: {"de": "Eiweißbrot"}
- description: type of bread
- countries: (none)
- kinds: dish

## DISH Q20182561
- name: Quarktasche
- other names: {"de": "Quarktasche"}
- countries: (none)
- kinds: dish
- ingredients: quark

## DISH Q20182633
- name: Resteessen
- other names: {"de": "Resteessen"}
- countries: (none)
- kinds: dish

## DISH Q20182897
- name: Sofrito
- description: traditional Sephardic Jewish stew
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q20202168
- name: Cennet çamuru
- description: dessert from the Turkish cuisine
- countries: TR
- kinds: dessert, food

## DISH Q20203475
- name: Hamsili pilav
- description: Turkish cuisine (Black Sea Region) rice dish with "hamsi" fish
- countries: TR
- kinds: fish dish, rice dish, food
- ingredients: European anchovy, rice

## DISH Q2021235
- name: Put chai ko
- other names: {"zh": "砵仔糕"}
- description: Rice cake
- countries: HK
- kinds: pudding
- ingredients: steaming
- has Wikipedia article: en, zh

## DISH Q2021346
- name: Ciorbă
- other names: {"zh": "乔尔巴"}
- description: Romanian or Moldovan sour soup
- countries: (none)
- kinds: sour soup
- ingredients: water
- has Wikipedia article: zh

## DISH Q20220343
- name: Zhajiang
- other names: {"zh": "炸醬"}
- description: salty fermented soybean paste
- countries: (none)
- kinds: fermented bean paste
- ingredients: soy bean

## DISH Q2022222
- name: Crempog
- description: Welsh pancake made with self-raising flour
- countries: (none)
- kinds: food, pancake
- ingredients: flour
- has Wikipedia article: en

## DISH Q2022950
- name: Umm Ali
- other names: {"zh": "埃及布丁面包"}
- description: traditional Egyptian dessert
- countries: (none)
- kinds: pudding, dessert
- ingredients: pastry, milk
- has Wikipedia article: en

## DISH Q2023763
- name: Jin deui
- other names: {"zh": "煎堆"}
- description: Chinese fried pastry
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, doughnut
- ingredients: Sesamum indicum, Vigna radiata, glutinous rice
- has Wikipedia article: en, zh

## DISH Q2025650
- name: Sucadekoek
- other names: {"nl": "Sucadekoek"}
- countries: (none)
- kinds: food, cookie

## DISH Q20278692
- name: Palóc soup
- description: Hungarian soup
- countries: HU
- cuisines: Hungarian cuisine
- kinds: soup
- has Wikipedia article: en

## DISH Q2028136
- name: Orangeat
- description: candied bitter orange peel
- countries: (none)
- kinds: candied fruit
- ingredients: Seville orange, sugar

## DISH Q202946
- name: Metcalfahonig
- other names: {"de": "Metcalfahonig"}
- countries: (none)
- kinds: honey

## DISH Q202989
- name: Salame turco PAT
- other names: {"zh": "Salame turco PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT, PT, RO
- kinds: food, baked good, dessert
- ingredients: Marie biscuit, egg as food, butter, cocoa powder
- has Wikipedia article: en

## DISH Q203176
- name: Gyūdon
- other names: {"zh": "牛丼"}
- description: Japanese dish
- countries: JP
- kinds: food, donburi, rice dish, beef dish
- ingredients: beef, rice, onion
- has Wikipedia article: en, zh

## DISH Q2035996
- name: Hollandse salade
- other names: {"nl": "Hollandse salade"}
- countries: (none)
- kinds: salad

## DISH Q20383132
- name: Sfinz
- countries: LY
- kinds: doughnut

## DISH Q203886
- name: Tzimmes
- description: Ashkenazi Jewish stew made from carrots and fruits
- countries: IL
- cuisines: Jewish cuisine
- kinds: dish, stew, legumina
- ingredients: raisin, carrot
- has Wikipedia article: en

## DISH Q20389034
- name: سياح
- other names: {"ar": "سياح"}
- countries: IQ
- kinds: bread, type of food or dish
- ingredients: rice flour, water

## DISH Q2039175
- name: Flemish-style asparagus
- countries: BE
- kinds: dish

## DISH Q204161
- name: Zimtstern
- description: Christmas cookie common to German-speaking countries
- countries: (none)
- kinds: Christmas cookies
- ingredients: egg white, almond, cinnamon, sugar
- has Wikipedia article: en

## DISH Q20422573
- name: منقوشة
- other names: {"ar": "منقوشة"}
- countries: (none)
- kinds: dish

## DISH Q20423491
- name: Mutabbaq Samak
- description: rice-based dish
- countries: (none)
- kinds: fish dish, rice dish
- has Wikipedia article: en

## DISH Q204251
- name: Wheat tortilla
- other names: {"zh": "麵粉薄餅"}
- description: type of soft, thin flatbread made from finely ground wheat flour
- countries: MX
- kinds: flatbread, finger food, tortilla
- ingredients: wheat flour, lard, table salt, water
- has Wikipedia article: en

## DISH Q20427122
- name: Carang gesing
- description: Indonesian food
- countries: (none)
- kinds: food, street food, kue, type of food or dish, jajan pasar
- ingredients: coconut milk, Pandanus amaryllifolius, table salt, sugar, banana

## DISH Q20427131
- name: Jalangkote
- description: A type of snack from Makassar that is shaped like a pastel
- countries: ID
- cuisines: Indonesian cuisine
- kinds: pastry, fritter, snack, meal, jajan pasar, dish, human food, type of food or dish
- ingredients: shallot, garlic, wheat flour, coconut milk, rice vermicelli, egg as food, butter, table salt, sugar, potato, carrot
- has Wikipedia article: en

## DISH Q20427327
- name: Bulayak satay
- description: satay dish from Lombok, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: satay, meat dish, side dish, dish, human food, type of food or dish
- ingredients: shallot, peanut, lontong, coconut milk, beef, Cymbopogon citratus

## DISH Q20427468
- name: Sinonggi
- description: traditional staple food of the Tolaki people from Southeast Sulawesi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: staple food, fish dish, traditional food, type of food or dish, food, dish, human food
- ingredients: shallot, turmeric rhizome, garlic, tomato, fish as food, water spinach, sago, Cymbopogon citratus

## DISH Q20427541
- name: Sop saudara
- description: Indonesia traditional buffalo soup
- countries: ID
- cuisines: Indonesian cuisine
- kinds: soup, stew, dish, human food, type of food or dish
- ingredients: shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, coriander seed, ginger, Aleurites moluccanus, Alpinia galanga, beef, nutmeg, Cymbopogon citratus, cinnamon, Carum carvi
- has Wikipedia article: en

## DISH Q20438528
- name: Brassói aprópecsenye
- description: Hungarian dish
- countries: HU
- kinds: food
- has Wikipedia article: en

## DISH Q20445517
- name: Kkulppang
- other names: {"zh": "统营蜂蜜面包"}
- description: South Korean honey bread dish
- countries: KR
- cuisines: South Korean cuisine
- kinds: bread, pastry
- ingredients: dough
- has Wikipedia article: en

## DISH Q20450717
- name: Lihing chicken soup
- countries: MY
- kinds: chicken soup

## DISH Q20456792
- name: Masak lemak
- description: Malay coconut curry
- countries: MY
- kinds: curry
- ingredients: turmeric, coconut milk

## DISH Q20458172
- name: Noonsom
- description: Kadazandusun traditional cuisine
- countries: (none)
- kinds: dish, pickle

## DISH Q2045908
- name: Paderborner Landbrot
- other names: {"de": "Paderborner Landbrot"}
- countries: (none)
- kinds: rye bread

## DISH Q20460303
- name: Corn pudding
- countries: (none)
- kinds: cake

## DISH Q20465466
- name: Ketupat palas
- description: Traditional Malaysian festive triangular glutinous rice cake wrapped in fan palm leaves
- countries: MY
- cuisines: Malay cuisine
- kinds: glutinous rice, ketupat, Eid food

## DISH Q2047314
- name: Maror
- description: bitter herbs eaten during the Passover meal
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q2048003
- name: Pastry cream
- other names: {"zh": "糕点奶油"}
- description: custard
- countries: (none)
- kinds: custard, Cream
- ingredients: egg yolk, flour, sugar, milk

## DISH Q20487101
- name: Utica greens
- description: Italian-American escarole dish
- countries: (none)
- kinds: dish
- ingredients: endive
- has Wikipedia article: en

## DISH Q2048777
- name: Casinobread
- countries: (none)
- kinds: bread

## DISH Q20497774
- name: Родопска салата
- other names: {"bg": "Родопска салата"}
- countries: BG
- kinds: salad

## DISH Q20501051
- name: Гарнирана пита
- other names: {"bg": "Гарнирана пита"}
- countries: (none)

## DISH Q20504418
- name: Шупеня
- other names: {"be-tarask": "шупеня"}
- countries: (none)
- kinds: dish

## DISH Q20508454
- name: Panrkhash
- description: Armenian traditional dish
- countries: AM
- cuisines: Armenian cuisine
- kinds: dish

## DISH Q20508879
- name: Spas
- description: soup, made with yogurt, popular in Armenia
- countries: AM
- cuisines: Armenian cuisine
- kinds: soup
- ingredients: matsoni, egg yolk, egg as food, Triticum
- has Wikipedia article: en

## DISH Q20521651
- name: Mežerli
- description: offal dish.
- countries: SI
- kinds: offal dish
- ingredients: chicken egg, cow's milk, onion, sour cream, offal, lard, bread

## DISH Q2052399
- name: Pariser schnitzel
- description: French veal cutlet
- countries: (none)
- kinds: veal dish
- has Wikipedia article: en

## DISH Q2052426
- name: Parisienne
- description: French culinary specialty
- countries: FR
- kinds: culinary speciality

## DISH Q20529721
- name: Vürtsikilu
- countries: (none)
- kinds: dish
- ingredients: Sprattus sprattus balticus

## DISH Q205328
- name: Gambas al ajillo
- description: shrimp and garlic dish
- countries: (none)
- kinds: shrimp dish
- ingredients: garlic, shrimp, olive oil
- has Wikipedia article: en

## DISH Q20546828
- name: Ousá bread
- description: traditional bread from Galicia, Spain
- countries: ES
- kinds: bread

## DISH Q20552974
- name: Ankerstokk
- other names: {"nb": "ankerstokk"}
- countries: (none)
- kinds: rye bread

## DISH Q20553191
- name: Berlinerkrans
- other names: {"nb": "berlinerkrans"}
- countries: (none)
- kinds: Christmas cookies
- ingredients: egg yolk, flour, butter, sugar

## DISH Q20560831
- name: เปิงคะดอจก์
- other names: {"th": "เปิงคะดอจก์"}
- countries: (none)
- kinds: sweet dish

## DISH Q2056216
- name: Pasta con le melanzane
- other names: {"de": "Pasta con le melanzane"}
- countries: (none)
- kinds: dish

## DISH Q2056262
- name: Pastinakenpüree
- other names: {"de": "Pastinakenpüree"}
- countries: (none)
- kinds: dish

## DISH Q2056389
- name: Pasulj
- other names: {"zh": "熏肉炖豆子"}
- description: Bean stew
- countries: RS
- cuisines: Serbian cuisine
- kinds: soup, dish
- ingredients: Dutch brown bean, Apium graveolens var. dulce, bell pepper, onion, meat
- has Wikipedia article: en

## DISH Q2056399
- name: Pastırma
- description: Anatolian cuisine cold cut, also found in neighbouring countries
- countries: TR
- kinds: dish, raw whole-muscle cut
- ingredients: camel meat, veal, ox
- has Wikipedia article: en

## DISH Q20571750
- name: Khao kaeng
- description: Thai rice dish
- countries: TH
- kinds: dish
- has Wikipedia article: en

## DISH Q20573009
- name: Aravana
- countries: (none)
- kinds: sweet dish, payasam

## DISH Q20576168
- name: Jemblem
- description: Indonesian savoury snack made of cassava and palm sugar
- countries: ID
- kinds: sweet dish, snack
- ingredients: cassava root, palm sugar, palm oil

## DISH Q20582652
- name: Qaraciyər kababı
- other names: {"az": "Qaraciyər kababı"}
- countries: (none)
- kinds: kebab

## DISH Q20583405
- name: Walnut kuku
- description: Turkish type of kuku dish
- countries: (none)
- kinds: food, kuku

## DISH Q20585312
- name: Brywes
- other names: {"cy": "Brywes"}
- countries: (none)
- kinds: bread dish

## DISH Q20585441
- name: Mum
- description: dish originated in Isan region of Thailand and Laos
- countries: LA, TH
- cuisines: Thai cuisine, Lao cuisine
- kinds: food

## DISH Q2058588
- name: Brugse kletskoppen
- other names: {"nl": "Brugse kletskoppen"}
- countries: (none)
- kinds: cookie, food

## DISH Q20585935
- name: Yayma
- description: Azerbaijani rice pudding
- countries: AZ
- kinds: rice pudding
- ingredients: saffron

## DISH Q20586519
- name: Çığırtma plov
- other names: {"az": "çığırtma plov"}
- description: rice dish with eggs from the Azerbaijani cuisine
- countries: (none)
- kinds: rice dish, egg dish

## DISH Q20587724
- name: Bacem tofu
- description: Indonesian tofu dish cooked in "bacem" style
- countries: ID
- cuisines: Indonesian cuisine
- kinds: tofu, dish, human food, type of food or dish
- ingredients: brown sugar, coconut water, tofu

## DISH Q20587733
- name: Əvəlik aşı
- other names: {"az": "Əvəlik aşı"}
- countries: (none)
- kinds: dish

## DISH Q20590936
- name: Picws mali
- other names: {"cy": "Picws mali"}
- countries: (none)
- kinds: bread dish

## DISH Q205964
- name: Főzelék
- description: Hungarian stew type
- countries: HU
- kinds: dish
- has Wikipedia article: en

## DISH Q20600209
- name: Tatws a llaeth
- other names: {"cy": "Tatws a llaeth"}
- countries: (none)
- kinds: dish
- ingredients: potato, milk

## DISH Q2060624
- name: Gored gored
- description: Ethiopian and Eritrean raw beef dish
- countries: ER, ET
- kinds: raw beef dish
- ingredients: raw meat
- has Wikipedia article: en

## DISH Q2060858
- name: Cachupa
- other names: {"zh": "卡丘帕"}
- description: traditional dish from Cape Verde, considered the national dish
- countries: CV
- cuisines: African cuisine
- kinds: dish, national dish, stew
- ingredients: common bean, fish as food, maize, meat
- has Wikipedia article: en, zh

## DISH Q20614517
- name: Brunsli
- description: Swiss christmas cookie
- countries: CH
- cuisines: Swiss cuisine
- kinds: dish, Christmas cookies
- ingredients: beaten egg whites, almond, cinnamon, sugar, chocolate

## DISH Q20620213
- name: پیس گندله
- other names: {"fa": "پیس گندله"}
- countries: IR
- kinds: pastry

## DISH Q20622033
- name: Ljochtmisbrea
- other names: {"fy": "ljochtmisbrea"}
- countries: (none)
- kinds: bread

## DISH Q20625135
- name: Kocho
- description: Ethiopian flatbread
- countries: ET
- kinds: flatbread
- ingredients: Ensete ventricosum

## DISH Q2063761
- name: Pignolo
- description: classic Italian cookie covered in pine nuts
- countries: IT
- kinds: macaroon
- ingredients: Pasta di mandorle PAT
- has Wikipedia article: en

## DISH Q20639978
- name: Drops
- other names: {"zh": "水果硬糖"}
- description: small, round confectionery made from a mixture of boiled sugar and flavourings
- countries: (none)
- kinds: candy, confectionery
- has Wikipedia article: en

## DISH Q20639980
- name: Kisses (confectionery)
- description: confectionery
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q20644870
- name: Fruktsoppa
- description: fruit soup typically prepared using dried fruit, part of Scandinavian food culture, especially Swedish cuisine
- countries: SE
- cuisines: Swedish cuisine, Norwegian cuisine
- kinds: fruit soup
- ingredients: dried fruit, sugar, red wine
- has Wikipedia article: en

## DISH Q2064491
- name: Pausenbrot
- other names: {"de": "Pausenbrot"}
- description: usually slices of bread with something between, usually prepared at home beforehands, as smaller meal during the day (at school, work)
- countries: (none)
- kinds: merienda, bánh, bread dish, type of food or dish

## DISH Q20645113
- name: Köftes in the Turkish cuisine
- description: "köfte" dishes in the Turkish cuisine
- countries: (none)
- kinds: food, kofta, meatball

## DISH Q20645147
- name: Tekirdağ köfte
- description: Meatballs in the Turkish cuisine, originating from the city and province of Tekirdağ
- countries: (none)
- kinds: Köftes in the Turkish cuisine

## DISH Q20645434
- name: Čunga Lunga
- description: chewing gum
- countries: (none)
- kinds: chewing gum

## DISH Q20650605
- name: Kuru köfte
- description: Turkish cuisine köfte variety
- countries: (none)
- kinds: food, Köftes in the Turkish cuisine
- ingredients: minced meat, Allium, spice, meat, bread
- has Wikipedia article: en

## DISH Q20650795
- name: Ekşili köfte
- description: sour soup from the Turkish cuisine
- countries: TR
- kinds: sour soup

## DISH Q20650896
- name: Turkish soups
- description: soups in the Turkish cuisine
- countries: (none)
- kinds: food, soup

## DISH Q20655532
- name: Shish kebab
- other names: {"zh": "中东烤肉"}
- description: skewered meat dish
- countries: AM
- kinds: meat dish, skewer
- has Wikipedia article: en, zh

## DISH Q20658501
- name: She-crab soup
- description: soup or bisque, made of milk or heavy cream, crab or fish stock, Atlantic blue crab meat, and crab roe, and some dry sherry added as it is plated; a regional specialty from Virginia, South Carolina, and Georgia
- countries: US
- kinds: soup, fish soup, crab dish
- ingredients: Callinectes sapidus
- has Wikipedia article: en

## DISH Q20670432
- name: Tako wasabi
- description: Salted raw octopus with chopped wasabi stems
- countries: JP
- kinds: shiokara
- ingredients: octopus as food, wasabi

## DISH Q20670919
- name: Buğu kebabı
- description: lamb stew from the Turkish cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q20671784
- name: Tetù
- other names: {"it": "Tetù"}
- countries: IT
- kinds: dessert

## DISH Q20679876
- name: Taro with yellow sauce
- countries: CM
- kinds: dish
- ingredients: palm oil, mushroom, spice, meat

## DISH Q2068389
- name: Advieh
- other names: {"zh": "伊朗香料"}
- description: Iranian spice mixture
- countries: IR
- kinds: spice mix
- ingredients: cardamom
- has Wikipedia article: en, zh

## DISH Q20706218
- name: Diamond ring candy
- description: candy
- countries: (none)
- kinds: candy

## DISH Q207104
- name: Sacramental bread
- other names: {"zh": "圣体"}
- description: communion bread used in the Lord's Supper
- countries: (none)
- kinds: bread, wafer cookie, food in religion, religious object, use of bread
- has Wikipedia article: en, zh

## DISH Q20714247
- name: Cruffin
- description: croissant/muffin hybrid
- countries: AU
- kinds: muffin, croissant, type of food or dish
- has Wikipedia article: en

## DISH Q20714587
- name: Black bottom pie
- description: Dessert
- countries: (none)
- kinds: pie
- has Wikipedia article: en

## DISH Q2071540
- name: Lange Jan
- other names: {"nl": "Lange Jan"}
- countries: (none)
- kinds: candy

## DISH Q207220
- name: Muffin
- other names: {"zh": "玛芬"}
- description: type of baked product
- countries: US
- kinds: quick bread
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q20724435
- name: Collégial de Ciney
- other names: {"fr": "Collégial de Ciney"}
- countries: BE
- kinds: raw-milk cheese, cow's-milk cheese, cheese
- ingredients: cow's milk

## DISH Q20726175
- name: Medfouna
- description: Moroccan stuffed dough dish
- countries: MA
- cuisines: Moroccan cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q20726199
- name: Mihmih
- other names: {"fr": "Mihmih"}
- countries: MA
- kinds: dish

## DISH Q20727695
- name: Fenkata
- description: Maltese dish
- countries: MT
- cuisines: Maltese cuisine
- kinds: dish
- ingredients: rabbit meat, Origanum vulgare, olive oil, onion, Allium sativum, wine

## DISH Q20732520
- name: Pumpkin flower fritter
- description: dish
- countries: IT
- kinds: dish
- has Wikipedia article: en

## DISH Q20734
- name: Doner kebab
- other names: {"zh": "土耳其烤肉"}
- description: Turkish dish
- countries: TR
- cuisines: Turkish cuisine
- kinds: type of food or dish, fast food, street food, lamb dish, stuffed flatbread
- ingredients: flatbread, vegetable, meat
- has Wikipedia article: en, zh

## DISH Q2074267
- name: Lomi salmon
- description: hawaiian tomato and salmon salad
- countries: (none)
- kinds: fish dish, salmon dish
- ingredients: salmon
- has Wikipedia article: en

## DISH Q20747642
- name: Salsa verde
- description: spicy Mexican sauce based on tomatillos
- countries: MX
- kinds: food, sauce
- ingredients: Physalis philadelphica
- has Wikipedia article: en

## DISH Q20747991
- name: Arroz poblano
- description: Mexican rice dish
- countries: MX
- kinds: rice dish
- has Wikipedia article: en

## DISH Q20748
- name: Raclette
- description: A Swiss national dish
- countries: CH
- cuisines: Swiss cuisine
- kinds: national dish
- ingredients: potato, Raclette du Valais
- has Wikipedia article: en

## DISH Q20748063
- name: Carne a la tampiqueña
- description: Mexican cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q20748070
- name: Al ajillo (Mexican cuisine)
- description: cooking style
- countries: MX
- kinds: seafood dish
- has Wikipedia article: en

## DISH Q20748123
- name: 希舒梅耶
- countries: FR
- kinds: dish
- ingredients: eggplant, tomato

## DISH Q20751180
- name: Arroz a la tumbada
- description: Mexican dish
- countries: MX
- kinds: rice dish
- has Wikipedia article: en

## DISH Q20754699
- name: St. Galler Bratwurst IGP
- description: Swiss speciality veal and pork sausage
- countries: (none)
- kinds: Bratwurst
- has Wikipedia article: en

## DISH Q20755749
- name: Big One
- countries: (none)

## DISH Q2076907
- name: Yubeshi
- description: Japanese confection
- countries: JP
- kinds: wagashi, rice cake
- ingredients: yuzu, glutinous rice
- has Wikipedia article: en

## DISH Q20776094
- name: Chicharrón en salsa
- description: Mexican dish made from pork rinds
- countries: MX
- kinds: pork dish
- ingredients: chicharrón
- has Wikipedia article: en

## DISH Q2078349
- name: Ajapsandali
- other names: {"zh": "阿賈普桑達利"}
- description: traditional eggplant dish
- countries: AM, AZ, GE, UZ
- kinds: dish
- ingredients: eggplant, Cuminum cyminum, black pepper, Daucus, tomato, Allium sativum, salt, potato
- has Wikipedia article: en, zh

## DISH Q20787367
- name: Sprängd anka
- other names: {"sv": "Sprängd anka"}
- countries: (none)
- kinds: dish
- ingredients: duck meat

## DISH Q2079526
- name: Geuteling
- description: Flemish food, similar to a pancake
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q208
- name: Rakfisk
- description: Norwegian fish dish made from trout or char
- countries: NO
- kinds: fish dish
- has Wikipedia article: en

## DISH Q2080641
- name: Café liégeois
- other names: {"zh": "列日咖啡"}
- description: cold dessert of French origin, made from lightly sweetened coffee, coffee flavour ice cream and chantilly cream
- countries: FR
- kinds: dessert
- ingredients: coffee
- has Wikipedia article: en

## DISH Q20809686
- name: Dalwada
- description: Gujarati dish from India
- countries: IN
- kinds: dish
- ingredients: Vigna radiata, peanut oil

## DISH Q20814407
- name: Clemole
- description: traditional dish in Mexican cuisine
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q208172
- name: 法式长棍面包
- description: Long French white bread
- countries: FR
- kinds: food product, bread loaf
- ingredients: yeast, flour, table salt, water
- has Wikipedia article: en, zh

## DISH Q20819041
- name: Doblada (Mexican cuisine)
- description: a Mexican corn or wheat tortilla
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q20819164
- name: Calabacitas con puerco
- description: Traditional Mexican dish
- countries: MX
- kinds: pork dish
- has Wikipedia article: en

## DISH Q20820571
- name: Pönnukaka
- countries: (none)
- kinds: pancake

## DISH Q20822378
- name: Pulpo a la campechana
- description: Mexican dish made with octopus
- countries: MX
- kinds: octopus dish
- has Wikipedia article: en

## DISH Q2082513
- name: Zwaantje
- other names: {"nl": "zwaantje"}
- countries: (none)
- kinds: pastry

## DISH Q20826672
- name: Boeber
- description: Malay dish
- countries: ZA
- kinds: dish
- has Wikipedia article: en

## DISH Q2083470
- name: Pfefferpotthast
- description: German dish
- countries: DE
- kinds: dish
- has Wikipedia article: en

## DISH Q2083501
- name: Vleessalade
- other names: {"nl": "vleessalade"}
- countries: (none)
- kinds: salad

## DISH Q2084500
- name: Pfälzer Bauernseufzer
- other names: {"de": "Pfälzer Bauernseufzer"}
- countries: (none)
- kinds: dish

## DISH Q20847867
- name: Curry fishball
- other names: {"zh": "咖喱魚蛋"}
- description: Hong Kong street food
- countries: (none)
- kinds: street food
- has Wikipedia article: en, zh

## DISH Q20851509
- name: Brzadowô zupa
- other names: {"csb": "brzadowô zupa"}
- countries: PL
- kinds: soup

## DISH Q20855047
- name: Kpekpele
- description: food eaten by the Gas during Homowo
- countries: GH
- kinds: food
- ingredients: okra, cornmeal, Capsicum, onion
- has Wikipedia article: en

## DISH Q20855173
- name: Red red
- description: Ghanaian dish made of black eyed peas cooked in palm oil
- countries: GH
- kinds: dish
- ingredients: black-eyed pea, palm oil, table salt, water
- has Wikipedia article: en

## DISH Q20856260
- name: Chileajo de cerdo
- description: Pork dish in Mexican cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q2087110
- name: Sklandrausis
- description: traditional Latvian dish
- countries: LV
- cuisines: Latvian cuisine
- kinds: food, pie
- ingredients: caraway seeds, potato, rye flour, carrot
- has Wikipedia article: en

## DISH Q20872372
- name: Limón serrano
- other names: {"es": "Limón serrano"}
- description: salad of citrus fruits and charcuterie from Spain
- countries: ES
- kinds: salad
- ingredients: embutido, citrus fruit

## DISH Q20872378
- name: Puchero de hinojos
- description: Cooked white beans or chickpeas with fennel, traditional in some areas of Andalusia, Spain
- countries: ES
- cuisines: Spanish cuisine
- kinds: food, type of food or dish, potage

## DISH Q20872389
- name: Mint soup
- countries: ES
- cuisines: Spanish cuisine
- kinds: soup
- ingredients: Mentha spicata

## DISH Q208729
- name: Nougat
- other names: {"zh": "牛轧糖"}
- description: confection
- countries: (none)
- kinds: confectionery
- ingredients: hazelnut, sugar
- has Wikipedia article: en, zh

## DISH Q20875713
- name: Milk pilaf
- description: Turkish pilav (pilaf) variety with milk
- countries: TR
- kinds: food, pilav
- ingredients: milk, rice

## DISH Q20876496
- name: Pauladina de Terrassa
- other names: {"ca": "Pauladina de Terrassa"}
- countries: (none)
- kinds: confectionery

## DISH Q2088672
- name: Weespermop
- description: Dutch cookie made of almonds
- countries: (none)
- kinds: food, cookie
- ingredients: Prunus dulcis, sugar

## DISH Q2088910
- name: Zwartwit
- other names: {"nl": "Zwartwit"}
- countries: (none)
- kinds: candy

## DISH Q2089007
- name: Rigotte de Condrieu
- description: French cheese
- countries: FR
- kinds: French cheese, goat cheese, white mold-rind cheese, raw-milk cheese
- ingredients: goat milk
- has Wikipedia article: en

## DISH Q20892154
- name: Fast food in the United States and Canada
- other names: {"zh": "美国和加拿大的快餐食品"}
- description: iconic fast food items found in restaurant chains in North America
- countries: (none)
- kinds: fast food

## DISH Q2089240
- name: Oatmeal
- other names: {"zh": "燕麦片"}
- description: porridge dish made from oat grains (groats, flakes, flour)
- countries: (none)
- kinds: dish, vegan food, groat, food ingredient
- ingredients: oats, Avena sativa
- has Wikipedia article: en, zh

## DISH Q2089470
- name: Vijfschaft
- other names: {"nl": "vijfschaft"}
- countries: (none)
- kinds: dish, type of food or dish
- ingredients: potato, onion, Dutch brown bean, apple, carrot

## DISH Q2089716
- name: Pljeskavica
- other names: {"zh": "普列卡維察"}
- description: traditional Balkan (Serbian) meat dish
- countries: RS
- cuisines: Serbian cuisine
- kinds: meat product, patty
- ingredients: table salt, beef, pork, black pepper, onion
- has Wikipedia article: en, zh

## DISH Q20899172
- name: Misri
- description: lump sugar, confectionary
- countries: IN
- kinds: rock candy
- has Wikipedia article: en

## DISH Q20917544
- name: Brain Blasterz
- other names: {"fi": "Brain Blasterz"}
- countries: (none)
- kinds: candy

## DISH Q20918234
- name: Ispinä
- other names: {"fi": "Ispinä"}
- countries: (none)
- kinds: dish

## DISH Q20919276
- name: Lämmin voileipä
- other names: {"fi": "lämmin voileipä"}
- countries: (none)
- kinds: sandwich

## DISH Q20920934
- name: San Francisco sourdough
- other names: {"fi": "San Francisco sourdough"}
- countries: (none)
- kinds: bread

## DISH Q20921881
- name: Cañas
- other names: {"es": "Cañas"}
- countries: ES
- kinds: dessert

## DISH Q20921887
- name: Codornices estofadas
- other names: {"es": "Codornices estofadas"}
- countries: (none)
- kinds: dish

## DISH Q20921898
- name: Jamón asado
- description: Galician dish
- countries: ES
- cuisines: Galician cuisine
- kinds: pork dish

## DISH Q20921917
- name: Rusos de Alfaro
- other names: {"es": "Rusos de Alfaro"}
- countries: ES
- kinds: dessert

## DISH Q20921925
- name: Tarta de Puentedeume
- other names: {"es": "Tarta de Puentedeume"}
- countries: ES
- kinds: dessert

## DISH Q209253
- name: Satay
- other names: {"zh": "沙嗲"}
- description: type of skewers dish from Indonesia
- countries: ID
- cuisines: Singaporean cuisine, Indonesian cuisine
- kinds: food, skewer
- ingredients: fish, chicken as food, seafood, offal, meat, satay sauce, kecap, garlic, stick, chicken fingers, peanut, goat meat, soy sauce, Allium ascalonicum, beef, lime, table salt, drinking water
- has Wikipedia article: en, zh

## DISH Q2093743
- name: Sopa paraguaya
- description: gastronomic dish of Paraguay
- countries: PY
- cuisines: Paraguayan cuisine
- kinds: bread
- ingredients: cornmeal, egg as food, onion, cheese, milk
- has Wikipedia article: en

## DISH Q209486
- name: Niçard salad
- other names: {"zh": "尼斯沙拉"}
- description: composed tomato, egg, fish and vegetable salad
- countries: FR
- kinds: dish, salad, tuna dish
- ingredients: basil, globe artichoke, celery, garlic, Raphanus sativus, Olive de Nice, Mesclun, Thunnus, bell pepper, boiled egg, scallion, European anchovy, olive oil, tomato
- has Wikipedia article: en

## DISH Q2095020
- name: Markook
- description: Syrian bread
- countries: SY
- kinds: food, bread
- has Wikipedia article: en

## DISH Q2095042
- name: Pillekuchen
- other names: {"de": "Pillekuchen"}
- countries: DE
- kinds: culinary speciality, potato dish

## DISH Q2095632
- name: Sloppy joe
- other names: {"zh": "邋遢喬"}
- description: Variety of sandwich made with ground meat
- countries: US
- kinds: beef dish, meat sandwich
- ingredients: ground beef
- has Wikipedia article: en, zh

## DISH Q2096475
- name: Palmier
- other names: {"zh": "蝴蝶酥"}
- description: French pastry
- countries: FR
- kinds: type of food or dish, dessert, pastry
- ingredients: puff pastry
- has Wikipedia article: en, zh

## DISH Q20968815
- name: Mimolette extra vieille
- description: French cheese
- countries: FR
- kinds: French cheese, Mimolette, pressed uncooked cheese

## DISH Q2096886
- name: Serundeng
- description: Javanese meat dish with grated coconut
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, meat dish
- ingredients: Indonesian bay leaf, shallot, garlic, coriander seed, coconut, palm sugar, Alpinia galanga, Cymbopogon citratus
- has Wikipedia article: en

## DISH Q20970577
- name: Flower of Love Nigiri
- other names: {"zh": "花之戀"}
- description: Sushi
- countries: (none)
- kinds: nigirizushi
- has Wikipedia article: zh

## DISH Q20971886
- name: Salade lyonnaise
- countries: FR
- kinds: salad

## DISH Q20972433
- name: Méture
- description: corn bread
- countries: FR
- kinds: bread

## DISH Q2097276
- name: Smalahove
- description: dish made from a sheep's head
- countries: NO
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q20979646
- name: Hoggan
- description: Cornish type of bread
- countries: (none)
- kinds: flatbread
- has Wikipedia article: en

## DISH Q20980111
- name: Pan de cazón
- description: Mexican casserole
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q2098139
- name: Kringle
- description: Northern European baked pastry shaped into a knot, variety of pretzel
- countries: RU, FI, DE, DK
- cuisines: Russian cuisine, Finnish cuisine, German cuisine, Danish cuisine
- kinds: pastry, dish, baked good
- ingredients: rye flour, wheat flour
- has Wikipedia article: en

## DISH Q20981512
- name: Dikgobe
- description: dish of samp and beans
- countries: BW
- kinds: dish
- ingredients: samp, bean
- has Wikipedia article: en

## DISH Q20981977
- name: Spatlo
- description: South African street food
- countries: ZA
- kinds: sandwich
- ingredients: fries, meat, bread
- has Wikipedia article: en

## DISH Q20984134
- name: Fujian red wine chicken
- description: Chicken dish
- countries: CN
- kinds: sauce, chicken dish
- ingredients: chicken as food, wine
- has Wikipedia article: en

## DISH Q20984265
- name: Bột chiên
- description: fried rice flour cakes
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q20984266
- name: Bì cuốn
- description: Vietnamese pork and rice rolls
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q20984269
- name: Cơm gà rau thơm
- description: Chicken and rice dish from Vietnamese cuisine
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q20984273
- name: Gà nướng sả
- other names: {"zh": "香茅燒雞"}
- description: Vietnamese lemongrass chicken
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q20984302
- name: Bánh bột lọc
- description: small, clear-looking, chewy tapicoa dumpling in Vietnamese cuisine
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: stuffed pasta, bánh, pork dish, shrimp dish
- ingredients: shrimp and prawn as food, pork belly, tapioca
- has Wikipedia article: en

## DISH Q20987430
- name: Malu Mirisata
- description: spicy Sri Lankan fish curry
- countries: LK
- kinds: fish curry
- ingredients: fish
- has Wikipedia article: en

## DISH Q20987738
- name: Ash-e doogh
- other names: {"zh": "伊朗酸奶汤"}
- description: traditional soup dish
- countries: IR
- kinds: soup
- ingredients: yogurt
- has Wikipedia article: en, zh

## DISH Q20987904
- name: Masghati
- description: soft, translucent Iranian confection
- countries: IR
- kinds: confectionery
- has Wikipedia article: en

## DISH Q20987994
- name: Sholezard
- other names: {"zh": "番紅花米布丁"}
- description: Iranian dessert
- countries: IR
- cuisines: Iranian cuisine
- kinds: dish, dessert
- ingredients: rice, cardamom, rose water, butter, cinnamon, saffron, coffee
- has Wikipedia article: en

## DISH Q20988782
- name: Tahini cookie
- description: Egyptian dessert
- countries: (none)
- kinds: dessert
- ingredients: tehina
- has Wikipedia article: en

## DISH Q20988817
- name: Ziva
- other names: {"zh": "姬瓦菜"}
- description: Israeli dish
- countries: IL
- cuisines: Israeli cuisine
- kinds: dish, meal
- ingredients: olive, puff pastry, cheese
- has Wikipedia article: en

## DISH Q21002167
- name: Fruita en almívar
- other names: {"ca": "fruita en almívar"}
- countries: (none)
- kinds: dessert, fruit preserves
- ingredients: glucose syrup, fruit

## DISH Q21004069
- name: Relleno Negro
- description: Mexican dish
- countries: MX
- cuisines: Mexican cuisine
- kinds: dish
- ingredients: turkey meat, pork, chili pepper
- has Wikipedia article: en

## DISH Q21005946
- name: Ayam masak merah
- description: Malaysian traditional dish
- countries: MY
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q21007833
- name: Spit cake
- other names: {"zh": "炙叉蛋糕"}
- description: european-style cake roasted on a rotating spit
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q21009183
- name: Langues de porc à la mode de Troyes
- other names: {"fr": "langues de porc à la mode de Troyes"}
- countries: (none)
- kinds: dish
- ingredients: pork tongue

## DISH Q2101181
- name: Polbo á feira
- description: Traditional Galician dish
- countries: (none)
- cuisines: Galician cuisine
- kinds: dish, octopus dish
- ingredients: octopus as food, paprika, olive oil, table salt
- has Wikipedia article: en

## DISH Q21012658
- name: Piedra (Mexican cuisine)
- description: Mexican stuffed corn dumpling
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q21014439
- name: Kue gapit
- description: Indonesian traditional snack
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack
- ingredients: tapioca, coconut milk, egg as food, table salt, sugar
- has Wikipedia article: en

## DISH Q21014551
- name: Galuchon
- other names: {"fr": "galuchon"}
- description: French cooking recipe
- countries: FR
- kinds: culinary speciality

## DISH Q21025055
- name: Muroran curry ramen
- description: specialty Ramen of Muroran, Hokkaido, Japan
- countries: JP
- kinds: curry ramen, ramen in Hokkaido
- has Wikipedia article: en

## DISH Q21028989
- name: Hare à la royale
- description: French culinary dish
- countries: FR
- kinds: food, rabbit dish
- has Wikipedia article: en

## DISH Q21029475
- name: Silter PDO
- other names: {"zh": "Silter DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, cow's-milk cheese, Italian cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q21041059
- name: Slezský stryk
- other names: {"cs": "Slezský stryk"}
- countries: (none)
- kinds: dish, potato dish

## DISH Q21044363
- name: Conejito
- description: Chilean pastry
- countries: CL
- kinds: meal, pastry
- has Wikipedia article: en

## DISH Q2105597
- name: Poschweck
- countries: (none)
- kinds: pastry

## DISH Q21057408
- name: Prosciutto de Capitán Pastene
- countries: CL
- kinds: raw ham
- ingredients: pork thigh

## DISH Q21059510
- name: 연근전
- other names: {"ko": "연근전"}
- countries: (none)
- kinds: jeon

## DISH Q21060314
- name: Jumeok-bap
- other names: {"zh": "拳頭飯"}
- description: Korean rice balls
- countries: (none)
- kinds: rice ball
- ingredients: bap
- has Wikipedia article: en

## DISH Q21061471
- name: Pope Ladies
- countries: (none)
- kinds: bun
- has Wikipedia article: en

## DISH Q2106483
- name: Trachitol
- description: throat lozenge brand
- countries: (none)
- kinds: medication, cough drop
- has Wikipedia article: en

## DISH Q2106620
- name: Pottsuse
- countries: DE
- kinds: food, spread
- ingredients: pork

## DISH Q2106693
- name: Baozhong
- other names: {"zh": "文山包種茶"}
- description: famous Taiwan spring tea between green and oolong
- countries: TW
- kinds: oolong
- has Wikipedia article: en, zh

## DISH Q2106765
- name: Poume d'oranges
- description: Medieval pork dish
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q2107118
- name: Powidltascherl
- countries: (none)
- kinds: dish

## DISH Q2107869
- name: Prasselkuchen
- countries: (none)
- kinds: cake

## DISH Q21079042
- name: Black peas
- description: traditional Lancashire dish
- countries: GB
- kinds: dish
- ingredients: pea
- has Wikipedia article: en

## DISH Q21080963
- name: Sandwich bread
- other names: {"zh": "三明治吐司"}
- description: bread designed for sandwich making
- countries: (none)
- kinds: bread, white bread, sliced bread
- has Wikipedia article: en, zh

## DISH Q21082813
- name: Flaona
- description: food
- countries: ES
- kinds: cake

## DISH Q21083016
- name: Purslane stew
- description: Turkish dish
- countries: TR
- kinds: dish

## DISH Q2108393
- name: Sale pisang
- description: dried banana dish from Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dessert, dish, human food, type of food or dish, cookie, snack, kue, traditional food, banana dish
- ingredients: Cavendish banana, table salt, water, glutinous rice flour

## DISH Q21086244
- name: Sèpia amb pèsols
- other names: {"ca": "Sèpia amb pèsols"}
- countries: (none)
- kinds: dish
- ingredients: sepia, Pisum sativum

## DISH Q21086249
- name: Tap de Cadaqués
- other names: {"ca": "tap de Cadaqués"}
- countries: ES
- kinds: cake, sponge cake
- ingredients: glucose syrup, egg as food, flour, sugar

## DISH Q21087825
- name: Caluk noodles
- description: Indonesian traditional noodle
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, noodle dish
- ingredients: Indonesian bay leaf, Kaffir Lime Leaf, garlic, tomato, Mi Gomak, ginger, peanut, kecap manis, fried onion, seedling, Aleurites moluccanus, Kaempferia galanga, scallion, krupuk, bird's eye chili, cooking oil, broth, soy sauce, chili pepper, black pepper, Brassica oleracea var. capitata, Apium graveolens, Cucumis sativus, table salt, water
- has Wikipedia article: en

## DISH Q21091274
- name: Pırasa
- other names: {"ca": "Pırasa"}
- countries: (none)
- kinds: food, dish
- ingredients: leek

## DISH Q21091894
- name: Ramyeon
- description: Korean instant noodle
- countries: KR
- kinds: food, noodle soup
- ingredients: Chinese noodles
- has Wikipedia article: en

## DISH Q21126937
- name: Dible
- other names: {"ca": "Dible"}
- countries: TR
- kinds: dish
- ingredients: bean, rice

## DISH Q2112994
- name: Prophetenkuchen
- other names: {"de": "Prophetenkuchen"}
- countries: DE
- cuisines: German cuisine
- kinds: pie

## DISH Q21133282
- name: Anelloni
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta

## DISH Q211361
- name: Matzah
- other names: {"zh": "猶太逾越節薄餅"}
- description: unleavened flatbread in Jewish cuisine; an element of the Passover festival
- countries: EG
- kinds: flatbread, unleavened bread
- ingredients: flour, drinking water
- has Wikipedia article: en, zh

## DISH Q21156490
- name: Chocolate egg
- description: chocolate shaped as an egg
- countries: (none)
- kinds: chocolate

## DISH Q21162481
- name: Güveç
- description: terracotta cooking pan and a variety of dishes in the Turkish cuisine
- countries: (none)
- kinds: meat dish, cooking pot, vegetable dish

## DISH Q2118270
- name: Pumpkin pie
- other names: {"zh": "南瓜餅"}
- description: traditional sweet dessert
- countries: US
- cuisines: cuisine of the United States
- kinds: sweet pie
- ingredients: ginger, maple syrup, pumpkin, egg as food, flour, butter, cinnamon, sugar
- has Wikipedia article: en, zh

## DISH Q21188673
- name: Boero
- other names: {"it": "boero"}
- countries: IT
- kinds: bonbon

## DISH Q21190046
- name: Bigoli in salsa
- description: Venetian pasta dish
- countries: IT
- kinds: pasta dish
- ingredients: bigoli, Engraulidae
- has Wikipedia article: en

## DISH Q21190161
- name: Luccio in salsa
- other names: {"it": "Luccio in salsa"}
- description: Italian dish
- countries: IT
- kinds: dish
- ingredients: pike

## DISH Q21190195
- name: Prosciutto di Venticano PAT
- other names: {"zh": "Prosciutto di Venticano PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product, prosciutto

## DISH Q21193080
- name: Ciambella di San Cataldo
- other names: {"it": "Ciambella di San Cataldo"}
- countries: IT
- kinds: dessert

## DISH Q2119414
- name: Paniyaram
- description: Indian dish
- countries: IN
- kinds: rice dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q2119832
- name: Barley sugar
- other names: {"zh": "大麥糖"}
- description: traditional variety of boiled sweet (hard candy), often yellow or orange in colour, which is usually made with an extract of barley, giving it a characteristic taste and colour
- countries: (none)
- kinds: hard candy
- has Wikipedia article: en

## DISH Q2120103
- name: Potato pyzy
- other names: {"zh": "皮茲"}
- description: potato dish
- countries: PL
- kinds: potato dish, pyzy, potato-dough dumpling

## DISH Q2120163
- name: Pâté de campagne
- countries: FR
- kinds: dish, pâté

## DISH Q2120502
- name: Pé de moleque
- other names: {"pt": "pé de moleque"}
- description: traditional Brazilian sweet made of peanuts and jaggery or molasses
- countries: BR
- kinds: confectionery
- ingredients: peanut, sugarcane
- has Wikipedia article: en

## DISH Q2121057
- name: Glacé cherry
- description: candied cherries
- countries: (none)
- kinds: candied fruit
- ingredients: sugar, cherry
- has Wikipedia article: en

## DISH Q21210941
- name: Fiapòn
- other names: {"it": "Fiapòn"}
- countries: IT
- kinds: dessert

## DISH Q21210947
- name: Prosciutto mantovano
- other names: {"it": "Prosciutto mantovano"}
- countries: IT
- kinds: prosciutto

## DISH Q21210955
- name: Agnolini
- description: Stuffed pasta originally from the Italian region of Lombardy
- countries: IT
- kinds: pasta
- ingredients: egg pasta, stuffed pasta
- has Wikipedia article: en

## DISH Q21210961
- name: Torta del buonumore
- other names: {"it": "Torta del buonumore"}
- countries: IT
- kinds: dessert

## DISH Q21210967
- name: Tortello della Possenta
- other names: {"it": "tortello della Possenta"}
- countries: IT
- kinds: type of pasta, stuffed pasta, egg pasta

## DISH Q21210969
- name: Tricotto
- other names: {"it": "Tricotto"}
- countries: IT
- kinds: dessert

## DISH Q21210971
- name: Turtèl sguasaròt
- other names: {"it": "Turtèl sguasaròt"}
- countries: IT
- kinds: dessert

## DISH Q2121797
- name: Sicilian pizza
- other names: {"zh": "西西里披薩"}
- description: style of pizza originating from Sicily, Italy
- countries: IT
- kinds: type of pizza
- has Wikipedia article: en, zh

## DISH Q21218886
- name: Carota dell'Altopiano del Fucino PGI
- other names: {"zh": "Carota dell'Altopiano del Fucino IGP"}
- description: Italian PGI fruit, vegetable or cereal product
- countries: IT
- kinds: geographical indications and traditional specialities of the European Union, agricultural product, carrot

## DISH Q21225089
- name: Uyutma
- description: traditional dried fruit and milk dessert of Turkey
- countries: TR
- kinds: food, dessert
- ingredients: fig, sugar, milk

## DISH Q2122633
- name: Queijo de Azeitão
- description: Portuguese cheese
- countries: PT
- kinds: sheep milk cheese, washed-rind cheese, cheese
- ingredients: sheep milk
- has Wikipedia article: en

## DISH Q21233952
- name: Budyń
- description: type of steamed dish part of Polish cuisine
- countries: PL
- cuisines: Polish cuisine
- kinds: dish

## DISH Q2123759
- name: Qâlat daqqa
- description: Tunisian spice blend
- countries: TN
- kinds: spice mix
- ingredients: grains of paradise, black pepper, clove, nutmeg, cinnamon
- has Wikipedia article: en

## DISH Q21244926
- name: Chicken Lahori
- description: A stewed chicken dish from Lahore, Pakistan
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q2125335
- name: Racuchy
- description: Polish sweet dish
- countries: PL
- cuisines: Polish cuisine
- kinds: potato dish, food
- has Wikipedia article: en

## DISH Q21263086
- name: Pa de pages catala
- description: Catalan bread
- countries: (none)
- kinds: bread

## DISH Q21282957
- name: Finskepinner
- description: Norwegian shortbread cookies
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q2130319
- name: Rampen
- other names: {"de": "Rampen"}
- countries: (none)
- kinds: offal, dish

## DISH Q213105
- name: Biangbiang noodles
- other names: {"zh": "𰻝𰻝面"}
- description: Shaanxi dish of thick, broad, hand-made noodles
- countries: CN
- kinds: dish, noodle, Chinese noodles
- has Wikipedia article: en, zh

## DISH Q21328980
- name: Niggilan
- other names: {"it": "Niggilan"}
- countries: IT
- kinds: dessert

## DISH Q2134477
- name: Ražnjići
- other names: {"zh": "塞爾維亞肉串"}
- description: Balkan grilled meat
- countries: RS
- kinds: food, skewer
- ingredients: meat
- has Wikipedia article: en

## DISH Q2135193
- name: Natas do Céu
- description: Portuguese dessert
- countries: PT
- kinds: dessert
- ingredients: doce de ovos, cookie, cream
- has Wikipedia article: en

## DISH Q2136770
- name: Reformationsbrötchen
- other names: {"de": "Reformationsbrötchen"}
- countries: (none)
- kinds: viennoiserie

## DISH Q2138741
- name: Kokinisto
- other names: {"nl": "kokinisto"}
- countries: (none)
- kinds: stew

## DISH Q2139026
- name: Rehrücken
- other names: {"de": "Rehrücken"}
- countries: AT, DE
- kinds: cake

## DISH Q2139778
- name: Gentse mokken
- other names: {"nl": "Gentse mokken"}
- countries: (none)
- kinds: cookie, food

## DISH Q21402490
- name: Balık böreği
- description: Turkish börek made with fish meat
- countries: TR
- kinds: dish, börek

## DISH Q2140326
- name: Tumtum
- other names: {"nl": "tumtum"}
- countries: (none)
- kinds: candy, type of food or dish

## DISH Q2140466
- name: Buckwheat cake
- countries: (none)
- kinds: dish

## DISH Q2141042
- name: Acar
- description: vegetable pickle made in Indonesia, Malaysia, Singapore and Brunei
- countries: ID
- kinds: food, salad
- ingredients: acetic acid, Cucumis sativus, vegetable, sugar, carrot
- has Wikipedia article: en

## DISH Q21418938
- name: Celery root salad
- description: Turkish cuisine salad of celery roots
- countries: (none)
- kinds: dish, salad
- ingredients: celeriac

## DISH Q2142465
- name: Crudités
- other names: {"zh": "法式生菜沙拉"}
- description: traditional French appetizers consisting of sliced or whole raw vegetables (celery, carrot, cucumber, bell pepper, broccoli, cauliflower, fennel, asparagus, ...) which are typically dipped in a vinaigrette or other dipping sauce
- countries: FR
- cuisines: French cuisine
- kinds: vegetable dish
- has Wikipedia article: en

## DISH Q21427074
- name: Clémentine de Corse
- description: Corsican clementine
- countries: FR
- kinds: fruit, Citrinos × clementina

## DISH Q21427573
- name: Mâche nantaise
- other names: {"fr": "Mâche nantaise"}
- countries: FR
- kinds: salad

## DISH Q21427617
- name: Melon du Quercy
- description: French cantaloupe
- countries: FR
- kinds: fruit, muskmelon

## DISH Q21427661
- name: Burgundy mustard
- countries: FR
- kinds: mustard
