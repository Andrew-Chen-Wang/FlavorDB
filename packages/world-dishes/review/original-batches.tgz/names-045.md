# Review batch names-045

## DISH Q5100723
- name: Chinese chicken salad
- other names: {"zh": "中式鸡沙律"}
- description: U.S. salad with chopped chicken, romaine lettuce and cabbage, deep-fried wonton skins or rice vermicelli, nuts (sliced almonds, cashews or peanuts), with a vinaigrette of vegetable oil, sesame oil, and rice vinegar (or citrus juice)
- countries: US
- kinds: chicken salad
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q5100855
- name: Chinese pancake
- description: wheat flour-based Chinese food with a flattened or disk-like shape
- countries: (none)
- kinds: bread, dish
- has Wikipedia article: en

## DISH Q5101003
- name: Ching bo leung
- other names: {"zh": "清补凉"}
- description: Chinese sweet cold soup
- countries: CN
- kinds: food, soup
- ingredients: Coix lacryma-jobi
- has Wikipedia article: en, zh

## DISH Q5102127
- name: Chislic
- description: traditional South Dakotan dish similar to shashlik
- countries: US
- kinds: skewer, meat dish
- has Wikipedia article: en

## DISH Q5102129
- name: Chirmol
- description: Central American cuisine or condiment
- countries: GT, HN, MX, SV
- kinds: condiment, sauce
- has Wikipedia article: en

## DISH Q5102345
- name: Chitranna
- description: Indian rice-based dish
- countries: IN
- cuisines: Karnataka cuisine
- kinds: rice dish
- ingredients: lemon, spice, rice
- has Wikipedia article: en

## DISH Q5102594
- name: Chivito
- description: goat dish eaten in Argentina
- countries: (none)
- kinds: goat meat dish
- has Wikipedia article: en

## DISH Q5103586
- name: Chocolate-covered raisin
- other names: {"zh": "巧克力葡萄乾"}
- description: raisins coated in a shell of milk, dark or white chocolate.
- countries: (none)
- kinds: confectionery
- ingredients: raisin
- has Wikipedia article: en

## DISH Q5103596
- name: Chocolate Biscuit pudding
- description: Sri Lankan dessert
- countries: LK
- kinds: pudding
- ingredients: Marie biscuit
- has Wikipedia article: en

## DISH Q5103643
- name: Chocolate-covered almonds
- description: type of candy
- countries: (none)
- kinds: food, confectionery
- ingredients: Prunus dulcis
- has Wikipedia article: en

## DISH Q5103646
- name: Chocolate biscuit
- description: biscuit which is flavoured with chocolate solids or covered in chocolate
- countries: (none)
- kinds: biscuit, chocolate dish
- ingredients: cocoa bean, Theobroma cacao, flour, chocolate
- has Wikipedia article: en

## DISH Q5103652
- name: Chocolate chip cookie dough ice cream
- description: ice cream flavor
- countries: US
- kinds: ice cream
- ingredients: chocolate chip cookie
- has Wikipedia article: en

## DISH Q5103653
- name: Chocolate fish
- description: Confectionary popular in New Zealand
- countries: NZ
- kinds: food, confectionery
- has Wikipedia article: en

## DISH Q5103654
- name: Chocolate crackles
- description: popular children's confection in Australia and New Zealand based on puffed rice
- countries: AU
- kinds: cupcake
- ingredients: Rice Krispies
- has Wikipedia article: en

## DISH Q5103662
- name: Chocolate marquise
- description: cake
- countries: FR
- kinds: dish, food
- ingredients: dark chocolate
- has Wikipedia article: en

## DISH Q5103667
- name: Chocolate sandwich
- description: type of sandwich
- countries: MX
- kinds: food, sandwich
- ingredients: bread, chocolate
- has Wikipedia article: en

## DISH Q5103668
- name: Chocolate pudding
- other names: {"zh": "巧克力布丁"}
- description: class of desserts with chocolate flavors
- countries: (none)
- kinds: pudding
- has Wikipedia article: en, zh

## DISH Q5103669
- name: Chocolate tart
- description: dark chocolate dessert
- countries: (none)
- kinds: chocolate dessert, sweet tart
- ingredients: shortcrust pastry, chocolate
- has Wikipedia article: en

## DISH Q510387
- name: Faggot
- other names: {"zh": "英式肉丸"}
- description: traditional dish in the UK
- countries: GB
- kinds: dish
- ingredients: offal
- has Wikipedia article: en, zh

## DISH Q5104057
- name: Choila
- description: Newari grilled buffalo dish
- countries: NP
- kinds: dish
- has Wikipedia article: en

## DISH Q5104308
- name: Cholermus
- description: traditional dish from Switzerland
- countries: CH
- kinds: food, pancake
- has Wikipedia article: en

## DISH Q51051035
- name: Smurfentaart
- other names: {"nl": "Smurfentaart"}
- countries: (none)
- kinds: cake

## DISH Q5105172
- name: Chorley cake
- description: flattened, fruit filled pastry cake
- countries: (none)
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q510521
- name: Balushahi
- description: South Asian donuts
- countries: IN
- kinds: confectionery, mithai
- ingredients: maida flour
- has Wikipedia article: en

## DISH Q5105498
- name: Chow-chow
- description: North American pickled relish
- countries: US
- cuisines: cuisine of the United States
- kinds: relish
- ingredients: vinegar
- has Wikipedia article: en

## DISH Q5105519
- name: Chow mein sandwich
- other names: {"zh": "炒面三明治"}
- description: regional sandwich of Fall River, Massachusetts
- countries: US
- kinds: sandwich
- ingredients: hamburger
- has Wikipedia article: en

## DISH Q5105636
- name: Chremslach
- description: Jewish holiday food item
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q51127905
- name: Spaghetti alla Nerano
- description: pasta dish
- countries: IT
- cuisines: Italian cuisine
- kinds: pasta dish
- ingredients: zucchini, Provolone del Monaco PDO, spaghetti
- has Wikipedia article: en

## DISH Q5115955
- name: Chugchucaras
- description: food of Ecuador
- countries: EC
- kinds: food
- has Wikipedia article: en

## DISH Q5117388
- name: Soto
- other names: {"zh": "印尼雞湯飯"}
- description: Indonesian soup
- countries: ID
- kinds: soup
- has Wikipedia article: en, zh

## DISH Q51183258
- name: Sorrentinos
- description: pasta stuffed with filling
- countries: AR
- kinds: single course, pasta
- has Wikipedia article: en

## DISH Q5118913
- name: Chè bà ba
- description: Vietnamese dessert
- countries: VN
- kinds: food, soup
- ingredients: coconut milk
- has Wikipedia article: en

## DISH Q5119519
- name: Cider doughnut
- description: type of doughnut
- countries: US
- kinds: doughnut
- ingredients: batter
- has Wikipedia article: en

## DISH Q5120165
- name: Cimpa
- description: several kinds of cake in Sumatra
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack
- has Wikipedia article: en

## DISH Q5120184
- name: Cincalok
- other names: {"zh": "腌虾酱"}
- description: Malay shrimp condiment
- countries: MY
- kinds: fish sauce
- has Wikipedia article: en

## DISH Q5120346
- name: Cincinnati chili
- other names: {"zh": "辛辛那提辣豆醬"}
- description: spiced meat sauce used as a topping for spaghetti
- countries: US
- kinds: pasta dish
- ingredients: ground beef
- has Wikipedia article: en

## DISH Q5123542
- name: City chicken
- description: cubes of meat cooked on a skewer
- countries: US
- kinds: dish
- ingredients: veal, pork
- has Wikipedia article: en

## DISH Q5125438
- name: Clam liquor
- description: liquid released during the cooking of clams
- countries: (none)
- kinds: clam dish
- has Wikipedia article: en

## DISH Q5125439
- name: Clam sauce
- description: pasta sauce
- countries: (none)
- kinds: sauce, clam dish
- has Wikipedia article: en

## DISH Q5125440
- name: Clam cake
- description: seafood dish
- countries: US
- cuisines: cuisine of New England
- kinds: clam dish
- ingredients: clam, batter
- has Wikipedia article: en

## DISH Q5125441
- name: Clam dip
- other names: {"zh": "蛤蜊蘸醬"}
- description: dipping sauce and condiment
- countries: US
- cuisines: cuisine of the United States
- kinds: meal, food, clam dish
- ingredients: clam, sour cream
- has Wikipedia article: en, zh

## DISH Q5125470
- name: Clams oreganata
- description: italian-American seafood dish
- countries: (none)
- kinds: clam dish
- has Wikipedia article: en

## DISH Q5125472
- name: Clams casino
- description: clam dish
- countries: US
- kinds: clam dish
- ingredients: clam
- has Wikipedia article: en

## DISH Q5135110
- name: Clootie dumpling
- other names: {"zh": "苏格兰甜糕"}
- description: traditional Scottish dessert pudding of flour, breadcrumbs, dried fruit, suet, sugar and spices, wrapped up in a floured cloth and simmered
- countries: GB
- cuisines: Scottish cuisine
- kinds: pudding
- ingredients: flour
- has Wikipedia article: en

## DISH Q5139107
- name: Coca flour
- description: coca leaves powder
- countries: BO, PE
- kinds: food, product
- has Wikipedia article: en

## DISH Q5139714
- name: Cocktion
- description: Jamaican dessert
- countries: JM
- kinds: dessert
- ingredients: maize, sugar
- has Wikipedia article: en

## DISH Q5139753
- name: Coco bread
- other names: {"zh": "可可麵包"}
- description: type of bread
- countries: JM
- kinds: bread, baked good
- ingredients: flour
- has Wikipedia article: en

## DISH Q5139783
- name: Cocol
- description: Mexican bread
- countries: MX
- kinds: food, bread
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q5139845
- name: Coconut cake
- other names: {"zh": "椰子蛋糕"}
- description: cake with white frosting and covered in coconut flakes
- countries: US
- kinds: food, cake
- ingredients: coconut
- has Wikipedia article: en, zh

## DISH Q5139848
- name: Coconut doughnut
- description: Type of doughnut in the United States and Canada
- countries: CA
- kinds: doughnut
- ingredients: coconut
- has Wikipedia article: en

## DISH Q5139863
- name: Coconut rice
- description: coconut-flavoured rice
- countries: IN
- kinds: food, rice dish
- ingredients: coconut, cooked rice
- has Wikipedia article: en

## DISH Q514467
- name: Breadstick
- other names: {"zh": "面包棒"}
- description: Italian bread
- countries: IT
- kinds: baked good
- ingredients: flour
- has Wikipedia article: en

## DISH Q514526
- name: Quarkkäulchen
- description: potato dish
- countries: DE
- cuisines: Saxon cuisine
- kinds: pancake, potato dish
- ingredients: quark, dough, raisin
- has Wikipedia article: en

## DISH Q5145957
- name: Collard liquor
- description: liquid remaining after boiling greens
- countries: US
- kinds: food, soup
- has Wikipedia article: en

## DISH Q5149379
- name: Colston bun
- description: Sweet bun with dried fruit and spices
- countries: (none)
- kinds: bun
- ingredients: baker's yeast
- has Wikipedia article: en

## DISH Q5149389
- name: Colt 45
- description: malt liquor
- countries: US
- kinds: malt liquor
- has Wikipedia article: en

## DISH Q5149494
- name: Coltsfoot Rock
- description: British confection
- countries: GB
- kinds: rock candy
- ingredients: rock candy, Tussilago farfara
- has Wikipedia article: en

## DISH Q5150435
- name: Colțunași
- description: Romanian dumplings
- countries: RO
- kinds: type of pasta, dumpling
- ingredients: wheat flour

## DISH Q515692
- name: Pozole
- other names: {"zh": "墨西哥玉米汤"}
- description: Mexican hominy and meat soup
- countries: MX
- cuisines: Mexican cuisine
- kinds: food, soup
- ingredients: hominy
- has Wikipedia article: en

## DISH Q5159611
- name: Coney Island hot dog
- other names: {"zh": "康尼岛热狗"}
- description: hot dog with chili, onions, and mustard
- countries: US
- kinds: food, chili dog
- ingredients: onion
- has Wikipedia article: en

## DISH Q516212
- name: Strammer Max
- description: traditional name applied to various sandwich dishes in German cuisine
- countries: DE
- kinds: sandwich, dish
- ingredients: Mischbrot, fried egg, ham
- has Wikipedia article: en

## DISH Q5162437
- name: Serabi
- description: Indonesian traditional of rice pancake
- countries: ID
- cuisines: Indonesian cuisine, jajan pasar
- kinds: dish, confectionery, human food, type of food or dish, food, pancake, Kuih
- ingredients: wheat flour, rice flour, coconut milk, table salt
- has Wikipedia article: en

## DISH Q5167072
- name: Cookie Cake Pie
- countries: (none)
- kinds: food, pie
- ingredients: cookie dough
- has Wikipedia article: en

## DISH Q5167105
- name: Cookie salad
- description: Type of dessert salad
- countries: US
- kinds: salad
- has Wikipedia article: en

## DISH Q5167429
- name: Cooleeney Farmhouse Cheese
- description: Irish cheese company
- countries: IE
- kinds: cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q51684958
- name: Cachap
- other names: {"ca": "Cachap"}
- countries: (none)
- kinds: confectionery

## DISH Q5169969
- name: Cordial
- description: type of confection in which a fruit filling is placed within a chocolate shell
- countries: (none)
- kinds: confectionery, candy covered fruit
- ingredients: fruit, beta-fructofuranosidase, chocolate
- has Wikipedia article: en

## DISH Q5171046
- name: Corn cookie
- description: baked good made from corn, often sweet
- countries: US
- kinds: cookie
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q5171047
- name: Corn chowder
- other names: {"zh": "玉米巧達濃湯"}
- description: creamy corn soup from the United States
- countries: US
- kinds: food, chowder
- ingredients: maize, onion
- has Wikipedia article: en, zh

## DISH Q5171049
- name: Corn crab soup
- other names: {"zh": "蟹肉粟米羹"}
- description: Chinese soup of corn and crab meat
- countries: CN
- kinds: dish, soup, crab dish
- has Wikipedia article: en

## DISH Q5171054
- name: Corn fritter
- other names: {"zh": "粟米黃金脆餅"}
- description: food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, food
- ingredients: wheat flour, Zea mays Saccharata Group
- has Wikipedia article: en

## DISH Q5171058
- name: Corn on the cob
- other names: {"zh": "玉米棒子"}
- description: food
- countries: (none)
- kinds: food, dish
- has Wikipedia article: en, zh

## DISH Q5171116
- name: Corned beef sandwich
- other names: {"zh": "鹹牛肉三文治"}
- description: type of sandwich
- countries: (none)
- kinds: food, beef dish, meat sandwich
- ingredients: bread
- has Wikipedia article: en

## DISH Q5171854
- name: Cornish game hen
- description: type of chicken
- countries: US
- kinds: food product, broiler
- has Wikipedia article: en

## DISH Q517394
- name: Daube
- description: French stew of beef braised in wine and garlic
- countries: FR
- cuisines: French cuisine
- kinds: stew
- ingredients: beef
- has Wikipedia article: en

## DISH Q5175528
- name: Cottage Pudding
- description: dessert
- countries: US
- kinds: dessert, pudding
- ingredients: maize, glucose syrup, strawberry, lemon, vanilla, sugar, chocolate
- has Wikipedia article: en

## DISH Q5175547
- name: Cottage loaf
- other names: {"zh": "農家麵包"}
- description: type of bread
- countries: GB
- kinds: food, yeast bread
- has Wikipedia article: en, zh

## DISH Q5175921
- name: Coo-coo
- other names: {"zh": "庫庫"}
- description: caribbean dish of cornmeal and okra
- countries: (none)
- kinds: dish, cuisine
- has Wikipedia article: en

## DISH Q5178059
- name: Couque suisse
- description: Belgian sweet pastry
- countries: (none)
- kinds: food, sweet roll
- has Wikipedia article: en

## DISH Q5179420
- name: Cow cod soup
- description: type of soup
- countries: JM
- kinds: food, soup
- ingredients: bull
- has Wikipedia article: en

## DISH Q5179571
- name: Cowboy beans
- description: popular dish in southwestern USA
- countries: US
- kinds: beef dish
- has Wikipedia article: en

## DISH Q51796021
- name: Grilled cheese
- other names: {"zh": "慢煎起司三明治"}
- description: type of cheese sandwich
- countries: (none)
- kinds: cheese sandwich
- has Wikipedia article: en

## DISH Q5180222
- name: Crab Louie
- description: type of salad featuring crab meat, originating from the U.S. west coast in the early 1900s
- countries: US
- cuisines: cuisine of the Western United States
- kinds: dish, salad
- ingredients: crab meat
- has Wikipedia article: en

## DISH Q5180300
- name: Crachi
- description: chocolate bar
- countries: DO
- kinds: product, chocolate bar
- ingredients: milk chocolate, puffed rice
- has Wikipedia article: en

## DISH Q5180411
- name: Crackling bread
- description: bread flavored with cracklings
- countries: US
- kinds: bread, cornbread, pork dish
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q518108
- name: Egg barley
- description: type of egg-based pasta
- countries: HU
- cuisines: Austrian cuisine, Hungarian cuisine, Slovak cuisine
- kinds: pasta
- ingredients: wheat flour, egg as food
- has Wikipedia article: en

## DISH Q5182294
- name: Crappit heid
- other names: {"zh": "鑲魚頭"}
- description: Traditional Scottish fish head dish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q5182527
- name: Craster kipper
- description: esteemed smoked herring of Craster, England
- countries: GB
- kinds: kipper, fish dish
- has Wikipedia article: en

## DISH Q5182787
- name: Crawfish Monica
- description: Louisiana food tradition
- countries: US
- kinds: dish
- ingredients: garlic, tomato, onion, peppercorn, crayfish, butter, cream, table salt, cheese, pasta
- has Wikipedia article: en

## DISH Q5183356
- name: Cream stew
- description: Japanese dish
- countries: JP
- cuisines: yōshoku
- kinds: meat dish, soup
- ingredients: potato, cabbage, roux, onion, vegetable, meat, water, carrot
- has Wikipedia article: en

## DISH Q5183359
- name: Cream cracker
- description: Flat, usually square, savoury biscuit
- countries: (none)
- kinds: food, cracker
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q5183361
- name: Cream horn
- description: Pastry filled with whipped cream
- countries: (none)
- kinds: food, pastry
- ingredients: flaky pastry, whipped cream, egg as food, flour, butter, sugar
- has Wikipedia article: en

## DISH Q5183373
- name: Creamed honey
- description: Honey with hindered crystallization
- countries: (none)
- kinds: honey
- has Wikipedia article: en

## DISH Q5183375
- name: Creamed eggs on toast
- other names: {"zh": "奶油煮蛋配吐司"}
- description: American breakfast
- countries: (none)
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q5184120
- name: Cremoso cheese
- description: Argentine cheese elaborated with cow's milk
- countries: AR
- kinds: cheese, cow's-milk cheese
- has Wikipedia article: en

## DISH Q5185785
- name: Criollo cheese
- description: Mexican grating cheese
- countries: MX
- kinds: Mexican cheese
- has Wikipedia article: en

## DISH Q5186001
- name: Crisp
- description: type of dessert food
- countries: (none)
- kinds: dessert, dish
- ingredients: fruit
- has Wikipedia article: en

## DISH Q518601
- name: Kūčiukai
- other names: {"zh": "庫丘凱"}
- description: small round crunchy biscuits made from wheat flour, poppy seeds, sugar
- countries: LT
- kinds: cookie, Christmas dinner, pastry
- ingredients: poppy seed, baker's yeast, flour, milk
- has Wikipedia article: en

## DISH Q5186074
- name: Crispy tadyang ng baka
- description: Cuisine of the Philippines
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q5186076
- name: Crispy pata
- description: Filipino dish (food)
- countries: PH
- kinds: food, pork dish
- has Wikipedia article: en

## DISH Q5186077
- name: Crispy fried chicken
- other names: {"zh": "炸子雞"}
- description: Chinese dish of fried chicken
- countries: CN
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q51882025
- name: X caboquinho
- description: Brazilian sandwich
- countries: (none)
- kinds: sandwich
- has Wikipedia article: en

## DISH Q5188689
- name: Guoqiao Mixian
- other names: {"zh": "过桥米线"}
- description: Chinese Cuisine
- countries: CN
- cuisines: Yunnan cuisine
- kinds: soup, mixian
- has Wikipedia article: en, zh

## DISH Q5189136
- name: Crow stew
- description: stew made primarily from the meat of a crow
- countries: (none)
- kinds: stew
- ingredients: Corvus
- has Wikipedia article: en

## DISH Q5189826
- name: Crucolo
- description: Italian cheese
- countries: IT
- kinds: cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q5189867
- name: Crudos
- description: German-Chilean dish with raw beef and bread
- countries: CL
- kinds: food, raw beef dish
- ingredients: onion, lemon juice, beef, mayonnaise, table salt, bread
- has Wikipedia article: en

## DISH Q5190246
- name: Pie crust
- description: hard shell of a pie
- countries: (none)
- kinds: baked good, crust
- ingredients: dough, fat, flour

## DISH Q5190257
- name: Crustless bread
- countries: (none)
- kinds: food, bread
- has Wikipedia article: en

## DISH Q5191461
- name: Crème Ninon
- description: French soup
- countries: (none)
- kinds: food, soup
- ingredients: stock
- has Wikipedia article: en

## DISH Q5192112
- name: Cuban pastry
- description: Cuban dessert dish
- countries: CU
- kinds: food, pastry
- ingredients: puff pastry
- has Wikipedia article: en

## DISH Q5192125
- name: Cuban sandwich
- other names: {"zh": "古巴三明治"}
- description: variation of a ham and cheese sandwich of Cuban-American
- countries: (none)
- kinds: sandwich
- ingredients: Cuban bread
- has Wikipedia article: en, zh

## DISH Q5192318
- name: Cuccidati
- other names: {"zh": "库奇达饼"}
- description: Christmas cookies
- countries: IT
- kinds: food
- ingredients: Ficus
- has Wikipedia article: en

## DISH Q5192531
- name: Cudighi
- description: italian-American Sandwich from Michigan's Upper Peninsula
- countries: US
- kinds: food, sandwich
- has Wikipedia article: en

## DISH Q5194622
- name: Curau
- description: Brazilian dessert
- countries: BR
- kinds: jam
- ingredients: milk
- has Wikipedia article: en

## DISH Q5194698
- name: Cured fish
- other names: {"zh": "腌鱼"}
- description: fish treated by curing to reduce spoilage
- countries: (none)
- kinds: preserved fish, fish dish
- has Wikipedia article: en, zh

## DISH Q5194699
- name: Cured salmon
- countries: (none)
- kinds: cured fish
- ingredients: salmon
- has Wikipedia article: en

## DISH Q5194921
- name: Fabes con almejas
- description: Stew originating in northwest Spain
- countries: (none)
- kinds: food, soup, clam dish
- ingredients: clam
- has Wikipedia article: en

## DISH Q5195226
- name: Curry beef turnover
- description: Hong Kong pastry, shaped in a half-moon crescent, with curry beef filling
- countries: HK
- kinds: food, beef dish
- has Wikipedia article: en

## DISH Q5195230
- name: Curry goat
- other names: {"zh": "咖喱山羊"}
- description: spicy stew
- countries: IN
- kinds: food, Indian curry, goat meat dish
- ingredients: goat meat
- has Wikipedia article: en

## DISH Q5195233
- name: Curry pie
- description: variety of savoury pie
- countries: GB
- kinds: food, pie
- has Wikipedia article: en

## DISH Q5195625
- name: Curtido
- other names: {"zh": "库蒂多"}
- description: type of lightly fermented cabbage relish from Central America
- countries: SV
- kinds: salad
- ingredients: Brassica oleracea var. capitata
- has Wikipedia article: en

## DISH Q5196662
- name: Cut cake
- other names: {"zh": "切糕 (糯米糕点)"}
- countries: (none)
- kinds: cake
- has Wikipedia article: en, zh

## DISH Q519753
- name: Buuz
- other names: {"zh": "蒙古包子"}
- description: Mongolian steamed dumpling
- countries: MN, RU
- cuisines: Mongolian cuisine, Buryat cuisine
- kinds: dish, dumpling
- ingredients: black pepper, onion, wheat flour, table salt, meat
- has Wikipedia article: en, zh

## DISH Q519761
- name: Chuanr
- other names: {"zh": "中式烤串"}
- description: Chinese street food
- countries: CN
- kinds: grilled skewer
- ingredients: seafood, vegetable, meat
- has Wikipedia article: en, zh

## DISH Q5202905
- name: Sopa wantan
- countries: (none)
- cuisines: Chifa
- kinds: meal, soup
- ingredients: wonton

## DISH Q5202956
- name: Cơm hến
- description: Famous traditional dish in Huế, Vietnam
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5202957
- name: Cơm nắm
- other names: {"zh": "粓揇"}
- description: Vietnam rice dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5202958
- name: Cơm lam
- countries: VN
- kinds: sticky rice in bamboo, rice dish

## DISH Q5202964
- name: Cơm tấm
- other names: {"zh": "碎米飯"}
- description: Vietnamese dish
- countries: VN
- kinds: Vietnamese cuisine, pork dish
- ingredients: broken rice
- has Wikipedia article: en

## DISH Q5202996
- name: Cốm
- other names: {"zh": "cốm"}
- description: Vietnamese flattened rice dish
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: dish, rice
- has Wikipedia article: en, zh

## DISH Q5203376
- name: Teja
- description: confectionery
- countries: PE
- kinds: meal, food, confectionery
- ingredients: Manjar blanco, Carya illinoinensis
- has Wikipedia article: en

## DISH Q5203707
- name: Chupe de camarones
- description: Shrimp chowder
- countries: (none)
- kinds: chowder, shrimp dish, meal

## DISH Q520598
- name: Ossau-Iraty
- other names: {"zh": "奥索-伊拉蒂奶酪"}
- description: Occitan-Basque cheese made from sheep milk
- countries: FR
- kinds: French cheese, sheep milk cheese, semi-hard cheese, pressed uncooked cheese, farmstead cheese, industrial cheese, dairy cheese
- ingredients: sheep milk
- has Wikipedia article: en, zh

## DISH Q5207448
- name: Dabby-Doughs
- description: Pastry
- countries: (none)
- kinds: food, pastry

## DISH Q5207457
- name: Dabeli
- description: snack food of India, originating in the Kutch or Kachchh region of Gujarat
- countries: IN
- kinds: food, sandwich
- ingredients: potato
- has Wikipedia article: en

## DISH Q5208692
- name: Dagwood sandwich
- description: tall, multilayered sandwich
- countries: US
- cuisines: cuisine of the United States
- kinds: dish, sandwich
- has Wikipedia article: en

## DISH Q5208800
- name: Dahi baigana
- description: Yogurt and eggplant dish
- countries: IN
- kinds: dish
- ingredients: eggplant
- has Wikipedia article: en

## DISH Q5209959
- name: Dakjuk
- description: Korean chicken porridge dish
- countries: (none)
- kinds: chicken dish, juk
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q5210284
- name: Dalcha
- description: Indian culinary dish
- countries: IN
- kinds: food, lamb dish, Indian curry
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q5211509
- name: Dalma
- description: vegetarian dish from Odisha
- countries: IN
- cuisines: cuisine of Odisha
- kinds: human food
- has Wikipedia article: en

## DISH Q5216031
- name: Danger dog
- description: method of cooking and serving a "hot dog" style of sausage
- countries: MX
- kinds: hot dog
- ingredients: hot dog
- has Wikipedia article: en

## DISH Q5227816
- name: Daube glacé
- description: jellied stew appetizer in New Orleans cuisine
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q523224
- name: Cooked rice
- other names: {"zh": "米饭"}
- description: rice that has been cooked either by steaming or boiling
- countries: (none)
- kinds: rice dish, cooked grain, cooking, dish
- ingredients: stock pot, cauldron, rice cooker
- has Wikipedia article: en, zh

## DISH Q5233479
- name: David Eyre's pancake
- description: dish
- countries: (none)
- kinds: dish, pancake
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q52376734
- name: Engadiner Torte
- countries: CH
- kinds: torte
- ingredients: dough, butter

## DISH Q52378255
- name: Bundesrat-Schaffner-Torte
- description: Swiss layer cake made from cream and kirsch
- countries: CH
- kinds: torte
- ingredients: beaten egg whites, whipped cream, dough

## DISH Q52406
- name: Muesli
- other names: {"zh": "木斯里"}
- description: breakfast dish based on unboiled rolled oats and other ingredients
- countries: CH
- kinds: dish, breakfast cereal, food preserve
- ingredients: grain, rolled oats, dried fruit
- has Wikipedia article: en, zh

## DISH Q524374
- name: Adoquín del Pilar
- other names: {"ca": "Adoquín del Pilar"}
- description: traditional hard candy from Zaragoza, Spain
- countries: ES
- kinds: food, dessert
- ingredients: caramel

## DISH Q5243850
- name: Esquites
- other names: {"zh": "墨西哥玉米杯"}
- description: Mexican corn salad
- countries: MX
- kinds: food, corn salad
- ingredients: maize
- has Wikipedia article: en

## DISH Q5247475
- name: Jeolpyeon
- other names: {"zh": "切饼"}
- description: Korean rice cake
- countries: (none)
- kinds: tteok
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q5249501
- name: Declawing of crabs
- description: removal of a live crab's claws
- countries: (none)
- kinds: crab dish
- has Wikipedia article: en

## DISH Q524966
- name: Tome des Bauges
- description: unpasteurised cow-milk cheese from the Bauges Mountains, France
- countries: FR
- cuisines: Savoy cuisine
- kinds: French cheese, raw-milk cheese, pressed uncooked cheese, cow's-milk cheese, farmstead cheese, industrial cheese, dairy cheese
- ingredients: cow's milk, milk
- has Wikipedia article: en

## DISH Q5250962
- name: Nasi Kerabu
- other names: {"zh": "葛拉布饭"}
- description: Mixed rice dish from southern Thailand and Malaysia with herbs and vegetables
- countries: MY, TH
- cuisines: Malay cuisine
- kinds: rice dish
- ingredients: Clitoria ternatea, rice, fish
- has Wikipedia article: en, zh

## DISH Q5253615
- name: Delele
- description: African dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5253850
- name: Deli Choices
- countries: (none)
- kinds: sandwich
- has Wikipedia article: en

## DISH Q5254291
- name: Delmonico steak
- other names: {"zh": "Delmonico牛排"}
- description: particular preparation of a cut of beef originated by Delmonico's restaurant in New York City
- countries: (none)
- kinds: food, short loin, beef dish
- has Wikipedia article: en

## DISH Q5254542
- name: Rengginang
- other names: {"zh": "印尼米餅"}
- description: Indonesian traditional rice cracker originating from Java island
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, kue, fried food
- ingredients: rice
- has Wikipedia article: en

## DISH Q5254978
- name: Mint
- other names: {"zh": "薄荷糖"}
- description: confectionery flavoured with mint
- countries: (none)
- kinds: candy
- has Wikipedia article: en, zh

## DISH Q525586
- name: Twinkie
- other names: {"zh": "炸忌廉手指"}
- description: snack cake
- countries: US
- kinds: snack cake
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q5257848
- name: Boiled noodles
- other names: {"zh": "馬來滷麵"}
- description: Johorean noodle soup
- countries: ID
- kinds: food, dish, type of food or dish, noodle, noodle dish
- ingredients: noodle, water
- has Wikipedia article: en

## DISH Q5257857
- name: Kolak
- description: Indonesian dessert
- countries: ID
- cuisines: dessert, Indonesian cuisine
- kinds: dessert, dish, human food, type of food or dish, food
- ingredients: brown sugar, palm sugar, coconut milk, Pandanus amaryllifolius, Sweet potato, banana
- has Wikipedia article: en

## DISH Q5259790
- name: Sausage bun
- other names: {"zh": "肠仔包"}
- description: type of pastry
- countries: HK
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q5260907
- name: Depression cake
- description: type of cake commonly made during the Great Depression
- countries: US
- kinds: cake
- ingredients: flour
- has Wikipedia article: en

## DISH Q5261363
- name: Pecel
- other names: {"zh": "皮索"}
- description: Indonesian dish originating from Java island
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, food, sauce
- ingredients: garlic, onion, Tamarindus indica, Asparagus bean, chili pepper
- has Wikipedia article: en

## DISH Q5261545
- name: Derby pie
- description: American pie
- countries: US
- kinds: food, pie
- ingredients: pecan nut, bourbon whiskey, walnut, chocolate
- has Wikipedia article: en

## DISH Q5262436
- name: Onde-onde
- other names: {"zh": "椰絲球"}
- description: Southeast Asia sweet green snack balls, coated in shredded coconut
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack, confectionery, traditional food
- ingredients: rice cake, brown sugar, coconut, rice flour, Pandanus amaryllifolius, sugar, drinking water
- has Wikipedia article: en, zh

## DISH Q5262528
- name: Getuk
- description: Javanese traditional cake
- countries: ID
- kinds: food, cookie, dessert, dish, confectionery, human food, traditional food, kue, jajan pasar
- ingredients: grated coconut, tapioca, vanilla, sugar, margarine
- has Wikipedia article: en

## DISH Q5265045
- name: Dessert bar
- other names: {"zh": "甜品棒"}
- description: layered dessert, cut into bar shapes
- countries: US
- kinds: dessert, baked good
- ingredients: sugar
- has Wikipedia article: en

## DISH Q5265049
- name: Dessert salad
- description: Sweet salads made with fruit, jello, cream, etc.
- countries: (none)
- kinds: salad
- has Wikipedia article: en

## DISH Q5265837
- name: Detroit-style pizza
- other names: {"zh": "底特律披萨"}
- description: style of pizza developed in Detroit, Michigan; square pizza with thick deep-dish crisp crust
- countries: US
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q5267251
- name: Devil's curry
- description: Kristang traditional dish
- countries: MY
- kinds: curry
- has Wikipedia article: en

## DISH Q5267360
- name: Deviled crab
- description: crab meat croquette cooked with hot and spicy seasoning
- countries: (none)
- kinds: crab dish
- has Wikipedia article: en

## DISH Q5267373
- name: Devilled kidneys
- other names: {"zh": "惡魔羊腰"}
- description: dish based on kidneys
- countries: GB
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en, zh

## DISH Q5267591
- name: Devizes pie
- description: English pie dish
- countries: (none)
- kinds: food, pie
- ingredients: offal
- has Wikipedia article: en

## DISH Q5269476
- name: Dhebra
- description: Gujarati bread made of pearl millet flour
- countries: (none)
- kinds: dish, Indian bread
- has Wikipedia article: en

## DISH Q527321
- name: Coca de recapte
- description: vegetables flatbread tipical from catalonia
- countries: (none)
- kinds: dish

## DISH Q5274381
- name: Fazuelos
- description: traditional Sephardic pastry for the Jewish holiday of Purim
- countries: (none)
- kinds: food, pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q527616
- name: Bettarazuke
- description: type of pickled daikon popular in Tokyo
- countries: JP
- kinds: tsukemono, food
- ingredients: white radish, Japanese radish
- has Wikipedia article: en

## DISH Q5276598
- name: Dal badam chakki
- description: Indian sweet dish
- countries: IN
- kinds: dessert
- ingredients: khoa, Vigna radiata, ghee, almond, sugar
- has Wikipedia article: en

## DISH Q5277707
- name: Dymdama
- description: A stew of the peoples of Central Asia
- countries: KG, KZ, UZ
- cuisines: Kazakh cuisine, Cuisine of Uzbekistan, Kyrgyz cuisine
- kinds: stew
- ingredients: Brassica oleracea, onion, potato, meat, carrot
- has Wikipedia article: en

## DISH Q5278042
- name: Dinengdeng
- description: Filipino soup-based dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5278120
- name: Ding Dong
- description: small chocolate cake similar in shape and size to a hockey puck
- countries: (none)
- kinds: chocolate cake
- has Wikipedia article: en

## DISH Q528008
- name: Obara
- description: food
- countries: SI
- kinds: food, stew, meal
- ingredients: meat
- has Wikipedia article: en

## DISH Q5280755
- name: Diri ak djon djon
- description: Haitian rice and mushrooms dish
- countries: HT
- kinds: rice dish, mushroom dish
- ingredients: djon djon, rice
- has Wikipedia article: en

## DISH Q5280948
- name: Dirt cake
- description: type of American desert
- countries: US
- kinds: cake
- ingredients: Oreo
- has Wikipedia article: en

## DISH Q52835801
- name: Rieska
- description: Finnish bread
- countries: FI
- kinds: bread, Wikimedia article covering multiple topics

## DISH Q5286572
- name: Doberge cake
- description: layered dessert originating in New Orleans, Louisiana
- countries: US
- kinds: cake
- ingredients: cake
- has Wikipedia article: en

## DISH Q5286620
- name: Dobin mushi
- other names: {"zh": "土瓶蒸"}
- description: Japanese dish of ingredients boiled in a broth in a tea pot (dobin)
- countries: JP
- kinds: dish
- has Wikipedia article: en

## DISH Q5286688
- name: Dobrada
- description: Portuguese meat dish
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q5287158
- name: Docang
- description: Indonesian traditional dish
- countries: ID
- kinds: salad, dish
- ingredients: oncom, lontong, seedling, krupuk
- has Wikipedia article: en

## DISH Q5287205
- name: Dock pudding
- description: savoury dish
- countries: (none)
- kinds: pudding
- ingredients: nettle leaf, Persicaria bistorta, onion, oatmeal, Bistorta officinalis, bacon
- has Wikipedia article: en

## DISH Q5287909
- name: Dodger Dog
- description: hot dog served by the Los Angeles Dodgers
- countries: US
- kinds: hot dog
- has Wikipedia article: en

## DISH Q5289177
- name: Kalduny
- description: type of dumplings in Balto-Slavic cuisines
- countries: BY
- cuisines: Belarusian cuisine
- kinds: stuffed pasta, potato dish
- ingredients: minced meat, vegetable oil, stuffing, dough, table salt, meat, water
- has Wikipedia article: en

## DISH Q529089
- name: Anelli
- description: type of pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q529100
- name: Anellini
- description: type of pasta; smaller version of anelli
- countries: IT
- kinds: anelli

## DISH Q5296220
- name: Donkey burger
- other names: {"zh": "驴肉火烧"}
- description: sandwich in Hebei, China, made of chopped or shredded donkey meat in a roasted, semi-flaky bread pocket
- countries: CN
- cuisines: Chinese cuisine
- kinds: food, sandwich
- ingredients: donkey meat, shaobing, meat
- has Wikipedia article: en, zh

## DISH Q5296979
- name: Doodhpak
- description: Indian rice pudding
- countries: IN
- kinds: pudding, dish
- ingredients: milk
- has Wikipedia article: en

## DISH Q529941
- name: Bocadillo
- other names: {"zh": "番石榴醬"}
- description: hispanic American confection made with guava pulp and panela
- countries: CO
- kinds: confectionery, candy
- ingredients: cane sugar, Psidium guajava
- has Wikipedia article: en, zh

## DISH Q5300145
- name: Doubles
- description: sandwich originating from Trinidad and Tobago
- countries: TT
- kinds: sandwich
- ingredients: chickpea, Vada, flour
- has Wikipedia article: en

## DISH Q53014370
- name: Stuffed Artichoke
- countries: MA
- kinds: dish
- ingredients: globe artichoke

## DISH Q5302283
- name: Doupi
- other names: {"zh": "豆皮"}
- description: breakfast dish from Wuhan, China
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q5304700
- name: Dracula Piller
- description: Danish salty liquorice
- countries: DK, SE
- kinds: candy, salty licorice
- has Wikipedia article: en

## DISH Q5305336
- name: Dragon tiger phoenix
- other names: {"zh": "龍虎鳳"}
- description: Chinese dish
- countries: (none)
- kinds: chicken dish
- ingredients: snake meat, dog meat, Silkie, cat meat
- has Wikipedia article: en, zh

## DISH Q5305996
- name: Draw soup
- description: Nigerian okra soup
- countries: NG
- cuisines: Yoruba cuisine
- kinds: okra soup, dish
- ingredients: okra, iru, onion, crayfish, palm oil, beef, cayenne pepper, fish
- has Wikipedia article: en

## DISH Q5309356
- name: Drunken chicken
- other names: {"zh": "醉雞"}
- description: chicken dish originated from Zhejiang
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food, alcoholic beverage
- has Wikipedia article: en, zh

## DISH Q5309357
- name: Drunken noodles
- other names: {"zh": "泰式炒宽粉"}
- description: Thai noodle dish
- countries: TH
- cuisines: Thai cuisine, Lao cuisine
- kinds: noodle dish
- ingredients: garlic, baby corn, vegetable oil, onion, peppercorn, shrimp, Pisum sativum subsp. sativum convar. axiphium, Holy Basil, shahe fen, chicken as food, oyster sauce, fish sauce, soy sauce, chili pepper, sugar, water
- has Wikipedia article: en, zh

## DISH Q5309466
- name: Raw ham
- countries: (none)
- kinds: ham, raw whole-muscle cut

## DISH Q5311489
- name: Duck blood and vermicelli soup
- other names: {"zh": "鸭血粉丝汤"}
- description: traditional delicacy of Nanjing, containing duck blood, vermicelli, dried fried tofu, dried small shrimp, duck gizzards, duck intestines, duck livers, shallots, ginger, sesame oil, and caraway
- countries: CN
- kinds: blood soup, duck dish
- ingredients: duck meat
- has Wikipedia article: en, zh

## DISH Q5311497
- name: Duck soup noodles
- other names: {"zh": "鸭腿麺线"}
- description: Malaysian dish; consists of duck meat in hot soup with mixed herbs and mee-sua (slim white noodles)
- countries: MY
- kinds: noodle soup
- has Wikipedia article: en

## DISH Q5311505
- name: Duckanoo
- description: Caribbean cornmeal dessert
- countries: (none)
- kinds: dessert
- ingredients: cornmeal, coconut, coconut milk, Sweet potato, butter
- has Wikipedia article: en

## DISH Q5317422
- name: Dutch baby pancake
- other names: {"zh": "荷蘭寶貝鬆餅"}
- description: baked American pancake
- countries: US
- cuisines: cuisine of the Western United States
- kinds: pudding, pancake
- ingredients: egg as food, flour, sugar, milk
- has Wikipedia article: en, zh

## DISH Q5317729
- name: Gajar ka halwa
- description: South Asian sweet
- countries: IN
- kinds: halva, food, sweet dish
- ingredients: khoa, ghee, sugar, milk, water, carrot
- has Wikipedia article: en

## DISH Q5319091
- name: Dynamite roll
- description: type of Western-style sushi
- countries: (none)
- kinds: makizushi, uramakizushi
- has Wikipedia article: en

## DISH Q531970
- name: Welf pudding
- description: Two-layered German pudding
- countries: DE
- kinds: pudding
- ingredients: milk
- has Wikipedia article: en

## DISH Q532718
- name: Kartoffelwurst
- description: potato dish
- countries: (none)
- kinds: sausage, potato dish

## DISH Q532942
- name: Choorrillanaz
- description: Chilean tipical food
- countries: PE
- kinds: food, meat dish, potato dish
- ingredients: tomato, beef, fries, onion
- has Wikipedia article: en

## DISH Q5331296
- name: Eating live seafood
- description: practice of eating seafood that is still alive
- countries: (none)
- kinds: seafood dish, live food for humans
- has Wikipedia article: en

## DISH Q5331480
- name: Eba
- description: West African staple food
- countries: BJ, NG, TG
- kinds: dish, swallow, food, human food
- ingredients: garri, hot water
- has Wikipedia article: en

## DISH Q5331853
- name: Chili shrimp
- other names: {"zh": "乾燒明蝦"}
- description: stir-fried shrimp in chili sauce
- countries: (none)
- kinds: shrimp dish, dish
- has Wikipedia article: en, zh

## DISH Q533210
- name: Schupfnudel
- description: Central European recipe
- countries: (none)
- kinds: potato-dough dumpling
- ingredients: flour
- has Wikipedia article: en

## DISH Q5332994
- name: Eclipse
- other names: {"zh": "易極"}
- description: brand of chewing gum and breath mint
- countries: (none)
- kinds: chewing gum
- has Wikipedia article: en, zh

## DISH Q5338306
- name: Edinburgh rock
- description: type of candy from Scotland
- countries: (none)
- kinds: rock, confectionery
- has Wikipedia article: en

## DISH Q534023
- name: Turducken
- other names: {"zh": "三鸟烤"}
- description: US dish consisting of a deboned chicken stuffed into a deboned duck which is then stuffed into a deboned turkey
- countries: US
- kinds: dish
- ingredients: turkey meat, chicken as food, duck meat
- has Wikipedia article: en, zh

## DISH Q534043
- name: Fontina PDO
- other names: {"zh": "Fontina DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cow's-milk cheese, pressed half-cooked cheese, Italian cheese, cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q534126
- name: Soan papdi
- other names: {"zh": "印度豆麵酥糖"}
- description: Indian dessert
- countries: IN
- kinds: dessert
- ingredients: besan
- has Wikipedia article: en, zh

## DISH Q534420
- name: Bauernfrühstück
- description: potato dish
- countries: DE
- kinds: potato dish, dish
- ingredients: onion, leek, smoked meat, pickled cucumber, Agaricus, fries, egg as food, Allium schoenoprasum, Welsh onion, tomato, bacon, potato, meat
- has Wikipedia article: en

## DISH Q5347166
- name: Eetch
- description: Armenian side dish
- countries: AM
- kinds: dish
- has Wikipedia article: en

## DISH Q5347834
- name: Egg and chips
- description: popular dish in the United Kingdom
- countries: GB
- kinds: potato dish, egg dish
- ingredients: fries, egg as food
- has Wikipedia article: en

## DISH Q5347835
- name: Egg bhurji
- description: South Asian dish of eggs, onions, chilies, and spices
- countries: IN
- kinds: omelette
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q5347858
- name: Egg tong sui
- countries: CN
- kinds: food, soup, egg dish
- has Wikipedia article: en

## DISH Q5347939
- name: Eggs Neptune
- countries: (none)
- kinds: food, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q5347941
- name: Eggs and brains
- description: breakfast dish of eggs and brains
- countries: (none)
- kinds: egg dish
- has Wikipedia article: en

## DISH Q53560342
- name: Riste d'aubergine d'Arles
- countries: (none)
- kinds: cuisine of Provence, dish, stew
- ingredients: black pepper, table salt, garlic, tomato, eggplant, onion, bay leaf, Thymus, Rosmarinus officinalis, olive oil

## DISH Q53581962
- name: Käsesalat
- other names: {"de": "Käsesalat"}
- countries: (none)
- kinds: dish

## DISH Q5358451
- name: Suksil-gwa
- description: cooked fruit confection
- countries: (none)
- kinds: hangwa
- ingredients: fruit
- has Wikipedia article: en

## DISH Q5359207
- name: Elenski but
- description: dry-cured ham from the town of Elena in northern Bulgaria
- countries: BG
- kinds: raw ham
- ingredients: ham
- has Wikipedia article: en

## DISH Q5360014
- name: Tofu puff
- other names: {"zh": "豆卜"}
- description: food product
- countries: (none)
- kinds: food product, tofu
- ingredients: tofu
- has Wikipedia article: zh

## DISH Q5361233
- name: Rotini
- other names: {"zh": "螺絲粉"}
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: wheat flour
- has Wikipedia article: zh

## DISH Q5361273
- name: Fiori
- description: decorative shape of extruded pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q53619707
- name: Egg pasta
- countries: (none)
- kinds: pasta, egg-based food, type of pasta
- ingredients: sfoglia

## DISH Q5363430
- name: Chicken rice
- other names: {"zh": "鸡肉饭"}
- countries: JP
- kinds: type of food or dish, Japanese rice dish, chicken dish
- ingredients: chicken as food, ketchup, rice

## DISH Q5364840
- name: Robatayaki
- other names: {"zh": "爐端燒"}
- description: the method of cooking on the grill in the presence of the client and the dish obtained as a result of such cooking
- countries: JP
- kinds: dish, izakaya
- has Wikipedia article: en, zh

## DISH Q5365279
- name: Noppe
- other names: {"zh": "能平汁"}
- description: Japanese soup
- countries: JP
- kinds: food, soup
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q5366160
- name: Scrapple
- description: American pork offal mush
- countries: US
- kinds: pork dish, offal dish, savory pudding
- ingredients: mush, pork
- has Wikipedia article: en

## DISH Q5366437
- name: Orange chicken
- other names: {"zh": "橙子雞"}
- description: chicken dish
- countries: US
- kinds: dish, chicken dish
- ingredients: chicken as food, orange
- has Wikipedia article: en, zh

## DISH Q5366460
- name: Naengguk
- description: chilled soup in Korean cuisine
- countries: (none)
- kinds: soup, guk, cold sweet soup
- has Wikipedia article: en

## DISH Q5367573
- name: Meat pie
- other names: {"zh": "肉馅饼"}
- description: pie with a filling of meat
- countries: IT
- kinds: appetizer, pie
- ingredients: Potato, meat, carrot
- has Wikipedia article: en, zh

## DISH Q5368581
- name: Futomaki matsuri sushi
- countries: (none)
- kinds: kazari-sushi, futomaki

## DISH Q5368607
- name: Narezushi
- other names: {"zh": "熟寿司"}
- description: fermented sushi
- countries: JP
- kinds: sushi
- ingredients: fermented fish

## DISH Q5368617
- name: Fagottini
- description: type of pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q5368786
- name: Garae-tteok
- description: Korean rice cake
- countries: (none)
- kinds: tteok
- has Wikipedia article: en

## DISH Q5369082
- name: Gwamegi
- other names: {"zh": "鯰魚"}
- description: Korean dried fish preparation
- countries: (none)
- kinds: salted fish, fermented food
- has Wikipedia article: en

## DISH Q5369089
- name: Oritang
- description: Korean duck stew
- countries: (none)
- kinds: food, soup
- ingredients: duck, duck meat
- has Wikipedia article: en

## DISH Q5369104
- name: Ojingeo-chae-bokkeum
- description: Korea dish of squid, dried and shredded, cut into short pieces, stir-fried in oil, coated with a gochujang sauce, and sprinkled with sesame seeds
- countries: (none)
- kinds: squid dish
- ingredients: dried shredded squid
- has Wikipedia article: en

## DISH Q53698181
- name: Grilled cold noodles
- other names: {"zh": "烤冷面"}
- description: Chinese street food
- countries: (none)
- kinds: dish, street food
- has Wikipedia article: en, zh

## DISH Q5369868
- name: Rice burger
- other names: {"zh": "米汉堡"}
- description: sandwich, whose buns are made of rice
- countries: JP
- kinds: hamburger, sandwich, Japanese rice dish
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q5371164
- name: Hokkien fried rice
- other names: {"zh": "福建炒饭"}
- description: Hong Kong fried rice dish
- countries: (none)
- kinds: dish, rice dish, chǎofàn
- has Wikipedia article: en, zh

## DISH Q5371177
- name: Imitation shark's fin soup
- other names: {"zh": "碗仔翅"}
- description: Hong Kong dish
- countries: HK
- cuisines: Chinese cuisine
- kinds: soup, meat alternative, fish soup
- has Wikipedia article: en, zh

## DISH Q5371632
- name: Golbaengi-muchim
- other names: {"zh": "辣拌海螺"}
- description: Korean salad
- countries: (none)
- kinds: salad
- ingredients: sea snail
- has Wikipedia article: en

## DISH Q5371702
- name: Galbi-jjim
- other names: {"zh": "韓式牛肋骨"}
- description: Korean braised short ribs
- countries: (none)
- kinds: meat dish
- ingredients: short ribs
- has Wikipedia article: en

## DISH Q5371706
- name: Ropa vieja
- description: dish of mestizo-Hispanic origin whose main ingredient is beef
- countries: CO, CR, CU, PA, VE
- kinds: beef dish
- has Wikipedia article: en

## DISH Q5371715
- name: Yeonpotang
- description: Korean beef soup dish
- countries: (none)
- kinds: food, soup
- ingredients: broth
- has Wikipedia article: en

## DISH Q5371719
- name: Seon
- other names: {"zh": "膳"}
- description: Korean traditional dishes
- countries: KR
- cuisines: Korean cuisine
- kinds: stuffed vegetable
- has Wikipedia article: en

## DISH Q5372471
- name: Western confection
- other names: {"zh": "西點"}
- description: Japanese confectionery
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en, zh

## DISH Q5373825
- name: Empal gentong
- description: Indonesian beef soup
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, beef dish, food, soup
- ingredients: Indonesian bay leaf, Kaffir Lime Leaf, Aleurites moluccanus, coconut milk, tripe, Alpinia galanga, Allium ascalonicum, beef, black pepper, Curcuma longa, Cymbopogon citratus, Allium sativum, table salt, sugar
- has Wikipedia article: en

## DISH Q5376675
- name: Enduri Pitha
- description: steamed food of Odisha
- countries: IN
- kinds: seafood, food
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q5377413
- name: Engagement Chicken
- description: American dish rumored to lead to marriage
- countries: (none)
- kinds: dish, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q53844640
- name: Broodje gezond
- description: Dutch sandwich translates as "healthy sandwich"
- countries: (none)
- kinds: submarine sandwich, sandwich, dish
- has Wikipedia article: en

## DISH Q5389704
- name: Erkuai
- other names: {"zh": "饵块"}
- description: rice cake from Yunnan Province, China
- countries: (none)
- kinds: dish
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q5390330
- name: Tongue toast
- description: open sandwich of beef tongue and eggs
- countries: (none)
- kinds: food, sandwich, beef dish
- ingredients: onion, beef tongue, scrambled eggs, bread
- has Wikipedia article: en

## DISH Q5390483
- name: Medovník
- other names: {"zh": "俄式蜂蜜蛋糕"}
- description: cake from USSR
- countries: RU
- kinds: pastry
- has Wikipedia article: en, zh

## DISH Q5391979
- name: Gul-gukbap
- description: Korean rice soup
- countries: (none)
- kinds: gukbap, oyster dish
- ingredients: oyster
- has Wikipedia article: en

## DISH Q53925330
- name: Lapek bugih
- countries: ID
- cuisines: Indonesian cuisine, Padang cuisine
- kinds: dessert, street food, confectionery, jajan pasar, dish
- ingredients: coconut, coconut milk, Pandanus amaryllifolius, glutinous rice

## DISH Q53927047
- name: Egyptian martabak
- description: Indonesian savory food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: Mutabak, dish, human food, type of food or dish
- ingredients: palm sugar, scallion, beef, egg as food, flour

## DISH Q539429
- name: Funnel cake
- other names: {"zh": "漏斗糕"}
- description: deep-fried batter
- countries: DE, US
- kinds: torte
- ingredients: batter
- has Wikipedia article: en, zh

## DISH Q5395422
- name: Erotic cake
- countries: (none)
- kinds: cake
- ingredients: sponge cake

## DISH Q5396381
- name: Sándwich de potito
- other names: {"es": "Sándwich de potito"}
- countries: CL
- kinds: sandwich
- ingredients: tripe, onion, bread

## DISH Q5400740
- name: Corbata
- other names: {"es": "Corbata"}
- countries: ES
- kinds: dessert

## DISH Q540171
- name: Kompeitō
- other names: {"zh": "金平糖"}
- description: Japanese confection
- countries: JP
- kinds: Nanbangashi, sugar candy
- ingredients: sugar
- has Wikipedia article: en, zh

## DISH Q5402844
- name: Pataniscas
- description: typical Portuguese dish
- countries: PT
- cuisines: Portuguese cuisine
- kinds: deep-fried food, potato dish, bacalhau, fish dish
- ingredients: peppercorn, dried and salted cod, batter, parsley
- has Wikipedia article: en

## DISH Q540289
- name: Baked Alaska
- other names: {"zh": "熱烤阿拉斯加"}
- description: dessert dish of ice cream, sponge cake and meringue
- countries: US
- kinds: ice cream-based dessert, dessert
- ingredients: sponge cake, meringue, ice cream
- has Wikipedia article: en, zh

## DISH Q5403594
- name: Risgrynsgröt
- other names: {"sv": "risgrynsgröt"}
- countries: (none)
- kinds: porridge

## DISH Q5403625
- name: Ajo carretero
- description: sheep garlic, onions, red and green peppers, ñoras, paprika and hot chilli.
- countries: (none)
- kinds: stew

## DISH Q540543
- name: Kartoffelkäse
- description: potato dish
- countries: AT
- kinds: spread, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q5406515
- name: Patasca
- countries: (none)
- kinds: soup, meal
- ingredients: mote

## DISH Q540837
- name: Kopanisti mykonou
- description: Greek cheese
- countries: GR
- kinds: cheese, Greek cheese, meze
- has Wikipedia article: en

## DISH Q5408968
- name: Makki ki roti
- description: Punjabi corn flatbread
- countries: (none)
- kinds: bread, cuisine
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q5409500
- name: Tuulomantorttu
- other names: {"fi": "tuulomantorttu"}
- countries: FI
- kinds: pastry, chocolate brownie

## DISH Q5409699
- name: Euneo-juk
- description: Korean porridge
- countries: (none)
- kinds: juk
- ingredients: Plecoglossus altivelis
- has Wikipedia article: en

## DISH Q5411101
- name: Bica
- countries: (none)
- cuisines: Galician cuisine
- kinds: sponge cake, dessert
- ingredients: chicken egg, flour, butter

## DISH Q5412364
- name: Birote
- description: a type of Mexican sourdough bread
- countries: MX
- kinds: sourdough bread

## DISH Q5416128
- name: Eve's pudding
- description: Traditional British pudding
- countries: GB
- kinds: pudding
- ingredients: sponge cake
- has Wikipedia article: en

## DISH Q54165556
- name: Kunga cake
- other names: {"zh": "蚊餅"}
- description: East African food
- countries: MW, MZ, TZ
- kinds: torta, food
- ingredients: Ceratopogonidae
- has Wikipedia article: en, zh

## DISH Q541771
- name: Appenzeller Biber
- description: biscuits
- countries: CH
- cuisines: Swiss cuisine
- kinds: pastry

## DISH Q542046
- name: Brousse du Rove
- description: goat cheese from France
- countries: FR
- kinds: goat cheese, French cheese, cheese
- ingredients: goat milk
- has Wikipedia article: en

## DISH Q5420610
- name: Potage
- description: food
- countries: FR, ES, GB
- cuisines: French cuisine, Spanish cuisine, English cuisine
- kinds: food, soup, dish, stew
- ingredients: vegetable, meat, fish
- has Wikipedia article: en

## DISH Q54222942
- name: Vegetable risotto
- countries: (none)
- kinds: risotto, vegetable dish

## DISH Q54223338
- name: Salmon pizza
- countries: (none)
- kinds: dish

## DISH Q5422785
- name: Eyerlekh
- description: unlaid eggs found inside just-slaughtered chickens
- countries: (none)
- kinds: egg dish
- has Wikipedia article: en

## DISH Q542283
- name: Chicken Kiev
- other names: {"zh": "基辅鸡"}
- description: tsarist russian stuffed fried chicken dish
- countries: RU
- cuisines: Russian cuisine
- kinds: chicken dish
- ingredients: chicken as food, bread crumbs, butter
- has Wikipedia article: en, zh
