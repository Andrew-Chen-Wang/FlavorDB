# Review batch names-031

## DISH Q19610127
- name: Walnut pastry
- other names: {"zh": "桃酥饼"}
- description: Hong Kong food
- countries: CN
- kinds: dish, marry girl cake
- has Wikipedia article: en, zh

## DISH Q19610137
- name: Deep-fried shredded radish cake
- other names: {"zh": "炸油糍"}
- description: Hong Kong food
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q19612571
- name: Supangle
- description: Turkish cuisine pudding dessert
- countries: TR
- kinds: food, dessert
- has Wikipedia article: en

## DISH Q1962004
- name: Nabemono
- other names: {"zh": "鍋物"}
- description: variety of Japanese hot pot dishes
- countries: JP
- kinds: type of food or dish, hot pot
- has Wikipedia article: en, zh

## DISH Q1962115
- name: Nacatamal
- description: Nicaraguan typical food
- countries: NI
- kinds: meat dish
- has Wikipedia article: en

## DISH Q1963961
- name: Hematogen
- description: nutrition bar containing cow's blood
- countries: CH
- kinds: medication, confectionery, snack bar
- ingredients: food additive, sugar, blood
- has Wikipedia article: en

## DISH Q19646375
- name: Sate lilit
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine, Balinese cuisine
- kinds: Indonesian cuisine, human food, type of food or dish, dish, satay
- ingredients: shallot, garlic, coriander seed, ginger, grated coconut, Aleurites moluccanus, Kaempferia galanga, chicken as food, fish as food, Alpinia galanga, chili pepper, black pepper, Curcuma longa, Cymbopogon citratus, table salt, pig, Cocos nucifera
- has Wikipedia article: en

## DISH Q1967823
- name: Spare ribs
- other names: {"zh": "豬肋"}
- description: spareribs
- countries: (none)
- kinds: dish, pork
- has Wikipedia article: en, zh

## DISH Q1968074
- name: Dutch brandy
- description: liquor
- countries: (none)
- kinds: liquor
- has Wikipedia article: en

## DISH Q1968771
- name: Olla podrida
- description: Spanish stew made with chickpeas and beans
- countries: ES
- kinds: food, soup
- ingredients: pork and beans
- has Wikipedia article: en

## DISH Q19689781
- name: Ikanago
- other names: {"de": "Ikanago"}
- description: Japanese dish
- countries: (none)
- kinds: dish

## DISH Q19695008
- name: Num ansom
- description: Cambodian cylinder-shaped sticky rice cake
- countries: KH
- kinds: rice cake
- ingredients: banana leaf, glutinous rice
- has Wikipedia article: en

## DISH Q19695011
- name: Num banhchok
- description: lightly-fermented Cambodian rice noodles and breakfast noodle dish
- countries: KH
- kinds: rice noodle, noodle dish
- ingredients: freshwater fish, kroeung, rice vermicelli, prahok
- has Wikipedia article: en

## DISH Q1969648
- name: Amsterdam onion
- description: yellow pickled onions
- countries: (none)
- kinds: dish, pickled onion

## DISH Q19696604
- name: ຕຳໝາກແຕງ
- other names: {"lo": "ຕຳໝາກແຕງ"}
- countries: (none)
- kinds: salad

## DISH Q19702102
- name: Shemai
- description: common Bengali Eid dessert
- countries: IN, BD
- cuisines: Indian cuisine, Bangladeshi cuisine
- kinds: dessert
- has Wikipedia article: en

## DISH Q19702771
- name: Bergen Cookies
- other names: {"fi": "Bergen Cookies"}
- countries: (none)
- kinds: biscuit

## DISH Q19704261
- name: Kampanisu
- other names: {"fi": "Kampanisu"}
- countries: (none)
- kinds: pastry

## DISH Q19704410
- name: Kasvissosekeitto
- other names: {"fi": "Kasvissosekeitto"}
- countries: (none)
- kinds: dish

## DISH Q19704479
- name: Kauralastu
- other names: {"fi": "Kauralastu"}
- countries: (none)
- kinds: biscuit

## DISH Q19706789
- name: Mantelikala
- other names: {"fi": "mantelikala"}
- description: fish dish
- countries: (none)
- kinds: type of food or dish, fish dish
- ingredients: bread crumbs, fish as food, almond, butter, cream

## DISH Q19707923
- name: Ohraryynipuuro
- other names: {"fi": "Ohraryynipuuro"}
- countries: (none)
- kinds: dish

## DISH Q19709840
- name: Silkko
- other names: {"fi": "silkko"}
- countries: (none)
- kinds: bread, bark bread
- ingredients: soured milk

## DISH Q19709871
- name: Yüksük soup
- description: "mantı" and chickpea soup from the Turkish cuisine
- countries: TR
- kinds: soup

## DISH Q19711295
- name: Talabaw
- description: a soup from Myanmar
- countries: MM
- kinds: dish, soup
- ingredients: bamboo shoots, Channidae, basil
- has Wikipedia article: en

## DISH Q19712268
- name: Buttered rice
- description: Burmese butter and lentil rice
- countries: MM
- kinds: dish
- has Wikipedia article: en

## DISH Q19713753
- name: Aranese cream
- description: type of dessert dish
- countries: (none)
- kinds: dish
- ingredients: egg as food, cinnamon, sugar, milk

## DISH Q19714167
- name: Esparteros
- other names: {"ca": "esparteros"}
- countries: (none)
- kinds: confectionery, cake

## DISH Q19715589
- name: Manjoia
- other names: {"ca": "manjoia"}
- countries: (none)
- kinds: dish

## DISH Q19716076
- name: Pan con chicharrón
- countries: PE
- kinds: meal, sandwich, dish
- ingredients: pork, bread

## DISH Q19716154
- name: Pataqueta
- description: Spanish bread
- countries: (none)
- kinds: dish

## DISH Q19716651
- name: Sang amb ceba
- other names: {"ca": "sang amb ceba"}
- description: Valencian dish of blood curd and onion
- countries: (none)
- kinds: tapas, Valencian cuisine
- ingredients: blood curd, onion
- has Wikipedia article: en

## DISH Q19717186
- name: Torró de gat
- other names: {"ca": "Torró de gat"}
- countries: ES
- kinds: dish, dessert
- ingredients: popcorn, honey

## DISH Q19717247
- name: Trinxada
- other names: {"ca": "trinxada"}
- countries: (none)
- kinds: dish

## DISH Q19723512
- name: Fava
- description: broad bean-based meze from the Turkish cuisine
- countries: TR
- kinds: food, dish, meze
- ingredients: broad bean
- has Wikipedia article: en

## DISH Q19724350
- name: Binte biluhuta
- description: soup consisting of corn, fish or shrimp typical of Gorontalo
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, soup
- ingredients: fish as food, maize
- has Wikipedia article: en

## DISH Q19724535
- name: Bulung
- description: Balinese food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, rojak
- ingredients: seaweed

## DISH Q19725078
- name: Dadar gulung
- other names: {"zh": "斑蘭椰絲卷"}
- description: Indonesian traditional coconut pancake originating from Java island
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, Kuih, jajan pasar
- ingredients: coconut, palm sugar, coconut milk, Pandanus, cooking oil, egg as food, flour, table salt, drinking water
- has Wikipedia article: en

## DISH Q19725952
- name: Getuk pisang
- description: Indonesian snack made of banana
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, Getuk, banana dish
- ingredients: banana leaf, rice flour, tapioca, vanilla, table salt, sugar, banana

## DISH Q19726065
- name: Memek
- description: cuisine from Simeulue, Aceh
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: type of food or dish, congee, sweetmeat
- ingredients: coconut milk, glutinous rice, table salt, sugar, banana

## DISH Q19726067
- name: Gule petih Jepara
- other names: {"id": "Gule petih Jepara"}
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish

## DISH Q19726349
- name: Horok-horok
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, jajan pasar

## DISH Q19727205
- name: Kanji rumbi
- description: dish from Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: congee, dish, type of food or dish, food
- ingredients: cardamom, fried onion, star anise, cooking oil, ghee, Pandanus amaryllifolius, Murraya koenigii, nutmeg, Foeniculum vulgare, black pepper, cinnamon, clove, table salt, rice, water, shallot, garlic, coriander seed, Ayam Kampong, ginger

## DISH Q19727336
- name: Kasuami
- description: Traditional food from Southeast Sulawesi
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: cassava root

## DISH Q19727660
- name: Cassava chips
- description: thin wafer of deep fried cassava root
- countries: BR, ID
- kinds: food, dish, chip, fried cassava
- ingredients: cassava root
- has Wikipedia article: en

## DISH Q19727662
- name: Tempeh chips
- description: crispy snack made from tempeh
- countries: ID
- kinds: Tempeh, kripik
- ingredients: cooking oil, Tempeh, table salt

## DISH Q19727676
- name: Kerupuk Catak
- other names: {"id": "Kerupuk Catak"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish

## DISH Q19727704
- name: Keumamah
- description: Acehnese fish dish
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, human food, type of food or dish, seafood
- ingredients: shallot, coriander seed, ginger, Thunnini, Thunnus tonggol, skipjack tuna, bird's eye chili, black pepper, Allium sativum, table salt
- has Wikipedia article: en

## DISH Q19728050
- name: Kue ape
- description: Indonesian type of pancake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, street food
- ingredients: coconut milk, Pandanus, flour, baking powder
- has Wikipedia article: en

## DISH Q19728052
- name: Maksuba
- description: Indonesian traditional layer cake
- countries: ID
- kinds: food, cake

## DISH Q19728565
- name: Lontong Krubyuk
- other names: {"id": "Lontong Krubyuk"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish

## DISH Q19729630
- name: Nasi Brongkos
- description: Indonesian traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish

## DISH Q19729632
- name: Nasi Ndoreng
- other names: {"id": "Nasi Ndoreng"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: Indonesian peanut sauces, Serundeng, Sesbania grandiflora, cooked rice, Leucaena leucocephala, leaf

## DISH Q19729633
- name: Nasi timbel
- description: Indonesian rice dish originating from West Java
- countries: ID
- kinds: rice dish
- ingredients: banana leaf, brown rice
- has Wikipedia article: en

## DISH Q19729905
- name: Ongol-ongol
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack
- ingredients: sago flour, coconut, palm sugar, Pandanus amaryllifolius

## DISH Q19729918
- name: Opor bakar Kudus
- other names: {"id": "Opor bakar Kudus"}
- countries: ID
- kinds: dish

## DISH Q19729919
- name: Opor kambing
- description: Indonesian dish
- countries: ID
- kinds: dish

## DISH Q19729946
- name: Pa'piong
- description: traditional cuisine from Toraja, Indonesia
- countries: ID
- kinds: dish

## DISH Q19730831
- name: Pésmol
- other names: {"bew": "pésmol"}
- countries: ID
- kinds: fish dish

## DISH Q19731618
- name: Roti Maros
- other names: {"id": "Roti Maros"}
- countries: ID
- kinds: dish

## DISH Q19731840
- name: Sambal asam udueng
- description: shrimp dish from Aceh, Indonesia
- countries: ID
- cuisines: Acehnese cuisine, Indonesian cuisine
- kinds: dish, sambal
- ingredients: bird's eye chili, cooking oil, Averrhoa bilimbi, Citrus × aurantiifolia, Cymbopogon citratus, table salt, sugar, shallot, Kaffir Lime Leaf, shrimp and prawn as food

## DISH Q19731841
- name: Sambal pepaya
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, sambal
- ingredients: Carica papaya

## DISH Q19731843
- name: Sambal lingkung
- description: a type of meat floss or serunding made from fish meat
- countries: ID
- cuisines: Indonesian cuisine, Abon Ikan Bandeng
- kinds: type of food or dish, dish, human food
- ingredients: spice, Coriandrum sativum, Cymbopogon citratus, table salt, sugar, Indonesian bay leaf, Kaffir Lime Leaf, garlic, caraway seeds, grated coconut, Spanish mackerel, Thunnus tonggol, coconut milk, bird's eye chili, Alpinia galanga, Allium ascalonicum, chili pepper

## DISH Q19731959
- name: Ambal satay
- description: the variant of satay dish originated from Ambal region in Kebumen Regency, Central Java
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay
- ingredients: shallot, coriander seed, ginger, palm sugar, Aleurites moluccanus, chicken as food, Tempeh, black pepper, Curcuma longa, Allium sativum, table salt

## DISH Q19731962
- name: Kikil satay
- description: Indonesian culinary
- countries: ID
- cuisines: Indonesian cuisine, cuisine of Java
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay
- ingredients: Indonesian bay leaf, shallot, Kaffir Lime Leaf, garlic, coriander seed, cow's trotters, kecap manis, palm sugar, Aleurites moluccanus, bird's eye chili, Alpinia galanga, chili pepper, Tamarindus indica, black pepper, peanut, Cymbopogon citratus, Allium sativum, table salt, water

## DISH Q19731963
- name: Lalat satay
- description: madura satay, Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Madurese cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay
- ingredients: satay sauce, kecap, shallot, garlic, peanut, kecap manis, chicken as food, goat meat, bird's eye chili, Curcuma longa, table salt

## DISH Q19731964
- name: Matang satay
- description: types of mutton or beef satay from Aceh
- countries: ID
- cuisines: Acehnese cuisine, Indonesian cuisine
- kinds: dish, satay
- ingredients: cardamom, white sugar, peanut, star anise, palm sugar, Aleurites moluccanus, coconut milk, goat meat, Alpinia galanga, Pandanus amaryllifolius, Allium ascalonicum, beef, chili pepper, black pepper, Cymbopogon citratus, cinnamon, clove, Allium sativum, table salt, Indonesian bay leaf, Kaffir Lime Leaf, turmeric rhizome, coriander seed, ginger

## DISH Q19731965
- name: Jepara beef satay
- description: traditional food from Jepara, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, satay
- ingredients: satay sauce, shallot, beef

## DISH Q19732014
- name: Sayur Betik
- other names: {"id": "Sayur Betik"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: Carica papaya

## DISH Q19733063
- name: Sengkulun
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: glutinous rice flour, palm sugar

## DISH Q19733671
- name: Sie reuboh
- description: meat stew from Aceh, Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, meat dish, stew
- ingredients: animal fats and oils, chili powder, Alpinia galanga, Arenga pinnata, beef, chili pepper, Curcuma longa, Allium sativum, table salt

## DISH Q19738024
- name: Gantilut
- other names: {"id": "Gantilut"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: cassava

## DISH Q19738539
- name: Mi Gomak
- description: Indonesian spicy noodle soup dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, noodle, meal, noodle dish
- ingredients: Indonesian bay leaf, shallot, Kaffir Lime Leaf, turmeric rhizome, Sicyos edulis, garlic, ginger, Andaliman, coconut milk, scallion, Alpinia galanga, noodle, chili pepper, black pepper, Cymbopogon citratus
- has Wikipedia article: en

## DISH Q19738844
- name: Pindang
- description: Indonesian cooking method
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fish, dish, human food, type of food or dish
- ingredients: table salt, fish as food
- has Wikipedia article: en

## DISH Q19740569
- name: 소토 캄빙
- other names: {"ko": "소토 캄빙"}
- countries: (none)
- kinds: soto

## DISH Q19740571
- name: Soto Tangkar
- description: a dish with coconut milk sauce rich in Betawi spices
- countries: ID
- cuisines: Indonesian cuisine
- kinds: traditional food, type of food or dish, food, dish, human food, soto, soup
- ingredients: tomato, shallot, peppercorn, coconut milk, beef, Curcuma longa

## DISH Q19743784
- name: Tapai singkong
- description: Indonesian food made from fermented cassava
- countries: ID
- cuisines: snack, Indonesian cuisine
- kinds: dish, human food, type of food or dish, plant-based food
- ingredients: cassava root, fermentation starter, yeast

## DISH Q19744002
- name: Bongkrèk tempeh
- description: a variety of tempeh prepared with coconut dregs
- countries: ID
- kinds: dish
- ingredients: coconut

## DISH Q19744214
- name: Tipat cantok
- description: Indonesian food item
- countries: ID
- kinds: rice dish
- has Wikipedia article: en

## DISH Q19744568
- name: Turuk Bintol
- other names: {"id": "Turuk Bintol"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish

## DISH Q19745541
- name: Ayam cincane
- description: a typical dish from Samarinda, East Kalimantan
- countries: ID
- kinds: dish, fried chicken

## DISH Q19745826
- name: Gajebo
- description: typical West Sumatra food
- countries: ID
- kinds: gulai
- ingredients: garlic, turmeric, ginger, onion, Tamarindus indica, bay leaf, coconut milk, galangal, beef, chili pepper, Cymbopogon citratus, table salt, sugar, water

## DISH Q19745939
- name: Jamu Jun
- other names: {"id": "Jamu Jun"}
- countries: ID
- kinds: dish

## DISH Q19746040
- name: Keukarah
- description: Dessert from Aceh, Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dessert, dish, cookie, kue
- ingredients: white sugar, rice flour, cooking oil, water

## DISH Q19746080
- name: Kotokan Gereh Tongkol
- other names: {"id": "Kotokan Gereh Tongkol"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish
- ingredients: Indonesian bay leaf, shallot, garlic, palm sugar, Thunnus tonggol, shrimp paste, coconut milk, cooking oil, Alpinia galanga, chili pepper, table salt

## DISH Q19746110
- name: Lapis pati bodin Jepara
- other names: {"id": "Lapis pati bodin Jepara"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, jajan pasar

## DISH Q19746189
- name: Mangut Kepala Manyung
- other names: {"id": "Mangut Kepala Manyung"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: human food, type of food or dish, dish
- ingredients: bird's eye chili, cooking oil, Alpinia galanga, chili pepper, Cymbopogon citratus, table salt, water, Indonesian bay leaf, shallot, Kaffir Lime Leaf, garlic, palm sugar, coconut milk, fish as food

## DISH Q19746250
- name: Meuseukat
- description: dodol-like cake found in Acehnese cuisine
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: dish, cookie, dessert, kue
- ingredients: wheat flour, butter, orange, sugar, Ananas comosus, water
- has Wikipedia article: en

## DISH Q19746552
- name: Javanese fried rice
- description: Javanese-style of fried rice
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- has Wikipedia article: en

## DISH Q19746558
- name: Nasi langgi
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: type of food or dish, food, dish, traditional food
- ingredients: egg as food, Tamarindus indica, black pepper, Coriandrum sativum, Cymbopogon citratus, table salt, rice, granulated sugar, Indonesian bay leaf, Kaffir Lime Leaf, garlic, coconut milk, Alpinia galanga, Allium ascalonicum, chili pepper, Tempeh, shrimp paste, sambal, cooked rice

## DISH Q19746560
- name: Nasi uduk ungu
- other names: {"id": "nasi uduk ungu"}
- countries: ID
- kinds: rice dish
- ingredients: Beta vulgaris, Sweet potato, rice

## DISH Q19747105
- name: Pecel pakis Colo
- other names: {"id": "Pecel pakis Colo"}
- countries: ID
- kinds: dish

## DISH Q19747511
- name: Roti gambang
- description: Javanese traditional bread
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, bread
- ingredients: palm sugar, bread crumbs, Cinnamomum verum, egg as food, sugar
- has Wikipedia article: en

## DISH Q19747627
- name: Sambal goreng hati
- other names: {"id": "Sambal goreng hati"}
- countries: ID
- kinds: dish, Sambal goreng

## DISH Q19747721
- name: Sego Tewel
- other names: {"id": "Sego Tewel"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish
- ingredients: Indonesian bay leaf, asparagus bean, garlic, Aleurites moluccanus, coconut milk, Alpinia galanga, Allium ascalonicum, chili pepper, Artocarpus heterophyllus, black pepper, table salt, water

## DISH Q19748451
- name: Soto kerbau
- other names: {"id": "soto kerbau"}
- countries: (none)
- kinds: soto

## DISH Q19748856
- name: Tasak telu
- description: Karo Batak dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: Kaffir Lime Leaf, grated coconut, Etlingera elatior, coconut, chicken as food, Citrus × aurantiifolia, Cymbopogon citratus, table salt

## DISH Q19748867
- name: Tawur
- description: traditional Indonesian food, specifically a snack from Jepara, Central Java
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: grated coconut, maize

## DISH Q19749023
- name: Adrem
- description: Indonesian traditional snacks
- countries: ID
- kinds: dish, kue
- ingredients: coconut, palm sugar, rice flour
- has Wikipedia article: en

## DISH Q19749222
- name: Wedang Pekak
- other names: {"id": "Wedang Pekak"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish

## DISH Q19752274
- name: Vakfıkebir ekmeği
- description: Turkish bread
- countries: TR
- kinds: food, Turkish breads
- ingredients: durum flour
- has Wikipedia article: en

## DISH Q19752839
- name: Soto kuning
- other names: {"id": "Soto kuning"}
- countries: (none)
- kinds: soto

## DISH Q1975589
- name: Ptasie mleczko
- other names: {"zh": "birds milk cake"}
- description: confectionery product
- countries: PL
- kinds: candy, bonbon
- ingredients: soufflé, agar, butter, sugar, milk, chocolate
- has Wikipedia article: en

## DISH Q1975673
- name: Nasi krawu
- description: rice dish from Gresik
- countries: ID
- cuisines: Indonesian cuisine, Javanese cuisine
- kinds: food, rice dish
- ingredients: coconut, rice

## DISH Q19766201
- name: Pizza cake
- description: Canadian multiple-layer pizza baked in a pot or cake pan
- countries: CA
- kinds: type of pizza
- has Wikipedia article: en

## DISH Q1979013
- name: Pain d'épices de Deventer
- other names: {"fr": "Pain d'épices de Deventer"}
- countries: (none)
- kinds: food, ontbijtkoek

## DISH Q1979684
- name: Korma
- description: dish originating in South Asia or Central Asia
- countries: IN
- kinds: type of food or dish, Indian curry
- ingredients: yogurt
- has Wikipedia article: en

## DISH Q197969
- name: Mooncake
- other names: {"zh": "月饼"}
- description: Chinese bakery product traditionally eaten during the Mid-Autumn Festival
- countries: CN, TW
- kinds: pastry, Chinese bakery product, bánh, confectionery
- has Wikipedia article: en, zh

## DISH Q19799381
- name: Strutglass
- other names: {"sv": "strutglass"}
- countries: (none)
- kinds: ice cream

## DISH Q19803309
- name: Martell de Sant Eloi
- other names: {"ca": "martell de Sant Eloi"}
- countries: ES
- kinds: dessert

## DISH Q19803312
- name: Volant de Sant Cristòfol
- other names: {"ca": "volant de Sant Cristòfol"}
- countries: ES
- kinds: dessert

## DISH Q1980783
- name: Spikkels
- other names: {"nl": "Spikkels"}
- countries: (none)
- kinds: candy

## DISH Q19814732
- name: Nankhatai
- description: shortbread biscuit popular in the Indian subcontinent
- countries: IN
- kinds: human food, cookie
- has Wikipedia article: en

## DISH Q19819989
- name: Kabak kalye
- description: light dish of spring courgettes, from the Turkish cuisine
- countries: TR
- kinds: food, dish
- ingredients: zucchini

## DISH Q19820043
- name: Mokary
- countries: MG
- kinds: cake, galette, food

## DISH Q19820105
- name: Semizotu with yogurt
- description: Turkish meze or starter plate made with verdolaga and yogurt
- countries: TR
- kinds: salad

## DISH Q19824455
- name: Solothurner Torte
- description: cake with origin in the Swiss city Solothurn
- countries: (none)
- kinds: torte
- ingredients: meringue

## DISH Q19829597
- name: Janhagel
- description: Old-fashioned Dutch cookie
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q1983643
- name: Taai-taai
- description: Dutch cookie
- countries: (none)
- kinds: food, cookie
- ingredients: Pimpinella anisum, Secale cereale, honey

## DISH Q19838749
- name: Düğün çorbası
- description: traditional soup from the Turkish cuisine, which literally means "wedding soup" and is served in social occasions like a wedding
- countries: TR
- cuisines: Turkish cuisine
- kinds: dish, chorba
- ingredients: mutton, onion, paprika, flour, carrot
- has Wikipedia article: en

## DISH Q19839599
- name: List of apple dishes
- description: Wikimedia list article
- countries: (none)
- kinds: dessert, Wikimedia list article
- has Wikipedia article: en

## DISH Q19839943
- name: Cantonese salted fish
- description: traditional Chinese food originating from Guangdong province
- countries: (none)
- kinds: dried fish, fermented fish
- has Wikipedia article: en

## DISH Q19840502
- name: Yarma çorbası
- description: soup from the Turkish cuisine, made with "yarma", a wheat by-product
- countries: TR
- kinds: soup

## DISH Q19841241
- name: Açma
- description: Turkish bread, widely consumed as street food
- countries: TR
- kinds: food, Turkish breads
- ingredients: white sugar, wheat flour, cooking oil, yeast, butter, table salt, drinking water, margarine
- has Wikipedia article: en

## DISH Q19851743
- name: Danbing
- other names: {"zh": "台式蛋餅"}
- description: Taiwanese egg crêpe
- countries: TW
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q19851800
- name: Wu geng chang wang
- other names: {"zh": "五更腸旺"}
- description: Taiwanese dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q19854112
- name: Ma jiang mian
- other names: {"zh": "麻酱面"}
- description: noodles stirred with sesame sauce
- countries: (none)
- kinds: noodle dish
- has Wikipedia article: zh

## DISH Q1987316
- name: Maida flour
- other names: {"zh": "麥達麵粉"}
- description: fine wheat flour
- countries: IN
- kinds: flour, wheat flour, atta
- has Wikipedia article: en

## DISH Q19875130
- name: Light cheese cake
- other names: {"zh": "日式起司蛋糕"}
- description: Light sponge cake with cream cheese
- countries: JP
- cuisines: Japanese cuisine
- kinds: cake, cheesecake
- ingredients: egg as food, cheese, cream cheese, butter, sugar
- has Wikipedia article: en, zh

## DISH Q198788
- name: Senbei
- other names: {"zh": "煎饼"}
- description: Japanese rice cracker
- countries: JP
- kinds: wagashi, Beika, rice cracker
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q1988612
- name: Bean soup
- description: dish
- countries: (none)
- kinds: dish, soup, legume dish
- ingredients: bean, broth

## DISH Q19887142
- name: Potato cake
- description: various cake-shaped potato dishes
- countries: (none)
- kinds: type of food or dish, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q1988957
- name: Worstenbrood
- description: sausage filled bread roll
- countries: (none)
- kinds: finger food

## DISH Q1988970
- name: Kibinai
- other names: {"zh": "基比奈"}
- description: Karaim meat pies
- countries: PL, UA, LT
- cuisines: Polish cuisine, Ukrainian cuisine, Lithuanian cuisine, Karaite cuisine
- kinds: dish, stuffed food
- ingredients: mutton, dough, onion
- has Wikipedia article: en

## DISH Q19891138
- name: Chargha
- description: Pakistani chicken dish
- countries: (none)
- kinds: chicken dish
- ingredients: chicken
- has Wikipedia article: en

## DISH Q19892252
- name: Concave cake
- description: Taiwanese cake with filling, originally from Portuguese and Japanese cuisine
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q19893634
- name: Nem Nướng
- description: Vietnamese food item
- countries: VN
- kinds: food, pork dish
- ingredients: minced meat
- has Wikipedia article: en

## DISH Q19894306
- name: Mutton curry
- other names: {"zh": "羊肉咖哩"}
- description: South Asian curry dish that is prepared from mutton
- countries: IN
- kinds: lamb dish, Indian curry
- ingredients: lamb meat
- has Wikipedia article: en, zh

## DISH Q19895414
- name: Chingri malai curry
- description: Bengali curry made from prawns and coconut milk and flavored with spices
- countries: (none)
- kinds: shrimp dish, Indian curry
- ingredients: prawn
- has Wikipedia article: en

## DISH Q19896348
- name: Shab Deg
- description: kashmiri dish
- countries: IN
- kinds: goat meat dish
- ingredients: turnip, goat meat
- has Wikipedia article: en

## DISH Q19898437
- name: Sorshe ilish
- description: Bengali fish recipe
- countries: BD
- cuisines: Bangladeshi cuisine
- kinds: ilish dish
- ingredients: Tenualosa ilisha, mustard oil, mustard, table salt
- has Wikipedia article: en

## DISH Q19898963
- name: Treccia d'oro
- description: cake
- countries: IT
- kinds: confectionery
- has Wikipedia article: en

## DISH Q19903564
- name: Bolo de arroz
- description: rice muffin from Portugal
- countries: PT
- kinds: food, egg dish, muffin
- ingredients: rice flour, egg as food
- has Wikipedia article: en

## DISH Q19910927
- name: Пачат
- other names: {"mdf": "Пачат"}
- countries: (none)
- cuisines: Mordovian cuisine
- kinds: pancake, dish

## DISH Q19921797
- name: Dried mixed fruits
- description: mixture of dried fruits
- countries: (none)
- kinds: dried fruit, dish
- ingredients: plum, apricot, apple

## DISH Q19933360
- name: Dražgoše honey breads
- countries: SI
- kinds: biscuit, gingerbread, Slovenian cuisine
- ingredients: clove, wheat flour, ammonium carbonate, cinnamon, honey

## DISH Q1993557
- name: Multigrain bread
- other names: {"zh": "雜糧麵包"}
- description: type of bread
- countries: (none)
- kinds: bread
- ingredients: Multigrain flour
- has Wikipedia article: en

## DISH Q19936058
- name: Slovenian roasted potatoes
- description: boiled potatoes fried in fat and onion according to Slovenian recipes
- countries: SI
- kinds: home fries

## DISH Q19938094
- name: Škofja Loka honey breads
- countries: SI
- kinds: biscuit, gingerbread, Slovenian cuisine
- ingredients: clove, rye flour, peppercorn, ammonium carbonate, honey

## DISH Q199401
- name: Zigeunerschnitzel
- description: German meat dish
- countries: DE
- kinds: meat dish
- ingredients: schnitzel

## DISH Q19943522
- name: Kalio
- description: Indonesian dish
- countries: ID
- kinds: meat dish
- has Wikipedia article: en

## DISH Q19943899
- name: Nasi tumpang
- countries: ID
- cuisines: Indonesian cuisine
- kinds: rice dish, dish, human food, traditional food, type of food or dish
- ingredients: mung bean sprout, rempeyek, Tempeh, peanut, rice

## DISH Q19944077
- name: Petis
- countries: ID
- cuisines: Indonesian cuisine
- kinds: stimulant foodstuff, dish, human food, type of food or dish
- ingredients: garlic, shrimp and prawn as food, palm sugar, table salt, water

## DISH Q19944109
- name: Pukis
- description: Indonesian hot cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: cake, jajan pasar, dish, human food, type of food or dish
- ingredients: coconut, wheat flour, fermentation starter, coconut milk, egg as food, sugar, margarine
- has Wikipedia article: en

## DISH Q19947090
- name: Jabłko łąckie
- other names: {"pl": "Jabłko łąckie"}
- countries: (none)
- kinds: dish

## DISH Q19947255
- name: Sneeuwbal
- other names: {"nl": "sneeuwbal"}
- countries: (none)
- kinds: candy

## DISH Q19947359
- name: Canard á foie gras du Sud-Ouest
- description: indication géographique protégée, in France
- countries: FR
- kinds: foie gras
- ingredients: duck liver

## DISH Q19947459
- name: Gâteau de Savoie
- other names: {"zh": "萨伏依蛋糕"}
- countries: FR
- kinds: cake
- has Wikipedia article: zh

## DISH Q19949631
- name: Aguachile
- description: Mexican dish
- countries: MX
- kinds: shrimp dish
- has Wikipedia article: en

## DISH Q19950730
- name: Torta
- description: Mexican dish
- countries: (none)
- kinds: sandwich
- ingredients: bolillo
- has Wikipedia article: en

## DISH Q19951699
- name: Artichauts à la barigoule
- other names: {"de": "Artichauts à la barigoule"}
- countries: FR
- kinds: dish

## DISH Q19952
- name: Farfalle
- other names: {"zh": "蝴蝶麵"}
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: durum flour
- has Wikipedia article: en, zh

## DISH Q1995435
- name: Tiradito
- description: Peruvian dish of raw seafood
- countries: PE
- kinds: meal, raw fish dish
- ingredients: lime juice, fish as food
- has Wikipedia article: en

## DISH Q19958198
- name: Ming'oko
- description: traditional food in Mtwara and Lindi, Tanzania
- countries: TZ
- kinds: food, soup
- has Wikipedia article: en

## DISH Q19958364
- name: Rollò
- description: a type of swiss roll from Caltanissetta
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q19959
- name: Cavatelli
- description: type of pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q19961671
- name: Callos con garbanzos
- description: tripe and chickpea dish, common to Spain and Turkey (nohutlu işkembe yahnisi)
- countries: TR
- kinds: dish
- ingredients: chickpea, tripe

## DISH Q19962
- name: Conchiglie
- other names: {"zh": "貝殼麵"}
- description: type of pasta in the shape of a seashell
- countries: IT
- kinds: pasta
- has Wikipedia article: en, zh

## DISH Q1996530
- name: Bánh tẻ
- description: Vietnamese steamed rice cakes
- countries: VN
- kinds: bánh, pork dish
- has Wikipedia article: en

## DISH Q19966
- name: Fusilli
- other names: {"zh": "螺旋粉"}
- description: long, thick, corkscrew shaped pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en, zh

## DISH Q19969
- name: Orecchiette
- other names: {"zh": "猫耳朵 (意大利)"}
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q19971593
- name: Braune Kuchen
- countries: (none)
- kinds: cookie

## DISH Q19978502
- name: Bänkvälling
- other names: {"sv": "Bänkvälling"}
- countries: (none)
- kinds: dish

## DISH Q19979570
- name: Hamsi tava
- description: fried "hamsi" (European anchovies) dish in the Black Sea Region cuisine of Turkey
- countries: TR
- kinds: fish dish, food
- ingredients: cornmeal, hazelnut oil, European anchovy

## DISH Q1999698
- name: Oudewijvenkoek
- other names: {"nl": "Oudewijvenkoek"}
- countries: (none)
- kinds: food, ontbijtkoek

## DISH Q20000906
- name: Dam curry
- other names: {"zh": "水壩咖哩飯"}
- countries: (none)
- kinds: dish, Japanese curry
- has Wikipedia article: zh

## DISH Q20007
- name: Bucatini
- other names: {"zh": "吸管麵"}
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: durum wheat semolina
- has Wikipedia article: en

## DISH Q20008263
- name: Finocchini
- countries: IT
- kinds: dessert

## DISH Q20008404
- name: Pinza bolognese
- description: Italian pastry
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q20009059
- name: Baci di Cherasco
- description: Italian hazelnut chocolate dessert
- countries: (none)
- kinds: bonbon
- ingredients: hazelnut, dark chocolate

## DISH Q20009298
- name: Pandoli di Schio
- other names: {"it": "Pandoli di Schio"}
- countries: IT
- kinds: dessert

## DISH Q20009623
- name: Caciotta al tartufo
- other names: {"it": "Caciotta al tartufo"}
- countries: IT
- kinds: cheese

## DISH Q20009629
- name: Cartoccio di ricotta
- other names: {"it": "Cartoccio di ricotta"}
- countries: IT
- kinds: dessert

## DISH Q20009675
- name: Formaggella del Luinese PDO
- other names: {"zh": "Formaggella del Luinese DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: goat cheese, soft cheese, Italian cheese, cheese

## DISH Q20009780
- name: Raffiolini
- other names: {"it": "Raffiolini"}
- countries: IT
- kinds: dessert

## DISH Q20009781
- name: Raviola di ricotta of Caltanissetta
- description: ricotta and honey based dessert
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q20009796
- name: Easter flatbread
- description: Easter treat in Tuscany
- countries: IT
- kinds: dessert

## DISH Q20009814
- name: Holy Spina
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q20009815
- name: Squacquerone di Romagna PDO
- other names: {"zh": "Squacquerone di Romagna DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: Squacquerone, cheese

## DISH Q20009834
- name: Stroncatura
- description: type of pasta originating in Italy
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q20013195
- name: White rice
- description: plainly cooked rice
- countries: (none)
- kinds: meal, seed, rice dish
- ingredients: white rice, rice

## DISH Q20016
- name: Fideuà
- description: dish typical of the Valencian Community, in Spain
- countries: ES
- kinds: seafood dish, pasta dish, dish
- ingredients: garlic, onion, Sepia esculenta, shrimp, seafood, noodle, olive oil, Mytilus edulis, table salt, water
- has Wikipedia article: en

## DISH Q20017159
- name: Mantecados de Portillo
- countries: ES
- kinds: mantecado

## DISH Q20017300
- name: Corone
- other names: {"zh": "螺旋麵包"}
- description: Japanese horn-shaped sweet bread
- countries: (none)
- kinds: sweet bread
- has Wikipedia article: en, zh

## DISH Q20019
- name: Macaroni
- other names: {"zh": "通心粉"}
- description: dry pasta variety
- countries: IT
- kinds: pasta, type of pasta
- ingredients: durum wheat semolina, wheat flour
- has Wikipedia article: en, zh

## DISH Q20022277
- name: Rondón
- description: Afro-Caribbean dish present in Latin American Cuisine, made of seafood, coconut milk and vegetables
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q20023
- name: Paccheri
- other names: {"zh": "帕凱利通心粉"}
- description: type of pasta
- countries: IT
- cuisines: Italian cuisine
- kinds: pasta, type of food or dish
- has Wikipedia article: en, zh

## DISH Q20024
- name: Rigatoni
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: flour
- has Wikipedia article: en

## DISH Q20024826
- name: Soltero de queso
- countries: PE
- kinds: entrée, meal
- ingredients: Habas, tomato, cheese, potato

## DISH Q20026
- name: Spaghetti
- other names: {"zh": "意大利面"}
- description: long, thin, solid, cylindrical pasta
- countries: IT
- cuisines: Italian cuisine
- kinds: noodle, string-like macaroni products, type of pasta
- ingredients: durum wheat semolina, water
- has Wikipedia article: en, zh

## DISH Q20027
- name: Vermicelli
- other names: {"zh": "线面"}
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta, macaroni and analogous flour products, string-like macaroni products
- ingredients: wheat
- has Wikipedia article: en, zh

## DISH Q2002721
- name: Peanut paçoca
- description: Brazilian sweet made of ground peanuts, sugar, and cassava flour
- countries: BR
- kinds: river, confectionery
- ingredients: peanut, sugar
- has Wikipedia article: en

## DISH Q20029
- name: Capellini
- other names: {"zh": "Capellini"}
- description: type of pasta
- countries: IT
- cuisines: Italian cuisine
- kinds: pasta, type of pasta
- has Wikipedia article: en, zh

## DISH Q20031
- name: Bavette
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q20032
- name: Fettuccine
- other names: {"zh": "緞帶麵"}
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q20033470
- name: Kavring
- other names: {"sv": "kavring"}
- countries: (none)
- kinds: bread
- ingredients: filmjölk, golden syrup, wheat flour

## DISH Q20033650
- name: Arumszalc
- other names: {"pl": "Arumszalc"}
- description: variety of scrambled eggs of the Old-Polish cuisine
- countries: (none)
- kinds: dish

## DISH Q20033796
- name: Kiełbasa markowska
- other names: {"pl": "Kiełbasa markowska"}
- countries: (none)
- kinds: dish

## DISH Q20033797
- name: Saucisse des Basses-Carpates
- other names: {"fr": "saucisse des Basses-Carpates"}
- countries: PL
- kinds: dish

## DISH Q20033866
- name: Mus Charosset
- other names: {"pl": "Mus Charosset"}
- countries: (none)
- kinds: dessert

## DISH Q20034
- name: Lasagna
- other names: {"zh": "千層麵"}
- description: layered pasta dish
- countries: IT
- cuisines: Italian cuisine
- kinds: pasta dish, dish
- ingredients: ragù, lasagne sheet, béchamel, Parmesan
- has Wikipedia article: en, zh

## DISH Q20034048
- name: Piękny Jaś z Doliny Dunajca
- other names: {"pl": "Piękny Jaś z Doliny Dunajca"}
- countries: (none)
- kinds: dish

## DISH Q20034088
- name: Polędwica swojska pilzneńska
- other names: {"pl": "Polędwica swojska pilzneńska"}
- countries: PL
- kinds: dish

## DISH Q20034136
- name: Salsza
- other names: {"pl": "Salsza"}
- countries: (none)
- kinds: dish

## DISH Q20035
- name: Linguine
- other names: {"zh": "扁意粉"}
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: flour
- has Wikipedia article: en

## DISH Q20035299
- name: Melchmus
- other names: {"pl": "Melchmus"}
- countries: (none)
- kinds: dish

## DISH Q20035333
- name: Obermus
- other names: {"pl": "Obermus"}
- countries: (none)
- kinds: dish

## DISH Q20035399
- name: Czarny sos polski
- other names: {"pl": "Czarny sos polski"}
- countries: (none)
- kinds: dish

## DISH Q20035400
- name: Żółty sos polski
- other names: {"pl": "Żółty sos polski"}
- countries: (none)
- kinds: dish

## DISH Q20039
- name: Mafaldine
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: flour
- has Wikipedia article: en

## DISH Q20039423
- name: Katsu rice
- countries: (none)
- kinds: Japanese rice dish
- ingredients: katsu, cooked rice

## DISH Q20041
- name: Pappardelle
- description: type of pasta
- countries: IT
- kinds: egg pasta, type of pasta
- has Wikipedia article: en

## DISH Q20043
- name: Stringozzi
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q20043331
- name: Ekmek
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q20044
- name: Tagliatelle
- other names: {"zh": "鳥巢麵"}
- description: type of pasta
- countries: IT
- cuisines: Italian cuisine
- kinds: egg pasta, type of pasta
- ingredients: egg as food, flour
- has Wikipedia article: en

## DISH Q20046
- name: Tagliolini
- description: type of pasta
- countries: IT
- kinds: egg pasta, type of pasta
- has Wikipedia article: en

## DISH Q20047
- name: Alphabet soup
- description: soup made with alphabet pasta
- countries: (none)
- kinds: noodle soup
- ingredients: alphabet pasta, broth

## DISH Q20048
- name: Fregula
- description: type of pasta
- countries: IT
- cuisines: cuisine of Sardinia
- kinds: pasta
- ingredients: semolina
- has Wikipedia article: en

## DISH Q20051
- name: Agnolotti
- description: type of pasta
- countries: FR, IT
- cuisines: Italian cuisine
- kinds: stuffed pasta
- ingredients: vegetable, meat, pasta
- has Wikipedia article: en

## DISH Q2005160
- name: Nunt
- description: walnut honey confection traditionally eaten on Purim
- countries: (none)
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q200527
- name: Salisbury steak
- other names: {"zh": "梳士巴利漢堡扒"}
- description: meat patty
- countries: US
- kinds: dish, hamburger
- ingredients: beef
- has Wikipedia article: en, zh

## DISH Q20052814
- name: Bolo baeta
- other names: {"pt": "bolo baeta"}
- countries: (none)
- kinds: dessert

## DISH Q20052841
- name: Brisas do lis
- description: Portuguese dessert
- countries: PT
- kinds: dessert
- ingredients: almond meal, egg yolk, sugar

## DISH Q2005477
- name: Walnut and almond cake
- description: Polish cake
- countries: PL
- kinds: torte, cake

## DISH Q20055
- name: Maultasche
- other names: {"zh": "德国馄饨"}
- description: German dish
- countries: DE
- kinds: stuffed pasta, pasta dish
- has Wikipedia article: en, zh

## DISH Q2005538
- name: Nussecke
- countries: (none)
- kinds: viennoiserie

## DISH Q20057
- name: Tortellini
- other names: {"zh": "意大利馄饨"}
- description: pasta stuffed with filling
- countries: IT
- cuisines: Emilian cuisine, cuisine of the province of Modena
- kinds: stuffed pasta, egg pasta, type of pasta
- ingredients: egg as food, nutmeg, wheat, raw ham, short loin, mortadella, Parmesan
- has Wikipedia article: en, zh

## DISH Q20059083
- name: Mel das Terras Altas do Minho
- description: Portuguese honey
- countries: (none)
- kinds: honey

## DISH Q20059084
- name: Mel do Alentejo
- description: Portuguese honey
- countries: (none)
- kinds: honey

## DISH Q20059289
- name: Presunto de Campo Maior e Elvas
- description: Portuguese pork dish
- countries: (none)
- kinds: ham

## DISH Q20060232
- name: Mallung
- description: Sri Lankan dish
- countries: LK
- kinds: dish
- has Wikipedia article: en

## DISH Q20060278
- name: Mel de Barroso
- description: Portuguese honey
- countries: (none)
- kinds: honey

## DISH Q20060279
- name: Mel do Ribatejo Norte
- description: Portuguese honey
- countries: (none)
- kinds: honey

## DISH Q20060505
- name: Pão brote
- other names: {"pt": "pão brote"}
- countries: (none)
- kinds: bread

## DISH Q20061
- name: Tortelloni
- description: type of pasta
- countries: IT
- kinds: stuffed pasta, egg pasta, type of pasta
- has Wikipedia article: en

## DISH Q20061165
- name: Sardinhas doces de Trancoso
- description: fish-shaped cakes
- countries: PT
- kinds: dessert
- ingredients: almond, egg yolk, flour, cinnamon, sugar, chocolate

## DISH Q20061544
- name: Torta capixaba
- other names: {"pt": "torta capixaba"}
- countries: (none)
- kinds: dish

## DISH Q20063132
- name: 大雕燒
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q20064322
- name: Kavurma
- description: Turkish meat conservation tecnique and meat conserved as such
- countries: TR
- cuisines: Turkish cuisine
- kinds: meat dish, cold cut
- has Wikipedia article: en

## DISH Q2007076
- name: Nürnberger Gwerch
- other names: {"de": "Nürnberger Gwerch"}
- countries: (none)
- kinds: salad

## DISH Q20075421
- name: Гарбузова каша
- other names: {"uk": "Гарбузова каша"}
- countries: RU, UA
- cuisines: Russian cuisine, Ukrainian cuisine
- kinds: porridge
- ingredients: groat, Cucurbita

## DISH Q20081987
- name: Mandrykas
- description: Ukrainian pastry
- countries: UA
- kinds: baking, dish
- ingredients: smetana, dough, egg, cheese
- has Wikipedia article: en

## DISH Q20083166
- name: Облызни
- other names: {"ru": "облызни"}
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: dish
- ingredients: flour

## DISH Q20083188
- name: 野菜ペースト
- other names: {"ja": "野菜ペースト"}
- countries: (none)
- kinds: vegetable dish

## DISH Q20085174
- name: Kue putu
- other names: {"zh": "普圖糕"}
- description: Indonesian traditional cake
- countries: ID
- kinds: food, human food
- ingredients: brown sugar, coconut, rice flour, food coloring, Pandanus amaryllifolius, table salt, water
- has Wikipedia article: en

## DISH Q20088993
- name: Tuo Zaafi
- description: Ghanaian delicacy from the North
- countries: GH
- kinds: swallow, dish
- ingredients: cassava flour, maize, drinking water

## DISH Q2009256
- name: Banitsa
- other names: {"zh": "保加利亞褶餅"}
- description: traditional Bulgarian pie
- countries: BG
- cuisines: Bulgarian cuisine
- kinds: food, pastry, egg dish
- ingredients: phyllo, egg as food
- has Wikipedia article: en, zh

## DISH Q20092696
- name: Chocolate salo
- description: Ukrainian dish
- countries: UA
- kinds: dessert
- ingredients: salo, butter, chocolate
- has Wikipedia article: en

## DISH Q20093085
- name: Slastions
- description: filled doughnuts found in Ukrainian cuisine
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: pastry

## DISH Q20093206
- name: Solozhenyk
- description: traditional Ukrainian Easter pie
- countries: (none)
- kinds: dessert

## DISH Q2009326
- name: Butterscotch
- other names: {"zh": "奶油糖果"}
- description: type of confection whose primary ingredients are brown sugar and butter
- countries: (none)
- kinds: confectionery
- ingredients: butter, sugar, brown sugar
- has Wikipedia article: en, zh

## DISH Q20097569
- name: Ябчанка
- other names: {"uk": "Ябчанка"}
- countries: (none)
- kinds: dish, confectionery

## DISH Q20099097
- name: İslim kebap
- description: Turkish stew with eggplants and beef or veal (sometimes w/ lamb or mutton)
- countries: TR
- kinds: eggplant kebab

## DISH Q20102965
- name: El Niu
- other names: {"ca": "El Niu"}
- countries: (none)
- kinds: dish

## DISH Q20103300
- name: Rotllets de Sant Antoni
- other names: {"ca": "Rotllets de Sant Antoni"}
- countries: (none)
- kinds: confectionery

## DISH Q20103344
- name: Sabre de Sant Pau
- other names: {"ca": "Sabre de Sant Pau"}
- countries: (none)
- kinds: food, Tortell

## DISH Q20103797
- name: Blat de moro escairat
- other names: {"ca": "blat de moro escairat"}
- countries: (none)
- kinds: dish
- ingredients: maize, pig

## DISH Q20104106
- name: Fava parada
- other names: {"ca": "fava parada"}
- countries: (none)
- kinds: dish

## DISH Q20104109
- name: Pa de ronyó
- description: Bread tipical from West Catalonia, Spain
- countries: (none)
- kinds: bread

## DISH Q20104112
- name: Pa del Pamano
- other names: {"ca": "Pa del Pamano"}
- countries: (none)
- kinds: bread

## DISH Q20104174
- name: Paracota
- other names: {"es": "Paracota"}
- countries: (none)
- kinds: dish

## DISH Q20104352
- name: Figat
- other names: {"ca": "figat"}
- countries: (none)
- kinds: confectionery

## DISH Q20104793
- name: Xatonada
- other names: {"ca": "xatonada"}
- countries: (none)
- kinds: dish

## DISH Q20105841
- name: Macarrons amb grevi
- other names: {"ca": "macarrons amb grevi"}
- countries: (none)
- kinds: dish
- ingredients: penne

## DISH Q20105863
- name: Pa de Tramuntana
- other names: {"ca": "Pa de Tramuntana"}
- countries: (none)
- kinds: bread

## DISH Q20106004
- name: Pastís de Sant Jordi
- other names: {"ca": "pastís de Sant Jordi"}
- countries: (none)
- kinds: cake

## DISH Q20106022
- name: Patates amb tomàquets al forn
- other names: {"ca": "Patates amb tomàquets al forn"}
- countries: (none)
- kinds: dish
- ingredients: potato, tomato

## DISH Q20106042
- name: Bisbalenc
- other names: {"ca": "Bisbalenc"}
- countries: (none)
- cuisines: cuisine of La Bisbal d'Empordà
- kinds: culinary speciality

## DISH Q20106091
- name: Bou i arròs
- other names: {"ca": "Bou i arròs"}
- countries: (none)
- kinds: dish

## DISH Q20106127
- name: Pèsols negres
- other names: {"ca": "pèsols negres"}
- countries: (none)
- kinds: dish

## DISH Q20106265
- name: Pomes de relleno
- other names: {"ca": "pomes de relleno"}
- countries: (none)
- kinds: dessert
- ingredients: apple

## DISH Q20106267
- name: Caragols cuinats
- other names: {"ca": "caragols cuinats"}
- countries: (none)
- kinds: dish, snail as food

## DISH Q20106371
- name: Farinosa
- other names: {"ca": "Farinosa"}
- countries: (none)
- kinds: dessert

## DISH Q20106375
- name: Faviola
- other names: {"ca": "faviola"}
- countries: (none)
- kinds: cake

## DISH Q20106816
- name: Vedella dels Pirineus Catalans
- other names: {"ca": "Vedella dels Pirineus Catalans"}
- countries: ES, FR
- kinds: veal

## DISH Q20107263
- name: Aspes de Santa Eulàlia
- other names: {"ca": "aspes de Santa Eulàlia"}
- countries: (none)
- kinds: confectionery

## DISH Q20107719
- name: Ayran soup
- description: Turkish cold soup with yogurt, chickpeas, and yarma
- countries: (none)
- kinds: Turkish soups, cold sweet soup
- ingredients: chickpea, Wheat mote, yogurt

## DISH Q20107937
- name: Fruit sweets in the Turkish cuisine
- countries: (none)
- kinds: dish

## DISH Q20108087
- name: Fanurópita
- other names: {"ca": "Fanurópita"}
- countries: GR
- kinds: dessert

## DISH Q20108295
- name: Kuzu haşlama
- description: mutton or lamb stew from Turkey
- countries: TR
- kinds: stew, food
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q20108564
- name: Orelletes
- other names: {"ca": "orelletes"}
- countries: (none)
- kinds: confectionery

## DISH Q20108576
- name: Pa oli boix
- other names: {"ca": "pa oli boix"}
- countries: (none)
- kinds: dish

## DISH Q20108596
- name: Panellets de Sant Roc
- other names: {"ca": "panellets de Sant Roc"}
- countries: (none)
- kinds: confectionery

## DISH Q20108616
- name: Patlıcanlı köfte
- description: Turkish meatball stew with eggplants
- countries: TR
- kinds: stew, meatball, food
- ingredients: minced meat, eggplant

## DISH Q20108763
- name: Recuit de drap
- other names: {"ca": "Recuit de drap"}
- countries: (none)
- kinds: dessert, fresh cheese
- ingredients: milk

## DISH Q20108974
- name: Terregada
- other names: {"ca": "terregada"}
- countries: (none)
- kinds: dish

## DISH Q20110889
- name: کاکولی
- other names: {"fa": "کاکولی"}
- countries: (none)
- kinds: pastry

## DISH Q20110925
- name: کلوچه فومن
- other names: {"fa": "کلوچه فومن"}
- countries: (none)
- kinds: pastry

## DISH Q20110927
- name: Kamach sahan
- description: sweet from Iran
- countries: (none)
- kinds: pastry

## DISH Q201120
- name: Paska
- other names: {"zh": "帕斯卡"}
- description: Eastern European pastry traditionally baked for Easter
- countries: BY, MD, RO, RU, UA
- cuisines: Russian cuisine, Belarusian cuisine, Ukrainian cuisine
- kinds: Easter bread, baked good
- ingredients: egg as food, butter, sugar, milk
- has Wikipedia article: en, zh
