# Review batch names-006

## DISH Q108552972
- name: Amudi machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552973
- name: Sankar machher kalia
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q108552974
- name: Sankar machher tel er bora
- description: bengali cuisine
- countries: (none)
- kinds: Vada, fish dish

## DISH Q108552975
- name: Sankar machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552976
- name: Alu peyajkoli diye sankar machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552977
- name: Sankar machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552978
- name: Sankar machher rosa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108552979
- name: Kuche machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552980
- name: Gule machher jhal chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish, Jhal

## DISH Q108552982
- name: Pangas machher kalia
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q108552984
- name: Alu begun diye pangas machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552985
- name: Pangas machher vuna
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108552987
- name: Pangas machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552988
- name: Pangas machher tok jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552989
- name: Foli machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552990
- name: Alu tomato diye foli machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552991
- name: Foli machher sorse jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552992
- name: Alu kanchakola diye foli machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552994
- name: Foli machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552995
- name: Alu diye foli machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552997
- name: Alu begun daler bori diye foli machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552998
- name: Alu uchchhe diye foli machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552999
- name: Koi machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108553001
- name: Bori fulkopi diye koi machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553016
- name: Begun diye bata machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553018
- name: Mourola machher shukto
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Shukto

## DISH Q108553019
- name: Tengra machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108553020
- name: Desi tengrar tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553022
- name: Ban machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108553023
- name: Ban machher rosa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553024
- name: Alu diye ban machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553025
- name: Ban machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553026
- name: Narkel bata diye ban machher bhuna
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553027
- name: Ban machh kosha
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553028
- name: Chitol machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108553029
- name: Alu diye chitol machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553031
- name: Magur machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553032
- name: Jhinge alu diye rui machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553033
- name: Pepe totato diye telapia machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553034
- name: Telapia machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553035
- name: Alu fulkopi diye telapia machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553036
- name: Alu begun diye telapia machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553037
- name: Telapia machher sorse jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553038
- name: Alu bori tomato diye telapia machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553040
- name: Telapia machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108553041
- name: Ritha machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108553043
- name: Ritha machher bhuna
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553044
- name: Ritha machher kalia
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q108553045
- name: Kochu, alu o begun diye bata machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553046
- name: Parse machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108553047
- name: Parse machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553048
- name: Parser sorse jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553050
- name: Alu bori diye parse machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553051
- name: Begun diye parse machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553052
- name: Doi parse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553053
- name: Parse bhapa
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Bhapa

## DISH Q108553054
- name: Sorse posto parse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553057
- name: Topser horogouri
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553059
- name: Mouri parse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553060
- name: Alu begun diye parse machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553061
- name: Alu tomato diye parse machher patla jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553062
- name: Dudh parse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553064
- name: Aam diye parse machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553066
- name: Tel parse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553067
- name: Posto bata diye parse machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553068
- name: Rangila parse
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553070
- name: Ol kochu diye parse machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553072
- name: Parse machher tok
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553073
- name: Doi mouri parse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553075
- name: Kanchkola diye parse machher patla jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553076
- name: Lonka parse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553099
- name: Sorse shim diye parse machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553100
- name: Begun bori diye sorse parse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553101
- name: Bata machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553103
- name: Alu begun bori diye bata machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553104
- name: Bata machher sorse jhal
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553105
- name: Sorse posto diye bata machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553107
- name: Doi bata
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553108
- name: Bata machher horogouri
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553109
- name: Alu potol begun diye bata machher patla jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553111
- name: Alu fulkopi diye bata machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553112
- name: Olkopi diye bata machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553113
- name: Jhinge alu diye bata machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553114
- name: Bata machh fry
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108553115
- name: Bata machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553116
- name: Bata machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108553117
- name: Bata machher vapa
- description: Bengali cuisine
- countries: (none)
- kinds: Bhapa, fish dish

## DISH Q108553119
- name: Bata machher tok
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553120
- name: Bata machher paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q108553121
- name: Shim alu diye bata machher patla jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553122
- name: Aam diya bata machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553123
- name: Doi pabda
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553124
- name: Pabda machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108553125
- name: Pabda machh er tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553126
- name: Malai pabda
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553127
- name: Pabda machher sorse jhal
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553129
- name: Pabda machher rosa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553130
- name: Kalojeera diye pabda machher patla jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553132
- name: Begun bori diye pabda machher patla jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553135
- name: Pabda machher bhuna
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553136
- name: Pabda sorse posto
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553137
- name: Pabda posto
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553138
- name: Tel pabda
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553140
- name: Tomato pabda
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553141
- name: Pabda machher tel bori jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553142
- name: Aam pabda
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553143
- name: Dudh pabda
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553144
- name: Hing diye pabda machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553146
- name: Jhinge pabdar jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553147
- name: Lebu pabda
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553148
- name: Bhapa pabda
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553149
- name: Alu, bori o potol diye pabda machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553150
- name: Pabda machher paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q108553151
- name: Topse fry
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108553153
- name: Aam kasundi pabda
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553154
- name: Fulkopi diye pabda machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553155
- name: Alu diye topse machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553156
- name: Topse begun chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108553157
- name: Lebu pata diye mourala machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553158
- name: Topse sorse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553178
- name: Topse machher paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q108553179
- name: Alu bori diye topse machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553180
- name: Topse machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553181
- name: Alu diye latha machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553182
- name: Thankuni pata diye latha macher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553183
- name: Ganti kochu diye latha machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553185
- name: Latha machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553186
- name: Aar machher doi sorse
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553188
- name: Aam diye latha machher tok
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108553189
- name: Aar machher sorse jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553190
- name: Dhai machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553191
- name: Mulo diye shol machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108553192
- name: Lau diye shol machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108553195
- name: Pui metuli diye mourala machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q10855333
- name: Kōri-mochi
- countries: (none)
- kinds: mochi, preserved food

## DISH Q10855366
- name: Goheimochi
- other names: {"zh": "五平饼"}
- description: Japanese regional cuisine
- countries: (none)
- kinds: mochi, kushiyaki, food
- has Wikipedia article: en, zh

## DISH Q108553710
- name: Rice with chicken a la chorrera
- description: Cuban dish
- countries: CU
- kinds: dish

## DISH Q10855549
- name: Kuzukiri
- description: kudzu starch noodle
- countries: JP
- kinds: noodle
- ingredients: kudzu powder

## DISH Q10855551
- name: Kuchitori gashi
- countries: (none)
- kinds: wagashi, New Year's food

## DISH Q10855985
- name: Nabeyaki udon
- countries: (none)
- kinds: nabemono, nikomi udon

## DISH Q10856235
- name: Nuta
- countries: JP
- kinds: namasu
- ingredients: sumiso

## DISH Q10856263
- name: Nibitashi
- countries: (none)
- kinds: nimono

## DISH Q10856318
- name: Tanukijiru
- description: Japanese vegetarian soup
- countries: JP
- cuisines: Japanese cuisine
- kinds: miso soup, dish
- ingredients: konnyaku, miso

## DISH Q10856331
- name: Tamago doufu
- other names: {"zh": "玉子豆腐"}
- description: savory egg pudding hardened like tofu
- countries: JP
- kinds: type of food or dish, egg dish
- ingredients: dashi, egg as food
- has Wikipedia article: zh

## DISH Q10856452
- name: Dak-bokkeum-tang
- description: Korean dish of braised spicy chicken
- countries: (none)
- kinds: food, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q108564625
- name: Ryssröra
- other names: {"sv": "Ryssröra"}
- countries: (none)
- kinds: dish

## DISH Q108568436
- name: Nilaga
- description: Filipino dish
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q108570082
- name: Gebzhalia
- description: a traditional Georgian dish
- countries: GE
- kinds: dish
- ingredients: Coriandrum, acıka, Capsicum, tarragon, Allium sativum, salt, cheese
- has Wikipedia article: en

## DISH Q108570447
- name: Gowi nitutu
- description: food of Nias Island, Indonesia
- countries: ID
- kinds: dish, human food, traditional food
- ingredients: cassava root

## DISH Q10857248
- name: 蟹黄汤包
- countries: CN
- kinds: Tangbao
- ingredients: crab roe
- has Wikipedia article: zh

## DISH Q108575262
- name: Ispi frito
- other names: {"es": "Ispi frito"}
- countries: (none)
- kinds: dish

## DISH Q108576689
- name: Cream roll
- other names: {"zh": "奶油面包"}
- description: sweet bun with cream filling
- countries: (none)
- kinds: sweet roll, bun
- has Wikipedia article: en

## DISH Q10858146
- name: Bacalao a la riojana
- other names: {"es": "Bacalao a la riojana"}
- countries: (none)
- kinds: fish dish, dish
- ingredients: tomato, Gadus morhua, olive oil, Capsicum annuum

## DISH Q108586604
- name: Cream korokke
- countries: (none)
- kinds: korokke
- ingredients: béchamel

## DISH Q108595777
- name: Gyokatsu
- countries: (none)
- kinds: fried fish, agekamaboko, katsu

## DISH Q10859806
- name: Norimaki
- other names: {"zh": "海苔卷"}
- description: rolled/filled seafood appetizer
- countries: JP
- kinds: type of food or dish, makizushi, seafood dish
- ingredients: nori
- has Wikipedia article: en

## DISH Q10860102
- name: Nigirizushi
- other names: {"zh": "握壽司"}
- description: variety of sushi consisting of a small mound of rice topped with a topping (typically raw seafood)
- countries: JP
- kinds: type of food or dish, sushi, Edo-style sushi
- ingredients: nori, raw fish, sumeshi
- has Wikipedia article: en, zh

## DISH Q10860302
- name: Haya-zushi
- other names: {"zh": "早寿司"}
- description: style of sushi
- countries: (none)
- kinds: Edo-style sushi

## DISH Q10860607
- name: Tekkamaki
- description: tekka maki
- countries: JP
- kinds: type of food or dish, makizushi, Edo-style sushi, tuna dish
- ingredients: sumeshi, Thunnus, nori

## DISH Q10860666
- name: Tororo kombu
- description: Ultrafine thread kelp
- countries: (none)
- kinds: entrée

## DISH Q108611058
- name: Håndværker
- other names: {"da": "håndværker"}
- countries: (none)
- kinds: bread

## DISH Q108611113
- name: Rundstykke
- other names: {"da": "rundstykke"}
- countries: (none)
- kinds: bread roll

## DISH Q108611407
- name: Zukeana
- description: A kind of Donburi or Chirashizushi
- countries: (none)
- kinds: chirashizushi, Kaisen-don

## DISH Q10861385
- name: Edo-style sushi
- other names: {"zh": "江户前寿司"}
- description: kind of sushi
- countries: JP
- kinds: sushi

## DISH Q10861386
- name: Kaki no ha zushi
- other names: {"zh": "柿葉壽司"}
- countries: JP
- kinds: dish, sushi
- ingredients: sumeshi, mackerel as food, leaf
- has Wikipedia article: zh

## DISH Q10861403
- name: Sumeshi
- other names: {"zh": "醋飯"}
- countries: (none)
- kinds: cooked rice, food ingredient
- ingredients: vinegar, rice
- has Wikipedia article: en, zh

## DISH Q108622800
- name: Wundschutzcreme
- other names: {"de": "Wundschutzcreme"}
- countries: (none)
- kinds: custard, cream, skincare product

## DISH Q108643173
- name: Mealie bread
- description: South African sweetcorn bread
- countries: (none)
- kinds: cornbread
- has Wikipedia article: en

## DISH Q108649402
- name: Icebox pie
- description: family of no-bake pies popular in the USA
- countries: (none)
- kinds: pie
- has Wikipedia article: en

## DISH Q10865714
- name: Sandapao
- other names: {"zh": "三大炮"}
- description: Chinese dessert made from glutinous rice flour
- countries: CN
- kinds: dessert
- ingredients: glutinous rice flour
- has Wikipedia article: zh

## DISH Q108672552
- name: Butter burger
- other names: {"zh": "黄油汉堡"}
- description: Hamburger topped with butter
- countries: US
- kinds: hamburger, type of food or dish
- ingredients: butter, hamburger
- has Wikipedia article: en

## DISH Q108673188
- name: Ghondhoraj lebu'r ghol
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108673238
- name: Gondhoraj chingri malaikari
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q108673269
- name: Sorshe diye bhola machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108673557
- name: Gondhoraj Pabda
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108673573
- name: Gondhoraj Ilish Paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q108673609
- name: Gondhoraj Paneer
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108673642
- name: Gondhoraj Ghol-er Pulao
- description: Bengali cuisine
- countries: (none)
- kinds: pilaf

## DISH Q108673658
- name: Gondhoraj Ol Chingri
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q1086747
- name: Virgin boy egg
- other names: {"zh": "童子蛋"}
- description: traditional dish of Dongyang, Zhejiang, China
- countries: (none)
- kinds: dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q10868024
- name: Shanghai-style salad
- other names: {"zh": "上海色拉"}
- description: localized Shanghai-style salad
- countries: (none)
- kinds: salad
- has Wikipedia article: en, zh

## DISH Q108684938
- name: Changsha stinky tofu
- description: hunan cuisine snack
- countries: CN
- cuisines: Hunan cuisine
- kinds: stinky tofu, type of food or dish
- has Wikipedia article: en

## DISH Q1086855
- name: Camembert de Normandie
- description: French cheese from Norrmandy
- countries: FR
- kinds: Camembert, white mold-rind cheese, French cheese, farmstead cheese, dairy cheese, cheese
- ingredients: cow's milk

## DISH Q10868579
- name: 下水湯
- countries: (none)
- kinds: soup, offal dish
- ingredients: offal
- has Wikipedia article: zh

## DISH Q108687663
- name: Ol Kochur Dhokla
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108687674
- name: Niramish Doi Olkopi
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108687684
- name: Olkopi aloor jhool
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108687692
- name: Shalgam Diye Rui Macher Jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q1086886
- name: Riviera Ligure PDO
- other names: {"zh": "Riviera Ligure DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q108697619
- name: Lauer Bichi bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697620
- name: Laupata-chingri machh bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697621
- name: Kachki macher bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697622
- name: Lau shaag bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697623
- name: Kochu patar bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697624
- name: Loitta Shutki bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697625
- name: Khathal bichi bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697626
- name: Kancha aam bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697627
- name: Vaja Rosuner bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697628
- name: Pora Rosun bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697629
- name: Chingri bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697630
- name: Uchchhe dherosh bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697631
- name: Ilisher lej bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697632
- name: Chyapa shutki bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697634
- name: Sorishar tele alu bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697635
- name: Narkeler bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697637
- name: Tometor bhorta
- description: bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697638
- name: Kalojira bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, Bhurta

## DISH Q108697639
- name: Borboti bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697640
- name: Rosun moricher bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697641
- name: Dhone patar bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697642
- name: Kancha tometor bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697643
- name: Ilish machher dimer bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697644
- name: Boyal machher bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697646
- name: Murgir keema begun bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697647
- name: Tometo rosun bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697649
- name: Rui machher dim tometo bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697650
- name: Murgir mete dim bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697651
- name: Ilish kachkola bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697653
- name: Chicken pora bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697654
- name: Dim badam bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697655
- name: Tok daal pora bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697656
- name: Chingri pora bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697658
- name: Mashladar alu bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697659
- name: Murgi bhorta
- description: bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697660
- name: Musoor Daal er bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697661
- name: Mishti Kumra bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697662
- name: Piyaj moricher bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697663
- name: Dherosh bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697664
- name: Alu Bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish, Bhurta

## DISH Q108697665
- name: Kakrol bhorta
- description: bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697666
- name: Badam bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697667
- name: Begun tometor bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697668
- name: Taki machher bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697669
- name: Seddho dimer bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish, Bhurta

## DISH Q108697670
- name: Pepe bhorta
- description: bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697671
- name: Shidol bhorta
- description: bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697672
- name: Kacha Kolar Bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697673
- name: Kolar khosa bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697674
- name: Sorshe o posto bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697691
- name: Chichinge bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697693
- name: Kucho chingri bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697694
- name: Palong Shak bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697695
- name: Korola patar bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697696
- name: Potol khosa bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697697
- name: Kochu shaag bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697698
- name: Dim Begun Bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697699
- name: Kachki shutki bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697700
- name: Mola shutki bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697702
- name: Bashpata shutki bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697703
- name: Mola bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697704
- name: Sidol shutki bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697705
- name: Thankuni pata bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697706
- name: Rui machher bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697708
- name: Pora tometo bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697709
- name: Shim Aloo bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697710
- name: Fulkopi bhorta
- description: bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697712
- name: Kumro borir bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697713
- name: Tomato Alur bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697714
- name: Sojona patar bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697715
- name: Ol kochur bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697716
- name: Rui machher lej bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697717
- name: Peyaj patar bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697718
- name: Narkel kochu bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697719
- name: Sorisha bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697720
- name: Beson bora bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697721
- name: Korola bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697722
- name: Laupata narkel bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697723
- name: Sheemer bichi bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697724
- name: Palong chingri bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697725
- name: Vaja begun bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697726
- name: Bata shutki bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697728
- name: Lau khosa rui bhorta
- description: bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697730
- name: Shalgom bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697731
- name: Telapia machher bhorta
- description: bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697732
- name: Bata ilish bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697733
- name: Sheem alu begun bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697734
- name: Mula shaag bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697735
- name: Sorisha shaag bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697736
- name: Nona ilish bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697737
- name: Puishaag ilish bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697738
- name: Lal shaag bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697740
- name: Peyaj kolir bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697741
- name: Alu kathal bichi bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697742
- name: Chingri alu bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697743
- name: Shim bichi alu bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697744
- name: Misti kumror ful bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697745
- name: Magur machher bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697746
- name: Kanchakolar borar bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697788
- name: Kochu bhorta
- description: bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q108697870
- name: Ilish machher matha diye pui shaker chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108698282
- name: Skefkef
- description: Moroccan street sandwich
- countries: MA
- kinds: sandwich, street food
- ingredients: beef, spice, bread

## DISH Q108703191
- name: Velouté
- description: soup
- countries: (none)
- kinds: potage

## DISH Q108717844
- name: Roti koekoes
- other names: {"nl": "roti koekoes"}
- countries: (none)
- cuisines: Indonesian-Dutch cuisine
- kinds: cake, type of food or dish

## DISH Q10872500
- name: Cutlet
- other names: {"zh": "Côtelette"}
- description: meat dish
- countries: (none)
- kinds: type of food or dish, meat dish
- has Wikipedia article: en, zh

## DISH Q108744549
- name: Galletes d'oli
- description: traditional salty biscuits from Majorca
- countries: (none)
- kinds: bread

## DISH Q1087577
- name: Sakuramochi
- other names: {"zh": "樱饼"}
- description: mochi made with sakura
- countries: JP
- kinds: mochi, wagashi
- ingredients: Sakuraba zuke, rice cake, red bean paste, mochi, flour
- has Wikipedia article: en, zh

## DISH Q108759397
- name: Dodol labu
- other names: {"id": "dodol labu"}
- countries: ID
- kinds: Dodol

## DISH Q108759512
- name: Kecampit
- description: Indonesian traditional snack from Way Kanan, Lampung
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, traditional food, type of food or dish

## DISH Q108770407
- name: Lalanga
- description: Greek and Turkish cuisine
- countries: (none)
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q108776243
- name: Pan cateto
- description: bread from Málaga and other parts of Andalusia, Spain
- countries: ES
- kinds: bread
