# Review batch names-034

## DISH Q2354397
- name: Kecap manis
- other names: {"zh": "甜酱油"}
- description: sweetened aromatic soy sauce, originating from Java island
- countries: ID
- kinds: soy sauce, kecap
- ingredients: soy bean, Aspergillus wentii, palm sugar, jaggery, spice, table salt
- has Wikipedia article: en, zh

## DISH Q2355867
- name: Stremellachs
- other names: {"de": "Stremellachs"}
- countries: (none)
- kinds: fish dish

## DISH Q2356049
- name: Khapse
- description: Tibetian deep-fried biscut
- countries: (none)
- kinds: food, cookie
- ingredients: wheat flour, tsampa, sunflower oil
- has Wikipedia article: en

## DISH Q2358937
- name: Brizoles
- other names: {"nl": "Brizoles"}
- countries: (none)
- kinds: meat dish

## DISH Q2360511
- name: Kortrijkse beschuiten
- other names: {"nl": "Kortrijkse beschuiten"}
- countries: (none)
- kinds: pastry

## DISH Q2364865
- name: Gazelle ankles🇲🇦🇲🇦
- description: traditional Marocain cookie made with almond paste and orange blossom water
- countries: (none)
- kinds: dish, pastry
- ingredients: Pasta di mandorle PAT, wheat flour, orange flower water, cinnamon, sugar
- has Wikipedia article: en

## DISH Q2365219
- name: Bappir
- description: sumerian Dish of Twice-baked barley bread
- countries: (none)
- kinds: food, bread
- ingredients: malt
- has Wikipedia article: en

## DISH Q23660813
- name: Ezme
- description: Turkish amuse-bouche, meze and/or hot sauce
- countries: TR
- cuisines: Turkish cuisine
- kinds: sauce, dip, food, salad
- ingredients: tomato, chili pepper, olive oil

## DISH Q2367602
- name: Fenalår
- description: Norwegian cured leg of lamb
- countries: NO
- kinds: lamb dish
- ingredients: sheep meat, kosher salt
- has Wikipedia article: en

## DISH Q2368931
- name: Schuimblok
- other names: {"nl": "Schuimblok"}
- countries: (none)
- kinds: candy

## DISH Q23689485
- name: Alt-Wiener Suppentopf
- other names: {"de": "Alt-Wiener Suppentopf"}
- countries: AT
- kinds: dish

## DISH Q23689489
- name: Gansleinmachsuppe
- other names: {"de": "Gansleinmachsuppe"}
- countries: (none)
- kinds: dish

## DISH Q23712115
- name: Avocado cake
- other names: {"zh": "鳄梨蛋糕"}
- description: cake using avocado as a primary ingredient
- countries: (none)
- kinds: cake
- ingredients: avocado
- has Wikipedia article: en, zh

## DISH Q2372494
- name: Plăcintă
- description: stuffed deep-fried pastry prepared with a variety of fillings
- countries: RO
- cuisines: Ukrainian cuisine
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q23758190
- name: Kinalas
- description: Philippine noodle dish
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q2378108
- name: Chanakhi
- other names: {"zh": "查纳基"}
- description: traditional Georgian dish
- countries: GE
- kinds: lamb dish, stew
- ingredients: leaf vegetable, vegetable, potato, Allium sativum, lamb meat, Allium, tomato
- has Wikipedia article: en, zh

## DISH Q23785743
- name: Ratiborer Pfefferkuchen
- other names: {"de": "Ratiborer Pfefferkuchen"}
- countries: (none)
- kinds: viennoiserie

## DISH Q23793187
- name: Hoşaf
- description: Turkish dried fruit compote
- countries: TR
- kinds: dessert
- has Wikipedia article: en

## DISH Q23807286
- name: Rabeg
- description: traditional Indonesian stew from Banten, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: garlic, beef, offal, table salt

## DISH Q2382108
- name: Sülzkotelett
- other names: {"de": "Sülzkotelett"}
- countries: (none)
- kinds: dish, sulze
- ingredients: gelatin dessert, pork chop

## DISH Q23824434
- name: Obwarzanek
- other names: {"zh": "克拉科夫貝果"}
- description: A kind of Polish bagel
- countries: (none)
- kinds: bread, street food, baranki
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q2383068
- name: Skerpikjøt
- description: Wind-dried mutton from the Faroe Islands
- countries: FO
- kinds: human food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q2383238
- name: Poularde
- other names: {"zh": "閹母雞"}
- description: chicken that is at least 120 days old at the time of slaughter and fattened with a rich diet that delays egg production
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q2386515
- name: Lacquemant waffles
- other names: {"zh": "拉克芒华夫饼"}
- description: culinary specialty from Liège, commonly eaten during the October fair; thin wheaten wafer, cut in two horizontally, filled and coated with sugar candy syrup flavored with orange blossom
- countries: (none)
- kinds: food, cookie
- has Wikipedia article: en

## DISH Q2386967
- name: Taco al pastor
- description: Mexican dish
- countries: MX
- kinds: meat dish, taco, shawarma
- ingredients: pineapple, pork
- has Wikipedia article: en

## DISH Q2387911
- name: Liver cheese
- description: liver-based product
- countries: (none)
- kinds: cold cut, liver pâté
- ingredients: pork liver

## DISH Q23888567
- name: Curry beef brisket
- other names: {"zh": "咖哩牛腩"}
- countries: (none)
- kinds: beef curry
- has Wikipedia article: zh

## DISH Q23902671
- name: Castagna Roscetta della valle Roveto
- countries: IT
- kinds: chestnut, Abruzzo's traditional food products

## DISH Q2390734
- name: Herheri
- other names: {"nl": "Herheri"}
- countries: SR
- cuisines: Suriname cuisine
- kinds: dish, type of food or dish

## DISH Q23907623
- name: Pate acha
- description: Northern Nigeria meal
- countries: NG
- kinds: soup, dish
- ingredients: Oryza molida, tomato, maize
- has Wikipedia article: en

## DISH Q2391342
- name: Bol renversé
- countries: MU
- kinds: culinary speciality
- ingredients: rice

## DISH Q2391835
- name: Cha-Cha
- description: Belgian candy
- countries: (none)
- kinds: candy
- ingredients: caramel, biscuit, sugar, chocolate

## DISH Q23925811
- name: Boat noodles
- description: Hong Kong cuisine
- countries: (none)
- kinds: noodle, dish

## DISH Q23930009
- name: Krupenik
- description: Russian dish
- countries: RU
- kinds: casserole
- ingredients: buckwheat seed, groat
- has Wikipedia article: en

## DISH Q2393807
- name: Taquito
- description: Mesoamerican food dish
- countries: MX
- kinds: dish
- ingredients: corn tortilla
- has Wikipedia article: en

## DISH Q2394623
- name: Suikerbrood
- description: buurman
- countries: (none)
- kinds: sweet bread, regional product
- ingredients: ginger, cereals' and pseudocereals' flour, yeast dough, baker's yeast, cinnamon, sugar
- has Wikipedia article: en

## DISH Q2395693
- name: Forshmak
- description: Eastern European dish made of salty minced fish
- countries: RU, IL
- cuisines: Russian cuisine, Jewish cuisine, Brandenburg cuisine
- kinds: fish dish, dish
- ingredients: minced meat, herring
- has Wikipedia article: en

## DISH Q2397393
- name: Picarón
- description: Peruvian dessert
- countries: PE
- cuisines: Peruvian cuisine
- kinds: dessert, doughnut, meal
- ingredients: panela, fig, wheat flour, Cucurbita maxima, Sweet potato
- has Wikipedia article: en

## DISH Q2397413
- name: Smen
- other names: {"zh": "腐臭黄油"}
- description: a salted, fermented butter native to North African cuisine as well as a traditional Yemeni dish.
- countries: MA
- kinds: butter
- ingredients: oregano, muslin, table salt, butter
- has Wikipedia article: en

## DISH Q2398830
- name: Salambo
- countries: FR
- kinds: pastry, food

## DISH Q24000322
- name: Gosori liquor
- description: Korean liquor
- countries: KR
- kinds: liquor, cultural heritage

## DISH Q2400452
- name: Teichlmauke
- other names: {"de": "Teichlmauke"}
- countries: (none)
- cuisines: Saxon cuisine
- kinds: dish
- ingredients: mashed potato, broth, beef, sauerkraut

## DISH Q24012081
- name: Pappardelle with wild boar
- countries: (none)
- kinds: pasta dish

## DISH Q2402333
- name: Buddha's delight
- other names: {"zh": "罗汉斋"}
- description: vegetarian dish of China
- countries: CN
- kinds: vegetable dish, dish
- has Wikipedia article: en, zh

## DISH Q24027629
- name: Halal snack pack
- description: Australian halal dish
- countries: AU
- kinds: dish
- ingredients: doner kebab
- has Wikipedia article: en

## DISH Q2403240
- name: Jambonneau
- description: Wikimedia disambiguation page
- countries: (none)
- kinds: Wikimedia disambiguation page, chicken dish, pork dish
- has Wikipedia article: en

## DISH Q24050975
- name: Mlawi
- description: bread
- countries: TN
- kinds: bread

## DISH Q2405114
- name: Eierbal
- description: hard-boiled egg surrounded by breaded meat
- countries: (none)
- kinds: egg dish

## DISH Q24054513
- name: Regina pizza
- countries: (none)
- ingredients: cooked ham, tomato sauce, mushroom, mozzarella

## DISH Q2407727
- name: Nudaj gluteoj en la herbo
- other names: {"eo": "Nudaj gluteoj en la herbo"}
- countries: (none)
- kinds: potato dish

## DISH Q24083230
- name: Rochefort
- description: Trappist cheese made at the Rochefort Abbey
- countries: BE
- kinds: cow's-milk cheese
- ingredients: cow's milk

## DISH Q2408388
- name: Fasole cu cârnaţi
- description: Romanian dish
- countries: RO
- kinds: food
- ingredients: sausage, Phaseolus vulgaris
- has Wikipedia article: en

## DISH Q24084883
- name: Spuma di mandorla
- other names: {"it": "Spuma di mandorla"}
- countries: IT
- kinds: dessert

## DISH Q24090752
- name: Coconut shrimp
- description: dish composed of shrimp and coconut
- countries: (none)
- kinds: shrimp dish
- has Wikipedia article: en

## DISH Q2410707
- name: Cachir
- description: Algerian saussage
- countries: DZ
- kinds: sausage

## DISH Q2410797
- name: Raspatat
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q2414031
- name: Lemper
- description: Indonesia traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, jajan pasar, rice ball
- ingredients: Indonesian bay leaf, garlic, coriander seed, banana leaf, chicken as food, coconut milk, red onion, glutinous rice, Cymbopogon citratus
- has Wikipedia article: en

## DISH Q2415718
- name: Panzanella
- description: salad
- countries: IT
- kinds: bread dish, tomato dish, salad, bread salad
- ingredients: tomato, bread
- has Wikipedia article: en

## DISH Q24190322
- name: Rotisserie chicken
- other names: {"zh": "檸檬香草轉轉烤雞"}
- description: whole seasoned chicken roasted in a rotisserie machine
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q241933
- name: Panch phoron
- description: South Asian spice blend
- countries: BD
- kinds: spice, pentad, spice mix
- ingredients: cumin seed, fennel fruit, mustard seed, Nigella sativa, Trigonella foenum-graecum
- has Wikipedia article: en

## DISH Q24196624
- name: Spice bag
- description: Fast food dish created in Ireland
- countries: IE
- kinds: potato dish, chicken dish
- has Wikipedia article: en

## DISH Q242003
- name: Galette
- other names: {"zh": "脆皮蛋糕"}
- description: food
- countries: FR
- kinds: food, flatbread
- ingredients: flour
- has Wikipedia article: en

## DISH Q24229267
- name: Канун, страва
- other names: {"be": "Канун, страва"}
- countries: (none)
- kinds: dish

## DISH Q2423291
- name: Hot snack
- description: spicy meat snack from Netherlands
- countries: (none)
- kinds: snack, spice, spring roll, meat dish

## DISH Q24238468
- name: Stoks
- other names: {"ltg": "Stoks"}
- countries: (none)
- kinds: dish

## DISH Q2424605
- name: Croquignoles
- description: French dessert
- countries: (none)
- kinds: dish, dessert

## DISH Q24249983
- name: Bola de Berlim
- description: Portuguese variant of the Berliner
- countries: DE, PT
- kinds: Berliner
- ingredients: custard

## DISH Q2425418
- name: Fico Bianco del Cilento PDO
- other names: {"zh": "Fico Bianco del Cilento DOP"}
- description: Italian PDO fruit, vegetable or cereal product
- countries: IT
- kinds: fig, agricultural product
- ingredients: Drought fig

## DISH Q24257106
- name: Tauge goreng
- description: Indonesian savoury vegetarian dish
- countries: ID
- kinds: noodle dish
- ingredients: soy sauce, noodle, tofu, chili pepper, Allium tuberosum, shallot, garlic, Tauco, mung bean sprout, peanut, lontong, scallion
- has Wikipedia article: en

## DISH Q2425845
- name: Sate kambing
- description: Indonesian goat meat dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, goat meat dish
- ingredients: garlic, goat meat, soy sauce, table salt
- has Wikipedia article: en

## DISH Q2427282
- name: Spekkoek
- other names: {"zh": "印尼千层糕"}
- description: Indonesian layered cake originating from Java island
- countries: ID
- kinds: layer cake
- ingredients: milk powder, egg yolk, butter, vanilla, sugar
- has Wikipedia article: en, zh

## DISH Q2427598
- name: Beguni
- description: Bengal region brinjal dish
- countries: (none)
- kinds: eggplant dish
- ingredients: eggplant
- has Wikipedia article: en

## DISH Q24285554
- name: Roast beef sandwich
- description: sandwich made from roast beef
- countries: (none)
- kinds: beef dish, meat sandwich
- ingredients: roast beef, bread
- has Wikipedia article: en

## DISH Q2428787
- name: Ayam Taliwang
- description: Indonesian roasted chicken dish from Lombok
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, meal, human food, type of food or dish, grilled chicken
- ingredients: garlic, shrimp paste, chicken as food, lime, table salt
- has Wikipedia article: en

## DISH Q2430685
- name: Bird's Custard
- other names: {"zh": "吉士粉"}
- description: brand of imitation custard powder
- countries: GB
- kinds: imitation custard
- has Wikipedia article: en, zh

## DISH Q24309184
- name: Zwiebelfleisch
- other names: {"de": "Zwiebelfleisch"}
- countries: (none)
- kinds: dish

## DISH Q2431975
- name: Yakiniku
- other names: {"zh": "日式燒肉"}
- description: Japanese term meaning grilled meat
- countries: JP
- kinds: dish, meat dish, cuisine, yakimono
- has Wikipedia article: en, zh

## DISH Q24346104
- name: Majoranfleisch
- other names: {"de": "Majoranfleisch"}
- countries: (none)
- kinds: dish

## DISH Q2436547
- name: Cơm rượu
- other names: {"zh": "酒饭"}
- description: Traditional Vietnamese dessert made from glutinous rice
- countries: VN
- kinds: pudding
- ingredients: rice wine, glutinous rice, table salt, sugar
- has Wikipedia article: en, zh

## DISH Q2436674
- name: Bath Oliver
- description: a hard, dry biscuit or cracker
- countries: (none)
- kinds: food, cookie, biscuit
- ingredients: flour
- has Wikipedia article: en

## DISH Q2440538
- name: Tomaten-Concassée
- other names: {"de": "Tomaten-Concassée"}
- description: dish
- countries: (none)
- kinds: dish

## DISH Q244495
- name: Zwetschkenknödel
- description: Plum dumplings
- countries: AT, HU, RO, CZ
- cuisines: Austrian cuisine, Hungarian cuisine, Romanian cuisine, Czech cuisine
- kinds: dish, Erdäpfelknödel

## DISH Q244496
- name: Zwetschkenröster
- description: Sweet dish in the traditional Austro-Bohemian cuisine
- countries: (none)
- kinds: sweet dish

## DISH Q2444993
- name: Çiğ köfte
- description: raw meat or vegan bulgur dish from Turkish cuisine
- countries: TR
- cuisines: Turkish cuisine, Şanlıurfa cuisine
- kinds: kofta, type of food or dish
- ingredients: bulgur, parsley, garlic, Urfa biber, onion, veal, lamb meat
- has Wikipedia article: en

## DISH Q2445410
- name: Hyderabadi biryani
- description: form of biryani, from Hyderabad, India
- countries: (none)
- kinds: dish, biryani
- has Wikipedia article: en

## DISH Q244589
- name: Zwiebeldinnele
- description: Specialty of the Swabian-Alemannic kitchen
- countries: (none)
- kinds: dish

## DISH Q244609
- name: Zwiebelrostbraten
- countries: (none)
- kinds: dish

## DISH Q24460908
- name: Fig cake
- description: cake made with figs
- countries: (none)
- kinds: food ingredient, pastry
- ingredients: Ficus carica
- has Wikipedia article: en

## DISH Q244611
- name: Onion ring
- other names: {"zh": "洋葱圈"}
- description: deep fried onion slices dipped in batter
- countries: US
- kinds: vegetable dish, fast food, snack
- ingredients: onion, batter
- has Wikipedia article: en, zh

## DISH Q2446322
- name: Knish
- other names: {"zh": "牛肉薯泥饼"}
- description: Ashkenazi Jewish baked or fried snack food consisting of a filling covered with dough
- countries: BY, UA
- kinds: bread, potato dish
- ingredients: dough, mashed potato
- has Wikipedia article: en

## DISH Q24471421
- name: Neujahrsblattlan
- other names: {"de": "Neujahrsblattlan"}
- countries: (none)
- kinds: dish

## DISH Q2449874
- name: Sultsina
- description: karelian pastry
- countries: FI, RU
- kinds: pastry, traditional food
- has Wikipedia article: en

## DISH Q2450914
- name: Chicken 65
- description: spicy, deep-fried chicken dish from India, usually served with onion and lemon garnish
- countries: IN
- kinds: fried chicken, chicken dish
- ingredients: chicken
- has Wikipedia article: en

## DISH Q2451334
- name: White soup
- description: soup of chicken bouillon, well known in the Netherlands, originating from France
- countries: (none)
- kinds: food, soup

## DISH Q2451463
- name: Chole bhature
- description: dish notable in Indian and Pakistani cuisine, consisting of poori bread with chana masala. it is considered as heavy lunch or dinner meal option.
- countries: IN
- kinds: dish
- ingredients: chickpea
- has Wikipedia article: en

## DISH Q24517
- name: Alfeñique
- description: figure made from molded sugar paste
- countries: (none)
- kinds: meal, confectionery
- has Wikipedia article: en

## DISH Q2452555
- name: Espagnole sauce
- other names: {"zh": "棕醬 (醬料)"}
- description: classic French sauce
- countries: FR
- cuisines: French cuisine
- kinds: mother sauce, sauce
- ingredients: stock, roux
- has Wikipedia article: en, zh

## DISH Q2456855
- name: Idiyappam
- description: Indian rice noodle dish
- countries: IN
- kinds: food, human food, type of food or dish, breakfast
- ingredients: Oryza molida, flour, palm sugar, rice flour, coconut milk, egg as food, table salt, water
- has Wikipedia article: en

## DISH Q24568658
- name: Fried cheese
- description: cheese dish fried in oil
- countries: (none)
- kinds: dish
- ingredients: cheese
- has Wikipedia article: en

## DISH Q2457455
- name: Sayur asem
- description: Indonesian vegetable soup
- countries: ID
- kinds: dish, food, soup, vegetable soup
- ingredients: asparagus bean, brown sugar, peanut, bay leaf, shrimp paste, Alpinia galanga, Sechium edule, Allium ascalonicum, beef, Allium sativum, Zea mays Saccharata Group, vegetable, water
- has Wikipedia article: en

## DISH Q2457672
- name: Nonnevot
- description: sweet and Salty Limburgian pastry
- countries: (none)
- kinds: doughnut, pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q2461000
- name: Apple turnover
- countries: (none)
- kinds: pastry, turnover
- ingredients: apple

## DISH Q2461918
- name: Pamonha
- description: traditional Brazilian food
- countries: BR
- kinds: dish, stuffed pasta
- has Wikipedia article: en

## DISH Q2462111
- name: Zwieback
- description: yeast bread roll
- countries: (none)
- kinds: food, bread roll
- ingredients: dough
- has Wikipedia article: en

## DISH Q24636822
- name: Allgäuer Sennalpkäse
- description: cheese from the Allgäu region of Germany
- countries: DE
- kinds: Granular cheese, raw-milk cheese, Alpkäse, cheese

## DISH Q2463769
- name: Mornay sauce
- other names: {"zh": "乾酪白汁"}
- description: type of béchamel sauce including cheese
- countries: FR
- kinds: sauce, béchamel, condiment, cheese sauce
- ingredients: Gruyère, béchamel, Parmesan
- has Wikipedia article: en, zh

## DISH Q2464350
- name: Öçpoçmaq
- other names: {"zh": "三角馅饼"}
- description: Tatar and Bashkir national dish
- countries: (none)
- cuisines: Tatarstan cuisine, Bashkir cuisine
- kinds: food, pie
- has Wikipedia article: en

## DISH Q2468860
- name: Chè trôi nước
- other names: {"zh": "越南湯圓"}
- description: Vietnamese dessert
- countries: VN
- kinds: dish, chè
- ingredients: bánh chay, bánh trôi
- has Wikipedia article: en

## DISH Q2468930
- name: Banket
- description: almond filled pastry
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q24711750
- name: Warthaer Pfefferkuchen
- other names: {"de": "Warthaer Pfefferkuchen"}
- countries: (none)
- kinds: pastry, dish

## DISH Q2471959
- name: Mojama
- description: Andalusian cured tuna delicacy
- countries: ES
- kinds: delicacy
- ingredients: Thunnini
- has Wikipedia article: en

## DISH Q24732220
- name: Soba manjū
- countries: (none)
- kinds: confectionery
- ingredients: buckwheat flour

## DISH Q24735647
- name: Sepik
- description: Estonian wheat bread
- countries: EE
- kinds: brown bread
- has Wikipedia article: en

## DISH Q2476143
- name: Zeeuwse bolus
- description: sweet pastry
- countries: (none)
- kinds: pastry, viennoiserie
- has Wikipedia article: en

## DISH Q2476688
- name: Tanghulu
- other names: {"zh": "冰糖葫芦"}
- description: skewers of glazed fruit (mainly hawthorn) mainly sold on the streets of Beijing and Tianjin
- countries: CN
- kinds: candied fruit, food
- ingredients: fruit
- has Wikipedia article: en, zh

## DISH Q2478397
- name: Poppelse janhagel
- other names: {"nl": "Poppelse janhagel"}
- countries: (none)
- kinds: food, cookie

## DISH Q2478703
- name: Khichri
- other names: {"zh": "扁豆燉飯"}
- description: dish from the South Asia made from rice and lentils (dal)
- countries: (none)
- kinds: dish
- ingredients: lentil, rice
- has Wikipedia article: en

## DISH Q2479287
- name: Potato babka
- other names: {"zh": "马铃薯巴布卡"}
- description: savoury Belarusian and Polish dish made from potato
- countries: BY, PL
- kinds: potato dish, pie
- ingredients: potato
- has Wikipedia article: en, zh

## DISH Q2481743
- name: Honmei choco
- other names: {"zh": "本命巧克力"}
- countries: JP
- kinds: chocolate, communication
- ingredients: chocolate
- has Wikipedia article: en, zh

## DISH Q2481820
- name: Liers vlaaike
- description: Belgian dessert
- countries: (none)
- kinds: pastry

## DISH Q2482440
- name: Fit-fit
- other names: {"zh": "非非 (食物)"}
- description: Ethiopian food
- countries: ET
- kinds: food, bread
- ingredients: niter kibbeh
- has Wikipedia article: en, zh

## DISH Q2482567
- name: Rumboon
- other names: {"nl": "Rumboon"}
- countries: (none)
- kinds: candy

## DISH Q2482979
- name: Pom
- description: oven dish
- countries: SR
- kinds: dish
- ingredients: chicken as food, Xanthosoma sagittifolium, tomato
- has Wikipedia article: en

## DISH Q24835653
- name: Kiâm-kong-piánn
- other names: {"zh": "鹹光餅"}
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q24839104
- name: Apple Bread
- other names: {"zh": "蘋果麵包"}
- description: Taiwanese aromatic bread
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: bread, dish
- ingredients: wheat germ, egg as food
- has Wikipedia article: en, zh

## DISH Q24841569
- name: Sió-kńg-á
- other names: {"zh": "小卷"}
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q248507
- name: Zürcher Ratsherrentopf
- other names: {"de": "Zürcher Ratsherrentopf"}
- countries: (none)
- kinds: meat dish

## DISH Q24855922
- name: テグタン
- other names: {"ja": "テグタン"}
- countries: (none)
- kinds: guk

## DISH Q24855923
- name: 다슬기국
- other names: {"ko": "다슬기국"}
- countries: (none)
- kinds: guk

## DISH Q24862829
- name: Mabo harusame
- countries: (none)
- kinds: dish
- ingredients: cellophane noodles

## DISH Q24863110
- name: Mizumama
- countries: (none)
- kinds: Japanese rice dish

## DISH Q24864708
- name: スア・ラオ
- other names: {"ja": "スア・ラオ"}
- countries: LA
- kinds: fermentation starter

## DISH Q24865307
- name: トゥック・トレイ
- other names: {"ja": "トゥック・トレイ"}
- countries: KH
- kinds: fish sauce

## DISH Q24867063
- name: Fugashi
- countries: (none)
- kinds: dagashi
- ingredients: fu

## DISH Q24869486
- name: Gesoten
- description: tempura of squid arms
- countries: JP
- kinds: tempura
- ingredients: squid as food

## DISH Q24869782
- name: 文旦漬け
- other names: {"ja": "文旦漬け"}
- countries: (none)
- kinds: candied fruit

## DISH Q24869886
- name: Saga ramen
- countries: (none)
- kinds: tonkotsu ramen

## DISH Q24870019
- name: シューアイス
- other names: {"ja": "シューアイス"}
- countries: (none)
- kinds: ice cream, cream puff

## DISH Q2487044
- name: Duimpje
- other names: {"nl": "duimpje"}
- countries: (none)
- kinds: cookie, type of food or dish

## DISH Q24870497
- name: 南部はっと
- other names: {"ja": "南部はっと"}
- countries: (none)
- kinds: nabemono, noodle dish

## DISH Q24870653
- name: ポテチパン
- other names: {"ja": "ポテチパン"}
- countries: (none)
- kinds: dish

## DISH Q24870799
- name: Ōmuta ramen
- countries: (none)
- kinds: tonkotsu ramen

## DISH Q24870943
- name: Takaoka Green Ramen
- countries: (none)
- kinds: tonkotsu ramen

## DISH Q24871329
- name: へらへら餅
- other names: {"ja": "へらへら餅"}
- countries: (none)
- kinds: mochi

## DISH Q24871575
- name: Kingyo-meshi
- countries: JP
- kinds: takikomi gohan

## DISH Q2487163
- name: Pig cake
- other names: {"zh": "豬仔餅"}
- countries: CN
- kinds: pastry
- has Wikipedia article: zh

## DISH Q24876362
- name: Honejiru
- other names: {"zh": "骨汁"}
- countries: (none)
- kinds: shirumono
- ingredients: pork bones
- has Wikipedia article: zh

## DISH Q24882667
- name: Sooji toast
- description: Indian snack food
- countries: (none)
- kinds: dish
- ingredients: semolina
- has Wikipedia article: en

## DISH Q24885167
- name: Buttermilk curry
- description: curry made with buttermilk and vegitables
- countries: IN
- kinds: curry, side dish
- has Wikipedia article: en

## DISH Q24885642
- name: Nam pla
- description: Thai fish sauce
- countries: TH
- kinds: fish sauce, condiment
- has Wikipedia article: en

## DISH Q24886722
- name: Fu
- other names: {"zh": "麸"}
- description: food made of wheat gluten from Japan
- countries: JP
- kinds: processed food, seitan
- ingredients: gluten

## DISH Q2488715
- name: Shiro
- description: type of stew
- countries: ER, ET
- kinds: stew
- ingredients: garlic, chickpea, onion, berbere
- has Wikipedia article: en

## DISH Q24887483
- name: 白醤油
- other names: {"ja": "白醤油"}
- countries: (none)
- kinds: shōyu

## DISH Q24889832
- name: Nibōtō
- other names: {"zh": "煮餺飥"}
- countries: (none)
- kinds: nabemono, hōtō, nikomi udon

## DISH Q24890727
- name: Raindrop cake
- other names: {"zh": "水信玄餅"}
- description: gelatinous dessert
- countries: JP
- kinds: confectionery
- has Wikipedia article: en, zh

## DISH Q24893927
- name: Nikomi udon
- countries: (none)
- kinds: udon, stew, noodle soup

## DISH Q24894820
- name: Garlic rice
- countries: JP
- kinds: rice dish
- ingredients: garlic, peppercorn, table salt, rice

## DISH Q24898032
- name: Mameita
- countries: (none)
- kinds: wagashi
- ingredients: bean

## DISH Q24898385
- name: 越後味噌
- other names: {"ja": "越後味噌"}
- countries: (none)
- kinds: miso

## DISH Q24898518
- name: Shimadōfu
- description: Type of tofu from Okinawa
- countries: (none)
- kinds: food, tofu
- has Wikipedia article: en

## DISH Q24898830
- name: Nuka nishin
- countries: (none)
- kinds: nukazuke, fish dish
- ingredients: herring as food

## DISH Q24899026
- name: ストレートスープ
- other names: {"ja": "ストレートスープ"}
- countries: (none)
- kinds: soup

## DISH Q24899492
- name: Udon-suki
- countries: (none)
- kinds: Yosenabe, nikomi udon

## DISH Q24902716
- name: Saiki ramen
- countries: (none)
- kinds: tonkotsu ramen

## DISH Q24906665
- name: Bhendi fry
- description: Stir fried okra dish
- countries: (none)
- kinds: vegetable dish, dish
- ingredients: okra
- has Wikipedia article: en

## DISH Q24906668
- name: Cucumber raita
- description: Indian condiment
- countries: IN
- kinds: dahi, condiment
- ingredients: dahi, cucumber
- has Wikipedia article: en

## DISH Q24906818
- name: Stir-fried water spinach
- other names: {"zh": "炒空心菜"}
- description: Asian vegetable dish
- countries: (none)
- kinds: vegetable dish
- ingredients: water spinach
- has Wikipedia article: en

## DISH Q24911299
- name: Matzah pizza
- description: pizza made from matzah
- countries: (none)
- kinds: type of food or dish
- ingredients: yellow cheese, tomato paste, matzah
- has Wikipedia article: en

## DISH Q249114
- name: Salsa (food)
- other names: {"zh": "萨尔萨酱"}
- description: sauce
- countries: MX
- kinds: sauce, hot sauce
- ingredients: chili pepper, tomato, onion
- has Wikipedia article: en, zh

## DISH Q2491452
- name: Dalle terre liberate dalla mafia
- countries: (none)
- kinds: pasta

## DISH Q249169
- name: Zōni
- other names: {"zh": "杂煮"}
- description: Japanese dish
- countries: JP
- kinds: type of food or dish, shirumono, New Year's food
- ingredients: mochi, miso, soy sauce
- has Wikipedia article: en, zh

## DISH Q24929136
- name: Jambon de Lacaune
- description: brand of ham
- countries: (none)
- kinds: ham

## DISH Q24929320
- name: Tarte à la farlouche
- other names: {"fr": "Tarte à la farlouche"}
- countries: (none)
- kinds: sweet pie

## DISH Q24930064
- name: Subric
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q249310
- name: Comté cheese
- other names: {"zh": "孔泰奶酪"}
- description: French cheese
- countries: FR
- kinds: cheese, French cheese, raw-milk cheese, cow's-milk cheese, industrial cheese, pressed cooked cheese
- ingredients: cow's milk, raw milk
- has Wikipedia article: en, zh

## DISH Q24931479
- name: Masala puri
- description: Indian snack from Karnataka
- countries: IN
- kinds: chaat, snack
- ingredients: puffed rice, spice
- has Wikipedia article: en

## DISH Q24933148
- name: Cubeletto
- other names: {"it": "Cubeletto"}
- countries: IT
- kinds: dessert

## DISH Q24937093
- name: Torciglione
- other names: {"it": "Torciglione"}
- countries: IT
- kinds: dessert

## DISH Q24937568
- name: Pan candeal
- description: Spanish white bread
- countries: (none)
- kinds: bread, white bread
- ingredients: wheat flour, yeast, table salt, water
- has Wikipedia article: en

## DISH Q24938057
- name: San Antón rolls
- description: Spanish dessert
- countries: ES
- cuisines: cuisine of Cartagena, Spain
- kinds: dessert

## DISH Q24938129
- name: Torcolo di San Costanzo
- other names: {"it": "Torcolo di San Costanzo"}
- countries: IT
- kinds: dessert

## DISH Q24940091
- name: Mostaccino
- description: Spicy biscuit made in Crema
- countries: IT
- kinds: pastry
- ingredients: cumin seed, clove, wheat flour, mace, star anise, cocoa powder, egg as food, nutmeg, black pepper, butter, cinnamon, sugar
- has Wikipedia article: en

## DISH Q24940816
- name: Pasta e ceci
- description: Italian pasta dish
- countries: IT
- kinds: soup, pasta dish, chickpea dish
- ingredients: chickpea, pasta
- has Wikipedia article: en

## DISH Q24940817
- name: Spaghetti allo scoglio
- other names: {"es": "Spaghetti allo scoglio"}
- countries: IT
- kinds: seafood dish, pasta dish

## DISH Q24941443
- name: Spongada
- other names: {"it": "Spongada"}
- countries: (none)
- kinds: focaccia

## DISH Q24942317
- name: Graffe napoletane
- description: deep-fried pastry
- countries: IT
- kinds: pastry
- has Wikipedia article: en

## DISH Q24942522
- name: Biscotti salati all'anice
- other names: {"fr": "biscotti salati all'anice"}
- countries: IT
- kinds: dessert

## DISH Q24943843
- name: Afghani burger
- other names: {"zh": "阿富汗捲餅"}
- description: Afghan food
- countries: AF
- kinds: sandwich
- ingredients: Afghan bread
- has Wikipedia article: en, zh

## DISH Q24944177
- name: Karp zatorski
- other names: {"pl": "Karp zatorski"}
- countries: (none)
- kinds: dish

## DISH Q24944198
- name: Katong Laksa
- description: variant of laksa lemak
- countries: SG
- kinds: laksa, food
- has Wikipedia article: en

## DISH Q24944426
- name: Vegetarian bee hoon
- description: Singaporean noodle dish
- countries: SG
- kinds: dish
- ingredients: rice vermicelli
- has Wikipedia article: en

## DISH Q24944542
- name: Teochew porridge
- description: Teochow dish popular in Singapore and Chaozhou
- countries: MY
- kinds: dish
- has Wikipedia article: en

## DISH Q24944691
- name: Rojak bandung
- description: Javanese type of salad originating from Bandung in West Java
- countries: ID
- kinds: rojak
- has Wikipedia article: en

## DISH Q24944863
- name: Crab been hoon
- description: Singaporean rice vermicelli dish
- countries: SG
- kinds: crab dish
- has Wikipedia article: en

## DISH Q24945409
- name: Hainanese curry rice
- description: Singaporean curry rice and chicken dish
- countries: SG
- kinds: rice dish
- ingredients: curry
- has Wikipedia article: en

## DISH Q24945530
- name: Har cheong gai burger
- countries: SG
- kinds: sandwich, chicken dish
- has Wikipedia article: en

## DISH Q24945547
- name: Daab Chingri
- description: Bengali prawn curry, cooked and served in green coconut
- countries: (none)
- kinds: shrimp dish, Indian curry
- ingredients: prawn
- has Wikipedia article: en

## DISH Q24945597
- name: Mahim halwa
- description: Semolina halva
- countries: IN
- kinds: confectionery
- ingredients: ghee, halva, Cashew, sugar
- has Wikipedia article: en

## DISH Q24945601
- name: Lonavala chikki
- description: Chikki originating from Lonavala
- countries: IN
- kinds: sweet dish, chikki, snack
- ingredients: jaggery
- has Wikipedia article: en

## DISH Q2494643
- name: Balep korkun
- description: Tibetan flatbread
- countries: (none)
- kinds: food, flatbread
- ingredients: tsampa
- has Wikipedia article: en

## DISH Q24946983
- name: Akhuni
- description: fermented product of the North Eastern Region of India
- countries: TH
- cuisines: Thai cuisine, Naga cuisine, Kachin cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q24947059
- name: Sohbat
- description: Pakistani stew dish
- countries: PK
- kinds: dish
- has Wikipedia article: en

## DISH Q24948875
- name: Bamboo chicken
- description: South Asian chicken curry prepared by stuffing chicken in bamboo segments
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q24950338
- name: Dhooska
- description: Snack from Jharkhand, India
- countries: IN
- kinds: deep-fried food, human food
- ingredients: black gram, split chickpea, rice
- has Wikipedia article: en

## DISH Q24950882
- name: Jhalmuri
- description: Bengali snack
- countries: IN
- kinds: chaat, snack
- ingredients: puffed rice
- has Wikipedia article: en

## DISH Q24951925
- name: Batik cake
- other names: {"zh": "蜡染蛋糕"}
- description: Typical malaysian cake
- countries: MY
- kinds: Hedgehog slice
- has Wikipedia article: en, zh

## DISH Q2495505
- name: Macaroni casserole
- description: dish of cooked macaroni and a mixture of egg and milk with additional ingredients like meats, vegetables or fish
- countries: (none)
- kinds: dish
- ingredients: macaroni
- has Wikipedia article: en

## DISH Q24955416
- name: Bánh dẻo
- description: traditional food during the Tết Trung Thu
- countries: VN
- kinds: mooncake

## DISH Q24957229
- name: Bánh nướng
- countries: VN
- kinds: mooncake

## DISH Q2495784
- name: Frog cake
- other names: {"zh": "青蛙蛋糕"}
- description: type of cake from Australia
- countries: AU
- kinds: cake, food
- ingredients: sponge cake
- has Wikipedia article: en, zh

## DISH Q24960939
- name: Marquesote
- description: Mexican bread
- countries: MX
- kinds: bread
- has Wikipedia article: en

## DISH Q249873
- name: Crottin de Chavignol
- other names: {"zh": "沙维尼奥勒圆形山羊奶酪"}
- description: French cheese
- countries: FR
- kinds: French cheese, goat cheese, raw-milk cheese
- ingredients: milk, goat milk
- has Wikipedia article: en, zh

## DISH Q24993896
- name: Queen Elizabeth cake
- other names: {"zh": "伊丽莎白女王蛋糕"}
- description: cake with coconut topping
- countries: (none)
- kinds: cake
- ingredients: coconut
- has Wikipedia article: en

## DISH Q24993926
- name: Battalia pie
- description: large game pie
- countries: GB
- kinds: dessert, game pie
- has Wikipedia article: en

## DISH Q24993955
- name: Scottish Morning Roll
- description: airy, chewy bread roll popular in Scotland
- countries: (none)
- kinds: bread roll
- has Wikipedia article: en

## DISH Q25000110
- name: Aplets & Cotlets
- description: type de confection
- countries: US
- kinds: confectionery
- ingredients: apple
- has Wikipedia article: en

## DISH Q2500197
- name: Dovga
- description: national meal of Azerbaijani cuisine
- countries: AZ
- cuisines: Cuisine of Uzbekistan, Azerbaijani cuisine
- kinds: fermented milk product, cold sweet soup
- ingredients: culinary herb, spinach, katyk, yogurt
- has Wikipedia article: en

## DISH Q25004038
- name: Italian sandwich
- description: Italian-American submarine sandwich
- countries: (none)
- kinds: submarine sandwich
- has Wikipedia article: en

## DISH Q25004448
- name: Chiffon pie
- description: type of dessert
- countries: US
- kinds: sweet pie
- has Wikipedia article: en

## DISH Q25004455
- name: Sonoran hot dog
- description: Mexican-style hot dog
- countries: MX
- kinds: hot dog
- ingredients: bolillo, bacon
- has Wikipedia article: en

## DISH Q25004703
- name: Lady Baltimore cake
- description: Dessert
- countries: US
- cuisines: cuisine of the United States
- kinds: cake
- ingredients: sponge cake
- has Wikipedia article: en

## DISH Q25004801
- name: Southern tomato pie
- description: type of pie from the Southern United States
- countries: (none)
- kinds: pie, tomato dish
- has Wikipedia article: en

## DISH Q25004816
- name: Cornell bread
- countries: US
- kinds: bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q25005338
- name: Peanut pie
- description: pie originating from the southern United States
- countries: US
- kinds: dessert, pie
- ingredients: Arachis
- has Wikipedia article: en

## DISH Q25005351
- name: Walnut pie
- other names: {"zh": "核桃派"}
- description: pie prepared with walnuts
- countries: (none)
- kinds: pie
- ingredients: walnut
- has Wikipedia article: en

## DISH Q25005355
- name: Chestnut pie
- description: pie prepared with chestnuts as a primary ingredient
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q25006844
- name: Spaghetti sandwich
- description: type of sandwich
- countries: (none)
- kinds: sandwich
- has Wikipedia article: en

## DISH Q2500956
- name: Urojo
- description: dish in Tanzanian cuisine
- countries: (none)
- kinds: soup, dish
- ingredients: turmeric, potato, flour, mango

## DISH Q2501196
- name: Shortbread (general)
- description: pastry made of one part white sugar, two parts butter and three to four parts plain wheat flour
- countries: (none)
- kinds: pastry

## DISH Q250170
- name: Poğaça
- description: Ottoman pastry that is known under similar names all around the Southeast and Central Europe
- countries: (none)
- kinds: food, bread
- has Wikipedia article: en

## DISH Q25019736
- name: Balıq südü
- other names: {"az": "Balıq südü"}
- countries: CL
- kinds: dish
- ingredients: fish meal, water

## DISH Q250271
- name: Pimentón de la Vera
- description: Paprika produced in Spain, of controlled origin from La Vera, a historic region in the northeast of the province of Cáceres in Extremadura
- countries: ES
- kinds: spice, paprika

## DISH Q25038426
- name: Chocolate pizza
- other names: {"zh": "巧克力披薩"}
- description: pizza prepared using chocolate
- countries: US
- kinds: dish, dessert, chocolate dish
- ingredients: chocolate
- has Wikipedia article: en, zh

## DISH Q25039790
- name: Spice cake
- other names: {"zh": "香料蛋糕"}
- description: cake flavored with a mixture of spices
- countries: (none)
- kinds: cake
- ingredients: spice
- has Wikipedia article: en

## DISH Q25040576
- name: Gnudi
- description: pasta dish
- countries: IT
- kinds: stuffed pasta
- ingredients: ricotta
- has Wikipedia article: en

## DISH Q25041417
- name: Tuwo masara (corn meal)
- description: meal commonly eaten in northern Nigeria, also known as hausa fufu. Tuwo masara is made from grounded corn
- countries: NG
- kinds: dish, human food, swallow
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q25041585
- name: Tomato jam
- description: jam made from tomatos
- countries: (none)
- kinds: fruit jam
- has Wikipedia article: en

## DISH Q25041852
- name: Bogobe jwa logala
- description: sorghum porridge boiled in milk
- countries: (none)
- kinds: food, bogobe
- ingredients: sorghum grain, milk
- has Wikipedia article: en

## DISH Q25041872
- name: Khanom bua loi
- description: Thai dessert
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q25042582
- name: Paximathia
- description: type of rusk eaten in Greece
- countries: GR
- kinds: human food, rusk
- has Wikipedia article: en

## DISH Q25042586
- name: Carrot bread
- description: Bread featuring carrots
- countries: (none)
- kinds: bread
- ingredients: flour, sugar, carrot
- has Wikipedia article: en

## DISH Q25042801
- name: Kongnamul-bulgogi
- description: Korean dish
- countries: (none)
- kinds: bulgogi
- ingredients: soybean sprout
- has Wikipedia article: en

## DISH Q25043157
- name: Kuku Paka
- description: African chicken dish
- countries: IN
- kinds: chicken dish
- ingredients: coconut milk, spice
- has Wikipedia article: en

## DISH Q25043179
- name: Hoagie roll
- description: long flat roll used to prepare hoagie sandwiches
- countries: (none)
- kinds: bread roll
- has Wikipedia article: en

## DISH Q25043234
- name: Miyar kuka
- description: type of soup made from powdered baobab leaves; popular in Nigeria and Ghana
- countries: NG
- kinds: dish, human food, soup
- ingredients: baobab leaf, palm oil

## DISH Q25043246
- name: Efo riro
- description: rich Nigeria vegetable stew that is native to the yorubas of the Western Nigeria
- countries: NG
- kinds: vegetable, dish, human food
- ingredients: pungency, palm oil, Capsicum, vegetable
- has Wikipedia article: en

## DISH Q25043326
- name: Sirabij
- description: Iranian egg dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q25043652
- name: Nocciolini di Canzo
- description: Italian cookies
- countries: IT
- kinds: cookie
- ingredients: hazelnut
- has Wikipedia article: en

## DISH Q25044050
- name: Toast point
- other names: {"zh": "吐司點"}
- description: Toasted bread triangle
- countries: (none)
- kinds: toast
- has Wikipedia article: en

## DISH Q2504513
- name: Namagashi
- other names: {"zh": "生糕點"}
- description: type of wagashi
- countries: JP
- kinds: wagashi
- has Wikipedia article: en, zh

## DISH Q25045172
- name: Kimchi burger
- description: hamburger that includes kimchi in its preparation
- countries: (none)
- kinds: hamburger
- ingredients: Kimchi
- has Wikipedia article: en

## DISH Q25045178
- name: Pa-kimchi
- description: Variant of the Korean dish kimchi
- countries: (none)
- kinds: Kimchi
- ingredients: Allium × proliferum
- has Wikipedia article: en

## DISH Q25047421
- name: Casarecce
- description: type of pasta that has a free shape
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q25047514
- name: Goat water
- other names: {"zh": "加勒比式肉骨湯"}
- description: Montserrat stew
- countries: MS
- kinds: stew
- ingredients: goat meat
- has Wikipedia article: en

## DISH Q25051984
- name: Kanom Piakpoon
- other names: {"zh": "泰式椰香香蘭糕"}
- description: Thai dessert
- countries: (none)
- kinds: sweet dish
- has Wikipedia article: en

## DISH Q2505233
- name: Egg foo young
- other names: {"zh": "芙蓉蛋"}
- description: Chinese-Indonesian egg dish
- countries: CN
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q25052449
- name: Khao piak sen
- description: southeast Asian noodle soup originating from Laos
- countries: LA
- kinds: noodle soup
- has Wikipedia article: en

## DISH Q25052547
- name: Doko-doko
- description: Sulawesi traditional rice-based cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: traditional food, type of food or dish, snack, human food, kue
- ingredients: coconut, coconut milk, vanilla, table salt, banana, rice flour, glutinous rice flour
- has Wikipedia article: en

## DISH Q25052639
- name: Kue satu
- description: Indonesian traditional cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, snack, human food, type of food or dish
- ingredients: Vigna radiata, vanilla, sugar, milk
- has Wikipedia article: en

## DISH Q25052735
- name: Pinipig
- description: Flattened rice ingredient in the Philippines
- countries: PH
- kinds: dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q25055558
- name: Barbine
- description: type of pasta
- countries: IT
- kinds: type of pasta, pasta
- has Wikipedia article: en

## DISH Q25055787
- name: Ttongppang
- description: South Korean feces-shaped bread
- countries: KR
- cuisines: South Korean cuisine
- kinds: bread
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q25055799
- name: Afghan salad
- other names: {"zh": "阿富汗沙拉"}
- description: Afghan cuisine
- countries: AF
- kinds: dish, salad
- ingredients: lemon juice, Allium, Coriandrum sativum, tomato, Cucumis sativus, carrot
- has Wikipedia article: en, zh

## DISH Q25055866
- name: Karydopita
- description: Greek dessert cake
- countries: GR
- cuisines: Greek cuisine
- kinds: cake
- ingredients: walnut
- has Wikipedia article: en

## DISH Q25055867
- name: Kolokythopita
- description: Greek zucchini pie
- countries: GR
- kinds: pie
- ingredients: phyllo, zucchini
- has Wikipedia article: en

## DISH Q25056560
- name: Brazil nut cake
- description: popular South American confection
- countries: BR
- kinds: nut cake
- ingredients: baking powder, sugar, milk, egg as food, Bertholletia excelsa, flour, butter
- has Wikipedia article: en

## DISH Q25056748
- name: Chupe Andino
- description: stews and soups from the Andes region
- countries: (none)
- kinds: soup, stew
- has Wikipedia article: en

## DISH Q25056844
- name: Nsala soup
- description: Nigerian soup popular among the Igbo people and usually prepared for special guests
- countries: NG
- kinds: dish, nutrition, human food
- ingredients: Dawadawa, yam, crayfish, chicken as food, Siluriformes, fish
- has Wikipedia article: en

## DISH Q25058095
- name: Osam bulgogi
- description: Korean dish made from squid and pork belly
- countries: (none)
- kinds: pork dish, squid dish
- ingredients: squid as food
- has Wikipedia article: en

## DISH Q25058467
- name: Bizcocho Dominicano
- description: cake popular in the Dominican Republic
- countries: DO
- kinds: cake
- has Wikipedia article: en

## DISH Q25060149
- name: Pollo al disco
- description: Argentine chicken dish
- countries: AR
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q25060346
- name: Misérable cake
- other names: {"zh": "悲慘蛋糕"}
- description: traditional Belgian almond sponge cake
- countries: BE
- kinds: cake
- has Wikipedia article: en, zh

## DISH Q25064159
- name: Apfelküchle
- description: German pastry, battered and fried apple slices
- countries: AT, DE
- kinds: dessert
- ingredients: apple
- has Wikipedia article: en

## DISH Q25066353
- name: Indori Poha
- description: Indian Food dish made from flattened rice
- countries: IN
- kinds: dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q25067130
- name: Pizzetta
- description: small personal-sized pizza
- countries: IT
- kinds: type of pizza
- ingredients: tomato sauce, cheese, bread
- has Wikipedia article: en

## DISH Q25067212
- name: Chicken Picasso
- description: chicken dish named after Pablo Picasso
- countries: ES
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q25080055
- name: Bami Haeng Pet
- other names: {"de": "Bami Haeng Pet"}
- countries: (none)
- kinds: dish

## DISH Q250875
- name: Tafelspitz
- description: dish made of boiled meat in Viennese cuisine
- countries: AT
- kinds: beef, cut of beef, beef dish
- ingredients: beef
- has Wikipedia article: en

## DISH Q25091738
- name: Bread dildo
- description: dildo prepared using bread, allegedly made in the Greco-Roman era around 2,000 years ago
- countries: (none)
- kinds: sex toy, use of bread, bread, dildo
- ingredients: bread
- has Wikipedia article: en

## DISH Q250966
- name: Supplì
- other names: {"zh": "罗马炸饭团"}
- description: dish
- countries: IT
- cuisines: Italian cuisine
- kinds: dish, snack
- ingredients: mozzarella
- has Wikipedia article: en, zh

## DISH Q2509786
- name: Krol
- description: Type of bread
- countries: (none)
- kinds: type of food or dish, bread
- ingredients: anise seed

## DISH Q25098594
- name: Cookie cake
- description: dessert
- countries: (none)
- kinds: dessert
- ingredients: cookie dough
- has Wikipedia article: en

## DISH Q25098851
- name: Bogobe jwa lerotse
- description: type of porridge eaten in Botswana
- countries: BW
- kinds: national dish, bogobe
- ingredients: sorghum grain, melon, milk
- has Wikipedia article: en

## DISH Q25099961
- name: Scharfe Maxx
- description: Swiss hard cheese
- countries: CH
- kinds: cow's-milk cheese, Swiss cheeses
- has Wikipedia article: en

## DISH Q2510412
- name: Vanilla sauce
- description: sauce used for desserts
- countries: (none)
- kinds: custard

## DISH Q25105527
- name: Xidoufen
- other names: {"zh": "稀豆粉"}
- description: Chinese soup dish
- countries: (none)
- kinds: dish
- ingredients: scallion, Coriandrum sativum, ginger, Pisum sativum
- has Wikipedia article: en

## DISH Q25105721
- name: Fried pork
- description: pork dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q25110268
- name: Mojakka
- description: North American food culture
- countries: (none)
- kinds: fish soup
- has Wikipedia article: en

## DISH Q25110703
- name: Kaeng phrik kraduk mhu
- description: variety of Thai curry from the areas of southern Thailand
- countries: (none)
- kinds: Thai curry
- has Wikipedia article: en

## DISH Q25111357
- name: Sukhothai noodles
- description: Thai rice noodle dish
- countries: (none)
- kinds: kuai tiao
- has Wikipedia article: en

## DISH Q2511137
- name: Vasina torta
- description: Serbian chocolate cake
- countries: RS
- kinds: cake

## DISH Q25111404
- name: Boba ice cream bar
- description: ice cream dessert
- countries: (none)
- kinds: frozen dessert
- ingredients: tapioca ball, ice cream
- has Wikipedia article: en

## DISH Q25111991
- name: Suguo
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q2511331
- name: Tula gingerbread
- other names: {"zh": "圖拉薑餅"}
- description: famous type of imprinted Russian pryanik
- countries: RU
- kinds: pryanik
- ingredients: powidl, dough
- has Wikipedia article: en, zh

## DISH Q251162
- name: Kaeng tai pla
- other names: {"zh": "鱼杂咖喱"}
- description: curry of southern Thai cuisine, made with tai pla, a salty sauce made from fermented fish entrails which gives the curry a strong smell and flavor; usually served with fresh vegetables in a separate plate and eaten along with steamed rice
- countries: TH
- kinds: Thai curry
- ingredients: tai pla
- has Wikipedia article: en

## DISH Q2511999
- name: Veilcheneis
- other names: {"de": "Veilcheneis"}
- countries: AT
- cuisines: Austrian cuisine
- kinds: sorbet, dish
- ingredients: syrup, lemon juice, Viola odorata

## DISH Q251265
- name: Frikadeller
- description: fried meatball
- countries: DK
- kinds: meatball
- ingredients: pork
- has Wikipedia article: en

## DISH Q251521
- name: Prinzregententorte
- description: traditional bavarian cake
- countries: DE
- kinds: torte
- ingredients: buttercream, chocolate
- has Wikipedia article: en

## DISH Q25171586
- name: Mortis
- description: sweet chicken pâté of Elizabethan times
- countries: (none)
- kinds: fish dish, chicken dish
- has Wikipedia article: en

## DISH Q2517913
- name: Tilslørte bondepiker
- description: scandinavian dessert
- countries: (none)
- kinds: dessert
- has Wikipedia article: en
