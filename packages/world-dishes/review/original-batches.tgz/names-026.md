# Review batch names-026

## DISH Q14918696
- name: Cursory rice
- other names: {"zh": "頹飯"}
- countries: CN
- cuisines: Hong Kong cuisine
- kinds: rice dish
- has Wikipedia article: zh

## DISH Q14918748
- name: Lotek
- description: Sundanese salad from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, salad
- ingredients: cauliflower, ginger, mung bean sprout, peanut, Kaempferia galanga, bird's eye chili, water spinach, Allium ascalonicum, chili pepper, Tamarindus indica, Allium sativum, table salt, sugar, potato
- has Wikipedia article: en

## DISH Q1492566
- name: Gallo Pinto
- other names: {"zh": "黑豆飯"}
- description: Nicaraguan dish based on rice and beans
- countries: (none)
- cuisines: Central American cuisine
- kinds: rice and beans
- has Wikipedia article: en, zh

## DISH Q14930421
- name: Juka
- description: blood soup
- countries: LT
- kinds: food, soup
- ingredients: blood as food
- has Wikipedia article: en

## DISH Q14931087
- name: İnegöl meatballs
- description: Turkish köfte variety from İnegöl, Bursa
- countries: TR
- kinds: food, dish, meatball, Köftes in the Turkish cuisine
- ingredients: meat
- has Wikipedia article: en

## DISH Q14940573
- name: Century egg pastry
- other names: {"zh": "皮蛋酥"}
- countries: (none)
- kinds: dish, pastry, marry girl cake
- ingredients: century egg
- has Wikipedia article: zh

## DISH Q14942719
- name: Wycam's borstbol
- other names: {"nl": "Wycam's borstbol"}
- countries: (none)
- kinds: candy

## DISH Q14943090
- name: Run down
- description: Typical Caribbean dish made with coconut milk and seafood
- countries: JM
- kinds: dish, fish dish
- ingredients: fish as food
- has Wikipedia article: en

## DISH Q1495867
- name: Hopje
- description: Dutch candy with light coffee and caramel taste
- countries: (none)
- kinds: sweetmeat
- ingredients: coffee
- has Wikipedia article: en

## DISH Q1496601
- name: Gaz
- description: pastry
- countries: IQ, IR
- kinds: type of food or dish, food, pastry
- ingredients: rose water, Tamarix, Pistacia vera
- has Wikipedia article: en

## DISH Q1497012
- name: Gebildbrot
- description: bread or bakery in the form of a figurative depiction
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q14971
- name: Pompe aux grattons
- description: culinary specialty of the center of France
- countries: (none)
- kinds: dish

## DISH Q1498208
- name: Gefüllte Kalbsbrust
- countries: (none)
- kinds: dish

## DISH Q1498378
- name: Chopped liver
- other names: {"zh": "碎肝"}
- description: Jewish dish
- countries: (none)
- kinds: liver pâté
- has Wikipedia article: en

## DISH Q1498834
- name: Kimmicher
- other names: {"de": "Kimmicher"}
- description: a type of bread roll
- countries: (none)
- kinds: bread roll

## DISH Q1499559
- name: Fruit jellies
- description: confections
- countries: (none)
- kinds: confectionery

## DISH Q15010030
- name: Poc Chuc
- description: Mayan dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en

## DISH Q1501015
- name: Swedish meatballs
- other names: {"zh": "瑞典肉圆"}
- description: Swedish dish made from ground meat
- countries: SE
- cuisines: Swedish cuisine
- kinds: meatball
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q1501043
- name: Güllaç
- description: Turkish dessert
- countries: TR
- kinds: dessert, dish
- ingredients: corn starch
- has Wikipedia article: en

## DISH Q15014447
- name: Cold noodle
- other names: {"zh": "凉面"}
- description: noodles
- countries: (none)
- kinds: noodle, noodle dish
- has Wikipedia article: en, zh

## DISH Q1501889
- name: White bread
- other names: {"zh": "白面包"}
- description: bread made from light-colored wheat flour
- countries: (none)
- kinds: bread
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q15023947
- name: Acquasale
- description: southern Italian dish
- countries: IT
- kinds: dish
- has Wikipedia article: en

## DISH Q15042119
- name: Stracciatella
- description: egg-based soup typical of central Italy
- countries: IT
- cuisines: Italian cuisine
- kinds: dish, national dish, soup, egg dish
- ingredients: Granular cheese, broth, egg as food
- has Wikipedia article: en

## DISH Q1504300
- name: Streusel
- other names: {"zh": "糖粉奶油细末"}
- description: crumbly topping of flour, butter, and sugar in baking
- countries: DE
- kinds: food, food ingredient
- ingredients: flour, butter, sugar
- has Wikipedia article: en, zh

## DISH Q1505087
- name: Halbseidene Klöße
- other names: {"de": "Halbseidene Klöße"}
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q1505500
- name: Tavukgöğsü
- other names: {"zh": "雞胸肉布丁"}
- description: Turkish milk pudding
- countries: TR
- kinds: budino, chicken dish, dish
- ingredients: wheat
- has Wikipedia article: en, zh

## DISH Q1505775
- name: Sîrbușca
- other names: {"de": "Sîrbușca"}
- countries: (none)
- kinds: dish

## DISH Q15059761
- name: Dak-kkochi
- other names: {"zh": "烤鸡串"}
- description: chicken skewers
- countries: KR
- kinds: kkochi
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q15060428
- name: Saltine cracker
- other names: {"zh": "蘇打餅"}
- description: square cracker made from white flour, yeast, and baking soda
- countries: US
- kinds: food, cracker
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q15062624
- name: Fried rice noodles
- other names: {"zh": "炒米粉"}
- description: food
- countries: (none)
- kinds: type of food or dish, dish
- ingredients: rice noodle
- has Wikipedia article: zh

## DISH Q1506811
- name: Pølse
- description: type of red sausage common in Denmark
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1509150
- name: Kirchtagskrapfen
- description: Tyrolean dessert
- countries: (none)
- kinds: pastry

## DISH Q1509400
- name: Tharid
- description: Popular Hijazi food
- countries: (none)
- kinds: food, stew
- ingredients: crumb
- has Wikipedia article: en

## DISH Q1509414
- name: Phanaeng curry
- other names: {"zh": "浓红咖喱"}
- description: thick, salty, sweet red Thai curry of chilis, galangal, lemongrass, kaffir lime, coriander roots and seeds, cumin, garlic, shallot, shrimp paste, salt and peanuts
- countries: TH
- kinds: Thai curry
- ingredients: curry paste, peanut, coconut milk
- has Wikipedia article: en

## DISH Q1509738
- name: Stutzweck
- other names: {"de": "Stutzweck"}
- countries: DE
- kinds: bread
- ingredients: yeast dough, flour, water

## DISH Q1510478
- name: Westphalian ham
- description: Ham
- countries: (none)
- has Wikipedia article: en

## DISH Q15106034
- name: Аппетайзер
- other names: {"ru": "аппетайзер"}
- countries: (none)
- kinds: dish

## DISH Q1511660
- name: Stosuppe
- other names: {"de": "Stosuppe"}
- countries: (none)
- kinds: dish

## DISH Q15121455
- name: Garlic soup
- description: type of soup using garlic as a main ingredient
- countries: (none)
- kinds: soup
- ingredients: garlic
- has Wikipedia article: en

## DISH Q151259
- name: Zwetschgenkuchen
- description: German plum sheet cake
- countries: (none)
- kinds: sheet cake
- ingredients: zwetschge
- has Wikipedia article: en

## DISH Q1512964
- name: Latke
- description: Jewish potato pancake dish
- countries: (none)
- kinds: potato pancake, potato dish
- has Wikipedia article: en

## DISH Q15139880
- name: Chāshū
- other names: {"zh": "日式叉燒"}
- description: Japanese braised pork
- countries: (none)
- kinds: char siu
- has Wikipedia article: zh

## DISH Q151466
- name: Röggelchen
- description: double bread roll made with rye flour
- countries: (none)
- kinds: baked good, type of food or dish
- has Wikipedia article: en

## DISH Q15149436
- name: Rice cake
- other names: {"zh": "米糕"}
- description: Asian rice dish
- countries: (none)
- kinds: cake, rice dish
- has Wikipedia article: en, zh

## DISH Q1515205
- name: Laufabrauð
- description: food
- countries: IS
- kinds: food, bread
- has Wikipedia article: en

## DISH Q1517954
- name: Pizokel
- description: buckwheat spätzle
- countries: (none)
- kinds: dish
- ingredients: flour

## DISH Q15181
- name: Shashlik
- other names: {"zh": "俄羅斯烤肉"}
- description: form of shish kebab
- countries: (none)
- cuisines: Caucasian cuisine
- kinds: food, meat dish, skewer
- ingredients: food ingredient, vegetable, meat
- has Wikipedia article: en, zh

## DISH Q1518169
- name: Key lime pie
- other names: {"zh": "佛岛青柠派"}
- description: pie made using Key limes
- countries: US
- kinds: sweet pie
- ingredients: shortcrust pastry, Citrus × aurantiifolia
- has Wikipedia article: en, zh

## DISH Q1518177
- name: Whoopie pie
- other names: {"zh": "无比派"}
- description: American baked product
- countries: US
- kinds: cookie
- has Wikipedia article: en

## DISH Q1518603
- name: Mămăligă
- other names: {"zh": "馬馬利加"}
- description: porridge made out of yellow maize flour, traditional in Romania and Moldova
- countries: MD, RO
- kinds: dish
- ingredients: cornmeal
- has Wikipedia article: en, zh

## DISH Q151862
- name: Himmel und Erde
- other names: {"zh": "天堂与大地"}
- description: traditional German dish with potatoes and mashed apples
- countries: (none)
- kinds: potato dish
- ingredients: potato, mashed potato, apple
- has Wikipedia article: en

## DISH Q1518955
- name: Hangtown fry
- description: American egg, oyster, and bacon dish
- countries: US
- cuisines: cuisine of California
- kinds: omelette, egg dish, oyster dish
- ingredients: oyster, egg as food, bacon
- has Wikipedia article: en

## DISH Q1519830
- name: Hamantash
- description: triangular filled-pocket cookie associated with Purim
- countries: IL
- cuisines: Jewish cuisine
- kinds: food, cookie
- ingredients: poppy seed, dough, Papaver, flour
- has Wikipedia article: en

## DISH Q1520147
- name: Getzen
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q1520778
- name: Ketupat
- other names: {"zh": "马来粽"}
- description: Malay traditional food
- countries: MY
- cuisines: Indonesian cuisine, Malay cuisine
- kinds: food, rice cake, Eid food, human food
- ingredients: rice
- has Wikipedia article: en, zh

## DISH Q152088
- name: Fries
- other names: {"zh": "马铃薯条"}
- description: deep-fried potatoes
- countries: BE
- kinds: potato dish, fast food, side dish, convenience food
- ingredients: potato, vegetable oil, table salt
- has Wikipedia article: en, zh

## DISH Q15215193
- name: Maccaroni
- other names: {"nb": "Maccaroni"}
- countries: (none)
- kinds: macaroni

## DISH Q15215698
- name: Genovese foccacia
- countries: IT
- kinds: focaccia

## DISH Q152192
- name: Neujahrsgebäck
- other names: {"de": "Neujahrsgebäck"}
- countries: (none)
- kinds: pastry

## DISH Q15220576
- name: Vinegret
- description: Russian salad
- countries: RU
- cuisines: Russian cuisine, Ukrainian cuisine, Soviet cuisine
- kinds: salad
- ingredients: onion, potato, vegetable oil, beet, sauerkraut, carrot
- has Wikipedia article: en

## DISH Q15223114
- name: Thong yip
- description: Thai dessert
- countries: TH
- kinds: food, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q1522595
- name: Ruchbrot
- description: Swiss bread variety
- countries: CH
- cuisines: Swiss cuisine
- kinds: bread

## DISH Q1522729
- name: Chicken Marengo
- description: chicken dish
- countries: FR
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q1522820
- name: Gibanica
- other names: {"zh": "吉巴尼察"}
- description: Serbian dish made from filo, white cheese, and eggs
- countries: IT, RS
- kinds: food, pie, egg dish
- ingredients: phyllo, egg as food
- has Wikipedia article: en, zh

## DISH Q152288
- name: Sisig
- other names: {"zh": "鐵板豬內臟"}
- description: A Filipino dish that consists of pork scraps
- countries: PH
- kinds: pork dish
- ingredients: pork
- has Wikipedia article: en, zh

## DISH Q152336
- name: Machaca
- description: Sonora
- countries: MX
- kinds: dish, beef dish, pork dish
- ingredients: chicken egg, Machaca
- has Wikipedia article: en

## DISH Q152526
- name: Berliner
- other names: {"zh": "柏林甜圈"}
- description: German jelly doughnut
- countries: DE
- kinds: cruller, jelly doughnut
- ingredients: yeast dough, cooking oil, egg as food
- has Wikipedia article: en, zh

## DISH Q152547
- name: Hagelslag
- other names: {"zh": "巧克力米"}
- description: candy topping
- countries: (none)
- kinds: spread, confectionery, sprinkles
- has Wikipedia article: en

## DISH Q1525655
- name: Giouvetsi
- description: baked meat dish
- countries: GR
- kinds: pasta dish, güveç, Category:Meat dishes
- ingredients: meat
- has Wikipedia article: en

## DISH Q15265706
- name: Ambula
- description: Dried mango preparation from Odisha, India
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1526667
- name: Girardirostbraten
- other names: {"de": "Girardirostbraten"}
- countries: (none)
- kinds: dish

## DISH Q152834
- name: Fruit salad
- other names: {"zh": "水果沙拉"}
- description: dish consisting of various kinds of fruit, sometimes served in a liquid, either in their own juices or a syrup
- countries: (none)
- kinds: dessert salad, fruit dish, dish
- ingredients: fruit
- has Wikipedia article: en, zh

## DISH Q15285629
- name: Chungmu gimbap
- other names: {"zh": "忠武紫菜包饭"}
- description: Korean gimbap variety
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q15290802
- name: Medvědí tlapky
- other names: {"cs": "medvědí tlapky"}
- countries: (none)
- kinds: Christmas cookies

## DISH Q152981
- name: Potato pancake
- other names: {"zh": "马铃薯煎饼"}
- description: fried pancakes of grated or ground potato
- countries: CZ, UA, BY, RU, DE, PL
- cuisines: Czech cuisine, Ukrainian cuisine, Belarusian cuisine, Russian cuisine, German cuisine, Polish cuisine
- kinds: dish, appetizer, culinary speciality, potato dish, pancake
- ingredients: flour, table salt, potato, vegetable oil, onion, egg as food
- has Wikipedia article: en, zh

## DISH Q1531771
- name: Nussknacker
- other names: {"de": "Nussknacker"}
- countries: (none)
- kinds: viennoiserie

## DISH Q153179
- name: Beetroot salad
- description: Finnish and Swedish dish made from beetroots
- countries: (none)
- kinds: salad, dish
- ingredients: mayonnaise, beet, apple

## DISH Q153230
- name: Dibbelabbes
- description: German hash
- countries: DE
- kinds: meat dish, potato dish

## DISH Q1533235
- name: Gnocchi alla romana
- description: dish with gnocci
- countries: IT
- kinds: gnocchi, dish
- ingredients: whole milk, semolina, Parmesan, butter
- has Wikipedia article: en

## DISH Q153352
- name: Sauerbraten
- other names: {"zh": "酸味燉牛肉"}
- description: German roast meat entree
- countries: BE, DE
- kinds: pot roast
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q15340455
- name: Smoked egg
- other names: {"zh": "熏蛋"}
- description: egg dish
- countries: (none)
- kinds: food, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q1535277
- name: Hoorische
- description: German potato dumpling
- countries: DE
- kinds: potato-dough dumpling
- ingredients: potato

## DISH Q153594
- name: Pellkartoffeln
- description: potato dish
- countries: (none)
- kinds: potato dish
- ingredients: potato

## DISH Q1536337
- name: Tenmusu
- description: Japanese rice ball filled with tempura shrimp
- countries: (none)
- kinds: onigiri
- ingredients: tempura, Rice, nori
- has Wikipedia article: en

## DISH Q1537510
- name: Ruisreikäleipä
- description: traditional Finnish rye bread with a hole in the middle
- countries: FI
- kinds: ruisleipä, reikäleipä
- ingredients: rye flour, water
- has Wikipedia article: en

## DISH Q1537533
- name: Hefekloß
- countries: (none)
- kinds: dish

## DISH Q1537922
- name: Isterband
- description: coarsely ground, lightly smoked sausage from Sweden
- countries: SE
- cuisines: Swedish cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q15393896
- name: Šumajstr
- other names: {"cs": "šumajstr"}
- countries: (none)
- kinds: dish

## DISH Q153944
- name: Stutenkerl
- description: Gebildbrot made of sweet yeasted dough belonging to the Saint Nicholas tradition
- countries: CH
- kinds: pastry
- has Wikipedia article: en

## DISH Q15401968
- name: Dodol susu
- other names: {"id": "dodol susu"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, Dodol
- ingredients: granulated sugar, glutinous rice flour, Vanilla planifolia, palm sugar, tapioca, coconut milk, raw milk, table salt, margarine

## DISH Q154043
- name: Rijstevlaai
- description: rice pie, typically from the Dutch or Belgian province of Limburg
- countries: BE
- kinds: dish, vlaai
- ingredients: rice pudding
- has Wikipedia article: en

## DISH Q15409271
- name: Herman cake
- description: sourdough cake
- countries: (none)
- kinds: food, cake
- ingredients: yeast
- has Wikipedia article: en

## DISH Q154166
- name: Sauerkraut
- other names: {"zh": "德国酸菜"}
- description: cabbage that has been fermented by various lactic acid bacteria
- countries: PL, CZ, UA, RU, DE, BG
- cuisines: Polish cuisine, Czech cuisine, Ukrainian cuisine, Russian cuisine, German cuisine, Bulgarian cuisine
- kinds: human food, fermented food, side dish
- ingredients: DL-lactic acid, Brassica oleracea var. capitata, table salt, water
- has Wikipedia article: en, zh

## DISH Q1542215
- name: Pastitsio
- description: Greek baked pasta dish
- countries: GR
- kinds: traditional food, food, casserole, pasta dish
- ingredients: tomato, minced meat, onion, béchamel, nutmeg, oil, flour, butter, table salt, cheese, milk, Capsicum annuum, pasta
- has Wikipedia article: en

## DISH Q15427731
- name: Kumpir
- description: Turkish baked potato dish
- countries: TR
- kinds: potato dish, dish
- ingredients: potato, baked potato
- has Wikipedia article: en

## DISH Q1543722
- name: Grey peas
- other names: {"zh": "灰豌豆"}
- description: dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1543770
- name: Grits
- other names: {"zh": "葛子"}
- description: food made from corn
- countries: US
- cuisines: cuisine of the United States, indigenous cuisine of the Americas
- kinds: porridge
- ingredients: maize flour, cornmeal
- has Wikipedia article: en, zh

## DISH Q1544629
- name: Vatapá
- description: afro-Brazilian dish
- countries: BR
- kinds: dish
- ingredients: bread
- has Wikipedia article: en

## DISH Q154482
- name: Blood sausage
- other names: {"zh": "血肠"}
- description: sausage filled with blood that are cooked or dried and mixed with a filler until they are thick enough to congeal when cooled
- countries: (none)
- kinds: sausage, tripe, pork dish
- ingredients: pork skin, blood as food, spice, bacon
- has Wikipedia article: en, zh

## DISH Q1545649
- name: Grenadiermarsch
- countries: AT, HU
- cuisines: Austrian cuisine, Hungarian cuisine
- kinds: dish

## DISH Q1546782
- name: Grilletta
- description: hamburger variant and 'Griletta' snack bars in East Germany
- countries: DD
- kinds: dish, hamburger, snack bar
- ingredients: chutney, frikadeller, bread roll

## DISH Q1548693
- name: Großer Hans
- other names: {"de": "Großer Hans"}
- countries: (none)
- kinds: dish

## DISH Q154872
- name: Baingan bartha
- description: South Asian dish, that originated in Punjab, bearing a resemblance to baba ghanoush
- countries: IN
- cuisines: Indian cuisine
- kinds: dish
- ingredients: eggplant
- has Wikipedia article: en

## DISH Q1550301
- name: Lemon meringue pie
- description: type of baked pie
- countries: (none)
- kinds: sweet pie
- ingredients: shortcrust pastry, lemon, meringue
- has Wikipedia article: en

## DISH Q1551132
- name: Mutzenmandeln
- description: viennoiserie
- countries: (none)
- kinds: viennoiserie

## DISH Q1551242
- name: Candy cigarette
- other names: {"zh": "香煙糖"}
- description: candy in the form of a cigarette
- countries: (none)
- kinds: confectionery
- ingredients: sugar
- has Wikipedia article: en, zh

## DISH Q1552373
- name: Crumb
- description: soft interior part of bread
- countries: (none)
- kinds: baked good, part

## DISH Q1553379
- name: Polsterzipf
- other names: {"de": "Polsterzipf"}
- countries: (none)
- kinds: deep-fried food

## DISH Q1554207
- name: Gulab jamun
- other names: {"zh": "玫瑰奶球"}
- description: milk-solid-based sweet from the Indian subcontinent
- countries: IN, PK
- kinds: confectionery, mithai
- ingredients: cardamom, khoa, saffron
- has Wikipedia article: en

## DISH Q15544669
- name: Buchholzia coriacea
- description: species of plant
- countries: (none)
- kinds: taxon, dish

## DISH Q1554570
- name: Gundel pancake
- description: food
- countries: HU
- kinds: food, pancake
- ingredients: walnut
- has Wikipedia article: en

## DISH Q1554726
- name: Placek
- other names: {"de": "Placek"}
- countries: (none)
- kinds: viennoiserie

## DISH Q15548160
- name: Roast duck
- other names: {"zh": "烤鸭"}
- countries: (none)
- kinds: duck dish
- ingredients: duck meat, honey
- has Wikipedia article: zh

## DISH Q1555816
- name: Piperade
- other names: {"zh": "番茄甜椒炒蛋"}
- description: French dish, from Gascony, prepared with onion, green peppers, and tomatoes sautéd and flavoured with red Espelette pepper
- countries: FR, ES
- cuisines: French cuisine, Basque cuisine
- kinds: dish, soup
- ingredients: tomato, onion, Capsicum
- has Wikipedia article: en

## DISH Q1558512
- name: Striezel
- description: pastry
- countries: AT
- kinds: pastry, Kuchen
- ingredients: poppy seed, yeast dough, apple

## DISH Q155922
- name: Parmesan
- other names: {"zh": "帕马森干酪"}
- description: Italian hard cheese
- countries: IT
- cuisines: cuisine of the province of Modena, cuisine of Emilia-Romagna
- kinds: cheese, type of cheese, dairy product, Grana Cheese
- ingredients: calf rennet, cow's milk
- has Wikipedia article: en, zh

## DISH Q1559781
- name: Götterspeise
- description: dessert originated in Germany
- countries: DE
- kinds: gelatin dessert
- ingredients: gelatin
- has Wikipedia article: en

## DISH Q156036
- name: Kaiser roll
- description: hard roll, orginally from Austria
- countries: AT
- kinds: bread roll
- ingredients: flour
- has Wikipedia article: en

## DISH Q15604372
- name: Yangchun noodles
- other names: {"zh": "阳春面"}
- description: noodle soup without any toppings
- countries: TW
- kinds: noodle
- has Wikipedia article: zh

## DISH Q1560455
- name: Wiener Boden
- other names: {"de": "Wiener Boden"}
- description: bakery product
- countries: (none)
- kinds: viennoiserie

## DISH Q1561248
- name: Lamian
- other names: {"zh": "中式拉面"}
- description: Chinese noodle made by twisting, stretching and folding the dough into strands
- countries: CN
- kinds: noodle, dish, Chinese noodles
- has Wikipedia article: en, zh

## DISH Q15622657
- name: Gemberkoek
- description: Dutch sweet
- countries: (none)
- kinds: food, ontbijtkoek

## DISH Q15629893
- name: Cornetto
- description: pastry similar to a croissant
- countries: IT
- kinds: pastry, viennoiserie
- ingredients: egg as food, yeast
- has Wikipedia article: en

## DISH Q15630073
- name: Acquacotta
- description: Italian soup with stale bread as a primary ingredient
- countries: IT
- cuisines: Italian cuisine
- kinds: food, soup
- ingredients: bread
- has Wikipedia article: en

## DISH Q1563014
- name: Snirtjebraten
- other names: {"de": "Snirtjebraten"}
- countries: (none)
- kinds: dish

## DISH Q15635457
- name: Kačamak
- description: traditional dish in the Balkan countries and Turkey
- countries: TR
- kinds: porridge
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q1563684
- name: Schleckmuscheln
- description: candy
- countries: (none)
- kinds: candy

## DISH Q15647777
- name: Nièr beurre
- description: preserve of apples that is part of the cuisine and culture of Jersey.
- countries: JE
- kinds: spread, culinary speciality
- has Wikipedia article: en

## DISH Q15648182
- name: Thepla
- description: Indian Flatbread
- countries: IN
- cuisines: Gujarati cuisine
- kinds: flatbread, Indian bread
- ingredients: atta
- has Wikipedia article: en

## DISH Q15656515
- name: Chaku
- description: Newa and/or Nepalese dish
- countries: (none)
- cuisines: Newar cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q15660894
- name: Corn tortilla
- other names: {"zh": "墨西哥玉米薄饼"}
- description: unleavened flatbread made from ground corn (maize)
- countries: (none)
- kinds: unleavened bread, tortilla
- ingredients: cornmeal, maize
- has Wikipedia article: en

## DISH Q1566840
- name: Supersize
- description: size or an extent
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1567471
- name: Leskovački roštilj
- description: Serbian meat dish and grilling method
- countries: RS
- kinds: dish

## DISH Q1567722
- name: Haemultang
- other names: {"de": "Haemultang"}
- countries: (none)
- kinds: dish, guk

## DISH Q15678227
- name: Moong dal halwa
- description: Indian sweet
- countries: IN
- kinds: dessert
- ingredients: cardamom powder, Vigna radiata, ghee, sugar, milk, water
- has Wikipedia article: en

## DISH Q1567954
- name: Peach Melba
- description: type of dessert
- countries: FR
- cuisines: French cuisine
- kinds: ice cream-based dessert
- ingredients: peach, vanilla ice cream, ice cream
- has Wikipedia article: en

## DISH Q1568296
- name: Scotch egg
- other names: {"zh": "蘇格蘭蛋"}
- description: British dish of a soft-boiled egg wrapped in sausage meat, coated in bread crumbs and baked or deep-fried
- countries: GB
- cuisines: British cuisine
- kinds: appetizer
- ingredients: minced meat, boiled egg, egg
- has Wikipedia article: en, zh

## DISH Q15686391
- name: Pepeçura
- description: Turkish grape dessert from the Black Sea Region
- countries: TR
- kinds: pudding, food
- ingredients: cornmeal, corn starch, wheat flour, sugar, grape
- has Wikipedia article: en

## DISH Q1568754
- name: Salpicon
- description: a side dish
- countries: BR
- kinds: ingredient, salad, chicken dish
- has Wikipedia article: en

## DISH Q1568905
- name: Hahnenkamm
- countries: (none)
- kinds: viennoiserie

## DISH Q15693942
- name: Pastel de Gloria
- description: Colombian puff pastry
- countries: ES
- kinds: dessert
- has Wikipedia article: en

## DISH Q15695438
- name: Cider confit
- countries: (none)
- kinds: dish
- ingredients: apple juice, cider, sugar

## DISH Q15696039
- name: Caragolada
- description: dish of cooked land snails
- countries: ES
- kinds: snail as food, dish
- ingredients: Helix pomatia

## DISH Q1570370
- name: Semifreddo
- description: Italian semi-frozen dessert
- countries: IT
- kinds: frozen dessert, dessert with spoon
- ingredients: egg as food, cream, sugar, milk
- has Wikipedia article: en

## DISH Q1570466
- name: Liverwurst
- other names: {"zh": "德国猪肝肠"}
- description: type of sausage
- countries: (none)
- kinds: dish, cold cut, spread, liver sausage
- ingredients: liver as food, head as food, offal
- has Wikipedia article: en, zh

## DISH Q15705292
- name: Filloas
- description: Spanish dish
- countries: (none)
- cuisines: Galician cuisine
- kinds: dessert
- ingredients: chicken egg, flour, milk, drinking water

## DISH Q15714224
- name: Zuccheroni montanari
- other names: {"it": "Zuccheroni montanari"}
- countries: (none)
- kinds: biscuit

## DISH Q15715760
- name: Blintz
- description: traditional Jewish filled pancake
- countries: (none)
- kinds: food, pancake, dish
- has Wikipedia article: en

## DISH Q1571724
- name: Halligbrot
- other names: {"de": "Halligbrot"}
- countries: (none)
- kinds: dish

## DISH Q1572040
- name: Halo-halo
- other names: {"zh": "哈囉哈囉"}
- description: Filipino dessert
- countries: PH
- kinds: dessert
- ingredients: crushed ice, evaporated milk, Gulaman, bean, sago, Cocos nucifera
- has Wikipedia article: en, zh

## DISH Q15724277
- name: Dahibara Aludam
- description: Street food of Odisha
- countries: IN
- cuisines: cuisine of Odisha
- kinds: chaat, street food, snack
- ingredients: potato, Dahi vada
- has Wikipedia article: en

## DISH Q1572670
- name: Meitschibei
- description: Swiss hazelnut pastry
- countries: CH
- kinds: viennoiserie
- ingredients: hazelnut, dough

## DISH Q15730394
- name: Mücver
- description: egg-fried courgette dish from the Turkish cuisine
- countries: TR
- kinds: food, dish
- has Wikipedia article: en

## DISH Q15733826
- name: Flour kurabiye
- description: Turkish kurabiye made with flour, sugar and butter
- countries: TR
- kinds: qurabiya
- ingredients: butter
- has Wikipedia article: en

## DISH Q15735342
- name: Tvarůžkové moučníky
- other names: {"cs": "Tvarůžkové moučníky"}
- countries: (none)
- ingredients: Olomouc curd cheese

## DISH Q1574018
- name: Skolebrød
- description: sweet roll
- countries: NO
- kinds: food, sweet roll
- ingredients: custard, powdered sugar, egg as food, yeast, flour, Cocos nucifera
- has Wikipedia article: en

## DISH Q15751203
- name: Eisbein
- other names: {"zh": "德国猪脚"}
- description: pork dish
- countries: (none)
- kinds: pork dish
- has Wikipedia article: en, zh

## DISH Q15751355
- name: Schweinshaxe
- other names: {"zh": "德國烤豬腳"}
- description: roasted pork knuckles
- countries: (none)
- kinds: food, pork dish
- has Wikipedia article: en, zh

## DISH Q1575225
- name: Halušky
- other names: {"zh": "起司麵疙瘩"}
- description: thick, soft noodles or dumplings in various Central and Eastern European cuisines
- countries: UA
- cuisines: Slovak cuisine, Ukrainian cuisine
- kinds: potato dish
- ingredients: batter
- has Wikipedia article: en, zh

## DISH Q1578239
- name: Chocolate-coated marshmallow treats
- description: marshmallow treat
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q1578447
- name: Lucanica
- description: pork sausage of Ancient Roman cuisine
- countries: (none)
- kinds: sausage, dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q15785303
- name: Bake and Shark
- description: traditional Trinidadian fast food dish
- countries: TT
- kinds: sandwich, fish dish
- has Wikipedia article: en

## DISH Q15785486
- name: Bakpau
- other names: {"zh": "肉包"}
- description: Indonesian bun filled with meat
- countries: (none)
- kinds: baozi
- has Wikipedia article: en

## DISH Q15789810
- name: Brennnesselspinat
- other names: {"de": "Brennnesselspinat"}
- countries: (none)
- kinds: dish
- ingredients: Urtica

## DISH Q15790217
- name: Buljol
- description: Trinidadian and Tobagonian salad
- countries: TT
- kinds: salad, fish dish
- ingredients: Gadus morhua
- has Wikipedia article: en

## DISH Q15792421
- name: Ballebäuschen
- other names: {"de": "Ballebäuschen"}
- countries: (none)
- kinds: pastry, dish

## DISH Q15794115
- name: Cholera
- description: savoury dish from Vaiais, Switzerland, involving potatoes, vegetables and fruits baked with cheese in a pastry similar to a tart
- countries: CH
- cuisines: Swiss cuisine
- kinds: pie, dish
- ingredients: potato, Allium, cheese, apple
- has Wikipedia article: en

## DISH Q1579751
- name: Tres leches cake
- other names: {"zh": "三种乳制品蛋糕"}
- description: dessert
- countries: (none)
- kinds: sponge cake
- ingredients: baked milk, condensed milk, sponge cake, egg as food, butter, cream
- has Wikipedia article: en, zh

## DISH Q15801159
- name: Shkmeruli
- other names: {"zh": "Chkmeruli"}
- description: Georgian chicken dish
- countries: GE
- cuisines: Georgian cuisine
- kinds: chicken dish, dish
- ingredients: white sauce, chicken as food, Allium sativum
- has Wikipedia article: en, zh

## DISH Q1580437
- name: Pyttipanna
- description: potato dish
- countries: (none)
- kinds: potato dish
- ingredients: potato, meat
- has Wikipedia article: en

## DISH Q1581463
- name: Turoš
- description: type of Cheese
- countries: (none)
- cuisines: Croatia
- kinds: food
- has Wikipedia article: en

## DISH Q1582056
- name: Schweinfurter Schlachtschüssel
- other names: {"de": "Schweinfurter Schlachtschüssel"}
- countries: (none)
- kinds: intangible cultural heritage, dish

## DISH Q15822587
- name: Kanelbulle
- other names: {"de": "Kanelbulle"}
- countries: (none)
- kinds: viennoiserie

## DISH Q15823102
- name: Karlsbader Schnitte
- description: type of ham sandwich
- countries: (none)
- kinds: sandwich
- ingredients: ham, cheese, bread

## DISH Q15835946
- name: Muzen
- countries: (none)
- kinds: cruller

## DISH Q1583698
- name: Hanseat
- countries: (none)
- kinds: viennoiserie

## DISH Q15839499
- name: Paprikaschnitzel
- other names: {"de": "Paprikaschnitzel"}
- countries: (none)
- kinds: meat dish
- ingredients: schnitzel

## DISH Q15839804
- name: Paulaner Würste
- other names: {"de": "Paulaner Würste"}
- description: Viennese dish
- countries: (none)
- kinds: fish dish

## DISH Q15840444
- name: Pholourie
- description: Fried, spiced dough balls
- countries: GY, IN, SR, TT
- kinds: dish
- has Wikipedia article: en

## DISH Q15843485
- name: Rübenmus
- other names: {"de": "Rübenmus"}
- description: dish
- countries: (none)
- kinds: dish

## DISH Q15845489
- name: Moroccan Rziza
- description: Moroccan cuisine
- countries: MA
- kinds: pastry, food

## DISH Q15845514
- name: Halwat tabaa
- other names: {"fr": "Halwat tabaa"}
- countries: (none)
- kinds: cake

## DISH Q15845628
- name: Amor polenta
- other names: {"it": "Amor polenta"}
- countries: IT
- kinds: dessert

## DISH Q15846908
- name: Schwierige Speisen
- other names: {"de": "Schwierige Speisen"}
- countries: (none)
- kinds: dish

## DISH Q1584788
- name: Smyrna meatballs
- description: A "köfte" dish that originated in Izmir, Turkey, and common to the Turkish and Greek cuisines.
- countries: TR
- kinds: main course, Köftes in the Turkish cuisine
- ingredients: meat

## DISH Q1584798
- name: Parsley potatoes
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q1585409
- name: Harees
- other names: {"zh": "哈里薩"}
- description: Armenian dish
- countries: AM
- cuisines: Armenian cuisine
- kinds: dish
- ingredients: wheat

## DISH Q15854364
- name: Wiener Wurst
- other names: {"de": "Wiener Wurst"}
- countries: AT
- kinds: sausage

## DISH Q15855727
- name: Zigerkrapfen
- description: Swiss deep fried dough served during carnival
- countries: CH
- kinds: viennoiserie
- ingredients: stuffing

## DISH Q15856811
- name: Ballı Börek
- other names: {"de": "Ballı Börek"}
- description: food
- countries: (none)
- kinds: dish

## DISH Q1587123
- name: Mutabak
- description: stuffed pancake or pan-fried bread dish
- countries: YE
- kinds: food, pancake, lamb dish
- ingredients: minced meat, onion, wheat flour, lamb meat, egg as food, table salt
- has Wikipedia article: en

## DISH Q15873544
- name: Broodje halfom
- other names: {"nl": "broodje halfom"}
- countries: (none)
- kinds: submarine sandwich

## DISH Q15877316
- name: Kandijkoek
- other names: {"nl": "Kandijkoek"}
- countries: (none)
- kinds: food, ontbijtkoek

## DISH Q15877508
- name: Kokindje
- description: Liquorice
- countries: (none)
- kinds: licorice candy

## DISH Q15880225
- name: Egg yolk pastry
- other names: {"zh": "蛋黃酥"}
- description: Taiwanese mooncake filled with salted duck egg yolk and red bean paste
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: mooncake, pastry
- ingredients: salted duck egg yolk, red bean paste
- has Wikipedia article: en, zh

## DISH Q15883356
- name: Venlose paeperkook
- other names: {"li": "Venlose paeperkook"}
- countries: (none)
- kinds: food, cookie

## DISH Q15884273
- name: Pea soup with pancakes
- description: traditional Swedish dish
- countries: (none)
- kinds: dish
- ingredients: pea soup, pancake, crêpe

## DISH Q1588808
- name: Hasty pudding
- description: pudding or porridge of grains cooked in milk or water
- countries: US
- kinds: food, pudding
- ingredients: cereal
- has Wikipedia article: en

## DISH Q15888508
- name: Duck blood curds
- other names: {"zh": "鴨血"}
- countries: (none)
- ingredients: domestic duck
- has Wikipedia article: zh

## DISH Q15893577
- name: Lamb brisket
- other names: {"zh": "羊腩"}
- countries: (none)
- kinds: dish, sheep meat
- has Wikipedia article: zh

## DISH Q15894338
- name: Kaolaolao
- other names: {"zh": "蓧麵栲栳栳"}
- countries: CN
- kinds: noodle dish
- has Wikipedia article: zh

## DISH Q15894369
- name: Pork liver noodles
- other names: {"zh": "豬肝麵"}
- description: Chinese dish
- countries: CN
- kinds: dish
- has Wikipedia article: zh

## DISH Q15894455
- name: 蝦仁煎
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q15896447
- name: Red bean paste bun
- other names: {"zh": "豆沙包"}
- countries: CN
- cuisines: Beijing cuisine, cuisine of Tianjin
- kinds: baozi
- ingredients: red bean paste
- has Wikipedia article: zh

## DISH Q15896582
- name: Menmian
- other names: {"zh": "焖面"}
- description: Braised String Bean with noodles
- countries: CN
- kinds: noodle dish
- has Wikipedia article: zh

## DISH Q15896774
- name: Water chestnut soup
- other names: {"zh": "馬蹄露"}
- description: Chinese food
- countries: CN
- kinds: tong sui, type of food or dish
- has Wikipedia article: zh

## DISH Q15896943
- name: Stir-fried ice cream
- other names: {"zh": "炒冰"}
- description: hand made ice cream dessert made with milk poured on an iced grill, mixed with fruit or different ingredients on the ice-pan
- countries: TH
- kinds: ice cream
- has Wikipedia article: en, zh

## DISH Q15897086
- name: Doubao
- other names: {"zh": "豆包"}
- description: food
- countries: CN
- kinds: vegetarian cuisine, baozi, type of food or dish
- ingredients: flour, sweet bean paste
- has Wikipedia article: zh

## DISH Q15898970
- name: Kaofu
- other names: {"zh": "烤麸"}
- countries: CN
- kinds: food product
- has Wikipedia article: zh

## DISH Q15899146
- name: 梁溪脆鳝
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q15900078
- name: 番茄切盤
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q15900310
- name: Rugao ham
- other names: {"zh": "如皋火腿"}
- description: Chinese dry-cured ham
- countries: CN
- cuisines: Chinese cuisine
- kinds: ham
- has Wikipedia article: en, zh

## DISH Q15902096
- name: Beef and macaroni in tomato soup
- other names: {"zh": "番茄牛肉通心粉"}
- countries: CN
- kinds: noodle soup
- has Wikipedia article: zh

## DISH Q15906640
- name: Napoleon cake
- description: dessert
- countries: FR
- kinds: cake, dish
- ingredients: buttercream, custard, puff pastry

## DISH Q15909171
- name: Pork floss
- other names: {"zh": "猪肉松"}
- countries: (none)
- kinds: rousong
- has Wikipedia article: zh

## DISH Q15912025
- name: 玉里麵
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q15915476
- name: Khong bah png
- other names: {"zh": "炕肉饭"}
- description: traditional Taiwanese pork dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish, type of food or dish
- has Wikipedia article: en, zh

## DISH Q15918345
- name: Palt
- description: Swedish meat-filled potato dumpling
- countries: SE
- kinds: potato dish
- has Wikipedia article: en

## DISH Q15918831
- name: Yyuasa
- description: dish of Bashkir cuisine
- countries: (none)
- cuisines: Bashkir cuisine
- kinds: pastry
- ingredients: vegetable oil, wheat flour, sodium bicarbonate, powdered sugar, egg as food, table salt, sugar, milk

## DISH Q15920051
- name: Jipai
- other names: {"zh": "香雞排"}
- description: Taiwanese chicken dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: fried chicken, chicken dish, cooking
- ingredients: fried chicken
- has Wikipedia article: en, zh

## DISH Q15925446
- name: 澎湖海鮮
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q15927529
- name: Zanahorias aliñadas
- description: Andalusian recipe
- countries: (none)
- kinds: dish, tapas
- ingredients: oregano, parsley, cumin seed, garlic, extra virgin olive oil, sherry vinegar, carrot

## DISH Q1592853
- name: Koi
- description: Lao-Thai salad dish with raw beef
- countries: LA
- kinds: raw meat dish
- has Wikipedia article: en

## DISH Q159290
- name: Kue lapis
- other names: {"zh": "印尼九層糕"}
- description: Malay layered cake
- countries: ID
- kinds: food, pastry, Kuih
- ingredients: rice flour, tapioca, coconut milk, table salt, sugar
- has Wikipedia article: en

## DISH Q15929559
- name: Gû-tsi̍h-piánn
- other names: {"zh": "牛舌餅 (台灣小吃)"}
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q15930176
- name: Bah-kenn
- other names: {"zh": "肉羹"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: dish, Geng
- has Wikipedia article: zh

## DISH Q159304
- name: Turrón
- description: southern European nougat confection
- countries: ES
- cuisines: Spanish cuisine
- kinds: nougat, dessert, dish
- ingredients: egg white, almond, sugar, honey
- has Wikipedia article: en

## DISH Q15931384
- name: Matang
- other names: {"zh": "玛仁糖"}
- description: Uyghur-style confection
- countries: CN
- kinds: confectionery
- has Wikipedia article: zh

## DISH Q15932277
- name: 清蒸武昌鱼
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q15932522
- name: Suan tang shui jiao
- other names: {"zh": "酸汤水饺"}
- description: variant of jiaozi
- countries: (none)
- kinds: jiaozi
- has Wikipedia article: zh

## DISH Q15935161
- name: Mutton hot pot
- other names: {"zh": "羊肉爐"}
- description: Taiwanese hot pot dish dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: lamb dish, Taiwanese Hot pot, dish
- ingredients: lamb meat
- has Wikipedia article: zh

## DISH Q1593672
- name: Yeast extract
- other names: {"zh": "酵母提取物"}
- description: food
- countries: DE
- kinds: food ingredient, food, nutritional yeast
- has Wikipedia article: en, zh

## DISH Q15939227
- name: Hulutou
- other names: {"zh": "葫芦头"}
- description: Paomo with pork intestines
- countries: (none)
- kinds: Paomo
- ingredients: pork large intestine, Laobing
- has Wikipedia article: zh

## DISH Q1594252
- name: Heidesand
- other names: {"de": "Heidesand"}
- countries: (none)
- kinds: viennoiserie

## DISH Q15942827
- name: 煲仔菜
- description: dish
- countries: CN
- cuisines: Chinese cuisine
- kinds: dish, type of food or dish
- has Wikipedia article: zh

## DISH Q15943298
- name: Duivekater
- countries: (none)
- kinds: floor-baked bread

## DISH Q15948677
- name: Sha Shingbee
- description: Tibetan sliced mutton with green beans
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q15949258
- name: 炒泡麵
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q15952986
- name: Jiaoquan
- other names: {"zh": "焦圈"}
- description: fried snack food
- countries: CN
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q15954264
- name: Ribs stewed in medicinal herbs
- other names: {"zh": "藥燉排骨"}
- description: Taiwanese pork rib dish stewed with medicinal herbs
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q15955061
- name: Shanxi knife-cut noodles
- other names: {"zh": "山西刀削麵"}
- countries: CN
- kinds: food, dāoxiāo miàn
- has Wikipedia article: zh

## DISH Q15955215
- name: Pålægssalat
- other names: {"da": "pålægssalat"}
- countries: (none)
- kinds: salad, spread

## DISH Q15955973
- name: Mendiant
- description: traditional French confectionery
- countries: FR
- kinds: cake, sweetmeat
- ingredients: chocolate
- has Wikipedia article: en

## DISH Q15957214
- name: Nijjoarsrollechie
- other names: {"nds-nl": "Nijjoarsrollechie"}
- countries: (none)
- kinds: food, pastry

## DISH Q1597319
- name: Obuku
- other names: {"da": "Obuku"}
- description: Japanese Buddhism offerings
- countries: (none)
- kinds: dish

## DISH Q159754
- name: Gugelhupf
- other names: {"zh": "奶油圆蛋糕"}
- description: German cake
- countries: FR, RU, DE, PL, UA, BY
- cuisines: French cuisine, Russian cuisine, German cuisine, Polish cuisine, Ukrainian cuisine, Belarusian cuisine
- kinds: bundt cake
- ingredients: yeast dough
- has Wikipedia article: en, zh

## DISH Q15976317
- name: Selat Solo
- description: Indonedian acculturation dish with a combination of meat and salad
- countries: ID
- cuisines: Indonesian cuisine
- kinds: type of food or dish, food, dish, human food, traditional food, salad, meat dish
- ingredients: egg as food, Lactuca sativa, vinegar, onion, carrot, garlic, tomato, potato, green bean, kecap manis, soy sauce, beef, mayonnaise
- has Wikipedia article: en

## DISH Q15979670
- name: Capocollo di Calabria PDO
- other names: {"zh": "Capocollo di Calabria DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: Capicola, meat product

## DISH Q15983343
- name: Sago soup
- other names: {"zh": "西米露"}
- description: Cantonese dessert soup
- countries: HK
- kinds: soup, dish, tong sui
- has Wikipedia article: en, zh

## DISH Q159841
- name: Millet porridge
- description: type of porridge
- countries: RU
- kinds: porridge, staple food, kasha
- ingredients: millet groat, millet, milk, water

## DISH Q15984356
- name: Casdoce
- countries: (none)
- kinds: Nanbangashi
- ingredients: castella

## DISH Q15985100
- name: Rfiss
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: flour

## DISH Q15985102
- name: Chocolate covered fruit
- countries: (none)
- kinds: dessert
- ingredients: fruit, chocolate
- has Wikipedia article: en

## DISH Q15990748
- name: Mtsvadi
- description: Georgian kebab
- countries: GE
- kinds: kebab

## DISH Q1599125
- name: Wrap
- other names: {"zh": "卷饼"}
- description: food dish made with a soft flatbread rolled around a filling
- countries: MX
- kinds: food, sandwich, fast food, street food, roll
- ingredients: stuffing, flatbread
- has Wikipedia article: en, zh

## DISH Q15992430
- name: Serradura
- other names: {"zh": "木糠布甸"}
- description: dessert
- countries: PT
- cuisines: Portuguese cuisine
- kinds: type of food or dish, food, pudding
- ingredients: sweetened condensed milk, whipped cream, biscuit, cream
- has Wikipedia article: en, zh

## DISH Q15992463
- name: طبيخ
- other names: {"ar": "طبيخ"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: beef, almond, honey

## DISH Q16024165
- name: Sandwich américain
- other names: {"zh": "美式三明治"}
- description: sandwich with hamburger steak and/or French fries
- countries: (none)
- kinds: sandwich
- has Wikipedia article: zh

## DISH Q1603166
- name: Twist bread
- description: food
- countries: (none)
- kinds: food, bread
- has Wikipedia article: en

## DISH Q16044494
- name: Ayam pop
- description: Indonesian chicken dish
- countries: ID
- cuisines: Padang cuisine
- kinds: food, fried chicken, chicken dish
- ingredients: chicken as food, coconut milk, coconut water, Alpinia galanga, chili pepper, Cymbopogon citratus
- has Wikipedia article: en

## DISH Q16044734
- name: آب دندون
- other names: {"fa": "آب دندون"}
- countries: (none)
- kinds: pastry

## DISH Q16044834
- name: آبگوشت فلفل همدانی
- other names: {"fa": "آبگوشت فلفل همدانی"}
- countries: IR
- kinds: dish

## DISH Q16044846
- name: آبنبات قیچی
- other names: {"fa": "آبنبات قیچی"}
- countries: (none)
- kinds: pastry

## DISH Q16045177
- name: Tarhana soup
- countries: (none)
- kinds: chorba

## DISH Q16045302
- name: خارک پخته
- other names: {"fa": "خارک پخته"}
- countries: (none)
- kinds: pastry

## DISH Q16045579
- name: خاکاره دبیج
- other names: {"fa": "خاکاره دبیج"}
- countries: (none)
- kinds: pastry

## DISH Q16045671
- name: خرش حلوا
- other names: {"fa": "خرش حلوا"}
- countries: (none)
- kinds: pastry

## DISH Q16045927
- name: List of Iranian Sweets
- description: Wikimedia list article
- countries: (none)
- kinds: Wikimedia list article, pastry

## DISH Q16045958
- name: Tar halva
- description: type of halva
- countries: (none)
- kinds: halva, pastry

## DISH Q16046026
- name: ترک حلوا
- other names: {"fa": "ترک حلوا"}
- countries: (none)
- kinds: pastry

## DISH Q16046038
- name: Khoresh bademjan
- description: Persian stew of eggplant and tomatoes
- countries: IR
- kinds: food
- ingredients: tomato, eggplant
- has Wikipedia article: en

## DISH Q16046063
- name: سیر قلیه
- other names: {"fa": "سیر قلیه"}
- countries: IR
- kinds: dish

## DISH Q16046109
- name: مرغ ترش
- other names: {"fa": "مرغ ترش"}
- countries: IR
- kinds: dish

## DISH Q16046218
- name: Reshteh bereshteh
- countries: (none)
- kinds: pastry

## DISH Q16046395
- name: گل قند
- other names: {"fa": "گل قند"}
- countries: (none)
- kinds: pastry

## DISH Q16046426
- name: گل پالوده
- other names: {"fa": "گل پالوده"}
- countries: (none)
- kinds: pastry

## DISH Q16046748
- name: توت
- other names: {"fa": "توت"}
- countries: (none)
- kinds: pastry

## DISH Q16046769
- name: رقایب حلوا
- other names: {"fa": "رقایب حلوا"}
- countries: (none)
- kinds: pastry

## DISH Q16048875
- name: قیقناق
- other names: {"fa": "قیقناق"}
- countries: (none)
- kinds: pastry

## DISH Q16048915
- name: پلادانه حلوا
- other names: {"fa": "پلادانه حلوا"}
- countries: (none)
- kinds: pastry

## DISH Q16048950
- name: باقلوای گل رز قزوینی
- other names: {"fa": "باقلوای گل رز قزوینی"}
- countries: (none)
- kinds: pastry

## DISH Q16049409
- name: لندو
- other names: {"fa": "لندو"}
- countries: (none)
- kinds: pastry

## DISH Q16049421
- name: شیرینی بهشتی
- other names: {"fa": "شیرینی بهشتی"}
- countries: (none)
- kinds: pastry

## DISH Q16049429
- name: شیرینی زبان
- other names: {"fa": "شیرینی زبان"}
- countries: (none)
- kinds: pastry

## DISH Q16049438
- name: شیرینی سام پوسته
- other names: {"fa": "شیرینی سام پوسته"}
- countries: (none)
- kinds: pastry

## DISH Q16049450
- name: شیرینی شکری
- other names: {"fa": "شیرینی شکری"}
- countries: (none)
- kinds: pastry

## DISH Q16049460
- name: شیرینی مشهدی
- other names: {"fa": "شیرینی مشهدی"}
- countries: (none)
- kinds: pastry

## DISH Q16049469
- name: شیرینی مینیاتوری
- other names: {"fa": "شیرینی مینیاتوری"}
- countries: (none)
- kinds: pastry

## DISH Q16049477
- name: Shirini Nargili
- description: Chewy coconut macaroons
- countries: IR
- kinds: pastry

## DISH Q16049486
- name: شیرینی نازک
- other names: {"fa": "شیرینی نازک"}
- countries: (none)
- kinds: pastry

## DISH Q16049497
- name: شیرینی نعلی
- other names: {"fa": "شیرینی نعلی"}
- countries: (none)
- kinds: pastry

## DISH Q16049507
- name: شیرینی هلال خامه
- other names: {"fa": "شیرینی هلال خامه"}
- countries: (none)
- kinds: pastry

## DISH Q16049517
- name: شیرینی پادرازی
- other names: {"fa": "شیرینی پادرازی"}
- countries: (none)
- kinds: pastry

## DISH Q16049527
- name: شیرینی کشمشی
- other names: {"fa": "شیرینی کشمشی"}
- countries: (none)
- kinds: pastry

## DISH Q16049536
- name: شیرینی گردویی
- other names: {"fa": "شیرینی گردویی"}
- countries: (none)
- kinds: pastry

## DISH Q16049599
- name: برساق
- other names: {"fa": "برساق"}
- countries: (none)
- kinds: pastry

## DISH Q16049608
- name: برشتوک
- other names: {"fa": "برشتوک"}
- countries: (none)
- kinds: pastry

## DISH Q16050293
- name: Aghuznun
- description: iranian cake
- countries: (none)
- kinds: pastry

## DISH Q16050541
- name: چنگمال
- other names: {"fa": "چنگمال"}
- countries: (none)
- kinds: pastry

## DISH Q16050684
- name: چولو
- other names: {"fa": "چولو"}
- countries: (none)
- kinds: pastry
