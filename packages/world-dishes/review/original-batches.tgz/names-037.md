# Review batch names-037

## DISH Q28668248
- name: Rustin negàa
- other names: {"it": "Rustin negàa"}
- countries: (none)
- kinds: dish

## DISH Q28668258
- name: Pan meino
- description: lombard dessert
- countries: IT
- cuisines: Lombard cuisine
- kinds: dessert
- has Wikipedia article: en

## DISH Q28668262
- name: Minestrone alla milanese
- other names: {"it": "Minestrone alla milanese"}
- countries: (none)
- kinds: minestrone

## DISH Q28669290
- name: Баррига де фрейра
- other names: {"ru": "Баррига де фрейра"}
- countries: PT
- kinds: dessert
- ingredients: egg yolk

## DISH Q28669928
- name: Torta greca
- other names: {"it": "Torta greca"}
- countries: IT
- kinds: dessert

## DISH Q28670093
- name: Mandorlini del Ponte
- description: Italian meringue cookie
- countries: IT
- kinds: cookie
- ingredients: egg white, almond, flour, butter, sugar

## DISH Q28670218
- name: Stufati di Teggiano
- other names: {"it": "Stufati di Teggiano"}
- countries: (none)
- kinds: dish

## DISH Q28670248
- name: Caldi dolci
- other names: {"it": "Caldi dolci"}
- countries: IT
- kinds: dessert

## DISH Q28670491
- name: Scattone
- description: soup from Italy
- countries: IT
- kinds: soup
- ingredients: red wine

## DISH Q28670827
- name: Anello di san Luigi Gonzaga
- other names: {"it": "Anello di san Luigi Gonzaga"}
- countries: IT
- kinds: dessert

## DISH Q28671281
- name: Шатобриан
- other names: {"ru": "шатобриан"}
- countries: FR
- cuisines: French cuisine
- kinds: sauce

## DISH Q28671371
- name: Nozza
- description: Italian food
- countries: IT
- kinds: dessert

## DISH Q2867155
- name: Assidat zgougou
- description: Tunisian dessert
- countries: TN
- kinds: food, dessert
- ingredients: Asida, Pinus halepensis, flour, cream, milk
- has Wikipedia article: en

## DISH Q2867162
- name: Walliser Teller
- other names: {"de": "Walliser Teller"}
- countries: (none)
- kinds: dish

## DISH Q28673045
- name: Kopalnioki
- description: candy from Silesia, Poland
- countries: (none)
- kinds: candy
- ingredients: anise seed
- has Wikipedia article: en

## DISH Q28674786
- name: Ogórek kołobrzeski
- other names: {"pl": "Ogórek kołobrzeski"}
- countries: PL
- kinds: preserved food, vegetable dish

## DISH Q28675205
- name: Miód drahimski
- description: Polish honey
- countries: PL
- kinds: honey

## DISH Q28682513
- name: Minazuki
- countries: (none)
- kinds: Kyōgashi
- ingredients: uirō, Vigna angularis

## DISH Q28682544
- name: Kirizashō
- countries: JP
- kinds: mochi, wagashi, New Year's food
- ingredients: glutinous rice

## DISH Q28682686
- name: 月之雫
- countries: (none)
- kinds: wagashi
- ingredients: Kōshū

## DISH Q286829
- name: Koeksister
- description: traditional Afrikaner confectionery
- countries: ZA
- kinds: doughnut
- ingredients: dough
- has Wikipedia article: en

## DISH Q28683001
- name: 桃山
- other names: {"ja": "桃山"}
- countries: (none)
- kinds: wagashi

## DISH Q28683065
- name: 茶通
- other names: {"ja": "茶通"}
- countries: JP
- kinds: wagashi

## DISH Q28683069
- name: つやぶくさ
- other names: {"ja": "つやぶくさ"}
- countries: (none)
- kinds: wagashi

## DISH Q28683469
- name: 鹿の子餅
- other names: {"ja": "鹿の子餅"}
- countries: (none)
- kinds: wagashi

## DISH Q28683552
- name: Oroshi mochi
- countries: (none)
- kinds: mochi
- ingredients: daikon oroshi, mochi

## DISH Q28683715
- name: Kamenokō Senbei
- countries: (none)
- kinds: senbei, Miyagegashi

## DISH Q28683808
- name: 時雨の松
- other names: {"ja": "時雨の松"}
- countries: JP
- kinds: wagashi

## DISH Q28684065
- name: くずシャリ
- other names: {"ja": "くずシャリ"}
- countries: (none)
- kinds: confectionery

## DISH Q28684540
- name: Kataharanbū
- countries: (none)
- kinds: tempura, deep-fried confection

## DISH Q28686794
- name: プチプチ占い
- other names: {"ja": "プチプチ占い"}
- countries: JP
- kinds: confectionery

## DISH Q28686826
- name: Sekitan Zangi
- description: Chicken karaage
- countries: (none)
- kinds: karaage

## DISH Q28688143
- name: 幽霊子育飴
- other names: {"ja": "幽霊子育飴"}
- countries: (none)
- kinds: ame

## DISH Q28689510
- name: Nikoji
- description: Japanese regional dish
- countries: (none)
- kinds: nabemono

## DISH Q28689881
- name: Akayu ramen
- countries: (none)
- kinds: miso ramen, Yamagata ramen

## DISH Q28692608
- name: Hamukatsu
- other names: {"zh": "吉列火腿"}
- countries: JP
- kinds: katsu
- ingredients: ham

## DISH Q28693034
- name: Yamagata ramen
- countries: (none)
- kinds: ramen

## DISH Q28693320
- name: Ankomaki
- countries: (none)
- kinds: teppanyaki, dagashi
- ingredients: red bean paste

## DISH Q28701751
- name: Okchundang
- other names: {"zh": "玉春糖"}
- description: traditional Korean sweet
- countries: (none)
- kinds: food, candy
- ingredients: rice flour
- has Wikipedia article: en, zh

## DISH Q28704166
- name: Krupci
- other names: {"pl": "krupci"}
- countries: (none)
- kinds: dish

## DISH Q28712168
- name: Bomba
- other names: {"ca": "Bomba"}
- countries: ES
- cuisines: Catalan cuisine
- kinds: tapas, food
- ingredients: potato, minced meat, bread crumbs, hot sauce

## DISH Q28715991
- name: Tamina
- description: Algerian dessert
- countries: DZ
- kinds: dessert
- ingredients: semolina, butter, honey

## DISH Q28717391
- name: القراصة
- other names: {"ar": "القراصة"}
- countries: SD
- kinds: baked good, type of food or dish

## DISH Q28724581
- name: Samtis chili sauce
- description: Jepara-style chili sauce
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: shallot, garlic, shrimp and prawn as food, cooking oil, chili pepper, tomato

## DISH Q28724652
- name: Kue precet
- description: West Java traditional cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: kue, dish, human food, type of food or dish
- ingredients: rice flour, coconut milk, banana

## DISH Q28724662
- name: Tahu bulat
- description: fried tofu with round shape
- countries: ID
- kinds: tahu goreng
- ingredients: tofu, salt

## DISH Q28724885
- name: Ayam goreng jepara
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fried chicken, dish, human food, type of food or dish
- ingredients: chicken

## DISH Q28724890
- name: Jeporo-style fried chicken
- description: typical food from Jepara Regency
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fried chicken, dish, human food, type of food or dish

## DISH Q28724892
- name: Ayam Goreng Lamongan
- other names: {"id": "Ayam Goreng Lamongan"}
- countries: ID
- kinds: dish

## DISH Q28725121
- name: I know
- description: a variety of traditional Indonesian dishes
- countries: ID
- cuisines: Indonesian cuisine
- kinds: tahu goreng, dish, human food, type of food or dish
- ingredients: garlic, tapioca, tofu, Allium tuberosum

## DISH Q28725149
- name: Akar Pinang
- description: variations of typical Indonesian food
- countries: ID
- kinds: kue, dish, type of food or dish
- ingredients: garlic, glutinous rice flour, chicken egg, monosodium L-glutamate, butter, table salt, water

## DISH Q28726278
- name: Ciorbă de pește
- other names: {"ca": "Ciorbă de pește"}
- countries: RO
- kinds: dish
- ingredients: fish as food

## DISH Q28733682
- name: Շաքարացված ծաղիկներ
- other names: {"hy": "Շաքարացված ծաղիկներ"}
- countries: (none)
- kinds: dessert
- ingredients: sugar, flower

## DISH Q2874616
- name: Avruga caviar
- description: caviar substitute made from herring and squid ink, made without any fish roe
- countries: (none)
- kinds: fish product, fish dish
- has Wikipedia article: en

## DISH Q28752866
- name: Presidential M&M's
- description: commemorative packs of red, white, and blue-colored M&M's given to guests of the president of the United States on board Air Force One
- countries: (none)
- kinds: gift, M&M's
- has Wikipedia article: en

## DISH Q28758669
- name: Drømmekage
- other names: {"da": "Drømmekage"}
- countries: (none)
- kinds: cake

## DISH Q28759404
- name: Cornish pasty
- description: pasty made in Cornwall
- countries: (none)
- kinds: pasty

## DISH Q2877510
- name: Dutchie
- description: Canadian doughnut
- countries: CA
- kinds: doughnut, food
- has Wikipedia article: en

## DISH Q2877840
- name: Bean goulash
- description: Hungarian food
- countries: HU
- kinds: gulyásleves
- ingredients: Phaseolus vulgaris, potato, meat

## DISH Q2878129
- name: Bacalao al ajoarriero
- description: Salted cod cooked with vegetables
- countries: ES
- kinds: fish dish
- ingredients: garlic, tomato, cod
- has Wikipedia article: en

## DISH Q2878697
- name: Liver pâté
- other names: {"zh": "豬肝醬"}
- description: pâté and meat spread popular in northern and eastern Europe
- countries: (none)
- kinds: food, cold cut, pâté, spread
- ingredients: pork liver, lard
- has Wikipedia article: en

## DISH Q28790919
- name: Spinach lasagne
- countries: (none)
- kinds: dish, lasagna
- ingredients: lasagne sheet, Spinacia oleracea

## DISH Q2879242
- name: Bagòss
- description: Italian cheese
- countries: IT
- kinds: Italian cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q2879351
- name: Bai ye
- countries: CN
- kinds: dish
- ingredients: tofu
- has Wikipedia article: en

## DISH Q2879979
- name: Baiser
- description: Belgian pastery
- countries: (none)
- kinds: confectionery, food

## DISH Q2880030
- name: Bajana
- other names: {"pl": "Bajana"}
- countries: (none)
- kinds: dish, soup
- ingredients: chestnut

## DISH Q2880033
- name: Bajadera
- description: Balkan nougat food
- countries: HR
- kinds: praline
- ingredients: nougat
- has Wikipedia article: en

## DISH Q2880284
- name: Baklawa El Bey
- description: Tunesian baklawa
- countries: TN
- kinds: cookie

## DISH Q28803
- name: Sandwich
- other names: {"zh": "三明治"}
- description: food made with bread and other ingredients
- countries: (none)
- kinds: finger food, bánh, bread dish, type of food or dish, bread
- ingredients: bread
- has Wikipedia article: en, zh

## DISH Q2880915
- name: Bacalhau à minhota
- description: traditional codfish dish from Alto Minho, Portugal
- countries: PT
- cuisines: Portuguese cuisine
- kinds: potato dish, fish dish
- ingredients: onion, dried and salted cod, olive, fries, olive oil
- has Wikipedia article: en

## DISH Q28812188
- name: Laz böreği
- description: Turkish dessert
- countries: TR
- kinds: dessert, food
- has Wikipedia article: en

## DISH Q2881759
- name: Bambalouni
- description: Tunisian donut
- countries: TN
- kinds: doughnut
- has Wikipedia article: en

## DISH Q2881895
- name: Andrajos
- description: stew from Spain
- countries: ES
- cuisines: Spanish cuisine
- kinds: stew
- ingredients: rabbit, pasta
- has Wikipedia article: en

## DISH Q2881969
- name: Cuchuflí
- description: Chilean biscuit roll
- countries: CL
- kinds: meal, biscuit, confectionery
- has Wikipedia article: en

## DISH Q28823854
- name: Rotterdams waterbroodje
- other names: {"nl": "Rotterdams waterbroodje"}
- countries: (none)
- kinds: floor-baked bread

## DISH Q28824213
- name: Siron
- description: a plate from the Black Sea Region of Turkey
- countries: TR
- kinds: dish
- has Wikipedia article: en

## DISH Q2882983
- name: Yemas de Santa Teresa
- description: Sweet made with egg yolk and sugar exclusively
- countries: ES
- kinds: dessert, pastry
- ingredients: syrup, lemon, Cinnamomum verum, egg yolk
- has Wikipedia article: en

## DISH Q28837710
- name: Shōyu
- description: soy sauce made in Japan
- countries: JP
- kinds: soy sauce
- ingredients: soy bean, wheat, table salt
- has Wikipedia article: en

## DISH Q2884071
- name: Huesos de san Expedito
- other names: {"es": "Huesos de san Expedito"}
- countries: ES
- kinds: dessert
- ingredients: masa, egg yolk, sugar

## DISH Q2884088
- name: Barbari bread
- other names: {"zh": "巴巴拉面包"}
- description: Iranian flatbread
- countries: IR
- kinds: food, flatbread
- ingredients: flour
- has Wikipedia article: en

## DISH Q2884225
- name: Barboton
- other names: {"fr": "Barboton"}
- countries: (none)
- kinds: potato dish

## DISH Q28843918
- name: Bokkeum-bap
- description: Korean fried rice
- countries: (none)
- kinds: fried rice
- ingredients: bap
- has Wikipedia article: en

## DISH Q2884589
- name: Bocadillo
- description: The bocadillo or bocata is a sandwich made with Spanish bread, usually a baguette or similar type of bread, cut lengthwise, sometimes seasoned with sauces like mayonnaise, aioli, ketchup, mustard or tomato sauce.
- countries: ES
- kinds: submarine sandwich
- has Wikipedia article: en

## DISH Q288511
- name: Tarak-juk
- description: milk porridge
- countries: (none)
- kinds: juk
- ingredients: milk, rice
- has Wikipedia article: en

## DISH Q2885517
- name: Nanaimo bar
- other names: {"zh": "纳奈莫条"}
- description: dessert
- countries: CA
- kinds: type of food or dish, dessert bar
- ingredients: coconut, ganache, wafer cookie, custard, nut
- has Wikipedia article: en, zh

## DISH Q2885532
- name: Barre marbrée
- other names: {"fr": "Barre marbrée"}
- countries: (none)
- kinds: cake

## DISH Q2885782
- name: Shmaky
- countries: (none)
- kinds: dish

## DISH Q2888124
- name: Milcao
- description: Chilean potato pancake
- countries: CL
- kinds: potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q2890029
- name: Charquicán
- description: stew consumed in the Andean region
- countries: BO, PE
- kinds: meal, stew, potato dish
- ingredients: Charqui
- has Wikipedia article: en

## DISH Q2890326
- name: Strawberries and cream
- description: typical English summer dessert
- countries: (none)
- kinds: dessert

## DISH Q2890574
- name: Karashizuke
- description: type of Japanese pickled vegetable
- countries: JP
- kinds: food, pickle
- ingredients: hot mustard
- has Wikipedia article: en

## DISH Q2891081
- name: Batata vada
- description: Indian vegetarian fast food in Maharashtra, India
- countries: IN
- kinds: Indian fast food, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q2891082
- name: Batata harra
- other names: {"zh": "中東海鮮 Harra"}
- description: Lebanese vegetable dish
- countries: LB
- kinds: potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q2892071
- name: Bauru
- description: Brazilian sandwich
- countries: BR
- cuisines: Brazilian cuisine
- kinds: sandwich
- has Wikipedia article: en

## DISH Q28922397
- name: Масляный баран
- other names: {"ru": "Масляный баран"}
- countries: (none)
- kinds: dish

## DISH Q2892320
- name: Panecillos de San Antón
- other names: {"es": "Panecillos de San Antón"}
- countries: ES
- kinds: dessert

## DISH Q2892364
- name: Rebojo
- other names: {"es": "Rebojo"}
- countries: ES
- kinds: dessert

## DISH Q2892592
- name: Cassola de tros de Juneda
- countries: (none)
- kinds: dish

## DISH Q2892954
- name: Matambre
- description: thin cut of beef in South American cuisine
- countries: AR
- cuisines: Argentine cuisine
- kinds: meal, beef dish
- has Wikipedia article: en

## DISH Q2893458
- name: Bechkito
- description: Moroccan biscuit
- countries: MA
- kinds: human food, biscuit

## DISH Q28936446
- name: Alexandrian Liver
- countries: EG
- kinds: food
- ingredients: garlic, tomato, onion, vinegar, table salt, liver

## DISH Q2893975
- name: Potato doughnut
- description: sweet potato-based treat
- countries: US
- kinds: doughnut, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q28944427
- name: Risotto alla certosina
- countries: (none)
- kinds: risotto

## DISH Q2894790
- name: Caldo de pimentón
- other names: {"es": "caldo de pimentón"}
- countries: (none)
- cuisines: cuisine of the province of Almería
- kinds: type of food or dish, soup

## DISH Q2895059
- name: Belokranjska povitica
- description: Slovenian dessert
- countries: SI
- kinds: food, cake
- ingredients: flour
- has Wikipedia article: en

## DISH Q2895095
- name: Salată de boeuf
- description: traditional Romanian dish
- countries: (none)
- kinds: salad, beef dish
- ingredients: beef
- has Wikipedia article: en

## DISH Q2895836
- name: Knickerbocker glory
- other names: {"zh": "高杯水果聖代"}
- description: type of ice cream
- countries: GB
- kinds: ice cream-based dessert
- ingredients: ice cream
- has Wikipedia article: en

## DISH Q2896056
- name: Bath bun
- description: sweet bun with segar sprinkles
- countries: GB
- kinds: sweet roll
- ingredients: sugar
- has Wikipedia article: en

## DISH Q2896075
- name: Sally Lunn bun
- description: sort of hot roll, first popular in Bath
- countries: GB
- kinds: bun
- has Wikipedia article: en

## DISH Q2896351
- name: Watergate salad
- description: type of salad
- countries: US
- kinds: dessert salad
- ingredients: pistachio pudding
- has Wikipedia article: en

## DISH Q2896374
- name: Scotch broth
- other names: {"zh": "蘇格蘭羊肉湯"}
- description: Scottish soup of barley, lamb, mutton or beef, root vegetables, and dried pulses
- countries: GB
- cuisines: Scottish cuisine
- kinds: lamb dish, soup
- ingredients: barley, lamb meat
- has Wikipedia article: en

## DISH Q28966859
- name: Garlic clove
- description: part of garlic contained within a garlic bulb
- countries: (none)
- kinds: food ingredient, vegetable, finger food

## DISH Q2897203
- name: Berkoukes
- description: dish
- countries: (none)
- kinds: dish
- ingredients: semolina, spice, vegetable
- has Wikipedia article: en

## DISH Q2897288
- name: Berlingot de Carpentras
- countries: (none)
- kinds: candy, Berlingot

## DISH Q2897290
- name: Berlingot nantais
- other names: {"fr": "berlingot nantais"}
- countries: (none)
- kinds: food, Berlingot

## DISH Q2899201
- name: Rousong
- other names: {"zh": "肉松"}
- description: dried meat product from China
- countries: CN, JP
- kinds: Tsukudani, dish
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q2900293
- name: 貝歇爾 (餐點)
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q2900923
- name: Candy pumpkin
- other names: {"zh": "南瓜糖"}
- description: pumpkin-shaped creme confection
- countries: US
- kinds: confectionery
- ingredients: corn syrup
- has Wikipedia article: en, zh

## DISH Q2901547
- name: Shumai
- other names: {"zh": "烧卖"}
- description: type of traditional Chinese dumpling
- countries: CN
- kinds: stuffed pasta, pork dish, food
- ingredients: minced meat
- has Wikipedia article: en, zh

## DISH Q2901605
- name: Fermented bean curd
- other names: {"zh": "腐乳"}
- description: Chinese condiment consisting of a form of processed, preserved tofu used in East Asian cuisine
- countries: CN
- kinds: tofu, fermented food, vegan cheese, food
- ingredients: mycelium, tofu
- has Wikipedia article: en, zh

## DISH Q29017361
- name: Chǎofàn
- other names: {"zh": "中式炒饭"}
- description: Chinese fried rice
- countries: CN
- kinds: fried rice
- ingredients: cooked rice
- has Wikipedia article: en

## DISH Q29019737
- name: Clam soup
- description: soup prepared with clams
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q29019793
- name: Clam pie
- description: savory meat pie prepared using clams
- countries: (none)
- kinds: dish, meat pie, clam dish
- ingredients: meat
- has Wikipedia article: en

## DISH Q2902203
- name: Salted duck egg
- other names: {"zh": "咸鸭蛋"}
- description: traditional Asian dish common in several regions
- countries: (none)
- kinds: food, egg dish
- ingredients: duck egg
- has Wikipedia article: en, zh

## DISH Q290233
- name: Spanisch Brötli
- description: speciality pastry from Baden, Switzerland
- countries: CH
- kinds: pastry
- has Wikipedia article: en

## DISH Q2902532
- name: Zagorski štrukli
- description: type of Dish
- countries: HR
- kinds: dish
- has Wikipedia article: en

## DISH Q29032645
- name: Vannkringle
- other names: {"nb": "vannkringle"}
- countries: (none)
- kinds: kringle, pastry
- ingredients: yeast, flour, butter, milk, water

## DISH Q2903643
- name: Helzel
- description: stuffed poultry neck skin
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q29043105
- name: Sweet confectionery products (ОКП 91 2000)
- countries: (none)
- kinds: chocolate and sugar confectionery, Production of food industry by OKP

## DISH Q2904639
- name: Biscuit rose de Reims
- other names: {"zh": "兰斯玫瑰饼干"}
- description: French pastries
- countries: FR
- kinds: biscuit, culinary speciality
- has Wikipedia article: en, zh

## DISH Q29048545
- name: Dosirak
- other names: {"zh": "韓式便當"}
- description: packed meal
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q2904894
- name: Miga sandwich
- other names: {"zh": "托斯塔德"}
- description: popular food item in Uruguay and Argentina
- countries: (none)
- kinds: sandwich
- ingredients: white bread, lettuce, green pepper, tomato, ham, egg as food, cheese
- has Wikipedia article: en

## DISH Q2905116
- name: Bjawia
- description: Tunisian pastry
- countries: TN
- kinds: pastry
- ingredients: pistachio nut, hazelnut, walnut, almond

## DISH Q2905196
- name: Mulukhiyah
- other names: {"zh": "黄麻燉湯"}
- description: Egyptian dish
- countries: (none)
- kinds: dish
- ingredients: garlic, coriander seed, broth, Corchorus olitorius
- has Wikipedia article: en

## DISH Q2905237
- name: Pkaila
- description: Judeo-Tunisian dish
- countries: TN
- kinds: dish
- has Wikipedia article: en

## DISH Q29052719
- name: Bierkäse
- description: German cheese made from cow's milk
- countries: DE
- kinds: cheese, dairy product, cow's-milk cheese, German cheese

## DISH Q2906012
- name: Tklapi
- description: Georgian fruit leather
- countries: GE
- kinds: fruit leather, food
- ingredients: Prunus domestica
- has Wikipedia article: en

## DISH Q2906052
- name: Gribenes
- description: Ashkenazi Jewish dish
- countries: DE
- cuisines: Jewish cuisine
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q2906124
- name: Blanke doreye
- other names: {"fr": "Blanke doreye"}
- countries: (none)
- kinds: sweet pie

## DISH Q2906471
- name: Bleu d'Élizabeth
- description: blue cheese from Quebec
- countries: CA
- kinds: blue cheese, cheese from Quebec
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q2907412
- name: Malawach
- other names: {"zh": "马拉瓦赫"}
- description: Israeli version of the Yemeni flatbread
- countries: IL, YE
- kinds: food, bread
- ingredients: smen, puff pastry, table salt, sugar, margarine
- has Wikipedia article: en, zh

## DISH Q2908226
- name: Bobó de camarão
- description: Brazilian shrimp chowder
- countries: BR
- cuisines: Brazilian cuisine
- kinds: fish soup, shrimp dish
- has Wikipedia article: en

## DISH Q2908820
- name: Bohémienne
- description: French dish in a Provencial style of tomatoes and olive oil
- countries: (none)
- kinds: dish
- ingredients: eggplant

## DISH Q2909230
- name: Bokit
- description: Guadeloupean sandwich
- countries: (none)
- kinds: sandwich
- has Wikipedia article: en

## DISH Q2909959
- name: Bonbon coco
- description: Malagasy dessert
- countries: MG
- kinds: confectionery

## DISH Q2909961
- name: Bonbon la rouroute
- description: pastry from Reunion
- countries: FR
- kinds: pastry

## DISH Q2909963
- name: Bonbons piment
- countries: (none)
- kinds: culinary speciality

## DISH Q2911386
- name: Borzgane
- description: type of couscous
- countries: TN
- kinds: couscous

## DISH Q2911553
- name: Rat na
- other names: {"zh": "辣那"}
- description: Thai-Chinese noodle dish
- countries: TH
- cuisines: Thai cuisine
- kinds: noodle dish
- ingredients: gai lan, tapioca, noodle
- has Wikipedia article: en

## DISH Q2915389
- name: Karpas
- description: one of the traditional rituals in the Passover Seder
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q2915502
- name: Jellied eels
- other names: {"zh": "鳝鱼冻"}
- description: traditional English dish
- countries: GB
- kinds: dish
- ingredients: Anguilliformes
- has Wikipedia article: en, zh

## DISH Q2915519
- name: Marshmallow creme
- description: confectionery spread made from marshmallow
- countries: US
- kinds: food, confectionery
- ingredients: flavor enhancer, egg white, corn syrup, sugar
- has Wikipedia article: en

## DISH Q2915599
- name: Compound chocolate
- description: inexpensive chocolate substitute that uses cocoa but excludes cocoa butter
- countries: (none)
- kinds: chocolate, ingredient
- ingredients: cocoa powder
- has Wikipedia article: en

## DISH Q2915670
- name: Sablé
- description: type of shortbread cookie of French origin
- countries: FR
- kinds: cookie, sandie
- ingredients: shortbread, citron, egg as food, flour, butter, vanilla, sugar
- has Wikipedia article: en

## DISH Q2915859
- name: Fettuccine Alfredo
- other names: {"zh": "奶油白醬寬版麵"}
- description: pasta dish made from fettuccine tossed with Parmesan cheese and butter
- countries: IT, US
- cuisines: Italian-American cuisine
- kinds: pasta dish, dish
- ingredients: Alfredo sauce, Parmesan, butter, fettuccine
- has Wikipedia article: en, zh

## DISH Q2916159
- name: Ambrosia
- description: type of fruit salad originating in the southern United States, consisting of pineapple, orange, miniature marshmallows and coconut
- countries: US
- cuisines: cuisine of the Southern United States
- kinds: fruit salad
- ingredients: pineapple, coconut, marshmallow
- has Wikipedia article: en

## DISH Q2916235
- name: Piyaz
- description: Turkish cuisine cold dish (meze or salad)
- countries: IQ, IR, TR
- cuisines: Turkish cuisine
- kinds: salad, dish
- ingredients: Phaseolus, onion
- has Wikipedia article: en

## DISH Q2917139
- name: Peanut butter, banana and bacon sandwich
- other names: {"zh": "花生酱香蕉三明治"}
- description: type of sandwich
- countries: US
- kinds: sandwich
- ingredients: peanut butter, bacon, bread, banana
- has Wikipedia article: en, zh

## DISH Q2917512
- name: Frixuelu
- other names: {"ast": "Frixuelu"}
- countries: ES
- kinds: dessert

## DISH Q2917730
- name: Crema de frijoles
- description: Colombian dish
- countries: (none)
- kinds: dish

## DISH Q2917846
- name: Black bun
- description: type of fruit cake associated with Scotland
- countries: (none)
- kinds: food, fruitcake
- has Wikipedia article: en

## DISH Q2918079
- name: Falooda
- other names: {"zh": "法鲁达"}
- description: liquid dessert
- countries: IR
- cuisines: Indian cuisine, Afghan cuisine, Pakistani cuisine, Iranian cuisine
- kinds: dessert, food
- ingredients: rose water, Ocimum, vermicelli, milk
- has Wikipedia article: en, zh

## DISH Q2918182
- name: Chicken lollipop
- other names: {"zh": "棒棒鸡锤"}
- description: fried chicken appetizer from Indo-Chinese cuisine
- countries: IN, PK
- kinds: appetizer, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q2918385
- name: Arctic roll
- description: British dessert
- countries: GB
- kinds: dessert
- ingredients: sponge cake
- has Wikipedia article: en

## DISH Q2918637
- name: Sweet and sour chicken
- description: dish in Chinese cuisine
- countries: (none)
- kinds: food, dish

## DISH Q2918809
- name: Parkin
- other names: {"zh": "Parkin蛋糕"}
- description: gingerbread cake
- countries: GB
- kinds: cake
- ingredients: flour
- has Wikipedia article: en

## DISH Q2919934
- name: Sou
- other names: {"zh": "酥"}
- description: type of food pastry
- countries: CN
- kinds: food, pastry
- has Wikipedia article: en, zh

## DISH Q2919985
- name: Cacasse à cul nu
- description: French dish
- countries: FR
- kinds: dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q2920132
- name: Shoti
- other names: {"zh": "肖提斯普里"}
- description: type of traditional Georgian bread
- countries: GE
- kinds: bread, dish
- ingredients: wheat, flour
- has Wikipedia article: en, zh

## DISH Q2920546
- name: Dulce de batata
- description: sweet potato jelly
- countries: AR, UY, PY
- cuisines: Argentine cuisine, Uruguayan cuisine, Paraguayan cuisine
- kinds: dessert
- ingredients: Sweet potato
- has Wikipedia article: en

## DISH Q2920963
- name: Stew
- other names: {"zh": "燉煮"}
- description: combination of solid food ingredients that have been cooked in liquid and served in the resultant gravy
- countries: FR
- kinds: food, dish, meat dish, type of food or dish
- ingredients: vegetable
- has Wikipedia article: en, zh

## DISH Q2921228
- name: Regeringsbrood
- description: war bread from the Netherlands
- countries: (none)
- kinds: bread

## DISH Q29214
- name: Sheet cake
- description: flat rectangular cake; cake baked in a large, flat rectangular pan
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q2921630
- name: Awara broth
- description: Creole stew with pork, chicken, seafood and vegetables
- countries: FR
- kinds: main course
- ingredients: Astrocaryum vulgare
- has Wikipedia article: en

## DISH Q2921757
- name: Boulette de Huy
- other names: {"fr": "boulette de Huy"}
- countries: BE
- kinds: list of Belgian cheeses, washed-rind cheese, cheese
- ingredients: cow's milk

## DISH Q2922200
- name: Bouneschlupp
- other names: {"zh": "豆子羹"}
- description: European bean soup
- countries: LU
- kinds: food, soup
- ingredients: green bean
- has Wikipedia article: en

## DISH Q2922222
- name: Boûkète
- other names: {"zh": "荞麦煎饼"}
- description: Belgian pancake
- countries: BE
- cuisines: cuisine of Belgium
- kinds: food, pancake
- ingredients: buckwheat seed
- has Wikipedia article: en

## DISH Q2922424
- name: Bourriquette
- other names: {"ca": "bourriquette"}
- countries: (none)
- kinds: dish

## DISH Q2923090
- name: Boîte bœuf
- other names: {"fr": "Boîte bœuf"}
- countries: FR
- kinds: food, beef, preserved food

## DISH Q2923736
- name: Brandon
- other names: {"fr": "brandon"}
- countries: FR
- kinds: dessert

## DISH Q2923932
- name: Brasillé
- description: French pastry
- countries: FR
- kinds: pastry

## DISH Q2924275
- name: Bredela
- description: biscuits or small cakes traditionally baked in Alsace and Moselle (France), especially during the Christmas period
- countries: FR
- kinds: biscuit
- has Wikipedia article: en

## DISH Q2924835
- name: Briám
- description: traditional roasted vegetable dish
- countries: (none)
- kinds: dish

## DISH Q2925603
- name: Brioche tressée de Metz
- description: braided sweet bread
- countries: (none)
- kinds: sweet bread

## DISH Q2925658
- name: Brissaouda
- description: culinary specialty of the Nice region and Provence
- countries: FR
- kinds: dish
- ingredients: garlic, olive oil, bread

## DISH Q2926295
- name: Brouet
- description: Meal, similar to a stew
- countries: (none)
- kinds: stew, dish
- ingredients: pork, sodium chloride, water

## DISH Q2926353
- name: Broyé du Poitou
- description: French pastry
- countries: FR
- kinds: pastry
- ingredients: chicken egg, wheat flour, butter, sugar
- has Wikipedia article: en

## DISH Q2927250
- name: Brânzoaică
- description: Romanian cheesecake
- countries: MD, RO
- kinds: cake

## DISH Q2927288
- name: Bréjaude
- other names: {"ca": "Bréjaude"}
- countries: (none)
- kinds: soup

## DISH Q2930178
- name: Bûche du Poitou
- countries: FR
- kinds: goat cheese, industrial cheese, natural-rind soft cheese, French cheese
- ingredients: goat milk

## DISH Q29310616
- name: Nervetti
- description: Italian meat salad
- countries: IT
- kinds: meat dish

## DISH Q29319464
- name: Maccheroni al pettine
- countries: (none)
- cuisines: Emilian cuisine, cuisine of the province of Modena
- kinds: type of pasta

## DISH Q2932523
- name: Cachelo
- other names: {"ca": "Cachelo"}
- countries: ES
- cuisines: Galician cuisine
- kinds: potato dish
- ingredients: potato, table salt

## DISH Q29326
- name: Kransekake
- description: traditional Danish and Norwegian dessert
- countries: DK
- cuisines: Norwegian cuisine, Danish cuisine
- kinds: cake
- ingredients: Prunus dulcis
- has Wikipedia article: en

## DISH Q2933003
- name: Café gourmand
- description: French culinary concept
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q29340
- name: Sweet bean paste
- other names: {"zh": "豆沙"}
- description: bean paste used in several Asian cuisines
- countries: (none)
- kinds: bean paste
- has Wikipedia article: en, zh

## DISH Q2934403
- name: Caltaboș
- description: Romanian liver-based pork sausage
- countries: RO
- kinds: sausage, food product, pork dish
- ingredients: pork, offal, rice

## DISH Q2936147
- name: Canard aux navets
- other names: {"fr": "canard aux navets"}
- countries: FR
- kinds: dish
- ingredients: turnip, onion, duck meat, butter

## DISH Q2936148
- name: Canard braisé aux Montmorency
- other names: {"fr": "canard braisé aux Montmorency"}
- countries: (none)
- kinds: dish
- ingredients: Montmorency cherry, leek, bouquet garni, duck meat, butter, red wine

## DISH Q2936377
- name: Canino PDO
- other names: {"zh": "Canino DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q2936423
- name: Cannibal
- description: Belgian dish consisting of toast and filet américain
- countries: (none)
- kinds: open sandwich
- ingredients: filet américain, toast

## DISH Q2936936
- name: Caobing
- other names: {"fr": "Caobing"}
- countries: (none)
- kinds: pastry

## DISH Q2937880
- name: Carapaus alimados
- description: Portuguese fish dish
- countries: PT
- kinds: fish dish
- ingredients: Atlantic horse mackerel

## DISH Q2937886
- name: Tapir casero de marte
- description: Andean stew
- countries: PE
- kinds: food, dish, meal
- has Wikipedia article: en

## DISH Q2937940
- name: Carbonada
- description: dish of Italian cuisine
- countries: (none)
- kinds: dish
- ingredients: beef

## DISH Q2938776
- name: Caricole
- countries: BE
- kinds: snail as food, dish
- ingredients: common periwinkle

## DISH Q2939736
- name: Carne de porco à alentejana
- other names: {"zh": "阿连特茹猪肉炖蛤蜊"}
- description: Portuguese dish of pork, clams, potatoes and coriander
- countries: PT
- kinds: pork dish
- ingredients: potato, clam, pork, Coriandrum sativum
- has Wikipedia article: en

## DISH Q2939742
- name: Carne-de-sol
- description: Beef dish from northeastern Brazil
- countries: BR
- kinds: beef dish
- has Wikipedia article: en

## DISH Q2940105
- name: Carotte de Créances
- other names: {"fr": "Carotte de Créances"}
- countries: (none)
- kinds: carrot

## DISH Q2940387
- name: Carré de Salers
- other names: {"fr": "Carré de Salers"}
- countries: FR
- kinds: biscuit

## DISH Q2941218
- name: Casse-Croûte
- description: traditional Belgian cheese
- countries: BE
- kinds: cheese

## DISH Q29415
- name: Angel food cake
- other names: {"zh": "天使蛋糕"}
- description: type of sponge cake
- countries: US
- cuisines: cuisine of the United States
- kinds: sponge cake
- ingredients: egg white, flour, sugar
- has Wikipedia article: en, zh

## DISH Q2943124
- name: Causa a la limeña
- description: Peruvian dish
- countries: PE
- kinds: potato dish
- has Wikipedia article: en

## DISH Q2943475
- name: Cazuela
- description: South American dishes cooked in shallow unglazed earthenware
- countries: (none)
- kinds: meal, food, soup
- ingredients: stock
- has Wikipedia article: en

## DISH Q2944132
- name: Sneeuwbal
- other names: {"nl": "sneeuwbal"}
- countries: (none)
- kinds: pastry

## DISH Q29443
- name: Pound cake
- other names: {"zh": "磅蛋糕"}
- description: type of cake traditionally made with a pound of flour, butter, eggs, and sugar
- countries: (none)
- kinds: butter cake
- ingredients: egg as food, flour, butter, sugar
- has Wikipedia article: en, zh

## DISH Q29467976
- name: Shooter's sandwich
- description: steak sandwich of English origin
- countries: (none)
- kinds: sandwich
- has Wikipedia article: en

## DISH Q29468984
- name: Lemon duck
- other names: {"zh": "檸檬鴨"}
- description: Duck dish
- countries: CN
- kinds: food, duck dish
- has Wikipedia article: en, zh

## DISH Q29477
- name: Devil's food cake
- other names: {"zh": "恶魔蛋糕"}
- description: moist, airy, rich chocolate layer cake
- countries: US
- kinds: chocolate cake, butter cake, layer cake
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q2948542
- name: Champ
- other names: {"zh": "愛爾蘭薯泥"}
- description: Irish dish
- countries: IE
- kinds: potato dish
- ingredients: scallion, mashed potato, butter, milk
- has Wikipedia article: en

## DISH Q295568
- name: Dobos torte
- other names: {"zh": "多層蛋糕"}
- description: Hungarian cake
- countries: HU
- kinds: torte, sponge cake
- ingredients: lemon juice, sponge cake, powdered sugar, rum, vanilla, chocolate
- has Wikipedia article: en, zh

## DISH Q2956338
- name: Chanteclair (gâteau)
- other names: {"fr": "Chanteclair (gâteau)"}
- countries: (none)
- kinds: cake
- ingredients: meringue

## DISH Q2957687
- name: Meat pastry
- countries: (none)
- kinds: dish, pastry
- ingredients: pastry dough, meat

## DISH Q2961907
- name: Chebakia
- description: North African pastry
- countries: (none)
- kinds: dish, pastry
- ingredients: almond meal, Sesamum indicum, egg as food, honey
- has Wikipedia article: en

## DISH Q2963355
- name: Shish taouk
- description: dish of Levantine cuisine, skewers of marinated chicken pieces
- countries: TR
- kinds: skewer, kebab, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q2963406
- name: Belgian endive with ham
- description: Dutch, Belgian, and northern French dish
- countries: (none)
- kinds: dish

## DISH Q2963566
- name: Chikwangue
- description: African cassava dish
- countries: CM
- kinds: dish
- has Wikipedia article: en

## DISH Q2963638
- name: Chimacien
- other names: {"fr": "Chimacien"}
- countries: (none)
- kinds: cake

## DISH Q2963783
- name: Chinois (pastry)
- countries: (none)
- kinds: pastry

## DISH Q29642090
- name: Tsilihourda
- description: Greek lamb offal soup associated with Easter from Corfu
- countries: GR
- kinds: food, soup, meat dish
- ingredients: dill, peppercorn, lamb meat, Tordylium apulum, garden chervil, Lactuca sativa, rice

## DISH Q2964251
- name: Chochoca
- description: Chilean dish
- countries: CL
- kinds: potato dish
- has Wikipedia article: en

## DISH Q2964269
- name: Belgian chocolate
- description: chocolate produced in Belgium
- countries: BE
- cuisines: cuisine of Belgium
- kinds: types of chocolate, chocolate
- has Wikipedia article: en

## DISH Q2964495
- name: Dchicha
- description: Algerian soup
- countries: DZ
- kinds: type of food or dish, soup

## DISH Q2967557
- name: Chtitha
- description: dish in Algerian cuisine
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q2967656
- name: Chupe
- other names: {"zh": "丘佩"}
- description: variety of stew
- countries: (none)
- kinds: meal, soup, potato dish
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q296867
- name: Ölbrot
- description: German term, outdated indicator of the production of a major component of the ink
- countries: (none)
- kinds: concept, substance, indicator, bread

## DISH Q2971383
- name: Gata
- description: traditional Armenian sweet pastry
- countries: AM
- kinds: food, pastry
- has Wikipedia article: en

## DISH Q29730484
- name: Накрёпок
- other names: {"ru": "накрёпок"}
- countries: RU
- kinds: pirog

## DISH Q2973283
- name: Sea-pie
- description: North American dish
- countries: (none)
- kinds: food, pie
- has Wikipedia article: en

## DISH Q2973291
- name: Cipolla Rossa di Tropea Calabria PGI
- other names: {"zh": "Cipolla Rossa di Tropea Calabria IGP"}
- description: Italian PGI fruit, vegetable or cereal product
- countries: IT
- kinds: red onion, agricultural product, onion

## DISH Q2974872
- name: Jugging
- other names: {"zh": "陶罐燉煮"}
- description: cooking process
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q2975676
- name: Cock-a-leekie soup
- description: Scottish soup dish consisting of leeks and peppered chicken stock, often thickened with rice, or sometimes barley
- countries: GB
- cuisines: Scottish cuisine
- kinds: soup, dish, chicken dish
- ingredients: leek, broth
- has Wikipedia article: en

## DISH Q2981206
- name: Coca de patata
- other names: {"ca": "coca de patata"}
- countries: (none)
- kinds: potato dish
- ingredients: potato, wheat flour, egg as food, lard, oil, sugar, water

## DISH Q2981323
- name: Coco Boer
- countries: FR
- kinds: food, candy, sweetmeat
- ingredients: liquorice

## DISH Q2982356
- name: Colatura di Alici
- description: Italian fish sauce made from anchovies fermented in brine
- countries: IT
- kinds: fish sauce
- has Wikipedia article: en

## DISH Q29840885
- name: Chocolate bunny
- description: piece of chocolate in the shape of a rabbit
- countries: (none)
- kinds: confectionery
- ingredients: chocolate
- has Wikipedia article: en

## DISH Q2984163
- name: Colombier
- description: traditional French cake
- countries: FR
- kinds: pastry

## DISH Q2984188
- name: Colonel
- other names: {"fr": "Colonel"}
- countries: (none)
- kinds: frozen dessert
- ingredients: lemon sorbet, vodka

## DISH Q2984414
- name: Uirō
- other names: {"zh": "外郎"}
- description: Japanese steamed cake
- countries: JP
- kinds: cake, mochi, wagashi
- ingredients: rice flour, flour
- has Wikipedia article: en, zh

## DISH Q2984652
- name: Asida
- description: common dish in Maghreb and the Middle East
- countries: (none)
- kinds: porridge, pudding
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q2985347
- name: Vada pav
- description: Maharashtrian vegetarian street-food sandwich originating in Mumbai
- countries: IN
- cuisines: Maharashtrian cuisine
- kinds: type of food or dish, sandwich, fast food, snack, street food
- ingredients: Batata vada, bread roll
- has Wikipedia article: en

## DISH Q2986506
- name: Faloodeh
- description: persian dessert
- countries: IR
- kinds: food, sorbet
- ingredients: vermicelli
- has Wikipedia article: en

## DISH Q29886971
- name: Satsebeli
- description: Georgian tomato sause
- countries: GE
- kinds: sauce, human food
- ingredients: spice, tomato, Allium sativum
- has Wikipedia article: en

## DISH Q29887669
- name: Stuffed mushrooms
- description: Culinary dish or snack
- countries: FR
- cuisines: French cuisine
- kinds: dish, stuffed vegetable, mushroom dish
- ingredients: edible mushroom
- has Wikipedia article: en

## DISH Q29887670
- name: Sautéed mushrooms
- description: dish
- countries: (none)
- kinds: dish, mushroom dish
- ingredients: cooking alcohol, edible fats and oils, edible mushroom
- has Wikipedia article: en

## DISH Q29920362
- name: Julienne
- description: Russian appetizer of mushrooms and poultry
- countries: RU
- kinds: zakuski, dish, meat dish, mushroom dish
- ingredients: cheese
- has Wikipedia article: en

## DISH Q2992507
- name: Flower jam
- description: jam made from flowers
- countries: (none)
- kinds: jam, confit

## DISH Q2993015
- name: Congri
- other names: {"fr": "congri"}
- countries: (none)
- kinds: dish

## DISH Q2993311
- name: Barmbrack
- description: Irish tradition for Samhain
- countries: IE
- kinds: raisin bread, traditional food, yeast bread
- ingredients: sultana
- has Wikipedia article: en

## DISH Q29933566
- name: Long egg
- description: cylindrical boiled egg
- countries: DK
- kinds: food, dish, hard-boiled egg
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q29944665
- name: Guljeot
- description: Korean side dish
- countries: (none)
- kinds: jeotgal
- ingredients: oyster
- has Wikipedia article: en

## DISH Q2996033
- name: Salceson
- description: Central and Eastern European sausage
- countries: PL, BY
- cuisines: Polish cuisine, Belarusian cuisine
- kinds: head cheese, sulze
- ingredients: offal
- has Wikipedia article: en

## DISH Q2996393
- name: Conversation tart
- description: French pastry
- countries: FR
- kinds: tart
- ingredients: frangipane, almond, royal icing, puff pastry
- has Wikipedia article: en

## DISH Q2996854
- name: Coppia Ferrarese PGI
- other names: {"zh": "Coppia Ferrarese IGP"}
- description: Italian PGI bakery product
- countries: IT
- kinds: baked good, food, sourdough bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q2996890
- name: Coq au Riesling
- description: Alsatian version of coq au vin
- countries: FR
- kinds: coq au vin
- ingredients: Riesling wine, onion, lardon, chicken as food, edible mushroom

## DISH Q2996892
- name: Coq au vin de chanturgue
- countries: (none)
- kinds: coq au vin

## DISH Q2996903
- name: Artos
- description: bread
- countries: (none)
- kinds: Easter bread
- ingredients: sourdough
- has Wikipedia article: en

## DISH Q2996921
- name: Coquelicot de Nemours
- other names: {"fr": "Coquelicot de Nemours"}
- countries: (none)
- kinds: confectionery

## DISH Q2996947
- name: Coquilles Saint-Jacques à l'albariño
- other names: {"fr": "Coquilles Saint-Jacques à l'albariño"}
- countries: (none)
- kinds: dish

## DISH Q2996948
- name: Coquillette
- other names: {"fr": "coquillette"}
- description: pasta
- countries: (none)
- kinds: pasta

## DISH Q2997013
- name: Coratella
- description: Small animal offal
- countries: IT
- cuisines: Roman cuisine
- kinds: offal dish

## DISH Q2997592
- name: Cornuleţe
- description: Stuffed Christmas pastry
- countries: RO
- kinds: cake
- ingredients: Turkish delight
- has Wikipedia article: en

## DISH Q2998566
- name: 奥尔良小黄瓜酱
- countries: FR
- cuisines: French cuisine
- kinds: confectionery, marmalade
- ingredients: sugar, quince

## DISH Q2998704
- name: Coucougnette
- description: confection made with almonds, marzipan, and chocolate
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q2998748
- name: Couilles de mouton
- other names: {"fr": "couilles de mouton"}
- countries: FR
- kinds: dish
- ingredients: testicle

## DISH Q29994343
- name: Glutinous rice cake
- description: rice cakes made with glutinous rice
- countries: (none)
- kinds: rice cake

## DISH Q30004878
- name: Tarte aux pralines
- countries: FR
- kinds: dessert, tart
- ingredients: praline

## DISH Q30005082
- name: Gachas manchegas estilo la Josefa
- other names: {"es": "gachas manchegas estilo la Josefa"}
- description: food preparation
- countries: ES
- kinds: dish, gachas
- ingredients: Lathyrus sativus, Allium sativum, bacon

## DISH Q30011777
- name: Albap
- other names: {"zh": "魚卵飯"}
- description: roe bibimbap
- countries: (none)
- kinds: bibimbap
- ingredients: bap
- has Wikipedia article: en, zh

## DISH Q3001487
- name: Court-bouillon
- description: quick broth
- countries: FR
- kinds: fish dish
- ingredients: brine, peppercorn, bouquet garni, vinegar, onion, table salt, white wine, red wine, carrot
- has Wikipedia article: en

## DISH Q3001611
- name: Couve
- other names: {"fr": "couve"}
- countries: (none)
- kinds: cake

## DISH Q3001949
- name: Soft-shell crab
- other names: {"zh": "軟殼蟹"}
- description: culinary term for molted crabs
- countries: (none)
- kinds: crab dish
- has Wikipedia article: en, zh

## DISH Q3002088
- name: Kramiek
- description: sweet milk bread filled with raisins
- countries: BE
- kinds: brioche
- ingredients: raisin

## DISH Q3002488
- name: Crespéou
- description: savory Provençal cake
- countries: FR
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q3002684
- name: Crique
- description: French potato dish
- countries: (none)
- kinds: potato dish

## DISH Q3002792
- name: Crisp sandwich
- other names: {"zh": "脆三明治"}
- description: sandwich that includes potato chips (crisps) as one of the fillings
- countries: GB
- kinds: potato dish, sandwich
- ingredients: potato chip, bread
- has Wikipedia article: en

## DISH Q30033148
- name: Kartoffelkager
- countries: DK
- kinds: pastry

## DISH Q3003697
- name: Cromesquis
- countries: FR
- cuisines: French cuisine
- kinds: dish

## DISH Q3003734
- name: Croquet
- other names: {"fr": "Croquet"}
- countries: (none)
- kinds: Croquants

## DISH Q3005443
- name: Tourtière
- countries: (none)
- kinds: pastry
- ingredients: pastry

## DISH Q3005446
- name: Crouzets
- countries: (none)
- kinds: pasta

## DISH Q3005487
- name: Crozets de Savoie
- description: small flat square-shaped pasta
- countries: FR
- cuisines: French cuisine
- kinds: pasta
- ingredients: wheat, chicken egg
- has Wikipedia article: en

## DISH Q3005490
- name: Croziflette
- other names: {"fr": "Croziflette"}
- countries: FR
- kinds: Tartiflette variant, dish

## DISH Q3006036
- name: Chiboust cream
- other names: {"zh": "希布斯特奶油"}
- description: crème pâtissière (pastry cream) lightened with Italian meringue
- countries: FR
- kinds: custard, pastry cream
- ingredients: Italian meringue, pastry cream
- has Wikipedia article: en

## DISH Q3006043
- name: Bresse butter
- description: butter from the Bresse region, France
- countries: FR
- kinds: butter, cream
- ingredients: cow's milk

## DISH Q3006051
- name: Mousseline cream
- description: genre of pastry cream
- countries: (none)
- kinds: pastry cream
- ingredients: pastry cream, butter

## DISH Q3006332
- name: Crêpe vonnassienne
- countries: FR
- kinds: crêpe, potato dish
- ingredients: mashed potato

## DISH Q3006731
- name: Cuchaule
- description: Swiss brioche-type bread
- countries: CH
- kinds: bread
- ingredients: flour, butter, saffron

## DISH Q3006733
- name: Cuchuco
- description: Staple food in Colombia
- countries: CO
- kinds: food, soup
- has Wikipedia article: en

## DISH Q3007617
- name: Curanto
- description: Chilean dish of seafood and potatoes cooked using heated rocks buried in an earth oven covered with pangue leaves and turf
- countries: CL
- kinds: meal, potato dish, seafood dish
- ingredients: potato
- has Wikipedia article: en
