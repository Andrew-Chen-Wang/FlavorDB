# Review batch names-005

## DISH Q107657222
- name: Narkel diye Shapla
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107657255
- name: Ol er tok
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107657284
- name: Ol vapa
- description: Bengali cuisine
- countries: (none)
- kinds: Bhapa

## DISH Q107657320
- name: Kochu Fuler Pakora
- description: Bengali cuisine
- countries: (none)
- kinds: pakora

## DISH Q107657331
- name: Ol shaager bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q107657349
- name: Pui Shaker Bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q107665302
- name: Bora
- description: Meitei Manipuri ethnic food item
- countries: (none)
- cuisines: Meitei cuisine
- kinds: dish

## DISH Q107674774
- name: Gordon Ramsay's Beef Wellington
- description: dish by Gordon Ramsay
- countries: (none)
- kinds: dish
- ingredients: Beef Wellington

## DISH Q107674870
- name: Tacos de cabeza
- description: tacos made with cabeza
- countries: MX
- kinds: dish
- ingredients: Cabeza, taco

## DISH Q107682259
- name: Misti alu vaja
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q1076824
- name: Chowder
- other names: {"zh": "巧達濃湯"}
- description: category of soups
- countries: US
- cuisines: cuisine of the United States
- kinds: soup, stew
- ingredients: seafood
- has Wikipedia article: en, zh

## DISH Q107682965
- name: Brahmi shaag ghee diye vaja
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107682988
- name: Brahmi Shaag Pakora
- description: Bengali cuisine
- countries: (none)
- kinds: pakora

## DISH Q107683020
- name: Begun bori diye betho saag
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107683045
- name: Note Shaag Ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q107683083
- name: Motor shaker charchari
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q107683146
- name: Kolmi shaaker chorchori
- description: bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q107683155
- name: Kolmi shaaker ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: Ghanto

## DISH Q107683778
- name: Kolmi shaaker pokoda
- description: Bengali cuisine
- countries: (none)
- kinds: pakora

## DISH Q107683974
- name: Aar machher kalia
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q107689195
- name: Cooked glutinous rice
- other names: {"zh": "糯米饭"}
- countries: (none)
- kinds: cooked rice
- ingredients: glutinous rice

## DISH Q107693925
- name: Red bean rice
- other names: {"zh": "紅豆飯"}
- description: rice cooked with red beans
- countries: (none)
- kinds: cooked rice, azuki bean based food
- ingredients: Vigna angularis, rice
- has Wikipedia article: en, zh

## DISH Q107695269
- name: Cooked grain
- other names: {"zh": "飯"}
- description: cooked rice and/or other grains as the staple food, or a meal
- countries: (none)
- kinds: cereal, dish, meal, food
- has Wikipedia article: zh

## DISH Q107695675
- name: Shʿifūra
- description: Syrian vegetarian dish
- countries: SY
- kinds: salad
- ingredients: onion, Shanklish, olive oil, tomato
- has Wikipedia article: en

## DISH Q107718213
- name: Pizzas with shrimp or prawns
- description: dish
- countries: IT
- ingredients: shrimp

## DISH Q107722188
- name: Ilish machher matha diye kochu shaag
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q107722376
- name: Dumur Chingri
- description: bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q107722388
- name: Dumurer dalna
- description: bengali cuisine
- countries: (none)
- kinds: dalna, vegetable dish

## DISH Q107724036
- name: Gadal Patar Bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada
- ingredients: Paederia foetida, table salt

## DISH Q107724085
- name: Gadal pata bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107724124
- name: Pepe alu diye gadal patar torkari
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107724335
- name: Gandal Patar Jhol
- description: bengali cuisine
- countries: (none)
- kinds: Jhol

## DISH Q107724548
- name: Kulekhara patar bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q107724609
- name: Lau pata bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107736395
- name: Apapa ( Beans Loaf )
- description: Ebira local delicacy specially prepared with grounded beans,red oil, maggi and other nutritional ingredients
- countries: NG
- kinds: human food

## DISH Q107739566
- name: Yam ring
- description: Singaporean dish
- countries: SG
- kinds: dish
- has Wikipedia article: en

## DISH Q107739770
- name: Queso ice cream
- description: Filipino ice cream made with cheese
- countries: (none)
- kinds: ice cream
- ingredients: Cheddar cheese
- has Wikipedia article: en

## DISH Q107745950
- name: Brouet de cannelle
- other names: {"fr": "brouet de cannelle"}
- countries: (none)
- kinds: dish

## DISH Q107749708
- name: Boyal machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q107749848
- name: Alu dhonepata diye Boyal machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q107749866
- name: Gugli chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: snail as food, charchari

## DISH Q107750079
- name: Alu diye bramhi shaag vaja
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107750110
- name: Hinchar bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q107750143
- name: Chingri diye pui shaag er chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q107750147
- name: Lau shaager posto
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107750161
- name: Bori diye kumro dantar chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q107750170
- name: Rui machher matha diye note dantar chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q107750180
- name: Macher tel diye lal note shaager chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari

## DISH Q107750195
- name: Alu morich
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107750213
- name: Katla vapa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhapa

## DISH Q107750250
- name: Dudh shukto
- description: Bengali cuisine
- countries: (none)
- kinds: Shukto

## DISH Q107750339
- name: Ilish machher dim vaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q107782305
- name: Holandský řízek
- other names: {"cs": "holandský řízek"}
- countries: CZ
- kinds: frikadeller, dish
- ingredients: minced meat, cheese

## DISH Q107790439
- name: Ewedu soup
- description: popular Nigerian soup popularly eaten with Nigerian stew such as buka stew or gbegiri
- countries: NG
- kinds: dish, human food, food
- ingredients: jute leaves, iru, table salt
- has Wikipedia article: en

## DISH Q107790767
- name: Miyan Geda
- description: soup popular in Northern Nigeria
- countries: NG
- kinds: dish, human food, food

## DISH Q10779336
- name: Kho quẹt
- countries: VN
- cuisines: Southern Vietnamese cuisine
- kinds: dish

## DISH Q1077966
- name: Injeolmi
- description: variety of tteok (Korean rice cake)
- countries: (none)
- kinds: tteok
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q10779714
- name: Khô cá lóc
- description: Vietnamese seafood dish
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: dish, seafood
- ingredients: Channidae
- has Wikipedia article: en

## DISH Q107804272
- name: Mashed potato
- description: Bengali food
- countries: BD, IN
- kinds: food
- ingredients: onion, mustard oil, chili pepper, table salt, potato
- has Wikipedia article: en

## DISH Q107805938
- name: New Mexico roll
- description: uramakizushi containing New Mexico green chile, sometimes tempura fried, originating in the US state of New Mexico
- countries: US
- kinds: sushi, uramakizushi
- ingredients: New Mexico chile, rice

## DISH Q107813858
- name: Torta di zucca dolce
- other names: {"it": "Torta di zucca dolce"}
- countries: IT
- kinds: sweet pie
- ingredients: Marsala DOC, pine nut, pumpkin, egg as food, olive oil, flour, raisin, water

## DISH Q107817229
- name: Bhetki machher patapora
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q1078202
- name: Welsh cake
- other names: {"zh": "威尔士蛋糕"}
- description: Welsh traditional sweet bread made of flour, butter or lard, currants, eggs, milk and spices
- countries: (none)
- kinds: cake
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q107832448
- name: Ayamase
- description: Nigerian stew made with palm oil, fermented locust beans, and bell peppers
- countries: (none)
- kinds: dish, food
- ingredients: Capsicum, egg as food, spice, meat, fish
- has Wikipedia article: en

## DISH Q107834828
- name: Catfish pepper soup
- description: spicy fish dish in Nigeria
- countries: NG
- kinds: dish, food

## DISH Q107835198
- name: Peppered snail
- description: meal consisting of boiled snails sautéed in onions, peppers and spices
- countries: NG
- kinds: dish, food

## DISH Q107836323
- name: Peppered Ponmo
- description: Peppered "ponmo" is another way to describe spicy, succulent cow skin that is typically prepared among the Yorubas in Nigeria. It is a very hot and peppery cow skin".
- countries: (none)
- kinds: dish, food

## DISH Q107840688
- name: Beef stew
- description: stew prepared with beef
- countries: (none)
- kinds: stew, soup, dish
- ingredients: beef

## DISH Q107841628
- name: Chicken stew
- description: West African stew made with chicken thighs and simmered in a sauce made with tomatoes and peppers
- countries: (none)
- kinds: dish, food

## DISH Q107846503
- name: Okoho soup
- description: Okoho is the main traditional food peculiar to the Idoma people of Benue State Nigeria.
- countries: (none)
- kinds: dish, food

## DISH Q107848316
- name: Nigeria fisherman soup
- description: Nigerian Fisherman soup is a simple soup made with fish and other seafood as its protein source. It is called Efere Ndek Iyak in Efik and is indigenous to the people of Akwa-Ibom and Cross River states of Nigeria.
- countries: (none)
- kinds: dish, food

## DISH Q107850256
- name: Fried yam(Dundun)
- description: Dundun is a deep-fried yam recipe that can be eaten with a wide range of Nigerian stews and sauce.
- countries: NG
- kinds: dish, food, human food

## DISH Q10785085
- name: Turnover
- other names: {"zh": "夹饼"}
- description: pastry with a filling on a single piece of dough which has been folded over and sealed
- countries: (none)
- kinds: pastry, dish, stuffed food
- has Wikipedia article: en, zh

## DISH Q107851208
- name: Kokoro snacks
- description: Kokoro is a rod–like shaped crunchy Nigerian snack ,popular in some parts of Nigeria. It is made with corn meal/corn flour and usually sold by street .
- countries: (none)
- kinds: dish, food

## DISH Q107852688
- name: Plantain chips
- description: Nigerian snack made with either ripe or unripe plantains
- countries: (none)
- kinds: dish, food, snack
- ingredients: cooking banana

## DISH Q107854227
- name: Yaji spice
- description: Yaji is a spice blend that has its origin from the Northern part of Nigeria. It is mainly made from dried red chilli pepper mixed with various traditional spices grounded into a fine powder to create the mind blowing taste.
- countries: NG
- kinds: dish, food

## DISH Q107855294
- name: Agege
- description: type of Nigerian bread
- countries: (none)
- kinds: pan loaf, dish, food, Nigerian cuisine
- has Wikipedia article: en

## DISH Q107855662
- name: Keke Fieye
- description: Keke Fieye is a local dish made with unripe plantain, but you can add a little beans if you don't have enough plantain, although, most people prefer a combination of plantain and beans for this popular ijaw food.
- countries: (none)
- kinds: dish, food

## DISH Q107856275
- name: Boiled cocoyam and palm oil
- description: Nigerian dish
- countries: (none)
- kinds: dish, food
- ingredients: onion, cocoyam, palm oil, Capsicum, table salt

## DISH Q107856453
- name: Fried yam and egg sauce
- description: Fried yam and egg sauce is a popular Nigeria meal. Egg Sauce is a made with eggs, tomatoes and peppers
- countries: (none)
- kinds: dish, food

## DISH Q107856648
- name: Garden egg sauce
- countries: (none)
- kinds: dish, food

## DISH Q107856750
- name: Native jolloff rice
- description: rich jollof rice dish in Nigeria, which is easy to prepare, known as Iwuk Idesi by the Efik people of South Eastern Nigeria; palm oil is used to give it a traditional taste
- countries: (none)
- kinds: dish, food

## DISH Q107857284
- name: Guguru and epa
- description: Guguru and Epa are addictive popcorn-peanut snack combination.It is one of the simplest Nigeria snack recipe.
- countries: (none)
- kinds: dish, food

## DISH Q107857783
- name: Nigeria egg roll
- description: Nigeria egg roll is a popular Nigeria snack similar to scotch egg but unlike scotch egg,Egg roll is made from flour dough which is traditionally used to wrap the boiled egg.
- countries: (none)
- kinds: dish, food

## DISH Q107858798
- name: Stick meat
- description: easy-to-prepare Nigerian snack, also known as beef skewers or beef kebabs
- countries: (none)
- kinds: food, dish

## DISH Q107859176
- name: Gwote
- description: Gwote is a pottage made with Fonio, it’s commonly eaten by the people from Plateau State in Nigeria.. Gwote is easy to make,and you can make it with any assortment of vegetables that you like.
- countries: (none)
- kinds: food, dish

## DISH Q107859307
- name: Alkubus
- description: wheaten food often eaten with cabbage stew by the Northern Nigerians. Alkubus is Hausa-Fulani steamed bread made from wheat, flour, yeast and water, put in moulds and steamed. It is served with Miyan taushe
- countries: (none)
- kinds: food, dish

## DISH Q107859343
- name: Ukpo oka
- description: Steamed corn pudding is a meal that is native to the Eastern part of Nigeria. It is usually served during traditional engagements and taste really good.
- countries: (none)
- kinds: food, dish

## DISH Q107862812
- name: Alkaki
- description: Nigerian sanck
- countries: NG
- kinds: dish, food
- ingredients: wheat, sugar, honey
- has Wikipedia article: en

## DISH Q107862861
- name: Garau garau
- description: popular Hausa food which consists of the combination of plain rice & beans,vegetables, boiled eggs,oil and maggi. Cook your rice and beans with salt till done and set it aside.Fry onions and oil.Cut your lettuce,tomatoes and onions
- countries: (none)
- kinds: food, dish
- ingredients: onion, oil, Phaseolus vulgaris, rice

## DISH Q107862875
- name: Cowtail peppersoup
- description: Nigerian cowtail peppersoup is a mouthwatering peppersoup made with Cowtail, spices,peppers and other ingredients.
- countries: (none)
- kinds: meat, dish

## DISH Q107862891
- name: Dantsurku
- description: Northern Nigeria Spicy fish ball snacks.It is very tasty and delicious
- countries: (none)
- kinds: fish, food, dish

## DISH Q107862910
- name: Dakuwa
- description: Dakuwa. is a traditional snack, prominent in northern. Nigeria. It is made from roasted tiger nut and. groundnut; it can also be made from roasted sorghum.
- countries: (none)
- kinds: food, dish

## DISH Q107862948
- name: Zogale salad
- description: Zogale salad is popular in the Northern part of Nigeria.It is simple to make and delicious. it is made up of Moringa leaf (Zogale), Karago, Onions and peppers SeasoningG/oil
- countries: (none)
- kinds: food, dish
- ingredients: Moringa leaf

## DISH Q107862970
- name: Dambun nama
- description: Dambu nama is a popular meat snack in Northern Nigeria and its more commonly prepared during the Muslim Sal-ah celebrations. The choice meat for making this snack for Sal-ah is lamb but beef and chicken are also used.
- countries: (none)
- kinds: food, beef, dish

## DISH Q107863024
- name: Gireba
- description: Gireba is a Northern Nigeria delicacy derived from flour, and is made with everyday easily digestible ingredients. Flour is a powder made by grinding raw grains, roots, beans, nuts, or seeds.
- countries: (none)
- kinds: food, dish

## DISH Q107863049
- name: Yamarita
- description: Yamarita is plain boiled yam that is coated in egg, flour, ginger, garlic, and salt and fried. This is one of the most popular Hausa food in Nigeria.
- countries: (none)
- kinds: food, dish

## DISH Q107863092
- name: Garnished liver sauce
- description: rich Nigeria dish which consists of chopped liver, chopped onion, pepper and other spices
- countries: (none)
- kinds: food, liver as food, peppercorn, Onions, dish

## DISH Q107863177
- name: Yam balls
- description: Nigerian dish with mashed boiled yam, eggs, peppers and spices moulded into ball shape and fried
- countries: (none)
- kinds: dish

## DISH Q107863246
- name: Moringa smoothie
- description: Moringa smoothie is a rich antioxidant drink that fights against oxygen-free radicals, which can contribute to cholesterol build-up and inflammation.
- countries: (none)
- kinds: food, dish
- ingredients: Moringa leaf

## DISH Q107863271
- name: Sweet potatoes pottage
- description: dish
- countries: (none)
- kinds: food, dish
- ingredients: sweet potato

## DISH Q107863313
- name: Fonio jolloff
- description: This recipe is a popular dish in West Africa using gluten free grain called fonio. Fonio is the term for two cultivated grasses in the genus Digitaria that are notable crops in parts of West Africa.[1] They are millets with small grains.
- countries: (none)
- kinds: food, Fonio, dish

## DISH Q107863353
- name: Buns snack
- description: Nigerian Buns is one of the popular snacks in Nigeria. It’s a bit crusty on the outside but fluffy inside. A bun is a small, sometimes sweet, bread-based item or roll. Though they come in many shapes and sizes, they are most commonly hand-sized.
- countries: (none)
- kinds: Milk, sugar product, food, bun, dish, baker's yeast

## DISH Q107864321
- name: Flan coco
- other names: {"fr": "flan coco"}
- countries: (none)
- kinds: custard

## DISH Q107870318
- name: Pear tarts
- countries: (none)
- kinds: sweet pie

## DISH Q107870567
- name: Ilish shukto
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Shukto

## DISH Q107871390
- name: Tal er khir
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107871531
- name: Tal er luchi
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q107879743
- name: Croissant salé
- other names: {"fr": "croissant salé"}
- countries: FR
- kinds: croissant

## DISH Q107879852
- name: Almond croissant
- other names: {"zh": "杏仁牛角麵包"}
- countries: FR
- kinds: croissant

## DISH Q107885744
- name: Tatsutaage
- countries: (none)
- kinds: karaage, chicken dish

## DISH Q107891975
- name: Chocolate éclair
- countries: (none)
- kinds: éclair

## DISH Q10794259
- name: Miến lươn
- description: Vietnamese noodle soup
- countries: (none)
- kinds: noodle soup
- ingredients: eel as food, cellophane noodles

## DISH Q10796543
- name: Mắm ba khía
- other names: {"vi": "mắm ba khía"}
- countries: (none)
- cuisines: Southern Vietnamese cuisine
- kinds: fermented seafood
- ingredients: Episesarma mederi

## DISH Q10796544
- name: Mắm chua
- other names: {"vi": "mắm chua"}
- countries: VN
- cuisines: Vietnamese cuisine
- ingredients: toasted rice powder, Acetes

## DISH Q10796545
- name: Mắm cáy
- description: Vietnamese crab sauce
- countries: (none)
- cuisines: Northern Vietnamese cuisine
- kinds: fermented seafood
- ingredients: cáy
- has Wikipedia article: en

## DISH Q10796546
- name: Mắm kho
- other names: {"vi": "mắm kho"}
- countries: VN
- cuisines: Southern Vietnamese cuisine
- kinds: fish soup
- ingredients: snakehead paste, prahok

## DISH Q10796548
- name: Mắm nhĩ
- description: premium, undiluted Vietnamese fish sauce from the first press of fermented fish
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: delicacy, nước mắm

## DISH Q10796549
- name: Mắm nêm
- description: Vietnamese fermented fish sauce
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: fermented seafood
- has Wikipedia article: en

## DISH Q10796550
- name: Mắm rươi
- other names: {"vi": "mắm rươi"}
- countries: VN
- kinds: condiment, fermented seafood
- ingredients: Nereididae

## DISH Q10796551
- name: Mắm tép
- other names: {"vi": "mắm tép"}
- countries: VN
- cuisines: Vietnamese cuisine
- kinds: fermented seafood
- ingredients: Caridina flavilineata

## DISH Q10796553
- name: Mắm tôm chua
- other names: {"vi": "mắm tôm chua"}
- countries: VN
- cuisines: Central Vietnamese cuisine, Southern Vietnamese cuisine
- kinds: shrimp paste
- ingredients: Metapenaeus ensis

## DISH Q107969329
- name: Dhikri
- description: Nepalese rice cake
- countries: NP
- cuisines: Nepalese cuisine
- kinds: rice cake
- has Wikipedia article: en

## DISH Q10802091
- name: Cát Hải fish sauce
- countries: VN
- cuisines: Hải Phòng cuisine
- kinds: designation of origin, nước mắm

## DISH Q10802093
- name: Phan Thiết fish sauce
- other names: {"zh": "潘切魚露"}
- countries: VN
- cuisines: Southern Vietnamese cuisine
- kinds: designation of origin, nước mắm
- has Wikipedia article: zh

## DISH Q108030397
- name: Sorputi machh vapa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhapa

## DISH Q108030523
- name: Heura
- description: Vegetal product based on soy protein, olive oil and water
- countries: ES
- cuisines: vegetarian cuisine, vegan cuisine
- kinds: meat alternative, plant proteins, human food
- ingredients: ginger, cardamom, peppercorn, paprika, olive oil, nutmeg, table salt, soybean, drinking water, soy bean

## DISH Q108035185
- name: Hiyashi Ramen
- countries: (none)
- kinds: hiyashi chūka

## DISH Q108047543
- name: Brněnský řízek
- other names: {"cs": "brněnský řízek"}
- countries: CZ
- kinds: escalope, dish

## DISH Q108047762
- name: Pennoni
- description: long, tubular pasta
- countries: (none)
- kinds: pasta

## DISH Q108058576
- name: Katla machher matha diye lau ghonto
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Ghanto

## DISH Q108058590
- name: Chingri diye panchmishali torkari
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q108059251
- name: Kurkuri chhatur torkari
- description: bengali cuisine
- countries: (none)
- kinds: mushroom dish

## DISH Q108059267
- name: Kurkuri chhatu bhaja
- description: bengali cuisine
- countries: (none)
- kinds: mushroom dish

## DISH Q108059287
- name: Alu o chhola diye dumurer torkari
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108059294
- name: Dumur bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108059299
- name: Parbani chhatur chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: mushroom dish

## DISH Q108059318
- name: Parbani chhatu bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: mushroom dish

## DISH Q108059382
- name: Kochra bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108059401
- name: Kurul shaag bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108059424
- name: Mangser keemar bora
- description: Bengali cuisine
- countries: (none)
- kinds: chicken dish

## DISH Q108059434
- name: Dimer bora
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q108059457
- name: Chholar daler bora
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108059467
- name: Bandhakopir bora
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108059472
- name: Musur daler bora
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108059477
- name: Chhanar bora
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108059536
- name: Kumro bijer bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q108063900
- name: Pottekaas
- description: cheese from Brussels, Belgium
- countries: BE
- kinds: quark, cheese, regional product
- ingredients: plattekaas, Brussels cheese

## DISH Q108063948
- name: Martino
- description: sandwich from Belgium
- countries: BE
- kinds: submarine sandwich, raw beef dish, dish
- ingredients: peri-peri sauce, filet américain, onion, pickle, Worcestershire sauce, Tabasco sauce, ketchup, cayenne pepper

## DISH Q108065409
- name: Sahneeis
- other names: {"de": "Sahneeis"}
- countries: (none)
- kinds: ice cream
- ingredients: cream

## DISH Q108065444
- name: Milcheis
- other names: {"de": "Milcheis"}
- countries: (none)
- kinds: ice cream, dairy product
- ingredients: milk

## DISH Q108067365
- name: Kathal bijer bora
- description: bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q108067369
- name: Khoslar bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q108067379
- name: Korolar bora
- description: bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q108067382
- name: Sojne patar bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q108069195
- name: Pikina
- countries: FR
- kinds: apéritif

## DISH Q108086009
- name: Linguine carbonara
- countries: (none)
- kinds: carbonara
- ingredients: linguine

## DISH Q108086096
- name: Fleischknödel
- countries: (none)
- kinds: knödel, Erdäpfelknödel

## DISH Q108088119
- name: Pui patay ilish paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q108095007
- name: Boerenwafels
- other names: {"nl": "Boerenwafels"}
- countries: (none)
- kinds: dish
- ingredients: Beschuit, sawdust, egg as food, milk

## DISH Q108099796
- name: Flechtgebäck
- other names: {"de": "Flechtgebäck"}
- countries: (none)
- kinds: pastry

## DISH Q108112946
- name: Brânză de vaci
- description: Romanian cheese
- countries: MD, RO
- kinds: cow's-milk cheese, Romanian cheese, cheese
- has Wikipedia article: en

## DISH Q108120915
- name: Toheroa soup
- description: New Zealand soup made from Paphies ventricosa
- countries: NZ
- kinds: soup
- ingredients: Paphies ventricosa

## DISH Q108122335
- name: Sorputi machher jhal
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108122467
- name: Sojne dantar bora
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108122475
- name: Sojne fuler bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q108122480
- name: Oler bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q108122493
- name: Note shaager bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada

## DISH Q108122535
- name: Lote machher bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada, fish dish

## DISH Q108122552
- name: Amudi machher begun diye jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108127132
- name: Algérienne sauce
- description: sauce made of mayonnaise, harissa, spices, tomatoes and onions
- countries: BE
- cuisines: cuisine of Belgium
- kinds: hot sauce, condiment
- ingredients: tomato, onion, mayonnaise, spice
- has Wikipedia article: en

## DISH Q108130705
- name: ブルースターバーガー
- other names: {"ja": "ブルースターバーガー"}
- countries: (none)
- kinds: hamburger

## DISH Q108130712
- name: マイバーガーこめ松
- other names: {"ja": "マイバーガーこめ松"}
- countries: (none)
- kinds: rice burger

## DISH Q108130715
- name: トリキバーガー
- other names: {"ja": "トリキバーガー"}
- countries: (none)
- kinds: food, hamburger

## DISH Q108170369
- name: Plattekaas
- description: cheese from Brussels, Belgium
- countries: BE
- kinds: cheese, quark, fresh cheese

## DISH Q108170525
- name: Meulemeester eggs
- description: gratin of gray shrimps marinated in beer and hard-boiled egg
- countries: BE
- kinds: dish, egg dish
- ingredients: hard-boiled egg, shrimp, beer

## DISH Q108178857
- name: Galho
- description: naga dish made with mixed vegetables
- countries: (none)
- kinds: food, dish
- ingredients: vegetable, meat, rice
- has Wikipedia article: en

## DISH Q108181168
- name: Somun
- description: type of bread from Bosnia and Herzegovina
- countries: BA
- kinds: flatbread

## DISH Q108197336
- name: Parse machher jhol alu potol diye
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108206760
- name: Street food in Australia
- description: traditional Australian cuisine
- countries: (none)
- kinds: street food

## DISH Q108215843
- name: Boiroli machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108215920
- name: Kanchakolar khosa bata
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108216007
- name: Kola patai dim paturi
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q108216058
- name: Chingrir pur vora chhanar kofta
- description: Bengali cuisine
- countries: (none)
- kinds: kofta, shrimp dish

## DISH Q108216983
- name: ডিমের ধোঁকা
- other names: {"bn": "ডিমের ধোঁকা"}
- countries: (none)
- kinds: egg dish

## DISH Q108217137
- name: Ilisher muro diye shapla
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108217205
- name: পেঁপে বড়ি তরকারি
- other names: {"bn": "পেঁপে বড়ি তরকারি"}
- countries: (none)
- kinds: vegetable dish

## DISH Q108234722
- name: Uchchhe lau diye tetor dal
- description: Bengali cuisine
- countries: (none)
- kinds: lentil soup, vegetable dish

## DISH Q108296002
- name: Neritic squid rice noodles
- other names: {"zh": "小卷米粉"}
- description: traditional rice noodle soup from Tainan, Taiwan
- countries: TW
- kinds: rice vermicelli, squid dish
- has Wikipedia article: zh

## DISH Q108304103
- name: Panagyurishte-style eggs
- description: Bulgarian egg dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q108304231
- name: Popcorn shrimp
- description: shrimp fritter finger food
- countries: (none)
- kinds: fried shrimp
- has Wikipedia article: en

## DISH Q108305832
- name: Toffee au lait
- other names: {"fr": "Toffee au lait"}
- countries: (none)
- kinds: candy

## DISH Q108306128
- name: Ninnouwi
- countries: BJ
- kinds: food

## DISH Q108311076
- name: Ciorbă de fasole boabe
- other names: {"ca": "Ciorbă de fasole boabe"}
- countries: RO
- kinds: ciorbă

## DISH Q108311129
- name: Iahnie de cartofi
- other names: {"ca": "Iahnie de cartofi"}
- countries: RO
- kinds: dish

## DISH Q108315407
- name: Vercorais
- other names: {"fr": "Vercorais"}
- countries: FR
- kinds: French cheese, raw-milk cheese, cow's-milk cheese, industrial cheese, pressed cooked cheese
- ingredients: cow's milk, raw milk

## DISH Q108327562
- name: Pizza in New York City
- description: urban food culture
- countries: (none)
- cuisines: cuisine of New York City
- kinds: dish, pizza in the United States
- has Wikipedia article: en

## DISH Q108331164
- name: Baton
- description: type of bread
- countries: (none)
- kinds: bread

## DISH Q108364789
- name: Alu diye bhola machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108364830
- name: Alu begun diye telchorchori
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108364888
- name: Gule machher jhal
- description: bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108365005
- name: Ilisher tel ar matha diye note shaag
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108365039
- name: Dheros chingri diye tentuler tok
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q108365112
- name: Shaplar vela bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108366890
- name: Tfaya
- description: sweet sauce in Moroccan cuisine
- countries: MA
- kinds: dish
- ingredients: onion, Cinnamomum verum, raisin, honey
- has Wikipedia article: en

## DISH Q108368900
- name: Shapla diye mug dal
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108368935
- name: Shaplar paturi
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108375974
- name: Bhola machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q1083840
- name: Balti
- description: type of curry cooked and eaten in a thin, pressed-steel wok called a "balti bowl"
- countries: (none)
- kinds: curry, dish
- has Wikipedia article: en

## DISH Q108387469
- name: Erdbeeren Romanoff
- other names: {"de": "Erdbeeren Romanoff"}
- countries: (none)
- kinds: dessert

## DISH Q108394942
- name: Alu fulkopi diye katla machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108395190
- name: Ilish machher matha diye chal kumror ghonto
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108395259
- name: Thor chingri narkel diye
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q108395269
- name: Hanser dimer jhol
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q108395310
- name: Pur vora niramish alur dom
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108395330
- name: Chingri diye kolmi saag
- description: Bengali cuisine
- countries: (none)
- kinds: shrimp dish

## DISH Q108408336
- name: Famichiki
- other names: {"zh": "法米鸡"}
- countries: JP
- kinds: chicken dish, fried chicken
- ingredients: chicken as food

## DISH Q108417752
- name: Pizza bianca
- description: Roman flatbread
- countries: IT
- kinds: food
- has Wikipedia article: en

## DISH Q10842725
- name: Sabazushi
- other names: {"zh": "鯖壽司"}
- description: kind of sushi made from saba (mackerel)
- countries: JP
- kinds: sushi
- ingredients: mackerel as food

## DISH Q108441021
- name: Œufs Orsini
- other names: {"fr": "œufs Orsini"}
- countries: (none)
- kinds: dish

## DISH Q108447805
- name: كليچة
- other names: {"ar": "كليچة"}
- countries: IQ
- kinds: food

## DISH Q108459281
- name: Narkeler noboratna
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q108473781
- name: Koi machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108510898
- name: Vargabeles
- description: noodle and cheese cake originating in Transylvania
- countries: RO
- kinds: food, dish

## DISH Q108532355
- name: Poee
- description: goan traditional leavened bread
- countries: IN
- kinds: bread
- has Wikipedia article: en

## DISH Q108545001
- name: Cinta bread
- description: Spanish variety of bread
- countries: ES
- kinds: bread

## DISH Q108545863
- name: Llonguet
- description: White bread from Catalonia, Spain
- countries: ES
- kinds: French roll

## DISH Q10855251
- name: Gyeran-ppang
- other names: {"zh": "韓式雞蛋糕"}
- description: Korean snack
- countries: KR
- kinds: food, egg dish
- ingredients: egg as food
- has Wikipedia article: en, zh

## DISH Q108552864
- name: Punti machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552865
- name: Punti machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552866
- name: Begun alu diye punti machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552867
- name: Punti machher bati chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108552868
- name: Sorpunti machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552869
- name: Sorpunti machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552870
- name: Sorse posto bata diye sorpunti machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552871
- name: Sorse jeera bata diye sorpunti machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552872
- name: Alu begun diye bhola machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552873
- name: Bhola machh begun sorse diye jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552874
- name: Chela machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108552875
- name: Chela machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552876
- name: Chela machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552877
- name: Alu begun diye chela machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552879
- name: Sorse diye khoyra machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552880
- name: Khoyra machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552882
- name: Khoyra paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q108552883
- name: Dhela machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552884
- name: Peyaj bata diye dhela machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552885
- name: Sorse diye dhela machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552886
- name: Dhela machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552888
- name: Bacha machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552889
- name: Bacha machher jhal bhuna
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108552890
- name: Alu diye bacha machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552891
- name: Desi begun diye bacha machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552892
- name: Bacha machher sorse jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552893
- name: Bacha machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552895
- name: Bacha machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552896
- name: Mola machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552897
- name: Mola machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552898
- name: Mola machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552899
- name: Mola machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108552901
- name: Darkina machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552902
- name: Darkina machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552903
- name: Darkina machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108552904
- name: Alu diye boroli machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552905
- name: Boroli machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552906
- name: Shol machher bhuna
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108552907
- name: Shol machher kalia
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, kaliya

## DISH Q108552909
- name: Alu tomato diye shingi machher jhol
- description: bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552912
- name: Fulkopi diye shingi machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552913
- name: Uchchhe diye shingi machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552914
- name: Lau shaag diye shingi machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552915
- name: Lau patay shingi machh vapa
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhapa

## DISH Q108552916
- name: Shingi machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552917
- name: Bok machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552918
- name: Kancha tentul diye bok machher tok
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108552919
- name: Begun diye bok machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552940
- name: Chanda machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552941
- name: Chanda machher vorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta, fish dish

## DISH Q108552943
- name: Chanda machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552944
- name: Chanda machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108552945
- name: Chanda machher tok
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108552946
- name: Kajoli machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552947
- name: Kalojeera diye kajoli machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552948
- name: Kajoli machher sorse jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552949
- name: Kajoli machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108552950
- name: Kajoli machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552951
- name: Kajoli machher tel jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552954
- name: Kajoli machh bhapa
- description: Bengali cuisine
- countries: (none)
- kinds: Bhapa, fish dish

## DISH Q108552955
- name: Kachki machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552956
- name: Kochur loti kachki shutki diye vorta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta, fish dish

## DISH Q108552957
- name: Kachki machher bora
- description: Bengali cuisine
- countries: (none)
- kinds: Vada, fish dish

## DISH Q108552958
- name: Kachki machher bhuna
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q108552959
- name: Kachki machher jhal
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhal

## DISH Q108552960
- name: Lau patay kachki machher paturi
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, paturi

## DISH Q108552963
- name: Kachki machher jhal chorchori
- description: bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108552965
- name: Chapila machh bhaja
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja

## DISH Q108552966
- name: Chapila machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108552967
- name: Peyajkoli diye chapila machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Jhol

## DISH Q108552969
- name: Amudi machher chorchori
- description: Bengali cuisine
- countries: (none)
- kinds: charchari, fish dish

## DISH Q108552971
- name: Muchmuche amudi fry
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish, Bhaja
