# Review batch names-040

## DISH Q3412448
- name: Shawarma
- other names: {"zh": "沙威玛"}
- description: Levantine meat dish inspired by döner kebab
- countries: SA
- cuisines: Arab cuisine
- kinds: snack, wrap, stuffed flatbread
- ingredients: cumin seed, garlic, turmeric, cardamom, cabbage, Morkovcha, paprika, lemon juice, taboon bread, lavash, pita, sauce, Syzygium, cinnamon, vegetable, meat
- has Wikipedia article: en, zh

## DISH Q3414202
- name: Quepapas
- other names: {"es": "Quepapas"}
- countries: (none)
- kinds: potato dish

## DISH Q3419728
- name: 土豆烙饼
- countries: (none)
- kinds: potato dish

## DISH Q3420023
- name: Rata
- other names: {"it": "rata"}
- countries: (none)
- kinds: ragout

## DISH Q3420363
- name: Raviole du Dauphiné
- other names: {"zh": "多菲内饺"}
- description: French pasta dish
- countries: FR
- cuisines: cuisine from Dauphiné (France)
- kinds: pasta, dish
- has Wikipedia article: en

## DISH Q3420368
- name: Ravitoto
- description: Cassava leaf
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q3421424
- name: Raïto
- description: provencal sauce
- countries: FR
- kinds: condiment, sauce

## DISH Q3421984
- name: Rechta
- description: vermicelli dish
- countries: DZ
- kinds: food, cooking
- ingredients: pasta and noodles, chicken as food, noodle, vegetable
- has Wikipedia article: en

## DISH Q342208
- name: Güveç
- description: Turkish and Balkan cuisine dish
- countries: TR
- kinds: stew
- ingredients: vegetable, meat
- has Wikipedia article: en

## DISH Q3422327
- name: Kneippbrød
- description: whole wheat bread
- countries: (none)
- kinds: bread, brown bread
- ingredients: whole-wheat flour
- has Wikipedia article: en

## DISH Q3425445
- name: Sol over Gudhjem
- description: Danish open sandwich dish
- countries: DK
- kinds: sandwich, open sandwich
- ingredients: rugbrød
- has Wikipedia article: en

## DISH Q3425450
- name: Dyrlægens natmad
- description: type of Danish open sandwich
- countries: DK
- kinds: type of food or dish, smørrebrød
- ingredients: rugbrød, liver pâté, aspic, smørrebrød, meat
- has Wikipedia article: en

## DISH Q3428078
- name: Cassavepap
- other names: {"nl": "cassavepap"}
- countries: (none)
- kinds: dish

## DISH Q34292
- name: Shchi
- other names: {"zh": "白菜湯"}
- description: Russian national cabbage soup
- countries: RU
- cuisines: Russian cuisine
- kinds: soup, dish
- ingredients: white cabbage, sauerkraut
- has Wikipedia article: en, zh

## DISH Q3431960
- name: Rigolette
- other names: {"fr": "rigolette"}
- countries: FR
- kinds: confectionery

## DISH Q3431975
- name: Rigouta
- description: Tunisian whey cheese
- countries: TN
- kinds: whey cheese
- has Wikipedia article: en

## DISH Q3434019
- name: Arroz de bacalhau
- description: Portuguese dish
- countries: PT
- kinds: fish dish, rice dish
- ingredients: cod, rice

## DISH Q3435353
- name: Tufahije
- description: Bosnian dessert
- countries: BA
- kinds: dessert
- ingredients: walnut
- has Wikipedia article: en

## DISH Q3436095
- name: Malatang
- other names: {"zh": "麻辣烫"}
- description: Sichuanese dish
- countries: CN
- kinds: type of food or dish, dish, soup
- has Wikipedia article: en, zh

## DISH Q3436828
- name: Cube steak
- description: cut of beef
- countries: (none)
- kinds: type of food or dish, beefsteak, beef dish
- has Wikipedia article: en

## DISH Q343864
- name: Imam Bayıldı
- other names: {"zh": "土耳其烤茄子"}
- description: Turkish cold dish based on eggplants, onions and olive oil
- countries: TR
- cuisines: Bulgarian cuisine, Turkish cuisine, Armenian cuisine, Greek cuisine, Macedonian cuisine, Albanian cuisine
- kinds: dish, food
- ingredients: onion, olive oil, tomato, Allium sativum
- has Wikipedia article: en, zh

## DISH Q3439845
- name: Roigebrageldi
- description: culinary specialty of Alsace (France) consisting of potatoes, bacon, onions, butter, and white wine
- countries: (none)
- kinds: dish, potato dish
- ingredients: potato, onion

## DISH Q344066
- name: İskender kebap
- other names: {"zh": "伊斯坎達爾烤肉"}
- description: Turkish meat dish (variety of "döner")
- countries: TR
- cuisines: Turkish cuisine
- kinds: doner kebab
- ingredients: mutton, tomato sauce, lavash, butter, yogurt
- has Wikipedia article: en, zh

## DISH Q3441149
- name: Romazava
- description: Malagasy stew
- countries: MG
- kinds: broth, dish, stew
- ingredients: Acmella oleracea, shrimp, fish as food, moringa, beef
- has Wikipedia article: en

## DISH Q3441161
- name: Baked apple
- description: German dessert
- countries: (none)
- kinds: sweet dish
- ingredients: apple
- has Wikipedia article: en

## DISH Q3441918
- name: Međimurska gibanica
- description: Croatian dessert
- countries: (none)
- kinds: food, layer cake
- ingredients: puff pastry
- has Wikipedia article: en

## DISH Q3442077
- name: Rožata
- description: Croatian custard dessert with caramel and rozalin
- countries: HR
- kinds: pudding
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q34421086
- name: Bagel and cream cheese
- description: common food pairing in American cuisine
- countries: US
- kinds: open sandwich
- has Wikipedia article: en

## DISH Q3442427
- name: Roses des sables
- description: French confection made with cornflakes and chocolate
- countries: FR
- kinds: pastry

## DISH Q3443096
- name: Roudoudou
- description: colored caramel
- countries: (none)
- kinds: candy

## DISH Q3443152
- name: Rougail
- other names: {"zh": "鲁加伊"}
- description: dish of Reunionese origin
- countries: FR, MU
- kinds: dish
- has Wikipedia article: en

## DISH Q3443155
- name: Rougail saucisse
- description: Dish from Reunion Island
- countries: FR
- kinds: dish
- ingredients: rougail, sausage

## DISH Q3443485
- name: Roustiquette
- other names: {"fr": "Roustiquette"}
- countries: (none)
- kinds: potato dish

## DISH Q3447542
- name: Fusi
- description: type of pasta
- countries: HR, SI
- kinds: pasta
- has Wikipedia article: en

## DISH Q3449266
- name: Pašticada
- description: Croatian braised beef dish
- countries: HR
- kinds: beef dish
- ingredients: beef
- has Wikipedia article: en

## DISH Q3449298
- name: Nut roll
- description: pastry
- countries: (none)
- kinds: food, pastry, roll
- has Wikipedia article: en

## DISH Q3460531
- name: Sabina PDO
- other names: {"zh": "Sabina DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil
- has Wikipedia article: en

## DISH Q3462362
- name: Arròs a banda
- description: Spanish dish of rice cooked in fish stock
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q3463262
- name: Saint-Raphaël
- countries: FR
- kinds: apéritif
- ingredients: Cinchona officinalis

## DISH Q34674117
- name: Calisson d'Aix
- other names: {"fr": "Calisson d'Aix"}
- countries: (none)
- kinds: Calisson

## DISH Q3469334
- name: Saka saka
- description: cassava leaves cooked with peanut butter
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q3469458
- name: Composed salad
- description: salad
- countries: (none)
- kinds: salad

## DISH Q3469460
- name: Salade cauchoise
- description: Traditional French potato dish
- countries: FR
- kinds: salad
- ingredients: potato
- has Wikipedia article: en

## DISH Q3469461
- name: Salade comtoise
- countries: (none)
- kinds: salad

## DISH Q3469463
- name: Dandelion salad
- other names: {"zh": "蒲公英沙拉"}
- description: Salad of dandelion greens
- countries: (none)
- kinds: garden salad, leaf lettuce, salad
- ingredients: lardon, dandelion, hard-boiled egg

## DISH Q3469465
- name: 列日沙拉
- countries: BE
- cuisines: cuisine of Belgium
- kinds: salad
- ingredients: green bean

## DISH Q3469471
- name: Mechouia salad
- description: Tunisian salad
- countries: TN
- kinds: salad
- ingredients: tomato
- has Wikipedia article: en

## DISH Q3469472
- name: Salade normande
- other names: {"fr": "Salade normande"}
- countries: (none)
- kinds: potato dish

## DISH Q3469475
- name: Serbian salad
- description: balkan vegetable salad
- countries: RS
- kinds: salad
- ingredients: tomato
- has Wikipedia article: en

## DISH Q3469476
- name: Salade tunisienne
- other names: {"fr": "Salade tunisienne"}
- description: Tunisian salad
- countries: TN
- kinds: salad

## DISH Q3469606
- name: Salampatata
- countries: IT
- kinds: potato dish, fresh sausage
- ingredients: potato

## DISH Q3472077
- name: Denver sandwich
- description: food dish
- countries: (none)
- kinds: omelette, sandwich
- ingredients: onion, scrambled eggs, ham
- has Wikipedia article: en

## DISH Q3472079
- name: Italian beef
- other names: {"zh": "義大利牛肉"}
- description: sandwich, originating in Chicago, composed of thin slices of seasoned roast beef
- countries: US
- cuisines: Italian-American cuisine
- kinds: food, roast beef sandwich, beef dish
- ingredients: Giardiniera, roast beef, au jus, bread roll
- has Wikipedia article: en, zh

## DISH Q3472373
- name: Sanganhèta
- description: Occitan blood dish
- countries: (none)
- has Wikipedia article: en

## DISH Q3473115
- name: Saba
- description: typical condiment used in Italy
- countries: IT
- kinds: gastronomy
- has Wikipedia article: en

## DISH Q3473166
- name: Sapin-sapin
- description: Filipino confection made of rice
- countries: PH
- kinds: confectionery
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q3473453
- name: Saramură
- description: Romanian sauce for marinating
- countries: RO
- kinds: fish dish
- has Wikipedia article: en

## DISH Q3473983
- name: Șodou
- description: culinary preparation from Romania
- countries: (none)
- kinds: dish
- ingredients: sweet wine, egg yolk, sugar
- has Wikipedia article: en

## DISH Q3474126
- name: Sauce Robert
- other names: {"zh": "罗贝尔酱"}
- description: French sauce consisting of onions, white wine, pepper, demi-glace, and mustard
- countries: FR
- kinds: sauce
- ingredients: onion, demi-glace, mustard, white wine
- has Wikipedia article: en

## DISH Q3474166
- name: Pleșcoi sausages
- description: Romanian sausage
- countries: RO
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q3476509
- name: Kuai
- other names: {"zh": "生鱼片"}
- description: Chinese food dish
- countries: (none)
- kinds: seafood dish, raw fish dish
- has Wikipedia article: en, zh

## DISH Q3477693
- name: Seffa
- description: sweetened couscous dish with butter and spices
- countries: (none)
- kinds: dish
- ingredients: semolina, almond, cinnamon, sugar
- has Wikipedia article: en

## DISH Q3478195
- name: Sellu
- description: maroccan pastry
- countries: MA
- cuisines: Moroccan cuisine
- kinds: human food, dessert, candy
- has Wikipedia article: en

## DISH Q34804358
- name: Stephaniebraten
- countries: (none)
- kinds: dish, Austrian Meatloaf

## DISH Q3480481
- name: Ábrystir
- description: Icelandic dessert
- countries: IS
- kinds: pudding
- has Wikipedia article: en

## DISH Q34807
- name: Foie gras
- other names: {"zh": "鵝肝"}
- description: French culinary dish
- countries: FR
- cuisines: French cuisine
- kinds: dish
- ingredients: liver as food
- has Wikipedia article: en, zh

## DISH Q3480991
- name: Grjúpán
- description: icelandic dish of sheep lungs
- countries: (none)
- kinds: lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q3481297
- name: Shambar
- description: Peruvian typical soup
- countries: PE
- kinds: meal, soup
- ingredients: wheat
- has Wikipedia article: en

## DISH Q3481488
- name: Shari
- countries: JP
- kinds: cooked rice

## DISH Q3481800
- name: Minced meat patty
- countries: (none)
- kinds: dish

## DISH Q3482613
- name: Potato wedges
- other names: {"zh": "薯角"}
- description: prepared food
- countries: (none)
- kinds: potato dish
- ingredients: potato
- has Wikipedia article: en, zh

## DISH Q3486962
- name: Smetannik
- description: torte of Russian and Ukrainian cuisine
- countries: RU
- kinds: torte

## DISH Q3488926
- name: Sohlob
- description: dessert
- countries: DZ
- kinds: dish, dessert
- ingredients: cow's milk, flour

## DISH Q3489093
- name: Svíčková
- description: typical Czech dish
- countries: CZ
- kinds: beef dish
- has Wikipedia article: en

## DISH Q3490797
- name: Sopa de mondongo
- other names: {"zh": "蒙東哥湯"}
- description: spanish-origin dish
- countries: (none)
- kinds: tripe soup, food, soup
- ingredients: tripe
- has Wikipedia article: en

## DISH Q3491264
- name: Sorra
- other names: {"it": "Sorra"}
- countries: TN
- kinds: pastry
- ingredients: pistachio nut, hazelnut, almond, sugar, honey

## DISH Q3491553
- name: Somun
- description: round bread from Turkish cuisine
- countries: TR
- kinds: food, bread

## DISH Q3491819
- name: Soupe aux gourganes
- description: fava bean soup from Quebec
- countries: (none)
- kinds: soup
- has Wikipedia article: en

## DISH Q3491822
- name: Sétoise fish soup
- other names: {"zh": "塞特鱼汤"}
- description: French fish soup
- countries: (none)
- cuisines: Occitan cuisine
- kinds: fish soup

## DISH Q3493331
- name: Burgersoep
- other names: {"nl": "Burgersoep"}
- countries: (none)
- kinds: food, soup

## DISH Q3494357
- name: Culinary speciality
- countries: (none)
- kinds: dish

## DISH Q3496916
- name: Dopiaza
- other names: {"zh": "洋葱酱咖喱"}
- description: Indian curry
- countries: IN
- kinds: Indian curry
- ingredients: mutton, chicken as food, beef, Allium
- has Wikipedia article: en

## DISH Q3497556
- name: Karnıyarık
- other names: {"zh": "茄子鑲肉"}
- description: eggplant and meat dish from the Turkish cuisine
- countries: TR
- kinds: dish, food
- ingredients: eggplant, meat
- has Wikipedia article: en

## DISH Q3497742
- name: Steak frites
- other names: {"zh": "牛排炸薯条"}
- description: Belgian and French dish of steak (usually entrecôte) in sauce (typically pan reduction) paired with French fries
- countries: BE
- kinds: meat, beef dish
- ingredients: steak, fries
- has Wikipedia article: en

## DISH Q3498785
- name: Demikát
- description: Slovak soup
- countries: SK
- kinds: soup
- ingredients: garlic, potato, onion, sour cream, Bryndza

## DISH Q3499420
- name: Stifado
- description: stew made from meat, onions and tomatoes
- countries: (none)
- kinds: meat dish, stew

## DISH Q3499431
- name: 西西里烤羊肠
- description: Italian meat dish originating from Sicily
- countries: IT
- cuisines: Sicilian cuisine
- kinds: meat dish
- ingredients: intestine
- has Wikipedia article: en

## DISH Q3499615
- name: Stoemp with sausage
- description: dish from Brussel
- countries: BE
- kinds: dish
- ingredients: stoemp, sausage

## DISH Q3499942
- name: Stracciatella
- description: variety of gelato
- countries: IT
- cuisines: Italian cuisine
- kinds: ice cream, gelato
- ingredients: sodium alginate, smetana, egg yolk, gelatin, ice cream, sugar, milk, chocolate
- has Wikipedia article: en

## DISH Q3500074
- name: Strata
- description: family of layered casserole dishes
- countries: (none)
- kinds: egg dish
- ingredients: egg as food, cheese, bread
- has Wikipedia article: en

## DISH Q3500519
- name: Stromboli
- description: savory turnover
- countries: US
- cuisines: Italian-American cuisine
- kinds: turnover
- ingredients: condiment, dough, olive oil, meat, cheese
- has Wikipedia article: en

## DISH Q3501098
- name: Stufat
- description: Romanian meat stew
- countries: RO
- kinds: stew

## DISH Q3501106
- name: Stufato à la pavesane
- other names: {"fr": "stufato à la pavesane"}
- countries: IT
- kinds: beef dish, stew

## DISH Q3502845
- name: Tablet
- other names: {"zh": "傳統奶油方塊糖"}
- description: sugary confection from Scotland
- countries: (none)
- kinds: Sinterklaas candy, confectionery
- has Wikipedia article: en

## DISH Q3503191
- name: Suisse de Valence
- other names: {"zh": "瑞士饼"}
- description: French man-shaped cookie
- countries: (none)
- kinds: biscuit

## DISH Q3505415
- name: Farina
- description: cereal meal
- countries: (none)
- kinds: porridge, groat
- ingredients: semolina
- has Wikipedia article: en

## DISH Q35056
- name: Angel wings
- other names: {"zh": "比涅甜饼"}
- description: sweet crisp pastry
- countries: BY, UA
- cuisines: Belarusian cuisine, Ukrainian cuisine
- kinds: dish, food, pastry
- ingredients: sugar, dough, lard, flour, egg
- has Wikipedia article: en

## DISH Q3505757
- name: Sautéed reindeer
- other names: {"zh": "炒驯鹿肉"}
- description: traditional meal from Lapland and Sakha (Yakutia)
- countries: FI, NO, RU, SE
- kinds: dish, meat dish
- ingredients: reindeer meat
- has Wikipedia article: en, zh

## DISH Q3509587
- name: Agemochi
- description: snack
- countries: JP
- kinds: mochi, snack, Agemono
- ingredients: mochi
- has Wikipedia article: en

## DISH Q3513513
- name: Tablier de sapeur
- description: Lyonnais dish made from beef tripe
- countries: FR
- cuisines: Lyonnaise cuisine
- kinds: dish
- ingredients: gras double
- has Wikipedia article: en

## DISH Q3513992
- name: Taillaule
- description: Swiss regional variety of brioche
- countries: CH
- kinds: brioche

## DISH Q3514113
- name: Tunisian tarte
- description: Tunisian dish
- countries: TN
- kinds: dish

## DISH Q3514675
- name: Tamari shoyu
- description: Japanese soy sauce
- countries: JP
- kinds: soy sauce
- has Wikipedia article: en

## DISH Q3515850
- name: Maroilles tart
- description: savoury tart made using Maroilles cheese
- countries: (none)
- kinds: pie
- ingredients: Maroilles, dough

## DISH Q3515851
- name: Tarte au maugin
- countries: (none)
- kinds: sweet pie
- ingredients: fromage blanc

## DISH Q3515852
- name: Tarte au vin
- other names: {"fr": "Tarte au vin"}
- countries: CH
- kinds: sweet pie

## DISH Q3515855
- name: Tarte aux quetsches
- other names: {"es": "Tarte aux quetsches"}
- countries: (none)
- kinds: sweet tart
- ingredients: damson, migaine, sweetcrust pastry

## DISH Q3515859
- name: Tarte Tropézienne
- description: French dessert pastry
- countries: FR
- kinds: pastry, sweet pie
- ingredients: brioche
- has Wikipedia article: en

## DISH Q3515860
- name: Tarte à la banane
- other names: {"fr": "tarte à la banane"}
- countries: (none)
- kinds: sweet pie

## DISH Q3515861
- name: Norman Tart
- other names: {"zh": "諾曼撻"}
- description: French almond dessert
- countries: FR
- kinds: sweet pie
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q3515862
- name: Tarte à la gomme
- countries: FR
- kinds: food, dessert, tart
- ingredients: flan

## DISH Q3518532
- name: Terra di Bari PDO
- other names: {"zh": "Terra di Bari DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3518777
- name: Terrine normande
- other names: {"fr": "Terrine normande"}
- countries: FR
- kinds: dish

## DISH Q3520287
- name: Puttu
- description: South Indian breakfast dish of steamed ground rice and coconut shavings
- countries: IN, LK
- kinds: food, rice dish
- ingredients: rice flour, Oryza, Cocos nucifera
- has Wikipedia article: en

## DISH Q3520299
- name: Nasi kandar
- other names: {"zh": "扁担饭"}
- description: Indian rice dish
- countries: IN
- kinds: dish, food
- ingredients: rice
- has Wikipedia article: en

## DISH Q352253
- name: Adana kebabı
- other names: {"zh": "阿达纳烤肉"}
- description: kebab from the Turkish cuisine, originating from the southern city of Adana
- countries: TR
- cuisines: Turkish cuisine
- kinds: kebab
- has Wikipedia article: en, zh

## DISH Q3528208
- name: Tielle
- description: type of pie
- countries: (none)
- kinds: pie

## DISH Q3530197
- name: Tocană
- description: Romanian stew
- countries: (none)
- kinds: ragout
- has Wikipedia article: en

## DISH Q3530321
- name: Tofailles
- countries: (none)
- kinds: potato dish
- ingredients: onion, butter, bacon, potato, white wine

## DISH Q3531002
- name: Tomate crevette
- description: Belgian stuffed tomato
- countries: (none)
- kinds: dish, appetizer
- ingredients: tomato, shrimp and prawn as food, lemon juice, mayonnaise, parsley

## DISH Q3531005
- name: Tomates à la provençale
- countries: (none)
- kinds: tomato dish

## DISH Q3531219
- name: 尚索尔奶酪
- countries: FR
- cuisines: cuisine niçoise
- kinds: white mold-rind cheese, pressed uncooked cheese, French cheese, farmstead cheese, dairy cheese, cheese
- ingredients: cow's milk

## DISH Q3531223
- name: Fresh Tomme
- description: French cheese
- countries: FR
- kinds: cheese, French cheese, farmstead cheese, industrial cheese, fresh cheese, dairy cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q3532515
- name: Torta Barozzi
- description: Italian cake
- countries: IT
- cuisines: cuisine of the province of Modena
- kinds: cake, chocolate cake
- has Wikipedia article: en

## DISH Q3532517
- name: Tortelli di patate
- countries: IT
- kinds: type of pasta, potato dish

## DISH Q3534131
- name: Tourment d'amour
- other names: {"fr": "Tourment d'amour"}
- countries: (none)
- kinds: cake

## DISH Q3535543
- name: Tourte de blettes
- other names: {"zh": "蓬蒿饼"}
- description: Culinary specialty from Nice, France
- countries: (none)
- cuisines: cuisine niçoise
- kinds: dish
- has Wikipedia article: en

## DISH Q3535544
- name: 贝里土豆烧饼
- countries: (none)
- kinds: potato dish

## DISH Q3535545
- name: Woolton pie
- description: vegetable pie
- countries: GB
- kinds: potato dish, pie
- has Wikipedia article: en

## DISH Q3535559
- name: Tourtière (Llemosí)
- other names: {"ca": "Tourtière (Llemosí)"}
- countries: (none)
- kinds: potato dish

## DISH Q3535568
- name: Tortú
- other names: {"ca": "Tortú"}
- countries: (none)
- kinds: dish

## DISH Q3535569
- name: Tourtière
- other names: {"zh": "加拿大肉餡餅"}
- description: French-Canadian meat pie dish
- countries: CA
- kinds: pork dish, beef dish, veal dish, savoury pie
- ingredients: pork
- has Wikipedia article: en

## DISH Q3537640
- name: Misal Pav
- description: Indian Spicy dish
- countries: IN
- kinds: food, Indian curry
- has Wikipedia article: en

## DISH Q3539309
- name: Trinxat
- description: resembles bubble and squeak
- countries: AD, ES
- kinds: tradition, potato dish, pork dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q3540823
- name: Trou d'Sottai
- other names: {"fr": "Trou d'Sottai"}
- countries: BE
- kinds: cheese, list of Belgian cheeses, washed-rind cheese
- ingredients: cow's milk

## DISH Q3542626
- name: Txangurro
- other names: {"fr": "Txangurro"}
- countries: (none)
- kinds: dish

## DISH Q3543273
- name: Xôi
- other names: {"zh": "越式糯米饭"}
- description: Vietnamese rice dish
- countries: VN
- kinds: rice dish
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q3543297
- name: Puto
- other names: {"zh": "蛋糕"}
- description: type of steamed rice cake
- countries: PH
- kinds: street food, rice cake, rice dish, jajan pasar
- ingredients: rice
- has Wikipedia article: en

## DISH Q3543359
- name: Kaldereta
- other names: {"zh": "卡爾德拉塔"}
- description: goat meat stew from the Philippines
- countries: PH
- kinds: viand, goat meat dish
- has Wikipedia article: en, zh

## DISH Q3543376
- name: Suman
- other names: {"zh": "苏曼"}
- description: rice cake originating in the Philippines
- countries: PH
- kinds: Binalot
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q3543394
- name: Arròs negre
- other names: {"zh": "墨鱼饭"}
- description: Valencian and Catalan dish made with cuttlefish (or squid) and rice
- countries: ES
- cuisines: Valencian cuisine, Catalan cuisine
- kinds: main course, squid dish
- ingredients: white rice
- has Wikipedia article: en, zh

## DISH Q3543397
- name: Espasol
- description: cylinder-shaped Filipino rice cake
- countries: PH
- kinds: pudding
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q3543525
- name: Dinuguan
- other names: {"zh": "燉豬血"}
- description: Filipino savory stew
- countries: PH
- kinds: pork dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q3543686
- name: Ginataan
- other names: {"zh": "菲律賓椰奶湯"}
- description: Filipino dish made with coconut milk
- countries: PH
- kinds: food, dish
- ingredients: coconut milk
- has Wikipedia article: en

## DISH Q3543811
- name: Pork and beans
- description: culinary dish
- countries: (none)
- kinds: pork dish, legume dish
- ingredients: bean, pork
- has Wikipedia article: en

## DISH Q3544203
- name: Bakpia pathok
- description: Indonesian sweet rolls
- countries: ID
- kinds: jajan pasar, food, cookie, bakpia
- ingredients: wheat flour, coconut milk, vanilla, table salt, sugar, margarine
- has Wikipedia article: en

## DISH Q3544562
- name: Sinigang
- other names: {"zh": "Sinigang"}
- description: Filipino sour soup
- countries: PH
- kinds: viand, sour soup
- ingredients: fish as food, vegetable, meat
- has Wikipedia article: en, zh

## DISH Q3544579
- name: Vispipuuro
- description: dessert porridge made from semolina and berries, usually lingonberries
- countries: (none)
- kinds: dessert, porridge
- ingredients: lingonberry, semolina, water
- has Wikipedia article: en

## DISH Q3545233
- name: Champorado
- other names: {"zh": "巧克力粥"}
- description: chocolate rice porridge made in the Philippines
- countries: PH
- cuisines: Filipino cuisine
- kinds: chocolate dish, rice porridge
- ingredients: glutinous rice
- has Wikipedia article: en, zh

## DISH Q3545686
- name: Mote
- description: corn kernels boiled in lime
- countries: (none)
- kinds: meal, food, dish, maize
- ingredients: maize
- has Wikipedia article: en

## DISH Q3548107
- name: Tahô
- description: Philippine snack food
- countries: PH
- kinds: snack, soy food
- ingredients: glucose syrup, tofu
- has Wikipedia article: en

## DISH Q3549118
- name: Palitaw
- description: rice cake eaten in the Philippines
- countries: PH
- kinds: pudding
- ingredients: glutinous rice
- has Wikipedia article: en

## DISH Q3549166
- name: Pandesal
- other names: {"zh": "鹽麵包"}
- description: Type of Philippine bread
- countries: PH
- kinds: food, sweet bread
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q3550480
- name: Tinola
- description: Filipino soup dish
- countries: PH
- kinds: food, soup
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q3552200
- name: Bagoong terong
- description: common ingredient used in the Philippines and particularly in Northern Ilocano cuisine
- countries: (none)
- kinds: fish sauce
- has Wikipedia article: en

## DISH Q3552223
- name: Siopao
- other names: {"zh": "燒包"}
- description: Philippine steamed bun
- countries: PH
- kinds: baozi, dish
- ingredients: starch
- has Wikipedia article: en, zh

## DISH Q3553107
- name: Vacherin
- description: type of dessert
- countries: (none)
- kinds: dessert
- has Wikipedia article: en

## DISH Q3553500
- name: Valda
- other names: {"nl": "Valda"}
- countries: (none)
- kinds: medication, cough drop

## DISH Q3553945
- name: Valle d'Aosta Jambon de Bosses PDO
- other names: {"zh": "Valle d'Aosta Jambon de Bosses DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: food, meat product, prosciutto
- has Wikipedia article: en

## DISH Q3553946
- name: Vallée d'Aoste Lard d'Arnad PDO
- other names: {"zh": "Vallée d'Aoste Lard d'Arnad DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, lardo
- has Wikipedia article: en

## DISH Q3555005
- name: Vastedda della valle del Belice PDO
- other names: {"zh": "Vastedda della valle del Belice DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, pasta filata, Italian cheese
- ingredients: sheep milk

## DISH Q3555007
- name: Vastedda
- description: type of Sicilian bread
- countries: IT
- kinds: bread
- has Wikipedia article: en

## DISH Q3555103
- name: Vaution
- other names: {"fr": "vaution"}
- countries: (none)
- kinds: cake
- ingredients: dough

## DISH Q3555157
- name: Veal Orloff
- other names: {"zh": "小牛肉奥尔洛夫"}
- description: 19th century dish of French cuisine
- countries: FR
- kinds: veal dish
- ingredients: Soubise sauce, Mornay sauce, duxelles, veal
- has Wikipedia article: en

## DISH Q3557655
- name: Victor et Berthold
- other names: {"fr": "Victor et Berthold"}
- description: Canadian cheese
- countries: CA
- kinds: cheese from Quebec, cheese, pressed uncooked cheese
- ingredients: cow's milk

## DISH Q35586024
- name: Rummaneyye
- description: Palestinian dish made of lentils and eggplant, leavened with pomegranate juice or molasses
- countries: TR
- kinds: dish, food
- ingredients: lentil, pomegranate juice
- has Wikipedia article: en

## DISH Q3559983
- name: Vindaye
- countries: MU
- kinds: culinary speciality

## DISH Q3561219
- name: Potatiskorv
- description: Swedish sausage
- countries: (none)
- kinds: potato dish
- has Wikipedia article: en

## DISH Q356346
- name: Rumford's Soup
- other names: {"zh": "伦福德粥"}
- description: soup of barley, dried peas, potatoes, and beer
- countries: (none)
- cuisines: Bavarian cuisine
- kinds: soup, dish
- ingredients: dried pea, potato, sour beer, pearl barley
- has Wikipedia article: en

## DISH Q3565924
- name: Bolo do caco
- description: Typical bread from Madeira, Portugal
- countries: PT
- kinds: bread, dish
- ingredients: garlic, whole wheat bread, Sweet potato, butter, table salt
- has Wikipedia article: en

## DISH Q35661296
- name: Rice porridge
- countries: (none)
- kinds: rice dish, porridge
- ingredients: rice

## DISH Q3569657
- name: Gebrochts
- description: matzo that has absorbed liquid
- countries: (none)
- kinds: food, matzah
- has Wikipedia article: en

## DISH Q3570585
- name: Xató
- description: sauce in Catlan cooking
- countries: ES
- kinds: salad, sauce
- has Wikipedia article: en

## DISH Q3571325
- name: Chireta
- description: aragonese type of savoury pudding
- countries: ES
- kinds: pudding
- has Wikipedia article: en

## DISH Q3572640
- name: Yosenabe
- countries: JP
- kinds: nabemono
- ingredients: broth

## DISH Q3573026
- name: Torta
- other names: {"zh": "意大利圆顶蛋糕"}
- description: umbrella term for cakes, pies, flatbreads, sandwiches and omelettes
- countries: ES
- kinds: umbrella term, type of food or dish, baked good
- ingredients: cheese, cold cut, milk, bread, embutido, birote salad, bolillo, Cochinita pibil, guiso, Romaine lettuce, tamale, avocado, refried beans, jalapeño, mayonnaise, egg as food, tomato, onion, vanilla, sugar
- has Wikipedia article: en

## DISH Q3573091
- name: Yuanxiao
- other names: {"zh": "元宵"}
- description: glutinous rice dish shaken from fillings, different from Tangyuan
- countries: (none)
- kinds: rice dish
- has Wikipedia article: en, zh

## DISH Q3574648
- name: Ternasco de Aragón
- description: Protected geographical indication of lamb meat
- countries: ES
- kinds: food, lamb meat

## DISH Q3576541
- name: Zézette de Sète
- countries: FR
- kinds: pastry
- ingredients: flour, vanilla, sugar, white wine

## DISH Q3577245
- name: Ça va se savoir
- countries: CM
- kinds: pastry, dish, beignet

## DISH Q3577420
- name: Echaude
- description: scalded pastry
- countries: FR
- kinds: pastry, dessert

## DISH Q35778572
- name: Laghman
- other names: {"zh": "拉条子"}
- description: Central Asian noodle dish
- countries: (none)
- kinds: noodle, dish
- has Wikipedia article: en, zh

## DISH Q358507
- name: Bosna
- description: It resembles a hot dog, consisting mainly of a Bratwurst sausage, onions and a blend of mustard and/or tomato ketchup and curry powder (Curry ketchup).
- countries: AT
- kinds: sandwich
- ingredients: onion, white bread, curry powder, Bratwurst, ketchup, mustard, Allium, bread
- has Wikipedia article: en

## DISH Q3589163
- name: Espinacs amb panses i pinyons
- other names: {"ca": "espinacs amb panses i pinyons"}
- countries: (none)
- kinds: dish
- ingredients: pine nut, Spinacia oleracea, raisin

## DISH Q3594111
- name: Huevo a la Toupinel
- other names: {"es": "Huevo a la Toupinel"}
- countries: (none)
- kinds: potato dish

## DISH Q3594113
- name: Snail caviar
- other names: {"zh": "蝸牛子醬"}
- description: Fresh or processed eggs of land snails
- countries: (none)
- kinds: dish, food
- ingredients: egg
- has Wikipedia article: en, zh

## DISH Q3594115
- name: Mid-boiled egg
- description: egg boiled during 5 minutes
- countries: (none)
- kinds: boiled egg

## DISH Q3594122
- name: Oeufs en meurette
- description: eggs in meurette sauce
- countries: FR
- cuisines: French cuisine
- kinds: dish, egg dish
- ingredients: sauce Bourguignonne, poached egg
- has Wikipedia article: en

## DISH Q35944
- name: Panellets
- description: Spanish pastry
- countries: ES
- kinds: dessert
- ingredients: marzipan
- has Wikipedia article: en

## DISH Q3595351
- name: Sadya
- description: Traditional feast in Kerala, India
- countries: IN
- kinds: food, festive meal
- ingredients: Pachadi, Koottukari, Olan, Thoran, Kichadi, Kaalan, Injipuli, Rasam, achar, Avial, papad, banana chip, sambar, buttermilk, banana
- has Wikipedia article: en

## DISH Q3595555
- name: Keema curry
- countries: IN
- kinds: lamb dish, Indian curry
- ingredients: minced meat, lamb meat

## DISH Q3595628
- name: Pathiri
- description: Indian Food
- countries: IN
- kinds: food, bread
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q3596097
- name: Tomato sauce
- other names: {"zh": "番茄沙司"}
- description: sauce made primarily from tomatoes
- countries: IT
- kinds: mother sauce, sauce, sugo, tomato dish
- ingredients: tomato, extra virgin olive oil, basil, table salt
- has Wikipedia article: en, zh

## DISH Q3596227
- name: 'Nzuddha
- other names: {"it": "'Nzuddha"}
- countries: IT
- kinds: dessert

## DISH Q3596242
- name: 'O pere e 'o musso
- description: Italian street food from Naples
- countries: (none)
- kinds: street food
- has Wikipedia article: en

## DISH Q3597267
- name: Black sesame roll
- other names: {"zh": "芝麻卷"}
- description: Refrigerated dim sum dessert
- countries: CN
- cuisines: Chinese cuisine
- kinds: pastry
- has Wikipedia article: en, zh

## DISH Q3599457
- name: 5 e 5
- countries: IT
- kinds: bread roll, pastry

## DISH Q3603155
- name: Abbamele
- description: honey-based product from rural Sardinia
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q3604288
- name: Aceto balsamico tradizionale di Reggio Emilia PDO
- other names: {"zh": "Aceto balsamico tradizionale di Reggio Emilia DOP"}
- description: Italian PDO agricultural product
- countries: IT
- kinds: condiment, agricultural product, balsamic vinegar

## DISH Q3606260
- name: Africani
- other names: {"it": "Africani"}
- countries: IT
- kinds: dessert

## DISH Q3606603
- name: Agliata
- description: savory and pungent garlic sauce and condiment in Italian cuisine
- countries: IT
- cuisines: Italian cuisine
- kinds: dish, sauce
- ingredients: Allium sativum
- has Wikipedia article: en

## DISH Q3606626
- name: Agnello di Sardegna PGI
- other names: {"zh": "Agnello di Sardegna IGP"}
- description: Italian PGI fresh meat
- countries: IT
- kinds: meat, lamb meat

## DISH Q3606633
- name: Agnello pasquale
- description: lamb-shaped Italian cake
- countries: IT
- kinds: dessert

## DISH Q3606896
- name: Agrì di valtorta PAT
- other names: {"zh": "Agrì di valtorta PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product, cow's-milk cheese, Italian cheese
- ingredients: cow's milk

## DISH Q3607167
- name: Ainuzzi
- countries: IT
- kinds: pasta filata, Italian cheese

## DISH Q3610216
- name: Diyabath
- description: Sri Lankan cold soup
- countries: LK
- kinds: food, soup
- ingredients: rice
- has Wikipedia article: en

## DISH Q3613295
- name: Alto Crotonese PDO
- other names: {"zh": "Alto Crotonese DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3613674
- name: Amaro San Giuseppe
- other names: {"it": "Amaro San Giuseppe"}
- countries: IT
- kinds: bitters

## DISH Q3614508
- name: Amor
- other names: {"it": "Amor"}
- countries: IT
- kinds: dessert

## DISH Q3616613
- name: Anello di Monaco
- description: Italian sweet bread
- countries: IT
- kinds: yeast bread, sweet bread
- ingredients: baker's yeast, egg as food, flour, butter, sugar

## DISH Q36180436
- name: Goat milk ice cream
- countries: (none)
- kinds: ice cream
- ingredients: goat milk

## DISH Q3618208
- name: Anolini
- description: Type of pasta
- countries: IT
- kinds: pasta

## DISH Q3621054
- name: Aprutino Pescarese PDO
- other names: {"zh": "Aprutino Pescarese DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil
- has Wikipedia article: en

## DISH Q3622651
- name: Arista
- other names: {"it": "Arista"}
- countries: IT
- kinds: dish, cuts of pork

## DISH Q3625357
- name: Assabesi
- other names: {"it": "Assabesi"}
- countries: IT
- kinds: dessert

## DISH Q3630112
- name: Gundruk
- description: Nepali fermented leafy vegetable
- countries: NP
- kinds: fermented food
- ingredients: radish, cauliflower
- has Wikipedia article: en

## DISH Q3630852
- name: Puran Poli
- description: sweet dish of South India
- countries: IN
- kinds: food, flatbread
- has Wikipedia article: en

## DISH Q3632870
- name: Baghara baingan
- description: Hyderabadi cuisine
- countries: (none)
- kinds: Indian curry, eggplant dish
- ingredients: eggplant
- has Wikipedia article: en

## DISH Q3632937
- name: Bagnun
- description: Italian soup
- countries: IT
- kinds: food, soup
- ingredients: Engraulidae
- has Wikipedia article: en

## DISH Q3633458
- name: Ballokume
- description: Traditional Albanian sweet pastry
- countries: AL
- kinds: pastry
- has Wikipedia article: en

## DISH Q3634389
- name: Baati
- description: type of bread popular in western India
- countries: (none)
- kinds: food, bread
- ingredients: ghee
- has Wikipedia article: en

## DISH Q3634426
- name: Rumali Roti
- other names: {"zh": "印度飞饼"}
- description: Types of flatbreads
- countries: (none)
- kinds: food, bread
- ingredients: atta
- has Wikipedia article: en, zh

## DISH Q3634538
- name: Sheermal
- description: Iranian flatbread
- countries: IR
- cuisines: Awadhi cuisine, Iranian cuisine
- kinds: food product, naan
- ingredients: cardamom, maida flour, saffron, sugar, milk
- has Wikipedia article: en

## DISH Q3636224
- name: Batsoà
- description: Italian pig's trotter recipe
- countries: IT
- kinds: dish
- has Wikipedia article: en

## DISH Q36368321
- name: Tostons
- other names: {"ca": "Tostons"}
- countries: (none)
- ingredients: olive oil, maize

## DISH Q3637056
- name: Baxin d'Albenga
- other names: {"it": "baxin d'Albenga"}
- description: Italian sweet baked good
- countries: IT
- cuisines: cuisine of Liguria
- kinds: dessert
- has Wikipedia article: en

## DISH Q3639714
- name: Bicciolani di Vercelli
- countries: IT
- kinds: dessert, biscuit

## DISH Q3640406
- name: Bisciola PAT
- other names: {"zh": "Bisciola PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- cuisines: cuisine of Valtellina
- kinds: baked good, confectionery, sweet bread
- has Wikipedia article: en

## DISH Q3640407
- name: Biscione reggiano
- other names: {"it": "Biscione reggiano"}
- countries: IT
- kinds: dessert

## DISH Q3640409
- name: Biscottini di Prosto
- description: Typical biscuits of Valchiavenna, Italy
- countries: IT
- kinds: biscuit

## DISH Q3640410
- name: Biscotto di Castellammare
- other names: {"it": "biscotto di Castellammare"}
- countries: IT
- kinds: dessert

## DISH Q3640411
- name: Ceglie biscuit
- description: biscuit made with almonds typical of Ceglie, Brindisi, Apulia, Italy
- countries: IT
- cuisines: Apulian cuisine
- kinds: biscuit, dessert

## DISH Q36415
- name: Roast goose
- other names: {"zh": "燒鵝"}
- description: dish
- countries: CN
- kinds: roast, meat dish, type of cooked meat
- ingredients: goose meat, Anserini
- has Wikipedia article: en, zh

## DISH Q3641520
- name: Boudin PAT
- other names: {"zh": "Boudin PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product, blood sausage
- ingredients: potato

## DISH Q3641568
- name: Boeuf à la mode
- other names: {"zh": "法式烧牛肉"}
- description: French braised beef dish
- countries: FR
- kinds: beef dish
- has Wikipedia article: en

## DISH Q3642641
- name: Borlengo
- description: Italian thin flatbread
- countries: IT
- cuisines: cuisine of the province of Modena
- kinds: food, pancake
- ingredients: milk
- has Wikipedia article: en

## DISH Q3642907
- name: Beer bread
- description: Bread baked with beer in the dough
- countries: (none)
- kinds: bread, baked good
- ingredients: beer-dough, flour
- has Wikipedia article: en

## DISH Q3642935
- name: Bossolà bresciano
- other names: {"zh": "布索拉"}
- countries: IT
- kinds: dessert

## DISH Q3643465
- name: Braciola
- other names: {"zh": "酒燴肉卷"}
- description: any of several Italian dishes
- countries: IT
- kinds: primal cut
- has Wikipedia article: en

## DISH Q3644493
- name: Samp
- description: South African corn kernel dish
- countries: ZA
- kinds: dish
- ingredients: maize
- has Wikipedia article: en

## DISH Q3644926
- name: Brisighella PDO
- other names: {"zh": "Brisighella DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3645416
- name: Brovada PDO
- other names: {"zh": "Brovada DOP"}
- description: Italian PDO fruit, vegetable or cereal product
- countries: IT
- kinds: agricultural product, dish

## DISH Q3646090
- name: Brustico
- countries: IT
- kinds: dish
- ingredients: European perch

## DISH Q3646108
- name: Brutti e buoni
- description: cookie of Italian origin
- countries: IT
- kinds: dessert, biscuit
- ingredients: almond, Prunus dulcis
- has Wikipedia article: en

## DISH Q3646112
- name: Bruzio PDO
- other names: {"zh": "Bruzio DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil
- has Wikipedia article: en

## DISH Q3646253
- name: Buccellato di Lucca
- description: sweet bread; cake typical of Lucca, Italy
- countries: IT
- kinds: cake, sweet bread
- ingredients: sultana
- has Wikipedia article: en

## DISH Q3647260
- name: Burebrot
- description: Swiss bread
- countries: CH
- kinds: bread
- ingredients: Saccharomyces cerevisiae, flour, milk, water
- has Wikipedia article: en

## DISH Q3647314
- name: Buridda
- description: seafood soup or stew from Liguria, in Italy
- countries: IT
- kinds: fish dish, food, soup
- ingredients: broth
- has Wikipedia article: en

## DISH Q3647608
- name: Bussilan
- other names: {"it": "Bussilan"}
- countries: IT
- kinds: dessert

## DISH Q3647615
- name: Bussolano
- other names: {"it": "Bussolano"}
- countries: IT
- kinds: dessert

## DISH Q3650577
- name: Caldo freddo
- other names: {"it": "caldo freddo"}
- countries: IT
- kinds: dessert with spoon

## DISH Q3651097
- name: Calzone di San Leonardo
- other names: {"it": "Calzone di San Leonardo"}
- countries: IT
- kinds: dessert
- ingredients: Vincotto

## DISH Q3655318
- name: Canestrato di Moliterno
- other names: {"zh": "Canestrato di Moliterno IGP"}
- description: Italian PGI cheese
- countries: IT
- kinds: cheese, Italian cheese

## DISH Q3655321
- name: Canestrelli novesi
- description: Italian cookie
- countries: IT
- kinds: cookie

## DISH Q3655393
- name: Cannarìculi
- other names: {"es": "Cannarìculi"}
- countries: IT
- kinds: dessert

## DISH Q3655437
- name: Cannolo (dolce di sfoglia)
- other names: {"it": "Cannolo (dolce di sfoglia)"}
- countries: IT
- kinds: dessert
- ingredients: puff pastry

## DISH Q3657738
- name: Cappellacci di zucca ferraresi PGI
- other names: {"zh": "Cappellacci di zucca ferraresi IGP"}
- description: Italian PGI pasta
- countries: IT
- kinds: type of pasta, pasta, stuffed pasta, egg pasta
- ingredients: durum flour, common wheat flour, grated cheese, bread crumbs, pumpkin, egg as food, nutmeg

## DISH Q3657790
- name: Cappon magro
- description: Italian seafood salad
- countries: IT
- kinds: salad, seafood salad, fish dish
- ingredients: seafood
- has Wikipedia article: en

## DISH Q3658173
- name: Caragnoli
- other names: {"it": "Caragnoli"}
- countries: IT
- kinds: dessert

## DISH Q3658569
- name: Carfogn
- other names: {"it": "Carfogn"}
- countries: IT
- kinds: dessert

## DISH Q3660404
- name: Carne cruda alla piemontese
- description: Italian version of steak tartare
- countries: IT
- kinds: raw beef dish
- ingredients: garlic, lemon juice, beef

## DISH Q3660408
- name: Carne Salada del Trentino
- other names: {"zh": "Carne salada del trentino PAT"}
- description: Italian cured beef product with Protected Geographical Indication (PGI) status
- countries: IT
- kinds: dish, meat product, appetizer

## DISH Q3660463
- name: Sicilian meat
- description: Fresh beef, sheep, goat and pork from Sicily
- countries: IT
- kinds: food, meat
- ingredients: sheep meat, goat meat, beef, pork

## DISH Q3660942
- name: Cartoceto PDO
- other names: {"zh": "Cartoceto DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3661871
- name: Casoncelli
- description: type of stuffed pasta used traditionally in Lombardy
- countries: IT
- kinds: stuffed pasta
- has Wikipedia article: en

## DISH Q3661967
- name: Cassatella di Agira
- description: typical Sicilian dessert
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dessert
- has Wikipedia article: en

## DISH Q3661968
- name: Cassatelle
- description: Sicilian deep-fried Italian pastry
- countries: IT
- kinds: dessert, pastry
- ingredients: ricotta

## DISH Q3661969
- name: Cassatella di Sant'Agata
- description: traditional pastry from Catania, Italy
- countries: IT
- cuisines: Italian cuisine
- kinds: dessert
- ingredients: succade, sponge cake, ceramic glaze, ricotta, marzipan, sugar
- has Wikipedia article: en

## DISH Q3662063
- name: Castagnole
- countries: IT
- kinds: confectionery

## DISH Q3663945
- name: Cavallucci
- description: Italian Christmas pastry
- countries: IT
- kinds: biscuit
- ingredients: anise seed
- has Wikipedia article: en

## DISH Q3664285
- name: Celli ripieni
- other names: {"it": "celli ripieni"}
- countries: IT
- kinds: dish

## DISH Q3664954
- name: Ceppe
- other names: {"it": "ceppe"}
- countries: IT
- cuisines: cuisine of Teramo
- kinds: type of pasta, egg pasta

## DISH Q3665214
- name: Certosino
- description: Italian cake
- countries: (none)
- kinds: dessert

## DISH Q3665589
- name: Baumkuchen
- other names: {"zh": "年轮蛋糕"}
- description: German spit cake
- countries: DE
- cuisines: German cuisine
- kinds: spit cake
- ingredients: layer, flour
- has Wikipedia article: en, zh

## DISH Q3666048
- name: Chomchom
- description: traditional Bengali sweet
- countries: (none)
- kinds: confectionery
- ingredients: milk
- has Wikipedia article: en

## DISH Q36672065
- name: Веснушка
- other names: {"ru": "веснушка"}
- countries: (none)
- kinds: food, dish

## DISH Q3667436
- name: Chianti Classico PDO
- other names: {"zh": "Chianti Classico DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil, extra virgin olive oil

## DISH Q3667736
- name: Chicharrón
- other names: {"zh": "Chicharrón"}
- description: Spanish and Latin American dish of pork belly or pork rind
- countries: ES
- cuisines: Andalusian cuisine
- kinds: food, pork dish
- ingredients: pork skin, pork belly
- has Wikipedia article: en, zh

## DISH Q3668413
- name: Kesme
- description: traditional egg noodles found in various Turkic cuisines
- countries: TR
- kinds: food, noodle, dish
- ingredients: flour, egg, salt, water
- has Wikipedia article: en

## DISH Q3668429
- name: Keşkek
- other names: {"zh": "凯斯凯克"}
- description: an Anatolian meat and grain stew that is listed in the UNESCO World Intangible Cultural Heritage List
- countries: TR
- cuisines: Turkish cuisine, Greek cuisine, Iranian cuisine
- kinds: stew
- has Wikipedia article: en

## DISH Q3668485
- name: Alinazik kebab
- description: Turkish dish
- countries: TR
- kinds: food, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q367225
- name: Pea soup
- other names: {"zh": "豌豆湯"}
- description: thick soup usually made out of dried split peas
- countries: (none)
- kinds: recipe, dish, vegetable soup
- ingredients: pea
- has Wikipedia article: en, zh

## DISH Q3674722
- name: Chimaki
- other names: {"zh": "日本粽子"}
- countries: JP
- kinds: mochi

## DISH Q3675184
- name: Chisciöi
- description: buckwheat pancake of Italy
- countries: IT
- cuisines: cuisine of Valtellina
- kinds: buckwheat pancake
- ingredients: buckwheat flour, Valtellina Casera PDO

## DISH Q3675266
- name: Petrali
- other names: {"ca": "petrali"}
- countries: (none)
- kinds: Christmas dessert
- ingredients: orange peel, Vino cotto, fig, sultana, white chocolate, sweetcrust pastry, almond, egg yolk, icing, nut, sugar, chocolate

## DISH Q3675466
- name: Kattama
- other names: {"zh": "卡提尔玛"}
- description: flatbread from the Turkish and Central Asian cuisines
- countries: KZ, TR, KG
- cuisines: Kazakh cuisine, Turkish cuisine, Kyrgyz cuisine
- kinds: food, flatbread, Turkish breads
- ingredients: dough, onion
- has Wikipedia article: en

## DISH Q3676186
- name: Kuymak
- description: cornmeal, butter and cheese dish from the central-eastern Black Sea Region of Turkey
- countries: RS, TR
- kinds: food, dish
- ingredients: cornmeal, butter, cheese
- has Wikipedia article: en

## DISH Q3676246
- name: Cialda di Montecatini
- other names: {"it": "Cialda di Montecatini"}
- countries: IT
- kinds: dessert

## DISH Q3676248
- name: Ciambella romagnola
- description: traditional loaf shaped cake
- countries: IT
- kinds: dish
- has Wikipedia article: en

## DISH Q3676251
- name: Ciambellino
- countries: IT
- kinds: dessert

## DISH Q3676255
- name: Ciambotta
- description: Italian stew
- countries: IT
- kinds: stew
- ingredients: vegetable
- has Wikipedia article: en

## DISH Q3676322
- name: Ciavarro
- description: Italian soup
- countries: IT
- kinds: food, lentil soup

## DISH Q3676324
- name: Ciauscolo PGI
- other names: {"zh": "Ciauscolo IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: sausage, meat product, salume
- ingredients: pork
- has Wikipedia article: en

## DISH Q3676366
- name: Ciccioli della Val Leogra PAT
- other names: {"zh": "Ciccioli della Val Leogra PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product, ciccioli

## DISH Q3676383
- name: Cicerchiata
- description: Italian carnival dessert
- countries: IT
- kinds: dish

## DISH Q3676632
- name: Cilento PDO
- other names: {"zh": "Cilento DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3677424
- name: Suasa's onion
- description: typical onion from Castelleone di Suasa
- countries: IT
- kinds: onion, prodotto agroalimentare tradizionale

## DISH Q3677884
- name: Ezogelin soup
- description: Turkish soup
- countries: TR
- kinds: soup, dish, Turkish soups
- ingredients: bulgur
- has Wikipedia article: en

## DISH Q3678059
- name: Çılbır
- description: an egg dish from the Turkish cuisine
- countries: TR
- kinds: dish, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q3678143
- name: Ciriola
- description: Roman bread
- countries: IT
- kinds: bread
