# Review batch names-010

## DISH Q11274724
- name: Nikuten
- countries: JP
- kinds: teppanyaki

## DISH Q11274765
- name: Nishin-zushi
- countries: JP
- kinds: narezushi
- ingredients: migaki nishin

## DISH Q11274898
- name: Ninjin shirishiri
- countries: JP
- kinds: egg dish, vegetable dish
- ingredients: egg as food, carrot

## DISH Q11274925
- name: ぬっぺ汁
- other names: {"ja": "ぬっぺ汁"}
- countries: JP
- kinds: shirumono

## DISH Q11274940
- name: Nure senbei
- other names: {"zh": "濕仙貝"}
- description: soft texture rice cracker
- countries: (none)
- kinds: senbei

## DISH Q11274985
- name: Negiyaki
- description: scallion pancake
- countries: JP
- kinds: pancake, teppanyaki
- ingredients: sujikon, wheat flour, Welsh onion

## DISH Q11275028
- name: Neko manma
- other names: {"zh": "貓飯"}
- description: Japanese soup rice named "cat's rice" because of its appearance
- countries: (none)
- kinds: Japanese rice dish

## DISH Q11275121
- name: Nerikuri
- description: Local cuisine of Kagoshima and Miyazaki prefecture
- countries: (none)
- kinds: mochi, vegetable dish
- ingredients: sweet potato, kinako, mochi
- has Wikipedia article: en

## DISH Q11275124
- name: ねり飴
- other names: {"ja": "ねり飴"}
- countries: (none)
- kinds: ame

## DISH Q11275153
- name: のし梅
- other names: {"ja": "のし梅"}
- countries: JP
- kinds: confectionery

## DISH Q11275191
- name: Noppe
- countries: JP
- kinds: nimono

## DISH Q11275307
- name: Nō manjū
- description: steamed manju confection from Okinawa Prefecture, Japan
- countries: (none)
- kinds: manjū, nikuman

## DISH Q11275349
- name: 秤丼
- countries: JP
- kinds: donburi

## DISH Q11275521
- name: はたさくらまんじゅう
- other names: {"ja": "はたさくらまんじゅう"}
- countries: (none)
- kinds: manjū

## DISH Q11275595
- name: Hatto
- countries: JP
- kinds: dish, dumpling

## DISH Q11275835
- name: Harako meshi
- other names: {"zh": "鮭魚親子丼"}
- description: rice bowl with cooked salmon and salmon roe
- countries: JP
- kinds: Japanese rice dish, salmon dish
- ingredients: red caviar, chum salmon

## DISH Q11275959
- name: Bakudandon
- countries: JP
- kinds: donburi, Kaisen-don

## DISH Q11276058
- name: Panapanbin
- countries: (none)
- kinds: deep-fried confection

## DISH Q112760594
- name: Payasam
- description: sweet dish
- countries: IN
- kinds: food, pudding

## DISH Q112760696
- name: Semiya payasam
- description: sweet dish of Kerala
- countries: (none)
- kinds: sweet dish, payasam, seviyan

## DISH Q11276076
- name: Panjū
- countries: JP
- kinds: confectionery

## DISH Q112761223
- name: Chilly Gobi
- description: a cauliflower dish of India
- countries: IN
- kinds: dish
- ingredients: cauliflower

## DISH Q11276179
- name: Hikozen
- countries: (none)
- kinds: Japanese rice dish

## DISH Q11276230
- name: Hitan-sushi
- countries: (none)
- kinds: sushi

## DISH Q11276259
- name: 岩手水團
- countries: (none)
- kinds: shirumono

## DISH Q11276269
- name: Hitsumabushi
- other names: {"zh": "櫃塗飯"}
- description: local cuisine from the Nagoya region of Japan
- countries: JP
- cuisines: Japanese cuisine
- kinds: eating, Japanese rice dish, fish dish
- ingredients: unagi, cooked rice
- has Wikipedia article: en

## DISH Q11276281
- name: Hitokuchi gyoza
- description: bite-size gyoza
- countries: JP
- kinds: jiaozi

## DISH Q11276614
- name: Hyugameshi
- description: Japanese regional cuisine
- countries: JP
- kinds: seafood dish, rice dish

## DISH Q11276695
- name: Hiruzen yakisoba
- other names: {"zh": "蒜山炒麵"}
- countries: JP
- kinds: Yakisoba

## DISH Q11276778
- name: Quick bread
- other names: {"zh": "速發麵包"}
- description: bread leavened with leavening agents other than yeast or eggs
- countries: US
- kinds: bread
- ingredients: flour
- has Wikipedia article: en

## DISH Q11276996
- name: ふくめん
- other names: {"ja": "ふくめん"}
- countries: (none)
- kinds: aemono
- ingredients: Amorphophallus konjac

## DISH Q11277004
- name: Fukuregashi
- description: Japanese confection
- countries: (none)
- kinds: confectionery, steamed bread, type of food or dish
- has Wikipedia article: en

## DISH Q1127705
- name: Shrimp paste
- other names: {"zh": "虾酱"}
- description: fermented condiment
- countries: CN
- kinds: shrimp dish, fermented seafood, condiment
- ingredients: shrimp and prawn as food
- has Wikipedia article: en, zh

## DISH Q11277194
- name: Fuchagi
- other names: {"zh": "吹上饼"}
- countries: (none)
- kinds: mochi, azuki bean based food

## DISH Q11277200
- name: Futokoro mochi
- countries: (none)
- kinds: mochi, wagashi

## DISH Q11277208
- name: Funankogui
- countries: (none)
- kinds: nimono, fish dish
- ingredients: crucian carp as food, kombu

## DISH Q11277418
- name: Bukkake udon
- other names: {"zh": "濃湯烏龍麵"}
- description: Japanese dish
- countries: JP
- kinds: Japanese noodles, udon
- ingredients: udon
- has Wikipedia article: zh

## DISH Q11277440
- name: Budo
- countries: (none)
- kinds: agar, seafood dish
- ingredients: seaweed

## DISH Q11277477
- name: Buri daikon
- countries: (none)
- kinds: nimono, fish dish, vegetable dish
- ingredients: Japanese radish, Ara

## DISH Q11277538
- name: ぷよまん
- other names: {"ja": "ぷよまん"}
- countries: (none)
- kinds: manjū

## DISH Q11277612
- name: Herahera dango
- countries: JP
- kinds: dango

## DISH Q11277634
- name: Beko mochi
- other names: {"zh": "牛餅"}
- countries: (none)
- kinds: mochi, wagashi
- ingredients: rice flour

## DISH Q11277777
- name: Hotchare
- description: confectionery from Kitami, Hokkaido, Japan
- countries: JP
- kinds: confectionery

## DISH Q11277913
- name: Bōze no sugata-zushi
- countries: (none)
- kinds: sushi
- ingredients: Japanese butterfish

## DISH Q11278027
- name: Botan nabe
- other names: {"zh": "牡丹鍋"}
- description: stew made of boar meat
- countries: JP
- kinds: nabemono
- ingredients: wild boar meat

## DISH Q11278053
- name: Bonchi-age
- description: Japanese fried rice cracker
- countries: JP
- kinds: rice cracker

## DISH Q11278088
- name: Poppoyaki
- countries: (none)
- kinds: confectionery

## DISH Q11278109
- name: Pōpō
- other names: {"zh": "炮炮"}
- countries: (none)
- kinds: confectionery

## DISH Q11278209
- name: Makoron
- description: Japanese biscuit
- countries: JP
- kinds: biscuit
- ingredients: peanut, wheat flour, egg white, almond, sugar

## DISH Q11278216
- name: Magokoro jutsumi
- description: dish
- countries: (none)
- kinds: dish

## DISH Q11278496
- name: Momodooru
- description: Japanese confection
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q11278514
- name: Mamebu-jiru
- countries: JP
- kinds: dumpling, shirumono

## DISH Q11278555
- name: Marimo yokan
- description: green spherical yokan, made to look like balls of the alga marimo (Aegagropila linnaei)
- countries: (none)
- kinds: tama yokan

## DISH Q11278627
- name: Marunabe
- description: Japanese softshell turtle pot
- countries: JP
- kinds: turtle soup, nabemono
- ingredients: Chinese softshell turtle

## DISH Q11278637
- name: Arrope y calabazate
- other names: {"es": "arrope y calabazate"}
- countries: ES
- kinds: dessert

## DISH Q112787717
- name: Eka soup
- description: popular dish among the Idomas of Benue State
- countries: (none)
- kinds: soup, food
- ingredients: Bitter Leaf, Red Pepper, onion, crayfish, sesame seed candy, palm oil, peanut, table salt, water
- has Wikipedia article: en

## DISH Q11278790
- name: みかん鍋
- other names: {"ja": "みかん鍋"}
- countries: JP
- kinds: nabemono

## DISH Q11278864
- name: みすず飴
- other names: {"ja": "みすず飴"}
- countries: JP
- kinds: confectionery

## DISH Q11278936
- name: Misosukidon
- countries: (none)
- kinds: donburi
- ingredients: sukiyaki

## DISH Q11278944
- name: Mizore nabe
- countries: (none)
- kinds: nabemono
- ingredients: daikon oroshi

## DISH Q11278951
- name: Midarashi dango
- description: Dumplings eaten in the Hida region of Gifu Prefecture
- countries: (none)
- kinds: shōyu dango

## DISH Q11279243
- name: みみ
- other names: {"ja": "みみ"}
- description: Japanese dish
- countries: JP
- kinds: dish
- ingredients: wheat flour, miso, vegetable

## DISH Q11279318
- name: Myōga bochi
- countries: JP
- kinds: dango
- ingredients: broad bean, wheat flour, Zingiber mioga, Broad Bean

## DISH Q11279319
- name: Myōga manjū
- countries: (none)
- kinds: manjū

## DISH Q112797036
- name: Ika shūmai
- countries: (none)
- kinds: shumai, squid dish

## DISH Q11280033
- name: Motsu soba
- countries: (none)
- kinds: soba, offal dish

## DISH Q11280034
- name: Motsu curry
- description: variety of Japanese curry from Shizuoka, Japan
- countries: (none)
- kinds: Japanese curry

## DISH Q11280038
- name: Motsuni
- other names: {"zh": "內藏煮"}
- description: Japanese tripe stew
- countries: JP
- kinds: type of food or dish, stew, nimono, offal dish
- ingredients: tripe

## DISH Q11280099
- name: Momiji
- countries: (none)
- kinds: chicken dish, nimono
- ingredients: shōyu, mirin, chicken foot as food, sugar

## DISH Q11280104
- name: Momiji manjū
- other names: {"zh": "紅葉饅頭"}
- description: Japanese dessert
- countries: JP
- kinds: manjū, Miyagegashi
- has Wikipedia article: en, zh

## DISH Q11280200
- name: Morokoshi
- countries: (none)
- kinds: rakugan

## DISH Q11280203
- name: もろみ
- other names: {"ja": "もろみ"}
- countries: (none)
- kinds: digestate, fermented bean paste

## DISH Q11280254
- name: Yakiton
- other names: {"zh": "日式烤肉串"}
- description: pork dish
- countries: JP
- kinds: yakimono, pork dish

## DISH Q11280354
- name: やせうま
- other names: {"ja": "やせうま"}
- countries: (none)
- kinds: dango

## DISH Q11281047
- name: Shizuoka yokanpan
- countries: (none)
- kinds: pastry
- ingredients: Yōkan

## DISH Q11281050
- name: Hokkaido yokanpan
- description: pastry containing yokan from Hokkaido, Japan
- countries: (none)
- kinds: pastry
- ingredients: Yōkan

## DISH Q112812573
- name: Lyvzæ
- countries: (none)
- kinds: soup

## DISH Q11281424
- name: Ramen can
- countries: JP
- kinds: ramen, canned food
- ingredients: shirataki noodles

## DISH Q112818476
- name: Curry udon
- description: Japanese noodle dish
- countries: JP
- kinds: noodle dish, noodle soup, Japanese noodles
- ingredients: soba, udon, broth, noodle, curry

## DISH Q11281911
- name: わっぱ煮
- other names: {"ja": "わっぱ煮"}
- countries: JP
- kinds: shirumono

## DISH Q11282171
- name: アイスまんじゅう
- other names: {"ja": "アイスまんじゅう"}
- countries: (none)
- kinds: manjū, ice pop

## DISH Q11282175
- name: Aisukurin
- description: low-fat ice cream-like dessert
- countries: (none)
- kinds: frozen dessert

## DISH Q11284032
- name: Adobo
- other names: {"zh": "菲律賓阿多波"}
- description: Filipino dish composed of chicken/pork cooked in soy sauce and vinegar
- countries: PH
- cuisines: Filipino cuisine
- kinds: dish
- ingredients: bay leaf, soy sauce, pork, vinegar, meat
- has Wikipedia article: en, zh

## DISH Q112845073
- name: Сметанный соус
- other names: {"ru": "сметанный соус"}
- countries: RU
- cuisines: Russian cuisine
- kinds: sauce
- ingredients: smetana

## DISH Q112846722
- name: Houti
- other names: {"fr": "Houti"}
- countries: (none)
- kinds: beignet

## DISH Q112847602
- name: Dapa kossan
- other names: {"fr": "dapa kossan"}
- countries: GN
- kinds: dessert

## DISH Q11284874
- name: アマヅラ
- other names: {"ja": "アマヅラ"}
- countries: JP
- kinds: syrup

## DISH Q112850312
- name: Chauffeur fahai
- other names: {"fr": "chauffeur fahai"}
- countries: GN
- kinds: biscuit

## DISH Q112851922
- name: Yétissé bantoui
- other names: {"fr": "yétissé bantoui"}
- countries: GN
- kinds: sauce

## DISH Q11285229
- name: Silver dragée
- countries: (none)
- kinds: dragée

## DISH Q112860544
- name: Ashikaga shūmai
- countries: JP
- kinds: food, shumai
- ingredients: onion, potato starch

## DISH Q112860630
- name: Miyan taushe
- description: hausa soup
- countries: NG
- kinds: soup
- ingredients: Dawadawa, onion, crayfish, pumpkin, table salt, meat
- has Wikipedia article: en

## DISH Q112860677
- name: Dambun shinkafa
- description: Dambun shinkafa is a delicacy widely enjoyed in the north
- countries: NG
- kinds: food, dambu
- ingredients: onion, Capsicum, peanut, rice, broken rice
- has Wikipedia article: en

## DISH Q112862537
- name: Tamago yaki fry
- countries: (none)
- kinds: dish

## DISH Q11286341
- name: Ika sōmen
- other names: {"zh": "烏賊素麵"}
- description: squid sashimi in fine strips
- countries: JP
- kinds: sashimi, squid dish
- has Wikipedia article: en, zh

## DISH Q11286348
- name: Black pasta
- countries: IT
- kinds: pasta dish
- ingredients: spaghetti, cephalopod ink

## DISH Q11286367
- name: Ika tokkuri
- countries: (none)
- kinds: tokkuri, edible tableware, dried squid

## DISH Q11286685
- name: Italian
- countries: JP
- kinds: noodle dish

## DISH Q11286686
- name: イタリアンスパゲッティ
- other names: {"ja": "イタリアンスパゲッティ"}
- countries: (none)
- kinds: pasta dish
- ingredients: spaghetti

## DISH Q11286892
- name: Inamuduchi
- countries: (none)
- kinds: miso soup, pork dish

## DISH Q11287147
- name: Irabū-jiru
- other names: {"zh": "永良部湯"}
- countries: (none)
- kinds: soup
- ingredients: snake meat

## DISH Q11288287
- name: Fukagawa-meshi
- countries: JP
- kinds: dish, Japanese rice dish, clam dish

## DISH Q11288323
- name: Whiskey Bon Bon
- countries: (none)
- kinds: bonbon

## DISH Q11288609
- name: Soil porridge
- other names: {"zh": "土粥"}
- description: porridge made from soil, supposedly eaten in Japan during times of famine
- countries: JP
- kinds: porridge

## DISH Q11288757
- name: Hina-arare
- countries: (none)
- kinds: arare

## DISH Q11289041
- name: Uni no kaiyaki
- countries: JP
- kinds: seafood dish, clam dish
- ingredients: uni

## DISH Q11289046
- name: Unidon
- other names: {"zh": "海膽丼"}
- description: Sea urchin bowl
- countries: JP
- kinds: donburi, Kaisen-don
- ingredients: uni

## DISH Q11289355
- name: Uroko dango
- description: Japanese sweet dumpling
- countries: JP
- kinds: dessert, dango

## DISH Q11289615
- name: Stingray fin
- countries: (none)
- kinds: food product, dish
- ingredients: Batomorphi

## DISH Q11290005
- name: Escalope
- countries: (none)
- kinds: Japanese rice dish, pork dish
- ingredients: butter rice, tonkatsu, demi-glace

## DISH Q11290194
- name: エチオピア饅頭
- other names: {"ja": "エチオピア饅頭"}
- countries: JP
- kinds: manjū

## DISH Q112911886
- name: Ukwa
- description: Nigerian food
- countries: NG
- kinds: dish, human food
- ingredients: Bitter Leaf, potash, breadfruit, palm oil, Capsicum, table salt, fish
- has Wikipedia article: en

## DISH Q112911928
- name: Miyar zogale
- description: hausa soup
- countries: NG
- cuisines: Nigerian cuisine
- kinds: dish
- ingredients: Moringa leaf, palm oil, beef, peanut, tomato
- has Wikipedia article: en

## DISH Q11292372
- name: Okhotsk Hoshikaibashira Shio Ramen
- other names: {"zh": "鄂霍次克干貝柱鹽拉麵"}
- countries: (none)
- kinds: ramen in Hokkaido, shio ramen
- has Wikipedia article: zh

## DISH Q11292373
- name: オホーツク北見塩やきそば
- other names: {"ja": "オホーツク北見塩やきそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q11292509
- name: Chocolate-covered citrus peel
- description: confection of candied citrus peel coated in chocolate
- countries: FR
- kinds: candy, chocolate covered fruit
- ingredients: candied orange peel, chocolate

## DISH Q11293960
- name: Kakioko
- other names: {"zh": "牡蠣燒烤"}
- description: local version of okonomiyaki
- countries: JP
- kinds: pancake, oyster dish, okonomiyaki
- ingredients: oyster

## DISH Q11293966
- name: Kaki fry
- description: Japanese deep-fried oysters
- countries: JP
- cuisines: Japanese cuisine
- kinds: food, oyster dish, Crumbed deep-fry
- ingredients: panko, oyster, egg as food
- has Wikipedia article: en

## DISH Q11294248
- name: Kachūyū
- countries: JP
- kinds: soup
- ingredients: katsuobushi

## DISH Q112943464
- name: Tougui
- description: Palm nuts
- countries: GN
- kinds: walnut

## DISH Q112943741
- name: 鰻のせいろ蒸し
- other names: {"ja": "鰻のせいろ蒸し"}
- description: Japanese regional cuisine
- countries: JP
- kinds: seafood dish
- ingredients: cooked grain, usuyaki tamago, tare sauce, unagi

## DISH Q112943987
- name: Cortadillo
- description: typical sweet from the south of Spain
- countries: ES
- kinds: pastry

## DISH Q112944304
- name: Cortadillo norteño
- description: Northern Mexican stew
- countries: MX
- kinds: stew

## DISH Q112944430
- name: Cortadillo
- description: Mexican sweet bread
- countries: MX
- kinds: pastry

## DISH Q11294479
- name: Tomalley
- description: lobster or crab digestive organs, eaten as a delicacy in Eastern Asia
- countries: JP, KR, VN
- kinds: dish
- ingredients: hepatopancreas
- has Wikipedia article: en

## DISH Q11294485
- name: Kani-jiru
- description: traditional Japanese crab soup
- countries: JP
- kinds: dish, miso soup, crab dish

## DISH Q112945424
- name: Wheat and ewedu soup
- description: Food
- countries: NG
- kinds: food

## DISH Q11295283
- name: Curry ramen
- other names: {"zh": "咖喱拉麵"}
- countries: (none)
- kinds: ramen
- ingredients: Japanese curry

## DISH Q11295284
- name: Karēdon
- other names: {"zh": "咖喱丼"}
- description: donburi with Japanese curry (karē)
- countries: (none)
- kinds: dish, donburi, Japanese curry rice
- ingredients: Japanese curry, rice

## DISH Q11295288
- name: Curry nabe
- other names: {"zh": "咖喱鍋"}
- description: Japanese dish
- countries: (none)
- kinds: Japanese curry, nabemono

## DISH Q11295436
- name: Ganjang-gejang
- countries: (none)
- kinds: gejang

## DISH Q11295711
- name: カープソース
- other names: {"ja": "カープソース"}
- countries: (none)
- kinds: Worcestershire sauce

## DISH Q11295996
- name: Gatatan
- other names: {"zh": "含多汤"}
- countries: (none)
- kinds: soup
- has Wikipedia article: zh

## DISH Q11296678
- name: キスミントガム
- other names: {"ja": "キスミントガム"}
- countries: (none)
- kinds: chewing gum

## DISH Q112967822
- name: Pawpaw soup
- description: popular delicacy of one of the Tiv ethnic group of Nigeria
- countries: NG
- kinds: soup, meat soup
- ingredients: papaya, Citrullus colocynthis, palm oil, Capsicum, beef, Ceratonia siliqua
- has Wikipedia article: en

## DISH Q11297228
- name: Kyabetsuyaki
- other names: {"zh": "烤高麗菜"}
- countries: JP
- kinds: teppanyaki, cabbage dish

## DISH Q112977273
- name: Meat peppersoup
- description: Food
- countries: NG
- kinds: food

## DISH Q112977543
- name: Rice and stew with cowskin
- description: Food
- countries: NG
- kinds: food, beef

## DISH Q112977605
- name: Spaghetti and chicken
- description: pasta and chicken dish
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food, spaghetti

## DISH Q11298649
- name: クジラかやき
- other names: {"ja": "クジラかやき"}
- countries: JP
- kinds: nabemono

## DISH Q112992946
- name: Buttamagedon
- countries: JP
- kinds: donburi
- ingredients: chicken egg, soft-boiled egg, yuzu, pork, rice

## DISH Q11299457
- name: Cream pan
- countries: (none)
- kinds: cream roll
- ingredients: pastry cream

## DISH Q11299458
- name: Cream Box
- description: a Japanese sweet from Fukushima
- countries: JP
- kinds: sweet bread
- has Wikipedia article: en

## DISH Q11300179
- name: グラタンフライ
- other names: {"ja": "グラタンフライ"}
- countries: JP
- kinds: Agemono

## DISH Q113002820
- name: Edo black soup
- description: popular and tasteful (Edo) Esan soup
- countries: NG
- cuisines: Nigerian cuisine
- kinds: dish, food
- ingredients: Bitter Leaf, Palm fruit juice, palm oil, Capsicum, beef, table salt, fish
- has Wikipedia article: en

## DISH Q113002838
- name: Ofe Achara
- description: igbo soup
- countries: NG
- kinds: soup
- ingredients: egusi, onion, crayfish, palm oil, Capsicum, beef, smoked fish, water
- has Wikipedia article: en

## DISH Q113003157
- name: Deep fried egg
- description: deep fried egg dish
- countries: (none)
- kinds: deep-fried food, egg dish
- has Wikipedia article: en

## DISH Q11300957
- name: Guten burger
- countries: (none)
- kinds: hamburger

## DISH Q11301550
- name: Gesodon
- countries: JP
- kinds: donburi, squid dish

## DISH Q113016118
- name: Baga tami
- description: pain
- countries: GN
- kinds: bread

## DISH Q11302150
- name: Cosmopolitan Confectionery
- countries: (none)
- kinds: confectionery

## DISH Q11302268
- name: コトレータ
- other names: {"ja": "コトレータ"}
- countries: (none)
- kinds: cutlet

## DISH Q113022782
- name: Plantain mosa
- description: Nigerian snack
- countries: NG
- kinds: snack
- ingredients: warm water, vegetable oil, baker's yeast, habanero, cooking banana, flour, table salt
- has Wikipedia article: en

## DISH Q113023113
- name: Gurasa
- description: hausa food
- countries: NG
- kinds: food, bread
- ingredients: baker's yeast, egg as food, flour, baking powder, bread
- has Wikipedia article: en

## DISH Q113028406
- name: Fried meat
- description: meat dish
- countries: (none)
- kinds: meat dish, fried food

## DISH Q11303596
- name: Gokko jiru
- description: Japanese fish soup
- countries: JP
- kinds: nabemono
- ingredients: Aptocyclus ventricosus

## DISH Q11303652
- name: ゴム容器アイス
- other names: {"ja": "ゴム容器アイス"}
- countries: (none)
- kinds: ice cream

## DISH Q11303852
- name: Neapolitan wafer
- description: thin Japanese waffle stuffed with cream
- countries: JP
- kinds: waffle

## DISH Q113038927
- name: Fio Fio
- description: spicy pigeon pea porridge, peculiar to the people of Enugu state, Nigeria
- countries: (none)
- kinds: food, dish
- ingredients: pigeon pea, Onions, cocoyam, palm oil, Capsicum, salt
- has Wikipedia article: en

## DISH Q113038928
- name: Egbo
- description: meal ground from dried corn
- countries: NG
- kinds: dish, Ebo
- ingredients: Capsicum, maize, onion
- has Wikipedia article: en

## DISH Q113039011
- name: Aadun
- description: Nigerian snack
- countries: NG
- kinds: food, snack
- ingredients: maize flour, palm oil, chili pepper, table salt
- has Wikipedia article: en

## DISH Q113039087
- name: Afia Efere
- description: Nigerian soup popular amongst the Efik/Ibibio tribe
- countries: NG
- kinds: human food, soup
- ingredients: Peppered Ponmo, yam, crayfish, seasoning, goat meat, stockfish, table salt, water
- has Wikipedia article: en

## DISH Q11304972
- name: サバップル
- other names: {"ja": "サバップル"}
- countries: (none)
- kinds: pie

## DISH Q11305289
- name: Salad Pan
- countries: (none)
- kinds: chōripan
- ingredients: hot dog bun, takuan, mayonnaise

## DISH Q11305999
- name: Sanma-men
- other names: {"zh": "生碼麺"}
- countries: (none)
- kinds: ramen

## DISH Q11306381
- name: ザッパ汁
- other names: {"ja": "ザッパ汁"}
- countries: (none)
- kinds: nabemono

## DISH Q113070410
- name: Ofe Ujuju
- description: igbo soup
- countries: (none)
- kinds: soup, stew
- ingredients: black pepper, Myrianthus arboreus, table salt, meat, fish
- has Wikipedia article: en

## DISH Q113070433
- name: Kekefia
- description: side dish of Bayelsa people in Nigeria
- countries: NG
- kinds: food, dish
- ingredients: onion, crayfish, palm oil, Capsicum, cooking banana, table salt
- has Wikipedia article: en

## DISH Q113070599
- name: Yam pepper soup
- description: Nigerian soup
- countries: (none)
- kinds: dish, soup
- ingredients: chili pepper, Dioscorea, table salt, meat
- has Wikipedia article: en

## DISH Q11307140
- name: Sicilian rice
- countries: (none)
- kinds: Japanese rice dish

## DISH Q11307369
- name: Cinnamon Toast
- countries: (none)
- kinds: toast
- has Wikipedia article: en

## DISH Q11307512
- name: Siberia
- other names: {"zh": "西伯利亞蛋糕"}
- description: Japanese pastry made from castelle and yōkan
- countries: JP
- kinds: confectionery
- ingredients: red bean paste, Yōkan, castella
- has Wikipedia article: en, zh

## DISH Q11307780
- name: Chaliapin steak
- other names: {"zh": "夏里亚宾牛排"}
- description: Japanese beef dish
- countries: JP
- kinds: beef dish
- has Wikipedia article: zh

## DISH Q11310088
- name: Jampan
- description: Japanese jam-filled pastry
- countries: (none)
- kinds: sweet bread
- ingredients: jam

## DISH Q11310465
- name: Jun Dog
- countries: (none)
- kinds: onigiri

## DISH Q11310970
- name: Jingisukan Caramel
- countries: (none)
- kinds: type of food or dish, caramel, confectionery
- ingredients: sweetened condensed milk, vegetable oil, flavoring, mizuame, wheat flour, D-sorbitol, lecithin, caramel, table salt, sugar

## DISH Q11311060
- name: Peanut tofu
- other names: {"zh": "花生豆腐"}
- countries: JP
- cuisines: Okinawan cuisine
- kinds: pudding, tofu
- ingredients: peanut
- has Wikipedia article: zh

## DISH Q113114616
- name: Snail pepper soup
- description: Nigerian soup
- countries: (none)
- kinds: food, dish, soup
- ingredients: snail, Capsicum, table salt
- has Wikipedia article: en

## DISH Q113114745
- name: Potato fufu
- description: potato-based staple food from Nigeria
- countries: NG
- kinds: human food, solid food
- ingredients: Flour, hot water, potato
- has Wikipedia article: en

## DISH Q11311915
- name: Stamina rice
- countries: (none)
- kinds: Japanese rice dish
- ingredients: yasai itame, tonkatsu, fried egg, rice

## DISH Q11311917
- name: Stamina ramen
- countries: (none)
- kinds: ramen

## DISH Q113119515
- name: Chikuwa salad
- countries: (none)
- kinds: dish
- ingredients: Chikuwa, potato salad

## DISH Q11312555
- name: Candy bar
- other names: {"zh": "糖果棒"}
- description: type of sugar confectionery that is in the shape of a bar
- countries: (none)
- kinds: sugar candy, snack bar
- has Wikipedia article: en, zh

## DISH Q113128973
- name: Torta de leche
- description: Spanish sweet
- countries: ES
- kinds: dessert

## DISH Q113131032
- name: Yamin
- description: noodle dish from West Java
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, noodle, chicken soup

## DISH Q11313337
- name: スヤキ
- other names: {"ja": "スヤキ"}
- countries: (none)
- kinds: Yakisoba

## DISH Q11314002
- name: Soup curry
- other names: {"zh": "湯咖哩"}
- description: a local dish originating from Sapporo, Hokkaido, Japan
- countries: (none)
- kinds: soup, Japanese curry
- has Wikipedia article: zh

## DISH Q11314011
- name: スープ入り焼きそば
- other names: {"ja": "スープ入り焼きそば"}
- countries: (none)
- kinds: Yakisoba, noodle soup

## DISH Q11314983
- name: Zerī furai
- countries: (none)
- kinds: korokke
- ingredients: potato, soy pulp

## DISH Q11315275
- name: ソフトスパゲッティ式めん
- other names: {"ja": "ソフトスパゲッティ式めん"}
- countries: JP
- kinds: Japanese noodles

## DISH Q113159014
- name: Mondulkiri wild honey
- description: Cambodian honey
- countries: KH
- kinds: honey
- has Wikipedia article: en

## DISH Q11316417
- name: Tart
- other names: {"zh": "塔魯特"}
- countries: (none)
- kinds: Swiss roll

## DISH Q11316510
- name: Tannafakurū
- countries: JP
- kinds: cookie, honeycomb toffee
- ingredients: non-centrifugal cane sugar, sodium bicarbonate

## DISH Q11316528
- name: Tanmen
- countries: JP
- kinds: dish, noodle dish

## DISH Q11317904
- name: Chicken nanban
- other names: {"zh": "鸡肉南蛮"}
- description: Chicken dish originated in Miyazaki Prefecture, Japan
- countries: JP
- kinds: Agemono, chicken dish, fried chicken
- has Wikipedia article: zh

## DISH Q11318281
- name: Char siu onigiri
- description: type of onigiri
- countries: JP
- kinds: onigiri
- ingredients: chāshū

## DISH Q1131837
- name: Ndolé
- description: national dish of Cameroon
- countries: CM
- kinds: stew, dish
- ingredients: nut
- has Wikipedia article: en

## DISH Q11318420
- name: Chocolate covered ants
- countries: (none)
- kinds: chocolate

## DISH Q11318559
- name: チンコロ
- other names: {"ja": "チンコロ"}
- countries: (none)
- kinds: confectionery

## DISH Q11318588
- name: チーズ饅頭
- other names: {"ja": "チーズ饅頭"}
- countries: JP
- kinds: confectionery

## DISH Q11318769
- name: Tuna mayonnaise
- description: Japanese dish of canned tuna and mayonnaise, used as a sandwich or onigiri filling or sushi topping
- countries: JP
- cuisines: Japanese cuisine
- kinds: tuna dish
- ingredients: canned tuna, mayonnaise

## DISH Q11318890
- name: Zuke
- countries: (none)
- kinds: food preparation technique, fish dish

## DISH Q113203875
- name: Pav gathiya
- countries: IN
- kinds: dish

## DISH Q11321401
- name: トマト鍋
- other names: {"ja": "トマト鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q11322056
- name: Japanese Turkish ice cream
- countries: JP
- kinds: ice cream

## DISH Q11322243
- name: Tonkatsu ramen
- other names: {"zh": "豬排拉麵"}
- countries: (none)
- kinds: ramen in Okayama Prefecture
- ingredients: tonkatsu

## DISH Q113227405
- name: Lüadèl
- other names: {"it": "Lüadèl"}
- countries: (none)
- kinds: dish
- ingredients: farina, table salt

## DISH Q11322794
- name: Demi-glace sauce katsudon
- countries: (none)
- kinds: katsudon, pork dish
- ingredients: tonkatsu

## DISH Q11323173
- name: Doria
- other names: {"zh": "焗饭"}
- description: Japanese type of gratin
- countries: JP
- cuisines: yōshoku
- kinds: dish, gratin
- ingredients: béchamel, cheese, rice, pilaf
- has Wikipedia article: en, zh

## DISH Q11324298
- name: Nikon yokan
- countries: (none)
- kinds: Yōkan

## DISH Q11324336
- name: Nishijiru
- description: Cold miso soup with the venom of sea snail for spice
- countries: JP
- kinds: miso soup
- ingredients: Thais clavigera

## DISH Q113249231
- name: Sauce chateaubriand
- countries: (none)
- kinds: dish

## DISH Q11326372
- name: Hatahatazushi
- description: sushi made from hatahata (Arctoscopus japonicus)
- countries: (none)
- kinds: i-zushi
- ingredients: Arctoscopus japonicus

## DISH Q11326596
- name: Honey toast
- description: Japanese dessert
- countries: JP
- kinds: dessert, toast
- ingredients: pain de mie, ice cream, honey, pan loaf, cream
- has Wikipedia article: en

## DISH Q1132679
- name: Tenshindon
- other names: {"zh": "天津饭"}
- description: Chinese-Japanese specialty
- countries: JP
- kinds: omelette, dish, donburi
- ingredients: crab meat, egg as food, rice
- has Wikipedia article: en, zh

## DISH Q11327115
- name: Hanton rice
- countries: (none)
- cuisines: yōshoku
- kinds: Japanese rice dish

## DISH Q11327141
- name: Hanbāgu karē
- other names: {"zh": "漢堡咖喱飯"}
- countries: (none)
- kinds: Japanese curry rice
- ingredients: hanbāgu, Japanese curry

## DISH Q11327589
- name: Bakudan onigiri
- countries: JP
- kinds: onigiri

## DISH Q113276855
- name: Ensaymada
- description: Philippine sweet bread
- countries: PH
- kinds: sweet bread

## DISH Q11327742
- name: Butter gohan
- countries: (none)
- kinds: gohan
- ingredients: cooked rice, soy sauce, butter

## DISH Q11327743
- name: Butter rice
- countries: (none)
- kinds: rice dish
- ingredients: butter, rice

## DISH Q11327745
- name: Butter mochi
- description: Hawaiian confection made from glutinous rice flour and butter
- countries: US
- cuisines: Hawaiian cuisine
- kinds: mochi, butter cake
- ingredients: rice flour, coconut milk, egg as food, butter, sugar, milk, glutinous rice flour
- has Wikipedia article: en

## DISH Q113279398
- name: Spanish bread
- description: a sweet bread from the Philippines
- countries: PH
- kinds: food, bread
- has Wikipedia article: en

## DISH Q11327942
- name: Banana castella
- countries: (none)
- kinds: castella, banana dish

## DISH Q11327953
- name: Banana monaka
- countries: (none)
- kinds: monaka

## DISH Q11327988
- name: Babahera
- other names: {"zh": "婆婆冰"}
- countries: (none)
- kinds: frozen dessert
- has Wikipedia article: zh

## DISH Q11328092
- name: 十和田炒牛五花
- countries: (none)
- kinds: meat dish

## DISH Q113291374
- name: Babelutte
- description: sweets made from candy syrup and butter
- countries: BE
- kinds: confectionery, toffee
- ingredients: syrup, butter
- has Wikipedia article: en

## DISH Q113292533
- name: Fafernuchy
- other names: {"pl": "fafernuchy"}
- countries: (none)
- kinds: pastry
- ingredients: rye flour, wheat flour, Piper, table salt, honey, carrot

## DISH Q113292966
- name: Suksessterte
- other names: {"nb": "suksessterte"}
- countries: (none)
- kinds: cake
- ingredients: almond

## DISH Q113298162
- name: Tagalia
- description: A sauce served in Chad and Sudan.
- countries: SD, TD
- kinds: sauce
- ingredients: Abelmoschus esculentus
- has Wikipedia article: en

## DISH Q113302651
- name: Cheese omelet
- countries: (none)
- kinds: dish, omelette
- ingredients: egg as food, cheese

## DISH Q113303417
- name: Στάκα
- other names: {"el": "στάκα"}
- countries: GR
- kinds: dairy product

## DISH Q1133123
- name: Buddha Jumps Over the Wall
- other names: {"zh": "佛跳墙"}
- description: Fujian soup of many expensive ingredients, e.g. shark fin, bamboo shoots, scallops, sea cucumber, abalone, fish maw, Jinhua ham, pork tendon, ginseng, mushrooms
- countries: (none)
- kinds: Shark Fin Soup, soup, Fujian cuisine
- ingredients: Four sea delicacies, shark fin
- has Wikipedia article: en, zh

## DISH Q1133127
- name: Corn dog
- other names: {"zh": "玉米狗"}
- description: deep-fried, corn-battered hot dog on a stick
- countries: US
- kinds: dish, sandwich
- ingredients: Vienna sausage, hot dog
- has Wikipedia article: en, zh

## DISH Q11331461
- name: Pizza toast
- countries: JP
- kinds: dish, bread

## DISH Q11331741
- name: ピーセン
- other names: {"ja": "ピーセン"}
- countries: (none)
- kinds: Beika

## DISH Q1133209
- name: Corned beef
- other names: {"zh": "粗盐腌牛肉"}
- description: salt-cured beef product
- countries: IE
- kinds: food, beef, preserved food
- ingredients: beef
- has Wikipedia article: en, zh

## DISH Q11332167
- name: ファルマン (菓子)
- other names: {"ja": "ファルマン (菓子)"}
- countries: (none)
- kinds: confectionery

## DISH Q11332417
- name: Fish katsu
- description: Fried fishcake from Tokushima prefecture, Japan
- countries: JP
- kinds: gyokatsu

## DISH Q11333432
- name: Furai
- countries: (none)
- kinds: teppanyaki

## DISH Q113334375
- name: Rosquillas de Alhama
- countries: (none)
- kinds: rosquilla

## DISH Q11333438
- name: Fried cake
- countries: (none)
- kinds: manjū, An-doughnut, Crumbed deep-fry

## DISH Q113336629
- name: Libreta bread
- description: Spanish type of bread
- countries: ES
- kinds: bread

## DISH Q113348972
- name: Perenstroop
- description: pear syrup
- countries: (none)
- kinds: spread, syrup
- ingredients: pear, sugar

## DISH Q11335663
- name: Pudding à la mode
- description: crème caramel
- countries: (none)
- kinds: crème caramel

## DISH Q11335862
- name: 壓制火腿
- countries: (none)
- kinds: pork dish

## DISH Q113360141
- name: Yako tourébéli
- other names: {"fr": "Yako tourébéli"}
- countries: GN
- kinds: food

## DISH Q113360483
- name: Tounhori
- other names: {"fr": "Tounhori"}
- countries: GN
- kinds: food

## DISH Q113360494
- name: Koussou hori
- other names: {"fr": "Koussou hori"}
- countries: GN
- kinds: food

## DISH Q113365858
- name: Louhouré noun coco
- description: dessert from Guinea
- countries: GN
- kinds: dessert

## DISH Q113365898
- name: Forè
- other names: {"fr": "Forè"}
- countries: GN
- kinds: fruit

## DISH Q113368015
- name: Tian
- description: food
- countries: (none)
- kinds: dish
- ingredients: vegetable

## DISH Q113369626
- name: Halawat Nahar Khuz
- description: Iraqi confectionery
- countries: IQ
- kinds: dessert

## DISH Q11336977
- name: Viet Cong Ramen
- countries: (none)
- kinds: ramen

## DISH Q11337025
- name: Baby castella
- other names: {"zh": "迷你長崎蛋糕"}
- countries: (none)
- kinds: castella, street food

## DISH Q11337373
- name: Pescatora sauce
- countries: (none)
- kinds: tomato sauce

## DISH Q1133745
- name: Tonjiru
- other names: {"zh": "豚汁"}
- description: Japanese soup
- countries: JP
- kinds: food, soup
- ingredients: pork
- has Wikipedia article: en, zh

## DISH Q11337766
- name: Toasted sandwich
- countries: (none)
- kinds: sandwich

## DISH Q113379133
- name: Bartolo
- description: pastry from Asturias, Spain
- countries: ES
- kinds: pastry

## DISH Q11338074
- name: Hormone yaki udon
- countries: JP
- kinds: horumonyaki, noodle dish, yaki udon
- ingredients: udon, offal

## DISH Q11338075
- name: Horumon yakisoba
- countries: (none)
- kinds: Yakisoba, horumonyaki

## DISH Q11338102
- name: 白咖哩 (北海道)
- countries: (none)
- kinds: Japanese curry
- has Wikipedia article: zh

## DISH Q11338139
- name: White Christmas
- description: Australian dessert
- countries: AU
- kinds: sweet dish, food
- ingredients: raisin
- has Wikipedia article: en

## DISH Q113381739
- name: Spaghetti tunisien
- other names: {"fr": "spaghetti tunisien"}
- countries: (none)
- kinds: recipe, spaghetti
- ingredients: garlic, tomato paste, olive oil, spaghetti

## DISH Q11338428
- name: ホームランバー
- other names: {"ja": "ホームランバー"}
- countries: JP
- kinds: ice cream

## DISH Q11338601
- name: Bograč
- description: Slovenian meat stew
- countries: SI
- kinds: food, stew

## DISH Q11338778
- name: Volga rice
- description: Japanese fried rice dish
- countries: (none)
- cuisines: yōshoku
- kinds: Japanese rice dish
- ingredients: breaded cutlet, omurice
- has Wikipedia article: en

## DISH Q11338875
- name: ボンボン・ショコラ
- other names: {"ja": "ボンボン・ショコラ"}
- countries: (none)
- kinds: chocolate

## DISH Q113389032
- name: Coco gâteau
- other names: {"fr": "Coco gâteau"}
- countries: GN
- kinds: beignet
- ingredients: Cocos

## DISH Q113389041
- name: Bakers' confection
- description: food prepared by bakers
- countries: (none)
- kinds: confectionery

## DISH Q113389225
- name: Sweet pastry
- countries: (none)
- kinds: pastry, sweet dish

## DISH Q113389255
- name: Diguiyangni
- countries: GN
- kinds: biscuit

## DISH Q113389319
- name: Gâteau coco
- other names: {"fr": "Gâteau coco"}
- countries: GN
- kinds: cake
- ingredients: Cocos

## DISH Q113389445
- name: Bourohai fihai
- other names: {"fr": "Bourohai fihai"}
- countries: GN
- kinds: sauce

## DISH Q113389900
- name: Cocos gâteaux
- other names: {"fr": "Cocos gâteaux"}
- countries: GN
- kinds: cake
- ingredients: Cocos

## DISH Q113390839
- name: Yoka cake
- countries: GN
- kinds: cake
- ingredients: cassava

## DISH Q11339222
- name: Potato yakisoba
- countries: (none)
- kinds: yakisoba with potato

## DISH Q113393434
- name: Chiratta puttu
- description: rice dish from Kerala
- countries: (none)
- kinds: dish

## DISH Q11339419
- name: Ponpon-yaki
- other names: {"zh": "烤烏賊"}
- description: squid dish from Hachinohe, Aomori Prefecture, Japan
- countries: (none)
- kinds: dish
- ingredients: squid as food

## DISH Q11339427
- name: Sauteed pork
- countries: (none)
- kinds: meat dish

## DISH Q1133945
- name: Funazushi
- other names: {"zh": "鮒壽司"}
- description: dish of fermented stuffed crucian carp
- countries: JP
- kinds: narezushi
- ingredients: Carassius auratus grandoculis, Crucian carp
- has Wikipedia article: en, zh

## DISH Q113403844
- name: Chocolate lobster
- description: Spanish dish
- countries: ES
- kinds: dish

## DISH Q11340898
- name: マミーすいとん
- other names: {"ja": "マミーすいとん"}
- countries: (none)
- kinds: suiton

## DISH Q113409204
- name: Abxazuri
- other names: {"az": "Abxazuri"}
- countries: GE
- kinds: meat dish

## DISH Q11340923
- name: Mayā no ushiru
- countries: (none)
- kinds: soup, meat dish, medicinal food
- ingredients: cat meat

## DISH Q113410072
- name: Чапильг
- other names: {"ru": "Чапильг"}
- countries: RU
- kinds: dish

## DISH Q113410153
- name: Даттараш
- other names: {"ru": "Даттараш"}
- countries: RU
- kinds: dish

## DISH Q113411438
- name: Kaluzhskoe testo
- description: kind of confection in Russia, named after Kaluga city
- countries: (none)
- kinds: food, confectionery
- ingredients: flour, honey

## DISH Q113411676
- name: Жалбаур
- other names: {"ru": "Жалбаур"}
- countries: (none)
- kinds: dish

## DISH Q113412039
- name: Snail liver
- description: dish
- countries: (none)
- kinds: dish, liver

## DISH Q11341815
- name: 麻婆咖喱
- countries: JP
- kinds: Japanese curry

## DISH Q11342511
- name: Mimigā
- countries: (none)
- kinds: pig's ear

## DISH Q11342916
- name: 黃金牛奶
- countries: JP
- kinds: crème caramel

## DISH Q11342927
- name: ミルクケーキ
- other names: {"ja": "ミルクケーキ"}
- countries: (none)
- kinds: dairy product, confectionery

## DISH Q11342935
- name: ミルクヨーカン
- other names: {"ja": "ミルクヨーカン"}
- countries: (none)
- kinds: Western confection

## DISH Q11342949
- name: ミルフィーユカツ
- other names: {"ja": "ミルフィーユカツ"}
- countries: (none)
- kinds: tonkatsu

## DISH Q11342962
- name: Mille crêpe
- other names: {"zh": "日式千層蛋糕"}
- description: stacking of several crepes with cream or fruit in between
- countries: JP
- kinds: cake
- ingredients: crêpe

## DISH Q11342980
- name: Mire biscuit
- countries: JP
- kinds: confectionery, Western confection

## DISH Q11343150
- name: Mehallabiyya
- other names: {"zh": "Muhallebi"}
- description: Levantine dessert, milk pudding
- countries: IR
- kinds: dish, budino
- ingredients: rice flour, semolina, starch, sugar, milk
- has Wikipedia article: en, zh
