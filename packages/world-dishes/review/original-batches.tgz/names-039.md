# Review batch names-039

## DISH Q31836003
- name: Würzfleisch
- description: German dish
- countries: DE
- kinds: dish

## DISH Q31837365
- name: Buttered eggs
- description: Irish food and egg preservation method
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q31838053
- name: Düsseldorfer Senfrostbraten
- description: Food speciality from Düsseldorfer, Germany, made with a gratinated mustard crust
- countries: (none)
- kinds: dish

## DISH Q31839671
- name: Morosche Karottensuppe
- other names: {"de": "Morosche Karottensuppe"}
- countries: (none)
- kinds: dish, carrot soup

## DISH Q31840656
- name: Topfwurst
- other names: {"de": "Topfwurst"}
- countries: (none)
- kinds: dish

## DISH Q31843329
- name: Potato croquette
- countries: (none)
- kinds: food, potato dish

## DISH Q31883707
- name: Dishes of Chile
- countries: (none)
- kinds: dish

## DISH Q31884780
- name: Dallas salad
- countries: (none)
- kinds: salad

## DISH Q31886692
- name: La kama
- other names: {"sv": "La kama"}
- countries: DZ
- kinds: spice mix

## DISH Q31888072
- name: Arrakskrans
- other names: {"sv": "arrakskrans"}
- countries: (none)
- kinds: cake

## DISH Q31888154
- name: Gáhkku
- countries: (none)
- cuisines: Sami cuisine
- kinds: bread

## DISH Q31892497
- name: Stomp
- other names: {"sv": "Stomp"}
- countries: (none)
- kinds: bread

## DISH Q31896543
- name: Matpaket
- other names: {"sv": "Matpaket"}
- countries: (none)
- kinds: dish

## DISH Q31898202
- name: Sill och potatis
- other names: {"sv": "Sill och potatis"}
- countries: (none)
- kinds: dish

## DISH Q3191108
- name: Jésuite
- description: French pastry
- countries: FR
- cuisines: Argentine cuisine
- kinds: pastry
- ingredients: frangipane, almond, powdered sugar, puff pastry
- has Wikipedia article: en

## DISH Q3191139
- name: Jókai Bean Soup
- description: Hungarian bean soup
- countries: HU
- cuisines: Hungarian cuisine
- kinds: food, soup
- has Wikipedia article: en

## DISH Q3191665
- name: Baby carrot
- other names: {"zh": "迷你胡蘿蔔"}
- description: carrot sold at a smaller size before reaching maturity
- countries: (none)
- kinds: carrot, snack, food product
- ingredients: carrot
- has Wikipedia article: en, zh

## DISH Q3192044
- name: Kakiage
- other names: {"zh": "炸什錦丼"}
- description: Japanese dish of battered and deep-fried shrimp or other ingredients
- countries: JP
- kinds: tempura
- has Wikipedia article: en

## DISH Q3192094
- name: Kalamai
- description: a traditional Chamorro corn / coconut pudding
- countries: GU
- kinds: pudding
- ingredients: masa, coconut milk, sugar, water
- has Wikipedia article: en

## DISH Q3192476
- name: Kamounia
- description: beef and liver stew prepared with cumin
- countries: (none)
- kinds: lamb dish, beef dish
- has Wikipedia article: en

## DISH Q31930768
- name: Easter candy
- description: candy especially made for Easter
- countries: (none)
- kinds: Easter traditions, candy

## DISH Q319435
- name: Linsen mit Spätzle
- description: Swabian dish of egg noodles, lentils, and wiener sausages
- countries: DE
- kinds: noodle dish
- ingredients: lentil, Vienna sausage, spätzle
- has Wikipedia article: en

## DISH Q3194656
- name: Kefteji
- description: Tunisian dish
- countries: TN
- kinds: dish
- ingredients: potato

## DISH Q3195568
- name: Kesra
- description: flat bread from Algeria
- countries: DZ
- kinds: flatbread, food
- ingredients: semolina, butter, table salt
- has Wikipedia article: en

## DISH Q3196097
- name: Khashlama
- description: Armenian and Georgian meat dish
- countries: AM, GE
- kinds: meat dish
- has Wikipedia article: en

## DISH Q3196927
- name: Kimchi-don
- description: donburi made with kimchi
- countries: JP
- kinds: dish, donburi
- ingredients: Kimchi, rice

## DISH Q3197476
- name: Kisra
- description: type of bread
- countries: DZ, KE, SD, SS, TD, UG
- kinds: recipe, flatbread
- ingredients: Sorghum
- has Wikipedia article: en

## DISH Q3198369
- name: Koki
- description: Cameroonian dish
- countries: CM
- kinds: dish, food
- has Wikipedia article: en

## DISH Q3200265
- name: Patty
- other names: {"zh": "汉堡排"}
- description: serving of chopped ingredients formed into a disc
- countries: (none)
- kinds: fast food, meat dish, meat product
- ingredients: meat alternative, meat
- has Wikipedia article: en

## DISH Q3201055
- name: Kaak warka
- description: Tunisian pastry
- countries: TN
- kinds: pastry, Ka'ak
- ingredients: almond, powdered sugar, flour, butter

## DISH Q3202304
- name: Nemmuş
- other names: {"nl": "Nemmuş"}
- countries: TR
- kinds: dish

## DISH Q320657
- name: Swiss roll
- other names: {"zh": "卷蛋糕"}
- description: dessert
- countries: (none)
- kinds: sponge cake, roll
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q321356
- name: Ričet
- description: stew from Bavaria, Austria and Slovenia
- countries: SI
- kinds: food, soup
- ingredients: barley, leek, Vigna angularis, Laurus nobilis, Allium sativum
- has Wikipedia article: en

## DISH Q32153719
- name: Phoenix egg rolls
- other names: {"zh": "鳳凰卷"}
- countries: (none)
- cuisines: Macau's cuisine
- kinds: biscuit roll

## DISH Q32164159
- name: Shan tounsi
- description: Tunisian food made with eggs, known for its ease of preparation
- countries: TN
- kinds: dish

## DISH Q3216490
- name: لكلوكة
- other names: {"ar": "لكلوكة"}
- countries: TN
- kinds: pastry
- ingredients: Sesamum indicum, olive oil, raisin, sugar

## DISH Q3217743
- name: 列日烩兔
- countries: BE
- kinds: main course, stew
- ingredients: plum, rabbit

## DISH Q3217888
- name: Lardon
- other names: {"zh": "培根丁"}
- description: small cube of pork fat
- countries: (none)
- kinds: food, fatback, fatty pork
- ingredients: pork
- has Wikipedia article: en

## DISH Q321797
- name: Zefir
- description: type of soft confectionery
- countries: RU
- kinds: confectionery
- ingredients: egg white
- has Wikipedia article: en

## DISH Q3220237
- name: Kuivaliha
- description: salted and dried meat
- countries: FI
- cuisines: Finnish cuisine
- kinds: meat dish, reindeer meat
- has Wikipedia article: en

## DISH Q3220669
- name: Le Burgou
- other names: {"fr": "Le Burgou"}
- countries: (none)
- kinds: cake

## DISH Q3221428
- name: Käsebrot
- other names: {"de": "Käsebrot"}
- countries: (none)
- ingredients: cheese, bread

## DISH Q3224160
- name: Gevulde koek
- description: baked treat filled with almond paste
- countries: (none)
- kinds: food, cookie
- ingredients: Pasta di mandorle PAT, almond, dough, egg as food
- has Wikipedia article: en

## DISH Q322787
- name: Mashed potato
- other names: {"zh": "马铃薯泥"}
- description: potato dish
- countries: (none)
- kinds: purée, potato dish
- ingredients: potato, butter, milk
- has Wikipedia article: en, zh

## DISH Q3228734
- name: Lechona
- description: stuffed roast pig in Colombian cuisine
- countries: CO
- kinds: pork dish

## DISH Q322899
- name: Abondance
- description: semi-hard, fragrant, raw-milk cheese made in Haute-Savoie, France; named after the French commune Abondance
- countries: FR
- cuisines: Savoy cuisine
- kinds: cheese, French cheese, raw-milk cheese, cow's-milk cheese, farmstead cheese, industrial cheese, pressed cooked cheese, dairy cheese
- ingredients: milk, cow's milk, raw milk
- has Wikipedia article: en

## DISH Q3232406
- name: Æbleflæsk
- other names: {"zh": "苹果猪肉"}
- description: Danish pork dish fried with apples, thyme and sugar
- countries: DK
- cuisines: Danish cuisine
- kinds: dish
- ingredients: yellow onion, peppercorn, cinnamon, bacon, sugar, apple
- has Wikipedia article: en, zh

## DISH Q3232603
- name: Marie biscuit
- other names: {"zh": "马利饼"}
- description: vanilla-flavoured round biscuit
- countries: (none)
- kinds: biscuit
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q3234514
- name: Dagang rice
- other names: {"zh": "搭冈饭"}
- description: Traditional food of Terengganu origin
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q3234931
- name: Otak-otak
- other names: {"zh": "乌打"}
- description: Muarian fish cakes
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, snack, side dish, kue
- ingredients: shallot, sago flour, garlic, caraway seeds, coriander seed, ginger, grated coconut, banana leaf, Spanish mackerel, Aleurites moluccanus, scallion, Chanos chanos, bird's eye chili, cooking oil, Alpinia galanga, Allium ascalonicum, chili pepper, egg as food, Tamarindus indica, Curcuma longa, table salt, coconut milk
- has Wikipedia article: en, zh

## DISH Q3234952
- name: Lion's head
- other names: {"zh": "狮子头"}
- description: Huaiyang dish, consisting of large pork meatballs stewed with vegetables
- countries: (none)
- kinds: meatball, pork dish
- has Wikipedia article: en, zh

## DISH Q32360952
- name: Cirdingis
- description: Chechen dish
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q32361264
- name: Yokh
- description: traditional Chechen dish
- countries: (none)
- cuisines: Chechen cuisine
- kinds: dish
- ingredients: cornmeal, tail fat, onion, intestine

## DISH Q32361667
- name: Motal
- description: Armenian traditional cheese
- countries: AM
- kinds: cheese, brined cheese
- ingredients: sheep milk, goat milk
- has Wikipedia article: en

## DISH Q3236175
- name: Nasi uduk
- other names: {"zh": "乌督饭"}
- description: Indonesian traditional rice cooked with coconut milk
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, traditional food, rice dish
- ingredients: Indonesian bay leaf, Kaffir Lime Leaf, coconut milk, Cymbopogon citratus, table salt, rice, water
- has Wikipedia article: en, zh

## DISH Q3237597
- name: Li p'tit rossê
- other names: {"fr": "Li p'tit rossê"}
- countries: BE
- kinds: cheese, list of Belgian cheeses, washed-rind cheese
- ingredients: cow's milk

## DISH Q3238238
- name: Beef ball
- other names: {"zh": "牛肉丸"}
- description: beef dish
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en, zh

## DISH Q3239751
- name: Hainanese chicken rice
- other names: {"zh": "海南鸡饭"}
- description: Rice and chicken dish originating from Hainan island
- countries: SG, TH, CN
- cuisines: Singaporean cuisine, Thai cuisine, Hainan cuisine, Chinese cuisine, Chinese Indonesian cuisine, Malaysian Chinese cuisine
- kinds: rice dish, chicken dish
- ingredients: chicken as food, rice
- has Wikipedia article: en, zh

## DISH Q3242200
- name: Geelse hartjes
- other names: {"nl": "Geelse hartjes"}
- countries: (none)
- kinds: pastry, regional product

## DISH Q3243732
- name: Bitter almond cookie
- description: Turkish kurabiye (cookie)
- countries: TR
- kinds: dish, almond biscuit
- ingredients: Prunus dulcis
- has Wikipedia article: en

## DISH Q3243750
- name: Afelia
- description: traditional Cypriot pork dish
- countries: CY
- kinds: pork dish
- has Wikipedia article: en

## DISH Q3244647
- name: Nasi kucing
- description: Indonesian rice dish originating from Java island
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, rice dish
- ingredients: anchovy, sambal, egg as food, rice
- has Wikipedia article: en

## DISH Q32460459
- name: Koza prostyńska
- other names: {"pl": "Koza prostyńska"}
- countries: PL
- kinds: bread

## DISH Q3246340
- name: Sweet potato pie
- other names: {"zh": "红薯饼"}
- description: traditional side dish in the southern United States
- countries: US
- kinds: side dish, pie
- ingredients: sweet potato, egg as food
- has Wikipedia article: en

## DISH Q3246820
- name: Custard cream
- description: type of biscuit popular in the United Kingdom and Republic of Ireland
- countries: GB
- kinds: food, biscuit
- has Wikipedia article: en

## DISH Q3247788
- name: Tandyr nan
- description: type of Central Asian naan
- countries: AF, KG, KZ, TJ, UZ
- kinds: bread, naan
- has Wikipedia article: en

## DISH Q3250451
- name: Kupati
- description: Georgian sausage
- countries: GE
- kinds: sausage, fresh sausage
- ingredients: beef, pork, spice, table salt
- has Wikipedia article: en

## DISH Q3257494
- name: Llapingacho
- description: Ecuadorian fried potato pancake
- countries: (none)
- kinds: dish, potato pancake
- has Wikipedia article: en

## DISH Q325765
- name: Allgäuer Bergkäse
- description: German cheese
- countries: DE
- kinds: cheese, Bergkäse, cow's-milk cheese
- ingredients: raw milk

## DISH Q32585145
- name: Chinese almond biscuit
- other names: {"zh": "杏仁餅"}
- countries: CN
- kinds: biscuit, almond biscuit

## DISH Q3258743
- name: Lokshen kugel
- other names: {"fi": "Lokshen kugel"}
- countries: (none)
- kinds: dish

## DISH Q3260142
- name: Lou Pisadou
- description: French pastry
- countries: (none)
- kinds: pastry

## DISH Q3260187
- name: Loubia
- description: Moroccan stewed beans
- countries: MA
- kinds: stew, side dish
- ingredients: white bean

## DISH Q3269362
- name: Laziji
- other names: {"zh": "辣子鸡"}
- description: Chinese Sichuan chicken with chilies
- countries: CN
- cuisines: Sichuan cuisine
- kinds: type of food or dish, chicken dish
- ingredients: chicken as food
- has Wikipedia article: en, zh

## DISH Q3269618
- name: Shaobing
- other names: {"zh": "烧饼"}
- description: Chinese food
- countries: CN
- kinds: food, bread
- has Wikipedia article: en, zh

## DISH Q3269818
- name: Nasi kuning
- other names: {"zh": "黄姜饭"}
- description: Indonesian yellow rice dish originating from Java
- countries: ID
- cuisines: Indonesian cuisine
- kinds: human food, type of food or dish, dish, Indonesian cuisine, rice dish
- ingredients: turmeric, coconut milk, cooked rice, Curcuma longa, rice
- has Wikipedia article: en

## DISH Q3270102
- name: Bebinca
- other names: {"zh": "貝碧嘉"}
- description: traditional Indo-Portuguese pudding dessert
- countries: IN
- cuisines: Goan cuisine
- kinds: pudding
- ingredients: coconut, ghee, flour, sugar
- has Wikipedia article: en, zh

## DISH Q3270149
- name: Singapore style noodles
- other names: {"zh": "星洲炒米"}
- description: Cantonese stir-fried dish
- countries: (none)
- kinds: dish, fried noodle
- ingredients: rice vermicelli
- has Wikipedia article: en, zh

## DISH Q3271515
- name: Saltah
- description: traditional Saudi food
- countries: YE
- kinds: stew
- has Wikipedia article: en

## DISH Q3272159
- name: Mithai
- other names: {"zh": "印度甜食"}
- description: confectionery and desserts of the Indian subcontinent
- countries: (none)
- kinds: type of food or dish, confectionery
- has Wikipedia article: en

## DISH Q3272179
- name: Kare-kare
- other names: {"zh": "Kare-kare"}
- description: Filipino cuisine
- countries: PH
- kinds: viand
- ingredients: oxtail
- has Wikipedia article: en, zh

## DISH Q3272827
- name: Bonbon
- other names: {"zh": "胖胖糖"}
- description: sweet or small confection coated in chocolate
- countries: FR
- kinds: candy, chocolate dish
- has Wikipedia article: en

## DISH Q3272930
- name: Kyaraben
- other names: {"zh": "角色便當"}
- description: boxed lunch decorated with characters from popular media, animals, and plants
- countries: JP
- kinds: dish, bento
- has Wikipedia article: en

## DISH Q3273096
- name: Doubanjiang
- other names: {"zh": "豆瓣酱"}
- description: Chinese bean paste
- countries: CN
- cuisines: Sichuan cuisine
- kinds: type of food or dish, hot sauce, fermented bean paste
- ingredients: broad bean
- has Wikipedia article: en, zh

## DISH Q3273642
- name: Mansaf
- other names: {"zh": "曼薩夫"}
- description: lamb dish
- countries: JO
- kinds: lamb dish, rice dish
- ingredients: jameed, lamb meat
- has Wikipedia article: en, zh

## DISH Q3273854
- name: Sachima
- other names: {"zh": "萨其马"}
- description: Manchurian pastry made of fluffy strands of fried batter bound together with a stiff sugar syrup
- countries: CN
- kinds: pastry
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q3273951
- name: Nasi Campur
- other names: {"zh": "印尼什锦饭"}
- description: Indonesian rice dish originating from Java island
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, street food, rice dish
- ingredients: egg as food, meat, rice
- has Wikipedia article: en

## DISH Q3273961
- name: Hishi mochi
- other names: {"zh": "菱饼"}
- description: diamond shaped mochi that consists of three layers
- countries: JP
- kinds: mochi, wagashi
- ingredients: mochi
- has Wikipedia article: en

## DISH Q3274058
- name: Chả cá Lã Vọng
- description: Vietnamese fish dish
- countries: VN
- kinds: dish, fish dish
- has Wikipedia article: en

## DISH Q3274068
- name: 亚眠马卡龙
- countries: (none)
- kinds: macaron, cookie

## DISH Q3274070
- name: Macaron de Boulay
- other names: {"fr": "Macaron de Boulay"}
- countries: (none)
- kinds: macaron

## DISH Q3274072
- name: 马卡罗纳德
- countries: (none)
- kinds: culinary speciality
- ingredients: macaroni, braciola, tomato sauce, Saucisse de Toulouse, pork ribs, Herbes de Provence

## DISH Q3274091
- name: Macatias
- countries: RE
- kinds: bread

## DISH Q3274645
- name: Jinhua ham
- other names: {"zh": "金華火腿"}
- description: Chinese cured ham
- countries: CN
- kinds: raw ham
- has Wikipedia article: en, zh

## DISH Q3275270
- name: Tangbao
- other names: {"zh": "灌汤包"}
- description: Soup-filled baozi from China
- countries: CN
- kinds: dish, baozi
- has Wikipedia article: en, zh

## DISH Q3275558
- name: Rice noodle roll
- other names: {"zh": "肠粉"}
- description: food
- countries: TH, HK, CN
- cuisines: Thai cuisine, Hong Kong cuisine, Cantonese cuisine
- kinds: type of food or dish, dim sum
- ingredients: rice noodle
- has Wikipedia article: en, zh

## DISH Q3275692
- name: Fios de ovos
- description: Portuguese egg dessert
- countries: PT
- cuisines: Portuguese cuisine
- kinds: dessert, egg noodle
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q3275951
- name: Fried shrimp
- other names: {"zh": "炸大虾"}
- description: type of food
- countries: (none)
- kinds: shrimp dish
- has Wikipedia article: en, zh

## DISH Q32759803
- name: Zelňačka
- description: Czech sauerkraut soup
- countries: CZ
- kinds: soup, cabbage soup, dish

## DISH Q3276660
- name: Tsukudani
- other names: {"zh": "佃煮"}
- description: simmered Japanese side dish
- countries: JP
- cuisines: Japanese cuisine
- kinds: nimono, seafood dish
- has Wikipedia article: en, zh

## DISH Q3277405
- name: Bacon and eggs
- description: breakfast dish
- countries: (none)
- kinds: food, breakfast, egg dish
- ingredients: egg as food, bacon
- has Wikipedia article: en

## DISH Q3278369
- name: Antwerps Handje
- description: cookie from Antwerp, Belgium
- countries: BE
- kinds: regional product, cookie
- has Wikipedia article: en

## DISH Q3280441
- name: Tostada
- other names: {"zh": "托斯塔達"}
- description: flat or bowl-shaped tortilla that is deep fried or toasted
- countries: MX
- kinds: dish
- ingredients: corn tortilla, wheat tortilla
- has Wikipedia article: en, zh

## DISH Q3281551
- name: Malasada
- description: Portuguese style fried doughnut
- countries: PT
- kinds: dessert, doughnut
- ingredients: dough, cinnamon, sugar
- has Wikipedia article: en

## DISH Q3281619
- name: Malban
- description: Lebanese sweet
- countries: LB
- kinds: confectionery
- ingredients: nougat, Pistacia vera

## DISH Q328178
- name: Steckerlfisch
- description: fish grilled on a stick
- countries: DE
- cuisines: German cuisine
- kinds: type of food or dish, fish dish
- ingredients: fish
- has Wikipedia article: en

## DISH Q3282218
- name: Malloreddus
- description: gnocchi-shaped pasta variety
- countries: IT
- kinds: pasta
- ingredients: durum flour, saffron, table salt
- has Wikipedia article: en

## DISH Q3286616
- name: Mantecadas de Astorga
- description: type of spongy pastry from Spain similar to a muffin
- countries: ES
- kinds: dessert
- ingredients: flour
- has Wikipedia article: en

## DISH Q3287467
- name: Marathon
- description: chocolate bar manufactured by Mars
- countries: (none)
- kinds: chocolate bar
- has Wikipedia article: en

## DISH Q32890
- name: Corn steak
- other names: {"zh": "粟米石斑塊"}
- description: Hong Kong dish consisting of fried fish served with corn and egg
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q3290483
- name: Caramelized potatoes
- countries: DK
- cuisines: Danish cuisine
- kinds: potato dish

## DISH Q329052
- name: Elderberry soup
- countries: DE
- kinds: soup
- ingredients: elderberry

## DISH Q3292757
- name: Vori vori
- description: Paraguayan soup
- countries: PY
- kinds: soup
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q3293380
- name: Twelve Grapes
- other names: {"zh": "十二颗葡萄"}
- description: Spanish New Year tradition
- countries: (none)
- kinds: tradition, dish
- has Wikipedia article: en, zh

## DISH Q3294501
- name: Marmite dieppoise
- other names: {"fr": "Marmite dieppoise"}
- countries: FR
- kinds: soup
- ingredients: fish

## DISH Q32945376
- name: Kapustnica
- countries: SK
- kinds: soup, cabbage soup, dish

## DISH Q3295382
- name: Potters Linea
- other names: {"nl": "Potters Linea"}
- countries: (none)
- kinds: candy

## DISH Q3296567
- name: Frigărui
- description: Romanian kebab
- countries: RO
- cuisines: Romanian cuisine
- kinds: dish, skewer
- has Wikipedia article: en

## DISH Q3296648
- name: Rubing
- other names: {"zh": "乳饼"}
- description: Chinese goat cheese
- countries: CN
- kinds: farmer cheese
- ingredients: goat milk
- has Wikipedia article: en, zh

## DISH Q3296760
- name: Liver casserole
- description: Finnish dish
- countries: FI
- kinds: casserole
- has Wikipedia article: en

## DISH Q3297247
- name: Masgouf
- other names: {"zh": "瑪斯古夫"}
- description: Iraqi national dish
- countries: IQ
- kinds: fish dish
- has Wikipedia article: en, zh

## DISH Q3297569
- name: Massepain cuit
- other names: {"fr": "Massepain cuit"}
- countries: (none)
- kinds: cake

## DISH Q32977
- name: Dominostein
- other names: {"zh": "多米诺巧克力"}
- description: Christmastime confection from Austria and Germany
- countries: DE
- kinds: confectionery
- ingredients: lebkuchen
- has Wikipedia article: en, zh

## DISH Q3298417
- name: Matelote
- description: French fish stew
- countries: FR
- cuisines: French cuisine
- kinds: fish stew
- ingredients: fish stock, fish as food, wine
- has Wikipedia article: en

## DISH Q3298630
- name: Crab rangoon
- other names: {"zh": "炸蟹角"}
- description: dumpling appetizer typically filled with cream cheese, crab meat, and other flavorings
- countries: US
- kinds: stuffed pasta, crab dish
- ingredients: wonton
- has Wikipedia article: en, zh

## DISH Q32996302
- name: Melekouni
- description: sesame seed treat
- countries: GR
- kinds: sesame seed candy, confectionery
- ingredients: sesame seed, honey

## DISH Q3301197
- name: Deep-fried pizza
- description: Scottish chip shop dish of pizza deep-fried (usually without batter)
- countries: (none)
- kinds: type of pizza, deep-fried food
- has Wikipedia article: en

## DISH Q3301328
- name: Sugar cookie
- description: plain, sweet cookie
- countries: (none)
- kinds: cookie
- ingredients: flour
- has Wikipedia article: en

## DISH Q3301336
- name: Negimaki
- description: japanese-American beef dish
- countries: JP, US
- kinds: dish
- ingredients: teriyaki sauce, beef, Welsh onion
- has Wikipedia article: en

## DISH Q3302944
- name: Rugbrød
- other names: {"zh": "黑麦面包"}
- description: Danish style rye bread
- countries: DK
- kinds: food, rye bread
- ingredients: sourdough
- has Wikipedia article: en

## DISH Q3303492
- name: المبرجة الجزائرية
- other names: {"ar": "المبرجة الجزائرية"}
- countries: (none)
- kinds: cake

## DISH Q3303725
- name: Mchewek
- description: pastry
- countries: DZ
- kinds: pastry
- ingredients: almond, egg as food

## DISH Q3304394
- name: Pork pie
- other names: {"zh": "豬肉派"}
- description: British meat pie
- countries: GB
- cuisines: English cuisine
- kinds: food, meat pie, pork dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q3304590
- name: Blackberry pie
- other names: {"zh": "黑莓派"}
- description: pie composed of blackberry filling
- countries: US
- kinds: fruit pie
- ingredients: blackberry
- has Wikipedia article: en, zh

## DISH Q3305189
- name: Cabidela
- other names: {"zh": "血鴨飯"}
- description: Portuguese cuisine dish
- countries: PT
- kinds: rice dish
- has Wikipedia article: en

## DISH Q3306566
- name: Merluza en salsa verde
- description: Basque dish
- countries: (none)
- kinds: dish

## DISH Q3306574
- name: Mermez
- countries: (none)
- kinds: potato dish

## DISH Q3307812
- name: Mhamsa
- countries: MA, TN
- kinds: dish

## DISH Q3307839
- name: Mi xao
- other names: {"fr": "Mi xao"}
- countries: (none)
- kinds: dish, Vietnamese cuisine, human nutrition, Chinese cuisine, food
- ingredients: cereal legume, chicken as food, noodle, pork, sauce, meat

## DISH Q3308312
- name: Cookies and Cream
- description: variety of ice cream based on flavoring from chocolate cookies
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q33084088
- name: Pizza in China
- description: overview about the pizza industry of China
- countries: (none)
- has Wikipedia article: en

## DISH Q3309212
- name: French dip sandwich
- description: sandwich on roll
- countries: US
- kinds: sandwich, beef dish
- has Wikipedia article: en

## DISH Q3312252
- name: Cozido à portuguesa
- other names: {"zh": "葡萄牙乱炖"}
- description: traditional Portuguese boiled meal
- countries: PT
- kinds: food, soup
- ingredients: meat
- has Wikipedia article: en

## DISH Q3312636
- name: Nisa cheese
- description: Portuguese cheese
- countries: PT
- kinds: cheese
- ingredients: sheep milk
- has Wikipedia article: en

## DISH Q3312775
- name: Provence Honey
- countries: FR
- kinds: honey
- has Wikipedia article: en

## DISH Q3312777
- name: Miel d'Alsace
- description: Honey product from Alsace
- countries: FR
- kinds: honey
- has Wikipedia article: en

## DISH Q3312779
- name: Miel de sapin des Vosges
- description: French honey
- countries: FR
- kinds: honey

## DISH Q3312825
- name: Migaine
- description: custard made with eggs and crème fraîche
- countries: (none)
- kinds: custard
- ingredients: crème fraîche, egg as food

## DISH Q3313106
- name: Mijet
- other names: {"fr": "mijet"}
- countries: FR
- kinds: food, soup
- ingredients: sugar, bread, red wine

## DISH Q33144185
- name: Bischofsbrot
- other names: {"de": "Bischofsbrot"}
- countries: (none)
- kinds: pastry

## DISH Q3314532
- name: Spiced meat roll
- countries: (none)
- kinds: pork dish, traditional food
- has Wikipedia article: en

## DISH Q3314588
- name: Mock turtle soup
- other names: {"zh": "仿龜湯"}
- description: 18th century dish
- countries: DE, GB
- cuisines: German cuisine, English cuisine
- kinds: soup, dish
- ingredients: offal
- has Wikipedia article: en

## DISH Q3314757
- name: Mince and tatties
- description: Scottish dish made from beef and potato
- countries: GB
- cuisines: Scottish cuisine
- kinds: potato dish, beef dish
- has Wikipedia article: en

## DISH Q3315724
- name: Mique
- countries: (none)
- kinds: pudding

## DISH Q3316075
- name: Mirliton de Pont-Audemer
- description: Norman pastry
- countries: FR
- kinds: pastry

## DISH Q3316076
- name: Mirliton de Rouen
- other names: {"zh": "鲁昂苹果烙饼"}
- description: Norman puff pastry tart
- countries: FR
- kinds: tart

## DISH Q3316163
- name: Miroton de bœuf
- countries: (none)
- kinds: guiso, type of food or dish

## DISH Q3316250
- name: Mise en bouche
- countries: (none)
- kinds: dish, course

## DISH Q3317001
- name: Mistral gagnant
- description: powdered candy
- countries: (none)
- kinds: candy

## DISH Q3317405
- name: Mkharek
- description: Tunisian pastry
- countries: TN
- kinds: beignet, pastry

## DISH Q3317412
- name: Mlabes
- description: pastry
- countries: DZ, TN
- kinds: pastry
- ingredients: egg white, almond, sugar

## DISH Q3318218
- name: Moffle
- description: Japanese dish; waffle rice cake
- countries: JP
- kinds: waffle, mochi
- has Wikipedia article: en

## DISH Q3319470
- name: Mole poblano
- countries: MX
- kinds: mole, culinary speciality

## DISH Q3322531
- name: Monte Etna PDO
- other names: {"zh": "Monte Etna DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3323782
- name: Morbiflette
- countries: FR
- kinds: dish, potato dish, Tartiflette variant

## DISH Q3323829
- name: Morcilla patatera
- description: Spanish blood sausage
- countries: ES
- kinds: blood sausage, potato dish, embutido
- ingredients: potato, paprika, blood

## DISH Q3325555
- name: Mussels marinière
- description: Traditional dish of mussels cooked with white wine, shallots, garlic and parsley
- countries: BE, FR
- kinds: dish
- ingredients: shallot, garlic, mussel, parsley, white wine

## DISH Q3325957
- name: Mounassou
- countries: (none)
- kinds: potato dish

## DISH Q332609
- name: Mus
- countries: (none)
- cuisines: Ainu cuisine, Nivkh cuisine
- kinds: gelatin dessert

## DISH Q3326257
- name: Mousse de foie de canard au Porto
- description: French offal dish
- countries: FR
- kinds: mousse, dish, appetizer
- ingredients: duck liver, crème fraîche, Port Wine, egg as food, black pepper

## DISH Q3326726
- name: Sukalki
- description: dish
- countries: ES, FR
- cuisines: Basque cuisine
- kinds: ragù, dish
- ingredients: potato, Choricero peppers, veal, vegetable
- has Wikipedia article: en

## DISH Q3327283
- name: Msoki
- description: soup traditional to Algerian and Tunisian Jews
- countries: TN
- kinds: dish
- ingredients: sheep meat, matzah, vegetable
- has Wikipedia article: en

## DISH Q3327301
- name: Mtewem
- description: Algerian meal
- countries: DZ
- kinds: dish
- ingredients: meatball, onion
- has Wikipedia article: en

## DISH Q3328358
- name: Musculine
- countries: FR
- kinds: dietary supplement, confectionery, culinary speciality

## DISH Q3330699
- name: Costrada
- countries: (none)
- kinds: empanada
- has Wikipedia article: en

## DISH Q3331341
- name: Guiso
- description: cooking method
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q3332648
- name: Androlla
- description: meat product
- countries: (none)
- cuisines: Galician cuisine
- kinds: sausage, embutido, dry sausage
- ingredients: oregano, garlic, paprika, pork, white wine
- has Wikipedia article: en

## DISH Q3334037
- name: Mămăligă în pături
- description: Romanian layered dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q3341250
- name: Bird's nest
- description: dish from Brussel
- countries: BE
- kinds: meat dish, egg dish, dish
- ingredients: meatball, boiled egg

## DISH Q3341335
- name: Niflettes
- countries: FR
- kinds: pastry, pasta
- ingredients: pastry cream, egg yolk, flour, butter, puff pastry, milk

## DISH Q3342000
- name: Niniches de Quiberon
- other names: {"fr": "Niniches de Quiberon"}
- countries: (none)
- kinds: lollipop

## DISH Q3342362
- name: Nkui
- description: traditional Cameroonian dish
- countries: CM
- kinds: dish
- ingredients: Triumfetta pentandra

## DISH Q3344796
- name: Nouacers
- other names: {"fr": "nouacers"}
- countries: TN
- kinds: dish
- ingredients: pasta

## DISH Q3344838
- name: The Nougat of Montélimar
- other names: {"zh": "蒙特利马尔牛轧糖"}
- description: type of French confection
- countries: (none)
- kinds: nougat
- ingredients: pistachio nut, azymes, egg white, almond, vanilla, honey
- has Wikipedia article: en

## DISH Q3346426
- name: Luchi
- description: deep-fried flatbread made of wheat flour
- countries: (none)
- kinds: flatbread
- has Wikipedia article: en

## DISH Q3347905
- name: Oatcake
- other names: {"zh": "燕麥蛋糕"}
- description: oat flatbread like a cracker or biscuit
- countries: GB
- kinds: cracker
- ingredients: oatmeal
- has Wikipedia article: en, zh

## DISH Q3348124
- name: Dahi vada
- description: Indian snack
- countries: IN
- cuisines: Indian cuisine
- kinds: chaat
- ingredients: Vada
- has Wikipedia article: en

## DISH Q3348137
- name: Sandesh
- description: Bengali confectionery
- countries: BD, IN
- kinds: cookie
- ingredients: chhena, sugar, milk
- has Wikipedia article: en

## DISH Q334891
- name: Joshpara
- other names: {"zh": "中亚馄饨"}
- description: Central Asian dumpling dish
- countries: IR
- kinds: dish, dumpling
- ingredients: minced meat, dumpling
- has Wikipedia article: en, zh

## DISH Q3349224
- name: Rosogolla
- other names: {"zh": "拉斯古拉"}
- description: syrupy dessert popular in the Indian subcontinent and regions with South Asian diaspora
- countries: IN
- kinds: dessert, confectionery
- ingredients: chhena, sucrose, semolina
- has Wikipedia article: en, zh

## DISH Q3349241
- name: Malapua
- description: pancake served as dessert or snack, originating from the Indian subcontinent
- countries: (none)
- kinds: confectionery
- ingredients: flour
- has Wikipedia article: en

## DISH Q3349340
- name: Odontol
- countries: (none)
- kinds: dish

## DISH Q3349987
- name: Ojja
- description: Tunisian dish made with eggs and vegetables
- countries: TN
- kinds: dish, stew
- ingredients: tomato, egg as food, vegetable

## DISH Q3350588
- name: Haleem
- other names: {"zh": "Haleem"}
- description: Indian subcontinental stew
- countries: (none)
- kinds: food, soup, stew
- ingredients: lentil, wheat, meat
- has Wikipedia article: en, zh

## DISH Q3350783
- name: Panta bhat
- description: Traditional Bengali/ Assamese dish
- countries: (none)
- kinds: rice dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q3351982
- name: Ummak huriyya salad
- description: Tunisian dish
- countries: TN
- kinds: dish
- has Wikipedia article: en

## DISH Q3351983
- name: Omelette de la mère Poulard
- description: French egg dish
- countries: (none)
- kinds: omelette
- has Wikipedia article: en

## DISH Q3355025
- name: Oranais
- description: Viennoiserie
- countries: (none)
- kinds: viennoiserie
- ingredients: apricot, pastry cream, puff pastry
- has Wikipedia article: en

## DISH Q335626
- name: Þorramatur
- other names: {"zh": "冰岛臭食"}
- description: selection of traditional Icelandic food
- countries: IS
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q3356613
- name: Layer cake
- other names: {"zh": "夹层蛋糕"}
- description: cake made from stacked layers of cake held together by filling
- countries: (none)
- kinds: cake
- has Wikipedia article: en, zh

## DISH Q3356849
- name: Fromage D'Orval
- countries: BE
- kinds: pressed uncooked cheese, mixed milk cheese, list of Belgian cheeses, cheese

## DISH Q3357405
- name: Velikonoční beránek
- description: lamb-shaped Czech cake
- countries: CZ
- kinds: cake

## DISH Q3357568
- name: Slider
- other names: {"zh": "小汉堡"}
- description: small sandwich
- countries: US
- kinds: hamburger, sandwich
- ingredients: bun
- has Wikipedia article: en, zh

## DISH Q3357698
- name: Sandbakelse
- description: north European cuisine
- countries: NO
- kinds: sugar cookie
- ingredients: flour
- has Wikipedia article: en

## DISH Q3358516
- name: Kiribath
- description: coconut milk rice dish
- countries: LK
- kinds: rice dish
- ingredients: coconut milk, rice
- has Wikipedia article: en

## DISH Q3359952
- name: Pabellón criollo
- description: Comida creada por el marihuano López. un consumidor de droga que echo de todo en una bolsa. a eso le llamo pabellón algo parecido al vomito después de una pea.
- countries: VE
- kinds: platter, rice dish
- ingredients: white rice, tajada, frijoles negros, ropa vieja
- has Wikipedia article: en

## DISH Q336039
- name: 油炸豆皮
- description: deep-fried tofu slices
- countries: JP
- kinds: Agemono, soy food, type of food or dish
- ingredients: tofu, soy bean
- has Wikipedia article: en, zh

## DISH Q3360448
- name: Pagnotta del Dittaino
- description: Italian sourdough bread
- countries: IT
- kinds: bread, loaf
- ingredients: sourdough

## DISH Q3360555
- name: Sandwich loaf
- description: North American dish of a sandwich made of a horizontally sliced loaf of bread
- countries: (none)
- kinds: food, sandwich
- ingredients: white bread
- has Wikipedia article: en

## DISH Q3360560
- name: Sourdough bread
- other names: {"zh": "酸面包"}
- description: bread made with a sourdough starter
- countries: (none)
- kinds: bread, baked good, fermented food, leavened bread
- ingredients: sourdough
- has Wikipedia article: en, zh

## DISH Q3360569
- name: Pain brié
- description: traditional Normandy bread
- countries: FR
- kinds: bread, baked good
- ingredients: flour
- has Wikipedia article: en

## DISH Q3360576
- name: Pain d'épices de Reims
- other names: {"fr": "Pain d'épices de Reims"}
- countries: (none)
- kinds: cake
- ingredients: cake

## DISH Q3360592
- name: Pa de fajol
- other names: {"ca": "Pa de fajol"}
- countries: (none)
- kinds: bread
- ingredients: buckwheat flour

## DISH Q3360595
- name: Pain de campagne
- description: French risen bread
- countries: FR
- kinds: bread, food
- has Wikipedia article: en

## DISH Q3360600
- name: Rewena bread
- description: Type of sourdough bread from New Zealand
- countries: NZ
- kinds: bread, potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q3360605
- name: Party surprise loaf
- countries: (none)
- kinds: dish
- ingredients: bread

## DISH Q3360607
- name: Tabouna bread
- description: bread
- countries: TN
- kinds: bread
- has Wikipedia article: en

## DISH Q3360757
- name: Hortobágyi palacsinta
- description: Hungarian stuffed crêpes
- countries: HU
- kinds: pancake, beef dish, veal dish
- ingredients: goulash, pancake
- has Wikipedia article: en

## DISH Q3361376
- name: Palet
- description: French pastry
- countries: (none)
- kinds: biscuit

## DISH Q3361383
- name: Palet breton
- description: French biscuit
- countries: (none)
- kinds: palet

## DISH Q3361960
- name: Panchuker
- countries: (none)
- kinds: bocadillo
- has Wikipedia article: en

## DISH Q3362039
- name: Genoa cake
- description: fruit cake from Genoa, Italy
- countries: IT
- kinds: Christmas cake
- ingredients: raisin
- has Wikipedia article: en

## DISH Q3362088
- name: Pangée
- other names: {"fr": "Pangée"}
- countries: (none)
- kinds: cake

## DISH Q3362159
- name: Panisse
- description: Traditional recipe of Liguria and Provence
- countries: IT
- cuisines: cuisine niçoise
- kinds: dish
- ingredients: besan

## DISH Q3362935
- name: Paprika of Szeged
- countries: HU
- kinds: paprika, spice

## DISH Q3362937
- name: Paprika of Kalocsa
- countries: HU
- kinds: paprika, spice

## DISH Q3365433
- name: Bakkwa
- other names: {"zh": "肉乾"}
- description: Salty-sweet dried meat product
- countries: CN
- kinds: dried meat, pork dish
- ingredients: dried meat, pork
- has Wikipedia article: en, zh

## DISH Q3368439
- name: Pasta di Gragnano PGI
- other names: {"zh": "Pasta di Gragnano IGP"}
- description: Italian PGI pasta
- countries: IT
- kinds: pasta, food product
- ingredients: flour

## DISH Q3368446
- name: Pastel de papa
- countries: (none)
- kinds: potato dish
- ingredients: onion, mashed potato, beef

## DISH Q3368469
- name: Pastillage
- description: sugar paste icing that dries firm
- countries: (none)
- kinds: sugar sculpture, confectionery

## DISH Q3368487
- name: Pastizz
- description: savory pastry from Malta filled with ricotta or mushy peas
- countries: MT
- cuisines: Maltese cuisine
- kinds: food, pastry
- ingredients: phyllo, ricotta, puff pastry
- has Wikipedia article: en

## DISH Q3368619
- name: Patachouffe
- other names: {"fr": "Patachouffe"}
- countries: BE
- kinds: pressed half-cooked cheese, list of Belgian cheeses, cheese

## DISH Q3368845
- name: Patranque
- description: French rural dish
- countries: (none)
- kinds: dish
- ingredients: bread
- has Wikipedia article: en

## DISH Q33691
- name: Meat chop
- other names: {"zh": "肋排"}
- description: meaty part at the end of ribs
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en, zh

## DISH Q3370171
- name: Skånsk æblekage
- other names: {"da": "Skånsk æblekage"}
- countries: (none)
- kinds: apple cake

## DISH Q3371467
- name: Hongshao rou
- other names: {"zh": "红烧肉"}
- description: pork dish
- countries: CN
- cuisines: Chinese cuisine
- kinds: pork dish, type of food or dish
- has Wikipedia article: en, zh

## DISH Q3373858
- name: Qingtuan
- other names: {"zh": "青团"}
- description: form of dumpling
- countries: CN
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q3376915
- name: Milk toast
- description: Breakfast dish consisting of toasted bread in warm milk
- countries: (none)
- kinds: bread dish
- ingredients: milk, toast
- has Wikipedia article: en

## DISH Q3377165
- name: Petit Lathuy
- other names: {"fr": "Petit Lathuy"}
- countries: BE
- kinds: white mold-rind cheese, list of Belgian cheeses, cheese
- ingredients: cow's milk

## DISH Q3377698
- name: Pets de sœurs
- description: French-Canadian pastry
- countries: CA
- kinds: food, dessert
- has Wikipedia article: en

## DISH Q3377925
- name: Pfloute
- other names: {"fr": "Pfloute"}
- countries: (none)
- kinds: potato dish

## DISH Q3378248
- name: Kongen af Danmark
- description: candy
- countries: (none)
- kinds: hard candy
- has Wikipedia article: en

## DISH Q3378936
- name: Boller i karry
- description: Danish meatball curry
- countries: DK
- kinds: meat dish
- ingredients: meatball

## DISH Q3379588
- name: Ziti
- other names: {"zh": "新郎麵"}
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta
- has Wikipedia article: en, zh

## DISH Q3380255
- name: Svensk pølseret
- other names: {"da": "svensk pølseret"}
- countries: DK
- kinds: dish

## DISH Q338205
- name: Bienenstich
- description: German cake
- countries: DE
- kinds: sheet cake, yeast cake
- ingredients: pastry cream, yeast dough, almond, butter
- has Wikipedia article: en

## DISH Q3382152
- name: Phở xào
- description: Vietnamese dish
- countries: VN
- kinds: meat dish, stir fried dish
- ingredients: bánh phở

## DISH Q338242
- name: Black and white cookie
- other names: {"zh": "美国人"}
- description: round cookie iced or frosted on one half with vanilla and on the other with chocolate
- countries: US
- kinds: biscuit
- ingredients: shortbread, black, white
- has Wikipedia article: en, zh

## DISH Q3382504
- name: Zeeuws spek
- description: Dutch cuisine
- countries: (none)
- kinds: dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q3382650
- name: Pieds paquets
- description: traditional Marseilles dish
- countries: FR
- kinds: food, dish
- ingredients: rumen
- has Wikipedia article: en

## DISH Q3388348
- name: Pikauba (cheese)
- description: Canadian cheese
- countries: CA
- kinds: cheese, cheese from Quebec
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q3388655
- name: Pinđur
- description: relish form
- countries: BG, MK, RS
- cuisines: Bulgarian cuisine, Serbian cuisine, Macedonian cuisine
- kinds: relish
- ingredients: eggplant, vegetable oil
- has Wikipedia article: en

## DISH Q3389074
- name: Piquenchagne
- other names: {"es": "Piquenchagne"}
- countries: FR
- kinds: tart, dessert
- ingredients: pear

## DISH Q3389085
- name: Piquette
- other names: {"fr": "piquette"}
- countries: FR
- kinds: dish

## DISH Q3389247
- name: Pissalat
- description: French condiment made from anchovies
- countries: (none)
- cuisines: cuisine niçoise
- kinds: fish sauce, fish dish
- has Wikipedia article: en

## DISH Q3389336
- name: Pithivier
- other names: {"zh": "皮蒂维耶蛋糕"}
- description: round, enclosed French pie
- countries: FR
- cuisines: French cuisine
- kinds: pastry
- ingredients: almond cream
- has Wikipedia article: en

## DISH Q3389508
- name: Pizza di scarola
- countries: IT
- ingredients: cheese

## DISH Q3391081
- name: Plakali
- description: Ghanaian food
- countries: GH
- kinds: swallow, food, Ghanaian cuisine
- has Wikipedia article: en

## DISH Q3391174
- name: Katemak
- description: East Nusa Tenggara food made from beef, sweet potatoes and corn
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, meat dish
- ingredients: shallot, cassava root, maize, garlic, chili pepper, meat
- has Wikipedia article: en

## DISH Q3391647
- name: Klappertaart
- description: Indonesian traditional cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, pastry
- ingredients: coconut, wheat flour, coconut water, almond, egg yolk, rum, raisin, table salt, sugar, milk, margarine
- has Wikipedia article: en

## DISH Q3392878
- name: Po'e
- description: Polynesian pudding
- countries: (none)
- kinds: pudding
- ingredients: coconut cream, banana
- has Wikipedia article: en

## DISH Q3393782
- name: Poire tapée
- other names: {"fr": "poire tapée"}
- countries: (none)
- kinds: dried fruit, culinary speciality
- ingredients: pear

## DISH Q3393785
- name: Poire à la Beaujolaise
- description: dessert
- countries: ES, FR
- kinds: dessert, poached pear
- ingredients: pear, red wine
- has Wikipedia article: en

## DISH Q3393853
- name: 'Ota 'ika
- description: Polynesian dish
- countries: (none)
- kinds: dish, seafood dish, raw fish dish
- has Wikipedia article: en

## DISH Q3393902
- name: Poivron de Szentes
- other names: {"fr": "Poivron de Szentes"}
- countries: HU
- kinds: bell pepper

## DISH Q3394588
- name: Almendrados de Allariz
- other names: {"es": "Almendrados de Allariz"}
- countries: ES
- kinds: dessert

## DISH Q3396004
- name: Pommes dauphine
- description: dish
- countries: FR
- cuisines: French cuisine
- kinds: potato dish
- ingredients: choux pastry, mashed potato
- has Wikipedia article: en

## DISH Q3396050
- name: Pompe
- other names: {"fr": "pompe"}
- countries: (none)
- kinds: dish

## DISH Q3396054
- name: Pompe aux pommes
- other names: {"fr": "pompe aux pommes"}
- countries: FR
- kinds: dessert
- ingredients: butter, puff pastry, sugar, apple

## DISH Q3396176
- name: Canutillos de Bilbao
- other names: {"es": "Canutillos de Bilbao"}
- countries: ES
- cuisines: Basque cuisine
- kinds: dish
- ingredients: custard, powdered sugar, puff pastry

## DISH Q3396229
- name: Biscayan sauce
- countries: ES, FR
- cuisines: Basque cuisine
- kinds: sauce
- ingredients: Choricero peppers, onion, olive oil, flour

## DISH Q3396255
- name: Pantxineta
- description: traditional Basque Country dessert
- countries: ES, FR
- cuisines: Basque cuisine
- kinds: dish, cake
- ingredients: chicken egg, cow's milk, custard, flour, butter, puff pastry, sugar
- has Wikipedia article: en

## DISH Q3396335
- name: Pont-Neuf
- other names: {"fr": "Pont-Neuf"}
- countries: FR
- kinds: pastry
- ingredients: pastry cream, shortcrust pastry, choux pastry

## DISH Q3397139
- name: Pastrmajlija
- description: Macedonian type of pie with pieces of pastrima
- countries: MK
- kinds: food, pie
- ingredients: dough
- has Wikipedia article: en

## DISH Q33977139
- name: Pineapple jam
- description: jam made from pineapples
- countries: (none)
- kinds: fruit jam
- ingredients: pineapple

## DISH Q3398148
- name: Porchetta di Ariccia PGI
- other names: {"zh": "Porchetta di Ariccia IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product, Porchetta PAT

## DISH Q339836
- name: Dim sum
- other names: {"zh": "点心"}
- description: style of Chinese cuisine of bite-sized portions served in small steamer baskets or plates
- countries: CN
- kinds: stuffed pasta, type of food or dish
- ingredients: fruit, seafood, vegetable, meat, pasta
- has Wikipedia article: en, zh

## DISH Q3398625
- name: Madeira cake
- other names: {"zh": "马德拉岛蛋糕"}
- description: sponge cake
- countries: GB
- kinds: sponge cake
- has Wikipedia article: en, zh

## DISH Q3399210
- name: Garibaldi biscuit
- other names: {"zh": "葡萄干饼干"}
- description: British biscuit consisting of currants squashed and sandwiched between two thin oblongs of biscuit dough before baking
- countries: GB
- cuisines: British cuisine
- kinds: type of food or dish, food, biscuit, cookie
- ingredients: cow's milk, wheat flour, currant, butter, sugar, grape
- has Wikipedia article: en

## DISH Q3399960
- name: Potaye
- other names: {"fr": "Potaye"}
- countries: (none)
- kinds: potato dish

## DISH Q3400143
- name: Potée limousine
- countries: (none)
- kinds: potée

## DISH Q3400256
- name: Poule au pot
- description: French chicken stew
- countries: FR
- kinds: dish
- has Wikipedia article: en

## DISH Q3400309
- name: Chicken Divan
- description: Recipe for baking chicken
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q3400315
- name: Chicken marsala
- other names: {"zh": "瑪莎拉雞肉"}
- description: Italian-American dish of chicken, mushrooms, and Marsala wine
- countries: IT
- kinds: Scaloppine, chicken dish
- ingredients: shallot, onion, chicken as food, Marsala DOC, edible mushroom, flour
- has Wikipedia article: en, zh

## DISH Q3400317
- name: Chicken moambe
- description: savoury chicken dish from central Africa
- countries: AO, CD, CG
- cuisines: Central African cuisine
- kinds: moambe, chicken dish
- ingredients: moambe, chicken as food
- has Wikipedia article: en

## DISH Q3400348
- name: Poumpet
- other names: {"fr": "poumpet"}
- countries: (none)
- kinds: cake

## DISH Q3400745
- name: Bottarga de Martigues
- description: dish from Martigues, France
- countries: FR
- kinds: dish
- ingredients: egg

## DISH Q3400746
- name: Pouteille
- countries: (none)
- kinds: dish

## DISH Q3400757
- name: Poutine râpée
- description: traditional Acadian dumpling dish
- countries: CA
- kinds: potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q3401127
- name: Poêlée montagnarde
- other names: {"fr": "Poêlée montagnarde"}
- countries: (none)
- kinds: potato dish

## DISH Q3404227
- name: Prisuttu
- other names: {"ca": "prisuttu"}
- countries: (none)
- kinds: salting, ham

## DISH Q3407661
- name: Prosciutto di Norcia PGI
- other names: {"zh": "Prosciutto di Norcia IGP"}
- description: Italian PGI meat product
- countries: IT
- kinds: meat product, prosciutto

## DISH Q3410675
- name: Puits d'amour
- description: French pastry filled with cream or jelly
- countries: FR
- kinds: pastry
- ingredients: puff pastry, jam
- has Wikipedia article: en

## DISH Q3411001
- name: Instant mashed potatoes
- description: dehydrated mashed potatoes
- countries: (none)
- kinds: mashed potato, instant food
- has Wikipedia article: en

## DISH Q3411523
- name: Paté criollo
- other names: {"es": "Paté criollo"}
- countries: FR
- kinds: dish

## DISH Q3411524
- name: Pâté de canard d'Amiens
- other names: {"zh": "亚眠鸭酱"}
- countries: (none)
- kinds: pâté en croûte
- ingredients: duck meat

## DISH Q3411531
- name: Pâté gaumais
- description: Belgian pie
- countries: BE
- kinds: pie

## DISH Q3411532
- name: Pâté en croûte
- other names: {"zh": "法式肉派"}
- description: traditional French meat pastry
- countries: FR
- kinds: meat pastry
- ingredients: puff pastry

## DISH Q3411536
- name: Pâté Lorrain
- description: French meat pastry
- countries: (none)
- kinds: appetizer, meat pastry
- ingredients: pork, puff pastry
- has Wikipedia article: en

## DISH Q3412160
- name: Pôchouse
- countries: (none)
- kinds: dish
- ingredients: pike
