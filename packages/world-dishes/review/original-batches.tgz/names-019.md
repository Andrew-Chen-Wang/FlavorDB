# Review batch names-019

## DISH Q1289229
- name: Prague ham
- description: type of boneless ham originally from Prague
- countries: (none)
- kinds: fiambre, smoked ham
- has Wikipedia article: en

## DISH Q12892299
- name: Kasav
- description: Haitian meal
- countries: HT
- kinds: dish
- ingredients: cassava

## DISH Q1289402
- name: Slambuc
- description: Hungarian stew
- countries: HU
- kinds: stew
- ingredients: garlic, potato, lebbencs, bacon

## DISH Q12895481
- name: Piti mi
- description: type of muesli
- countries: (none)
- kinds: dish, muesli

## DISH Q12897796
- name: Tonmtonm
- description: Haitian dish
- countries: HT
- kinds: dish
- ingredients: breadfruit

## DISH Q12899215
- name: Casatella Trevigiana PDO
- other names: {"zh": "Casatella Trevigiana DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: soft cheese, Italian cheese, cheese

## DISH Q1290028
- name: Somlói galuska
- description: Hungarian dessert
- countries: HU
- kinds: dessert, trifle

## DISH Q12902123
- name: Single Gloucester Cheese
- description: hard cheese from Gloucester
- countries: (none)
- kinds: cow's-milk cheese, English cheese, food
- ingredients: cow's milk

## DISH Q12902485
- name: Valencià
- other names: {"ca": "valencià"}
- description: dessert
- countries: (none)
- kinds: dessert

## DISH Q129098238
- name: Split pea soup
- description: variety of pea soup containing split peas
- countries: (none)
- kinds: dish, pea soup
- ingredients: split pea

## DISH Q129152
- name: Christmas wafer
- description: food
- countries: PL
- kinds: Christmas tradition, food, bread
- ingredients: wheat flour
- has Wikipedia article: en

## DISH Q129175425
- name: Meat sandwich
- other names: {"zh": "肉三明治"}
- description: sandwich containing meat
- countries: (none)
- kinds: type of food or dish, sandwich, meat dish

## DISH Q129178734
- name: Pince
- countries: SI
- kinds: pastry

## DISH Q129207023
- name: Gioitano
- other names: {"it": "Gioitano"}
- countries: (none)
- kinds: pastry, dessert

## DISH Q129243419
- name: Terang bulan
- description: Indo-Dutch pancake
- countries: ID
- kinds: pancake

## DISH Q1292506
- name: Gammon
- description: type of pork
- countries: (none)
- kinds: meat dish, raw ham
- has Wikipedia article: en

## DISH Q129259778
- name: Demok
- other names: {"ca": "demok"}
- countries: PW
- kinds: soup, type of food or dish
- ingredients: crab meat, coconut milk, Colocasia esculenta

## DISH Q129264258
- name: Sour soup
- description: type of soup
- countries: (none)
- kinds: soup

## DISH Q129306559
- name: Pitcher plant pulut
- countries: MY
- kinds: rice dish
- ingredients: Nepenthes, glutinous rice

## DISH Q129307011
- name: Mee mamak
- description: Malaysian noodle dish
- countries: MY
- kinds: noodle dish, Mee goreng
- ingredients: soy sauce, noodle, tofu, chili pepper, egg as food, potato

## DISH Q129307327
- name: Johor laksa
- description: type of laksa from Johor, Malaysia
- countries: MY
- cuisines: Malay cuisine
- kinds: laksa, noodle dish
- ingredients: Chirocentrus, coconut milk, spaghetti, kerisik, Garcinia atroviridis, cucumber, bean sprout

## DISH Q129307512
- name: Ayam percik
- description: Malaysian chicken dish
- countries: MY
- kinds: Ayam goreng

## DISH Q129307715
- name: Gulai tempoyak ikan patin
- description: Malaysian dish
- countries: MY
- cuisines: Malay cuisine
- kinds: fish dish
- ingredients: Tempoyak, gulai, Pangasius, durian

## DISH Q129307888
- name: Clay-fried fish
- description: Malaysian dish
- countries: MY
- kinds: fish dish
- ingredients: fish

## DISH Q129308081
- name: Gulai umbut
- description: type of gulai
- countries: MY
- kinds: gulai

## DISH Q129308210
- name: Gulai lemak cili padi
- description: type of gulai
- countries: (none)
- kinds: gulai

## DISH Q129308363
- name: Daging masak kurma
- description: Malaysian mutton dish
- countries: (none)
- kinds: gravy, goat meat dish

## DISH Q129308452
- name: Pajeri
- description: Malaysian dish
- countries: MY
- kinds: chutney

## DISH Q129308676
- name: Ikan dan pisang masak buluh
- other names: {"ms": "ikan dan pisang masak buluh"}
- countries: MY
- kinds: fish dish

## DISH Q129309329
- name: Sambal gesek ikan bilis
- description: type of sambal
- countries: MY
- kinds: sambal, condiment
- ingredients: Engraulidae, chili pepper

## DISH Q129309735
- name: Opok-opok
- description: Malaysian kueh
- countries: MY
- kinds: Kuih

## DISH Q129310056
- name: Breadfruit halva
- description: type of halva
- countries: (none)
- kinds: halva
- ingredients: breadfruit

## DISH Q129310302
- name: Wajik sirat
- description: Malaysian dish
- countries: (none)
- kinds: wajik

## DISH Q129310346
- name: Cassaba wajik
- description: type of wajik
- countries: (none)
- kinds: wajik
- ingredients: cassava root

## DISH Q129310952
- name: Pepper crab gravy
- description: crab gravy
- countries: MY
- kinds: crab dish

## DISH Q129313674
- name: Jagung ganti tandan
- other names: {"ms": "jagung ganti tandan"}
- countries: MY
- kinds: dessert
- ingredients: maize

## DISH Q129313803
- name: Kuih pepena
- description: Malaysian kueh
- countries: (none)
- kinds: Kuih

## DISH Q129314022
- name: Tompek
- description: dish from Sabah, Malaysia
- countries: (none)
- kinds: dish

## DISH Q129314449
- name: Steamed cassava
- description: Malay dish
- countries: (none)
- kinds: dish
- ingredients: cassava root

## DISH Q129314745
- name: Choon piah
- description: type of spring roll in Malaysia
- countries: (none)
- kinds: spring roll

## DISH Q129319045
- name: Itik golek
- description: Malaysian dish
- countries: MY
- kinds: duck dish

## DISH Q129319152
- name: Umbut rebus
- description: Malaysian dish
- countries: (none)
- kinds: dish

## DISH Q129319265
- name: Sambal biji getah
- other names: {"ms": "sambal biji getah"}
- countries: MY
- kinds: sambal

## DISH Q129319420
- name: Gulai masam keladi kemahang
- other names: {"ms": "gulai masam keladi kemahang"}
- countries: MY
- kinds: gulai, Tempoyak

## DISH Q129319591
- name: Sotong sumbat
- description: Malaysian squid dish
- countries: (none)
- kinds: squid dish

## DISH Q129319693
- name: Rendang campur
- description: type of rendang
- countries: (none)
- kinds: dish

## DISH Q129319923
- name: Sup belut
- description: eel dish
- countries: (none)
- kinds: dish

## DISH Q129320064
- name: Sambal rong
- description: type of sambal
- countries: MY
- kinds: sambal
- ingredients: asam rong

## DISH Q129320228
- name: Tauge masak lemak
- other names: {"ms": "tauge masak lemak"}
- countries: (none)
- kinds: gulai

## DISH Q129320371
- name: Lawar terung
- description: dish from Negeri Sembilan, Malaysia
- countries: (none)
- kinds: dish

## DISH Q129320476
- name: Lompap daging
- description: dish from Negeri Sembilan, Malaysia
- countries: MY
- kinds: dish

## DISH Q129320686
- name: Gerang asam
- description: Malaysian dish
- countries: (none)
- kinds: dish

## DISH Q129320804
- name: Ambila
- description: dish of Kristang community in Malaysia
- countries: (none)
- kinds: pork dish

## DISH Q129320895
- name: Asam rebus
- description: Malaysian dish
- countries: (none)
- kinds: dish

## DISH Q129321059
- name: Inchi kabin
- description: Peranakan fried chicken dish
- countries: MY
- kinds: fried chicken

## DISH Q1293258
- name: Bakmi
- other names: {"zh": "汁無し麺"}
- description: Indonesian pasta dish
- countries: ID
- kinds: dish, noodle, pasta dish
- ingredients: chicken as food, sesame oil, noodle, Brassica rapa subsp. chinensis, table salt, garlic, kecap manis, wheat flour
- has Wikipedia article: en

## DISH Q129328574
- name: Maribo
- other names: {"da": "Maribo"}
- countries: DK
- kinds: Danish cheese

## DISH Q129418274
- name: Mutton intestine soup
- other names: {"zh": "羊肠子"}
- countries: CN
- kinds: soup
- has Wikipedia article: zh

## DISH Q1295179
- name: Szatmári Szilvapálinka
- countries: HU
- kinds: Pálinka

## DISH Q12954648
- name: Pampavìa
- description: Typical biscuit from Ceresòle, Italy
- countries: IT
- cuisines: Italian cuisine
- kinds: cookie, pastry

## DISH Q12955006
- name: Quaquara
- description: biscuit from Genola, Italy
- countries: IT
- kinds: biscuit

## DISH Q129590051
- name: Pizza in North Korea
- countries: (none)
- has Wikipedia article: en

## DISH Q12961425
- name: Am
- description: Broth of cooked rice
- countries: CN
- kinds: broth

## DISH Q12961636
- name: Afritada
- description: Filipino meat and vegetable stew
- countries: PH
- kinds: chilindrón, viand
- has Wikipedia article: en

## DISH Q129618390
- name: Pyraene
- countries: (none)
- kinds: Western confection

## DISH Q12962178
- name: Biko
- description: type of sweet rice cake from the Philippines
- countries: PH
- kinds: rice cake
- ingredients: ginger, brown sugar, coconut milk, glutinous rice
- has Wikipedia article: en

## DISH Q12964402
- name: Gummy candy
- other names: {"zh": "軟糖"}
- description: gelatin/gum-based candies
- countries: DE
- kinds: food, candy, masticatory
- ingredients: natural gum, gelatin
- has Wikipedia article: en, zh

## DISH Q12964466
- name: Hamonado
- description: Filipino Christmas dish
- countries: PH
- kinds: pork dish
- has Wikipedia article: en

## DISH Q12964781
- name: Hototay
- description: Chinese food
- countries: (none)
- kinds: dish
- ingredients: pea, chicken breast, poached egg

## DISH Q12964893
- name: Igado
- description: Filipino meal
- countries: PH
- kinds: dish
- ingredients: Capsicum, pork, Allium sativum
- has Wikipedia article: en

## DISH Q129652189
- name: Chelang
- other names: {"ca": "chelang"}
- countries: PW
- kinds: dessert, dish
- ingredients: syrup, coconut milk, Colocasia esculenta, sugar

## DISH Q129652201
- name: Ukaeb
- other names: {"ca": "ukaeb"}
- countries: PW
- kinds: stuffed crab, dish

## DISH Q129652215
- name: Stuffed crab
- countries: (none)
- kinds: dish, stuffed food

## DISH Q12967012
- name: Latik
- other names: {"zh": "焦糖椰漿"}
- description: Filipino dessert garnishing and condiment
- countries: PH
- kinds: syrup, condiment
- ingredients: coconut
- has Wikipedia article: en

## DISH Q12967213
- name: Lepeg
- description: Food in the Philippines
- countries: PH
- kinds: food product
- ingredients: red rice

## DISH Q12969061
- name: Paksiw
- description: Filipino cooking process
- countries: PH
- kinds: dish
- has Wikipedia article: en

## DISH Q12969195
- name: Papaitan
- description: Filipino soup
- countries: PH
- kinds: soup
- ingredients: bile
- has Wikipedia article: en

## DISH Q12969316
- name: Pastillas
- description: Philippine milk-based confectionery
- countries: PH
- kinds: candy
- has Wikipedia article: en

## DISH Q12969705
- name: Putok
- description: Filipino bread roll
- countries: PH
- kinds: food, bread
- has Wikipedia article: en

## DISH Q12971248
- name: Macaroni soup
- description: soup containing macaroni pasta
- countries: IT
- kinds: soup, pasta dish, dish
- ingredients: macaroni
- has Wikipedia article: en

## DISH Q12974081
- name: Ambur biryani
- description: biryani dish from southern India
- countries: IN
- kinds: biryani, rice dish, dish

## DISH Q12975870
- name: Kool
- description: Sri Lankan seafood stew
- countries: LK
- kinds: stew, seafood dish
- ingredients: Odiyal, Tamarindus indica, seafood

## DISH Q1297721
- name: Eggs Sardou
- description: Louisiana Creole cuisine dish made with poached eggs, artichoke bottoms, creamed spinach and Hollandaise sauce
- countries: (none)
- cuisines: Louisiana Creole cuisine
- kinds: egg dish
- ingredients: spinach, globe artichoke, poached egg, hollandaise sauce, Tuber, Engraulis, egg as food
- has Wikipedia article: en

## DISH Q129785793
- name: Castelões
- description: Portuguese cheese
- countries: PT
- kinds: cheese

## DISH Q129811480
- name: Nasi buluh
- description: rice dish
- countries: (none)
- kinds: rice dish
- ingredients: bamboo, rice

## DISH Q129811486
- name: Sup tulang
- description: Malay soup dish
- countries: MY
- cuisines: Malay cuisine
- kinds: soup, meat dish
- ingredients: beef bones, clove, ginger, cardamom, onion, star anise, cinnamon

## DISH Q129811494
- name: Ubi gaung buluh
- description: bamboo dish from Malaysia
- countries: MY
- kinds: dish
- ingredients: Yam (vegetable)

## DISH Q129811500
- name: Dried steamed fish
- description: Malaysian fish dish
- countries: MY
- kinds: fish dish

## DISH Q129811505
- name: Cencaru sumbat sambal
- description: Malaysian fish dish
- countries: MY
- kinds: fish dish
- ingredients: Megalaspis cordyla

## DISH Q129811510
- name: Sayur midin goreng
- description: Malaysian vegetable dish
- countries: MY
- kinds: vegetable dish
- ingredients: Stenochlaena palustris, onion, shrimp paste, chili pepper

## DISH Q129811513
- name: Masak lemak mumbang
- description: type of gulai
- countries: (none)
- kinds: gulai

## DISH Q129811524
- name: Masak lemak kulat sisir
- description: type of gulai
- countries: (none)
- kinds: gulai

## DISH Q129811529
- name: Bubur anak lebah
- description: Malaysian porridge dish
- countries: MY
- kinds: porridge

## DISH Q129811536
- name: Ais kepal
- description: Malaysian shaved ice dish
- countries: MY
- kinds: shaved ice

## DISH Q129811542
- name: Koleh kacang
- description: type of kueh
- countries: (none)
- kinds: Kuih

## DISH Q129811597
- name: Tebaloi
- description: snack from Sarawak, Malaysia
- countries: MY
- kinds: snack
- ingredients: sago

## DISH Q129811603
- name: Solok ikan
- description: Malaysian fish dish
- countries: MY
- kinds: fish dish

## DISH Q129821504
- name: Gula tarik
- description: Malaysian kueh
- countries: (none)
- kinds: Kuih

## DISH Q129821582
- name: Kelamai
- description: Malaysian kueh
- countries: MY
- cuisines: Malay cuisine
- kinds: Kuih

## DISH Q129821670
- name: Tepung torak
- description: Malaysian kueh
- countries: (none)
- kinds: Kuih

## DISH Q129821898
- name: Sambal hitam ikan bilis
- description: type of sambal
- countries: MY
- kinds: sambal, condiment

## DISH Q129823080
- name: Badak kubang
- description: Malaysian kueh
- countries: (none)
- kinds: Kuih

## DISH Q129832149
- name: Bingka sawit
- description: Malaysian kueh
- countries: (none)
- kinds: Kuih

## DISH Q129832328
- name: Opor daging
- description: Malaysian mutton dish
- countries: (none)
- kinds: goat meat dish

## DISH Q129834204
- name: Iron Biscuits
- description: biscuit variety from Sahagún, Spain
- countries: ES
- kinds: cookie
- ingredients: egg as food, flour, butter, vanilla, sugar

## DISH Q129890788
- name: Талкыш-калеве
- other names: {"ru": "Талкыш-калеве"}
- countries: (none)
- kinds: confectionery

## DISH Q129900296
- name: Nesselrode pudding
- description: chestnut-based frozen dessert
- countries: RU
- cuisines: Russian cuisine
- kinds: dessert, dish
- ingredients: chestnut puree, succade, Maraschino, currant, sponge cake, whipped cream, egg yolk, powdered sugar
- has Wikipedia article: en

## DISH Q12997603
- name: Chakli
- description: fried-dough snack from India
- countries: IN
- kinds: food, fried dough
- ingredients: black gram flour, rice flour, besan
- has Wikipedia article: en

## DISH Q129979392
- name: Dulce de membrillo and cheese
- countries: (none)
- kinds: quince cheese
- ingredients: quince cheese, cheese

## DISH Q1300076
- name: Krautkrapfen
- countries: (none)
- kinds: dish

## DISH Q130061821
- name: Olive vegetable
- other names: {"zh": "橄榄菜"}
- countries: CN
- cuisines: Teochew cuisine
- kinds: side dish, human food, food
- has Wikipedia article: zh

## DISH Q130097
- name: Pemmican
- other names: {"zh": "乾肉餅"}
- description: mixture of tallow, dried meat, and sometimes dried berries
- countries: (none)
- kinds: dish, food, food preserve
- ingredients: dried meat, animal fats and oils, tallow, bone marrow, berry
- has Wikipedia article: en

## DISH Q130101093
- name: Chama
- description: Bolivian wheat bread
- countries: BO
- kinds: bread

## DISH Q130101795
- name: Three-pointed bread
- description: Peruvian wheat bread
- countries: PE
- kinds: bread

## DISH Q130101951
- name: Sango
- other names: {"es": "Sango"}
- countries: (none)
- kinds: food, gastronomy, guiso
- ingredients: cilantro, onion, yellowfin tuna, Plantanus orientalis, Bixa orellana, peanut, tomato, Allium sativum

## DISH Q130101956
- name: Sarna
- description: Bolivian cheese bread
- countries: BO
- kinds: bread

## DISH Q130125097
- name: Street food of South Africa
- description: overview of South African street food
- countries: (none)
- kinds: street food

## DISH Q13012656
- name: Kleeb lamduan
- description: Thai flower-shaped cookie
- countries: TH
- kinds: cookie
- has Wikipedia article: en

## DISH Q13012696
- name: Kuaichap
- other names: {"zh": "粿汁"}
- description: Chinese dish
- countries: (none)
- kinds: food, noodle, meat dish, stew
- has Wikipedia article: en, zh

## DISH Q13013252
- name: Khanom tan
- description: Thai dessert
- countries: TH
- kinds: dessert
- has Wikipedia article: en

## DISH Q13013257
- name: Khanom tom
- description: Thai dessert
- countries: TH
- kinds: dessert
- ingredients: coconut, rice flour
- has Wikipedia article: en

## DISH Q13013315
- name: Khao kha mu
- other names: {"zh": "猪脚饭"}
- description: Thai dish of stewed pork over rice
- countries: TH
- kinds: dish
- ingredients: pig's trotters, soy sauce pickle, sauce, rice
- has Wikipedia article: en

## DISH Q13013369
- name: Mango sticky rice
- other names: {"zh": "芒果糯米饭"}
- description: South and Southeast Asian dessert
- countries: (none)
- kinds: dessert
- ingredients: coconut milk, glutinous rice, mango
- has Wikipedia article: en, zh

## DISH Q13015322
- name: Thua nao
- description: traditional Shan food made from fermented soybeans
- countries: TH, MM
- cuisines: Thai cuisine, Burmese cuisine
- kinds: food, food ingredient
- ingredients: soybean
- has Wikipedia article: en

## DISH Q13015424
- name: Thong ek
- description: Thai dessert
- countries: TH
- kinds: snack, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q130186
- name: Torte
- other names: {"zh": "托爾特"}
- description: rich, usually multilayered, cake
- countries: (none)
- kinds: cake, confectionery
- ingredients: crust, buttercream
- has Wikipedia article: en, zh

## DISH Q13018870
- name: Mamuang kuan
- description: Thai preserved mango
- countries: TH
- kinds: confectionery
- has Wikipedia article: en

## DISH Q130194
- name: Nam ngiao
- other names: {"zh": "泰式辣湯麵"}
- description: food
- countries: CN, MM, TH
- cuisines: Thai cuisine
- kinds: soup, Thai curry
- ingredients: Dok ngio, garlic clove, tomato, Khanom chin, Thua nao, galangal, pork
- has Wikipedia article: en, zh

## DISH Q1301968
- name: Wat (food)
- other names: {"zh": "Wat"}
- description: Ethiopian and Eritrean stew or curry
- countries: ET
- kinds: stew
- ingredients: meat
- has Wikipedia article: en, zh

## DISH Q130198919
- name: Smash burger
- description: type of hamburger
- countries: (none)
- kinds: hamburger
- has Wikipedia article: en

## DISH Q130200473
- name: Kripanec
- description: Albanian pastry food
- countries: AL
- kinds: dish

## DISH Q13020442
- name: Luk chup
- description: Thai desert of marzipan
- countries: TH
- kinds: food
- has Wikipedia article: en

## DISH Q130225202
- name: Ćupter
- other names: {"hr": "Ćupter"}
- countries: (none)
- kinds: Bosnia and Herzegovina cuisine, Croatian cuisine, dessert
- ingredients: must, flour

## DISH Q1302342
- name: Cabbage stew a la Székely
- description: Hungarian stew dish
- countries: HU
- cuisines: Russian cuisine, Hungarian cuisine, Polish cuisine, Czech cuisine, Slovak cuisine
- kinds: goulash
- ingredients: pörkölt, sauerkraut, cream
- has Wikipedia article: en

## DISH Q130238975
- name: Boboji skewer
- other names: {"zh": "钵钵鸡"}
- countries: CN
- kinds: food
- has Wikipedia article: zh

## DISH Q130242386
- name: Buckwheat honey
- countries: (none)
- kinds: monofloral honey

## DISH Q130257193
- name: 津ぎょうざ
- other names: {"ja": "津ぎょうざ"}
- countries: (none)
- kinds: jiaozi

## DISH Q13025915
- name: Suea rong hai
- description: Northeastern Thai local food cooked from brisket of beef, flavored with spices, grilled rare, sliced into small pieces, and served with sticky rice and other dishes
- countries: TH
- kinds: beef dish, culinary speciality
- ingredients: brisket, fish sauce
- has Wikipedia article: en

## DISH Q13026131
- name: ゲーン・ルアン
- other names: {"ja": "ゲーン・ルアン"}
- countries: (none)
- kinds: Kaeng som

## DISH Q13026133
- name: Kaeng hang le
- other names: {"zh": "猪肉咖哩"}
- description: Northern Thai curry dish
- countries: TH
- kinds: Thai curry
- has Wikipedia article: en

## DISH Q130265510
- name: 3-in-1
- description: menu item in Irish fast food outlets
- countries: IE
- kinds: dish, curry, potato dish, rice dish
- ingredients: curry sauce, cooked rice, fries
- has Wikipedia article: en

## DISH Q130269974
- name: Varză à la Cluj
- description: a Hungarian-Romanian dish
- countries: RO
- kinds: dish

## DISH Q13028595
- name: Ашурэ
- other names: {"be": "Ашурэ"}
- countries: (none)
- kinds: dish

## DISH Q13028615
- name: Babka's porridge
- description: Belarusian food
- countries: (none)
- kinds: porridge

## DISH Q13028885
- name: Бяссольнік
- other names: {"be": "Бяссольнік"}
- countries: BY
- cuisines: Belarusian cuisine
- kinds: soup, dish
- ingredients: cannabis seed, millet, kvass

## DISH Q130298849
- name: פיתה סורית
- other names: {"he": "פיתה סורית"}
- countries: SY
- kinds: pita

## DISH Q130302285
- name: Ringerikskringle
- other names: {"nb": "Ringerikskringle"}
- countries: NO
- kinds: pastry, kringle

## DISH Q130303691
- name: Schnittkäse Marienberger PAT
- other names: {"zh": "Schnittkäse Marienberger PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q13030534
- name: Грыжанка
- other names: {"be": "Грыжанка"}
- countries: (none)
- kinds: soup
- ingredients: Brassica napus subsp. rapifera

## DISH Q130307901
- name: Lambiissi
- other names: {"fr": "Lambiissi"}
- countries: BF
- kinds: dish
- ingredients: cooking oil, ruminants, Allium sativum, table salt

## DISH Q13030990
- name: Каплун
- other names: {"be": "Каплун"}
- countries: (none)
- kinds: dish

## DISH Q130323394
- name: Schnitzel Pavlišov
- countries: CZ
- cuisines: Czech cuisine
- kinds: dish, escalope
- ingredients: houskové knedlíky, schnitzel, sauerkraut

## DISH Q13033550
- name: Яглі
- other names: {"be": "Яглі"}
- countries: (none)
- kinds: dish

## DISH Q130345178
- name: Mageli
- countries: ID
- kinds: dish, food
- ingredients: shallot, cassava root, garlic, coriander seed, Aleurites moluccanus, Kaempferia galanga, Vigna unguiculata, Vigna radiata, egg as food, black pepper

## DISH Q130349607
- name: Teriayki pine tsukimi burger
- countries: JP
- kinds: hamburger

## DISH Q130349748
- name: Pine tsukimi burger
- countries: JP
- kinds: hamburger, product

## DISH Q13035439
- name: Melkkos
- description: South African porridge
- countries: ZA
- kinds: porridge

## DISH Q13038702
- name: Panfried pork or veal escalope
- description: recipe for a panfried pork or veal escalope dish
- countries: (none)
- kinds: recipe, dish

## DISH Q130387201
- name: Roscón de Caldas
- other names: {"es": "roscón de Caldas"}
- countries: (none)
- kinds: roscón

## DISH Q130389191
- name: Linopot
- other names: {"dtp": "Linopot"}
- description: traditional dish of Sabah, Malaysia
- countries: (none)
- kinds: food, rice dish
- has Wikipedia article: en

## DISH Q130391489
- name: Chipotle pine tsukimi burger
- countries: JP
- kinds: hamburger, product

## DISH Q130395
- name: Oladyi
- other names: {"zh": "俄罗斯煎饼"}
- description: small thick pancakes or fritters common in Russian, Ukrainian and Belarusian cuisines
- countries: (none)
- kinds: pancake
- ingredients: sodium bicarbonate, egg as food, yeast, flour, salt, sugar, milk
- has Wikipedia article: en, zh

## DISH Q13041042
- name: Panfried cutlets of tender beef
- description: recipe for dish with panfried cutlets of tender beef
- countries: (none)
- kinds: recipe, dish

## DISH Q13041150
- name: Kryelana
- description: traditional Albanian baked dish, made from cornmeal and cheese
- countries: AL, XK
- kinds: human food

## DISH Q130417163
- name: Coffee ice cream
- description: ice cream flavor
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q130417229
- name: Tilkor Tarua
- description: tarua of Tilkor leaves in Mithila
- countries: (none)
- cuisines: Maithil cuisine
- kinds: fritter
- has Wikipedia article: en

## DISH Q13042357
- name: Lëng viçi
- description: recipe for a juicy beef dish
- countries: (none)
- kinds: recipe, dish

## DISH Q130425634
- name: সাবিত্রী
- other names: {"bn": "সাবিত্রী"}
- countries: BD
- kinds: human food

## DISH Q130436912
- name: Alua
- description: Indonesian food
- countries: ID
- kinds: kue, traditional food

## DISH Q130437003
- name: Babongko (wadai)
- other names: {"bjn": "Babongko (wadai)"}
- countries: ID
- kinds: kue, traditional food

## DISH Q1304390
- name: Oyakodon
- other names: {"zh": "親子丼"}
- description: Japanese chicken and rice dish
- countries: JP
- cuisines: Japanese cuisine
- kinds: donburi, rice dish, chicken dish, egg dish
- ingredients: chicken egg, chicken as food, rice
- has Wikipedia article: en, zh

## DISH Q13044059
- name: Patsas
- description: Greek tripe soup
- countries: GR
- kinds: soup

## DISH Q130443517
- name: Ninniku Garlic The One Pounder
- countries: JP
- kinds: hamburger, product

## DISH Q13046295
- name: Peppers with garlic and cream
- description: Dish made from sauteed peppers with garlic and sour cream
- countries: AL
- cuisines: Albanian cuisine
- kinds: food
- ingredients: Allium sativum, Capsicum annuum

## DISH Q130465645
- name: Panhas
- description: traditional German food
- countries: DE
- kinds: dish, blood sausage
- has Wikipedia article: en

## DISH Q13046648
- name: Tomato casserole from Gjakova
- description: Baked dish consisting mainly of tomatoes, onions and beef
- countries: XK
- cuisines: Albanian cuisine
- kinds: casserole, dish
- ingredients: tomato

## DISH Q130470526
- name: Rista
- description: Meatballs in a fiery red gravy, a dish in Wazwan
- countries: (none)
- kinds: human food, meatball, lamb dish
- ingredients: mutton

## DISH Q130470549
- name: Tabak maaz
- description: a dish in served in Wazwan made from ribs of lamb simmered in yogurt, then fried
- countries: (none)
- kinds: human food, cuisine, lamb dish
- ingredients: mutton
- has Wikipedia article: en

## DISH Q130471891
- name: Cicada ice cream
- description: abnormal food
- countries: (none)
- kinds: ice cream

## DISH Q130472512
- name: Carolina
- other names: {"pt": "carolina"}
- countries: BR
- kinds: confectionery

## DISH Q130478550
- name: Black raspberry ice cream
- description: ice cream flavor
- countries: (none)
- kinds: ice cream flavor
- ingredients: black raspberry, Ice Cream
- has Wikipedia article: en

## DISH Q130485240
- name: Mummentaart
- other names: {"lb": "Mummentaart"}
- countries: (none)
- kinds: apple pie

## DISH Q130486184
- name: Amaretti siciliani
- other names: {"it": "Amaretti siciliani"}
- countries: IT
- kinds: food

## DISH Q130486185
- name: Biscotto della monaca
- description: typical biscuit from Catania, Italy
- countries: IT
- kinds: cookie, biscuit

## DISH Q130486188
- name: Biscotti al latte PAT
- other names: {"zh": "Biscotti al latte PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: biscuit, baked good

## DISH Q130486189
- name: Biscotti di Natale PAT
- other names: {"zh": "Biscotti di Natale PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486190
- name: Biscotti duri PAT
- other names: {"zh": "Biscotti duri PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486191
- name: Biscotto di Monreale PAT
- other names: {"zh": "Biscotto di Monreale PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486192
- name: Biscotti glassati PAT
- other names: {"zh": "Biscotti glassati PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486193
- name: Bocconetto PAT
- other names: {"zh": "Bocconetto PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486194
- name: Braccialetti di Nicosia
- other names: {"it": "Braccialetti di Nicosia"}
- countries: IT
- kinds: food

## DISH Q130486195
- name: Cannillieri PAT
- other names: {"zh": "Cannillieri PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486197
- name: Cassateddi di Calatafimi PAT
- other names: {"zh": "Cassateddi di Calatafimi PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486198
- name: Cassatella di ceci PAT
- other names: {"zh": "Cassatella di ceci PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486199
- name: Ciascuna PAT
- other names: {"zh": "Ciascuna PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486201
- name: Cucciddati di Calatafimi PAT
- other names: {"zh": "Cucciddati di Calatafimi PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486202
- name: Cucuzzata PAT
- other names: {"zh": "Cucuzzata PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good, food

## DISH Q130486203
- name: Cuddriruni PAT
- other names: {"zh": "Cuddriruni PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486204
- name: Cuddriruni duci PAT
- other names: {"zh": "Cuddriruni duci PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486205
- name: Cudduruni di Buccheri PAT
- other names: {"zh": "Cudduruni di Buccheri PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486206
- name: Cuffitelle PAT
- other names: {"zh": "Cuffitelle PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486207
- name: Duci di tibbi PAT
- other names: {"zh": "Duci di tibbi PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486208
- name: Facciuni di Santa Chiara
- other names: {"it": "Facciuni di Santa Chiara"}
- countries: IT
- kinds: food

## DISH Q130486209
- name: Fasciatelle PAT
- other names: {"zh": "Fasciatelle PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486211
- name: Funciḍḍi di Buccheri
- other names: {"it": "Funciḍḍi di Buccheri"}
- countries: IT
- kinds: food

## DISH Q130486212
- name: Gaḍḍuzzi
- other names: {"it": "Gaḍḍuzzi"}
- countries: IT
- kinds: food

## DISH Q130486213
- name: Guammelle PAT
- other names: {"zh": "Guammelle PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486214
- name: Mandorlato siciliano
- other names: {"it": "Mandorlato siciliano"}
- countries: IT
- kinds: food

## DISH Q130486215
- name: Mastazzola PAT
- other names: {"zh": "Mastazzola PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486216
- name: Mmugliulati PAT
- other names: {"zh": "Mmugliulati PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486217
- name: Nfasciateḍḍi
- other names: {"it": "Nfasciateḍḍi"}
- countries: IT
- kinds: food

## DISH Q130486218
- name: Nfasciateḍḍi di Agira
- other names: {"it": "Nfasciateḍḍi di Agira"}
- countries: IT
- kinds: food

## DISH Q130486219
- name: Nfasciateḍḍi di Troina
- other names: {"it": "Nfasciateḍḍi di Troina"}
- countries: IT
- kinds: food

## DISH Q130486220
- name: Nfrigghiulata PAT
- other names: {"zh": "Nfrigghiulata PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486221
- name: Pagnotta alla disgraziata PAT
- other names: {"zh": "Pagnotta alla disgraziata PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: sandwich, food, baked good

## DISH Q130486222
- name: Pane a lievitazione naturale PAT
- other names: {"zh": "Pane a lievitazione naturale PAT"}
- countries: IT
- kinds: food, baked good

## DISH Q130486223
- name: Pane di Monreale PAT
- other names: {"zh": "Pane di Monreale PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486224
- name: Pane di San Giuseppe
- other names: {"it": "Pane di San Giuseppe"}
- countries: IT
- kinds: food

## DISH Q130486225
- name: Papareddi PAT
- other names: {"zh": "Papareddi PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486226
- name: Pasta alla crema di latte PAT
- other names: {"zh": "Pasta alla crema di latte PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486227
- name: Pasta di nocciola PAT
- other names: {"zh": "Pasta di nocciola PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486230
- name: Pizzarruna PAT
- other names: {"zh": "Pizzarruna PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486231
- name: Scursunera PAT
- other names: {"zh": "Scursunera PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486232
- name: Squartucciatu PAT
- other names: {"zh": "Squartucciatu PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486234
- name: Testa di turco PAT
- other names: {"zh": "Testa di turco PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, baked good

## DISH Q130486236
- name: Vucciḍḍati di mènnuli
- other names: {"it": "Vucciḍḍati di mènnuli"}
- countries: IT
- kinds: food

## DISH Q130493246
- name: Teaberry ice cream
- description: ice cream flavor
- countries: (none)
- kinds: flavoring, ice cream
- ingredients: white sugar, Gaultheria procumbens, cream, milk
- has Wikipedia article: en

## DISH Q130493939
- name: Garba
- other names: {"fr": "Garba"}
- countries: CI
- kinds: dish
- ingredients: Acheke, Thunnus, chili pepper

## DISH Q1305079
- name: Ghormeh sabzi
- other names: {"zh": "波斯炖菜"}
- description: Iranian herb stew
- countries: IR
- kinds: stew, food
- ingredients: coriander seed, herb, Trigonella foenum-graecum, Phaseolus vulgaris, parsley
- has Wikipedia article: en

## DISH Q130513962
- name: Guastedda dolce nissena
- other names: {"it": "Guastedda dolce nissena"}
- description: typical Nisseno dessert
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q130526517
- name: Sunflower honey
- description: type of honey
- countries: (none)
- kinds: monofloral honey

## DISH Q130526536
- name: Polyfloral honey
- description: type of honey
- countries: (none)
- kinds: honey

## DISH Q130526575
- name: Esparcet honey
- description: type of honey
- countries: (none)
- kinds: monofloral honey

## DISH Q130529381
- name: ごんじゅう
- other names: {"ja": "ごんじゅう"}
- description: type of onigiri
- countries: JP
- kinds: onigiri

## DISH Q130529385
- name: Milk tofu
- other names: {"zh": "奶豆腐"}
- description: coagulated soy milk compressed into blocks
- countries: MN
- kinds: dairy product, human food
- has Wikipedia article: zh

## DISH Q130529392
- name: くるみ雑煮
- other names: {"ja": "くるみ雑煮"}
- countries: JP
- kinds: zōni

## DISH Q130531854
- name: Totò al cioccolato
- description: typical chocolate biscuit of Catania, Italy
- countries: IT
- kinds: biscuit

## DISH Q130532079
- name: Strigoli
- other names: {"it": "strigoli"}
- countries: IT
- kinds: type of pasta

## DISH Q130541457
- name: Mangkrik
- other names: {"jv": "Mangkrik"}
- countries: ID
- kinds: human food
- ingredients: mashed potato, egg as food, carrot

## DISH Q130541856
- name: Ngiu vun sui
- other names: {"zh": "牛搵水"}
- description: Taiwanese traditional hakka dessert
- countries: TW
- kinds: dessert
- has Wikipedia article: zh

## DISH Q13054393
- name: Chanakh
- description: Armenian traditional cheese
- countries: AM
- kinds: cheese, brined cheese
- ingredients: cow's milk

## DISH Q130552525
- name: Kluwa
- other names: {"jv": "Kluwa"}
- countries: ID
- kinds: dish, human food
- ingredients: palm sugar, pumpkin

## DISH Q130552535
- name: Javanese fritters
- countries: ID
- kinds: dish, human food
- ingredients: egg as food, flour, cheese

## DISH Q130553333
- name: Mie Bangladesh
- description: Indonesian noodle dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q130559284
- name: Gangan haliling
- other names: {"bjn": "gangan haliling"}
- countries: ID
- kinds: food, soup, vegetable soup, dish
- ingredients: Indonesian bay leaf, garlic, Pila ampullacea, Aleurites moluccanus, coconut milk, Alpinia galanga, Cymbopogon citratus

## DISH Q130559314
- name: Sayur rebung
- description: Indonesian food
- countries: ID
- kinds: food, soup, vegetable soup, dish
- ingredients: bamboo shoots

## DISH Q130571534
- name: Dubai chocolate
- other names: {"zh": "杜拜巧克力"}
- description: chocolate tablet filled with battered dough and pistachio
- countries: AE
- kinds: chocolate
- ingredients: pistachio nut, Kadayif, tehina, chocolate
- has Wikipedia article: en, zh

## DISH Q13057386
- name: Kodma
- description: an Indian sugar candy
- countries: (none)
- kinds: confectionery
- ingredients: sugar

## DISH Q13057890
- name: Chhola bhuna
- description: bengali cuisine
- countries: (none)
- kinds: dish

## DISH Q13058198
- name: Darbesh
- countries: (none)
- kinds: confectionery

## DISH Q1305991
- name: Einback
- other names: {"de": "Einback"}
- countries: (none)
- kinds: sweet bread

## DISH Q130611730
- name: Lanche
- description: Portuguese dish
- countries: PT
- cuisines: Portuguese cuisine
- kinds: cheese, snack, food

## DISH Q130632338
- name: Eungkot Paya
- description: processed curry made from freshwater fish or swamp fish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: gulai, soup, food, dish, human food, type of food or dish
- ingredients: Etlingera elatior, coconut milk, Channa striata, Piper longum, Murraya koenigii, Allium ascalonicum, Citrus × aurantiifolia, chili pepper, Curcuma longa, Coriandrum sativum, Allium sativum, Cocos nucifera, table salt, sugar

## DISH Q130633595
- name: Chocolate haupia pie
- description: hawaiian dessert
- countries: US
- cuisines: Hawaii regional cuisine
- kinds: pie
- ingredients: Haupia, whipped cream
- has Wikipedia article: en

## DISH Q130668778
- name: Rostisciada
- other names: {"lmo": "Rostisciada"}
- countries: IT
- kinds: dish
- ingredients: Luganega, pancetta, pork, butter, tomato, onion

## DISH Q130677132
- name: Obo Ẹgwa
- description: Igala native soup prepared using beans
- countries: NG
- kinds: soup, dish, cuisine, human food
- ingredients: Fish, onion, bean, palm oil, Capsicum, Ceratonia siliqua, meat

## DISH Q130680930
- name: Discodel
- other names: {"nl": "Discodel"}
- countries: (none)
- kinds: snack

## DISH Q130681129
- name: Krokodel
- other names: {"nl": "Krokodel"}
- countries: (none)
- kinds: snack

## DISH Q130681167
- name: Loempidel
- other names: {"nl": "Loempidel"}
- countries: (none)
- kinds: snack

## DISH Q13069284
- name: Pon ye gyi
- description: Burmese fermented bean paste
- countries: MM
- kinds: fermented bean paste
- ingredients: Horse gram
- has Wikipedia article: en

## DISH Q130709926
- name: Tori paitan ramen
- countries: (none)
- kinds: ramen
- ingredients: chicken soup

## DISH Q130718197
- name: Abada
- description: Abada is an igala snack or chop made out of bambara nut flour (okpa flour). It can be enjoyed with pap or tea.
- countries: (none)
- kinds: dish, human food, snack

## DISH Q130718589
- name: Ogidigbo
- description: indigenous igala meal
- countries: (none)
- kinds: dish
- ingredients: maize

## DISH Q130741353
- name: Sbatudella
- other names: {"lmo": "Sbatudella"}
- countries: (none)
- cuisines: Lombard cuisine
- kinds: human food
- ingredients: egg as food

## DISH Q130751270
- name: Focaccia nissena
- other names: {"it": "Focaccia nissena"}
- description: Italian spleen sandwich
- countries: (none)
- kinds: focaccia

## DISH Q130758673
- name: Muffin
- countries: (none)
- cuisines: Ancient Roman cuisine
- kinds: pastry, human food

## DISH Q130777293
- name: Kočičí svatba
- other names: {"cs": "kočičí svatba"}
- countries: (none)
- kinds: dish
- ingredients: groat

## DISH Q130793834
- name: Boer
- other names: {"es": "boer"}
- countries: (none)
- kinds: cookie
- ingredients: wafer, stuffing

## DISH Q130804980
- name: Hiyama nattō
- countries: (none)
- kinds: nattō

## DISH Q130807868
- name: Chestnut hearts
- description: South Tyrolean dessert
- countries: IT
- kinds: food, dessert
- ingredients: Chestnut

## DISH Q1308184
- name: Ischler Törtchen
- countries: AT
- kinds: sweet dish

## DISH Q1308323
- name: Egg drop soup
- other names: {"zh": "蛋花汤"}
- description: Chinese soup of wispy beaten eggs in boiled chicken broth
- countries: CN
- kinds: soup, egg dish
- ingredients: broth, egg as food
- has Wikipedia article: en, zh

## DISH Q130878
- name: Chewing gum
- other names: {"zh": "口香糖"}
- description: soft, cohesive substance intended for chewing but not swallowing
- countries: (none)
- kinds: confectionery, masticatory
- ingredients: gum base, chicle, sweetener
- has Wikipedia article: en, zh

## DISH Q130899848
- name: Gangan Susupan
- description: Indonesian food
- countries: ID
- kinds: dish, soup

## DISH Q130899872
- name: Gangan Luncar
- other names: {"id": "Gangan Luncar"}
- countries: ID
- kinds: dish, soup

## DISH Q130902289
- name: Redning
- other names: {"sv": "redning"}
- countries: (none)
- kinds: sauce, ragout, food ingredient

## DISH Q13092279
- name: Bugis
- description: Meal in central Java
- countries: ID
- kinds: dish
- ingredients: rice flour, beetle

## DISH Q13092409
- name: Cethot
- description: Indonesian dish
- countries: ID
- kinds: dish

## DISH Q13093120
- name: Gemblong
- description: Indonesian traditional cake
- countries: ID
- kinds: dish, confectionery, meal, jajan pasar
- ingredients: glutinous rice flour, coconut milk, table salt, sugar

## DISH Q13093505
- name: Jadah
- other names: {"id": "Jadah"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, meal

## DISH Q130937219
- name: Hurut
- description: traditional Armenian dish
- countries: AM
- kinds: human food, dried food
- ingredients: celery, raw milk, parsley

## DISH Q13094329
- name: Kimpul
- description: food
- countries: (none)
- kinds: food product

## DISH Q13094650
- name: Legendar
- description: Sauce made from dried and then fried rice
- countries: ID
- kinds: dish, sauce
- ingredients: fried rice

## DISH Q13094657
- name: Lembarang
- description: dish that is served as a side dish
- countries: (none)
- cuisines: Javanese cuisine
- kinds: dish, side dish
- ingredients: shallot, onion, chicken as food, coconut milk

## DISH Q13094672
- name: Lentho
- description: Indonesian savoury snack made of black-eyed pea
- countries: ID
- cuisines: Indonesian cuisine
- kinds: snack, human food, traditional food, type of food or dish, dish, fritter
- ingredients: Kaempferia galanga, cooking oil, Coriandrum sativum, table salt, granulated sugar, Kaffir Lime Leaf, cassava root, garlic, coconut, nut

## DISH Q13095522
- name: Ote ote
- description: Food from East Java
- countries: (none)
- kinds: dish
- ingredients: wheat flour, vegetable

## DISH Q13095830
- name: Pasung
- description: Javanese food made from rice flour
- countries: (none)
- cuisines: Javanese cuisine
- kinds: type of food or dish, human food, rice dish

## DISH Q13096003
- name: Molen banana
- description: Indonesia traditional snack
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, snack, human food, traditional food, type of food or dish
- ingredients: vegetable oil, corn starch, wheat flour, egg yolk, butter, vanilla, table salt, sugar, banana, water

## DISH Q130961449
- name: Rivers state native soup
- description: Nigerian dish
- countries: NG
- kinds: food, dish, soup
- ingredients: shrimp and prawn as food, crayfish, palm oil, Capsicum, table salt, meat, fish

## DISH Q1309680
- name: Teste de Turke
- countries: (none)
- kinds: meat dish
- has Wikipedia article: en

## DISH Q13096825
- name: Klatak Satay
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, traditional food, type of food or dish, jajan pasar, beef, satay, street food
- ingredients: granulated sugar, shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, caraway seeds, coriander seed, ginger, kecap manis, Aleurites moluccanus, coconut milk, goat meat, cooking oil, Alpinia galanga, Citrus × aurantiifolia, Tamarindus indica, black pepper, Cymbopogon citratus, cinnamon, clove, table salt, margarine, water
- has Wikipedia article: en

## DISH Q13096834
- name: Maranggi satay
- description: Sundanese food, Indonesia
- countries: ID
- cuisines: Indonesian cuisine, Javanese cuisine
- kinds: dish, Indonesian cuisine, human food, traditional food, type of food or dish, satay
- ingredients: shallot, garlic, coriander seed, tomato, kecap manis, palm sugar, soy sauce, beef, acetic acid, vinegar, table salt, cayenne pepper

## DISH Q13096849
- name: Nasi jinggo
- description: Balinese dish
- countries: ID
- kinds: rice dish
- ingredients: shallot, garlic, palm sugar, Aleurites moluccanus, shrimp paste, chicken as food, chili pepper, Curcuma longa, Cymbopogon citratus, table salt
- has Wikipedia article: en

## DISH Q13096852
- name: Nasi Kapau
- description: Indonesian cuisine originating from Kapau region in West Sumatra
- countries: ID
- cuisines: Indonesian cuisine, Padang cuisine
- kinds: food, traditional food
- ingredients: rice, side dish
- has Wikipedia article: en

## DISH Q13097480
- name: Kupat Sumpil
- countries: (none)
- kinds: food, dish, traditional food

## DISH Q13097602
- name: Tahu bakso
- description: Indonesian food made from tofu and meatball
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: tapioca, beef, tofu, egg as food, Allium sativum, table salt

## DISH Q13097607
- name: Tahu kuning
- other names: {"id": "tahu kuning"}
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, tofu
- ingredients: soy bean, Curcuma longa, water

## DISH Q13097938
- name: Tiwul
- description: javanese tradisional rice
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish, meal
- ingredients: cassava root

## DISH Q1310066
- name: LPG cake
- description: type of cake from southeast Germany
- countries: DD
- cuisines: German cuisine
- kinds: sheet cake
- ingredients: confiture, glaze, buttercream, sponge cake, cookie

## DISH Q13100813
- name: Graton
- other names: {"lmo": "Graton"}
- countries: IT
- kinds: dish
