# Review batch names-029

## DISH Q17103609
- name: Medianoche
- description: sandwich consisting of roast pork, ham, mustard, Swiss cheese, and sweet pickles on medianoche bread
- countries: CU
- kinds: food, sandwich
- ingredients: medianoche, Swiss cheese, pickle, pork, ham, mustard
- has Wikipedia article: en

## DISH Q17103699
- name: Candy cane
- other names: {"zh": "拐杖糖"}
- description: cane-shaped stick candy
- countries: DE
- kinds: hard candy
- ingredients: sugar
- has Wikipedia article: en

## DISH Q1710389
- name: Hash brown
- other names: {"zh": "马铃薯饼"}
- description: dish
- countries: US
- kinds: type of food or dish, potato dish
- ingredients: potato
- has Wikipedia article: en, zh

## DISH Q17104228
- name: Vigorón
- description: Nicaraguan typical food
- countries: NI
- cuisines: Nicaraguan cuisine
- kinds: dish
- ingredients: chicharrón
- has Wikipedia article: en

## DISH Q17105567
- name: Sweet potato fries
- description: dish
- countries: (none)
- kinds: sweet potato dish
- ingredients: sweet potato
- has Wikipedia article: en

## DISH Q17105624
- name: Garlic ice cream
- other names: {"zh": "大蒜冰淇淋"}
- description: flavour of ice cream consisting mainly of vanilla, or honey, and cream as a base, to which garlic is added
- countries: (none)
- kinds: ice cream
- ingredients: garlic
- has Wikipedia article: en, zh

## DISH Q17107577
- name: Pipikaula
- description: Beef-based dish
- countries: (none)
- kinds: beef dish
- has Wikipedia article: en

## DISH Q17107651
- name: Koba
- other names: {"zh": "科巴"}
- description: confectionery sweet
- countries: MG
- kinds: dish, food, pastry
- ingredients: banana leaf, coconut, rice flour, peanut, sugar
- has Wikipedia article: en

## DISH Q17109441
- name: Ukodo
- description: yam and plantain dish of the Urhobo
- countries: NG
- kinds: food, dish
- ingredients: cooking banana, Dioscorea, vegetable, meat
- has Wikipedia article: en

## DISH Q17109463
- name: Usi
- other names: {"zh": "烏溪"}
- description: Nigerian foodstuff
- countries: NG
- kinds: food, dish
- ingredients: cassava root
- has Wikipedia article: en

## DISH Q17110181
- name: New Jersey sloppy joe
- description: double decker thin sliced rye bread sandwich made with one or more types of sliced deli meat (often ham) along with Swiss cheese, coleslaw, and Russian dressing
- countries: US
- kinds: sandwich
- ingredients: Russian dressing, Swiss cheese, rye bread, coleslaw, cold cut
- has Wikipedia article: en

## DISH Q17110849
- name: Kondowole
- description: Malawian cassava dish
- countries: (none)
- kinds: dish
- ingredients: cassava, water
- has Wikipedia article: en

## DISH Q17113207
- name: Carrot cake cookie
- description: baked good
- countries: (none)
- kinds: cookie
- ingredients: flour, sugar, carrot
- has Wikipedia article: en

## DISH Q17115908
- name: Bacon cake
- description: Dish made with bacon
- countries: (none)
- kinds: cake
- has Wikipedia article: en

## DISH Q17115910
- name: Shredded beef
- description: preparation of beef that features in various cuisines
- countries: (none)
- kinds: beef dish, shredded meat
- has Wikipedia article: en

## DISH Q17115947
- name: Doughwich
- countries: (none)
- kinds: sandwich
- has Wikipedia article: en

## DISH Q17116044
- name: Fudge cookie
- description: type of cookie
- countries: (none)
- kinds: cookie
- has Wikipedia article: en

## DISH Q17116069
- name: Grape ice cream
- other names: {"zh": "葡萄冰淇淋"}
- description: ice cream with natural or artificial grape flavoring
- countries: (none)
- kinds: ice cream, grape-based food
- ingredients: ice cream, grape
- has Wikipedia article: en, zh

## DISH Q17116096
- name: Hard candy
- other names: {"zh": "硬糖"}
- description: form of sugar candy
- countries: (none)
- kinds: sugar candy
- ingredients: syrup, caramel
- has Wikipedia article: en

## DISH Q17116102
- name: Holsum Bread
- description: American brand of packaged sliced white bread
- countries: US
- kinds: food, white bread
- has Wikipedia article: en

## DISH Q17116108
- name: Honey bun
- description: fried yeast pastry
- countries: US
- kinds: food, sweet roll
- ingredients: honey
- has Wikipedia article: en

## DISH Q17116114
- name: Horsebread
- description: type of bread
- countries: (none)
- kinds: food, bread
- ingredients: legume
- has Wikipedia article: en

## DISH Q17116189
- name: Kwacoco
- description: Cameroonian dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q17116267
- name: Lemon stick
- description: candy variety
- countries: (none)
- kinds: stick candy
- has Wikipedia article: en

## DISH Q17116283
- name: Limburger sandwich
- description: type of sandwich
- countries: (none)
- kinds: sandwich
- ingredients: Limburger
- has Wikipedia article: en

## DISH Q17116309
- name: Love Hearts
- description: confectioneries with embossed messages
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q17118710
- name: Tiger tail ice cream
- description: Ice cream flavor
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q17118853
- name: Oyster ice cream
- other names: {"zh": "牡蛎冰淇淋"}
- description: savory ice cream made from oysters
- countries: (none)
- kinds: ice cream, oyster dish
- has Wikipedia article: en, zh

## DISH Q17118912
- name: Pistachio ice cream
- description: ice cream flavor made with pistachio nuts or flavor
- countries: (none)
- kinds: ice cream flavor, ice cream
- ingredients: pistachio nut
- has Wikipedia article: en

## DISH Q17119210
- name: Rosolnyk
- countries: (none)
- kinds: food, soup
- ingredients: cucumber
- has Wikipedia article: en

## DISH Q17119263
- name: Smoked scallop
- description: scallops that have been smoked
- countries: (none)
- kinds: smoked meat, seafood dish
- ingredients: scallop
- has Wikipedia article: en

## DISH Q17119279
- name: Spaghetti taco
- description: taco variety
- countries: (none)
- kinds: dish, taco
- has Wikipedia article: en

## DISH Q17119288
- name: Stack cake
- description: layer cake from Appalachian cuisine
- countries: US
- kinds: layer cake
- ingredients: apple
- has Wikipedia article: en

## DISH Q17119302
- name: Sugar candy
- other names: {"zh": "糖製糖果"}
- description: candy whose primary ingredient is sugar
- countries: (none)
- kinds: candy
- ingredients: sugar
- has Wikipedia article: en

## DISH Q17119324
- name: Tiger tail donut
- description: dessert food
- countries: (none)
- kinds: doughnut
- has Wikipedia article: en

## DISH Q17119353
- name: West Indies salad
- description: variation of crab meat ceviche
- countries: (none)
- kinds: crab dish, raw fish dish
- has Wikipedia article: en

## DISH Q17122679
- name: Coburger Bratwurst
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q17137076
- name: Tompouce
- description: type of pastry in the Netherlands and Belgium
- countries: (none)
- kinds: mille-feuille
- ingredients: pastry cream, fondant, puff pastry
- has Wikipedia article: en

## DISH Q17142904
- name: Poppyseed muffin
- description: bread
- countries: (none)
- kinds: bread
- has Wikipedia article: en

## DISH Q17143425
- name: Katogo
- description: Ugandan breakfast dish
- countries: UG
- kinds: food, dish, human food
- ingredients: Matoke
- has Wikipedia article: en

## DISH Q1715200
- name: Pelt porridge
- description: Swabian staple dish of roasted flour
- countries: DE
- kinds: porridge
- ingredients: Triticum spelta
- has Wikipedia article: en

## DISH Q17156648
- name: Ay çöreği
- description: Turkish sweet bread, or "çörek".
- countries: (none)
- kinds: sweet roll, çörek

## DISH Q17162482
- name: Paigu niangao
- other names: {"zh": "排骨年糕"}
- description: dish from Shanghai consisting of fried pork chop and niangao (glutinous rice cake)
- countries: (none)
- kinds: pork dish
- has Wikipedia article: zh

## DISH Q17164012
- name: 撈起魚生
- countries: MY, SG
- kinds: raw fish
- has Wikipedia article: zh

## DISH Q17164276
- name: Juanfen
- other names: {"zh": "卷粉"}
- description: type of flat rice noodle in China
- countries: CN
- kinds: dish, Chinese noodles
- has Wikipedia article: en

## DISH Q17165588
- name: Finker (madret)
- other names: {"da": "Finker (madret)"}
- countries: DK
- cuisines: Danish cuisine
- kinds: dish
- ingredients: offal

## DISH Q17166373
- name: Mung bean paste pastry
- countries: (none)
- kinds: pastry, dish, marry girl cake

## DISH Q17173204
- name: 湯
- other names: {"ja": "湯"}
- countries: (none)
- kinds: soup

## DISH Q17173262
- name: Aftir oukessoul
- countries: DZ
- kinds: recipe, dish
- ingredients: legume, olive oil, Coriandrum sativum, vegetable, meat, pasta

## DISH Q17174348
- name: آضمين
- other names: {"ar": "آضمين"}
- countries: DZ
- cuisines: Berber (Amazigh) cuisine, Algerian cuisine
- kinds: dish

## DISH Q17174620
- name: Barak ainou
- countries: DZ
- kinds: goat meat dish

## DISH Q17175691
- name: Casse-croûte
- countries: (none)
- kinds: sandwich, meal

## DISH Q17190268
- name: El louza
- other names: {"fr": "El louza"}
- countries: DZ
- kinds: pastry

## DISH Q17190893
- name: Aomori ginger miso oden
- description: regional oden dish from Aomori Prefecture, Japan
- countries: JP
- kinds: oden
- ingredients: ginger, miso

## DISH Q17191020
- name: アカツキガユ
- other names: {"ja": "アカツキガユ"}
- countries: (none)

## DISH Q17192072
- name: Ariran Ramen
- other names: {"zh": "阿里郎拉麵"}
- countries: (none)
- kinds: ramen

## DISH Q17192558
- name: Candied angelica
- description: candied stems of angelica species
- countries: (none)
- kinds: wild food, confectionery
- ingredients: plant stem, sugar

## DISH Q17192593
- name: Andansū
- description: Okinawan dish
- countries: (none)
- kinds: miso
- ingredients: miso, lard

## DISH Q17193194
- name: Itawasa
- description: sliced kamaboko with wasabi
- countries: (none)
- kinds: dish
- ingredients: wasabi, kamaboko

## DISH Q17194099
- name: 宇佐飴
- other names: {"ja": "宇佐飴"}
- countries: (none)
- kinds: Miyagegashi, ame

## DISH Q171983
- name: Dhokla
- description: Indian vegetarian dish
- countries: IN
- cuisines: Gujarati cuisine
- kinds: dish
- ingredients: chickpea, coriander seed, ginger, mustard oil, sodium bicarbonate, chili pepper
- has Wikipedia article: en

## DISH Q1720857
- name: Kabsa
- other names: {"zh": "卡布沙"}
- description: Arab rice dish
- countries: SA
- kinds: food, rice dish
- ingredients: tomato, cardamom, onion, bay leaf, Black lime, nutmeg, cinnamon, meat, rice
- has Wikipedia article: en

## DISH Q1720986
- name: Kadu bouranee
- other names: {"zh": "酸奶南瓜"}
- description: Afghan and Turkish pumpkin dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en, zh

## DISH Q1721014
- name: Red curry
- other names: {"zh": "紅咖哩"}
- description: Thai dish consisting of red curry paste cooked in coconut milk with meat or tofu
- countries: TH
- kinds: dish, Thai curry
- ingredients: red curry paste, coconut milk
- has Wikipedia article: en, zh

## DISH Q17210625
- name: Takosen
- countries: (none)
- kinds: senbei

## DISH Q17210742
- name: 円山動物園白クマラーメン
- other names: {"ja": "円山動物園白クマラーメン"}
- countries: (none)
- kinds: instant noodles

## DISH Q17211275
- name: Shiomi manjū
- countries: JP
- kinds: manjū

## DISH Q17212805
- name: しぼり焼
- other names: {"ja": "しぼり焼"}
- countries: (none)
- kinds: senbei

## DISH Q17213511
- name: Funabashi sauce ramen
- countries: (none)
- kinds: ramen

## DISH Q17213562
- name: きりせんしょ
- other names: {"ja": "きりせんしょ"}
- countries: (none)
- kinds: wagashi

## DISH Q17214429
- name: 美濃加茂やきそば
- other names: {"ja": "美濃加茂やきそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q17215367
- name: Rokujō dōfu
- countries: (none)
- kinds: tofu, dried food

## DISH Q17215761
- name: Shirasu no okizuke
- countries: JP
- kinds: Okizuke
- ingredients: shirasu

## DISH Q17216600
- name: Kurobō
- other names: {"zh": "黑棒"}
- description: Japanese baked confectionery
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en, zh

## DISH Q17216826
- name: シロクマヌードル
- other names: {"ja": "シロクマヌードル"}
- countries: JP
- kinds: instant noodles

## DISH Q17216876
- name: Hakata udon
- countries: JP
- kinds: Japanese noodles, udon

## DISH Q17216893
- name: Shirohata-zushi
- description: style of sushi
- countries: (none)
- kinds: narezushi

## DISH Q17217665
- name: Kenkera
- countries: (none)
- kinds: higashi

## DISH Q17218215
- name: 興亞建國麵包
- countries: (none)
- kinds: bread

## DISH Q1721876
- name: Chocolate liquor
- other names: {"zh": "可可液"}
- description: pure cocoa mass in liquid, semi-liquid, solid or semi-solid form
- countries: (none)
- kinds: chocolate, intermediate good, food ingredient, food
- ingredients: cocoa bean
- has Wikipedia article: en, zh

## DISH Q17218908
- name: Tempura ramen
- description: ramen topped with tempura
- countries: (none)
- kinds: dish, ramen in Hokkaido
- ingredients: tempura

## DISH Q17219214
- name: Sujikon
- description: Japanese dish; Beef tendon and konnyaku
- countries: JP
- kinds: type of food or dish, nimono, beef dish
- ingredients: konnyaku, tendon as food

## DISH Q17219570
- name: Tougarashi miso
- description: chillipepper miso
- countries: JP
- kinds: miso, hot sauce

## DISH Q17220026
- name: White Gauramen
- countries: (none)
- kinds: ramen

## DISH Q1722090
- name: Calv steak Adlon
- countries: DE
- kinds: dish
- ingredients: potato, chicken egg, veal, Madeira sauce, scrambled eggs, shoestring potatoes, kidney

## DISH Q17221654
- name: Kozuyu
- other names: {"zh": "小汁"}
- countries: (none)
- kinds: shirumono, seafood dish

## DISH Q17222161
- name: Kazari-sushi
- countries: (none)
- kinds: sushi

## DISH Q17223469
- name: Korzh
- description: Ukrainian flatbread
- countries: UA
- kinds: flatbread

## DISH Q17224021
- name: Tōnyū nabe
- countries: (none)
- kinds: nabemono
- ingredients: dashi, soy milk

## DISH Q17224035
- name: Tofu steak
- countries: JP
- kinds: dish
- ingredients: tofu

## DISH Q17224172
- name: 中尾鍋
- other names: {"ja": "中尾鍋"}
- countries: (none)
- kinds: nabemono

## DISH Q17224202
- name: 片原饅頭
- other names: {"ja": "片原饅頭"}
- countries: (none)
- kinds: manjū

## DISH Q17224368
- name: おきつねバーガー
- other names: {"ja": "おきつねバーガー"}
- countries: JP

## DISH Q17225150
- name: Otaguri
- description: local cuisine; horse offal stew
- countries: (none)
- kinds: dish, meat dish, motsuni, offal dish

## DISH Q17225949
- name: Sasebo burger
- other names: {"zh": "佐世保漢堡"}
- countries: JP
- kinds: hamburger
- has Wikipedia article: zh

## DISH Q1722629
- name: Cold platter
- countries: (none)
- kinds: dish, platter

## DISH Q17226863
- name: Sanuki udon burger
- countries: JP
- kinds: sandwich, udon

## DISH Q17227781
- name: Ube ramen
- countries: (none)
- kinds: tonkotsu ramen

## DISH Q17227932
- name: 太田焼きそば
- other names: {"ja": "太田焼きそば"}
- countries: (none)
- kinds: Yakisoba

## DISH Q17228051
- name: オランダ煮
- other names: {"ja": "オランダ煮"}
- countries: JP
- kinds: dish

## DISH Q17228204
- name: がんす
- other names: {"ja": "がんす"}
- countries: JP
- kinds: gyokatsu

## DISH Q17228743
- name: 島田飴
- other names: {"ja": "島田飴"}
- countries: (none)
- kinds: ame

## DISH Q17228947
- name: 仙台麻婆炒麵
- countries: (none)
- kinds: Yakisoba

## DISH Q17229022
- name: Taiwan mazesoba
- other names: {"zh": "台灣乾拌麵"}
- description: Japanese dry noodle dish
- countries: JP
- kinds: ramen
- has Wikipedia article: en, zh

## DISH Q17230138
- name: ブリュレフレンチトースト
- other names: {"ja": "ブリュレフレンチトースト"}
- countries: (none)
- kinds: French toast

## DISH Q17230213
- name: Bolo
- other names: {"zh": "圆松饼"}
- countries: (none)
- kinds: Nanbangashi

## DISH Q17230219
- name: Pork tamago
- description: okinawa style pork and egg
- countries: JP
- kinds: pork dish, egg dish
- ingredients: egg as food, cold cut

## DISH Q17231508
- name: Cup yakisoba
- other names: {"zh": "杯裝日式炒麵"}
- description: instant noodle form of yakisoba
- countries: (none)
- kinds: Yakisoba, cup noodle
- has Wikipedia article: zh

## DISH Q17232463
- name: シュリンプ・スキャンピ
- other names: {"ja": "シュリンプ・スキャンピ"}
- countries: US
- kinds: shrimp dish

## DISH Q17232939
- name: 焼きチョコ
- other names: {"ja": "焼きチョコ"}
- countries: (none)
- kinds: chocolate

## DISH Q17238884
- name: Ame
- other names: {"zh": "糖膠"}
- description: Japanese confectionery
- countries: (none)
- kinds: confectionery
- has Wikipedia article: zh

## DISH Q17240129
- name: Kinugasadon
- countries: JP
- kinds: tamagodon, egg dish

## DISH Q17255569
- name: Haşhaşlı çörek
- description: Turkish "çörek" with poppy seeds.
- countries: TR
- kinds: food, çörek
- ingredients: poppy seed

## DISH Q1725983
- name: Rauchemaad
- other names: {"de": "Rauchemaad"}
- countries: (none)
- kinds: potato dish

## DISH Q1726195
- name: Syrniki
- other names: {"zh": "錫爾尼基"}
- description: fried cheese pancakes from Eastern cuisine
- countries: UA
- cuisines: Russian cuisine, Ukrainian cuisine, Belarusian cuisine
- kinds: dish, pancake
- ingredients: tvorog, chicken egg, flour
- has Wikipedia article: en, zh

## DISH Q17271258
- name: Paskalya çöreği
- description: Turkish easter sweet bun
- countries: (none)
- kinds: çörek

## DISH Q17271604
- name: Pilav
- description: Turkish style rice, bulgur or pasta dish
- countries: TR
- kinds: dish

## DISH Q1727306
- name: Schmeerbrei
- other names: {"de": "Schmeerbrei"}
- countries: (none)
- kinds: dish

## DISH Q17274349
- name: Asado con cuero
- description: Argentine beef dish
- countries: (none)
- kinds: asado, beef dish

## DISH Q1727696
- name: Klaushähnchen
- description: chicken-shaped pastry
- countries: DE
- kinds: pastry

## DISH Q17277332
- name: Crab in Padang sauce
- description: Indonesian seafood dish
- countries: ID
- kinds: food, crab dish
- ingredients: shallot, Kaffir Lime Leaf, turmeric rhizome, garlic, ginger, oyster sauce, ketchup, chili pepper, Brachyura, Cymbopogon citratus, onion
- has Wikipedia article: en

## DISH Q17277338
- name: Iga penyet
- description: Indonesian dish
- countries: ID
- kinds: food, beef dish
- ingredients: Indonesian bay leaf, shallot, turmeric rhizome, garlic, coriander seed, tomato, ginger, Aleurites moluccanus, Alpinia galanga, rib, Cymbopogon citratus, table salt, sugar
- has Wikipedia article: en

## DISH Q17278742
- name: Karides güveç
- description: A Turkish "güveç" dish made with shrimps or prawns.
- countries: (none)
- kinds: shrimp dish
- has Wikipedia article: en

## DISH Q17279856
- name: Fırın sütlaç
- description: oven-baked version of the Turkish rice pudding known as "sütlaç"
- countries: TR
- kinds: dish, dessert
- ingredients: white sugar, milk, rice

## DISH Q17280693
- name: Baccalà alla lucana
- description: christmas dish of cod and red peppers from Basilicata, Italy
- countries: IT
- kinds: fish dish
- ingredients: Peperone crusco, cod
- has Wikipedia article: en

## DISH Q1730287
- name: Schokolinse
- other names: {"de": "Schokolinse"}
- countries: (none)
- kinds: dragée
- ingredients: chocolate

## DISH Q17318793
- name: Mel dos Açores
- description: honey from the Azores
- countries: PT
- kinds: honey

## DISH Q173265
- name: Potato chip
- other names: {"zh": "马铃薯片"}
- description: deep-fried or baked thin slice of potato
- countries: (none)
- kinds: potato dish, food, snack, junk food, chip
- ingredients: potato, vegetable oil, condiment, spice, table salt
- has Wikipedia article: en, zh

## DISH Q17326924
- name: Weggli
- description: Swiss milk-based bread roll
- countries: CH
- kinds: bread roll
- ingredients: cow's milk

## DISH Q1734633
- name: Kartoffelschmarrn
- other names: {"de": "Kartoffelschmarrn"}
- countries: (none)
- kinds: potato dish

## DISH Q1735171
- name: Kaspressknödel
- countries: AT
- kinds: dish, knödel
- ingredients: caraway seeds, onion, peppercorn, grated cheese, white bread, egg as food, flour, butter, parsley, table salt, milk

## DISH Q17354914
- name: Salade périgourdine
- countries: (none)
- kinds: salad
- ingredients: salad

## DISH Q17355815
- name: Balık ekmek
- description: fried or grilled fish in a bread loaf
- countries: TR
- kinds: food, sandwich, dish, street food
- ingredients: fish as food, bread
- has Wikipedia article: en

## DISH Q1735816
- name: Katemeshi
- description: Japanese peasant food
- countries: (none)
- kinds: type of food or dish, peasant food, gohan
- has Wikipedia article: en

## DISH Q1735834
- name: Saure Rolle
- other names: {"de": "Saure Rolle"}
- countries: (none)
- kinds: dish

## DISH Q17372871
- name: Boyoz
- description: Turkish sephardic "çörek" or bun
- countries: TR
- kinds: food, çörek
- ingredients: flour
- has Wikipedia article: en

## DISH Q17373825
- name: Pandispanya
- description: Turkish cake
- countries: TR
- kinds: food, cake

## DISH Q1737564
- name: Kazunoko
- other names: {"zh": "青魚卵"}
- description: Japanese dish
- countries: (none)
- kinds: roe-based food, dried salted roe
- ingredients: ovary
- has Wikipedia article: en

## DISH Q1737607
- name: Schmandkuchen
- countries: (none)
- kinds: sheet cake, yeast cake

## DISH Q1737615
- name: Kaşar
- description: Turkish cheese
- countries: TR
- kinds: food, cheese
- ingredients: sheep milk

## DISH Q1737626
- name: Presnitz
- description: pastry from Trieste, Italy
- countries: IT
- kinds: pastry

## DISH Q1737699
- name: Kedgeree
- description: UK dish
- countries: GB, IN
- kinds: fish dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q1738767
- name: Kenkentjüch
- other names: {"de": "Kenkentjüch"}
- countries: (none)
- kinds: viennoiserie

## DISH Q1739802
- name: Cooked pig's head
- countries: AT, DE, CZ
- cuisines: Austrian cuisine, German cuisine, Czech cuisine
- kinds: meat dish
- ingredients: pork

## DISH Q17401352
- name: 수육국밥
- other names: {"ko": "수육국밥"}
- countries: (none)
- kinds: gukbap

## DISH Q17415166
- name: Gåsebryst
- countries: DK
- ingredients: whipped cream, marzipan, puff pastry, jam

## DISH Q1741570
- name: Linzer Augen
- description: Austrian cookie
- countries: AT
- kinds: cookie
- ingredients: almond, egg as food, flour, butter, cinnamon, sugar

## DISH Q1742211
- name: Kenkey
- description: Kenkey is a traditional Ghanaian fermented maize dish made from ground corn dough.
- countries: GH
- kinds: food, stuffed pasta
- ingredients: maize, table salt, drinking water
- has Wikipedia article: en

## DISH Q17425887
- name: Lotus seed paste pastry
- countries: (none)
- kinds: pastry, dish, marry girl cake

## DISH Q1743404
- name: Kirchtagssuppe
- other names: {"de": "Kirchtagssuppe"}
- countries: AT
- kinds: dish

## DISH Q17451766
- name: Sinjski arambaši
- description: Croatian meat dish
- countries: HR
- kinds: meat dish, sarma
- ingredients: cabbage, pork belly, beef

## DISH Q174539
- name: Double Gloucester cheese
- other names: {"zh": "格洛斯特芝士"}
- description: type of cheese originating from Gloucestershire, England
- countries: GB
- kinds: food, cow's-milk cheese, English cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q1746803
- name: Small pastry
- description: pastry category
- countries: (none)
- kinds: pastry

## DISH Q1747162
- name: Schinkentüte
- other names: {"de": "Schinkentüte"}
- countries: (none)
- kinds: dish

## DISH Q17482572
- name: Ufo (pizza)
- other names: {"da": "Ufo (pizza)"}
- countries: (none)
- kinds: dish

## DISH Q17485383
- name: Soparnik
- description: Dalmatian pie
- countries: HR
- kinds: dish
- has Wikipedia article: en

## DISH Q17492677
- name: Mugoyo
- description: Mashed sweet potatoes and beans
- countries: UG
- kinds: food, dish, human food
- ingredients: Sweet potato
- has Wikipedia article: en

## DISH Q1749682
- name: Hollandse Nieuwe
- description: raw herring soaked in a mild preserving liquid
- countries: (none)
- kinds: food, fish dish
- ingredients: Clupea harengus
- has Wikipedia article: en

## DISH Q17499197
- name: 油浸淡水魚
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q17499496
- name: 網油蒸三鯠
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q17499568
- name: 豆腐蒸淡水魚
- countries: (none)
- kinds: fish dish
- has Wikipedia article: zh

## DISH Q17499646
- name: Tea dessert
- other names: {"zh": "茶食"}
- description: food consumed while drinking tea
- countries: CN
- kinds: dessert
- has Wikipedia article: zh

## DISH Q1750077
- name: Krebsbutter
- other names: {"de": "Krebsbutter"}
- countries: FR
- kinds: food ingredient, sauce
- ingredients: crayfish, butter

## DISH Q17501980
- name: Nigori
- countries: (none)
- kinds: recipe, aspic

## DISH Q175123
- name: Kroppkaka
- description: Swedish potato dumpling
- countries: SE
- cuisines: Swedish cuisine
- kinds: potato-dough dumpling
- ingredients: potato
- has Wikipedia article: en

## DISH Q17520921
- name: Адкрыты пірог
- other names: {"be": "Адкрыты пірог"}
- countries: (none)
- kinds: pie
- ingredients: dough

## DISH Q1752442
- name: Schillerlocke
- other names: {"de": "Schillerlocke"}
- countries: DE
- kinds: dish

## DISH Q1753265
- name: Skordalia
- description: potato-based dish
- countries: GR
- kinds: dish, sauce, potato dish
- ingredients: garlic
- has Wikipedia article: en

## DISH Q1753513
- name: Kæst skata
- other names: {"de": "Kæst skata"}
- countries: IS
- cuisines: Icelandic cuisine
- kinds: fish dish
- ingredients: fermented fish

## DISH Q1753583
- name: Hefekranz
- other names: {"zh": "花环面包"}
- description: sweet bread from the Germanic region
- countries: (none)
- kinds: pastry
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q1754338
- name: Mbejú paraguayo
- description: comida tipica paraguaya
- countries: PY
- kinds: pancake
- has Wikipedia article: en

## DISH Q17553788
- name: Gochtial
- description: breton pastry
- countries: FR
- kinds: bread, brioche

## DISH Q1755668
- name: Taimen
- other names: {"zh": "鲷面"}
- description: Noodle cooked in sea bream broth
- countries: JP
- kinds: sōmen, fish dish
- ingredients: red seabream, sōmen
- has Wikipedia article: zh

## DISH Q175595
- name: Kaiseki
- other names: {"zh": "懷石料理"}
- description: traditional multi-course Japanese dinner
- countries: JP
- kinds: cuisine, Japanese cuisine, dish
- has Wikipedia article: en, zh

## DISH Q1756296
- name: Spaghettieis
- other names: {"zh": "義大利麵冰淇淋"}
- description: German ice cream dish
- countries: DE
- cuisines: German cuisine
- kinds: ice cream
- ingredients: Strawberry coulis
- has Wikipedia article: en, zh

## DISH Q1756465
- name: Sagon
- description: Indonesia traditional snack
- countries: ID
- kinds: food, snack
- ingredients: sago flour, coconut, egg as food, vanilla, table salt, sugar

## DISH Q1757352
- name: Soy yogurt
- description: yogurt prepared with soy milk-
- countries: (none)
- kinds: fermented food, imitation food, soy food
- ingredients: soy milk
- has Wikipedia article: en

## DISH Q1757401
- name: Svið
- other names: {"zh": "烤羊头"}
- description: Icelandic dish made from sheep's head
- countries: (none)
- kinds: lamb dish, dish
- ingredients: lamb meat
- has Wikipedia article: en, zh

## DISH Q17582679
- name: Bird's nest soup
- description: soup made from the saliva of the edible-nest swiftlet
- countries: (none)
- kinds: soup
- ingredients: edible bird's nest, broth
- has Wikipedia article: en

## DISH Q1758911
- name: Culatello di Zibello PDO
- other names: {"zh": "Culatello di Zibello DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: food product, meat product, prosciutto
- has Wikipedia article: en

## DISH Q17590922
- name: Pelau
- description: rice dish of the West Indies
- countries: DM, GP, TT
- kinds: dish
- ingredients: pigeon pea, coconut milk, sugar, meat, rice
- has Wikipedia article: en

## DISH Q17591252
- name: Pulpitos en su tinta
- other names: {"de": "Pulpitos en su tinta"}
- countries: (none)
- kinds: dish

## DISH Q1759217
- name: Stäerzelen
- description: Luxembourgish dumplings
- countries: (none)
- kinds: dish, dumpling
- ingredients: buckwheat flour

## DISH Q1759289
- name: Laddu
- description: Sphere shaped sweet originating from the Indian sub-continent
- countries: IN
- kinds: dessert, mithai
- ingredients: sugar
- has Wikipedia article: en

## DISH Q1760240
- name: Quatre mendiants
- countries: FR
- kinds: dish
- ingredients: hazelnut

## DISH Q1760470
- name: Tramezzino
- description: triangular Italian sandwich
- countries: IT
- kinds: sandwich, dish
- ingredients: bread
- has Wikipedia article: en

## DISH Q176063
- name: Currywurst
- other names: {"zh": "德國咖哩香腸"}
- description: fast food dish of German origin
- countries: DE
- kinds: fast food, dish
- ingredients: curry ketchup, curry powder, sausage
- has Wikipedia article: en, zh

## DISH Q17620066
- name: Acemita tocuyana
- countries: (none)
- kinds: rosquilla

## DISH Q176236
- name: Fiore Sardo PDO
- other names: {"zh": "Fiore Sardo DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, sheep milk cheese, Italian cheese
- ingredients: sheep milk

## DISH Q17623932
- name: Whole stuffed camel
- description: fictional dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1762398
- name: Mohnkuchen
- description: poppy seed dessert
- countries: (none)
- kinds: dessert
- ingredients: poppy seed

## DISH Q17627934
- name: Saumon à l'oseille
- countries: FR
- kinds: dish
- ingredients: salmon

## DISH Q17628717
- name: فطيرات
- other names: {"ar": "فطيرات"}
- countries: DZ
- kinds: cake
- ingredients: citron, egg as food, flour, butter, vanilla, sugar

## DISH Q17630576
- name: Focaccia messinese
- other names: {"it": "Focaccia messinese"}
- countries: IT
- cuisines: Sicilian cuisine
- kinds: dish

## DISH Q17630839
- name: Escabeche oriental
- description: Mexican fish dish
- countries: MX
- kinds: meal, chicken dish
- ingredients: peppercorn, escabeche, Coriandrum sativum, vinegar, table salt
- has Wikipedia article: en

## DISH Q17631444
- name: خبيزة المعدنوس
- other names: {"ar": "خبيزة المعدنوس"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish

## DISH Q17631593
- name: Kriegskartoffelbrot
- other names: {"fr": "Kriegskartoffelbrot"}
- countries: (none)
- kinds: potato dish

## DISH Q17632071
- name: Tripa mishki
- description: tripe dish
- countries: EC
- kinds: national dish, chunchullo
- ingredients: garlic, tripe, lard

## DISH Q17634293
- name: Miód kurpiowski
- description: Polish honey
- countries: PL
- kinds: honey

## DISH Q17634577
- name: Mahjouba
- description: Algerian food item
- countries: DZ
- kinds: flatbread, food
- ingredients: tomato, onion, semolina, flour
- has Wikipedia article: en

## DISH Q17635231
- name: مختر
- other names: {"arq": "مختر"}
- countries: (none)
- kinds: dish

## DISH Q17635661
- name: Nekkache
- countries: DZ
- kinds: human food, biscuit, Ka'ak

## DISH Q17635889
- name: Kak'ik
- description: Guatemalan turkey leg stew
- countries: GT
- kinds: soup, intangible cultural heritage, stew, poultry dish
- ingredients: turkey leg
- has Wikipedia article: en

## DISH Q17636964
- name: Pommé
- description: culinary tradition with apples and cider
- countries: FR
- kinds: culinary speciality, spread
- ingredients: apple

## DISH Q17637181
- name: Président
- countries: (none)
- kinds: cake
- ingredients: chocolate

## DISH Q17638083
- name: Tuiles aostoises
- other names: {"fr": "tuiles aostoises"}
- countries: IT
- kinds: dessert

## DISH Q17638841
- name: Saint-Feuillien
- other names: {"fr": "Saint-Feuillien"}
- countries: BE
- kinds: cheese
- ingredients: cow's milk

## DISH Q17639757
- name: تسطيرة
- other names: {"ar": "تسطيرة"}
- countries: TN
- kinds: dish
- ingredients: chili pepper, egg as food, tomato

## DISH Q17640050
- name: تيزميث
- other names: {"ar": "تيزميث"}
- countries: DZ
- cuisines: Algerian cuisine
- kinds: dish
- ingredients: barley flour, carob, olive oil

## DISH Q17640292
- name: Pasta Elena
- other names: {"it": "Pasta Elena"}
- countries: IT
- kinds: dessert
- ingredients: sponge cake

## DISH Q176436
- name: Zrazy
- description: meat roulade dish
- countries: RU, PL, UA, BY, LT
- cuisines: Russian cuisine, Polish cuisine, Ukrainian cuisine, Belarusian cuisine, Lithuanian cuisine
- kinds: main course, beef dish
- ingredients: mutton, beef, pork
- has Wikipedia article: en

## DISH Q17651691
- name: Puoti
- other names: {"it": "Puoti"}
- countries: IT
- kinds: dessert

## DISH Q17652279
- name: Seppie in zimino
- other names: {"it": "seppie in zimino"}
- description: dish
- countries: IT
- kinds: dish

## DISH Q17680151
- name: Eggplant Caviar
- description: Paste made from eggplant / aubergine / brinjal
- countries: IR
- kinds: dish, mash, food paste
- ingredients: eggplant

## DISH Q176927
- name: Neapolitan wafer
- description: a wafer and chocolate-cream sandwich biscuit, first made by Austrian company Manner in 1898
- countries: AT
- kinds: wafer
- ingredients: wafer cookie, hazelnut
- has Wikipedia article: en

## DISH Q1769523
- name: Fondant
- other names: {"zh": "翻糖"}
- description: a type of icing used to decorate cakes
- countries: (none)
- kinds: icing, confectionery, mixture
- ingredients: starch, sugar, glucose syrup, invert sugar
- has Wikipedia article: en, zh

## DISH Q177
- name: 比萨饼
- description: Italian universal popular dish with a flat dough-based base and toppings
- countries: IT
- cuisines: Italian cuisine
- kinds: type of food or dish, snack, finished good, baked good, human food, convenience food, Pizzas, casseroles
- ingredients: tomato sauce, bell pepper, baker's yeast, dough, oil, mozzarella, table salt, sugar, cheese
- has Wikipedia article: en, zh

## DISH Q177166
- name: King cake
- other names: {"zh": "国王饼"}
- description: a type of cake associated with Epiphany or Mardi Gras
- countries: CH, ES
- kinds: pastry, sweet bread
- ingredients: frangipane, dough
- has Wikipedia article: en, zh

## DISH Q1772090
- name: Nøkkelost
- description: Norwegian cheese
- countries: NO
- kinds: cheese, cow's-milk cheese, Norwegian cheese
- ingredients: cumin seed, cow's milk, clove, milk
- has Wikipedia article: en

## DISH Q1772368
- name: Vegetarisches Schnitzel
- other names: {"de": "vegetarisches Schnitzel"}
- countries: (none)
- kinds: dish

## DISH Q1774328
- name: Kliebensuppe
- other names: {"de": "Kliebensuppe"}
- countries: (none)
- kinds: Milk soup

## DISH Q17747125
- name: Dal dhokli
- description: Indian lentil dish
- countries: IN
- cuisines: Indian cuisine, Rajasthani cuisine
- kinds: dal
- ingredients: lentil, wheat flour
- has Wikipedia article: en

## DISH Q17747219
- name: Ansom chek
- countries: KH
- kinds: dessert
- has Wikipedia article: en

## DISH Q17747240
- name: Pleah sach ko
- description: Cambodian salad
- countries: KH
- kinds: salad, food
- has Wikipedia article: en

## DISH Q17750349
- name: Biffsnadder
- other names: {"nb": "biffsnadder"}
- countries: (none)
- kinds: dish
- ingredients: beef

## DISH Q17767877
- name: Queen Maud fromage
- description: Norwegian dessert
- countries: (none)
- kinds: pudding
- has Wikipedia article: en

## DISH Q17769231
- name: Eggehakk
- other names: {"nb": "Eggehakk"}
- countries: (none)
- kinds: dish

## DISH Q1776997
- name: Cozonac
- other names: {"zh": "科佐納茨"}
- description: sweet leavened bread, traditional in the Balkans
- countries: BG, MD, RO
- kinds: food, Easter bread
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q1777113
- name: Knieper
- countries: (none)
- kinds: dish

## DISH Q177727
- name: Morbier
- other names: {"zh": "莫爾比耶乾酪"}
- description: French cheese
- countries: FR
- kinds: French cheese, pressed uncooked cheese, farmstead cheese, industrial cheese, dairy cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q1777339
- name: Knockepott
- other names: {"de": "Knockepott"}
- countries: (none)
- kinds: dish

## DISH Q1779559
- name: Kololak
- countries: AM
- cuisines: Armenian cuisine
- kinds: dish, soup
- ingredients: lamb meat

## DISH Q177998
- name: Agar
- other names: {"zh": "洋菜"}
- description: thickening agent used in microbiology and food
- countries: (none)
- kinds: polysaccharide, food ingredient
- ingredients: agaropectin, agarose
- has Wikipedia article: en, zh

## DISH Q178
- name: Pasta
- other names: {"zh": "意式面食"}
- description: Italian food made from flour, eggs and water and shaped in different forms, usually cooked and served with a sauce
- countries: (none)
- kinds: dish, shelf-stable food, pasta and noodles
- ingredients: durum flour, wheat flour, egg as food, water
- has Wikipedia article: en, zh

## DISH Q1781099
- name: Surf and turf
- other names: {"zh": "海陸大餐"}
- description: U.S. dish of seafood (e.g. lobster) and red meat (e.g. beefsteak)
- countries: (none)
- kinds: seafood dish
- ingredients: red meat, seafood
- has Wikipedia article: en

## DISH Q1781865
- name: Konowata
- description: Japanese seafood
- countries: JP
- kinds: seafood dish, shiokara, sea cucumber as food
- ingredients: Holothuroidea
- has Wikipedia article: en

## DISH Q1784786
- name: Pisto
- description: Spanish dish
- countries: ES
- kinds: food, soup, dish
- ingredients: tomato, Cucurbita pepo subsp. pepo, Capsicum, olive oil, onion
- has Wikipedia article: en

## DISH Q1786572
- name: Sodd
- description: Norwegian meal
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1787022
- name: Crab soup
- description: German and French dish usually consumed during Lent
- countries: DE, FR
- kinds: dish, crab dish

## DISH Q1787956
- name: Krenfleisch
- other names: {"de": "Krenfleisch"}
- countries: (none)
- kinds: meat dish

## DISH Q1788872
- name: Cough drop
- other names: {"zh": "喉片"}
- description: medicated tablet
- countries: (none)
- kinds: candy
- has Wikipedia article: en, zh

## DISH Q178899
- name: Akvavit
- other names: {"zh": "阿夸维特"}
- description: flavored Scandinavian spirit
- countries: (none)
- kinds: schnapps
- has Wikipedia article: en, zh

## DISH Q1790280
- name: Krusta
- other names: {"de": "Krusta"}
- countries: (none)
- kinds: dish

## DISH Q1790741
- name: Krüstchen
- other names: {"de": "Krüstchen"}
- countries: (none)
- kinds: dish

## DISH Q1790835
- name: Cioccolato di Modica PGI
- other names: {"zh": "Cioccolato di Modica IGP"}
- description: Italian PGI chocolate
- countries: IT
- kinds: chocolate, food, confectionery
- ingredients: sugar, chocolate
- has Wikipedia article: en

## DISH Q1790839
- name: Pulla
- description: Finnish pastry
- countries: FI
- kinds: cardamom bread, sweet roll
- ingredients: cardamom, wheat flour, baker's yeast, egg as food, sugar
- has Wikipedia article: en

## DISH Q1791453
- name: Kulish
- description: dish from Belarusian and Ukrainian cuisine
- countries: BY, UA
- cuisines: Russian cuisine, Hungarian cuisine, Ukrainian cuisine, Belarusian cuisine
- kinds: dish, kasha
- ingredients: salo, groat, Allium, flour, Allium sativum, table salt, water

## DISH Q1791462
- name: Coulibiac
- description: Russian pie
- countries: RU
- kinds: pastry, pirog, fish dish
- ingredients: minced meat, fish as food
- has Wikipedia article: en

## DISH Q1791505
- name: Kullerpfirsich
- other names: {"de": "Kullerpfirsich"}
- countries: (none)
- kinds: dish

## DISH Q1795426
- name: Kasnudeln
- description: Austrian dumpling
- countries: (none)
- kinds: dumpling, stuffed pasta

## DISH Q1795457
- name: Käsefladen
- description: cheese tart
- countries: CH
- kinds: dish, wähe

## DISH Q1795470
- name: Cheese straw
- description: cheese-based dish
- countries: (none)
- kinds: viennoiserie, cheese stick, pastry
- has Wikipedia article: en

## DISH Q1795580
- name: Kedjenou
- description: spicy chicken stew from West Africa
- countries: CI
- kinds: food, chicken dish
- has Wikipedia article: en

## DISH Q1796292
- name: Königsberg marzipan
- description: Type of marzipan from Kaliningrad
- countries: (none)
- kinds: marzipan
- has Wikipedia article: en

## DISH Q1797415
- name: Küttiger carrot
- description: variety of carrot from Switzerland
- countries: (none)
- kinds: carrot, vegetable
- has Wikipedia article: en

## DISH Q1798180
- name: Magenbrot
- description: type of lebkuchen
- countries: (none)
- kinds: Christmas cookies, Christmas tradition
- ingredients: clove
- has Wikipedia article: en

## DISH Q1798420
- name: Snuten un Poten
- other names: {"de": "Snuten un Poten"}
- countries: (none)
- kinds: dish

## DISH Q17986779
- name: Djote
- description: Belgian dish with stomped potatoes, vegetables and small smoked ham cubes
- countries: (none)
- kinds: potée
- ingredients: lardon, vegetable, potato

## DISH Q17990295
- name: Kanpan
- other names: {"zh": "罐裝乾麵包"}
- countries: (none)
- kinds: type of food or dish, bread, emergency ration, preserved food
- ingredients: wheat flour

## DISH Q17992361
- name: Bryndzové pirohy
- description: dumplings filled with curd, boiled potatoes and onions
- countries: SK
- kinds: pierogi
- ingredients: Bryndza

## DISH Q17993009
- name: Japanese Air Self Defence Force yokan
- countries: (none)
- kinds: Yōkan

## DISH Q17993873
- name: Costrada de Alcalá
- description: typical dessert from the city of Alcalá de Henares
- countries: (none)
- kinds: dessert, food
- ingredients: corn starch, almond, egg yolk, flour, butter, vanilla, sugar, milk

## DISH Q17994521
- name: Suna tamago
- description: egg snack
- countries: JP
- kinds: boiled egg

## DISH Q17997299
- name: Cucur cake
- description: Indonesian traditional Betawi-Sundanese snack originated from western Java
- countries: BN, ID, MY, TH
- kinds: snack, confectionery, human food, food, traditional food
- ingredients: palm sugar, rice flour, wheat flour, cooking oil, vanilla
- has Wikipedia article: en

## DISH Q17997301
- name: Kue rangi
- description: Indonesian coconut waffle
- countries: ID
- cuisines: Indonesian cuisine
- kinds: human food, type of food or dish, dish, sweet dish
- ingredients: tapioca, coconut, palm sugar
- has Wikipedia article: en

## DISH Q17998371
- name: Asem-Asem Daging
- other names: {"id": "Asem-Asem Daging"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: Indonesian bay leaf, kecap, Alpinia galanga, Allium ascalonicum, beef, chili pepper, ginger, Cymbopogon citratus, Allium sativum, table salt, vegetable

## DISH Q17998502
- name: Ayam goreng Kalasan
- description: Indonesia fried chicken from Kalasan, Yogyakarta
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, fried chicken
- ingredients: Indonesian bay leaf, shallot, garlic, coriander seed, kecap manis, palm sugar, shrimp paste, chicken as food, coconut water, cooking oil, Alpinia galanga, chili pepper, table salt
- has Wikipedia article: en

## DISH Q1799855
- name: Fruit curd
- other names: {"zh": "水果凝乳"}
- description: dessert spread and topping
- countries: (none)
- kinds: spread, dessert with spoon, dessert sauce, fruit preserves
- ingredients: egg yolk, sugar
- has Wikipedia article: en, zh

## DISH Q17998552
- name: Babi panggang karo
- description: roasted pork dish from Karo, North Sumatra
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: kecap manis, pork, Citrus × aurantiifolia, Cymbopogon citratus, Allium sativum, table salt

## DISH Q17998681
- name: Bakmi Nyemek
- other names: {"id": "Bakmi Nyemek"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, bakmi
- ingredients: Allium ascalonicum, noodle, Brassica rapa subsp. chinensis, egg as food, Allium sativum, table salt

## DISH Q17998685
- name: Bakso Balungan
- description: Indonesian food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: granulated sugar, Aleurites moluccanus, scallion, cooking oil, beef, black pepper, Allium sativum

## DISH Q17998983
- name: Baroncong
- other names: {"id": "Baroncong"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, kue, type of food or dish, snack

## DISH Q17998988
- name: Barongko pisang
- description: Bugis traditional dish of banana mixed with sugar, eggs and coconut milk
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, dessert
- ingredients: Saba banana, banana leaf, coconut milk, egg as food, vanilla, table salt, sugar, banana

## DISH Q17999020
- name: Bassang
- other names: {"id": "Bassang"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food
- ingredients: wheat flour, table salt, sugar, maize

## DISH Q17999200
- name: Beberuk terong
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish
- ingredients: shallot, garlic, tomato, Asparagus bean, shrimp paste, Kaempferia galanga, chili pepper, table salt, sugar

## DISH Q17999715
- name: Bolu kemojo
- description: Riau green cake
- countries: ID
- kinds: cake
- ingredients: wheat flour, coconut milk, Pandanus amaryllifolius, egg as food, table salt, sugar, margarine

## DISH Q17999717
- name: Bolu kojo
- description: traditional food from Jambi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, confectionery, kue, traditional food, type of food or dish, cake, pastry, steamed bread
- ingredients: chicken egg, wheat flour, coconut milk, Pandanus amaryllifolius, table salt, sugar, margarine

## DISH Q17999853
- name: Botok Telur Asin
- other names: {"id": "Botok Telur Asin"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish

## DISH Q18001674
- name: Chipolata pudding
- description: type of pudding
- countries: (none)
- kinds: pudding, dessert

## DISH Q1800458
- name: Pommes Anna
- description: Layered potato casserole
- countries: FR
- cuisines: French cuisine
- kinds: potato dish
- ingredients: potato
- has Wikipedia article: en

## DISH Q18011767
- name: Brodo
- other names: {"nl": "brodo"}
- countries: (none)
- kinds: food, soup, broth

## DISH Q18012354
- name: Cauliflower soup
- description: soup containing cauliflower
- countries: (none)
- kinds: food, vegetable soup
- ingredients: Brassica oleracea var. botrytis

## DISH Q18012356
- name: Broccoli soup
- description: vegetable soup made primarily of broccoli
- countries: (none)
- kinds: food, vegetable soup
- ingredients: broccoli

## DISH Q1801946
- name: Rose petal jam
- countries: (none)
- kinds: flower jam

## DISH Q18020974
- name: Anfu ham
- other names: {"zh": "安福火腿"}
- description: Chinese dish from Anfu
- countries: (none)
- kinds: ham
- ingredients: pig
- has Wikipedia article: en, zh

## DISH Q18027552
- name: Rumpsteak Strindberg
- other names: {"de": "Rumpsteak Strindberg"}
- description: preparation variant for beef
- countries: (none)
- kinds: dish

## DISH Q18043321
- name: Kemalpaşa dessert
- description: Turkish dessert
- countries: TR
- kinds: dish, dessert
- has Wikipedia article: en

## DISH Q1805687
- name: Lao khao
- other names: {"zh": "老犒"}
- description: Thai distilled spirit
- countries: TH
- kinds: liquor
- has Wikipedia article: en

## DISH Q18061506
- name: Vizovické pečivo
- other names: {"cs": "vizovické pečivo"}
- countries: (none)
- kinds: pastry

## DISH Q1807598
- name: Lye roll
- description: bread product dipped in lye before baking to ensure a very brown crust
- countries: (none)
- kinds: baked good
- has Wikipedia article: en

## DISH Q1808216
- name: Boterkoek
- other names: {"nl": "boterkoek"}
- countries: (none)
- kinds: pastry

## DISH Q18086964
- name: Gorcumse Zoute Bollen
- other names: {"nl": "Gorcumse Zoute Bollen"}
- countries: (none)
- kinds: type of food or dish, cookie

## DISH Q18088945
- name: Koek
- other names: {"nl": "koek"}
- countries: (none)
- kinds: food, cookie

## DISH Q1809371
- name: Lahoh
- other names: {"zh": "拉霍赫"}
- description: spongy bread originated from Yemen
- countries: SO
- cuisines: Yemen, Israeli cuisine
- kinds: food, pancake
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q1810059
- name: Le Pitchou
- other names: {"de": "Le Pitchou"}
- countries: (none)
- kinds: dish

## DISH Q1810575
- name: Thieboudienne
- other names: {"zh": "西布吉安"}
- description: traditional dish from West Africa
- countries: SN
- kinds: culinary speciality, fish dish
- ingredients: tomato sauce, Oryza molida, vegetable, rice, fish
- has Wikipedia article: en, zh

## DISH Q1810638
- name: Flapjack
- other names: {"zh": "谷物棒"}
- description: sweet tray-baked oat bar made from rolled oats, butter, brown sugar, and golden syrup
- countries: GB
- kinds: food, cookie, snack bar
- ingredients: rolled oats
- has Wikipedia article: en

## DISH Q18111280
- name: Chunla
- description: Nepalese meat dish
- countries: NP
- kinds: meat dish
- has Wikipedia article: en

## DISH Q18111413
- name: Crab jujube
- description: Chinese dish
- countries: CN
- cuisines: Teochew cuisine
- kinds: dish, meatball
- has Wikipedia article: en

## DISH Q1811166
- name: Moczka
- description: Silesian Christmas Eve dish
- countries: PL
- kinds: dessert
- ingredients: prune, pryanik, hazelnut, dried fruit, ale, walnut, almond, raisin, sugar
- has Wikipedia article: en
