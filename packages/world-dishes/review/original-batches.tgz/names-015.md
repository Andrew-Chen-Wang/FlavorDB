# Review batch names-015

## DISH Q12019323
- name: Hašlerka
- other names: {"cs": "Hašlerka"}
- countries: (none)
- kinds: bonbon

## DISH Q12020911
- name: Huli-huli
- description: Hawaiian chicken dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q1202221
- name: Lox
- other names: {"zh": "渍鲑鱼"}
- description: dish consisting of a fillet of brined salmon
- countries: US
- cuisines: American Jewish cuisine
- kinds: salmon dish
- ingredients: cured salmon, salmon
- has Wikipedia article: en, zh

## DISH Q1202255
- name: Loco moco
- other names: {"zh": "夏威夷米饭汉堡"}
- description: Hawaiian dish
- countries: US
- kinds: dish, hamburger, rice dish, egg dish
- ingredients: pilaf
- has Wikipedia article: en, zh

## DISH Q12024336
- name: Jaša marú
- other names: {"cs": "Jaša marú"}
- countries: BT
- kinds: chicken dish, food
- ingredients: chicken as food, tomato

## DISH Q120266072
- name: Меживо
- other names: {"ru": "Меживо"}
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: appetizer, vegetable dish

## DISH Q120280461
- name: Ulaniv-style potatoes
- description: Ukrainian fried potato dish
- countries: (none)
- kinds: potato dish
- has Wikipedia article: en

## DISH Q12031817
- name: Kuba
- description: traditional Czech Christmas meal
- countries: CZ
- kinds: Christmas food, dish
- ingredients: groat, fungi

## DISH Q120333038
- name: McFiesta
- countries: (none)
- kinds: hamburger, product

## DISH Q12033864
- name: Lokša
- description: type of potato pancake
- countries: SK
- kinds: dish, potato dish
- ingredients: potato, flour, sodium chloride
- has Wikipedia article: en

## DISH Q12033904
- name: Lomnice Biscuits
- countries: (none)
- kinds: dessert, hardtack

## DISH Q12037401
- name: Miletínská modlitbička
- countries: (none)
- kinds: confectionery

## DISH Q120378681
- name: Ensopado de turu
- other names: {"pt": "ensopado de turu"}
- countries: (none)
- kinds: dish

## DISH Q1203893
- name: Kabayaki
- other names: {"zh": "蒲烧"}
- description: Japanese eel dish
- countries: JP
- kinds: teriyaki, fish dish
- ingredients: eel
- has Wikipedia article: en, zh

## DISH Q12038988
- name: Muvi
- description: food of nivkh people
- countries: RU
- kinds: dish, potato dish

## DISH Q120391804
- name: Fried chicken skin
- countries: (none)
- kinds: fried chicken
- ingredients: chicken skin

## DISH Q120394663
- name: Yangtang
- other names: {"zh": "羊汤"}
- description: Chinese mutton/lamb soup
- countries: (none)
- kinds: mutton soup
- has Wikipedia article: zh

## DISH Q120395550
- name: Salt and pepper chips
- description: British Chinese dish
- countries: (none)
- cuisines: British Chinese cuisine
- kinds: food, dish
- has Wikipedia article: en

## DISH Q120400795
- name: Papes Bretana
- other names: {"ca": "Papes Bretana"}
- countries: (none)
- kinds: fries

## DISH Q12040362
- name: Nakládaný hermelín
- countries: (none)
- kinds: cheese, dish

## DISH Q120404013
- name: Alfajores en Medina-Sidonia
- other names: {"es": "Alfajores en Medina-Sidonia"}
- description: designation of intangible heritage of Medina Sidonia, Spain
- countries: (none)
- kinds: confectionery

## DISH Q120404251
- name: Perol cordobés
- other names: {"es": "perol cordobés"}
- description: designation of intangible heritage of Córdoba, Spain
- countries: (none)
- kinds: dish

## DISH Q120422413
- name: 晒よし飴
- other names: {"ja": "晒よし飴"}
- countries: JP
- cuisines: Japanese cuisine
- kinds: Miyagegashi, type of food or dish
- ingredients: ame, rice flour, sugar

## DISH Q12044493
- name: Parisian salad
- countries: (none)
- kinds: salad

## DISH Q12045473
- name: Pischinger
- countries: (none)
- kinds: torte

## DISH Q12045578
- name: Beef brisket
- description: variation of cooking brisket
- countries: (none)
- kinds: meat, dish

## DISH Q1204605
- name: Char siu
- other names: {"zh": "叉烧"}
- description: popular style of Cantonese barbecued pork
- countries: CN
- cuisines: Cantonese cuisine
- kinds: food, pork dish
- ingredients: dark soy sauce, fermented bean curd, rice wine, five-spice powder, fortified wine, hoisin sauce, pork, honey
- has Wikipedia article: en, zh

## DISH Q120471689
- name: Cafriela
- countries: (none)
- kinds: chicken dish

## DISH Q12047663
- name: Pučálka
- other names: {"cs": "pučálka"}
- description: traditional Czech snack made from sprouted and roasted dried peas
- countries: (none)
- kinds: dish, food
- ingredients: Pisum sativum

## DISH Q120486465
- name: Polvorosa
- description: Cookie from Colombia and Venezuela
- countries: CO
- kinds: food, cookie, dessert, type of food or dish
- ingredients: cow's milk, corn starch, wheat flour, butter, sugar
- has Wikipedia article: en

## DISH Q12048787
- name: Rakvička
- description: traditional Czech desert
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q120493206
- name: Saraman curry
- description: Cambodian curry dish
- countries: KH
- kinds: beef curry
- ingredients: curry paste, coconut milk, beef
- has Wikipedia article: en

## DISH Q120495847
- name: Ebi chiri
- countries: (none)
- kinds: chili shrimp

## DISH Q120495866
- name: Ebi furai
- other names: {"zh": "日本炸蝦"}
- countries: JP
- kinds: fried shrimp

## DISH Q120499220
- name: Petit four
- description: Pastry of Italy
- countries: IT
- kinds: biscuit

## DISH Q12050379
- name: Russian ice cream
- description: type of ice cream sandwich
- countries: SU
- kinds: ice cream sandwich, Plombières

## DISH Q120512623
- name: BigBob Carne
- other names: {"pt-br": "BigBob Carne"}
- countries: (none)
- kinds: sandwich

## DISH Q12054972
- name: Smaženice
- countries: (none)
- kinds: dish
- ingredients: egg as food, fungi

## DISH Q1205609
- name: Hayashi rice
- other names: {"zh": "香雅饭"}
- description: Japanese rice dish
- countries: JP
- cuisines: yōshoku
- kinds: food, Japanese rice dish, beef dish
- ingredients: tomato sauce, onion, edible mushroom, beef, rice, red wine, demi-glace, cooked rice
- has Wikipedia article: en, zh

## DISH Q12056671
- name: Tortiglioni
- description: type of pasta
- countries: IT
- kinds: pasta
- has Wikipedia article: en

## DISH Q12058996
- name: Goma-ae
- description: Japanese side dish
- countries: JP
- kinds: aemono, vegetable dish
- ingredients: spinach, sesame seed
- has Wikipedia article: en

## DISH Q120598334
- name: Maghzi Halva
- countries: (none)
- kinds: halva

## DISH Q120599590
- name: Kuzhimandi
- description: Mandi dish variety of Kerala
- countries: (none)
- kinds: Mandi, dish

## DISH Q120600488
- name: Mingau de tapioca
- description: Brazilian dish
- countries: BR
- kinds: dish
- ingredients: tapioca

## DISH Q12061056
- name: Kulich
- other names: {"zh": "庫利奇"}
- description: Russian type of Easter bread
- countries: RU
- kinds: cake, Easter bread, pastry
- has Wikipedia article: en, zh

## DISH Q120640342
- name: Francillon-Salat
- other names: {"de": "Francillon-Salat"}
- countries: (none)
- kinds: salad

## DISH Q120648396
- name: Ħobż biż-żejt
- description: Maltese appetizer
- countries: MT
- kinds: dish

## DISH Q120648586
- name: Krupky
- description: ritual dish in Mostove village in Andrushivka hromada in Zhytomyr Oblast
- countries: UA
- kinds: porridge, dish, cuisine
- ingredients: millet, egg as food, flour, chicken

## DISH Q120669355
- name: Olio agrumato PAT
- other names: {"zh": "Olio agrumato PAT"}
- description: traditional Italian edible fat (PAT)
- countries: IT
- kinds: olive oil, edible fats and oils

## DISH Q120681710
- name: Tsuufuunabe
- description: Japanese hotpot of gout-prone foods
- countries: JP
- kinds: nabemono
- ingredients: ankimo, milt, oyster

## DISH Q120682642
- name: Conch fritter
- description: dish in Bahamian cuisine
- countries: BS
- cuisines: Bahamian cuisine
- kinds: fritter, dish
- ingredients: conch
- has Wikipedia article: en

## DISH Q12070251
- name: Sukuma wiki
- other names: {"zh": "燉宽叶羽衣甘蓝"}
- description: East African dish made with collard greens
- countries: (none)
- kinds: dish
- ingredients: Brassica oleracea var. viridis
- has Wikipedia article: en

## DISH Q120703855
- name: Yellowhammer cookie
- description: type of stuffed drop cookie
- countries: (none)
- kinds: food, cookie, Stuffed cookie
- ingredients: rolled oats, pecan nut, peanut butter, honey
- has Wikipedia article: en

## DISH Q12071938
- name: Vanilla ice cream
- other names: {"zh": "香草冰淇淋"}
- description: ice cream flavored with vanilla
- countries: (none)
- kinds: ice cream
- ingredients: vanilla extract, ice cream
- has Wikipedia article: en, zh

## DISH Q1207626
- name: Jelly bean
- other names: {"zh": "雷根糖"}
- description: small bean-shaped type of confectionery
- countries: US
- cuisines: cuisine of the United States
- kinds: gummy candy
- ingredients: sugar
- has Wikipedia article: en, zh

## DISH Q120766622
- name: Chu Jelly
- other names: {"zh": "丘丘膠"}
- description: material derived from Chuchus in The Legend of Zelda
- countries: (none)
- kinds: sweetmeat, object from The Legend of Zelda

## DISH Q1207732
- name: Cha siu bao
- other names: {"zh": "叉烧包"}
- description: Cantonese barbecue-pork-filled bun
- countries: CN
- cuisines: Chinese cuisine
- kinds: dim sum, dish, pork dish
- ingredients: pork
- has Wikipedia article: en, zh

## DISH Q120783890
- name: Bell castella
- countries: (none)
- kinds: castella

## DISH Q1208221
- name: Rolled oats
- other names: {"zh": "大燕麥片"}
- description: lightly processed whole-grain food made from oat
- countries: (none)
- kinds: oatmeal, cereal flakes, food
- ingredients: oats
- has Wikipedia article: en

## DISH Q120824242
- name: Katt Bafla
- description: food from Northern India
- countries: (none)
- cuisines: Rajasthani cuisine
- kinds: food, dish
- ingredients: wheat flour, jaggery, ghee
- has Wikipedia article: en

## DISH Q120829140
- name: Storceag la cuptor
- description: Fish soup typically served in the Danube Delta
- countries: RO
- kinds: soup, food
- ingredients: sour cream, whey, sturgeon

## DISH Q120831995
- name: Fedde del Cancelliere
- other names: {"de": "Fedde del Cancelliere"}
- countries: (none)
- kinds: sweet dish

## DISH Q120841934
- name: Ukanshin ryori
- other names: {"zh": "御冠船料理"}
- countries: (none)
- kinds: dish
- has Wikipedia article: zh

## DISH Q12084278
- name: Borscht with uszka
- countries: UA
- kinds: soup, borscht
- ingredients: dough, Allium, table salt, fungi, water

## DISH Q12085692
- name: Бурачинка
- other names: {"ru": "Бурачинка"}
- countries: (none)
- kinds: dish

## DISH Q120860928
- name: Mamakari
- description: pickled sardine
- countries: (none)
- kinds: pickled fish
- ingredients: Japanese Sardinella, vinegar

## DISH Q120867636
- name: Ryukyu gashi
- countries: (none)
- kinds: confectionery

## DISH Q120878037
- name: Kanpyo maki
- countries: JP
- kinds: norimaki
- ingredients: Kanpyō

## DISH Q120890674
- name: Bokkake
- description: food in Fukuoka prefecture
- countries: (none)
- kinds: neko manma, chicken dish

## DISH Q120890947
- name: Nanbanbeccho
- countries: (none)
- kinds: dish

## DISH Q120891123
- name: Gajitsuae
- countries: (none)
- kinds: dish

## DISH Q120892828
- name: Massini
- description: Uruguayan dessert
- countries: UY
- kinds: dessert
- ingredients: chicken egg, chantilly cream, sponge cake

## DISH Q120919679
- name: Duru-ten
- countries: (none)
- kinds: tempura
- ingredients: taimo

## DISH Q120919888
- name: Sawani-wan
- countries: (none)
- kinds: shirumono

## DISH Q120919958
- name: Bōri
- countries: (none)
- kinds: nimono
- ingredients: Colocasia esculenta

## DISH Q120920042
- name: Itokirimochi
- countries: JP
- kinds: mochi

## DISH Q120944378
- name: Oi-seon
- countries: (none)
- kinds: Seon

## DISH Q120961670
- name: Jam tart
- description: English tart variety
- countries: GB
- kinds: dessert, tart
- ingredients: jam
- has Wikipedia article: en

## DISH Q120968865
- name: Alta Badia
- description: Italian cheese
- countries: IT
- kinds: cheese

## DISH Q12097130
- name: Gorohlianyky
- description: Ukrainian pea fritters
- countries: (none)
- kinds: oladyi, dish
- has Wikipedia article: en

## DISH Q120972787
- name: Donut hole
- description: type of donut
- countries: US
- cuisines: cuisine of the United States
- kinds: doughnut
- has Wikipedia article: en

## DISH Q120973181
- name: Jangan mrica
- other names: {"jv": "Jangan mrica"}
- description: Indonesian cuisine from Rembang Regency
- countries: ID
- kinds: food
- ingredients: vegetable, shrimp paste, Allium ascalonicum, Averrhoa carambola, black pepper, Curcuma longa, Allium sativum, table salt

## DISH Q12097630
- name: Грэчневы суп
- other names: {"be-tarask": "грэчневы суп"}
- countries: RU, BY
- cuisines: Russian cuisine, Belarusian cuisine
- kinds: soup

## DISH Q121015594
- name: Sheqerpare
- description: Albanian confectionery
- countries: AL, XK
- kinds: human food

## DISH Q121027105
- name: Loaded fries
- description: potato dish
- countries: US
- cuisines: cuisine of the United States
- kinds: appetizer, side dish
- ingredients: sauce, fries, vegetable, meat, cheese
- has Wikipedia article: en

## DISH Q12103008
- name: Dushenyna
- description: Ukrainian dish
- countries: (none)
- kinds: dish

## DISH Q121037170
- name: Japanese milk bread
- other names: {"zh": "長條麵包"}
- description: Style of bread
- countries: JP
- kinds: pan loaf, yeast bread, bread
- ingredients: pastry flour
- has Wikipedia article: en, zh

## DISH Q12105883
- name: Zahušťovaná polévka
- other names: {"cs": "zahušťovaná polévka"}
- countries: (none)
- kinds: soup

## DISH Q12106077
- name: Zatiruha
- description: Eastern European soup
- countries: BY
- cuisines: Belarusian cuisine
- kinds: dish
- ingredients: buckwheat flour, rye flour, wheat flour, egg as food, starch
- has Wikipedia article: en

## DISH Q12107189
- name: Зубцы
- other names: {"ru": "зубцы"}
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: dish, plant-based food

## DISH Q121075973
- name: Braciola di capra di Siano PAT
- other names: {"zh": "Braciola di capra di Siano PAT"}
- description: traditional Italian meat product (PAT)
- countries: IT
- kinds: meat product, roulade

## DISH Q121076628
- name: Sabbath stew
- description: traditional Jewish dish consumed on Saturday
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q121085597
- name: Tiger's blood
- description: flavoring added to snow cones, shaved ice, etc. consisting of cherry, strawberry, and watermelon flavors
- countries: US
- cuisines: cuisine of the United States
- kinds: flavoring
- ingredients: coconut, watermelon, cherry
- has Wikipedia article: en

## DISH Q121089786
- name: Juk
- description: Korean rice porridge
- countries: (none)
- kinds: congee
- has Wikipedia article: en

## DISH Q12109320
- name: Кулага
- other names: {"ru": "кулага"}
- countries: (none)
- kinds: porridge

## DISH Q121096316
- name: Latteruolo PAT
- other names: {"zh": "Latteruolo PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: animal product, baked good, dessert with spoon
- ingredients: custard, egg as food, sugar

## DISH Q121115158
- name: Hash
- description: stew or gravy made of pork, offal and onions
- countries: (none)
- cuisines: cuisine of the Southern United States
- kinds: dish
- has Wikipedia article: en

## DISH Q1211297
- name: Salzgurke
- description: small cucumber pickled in brine
- countries: PL, UA, BY, RU, US, DE
- cuisines: Polish cuisine, Ukrainian cuisine, Belarusian cuisine, Russian cuisine, cuisine of the United States, German cuisine
- kinds: pickle, dish
- ingredients: cucumber, pickling broth

## DISH Q121133789
- name: Cantarella
- other names: {"it": "Cantarella"}
- countries: IT
- kinds: dessert

## DISH Q121140766
- name: Blonde chocolate
- description: form of chocolate made from caramelized cocoa butter
- countries: (none)
- kinds: chocolate, types of chocolate
- ingredients: cocoa butter
- has Wikipedia article: en

## DISH Q121157049
- name: Minestra imbottita PAT
- other names: {"zh": "Minestra imbottita PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- cuisines: Romagna cuisine
- kinds: Italian stuffed pasta, baked good
- ingredients: sfoglia
- has Wikipedia article: en

## DISH Q121157575
- name: Gazpacho de segadores
- other names: {"es": "gazpacho de segadores"}
- countries: ES
- cuisines: Spanish cuisine
- kinds: gazpacho, type of food or dish

## DISH Q121162872
- name: Zaramandoña
- other names: {"es": "zaramandoña"}
- countries: ES
- cuisines: cuisine of the province of Almería
- kinds: salad, type of food or dish

## DISH Q1211684
- name: Kolach
- other names: {"zh": "小圆面包"}
- description: small, usually sweet, type of pastry
- countries: CZ
- kinds: pastry
- has Wikipedia article: en, zh

## DISH Q12117602
- name: Лемишка
- other names: {"ru": "Лемишка"}
- countries: UA
- kinds: dish, porridge
- ingredients: buckwheat flour, butter

## DISH Q121224424
- name: Schnittkäse Dolomitenkönig PAT
- other names: {"zh": "Schnittkäse Dolomitenkönig PAT"}
- description: traditional Italian cheese (PAT)
- countries: IT
- kinds: cheese

## DISH Q121224535
- name: Caffè in forchetta
- other names: {"it": "Caffè in forchetta"}
- countries: (none)
- kinds: dessert

## DISH Q121257692
- name: Khavits
- description: Armenian sweetmeat
- countries: (none)
- kinds: sweetmeat
- ingredients: white sugar, butter

## DISH Q121295961
- name: Kams
- other names: {"sv": "kams"}
- countries: SE
- kinds: dish

## DISH Q121366296
- name: Fritanga
- description: Bolivian stew
- countries: BO
- kinds: dish

## DISH Q12137633
- name: Palianytsia
- other names: {"zh": "圓麵包"}
- description: Ukrainian round bread
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: bread
- ingredients: wheat flour
- has Wikipedia article: en, zh

## DISH Q121379458
- name: Evil jungle prince
- description: Thai-style dish originating in Hawaiʻi
- countries: US
- cuisines: Thai cuisine, Hawaiian cuisine
- kinds: dish
- ingredients: Kaffir Lime Leaf, Cymbopogon citratus leaf, cabbage, coconut milk, chili pepper, basil
- has Wikipedia article: en

## DISH Q121409949
- name: Otōshi
- description: tiny appetizer with cover charge in izakayas
- countries: JP
- kinds: appetizer, cover charge

## DISH Q121433974
- name: Supa barbetta
- other names: {"it": "Supa barbetta"}
- countries: IT
- kinds: first course

## DISH Q121438054
- name: Annie Rauwerda's perpetual stew
- description: 2023 event in Brooklyn, New York
- countries: (none)
- kinds: planned event, perpetual stew

## DISH Q121483583
- name: Biliaivka fish yushka
- description: soup, made from various types of fish
- countries: UA
- kinds: soup, ukha

## DISH Q121544620
- name: Pan de queso
- description: bread from Venezuela
- countries: VE
- kinds: bread

## DISH Q12156539
- name: Hamin
- description: stew in Jewish cuisine
- countries: (none)
- kinds: stew
- has Wikipedia article: en

## DISH Q12158729
- name: Суп квасолевий
- other names: {"uk": "Суп квасолевий"}
- countries: PL, UA
- kinds: soup
- ingredients: Phaseolus, Allium, table salt, potato, water, carrot

## DISH Q12159935
- name: Tarak
- description: fermented milk product
- countries: RU
- kinds: fermented milk product

## DISH Q121600417
- name: Mennonite bread
- description: a bread from Chihuahua, México
- countries: MX
- kinds: bread

## DISH Q121600797
- name: Gefüllter Schweinebauch
- other names: {"de": "Gefüllter Schweinebauch"}
- countries: (none)
- kinds: dish

## DISH Q121601792
- name: Gefüllte Schweinebrust
- other names: {"de": "Gefüllte Schweinebrust"}
- countries: (none)
- kinds: dish

## DISH Q12160988
- name: Тетеря (блюдо)
- other names: {"ru": "Тетеря (блюдо)"}
- countries: (none)
- kinds: porridge, dish

## DISH Q12162645
- name: Diacitrón
- other names: {"es": "Diacitrón"}
- countries: ES
- kinds: dessert

## DISH Q121632964
- name: Pasta seca
- other names: {"ca": "Pasta seca"}
- countries: (none)
- kinds: pasta

## DISH Q121686412
- name: Bread and dripping
- description: Hungarian sandwich with lard, onion slices, sweet paprika and salt
- countries: HU
- kinds: sandwich, bread dish
- ingredients: paprika, red onion, lard, onion, bread

## DISH Q121695915
- name: Brioche con gelato
- description: Italian dessert typical in Sicily
- countries: IT
- kinds: dessert, confectionery
- ingredients: brioscia, whipped cream, ice cream

## DISH Q1216990
- name: Trucha a la navarra
- other names: {"es": "Trucha a la navarra"}
- countries: (none)
- cuisines: cuisine of Navarre
- kinds: fish dish
- ingredients: Salmo trutta, jamón

## DISH Q1216999
- name: Porrusalda
- countries: ES, FR
- cuisines: Basque cuisine, cuisine of Navarre
- kinds: dish, stew
- ingredients: garlic, potato, onion, leek, carrot

## DISH Q12170274
- name: Cheer
- description: Dish of Ukrainian cuisine
- countries: UA
- kinds: dish
- ingredients: maize flour, milk

## DISH Q12172314
- name: Shpundra
- description: Ukrainian dish
- countries: UA
- kinds: dish

## DISH Q12172497
- name: Shulyky
- description: traditional Ukrainian dish
- countries: UA
- kinds: dish
- has Wikipedia article: en

## DISH Q121757100
- name: Cheese (Shirak)
- countries: AM
- kinds: cheese, dairy product

## DISH Q121788204
- name: Պահքի ուտեստը Գյումրիում
- other names: {"hy": "Պահքի ուտեստը Գյումրիում"}
- countries: AM
- kinds: dish

## DISH Q121788679
- name: Chinito
- other names: {"es": "chinito"}
- countries: (none)
- kinds: confectionery
- ingredients: bun, chocolate

## DISH Q121791577
- name: Chbâh es' Safra Khobza
- countries: (none)
- kinds: tajine

## DISH Q12179369
- name: روز جربي
- other names: {"ar": "روز جربي"}
- description: Tunisian dish
- countries: TN
- kinds: rice dish

## DISH Q121804925
- name: Suzhou-style mooncake
- other names: {"zh": "苏式月饼"}
- countries: (none)
- kinds: mooncake
- has Wikipedia article: zh

## DISH Q121811773
- name: Հացը հայ ժողովրդական հավատալիքներում
- other names: {"hy": "Հացը հայ ժողովրդական հավատալիքներում"}
- countries: AM
- kinds: bread

## DISH Q121832765
- name: Num pang
- description: Cambodian bread or sandwich
- countries: KH
- kinds: submarine sandwich
- ingredients: vegetable, meat
- has Wikipedia article: en

## DISH Q12184379
- name: البرعى
- other names: {"ar": "البرعى"}
- countries: (none)
- kinds: dish

## DISH Q1218450
- name: Lacón Gallego
- description: Spanish dried ham
- countries: ES
- cuisines: Galician cuisine
- kinds: pork, dish
- has Wikipedia article: en

## DISH Q121858197
- name: Prizren Noodles
- countries: XK
- kinds: Albanian cuisine, human food

## DISH Q121862998
- name: 鯨竜田揚げ
- other names: {"ja": "鯨竜田揚げ"}
- countries: JP
- kinds: tatsutaage
- ingredients: whale meat

## DISH Q12187758
- name: الرز الحامض
- other names: {"ar": "الرز الحامض"}
- countries: JO
- kinds: dish

## DISH Q12187786
- name: Al-rashoof
- description: Jordanian soup
- countries: JO
- kinds: type of food or dish, soup
- ingredients: green lentil, onion, jameed, yogurt

## DISH Q121878115
- name: Thattu dosa
- countries: IN
- kinds: dosa, food

## DISH Q121889426
- name: Torró de cacau
- other names: {"ca": "Torró de cacau"}
- countries: (none)
- kinds: turrón
- ingredients: peanut

## DISH Q121889462
- name: Turrones de maní
- countries: PH
- kinds: sweetmeat

## DISH Q12191243
- name: Gursan
- description: Saudi Arabian dish
- countries: SA
- kinds: dish

## DISH Q12191857
- name: كنافة حلبية
- other names: {"ar": "كنافة حلبية"}
- countries: (none)
- kinds: confectionery

## DISH Q121920223
- name: Ume suishō
- countries: JP
- kinds: sakana, fish dish
- ingredients: fish bone, umeboshi
- has Wikipedia article: en

## DISH Q12192208
- name: بطاطا مبطنة
- other names: {"ar": "بطاطا مبطنة"}
- countries: LY
- kinds: dish

## DISH Q12192991
- name: Meskouta Mouskoutchou
- description: cake from algiers
- countries: MA
- kinds: human food, pastry
- has Wikipedia article: en

## DISH Q12195766
- name: Bāṭarsh
- description: eggplant-based dish originating from Hama (Syria)
- countries: SY
- kinds: dish
- ingredients: tehina

## DISH Q12197801
- name: Barazek
- description: arabic sesame cookies
- countries: SY
- kinds: dessert, cookie
- ingredients: pistachio nut, Sesamum indicum, biscuit
- has Wikipedia article: en

## DISH Q12199101
- name: Boulaghmane
- description: West Saharan barley flour dish
- countries: (none)
- cuisines: Mauritania cuisine, Western Saharan cuisine
- kinds: Barley-based dishes
- has Wikipedia article: en

## DISH Q121994113
- name: T'beet
- other names: {"de": "T'beet"}
- countries: (none)
- kinds: dish

## DISH Q12200
- name: Crêpe
- other names: {"zh": "可丽饼"}
- description: type of very thin pancake
- countries: FR
- kinds: pancake, dish
- ingredients: cow's milk, wheat flour, egg as food, butter
- has Wikipedia article: en, zh

## DISH Q122017831
- name: Avellanate
- description: old Spanish recipe
- countries: ES
- kinds: dish

## DISH Q12203234
- name: Stuffed dates
- description: Heated dates filled with meat, mint, and parsley
- countries: (none)
- kinds: dish
- ingredients: date
- has Wikipedia article: en

## DISH Q122045403
- name: Palada Pradhaman
- description: sweet dish of Kerala
- countries: (none)
- kinds: Pradhaman, pudding
- ingredients: ghee, sugar, milk

## DISH Q12208569
- name: Halawet el Jibn
- description: traditional Syrian dessert
- countries: SY
- cuisines: Syrian cuisine
- kinds: dish
- has Wikipedia article: en

## DISH Q12208571
- name: Mawlid sweets
- description: Sweets from Egypt, used to celebrate the birth of great figures
- countries: EG
- kinds: dessert

## DISH Q12212000
- name: Daheen
- description: Iraqi dessert
- countries: IQ
- kinds: dessert
- ingredients: flour
- has Wikipedia article: en

## DISH Q12212197
- name: دولمة الباذنجان
- other names: {"ar": "دولمة الباذنجان"}
- countries: (none)
- kinds: dish

## DISH Q12213597
- name: رقاق بالعدس
- other names: {"ar": "رقاق بالعدس"}
- countries: (none)
- kinds: dish

## DISH Q12214836
- name: زيت الخريج
- other names: {"ar": "زيت الخريج"}
- countries: SY
- kinds: olive oil

## DISH Q122154
- name: Puffed rice cake
- other names: {"zh": "米饼"}
- description: food made of puffed rice
- countries: (none)
- kinds: rice cake, snack
- ingredients: puffed rice
- has Wikipedia article: en, zh

## DISH Q122167947
- name: Jawita
- other names: {"es": "jawita"}
- countries: (none)
- kinds: empanada

## DISH Q12218191
- name: Shakriyeh
- description: Levantine yogurt and lamb stew
- countries: (none)
- kinds: stew, human food
- ingredients: lamb meat, yogurt
- has Wikipedia article: en

## DISH Q12218486
- name: Sharba Libiya
- description: Libyan soup
- countries: LY
- kinds: soup
- ingredients: lamb meat

## DISH Q12219244
- name: Spinach soup
- description: type of soup
- countries: (none)
- kinds: food, soup, dish, type of food or dish
- ingredients: Spinacia oleracea
- has Wikipedia article: en

## DISH Q12220257
- name: Samoon
- description: type of bread
- countries: IQ
- kinds: white bread
- ingredients: yeast, flour, table salt, water
- has Wikipedia article: en

## DISH Q12220420
- name: Sayadieh
- description: Middle Eastern fish and rice dish
- countries: (none)
- kinds: fish dish, rice dish
- ingredients: onion, fish as food, baharat, rice
- has Wikipedia article: en

## DISH Q1222099
- name: Coca de San Juan
- description: Spanish cake
- countries: ES
- kinds: dessert, coca
- ingredients: pine nut, cherry

## DISH Q12221610
- name: Tbikha
- description: soup
- countries: DZ, TN
- kinds: soup

## DISH Q12221948
- name: طوربيد اللحم
- other names: {"ar": "طوربيد اللحم"}
- countries: (none)
- kinds: dish

## DISH Q122228524
- name: Babenda
- description: Burkinabe culinary specialty
- countries: BF
- kinds: dish, sauce, type of food or dish
- ingredients: Sumbala, chili pepper, Spinacia oleracea, oil, peanut, table salt, rice, fish

## DISH Q122237047
- name: Bhapa
- countries: (none)
- kinds: dish, type of food or dish

## DISH Q122237637
- name: Dhakai Biryani
- description: a variety of biryani from Dhaka
- countries: (none)
- kinds: biryani, dish
- ingredients: potato, rice

## DISH Q122237724
- name: Dhakai Beef Biryani
- description: a variety of beef biryani from Dhaka
- countries: (none)
- kinds: Dhakai Biryani, biryani
- ingredients: beef, potato, rice

## DISH Q122237762
- name: Dhakai Mutton Biryani
- description: variety of mutton biryani from Dhaka
- countries: (none)
- kinds: Dhakai Biryani
- ingredients: goat meat, rice

## DISH Q122241204
- name: Konbini Sweets
- other names: {"zh": "日本便利商店的甜點"}
- description: sweets served in Japanese convenience store
- countries: (none)
- kinds: confectionery
- has Wikipedia article: zh

## DISH Q122241480
- name: Gonza
- countries: JP
- kinds: nimono

## DISH Q122241559
- name: あご野焼き
- other names: {"ja": "あご野焼き"}
- countries: JP
- kinds: Chikuwa
- ingredients: Exocoetidae

## DISH Q12224442
- name: مراصيع
- other names: {"ar": "مراصيع"}
- countries: SA
- cuisines: Saudi Arabian cuisine
- kinds: cake, dish
- ingredients: oil, flour, sugar

## DISH Q12224780
- name: 'Arikah
- description: South Arabian dish
- countries: (none)
- kinds: dessert, food

## DISH Q122258938
- name: Danpuren
- description: Ogasawara cuisine; chicken soup with dumplings
- countries: (none)
- kinds: chicken and dumplings

## DISH Q12227158
- name: Christ's thorn honey
- countries: (none)
- kinds: honey, animal product
- ingredients: nectar

## DISH Q122292341
- name: 踊せんべい
- other names: {"ja": "踊せんべい"}
- countries: (none)
- kinds: higashi

## DISH Q122295640
- name: Tosamaki
- countries: (none)
- kinds: makizushi
- ingredients: Katsuo no tataki

## DISH Q12230290
- name: Hummus Fatteh
- description: A famous Levantine dish made of boiled chickpeas with garlic, topped with toasted or fried bread, and salted yogurt.
- countries: LB, SY
- kinds: dish, Fatteh

## DISH Q122305565
- name: 柿ようかん
- other names: {"ja": "柿ようかん"}
- countries: JP
- kinds: Yōkan

## DISH Q122307637
- name: Arzuman küftəsi
- other names: {"az": "Resept:Arzuman küftəsi"}
- countries: AZ
- cuisines: Azerbaijani cuisine
- kinds: food, dish

## DISH Q12230920
- name: Feteer meshaltet
- description: Type of Egyptian pastry
- countries: EG
- kinds: human food
- has Wikipedia article: en

## DISH Q122331596
- name: Mamakari zushi
- countries: (none)
- kinds: sushi
- ingredients: mamakari

## DISH Q122331690
- name: Sozurinabe
- countries: JP
- kinds: nabemono
- ingredients: beef

## DISH Q122331930
- name: Morro de porc
- other names: {"ca": "Morro de porc"}
- countries: (none)
- kinds: tapas

## DISH Q122332939
- name: にしんの山椒漬け
- other names: {"ja": "にしんの山椒漬け"}
- countries: (none)
- kinds: pickled fish
- ingredients: sansho pepper, herring as food

## DISH Q122332947
- name: いわしのだんご汁
- other names: {"ja": "いわしのだんご汁"}
- countries: (none)
- kinds: shirumono

## DISH Q12233354
- name: Galayet bandora
- description: Levantine dish of tomatoes
- countries: JO
- cuisines: Palestinian cuisine, Jordanian cuisine, Levantine cuisine
- kinds: tomato dish, dish
- ingredients: tomato, onion, chili pepper, olive oil, table salt
- has Wikipedia article: en

## DISH Q122335037
- name: Herazushi
- countries: (none)
- kinds: sushi, fish dish, dish

## DISH Q1223352
- name: Monte Veronese PDO
- other names: {"zh": "Monte Veronese DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, cow's-milk cheese, pressed half-cooked cheese, Italian cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q12234417
- name: Kibbeh labaniyeh
- description: dish of Levantine cuisine
- countries: PS
- cuisines: Levantine cuisine, Palestinian cuisine
- kinds: dish
- ingredients: leben, kibbeh, tarragon

## DISH Q122354930
- name: すもも漬
- other names: {"ja": "すもも漬"}
- countries: JP
- kinds: dagashi

## DISH Q122354953
- name: Shima sōmen
- countries: JP
- kinds: sōmen, Japanese noodles

## DISH Q12236278
- name: Knafeh Nabulsiyeh
- countries: (none)
- kinds: knafeh, dessert

## DISH Q122362951
- name: Mukisoba
- countries: (none)
- kinds: buckwheat porridge, dish
- ingredients: buckwheat seed

## DISH Q12236379
- name: Kawareʾ
- description: Egyptian dish made of slow-cooked cow's trotters
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q122370317
- name: Tanuki cake
- countries: (none)
- kinds: cake

## DISH Q122370327
- name: おでんぶ
- other names: {"ja": "おでんぶ"}
- countries: JP
- kinds: dish

## DISH Q12237734
- name: Layali lubnan
- description: dessert
- countries: LB
- kinds: dessert
- ingredients: pistachio nut, semolina, pudding
- has Wikipedia article: en

## DISH Q12238558
- name: Mebakbeka
- countries: LY
- kinds: food, dish
- ingredients: sauce, legume, meat, pasta

## DISH Q122389490
- name: Turrón de vino
- description: dessert of Chilean gastronomy
- countries: CL
- kinds: dessert
- ingredients: egg white, walnut, sugar, red wine

## DISH Q122411411
- name: たらし焼き
- other names: {"ja": "たらし焼き"}
- countries: JP
- kinds: dish

## DISH Q12241516
- name: مخلوطة
- other names: {"ar": "مخلوطة"}
- description: Levantine dish with chickpeas and broad beans
- countries: SA, PS
- cuisines: Arab cuisine, Levantine cuisine, Palestinian cuisine
- kinds: dish, eggplant dish
- ingredients: broad bean, lentil, cumin seed, olive oil, table salt

## DISH Q122417599
- name: Njapche
- other names: {"fr": "Njapche"}
- countries: CM
- kinds: dish

## DISH Q122417689
- name: Vapora
- description: Chilean soup
- countries: CL
- kinds: soup, type of food or dish

## DISH Q12243625
- name: Matlou
- other names: {"zh": "荷布茲"}
- description: type of leavened bread made in Maghreb
- countries: DZ
- kinds: bread, human food
- ingredients: semolina, yeast
- has Wikipedia article: en

## DISH Q12244460
- name: Mafroukeh
- description: Lebanese dessert
- countries: LB
- kinds: dessert, type of food or dish

## DISH Q1224461
- name: Valle d'Aosta Fromadzo PDO
- other names: {"zh": "Valle d'Aosta Fromadzo DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, cow's-milk cheese, Italian cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q12244832
- name: Negresco pasta
- countries: (none)
- kinds: dish, white sauce

## DISH Q122451068
- name: Kutsuzoko no nitsuke
- description: Japanese simmered sole dish
- countries: (none)
- kinds: nimono, fish dish, dish
- ingredients: Cynoglossidae

## DISH Q122453617
- name: Beggar's Purse
- description: Stuffed Crêpe
- countries: (none)
- kinds: dish

## DISH Q122514382
- name: 白味噌雑煮
- other names: {"ja": "白味噌雑煮"}
- countries: JP
- kinds: zōni

## DISH Q122528692
- name: 龍ケ崎コロッケ
- other names: {"ja": "龍ケ崎コロッケ"}
- countries: (none)
- kinds: korokke

## DISH Q1225577
- name: Dillkartoffeln
- other names: {"de": "Dillkartoffeln"}
- description: potato dish
- countries: (none)
- kinds: potato dish

## DISH Q12259249
- name: Hormigo
- description: Basque dish
- countries: ES
- kinds: dish
- ingredients: beet, flour

## DISH Q122599104
- name: Вырезка по-будапештски
- other names: {"ru": "вырезка по-будапештски"}
- countries: HU
- cuisines: Hungarian cuisine
- kinds: dish
- ingredients: beef

## DISH Q122609155
- name: Pucacapa
- other names: {"es": "pucacapa"}
- description: Bolivian typical food
- countries: (none)
- kinds: empanada

## DISH Q12261332
- name: Carolina
- description: typical pastry of Vitoria, Spain
- countries: ES
- kinds: dessert, meal
- has Wikipedia article: en

## DISH Q122632985
- name: Amok
- description: Cambodian steamed curry
- countries: KH
- kinds: steamed curry

## DISH Q12264276
- name: Palatschinke
- description: type of pancake
- countries: (none)
- kinds: food, pancake
- ingredients: egg as food, flour, milk
- has Wikipedia article: en

## DISH Q122644102
- name: Macho Camacho
- description: Bolivian spicy dish
- countries: BO
- kinds: dish

## DISH Q122650685
- name: Koi pla
- description: Thai dish
- countries: (none)
- kinds: dish

## DISH Q1226539
- name: Dinkelbread
- countries: (none)
- kinds: bread
- ingredients: Triticum spelta
- has Wikipedia article: en

## DISH Q122659569
- name: Koffiekoek
- other names: {"nl": "koffiekoek"}
- countries: BE
- kinds: pastry

## DISH Q122662498
- name: Sucre à la crème
- description: Canadian confectionery
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q1226651
- name: Wafer cookie
- other names: {"zh": "威化"}
- description: thin type of biscuit
- countries: CO, CZ, DE, ES, IT, LT, MX, PL, SK
- kinds: cookie, food, biscuit, unleavened bread
- ingredients: azymes
- has Wikipedia article: en

## DISH Q122667149
- name: Siu mei rice
- countries: CN
- cuisines: Cantonese cuisine
- kinds: dish
- ingredients: siu mei, cooked rice

## DISH Q122676349
- name: にら豚
- other names: {"ja": "にら豚"}
- countries: JP
- kinds: stir frying, dish
- ingredients: pork, Allium tuberosum

## DISH Q122676511
- name: 盆菓子
- other names: {"ja": "盆菓子"}
- countries: JP
- kinds: confectionery, Sacred food as offering

## DISH Q122677946
- name: Ленивые щи
- other names: {"ru": "Ленивые щи"}
- countries: RU
- cuisines: Russian cuisine
- kinds: shchi, dish

## DISH Q12268392
- name: Txintxorta
- other names: {"eu": "Txintxorta"}
- countries: (none)
- kinds: dessert
- ingredients: cinnamon, sugar

## DISH Q122696086
- name: Salame matto
- other names: {"it": "salame matto"}
- countries: IT
- kinds: dish
- ingredients: egg as food, cheese, bread

## DISH Q12271168
- name: Chomlek
- description: Macedonian stew
- countries: (none)
- kinds: stew
- ingredients: veal

## DISH Q1227144
- name: Intxaursaltsa
- description: Basque dessert
- countries: ES, FR
- cuisines: Basque cuisine
- kinds: dish, dessert, custard
- ingredients: cow's milk, cinnamon, cream, nut, sugar
- has Wikipedia article: en

## DISH Q12273417
- name: Bob chorba
- other names: {"zh": "豆子湯"}
- description: Bulgarian bean soup
- countries: BG
- kinds: food, soup
- has Wikipedia article: en

## DISH Q122746645
- name: Ingenting
- other names: {"da": "Ingenting"}
- countries: DK
- kinds: cookie

## DISH Q12275182
- name: Abbey of Westmalle
- description: cheese
- countries: BE
- kinds: cheese

## DISH Q122759178
- name: Pichón de Cliza
- description: dish in Bolivia
- countries: BO
- kinds: dish

## DISH Q122762284
- name: 근다르
- other names: {"ko": "근다르"}
- countries: (none)
- kinds: dish

## DISH Q122780671
- name: Drusenzelte
- description: pastry
- countries: (none)
- kinds: pastry

## DISH Q122780717
- name: Haslikuchen
- description: cake
- countries: (none)
- kinds: cake

## DISH Q122780744
- name: Pain aux noix
- description: bread
- countries: (none)
- kinds: bread

## DISH Q122782077
- name: Kampot fish sauce
- description: Cambodian variety of fish sauce
- countries: KH
- kinds: fish sauce
- has Wikipedia article: en

## DISH Q1227853
- name: Tomme des Pyrénées
- other names: {"zh": "比利牛斯芝士"}
- description: French cheese
- countries: FR
- kinds: French cheese, pressed uncooked cheese, cow's-milk cheese, industrial cheese, dairy cheese
- ingredients: cow's milk, sheep milk, goat milk
- has Wikipedia article: en, zh

## DISH Q122790013
- name: きゃらぶき
- other names: {"ja": "きゃらぶき"}
- countries: (none)
- kinds: Tsukudani

## DISH Q122790091
- name: もばらーめん
- other names: {"ja": "もばらーめん"}
- countries: (none)
- kinds: ramen

## DISH Q122790153
- name: Kujirajiru
- countries: (none)
- kinds: shirumono
- ingredients: whale meat

## DISH Q12279155
- name: Drob sarma
- description: dish
- countries: (none)
- kinds: offal dish, dish

## DISH Q12279211
- name: Дунавия
- other names: {"bg": "Дунавия"}
- countries: BG
- kinds: cheese, dish, Balkan cuisine, sirene, course
- ingredients: cow's milk

## DISH Q122792121
- name: 小豆雑煮
- other names: {"ja": "小豆雑煮"}
- countries: (none)
- kinds: zōni

## DISH Q122808444
- name: Chicken Mayo Rice
- description: Korean food
- countries: (none)
- kinds: rice dish, deopbap, chicken dish

## DISH Q122808989
- name: Stuffed arepa
- description: Typical food from Colombia
- countries: CO
- kinds: arepa, type of food or dish
- ingredients: maize flour, shredded meat, Colombian cheeses, chicharrón, guiso, ham, table salt, vegetable

## DISH Q122809709
- name: Mané pelado
- description: Brazilian shredded yuca cake
- countries: BR
- kinds: food, cake
- ingredients: coconut, cassava, cheese
- has Wikipedia article: en

## DISH Q122811070
- name: Vacherin du Haut-Doubs
- other names: {"de": "Vacherin du Haut-Doubs"}
- countries: FR
- kinds: French cheese, cow's-milk cheese
- ingredients: cow's milk

## DISH Q122818225
- name: Elanchi
- description: snack food of Kerala
- countries: IN
- kinds: snack

## DISH Q122829893
- name: Abak Soup
- countries: NG
- cuisines: Nigeria
- kinds: dish, human food
- ingredients: Palm fruit, Peppered Ponmo, Periwinkles, onion, crayfish, salt, meat, fish

## DISH Q122842209
- name: Korokke soba
- description: food
- countries: JP
- kinds: noodle dish, dish
- ingredients: korokke, soba

## DISH Q122842234
- name: Arroz con dulce
- description: Puerto Rican dessert
- countries: PR
- kinds: dish

## DISH Q122851719
- name: Schnellklops
- other names: {"de": "Schnellklops"}
- countries: (none)
- kinds: dish
- ingredients: cream sauce, beef

## DISH Q122851988
- name: Mariah's Cookies
- description: Chain of Cookie shop
- countries: (none)
- kinds: cookie

## DISH Q12287205
- name: Mish-mash
- description: Bulgarian vegetable dish
- countries: BG
- kinds: dish
- ingredients: sirene, egg as food, vegetable
- has Wikipedia article: en

## DISH Q122877681
- name: Ho mok
- description: Thai dish
- countries: (none)
- kinds: steamed curry

## DISH Q122890669
- name: Biscottini di Novara
- countries: (none)
- kinds: baking, cookie
- ingredients: sodium bicarbonate, flour, egg, vanilla, sugar

## DISH Q12289076
- name: Обреден хляб
- other names: {"bg": "Обреден хляб"}
- countries: (none)
- kinds: bread, ritual object

## DISH Q122898181
- name: Samlor prahal
- description: Cambodian soup
- countries: KH
- kinds: soup
- ingredients: chicken stock, Cymbopogon, fish stock, freshwater fish, kroeung, herb, vegetable
- has Wikipedia article: en

## DISH Q12290687
- name: Пиле с ориз
- other names: {"bg": "Пиле с ориз"}
- countries: (none)
- kinds: dish

## DISH Q12290688
- name: Пиле със зеле
- other names: {"bg": "Пиле със зеле"}
- countries: (none)
- kinds: dish

## DISH Q122915710
- name: Aceitunas de Campo Real
- countries: ES
- kinds: food

## DISH Q122917163
- name: Homemade bread
- countries: (none)
- kinds: bread

## DISH Q12291791
- name: Пълнен шаран
- other names: {"bg": "Пълнен шаран"}
- countries: (none)
- kinds: dish

## DISH Q122921187
- name: Zwiebelbrot
- other names: {"de": "Zwiebelbrot"}
- description: Onion bread, onion bun
- countries: (none)
- kinds: bread

## DISH Q12292267
- name: Редена салата
- other names: {"bg": "Редена салата"}
- countries: BG
- kinds: salad

## DISH Q122925646
- name: Carne de la Sierra de Guadarrama
- countries: ES
- kinds: veal, protected geographical indication, food

## DISH Q12293376
- name: Свинско с ориз
- other names: {"bg": "Свинско с ориз"}
- countries: (none)
- kinds: dish

## DISH Q12293377
- name: Свинско със зеле
- other names: {"bg": "Свинско със зеле"}
- countries: (none)
- kinds: dish

## DISH Q12293790
- name: Simid
- description: Bread product from Bulgaria
- countries: BG
- kinds: simit, type of food or dish
- ingredients: chickpea

## DISH Q122938110
- name: Нудлі
- other names: {"uk": "Нудлі"}
- countries: (none)
- kinds: dish
- ingredients: dough, potato

## DISH Q122940800
- name: ばら寿司 (徳島県)
- other names: {"ja": "ばら寿司 (徳島県)"}
- countries: (none)
- kinds: chirashizushi, dish

## DISH Q122948159
- name: Stuffed pineapple
- countries: (none)
- kinds: dish

## DISH Q122948483
- name: Okpehe Rice
- description: Nigerian food
- countries: NG
- kinds: food
- ingredients: iru, onion, oil, table salt, meat, rice, fish

## DISH Q122956346
- name: Meascia
- countries: IT
- kinds: dessert

## DISH Q122957244
- name: Egg fried rice
- other names: {"zh": "蛋炒飯"}
- countries: (none)
- kinds: fried rice, dish
- ingredients: egg as food, rice
- has Wikipedia article: en, zh

## DISH Q12295770
- name: Meatball soup
- description: Type of soup made using meatballs
- countries: (none)
- kinds: food, soup
- ingredients: meatball
- has Wikipedia article: en

## DISH Q122958910
- name: Bizcocho de Moya
- description: Pastry product from the Canary Islands, Spain
- countries: ES
- kinds: pastry

## DISH Q122960549
- name: Lechon
- description: suckling pig in Spanish- and Portuguese-speaking regions
- countries: ES, PT
- kinds: pork dish
- ingredients: suckling pig
