# Review batch names-042

## DISH Q3945798
- name: Salsiccia di Calabria PDO
- other names: {"zh": "Salsiccia di Calabria DOP"}
- description: Italian PDO meat product
- countries: IT
- kinds: meat product, salume, dry sausage

## DISH Q3948086
- name: Sancochado
- countries: PE
- kinds: meal, soup, cocido

## DISH Q3948365
- name: Sangeli
- other names: {"it": "Sangeli"}
- countries: IT
- kinds: pork dish, blood sausage

## DISH Q3948384
- name: Sangrecita
- description: Peruvian dish, made of chicken blood
- countries: PE
- kinds: dish
- ingredients: blood as food
- has Wikipedia article: en

## DISH Q3948425
- name: Sanguinaccio dolce
- other names: {"zh": "豬血巧克力糊"}
- description: Italian dessert made from pig's blood
- countries: IT
- kinds: dessert with spoon
- has Wikipedia article: en

## DISH Q3950514
- name: Sardella
- description: Calabrian sardine dish
- countries: IT
- kinds: fish dish
- ingredients: sardine

## DISH Q3950519
- name: Sardenaira
- description: type of focaccia from Sanremo, Italy
- countries: IT
- kinds: dish, focaccia
- ingredients: garlic, tomato sauce, olive, anchovy, Origanum vulgare, flour
- has Wikipedia article: en

## DISH Q3950598
- name: Sartù di riso
- description: typical dish of Naples
- countries: IT
- kinds: dish
- ingredients: pea, meatball, smoked Provola, tomato sauce, liver as food, salami, sausage, egg as food, rice
- has Wikipedia article: en

## DISH Q3950633
- name: Sasanello gravinese
- other names: {"it": "Sasanello gravinese"}
- countries: IT
- kinds: dessert

## DISH Q3951172
- name: Savōr
- other names: {"eml": "Savōr"}
- countries: IT
- kinds: dessert

## DISH Q3951313
- name: Sbrisolona
- countries: IT
- kinds: cake

## DISH Q3951371
- name: Scagliozzi
- countries: (none)
- kinds: dish

## DISH Q3951693
- name: Scarpinocc
- description: typical dish from Lombardy
- countries: IT
- kinds: pasta

## DISH Q3951711
- name: Scarsella orbetellana
- other names: {"it": "Scarsella orbetellana"}
- countries: IT
- kinds: dessert

## DISH Q3952008
- name: Schiaccia briaca
- countries: IT
- kinds: dessert

## DISH Q3952009
- name: Schiaccia campigliese
- other names: {"it": "Schiaccia campigliese"}
- countries: IT
- kinds: dessert

## DISH Q3952015
- name: Schiacciata con l'uva
- description: Italian sweet flatbread
- countries: IT
- kinds: dessert
- ingredients: Isabella

## DISH Q3952017
- name: Schiacciata
- other names: {"it": "schiacciata"}
- countries: IT
- kinds: bread

## DISH Q3952291
- name: Scialatelli
- description: type of pasta
- countries: IT
- kinds: type of pasta, pasta
- has Wikipedia article: en

## DISH Q3952312
- name: Sciatt
- description: fritters dish from Valtellina
- countries: IT
- cuisines: cuisine of Valtellina
- kinds: frittelle, dish

## DISH Q3952449
- name: Zucchini flower fritters
- description: Specialty of Provençal cuisine, the cuisine of the Pays Niçois, Italy, and the Balkan countries.
- countries: IT
- cuisines: cuisine niçoise, cuisine of Provence
- kinds: culinary speciality
- ingredients: squash blossom

## DISH Q3953196
- name: Scumuni
- other names: {"it": "Scumuni"}
- countries: IT
- kinds: dessert
- ingredients: egg as food

## DISH Q3953541
- name: Sebada
- description: Sardinian dessert
- countries: IT
- kinds: sweet dish, stuffed pasta
- ingredients: semolina, honey, cheese
- has Wikipedia article: en

## DISH Q3957944
- name: Serpentone
- other names: {"it": "Serpentone"}
- countries: IT
- kinds: dessert

## DISH Q3958689
- name: Sfinci di San Giuseppe
- description: Sicilian doughnut
- countries: IT
- kinds: food, dessert, doughnut
- has Wikipedia article: en

## DISH Q3958703
- name: Sformato
- description: sweet or savory Italian dish
- countries: IT
- cuisines: Italian cuisine
- kinds: dish
- ingredients: egg as food

## DISH Q3958710
- name: Sfratto di Pitigliano
- countries: (none)
- kinds: candy

## DISH Q3958721
- name: Sgabeo
- description: Libby
- countries: IT
- kinds: food, doughnut
- has Wikipedia article: en

## DISH Q3958744
- name: Sguta
- countries: IT
- kinds: dessert

## DISH Q3960389
- name: Signora di Conca Casale
- other names: {"it": "Signora di Conca Casale"}
- countries: IT
- kinds: sausage

## DISH Q3962071
- name: Sise delle monache
- other names: {"es": "Sise delle monache"}
- countries: IT
- kinds: dessert

## DISH Q3964934
- name: Sopa coàda
- description: Italian dish
- countries: IT
- kinds: dish
- ingredients: pigeon

## DISH Q3966710
- name: Spiedo bresciano
- other names: {"zh": "Spiedo bresciano PAT"}
- description: Italian barbeque dish
- countries: IT
- kinds: dish

## DISH Q3966968
- name: Spunghêda ed Bresèl
- other names: {"eml": "Spunghêda ed Bresèl"}
- countries: IT
- kinds: dessert

## DISH Q3973389
- name: Boudin blanc de Rethel
- countries: (none)
- kinds: culinary speciality

## DISH Q3973633
- name: Stocco alla ghiotta
- other names: {"it": "Stocco alla ghiotta"}
- countries: IT
- kinds: dish
- ingredients: fish

## DISH Q3973814
- name: Stomatico
- other names: {"it": "Stomatico"}
- countries: IT
- kinds: dessert

## DISH Q3974593
- name: Strachitunt PDO
- other names: {"zh": "Strachitunt DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: Italian cheese, cheese

## DISH Q3975865
- name: Strascinati
- description: type of pasta
- countries: IT
- kinds: pasta, type of pasta

## DISH Q3976135
- name: Strucchi
- description: Italian dessert
- countries: IT, SI
- kinds: dessert, dish, Slovenian cuisine
- has Wikipedia article: en

## DISH Q3976729
- name: Scottiglia
- description: Tuscan stew
- countries: IT
- kinds: stew

## DISH Q3976730
- name: Sugolo
- description: Italian dessert
- countries: IT
- kinds: dessert
- ingredients: must
- has Wikipedia article: en

## DISH Q3978219
- name: Susamielli
- countries: IT
- kinds: dessert

## DISH Q3979322
- name: Sòma d'aj
- other names: {"it": "Sòma d'aj"}
- countries: IT
- kinds: antipasto

## DISH Q3981027
- name: Taralli di Sant'Antonio
- other names: {"it": "Taralli di Sant'Antonio"}
- countries: IT
- kinds: dessert

## DISH Q3981215
- name: Tartufo nero pregiato della Toscana PAT
- other names: {"zh": "Tartufo nero pregiato della Toscana PAT"}
- description: traditional Italian fruit, vegetable or cereal product (PAT)
- countries: IT
- kinds: truffle, food, agricultural product

## DISH Q3984342
- name: Tergeste PDO
- other names: {"zh": "Tergeste DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q3984536
- name: Terra d'Otranto PDO
- other names: {"zh": "Terra d'Otranto DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: extra virgin olive oil, olive oil
- has Wikipedia article: en

## DISH Q3984620
- name: Terre Tarentine PDO
- other names: {"zh": "Terre Tarentine DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: extra virgin olive oil, olive oil
- has Wikipedia article: en

## DISH Q3984622
- name: Terre di Siena PDO
- other names: {"zh": "Terre di Siena DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil, extra virgin olive oil

## DISH Q3985185
- name: Testa di moro
- description: Italian dessert
- countries: IT
- kinds: dessert

## DISH Q3985208
- name: Testaroli
- description: type of pasta prepared using water, flour and salt
- countries: IT
- kinds: pasta, type of pasta
- has Wikipedia article: en

## DISH Q3991202
- name: Tiella of Gaeta
- description: traditional fish-based food from Gaeta, Lazio, Italy
- countries: IT
- kinds: Tiella, fish dish, single course

## DISH Q3991203
- name: Tiella
- description: Italian dish
- countries: IT
- kinds: focaccia
- has Wikipedia article: en

## DISH Q3992553
- name: Toma del Mottarone
- description: Cheese from Italy
- countries: IT
- kinds: Italian cheese, cheese

## DISH Q3992634
- name: Tombea
- other names: {"it": "Tombea"}
- countries: IT
- kinds: Italian cheese

## DISH Q3992663
- name: Tomini elettrici
- other names: {"it": "Tomini elettrici"}
- countries: IT
- kinds: appetizer
- ingredients: Tomino

## DISH Q3993708
- name: Torcinello
- countries: IT
- kinds: dish
- has Wikipedia article: en

## DISH Q3995780
- name: Torrone di Guardiagrele
- other names: {"it": "Torrone di Guardiagrele"}
- countries: IT
- cuisines: Abruzzese cuisine
- kinds: confectionery

## DISH Q3995781
- name: Torrone gelato
- other names: {"it": "torrone gelato"}
- countries: IT
- kinds: dessert

## DISH Q3995782
- name: Torrone Nurzia
- description: Italian chocolate nougat
- countries: IT
- cuisines: Abruzzese cuisine
- kinds: nougat, confectionery, food product
- has Wikipedia article: en

## DISH Q3995784
- name: Turrón de Alicante
- countries: ES
- kinds: turrón

## DISH Q3995785
- name: Jijona
- description: Spanish nougat
- countries: ES
- kinds: turrón

## DISH Q3995795
- name: Torta Bertolina
- description: Italian cake
- countries: IT
- kinds: pastry

## DISH Q3995798
- name: Torta Ostiglia
- other names: {"ca": "Torta Ostiglia"}
- countries: IT
- kinds: dessert

## DISH Q3995799
- name: Torta Tre Monti
- description: Traditional Sammarinese cake
- countries: SM
- kinds: layer cake
- ingredients: wafer cookie
- has Wikipedia article: en

## DISH Q3995800
- name: Torta co' bischeri
- other names: {"fr": "torta co' bischeri"}
- countries: IT
- kinds: dessert

## DISH Q3995802
- name: Tourte de riz
- other names: {"fr": "tourte de riz"}
- countries: IT
- kinds: dessert

## DISH Q3995804
- name: Torta della nonna
- description: Italian pastry pie
- countries: IT
- cuisines: Italian cuisine
- kinds: sweet pie
- ingredients: shortcrust pastry, custard, pine nut
- has Wikipedia article: en

## DISH Q3995806
- name: Torta di San Biagio
- other names: {"it": "Torta di San Biagio"}
- countries: IT
- kinds: dessert

## DISH Q3995811
- name: Torta di tagliatelle
- other names: {"it": "torta di tagliatelle"}
- countries: IT
- kinds: dessert

## DISH Q3995812
- name: Torta di tagliatelline
- other names: {"it": "torta di tagliatelline"}
- countries: IT
- kinds: dessert

## DISH Q3995813
- name: Torta mantovana
- other names: {"it": "Torta mantovana"}
- countries: IT
- kinds: dessert

## DISH Q3995814
- name: Torta setteveli
- description: seven-veil cake
- countries: IT
- cuisines: Italian cuisine
- kinds: cake, dessert
- ingredients: Gianduja, hazelnut, nougat, almond, Theobroma cacao, chocolate
- has Wikipedia article: en

## DISH Q3995817
- name: Tortelli cremaschi
- description: main dish of traditional Cremasque cuisine
- countries: IT
- kinds: pasta dish
- ingredients: Tortelli
- has Wikipedia article: en

## DISH Q3995818
- name: Tortelli
- description: type of stuffed pasta
- countries: IT
- kinds: stuffed pasta, type of pasta
- has Wikipedia article: en

## DISH Q3995819
- name: Tortelli alla lastra di Corezzo PAT
- other names: {"zh": "Tortelli alla lastra di Corezzo PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: pasta dish, baked good

## DISH Q3995820
- name: Tortellini di Valeggio sul Mincio
- other names: {"it": "tortellini di Valeggio sul Mincio"}
- countries: IT
- kinds: tortellini, type of pasta

## DISH Q3995824
- name: Tortello maremmano
- description: Italian traditional dish
- countries: IT
- kinds: pasta dish

## DISH Q3995825
- name: Tordè d’arbètta
- other names: {"eml": "Tordè d’arbètta"}
- countries: IT
- kinds: pasta dish
- ingredients: Tortelli

## DISH Q3995826
- name: Tortello amaro di Castel Goffredo
- description: type of pasta
- countries: IT
- kinds: stuffed pasta, pasta dish, egg pasta, type of pasta
- has Wikipedia article: en

## DISH Q3995832
- name: Tortionata
- description: Italian almond cake
- countries: IT
- kinds: cake
- ingredients: almond

## DISH Q3995875
- name: Toscano PGI
- other names: {"zh": "Toscano IGP"}
- description: Italian PGI olive oil
- countries: IT
- kinds: extra virgin olive oil, olive oil

## DISH Q4001072
- name: Twister
- description: ice cream
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q4001299
- name: Tóch
- other names: {"it": "tóch"}
- countries: IT
- cuisines: cuisine of the province of Como
- kinds: first course
- ingredients: butter, cheese

## DISH Q4007501
- name: Val di Mazara PDO
- other names: {"zh": "Val di Mazara DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q4007569
- name: Valdemone PDO
- other names: {"zh": "Valdemone DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q4008232
- name: Valli Trapanesi PDO
- other names: {"zh": "Valli Trapanesi DOP"}
- description: Italian PDO olive oil
- countries: IT
- kinds: olive oil

## DISH Q4008973
- name: Vasteḍḍa frijuta
- other names: {"it": "Vasteḍḍa frijuta"}
- countries: IT
- kinds: food

## DISH Q4010214
- name: Verretta
- description: chocolate-covered wafer cake
- countries: SM
- kinds: cake

## DISH Q4013610
- name: Vincisgrassi
- description: pasta dish fom Marche, Italy
- countries: IT
- kinds: pasta dish
- has Wikipedia article: en

## DISH Q4014718
- name: Virtù
- other names: {"it": "virtù"}
- countries: IT
- kinds: dish

## DISH Q4015029
- name: Vitellone bianco dell'Appennino Centrale PGI
- other names: {"zh": "Vitellone bianco dell'Appennino Centrale IGP"}
- description: Italian PGI fresh meat
- countries: IT
- kinds: meat

## DISH Q4023626
- name: Zafferano di San Gimignano PDO
- other names: {"zh": "Zafferano di San Gimignano DOP"}
- description: Italian PDO agricultural product
- countries: IT
- kinds: food product, agricultural product

## DISH Q4023629
- name: Zafferano di Sardegna PDO
- other names: {"zh": "Zafferano di Sardegna DOP"}
- description: Italian PDO agricultural product
- countries: IT
- kinds: food product, agricultural product

## DISH Q4024434
- name: Zigulì
- description: Italian sweet
- countries: IT
- kinds: food, candy

## DISH Q4024450
- name: Zimino
- description: Sardinian dish
- countries: IT
- cuisines: cuisine of Sardinia
- kinds: lamb dish, beef dish

## DISH Q4024571
- name: Zirotto
- other names: {"it": "Zirotto"}
- countries: IT
- kinds: dessert

## DISH Q4024898
- name: Zuccherino di Vernio
- other names: {"it": "Zuccherino di Vernio"}
- countries: IT
- kinds: confectionery

## DISH Q4024941
- name: Zucchine alla scapece
- description: Neapolitan dish
- countries: IT
- kinds: dish
- has Wikipedia article: en

## DISH Q4024992
- name: Kaisersuppe
- other names: {"de": "Kaisersuppe"}
- countries: (none)
- kinds: soup

## DISH Q4025000
- name: Zuppa gallurese
- countries: IT
- kinds: dish

## DISH Q402587
- name: Maple sugar
- description: food
- countries: CA, US
- kinds: confectionery
- ingredients: plant sap
- has Wikipedia article: en

## DISH Q4036160
- name: Chocodile
- description: confection created by the Hostess Brands company
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q4038290
- name: Ulevel
- other names: {"nl": "Ulevel"}
- countries: (none)
- kinds: candy

## DISH Q404973
- name: Peking duck
- other names: {"zh": "北京烤鸭"}
- description: roast duck from Beijing (Peking)
- countries: CN
- cuisines: Beijing cuisine
- kinds: roast duck
- ingredients: Spring pancake, cucumber, tianmianjiang, duck meat, Welsh onion
- has Wikipedia article: en, zh

## DISH Q4062939
- name: Altai honey
- countries: RU, SU
- kinds: honey

## DISH Q4068439
- name: Арака (хакасский напиток)
- other names: {"ru": "Арака (хакасский напиток)"}
- countries: (none)
- cuisines: Khakas cuisine
- kinds: dish

## DISH Q4073388
- name: Achma
- description: dish from Georgia
- countries: GE
- cuisines: Georgian cuisine
- kinds: dish, khachapuri
- ingredients: salt, water, Sulguni, dough, flour
- has Wikipedia article: en

## DISH Q4077486
- name: Banusz
- description: Ukrainian Dish
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: dish
- ingredients: maize flour, cornmeal, Bryndza, smetana, cream
- has Wikipedia article: en

## DISH Q4080173
- name: Bashkir honey
- countries: (none)
- kinds: honey

## DISH Q4082936
- name: Белочка
- other names: {"ru": "Белочка"}
- countries: (none)
- kinds: candy

## DISH Q40853306
- name: Full breakfast
- other names: {"zh": "英式早餐"}
- description: substantial British and Irish breakfast
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q40867220
- name: Lemon marmalade
- countries: (none)
- kinds: marmalade
- ingredients: lemon

## DISH Q4090235
- name: Bozbash
- description: mutton stew
- countries: AZ
- kinds: stew
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q40908960
- name: Mattang
- countries: KR
- kinds: sweet potato fries

## DISH Q4097120
- name: Brtuch
- countries: AM
- cuisines: Armenian cuisine
- kinds: stuffed flatbread

## DISH Q4097613
- name: Bubert
- countries: DE, LV
- kinds: dessert

## DISH Q40978520
- name: Pljukanci
- description: Istrian type of pasta
- countries: HR
- kinds: pasta

## DISH Q4101404
- name: Bäleş
- countries: (none)
- cuisines: Tatarstan cuisine, Bashkir cuisine
- kinds: pie

## DISH Q4102393
- name: Wazwan
- description: meal in Kashmiri cuisine
- countries: (none)
- cuisines: Kashmiri cuisine
- kinds: lamb dish, chicken dish, cuisine
- ingredients: Tabak maaz, Rista, seekh kebab, Gushtab, mutton, Rogan josh, chicken as food, cooked rice, vegetable
- has Wikipedia article: en

## DISH Q4102771
- name: Валенец
- other names: {"ru": "валенец"}
- countries: (none)
- kinds: bread roll

## DISH Q4102828
- name: Biscuit roll
- other names: {"zh": "雞蛋卷"}
- description: crispy rolled wafer pastry
- countries: ES
- kinds: biscuit, meal
- has Wikipedia article: en, zh

## DISH Q4103061
- name: Lumpia Semarang
- description: spring roll from Semarang
- countries: ID
- cuisines: Indonesian cuisine
- kinds: finger food, dish, human food, type of food or dish
- ingredients: garlic, bamboo shoots, chicken as food, dried shrimp, crêpe, table salt, sugar
- has Wikipedia article: en

## DISH Q4108173
- name: Вертута
- other names: {"ru": "вертута"}
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: dish

## DISH Q4115189
- name: Wikidata Sandbox
- other names: {"zh": "维基数据沙盒"}
- description: This is a sandbox for testing - It is a page, with triples, but the triples don't have any real world applicability, just demonstrating various linked properties etc.
- countries: IN
- kinds: music, SIMBAD, Web Ontology Language, olive, painting, human whose existence is disputed, Wikidata internal entity, human, unidentified flying object, computing platform, test
- ingredients: canvas, oil paint
- has Wikipedia article: en, zh

## DISH Q4116140
- name: Fesikh
- other names: {"zh": "埃及鹹魚"}
- description: traditional Egyptian fish dish
- countries: (none)
- kinds: food, dish
- ingredients: fish
- has Wikipedia article: en, zh

## DISH Q4118252
- name: Pizza-ghetti
- description: Quebecois casual restaurant dish
- countries: CA
- kinds: pasta dish
- ingredients: spaghetti
- has Wikipedia article: en

## DISH Q4118270
- name: Mixed nuts
- other names: {"zh": "混合堅果"}
- description: snack food consisting of any mixture of mechanically or manually combined nuts
- countries: (none)
- kinds: food, dish
- ingredients: nut
- has Wikipedia article: en

## DISH Q4122049
- name: Rusk
- description: form of rusk
- countries: DE
- kinds: food, baked good, bread, biscuit
- ingredients: flour
- has Wikipedia article: en

## DISH Q4129873
- name: Flatbrød
- other names: {"zh": "挪威無酵餅"}
- description: Norwegian unleavened bread
- countries: NO
- kinds: food, flatbread
- ingredients: barley
- has Wikipedia article: en

## DISH Q4130224
- name: Vyazma pryanik
- description: a type of Russian pryanik
- countries: RU
- kinds: dessert
- has Wikipedia article: en

## DISH Q4130778
- name: Ais Kacang
- other names: {"zh": "ABC冰"}
- description: Ais Kacang another variations of Air batu campur
- countries: MY
- kinds: shaved ice
- ingredients: evaporated milk, shaved ice, palm sugar, grass jelly, Phaseolus vulgaris, Zea mays Saccharata Group
- has Wikipedia article: en, zh

## DISH Q41384
- name: Chicken foot as food
- other names: {"zh": "凤爪"}
- description: type of offal
- countries: (none)
- kinds: foot, chicken dish
- ingredients: chicken foot
- has Wikipedia article: en, zh

## DISH Q41415
- name: Soup
- other names: {"zh": "湯"}
- description: primarily liquid food
- countries: (none)
- kinds: dish, type of food or dish
- ingredients: dressing, broth, spice, liquid, vegetable, water
- has Wikipedia article: en, zh

## DISH Q41415182
- name: Steppegras
- other names: {"de": "Steppegras"}
- countries: (none)
- kinds: dish
- ingredients: shoestring potatoes

## DISH Q4145098
- name: Գորոդեցի քաղցրաբլիթ
- other names: {"hy": "Գորոդեցի քաղցրաբլիթ"}
- countries: (none)
- kinds: pryanik, dish
- ingredients: dough

## DISH Q41484834
- name: Qedra
- description: traditional Palestinian dish
- countries: (none)
- kinds: food, meat dish, rice dish
- has Wikipedia article: en

## DISH Q41521988
- name: Fiambre
- description: Portuguese cooked ham
- countries: PT
- kinds: cooked whole-muscle cut, cooked ham

## DISH Q4152552
- name: Guriev porridge
- description: porridge made with semolina, nuts, milk and dried fruit
- countries: RU
- kinds: porridge
- ingredients: kaymak, semolina, semolina pudding, dried fruit, nut
- has Wikipedia article: en

## DISH Q4154144
- name: Dalieba
- other names: {"zh": "大列巴"}
- description: Chinese bread similar to Russian rye bread
- countries: RU
- kinds: bread
- has Wikipedia article: en, zh

## DISH Q4159174
- name: Ice cream-based dessert
- countries: (none)
- kinds: frozen dessert

## DISH Q4160901
- name: Dzykka
- countries: (none)
- cuisines: Ossetian cuisine
- kinds: porridge

## DISH Q41617095
- name: Steirisches Wurzelfleisch
- other names: {"de": "Steirisches Wurzelfleisch"}
- countries: (none)
- kinds: dish

## DISH Q4164571
- name: Bazeen
- description: unleavened bread in Libyan cuisine
- countries: LY
- cuisines: Tunisian cuisine, Libyan cuisine
- kinds: bread, dish
- ingredients: barley, table salt, water
- has Wikipedia article: en

## DISH Q4164590
- name: Mahyawa
- description: Sauce
- countries: IR
- kinds: fish sauce
- ingredients: fish
- has Wikipedia article: en

## DISH Q4165267
- name: Makdous
- other names: {"zh": "馬克杜斯"}
- description: Levantine dish of eggplants cured in oil
- countries: (none)
- kinds: food, appetizer
- ingredients: garlic, eggplant, paprika, walnut
- has Wikipedia article: en

## DISH Q4168613
- name: Дрочёна
- other names: {"ru": "дрочёна"}
- countries: RU, UA, BY
- cuisines: Russian cuisine, Ukrainian cuisine, Belarusian cuisine
- kinds: dish
- ingredients: groat, egg as food, oil, flour, milk

## DISH Q41799628
- name: Red chile brisket
- description: beef brisket meal
- countries: (none)
- kinds: dish
- ingredients: garlic, beef brisket, onion, peppercorn, table salt

## DISH Q41804851
- name: Pork chops and applesauce
- description: traditional dish in Spain and the United Kingdom, consisting of cooked pork chops and apple sauce
- countries: (none)
- kinds: pork dish
- ingredients: pork chop, apple sauce
- has Wikipedia article: en

## DISH Q41805869
- name: Dolsa
- other names: {"ca": "dolsa"}
- countries: (none)
- kinds: confectionery

## DISH Q41806779
- name: Sundaeguk
- other names: {"zh": "血腸湯"}
- description: Korean soup containing sundae (Korean blood sausage)
- countries: KR
- cuisines: Korean cuisine
- kinds: guk
- ingredients: sundae

## DISH Q4185632
- name: Zeamă
- countries: RO, MD
- cuisines: Romanian cuisine, Moldovan cuisine
- kinds: dish

## DISH Q4185902
- name: Parbaking
- description: Cooking technique
- countries: (none)
- kinds: bread, frozen food, food preparation technique
- has Wikipedia article: en

## DISH Q4189322
- name: Gulai
- other names: {"zh": "武唻"}
- description: Indonesian curry-like dish originating from Sumatra island
- countries: ID
- cuisines: Singaporean cuisine, Indonesian cuisine, Padang cuisine
- kinds: curry, food, dish, human food
- ingredients: condiment, coconut milk, fish as food, offal, meat, bird
- has Wikipedia article: en, zh

## DISH Q4189615
- name: Nagasari
- description: Indonesia steamed cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: banana dish, dish, human food, type of food or dish
- ingredients: tapioca flour, banana leaf, coconut, rice flour, coconut milk, Pandanus, cooking banana, table salt, sugar
- has Wikipedia article: en

## DISH Q4192299
- name: Oncom
- description: West Java traditional food
- countries: ID
- cuisines: Indonesian cuisine
- kinds: meal, dish, human food, type of food or dish
- ingredients: cassava, peanut, soy pulp
- has Wikipedia article: en

## DISH Q4193417
- name: Golden Opulence Sundae
- description: world-record most expensive sundae dessert
- countries: (none)
- kinds: sundae
- ingredients: gold
- has Wikipedia article: en

## DISH Q4197759
- name: Botok
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, vegetable, dish, human food, type of food or dish
- ingredients: Bothok Mlanding, Indonesian bay leaf, coconut, peppercorn, table salt
- has Wikipedia article: en

## DISH Q4197962
- name: Bubur kacang hijau
- other names: {"zh": "绿豆粥"}
- description: Indonesian mung bean soup
- countries: ID
- cuisines: Indonesian cuisine
- kinds: soup, dish
- ingredients: palm sugar, coconut milk, Vigna radiata, cinnamon, water
- has Wikipedia article: en

## DISH Q4198570
- name: Apam balik
- other names: {"zh": "曼煎粿"}
- description: Southeast Asian pancake
- countries: CN, ID
- kinds: pancake
- ingredients: condensed milk, flour, butter
- has Wikipedia article: en, zh

## DISH Q4199077
- name: Squash caviar
- countries: SU
- kinds: dish, varenye, mash
- ingredients: tomato paste, Allium, spice, table salt, zucchini, carrot

## DISH Q4199436
- name: Lawar
- description: Indonesian dish
- countries: ID
- cuisines: Indonesian cuisine, side dish
- kinds: food, main course, dish, human food, type of food or dish
- ingredients: grated coconut, Asparagus bean, bird's eye chili, Citrus × aurantiifolia, chili pepper, black pepper, Allium sativum, table salt, sugar, meat
- has Wikipedia article: en

## DISH Q4200659
- name: Pempek
- description: Indonesian dish made of fish and tapioca
- countries: ID
- cuisines: Indonesian cuisine, Palembang cuisine
- kinds: fast food, food, dish, type of food or dish, street food, fish dish
- ingredients: flavor enhancer, fish as food, egg as food, vinegar, flour, table salt, water, fish, garlic, Tamarindus indica, palm sugar
- has Wikipedia article: en

## DISH Q4200763
- name: Rawon
- other names: {"zh": "拉吻肉湯"}
- description: Indonesian traditional soup originating from Surabaya in East Java
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, type of food or dish, soup, human food
- ingredients: Cymbopogon citratus leaf, garlic, ginger, mung bean sprout, peppercorn, bay leaf, Pangium edule, scallion, galangal, palm oil, beef, Apium graveolens, table salt, water, Kaffir Lime Leaf
- has Wikipedia article: en

## DISH Q4201329
- name: Rice lengko
- description: a typical rice dish from Cirebon, West Java
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, rice dish
- ingredients: fried tempeh, Bawang goreng, tahu goreng, mung bean sprout, Indonesian peanut sauces, kecap manis, krupuk, cooked rice, Allium tuberosum, Cucumis sativus, omelette
- has Wikipedia article: en

## DISH Q4202016
- name: Lupis
- description: Indonesian traditional cake
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, confectionery, meal, Kuih, traditional food
- ingredients: banana leaf, coconut, palm sugar, glutinous rice, table salt, sugar, water
- has Wikipedia article: en

## DISH Q4203530
- name: Karedok
- other names: {"zh": "卡雷多"}
- description: Indonesian salad dish
- countries: ID
- cuisines: food, Indonesian cuisine
- kinds: vegetable, dish, human food, type of food or dish, jajan pasar, food, salad, street food
- ingredients: asparagus bean, mung bean sprout, peanut, Indonesian peanut sauces, shrimp paste, Kaempferia galanga, Holy Basil, Pachyrhizus erosus, chili pepper, Cucumis sativus, table salt, sugar
- has Wikipedia article: en

## DISH Q42044808
- name: Odawara-kei tantanmen
- description: building in Odawara, Kanagawa Prefecture, Japan
- countries: (none)
- kinds: dandan noodles

## DISH Q42045522
- name: Odawara-kei rāmen
- countries: (none)
- kinds: ramen

## DISH Q4205452
- name: Nasi kebuli
- description: Indonesian rice dish
- countries: ID
- cuisines: cooked rice, Indonesian cuisine
- kinds: cooked rice, dish, human food, type of food or dish, food, goat meat dish
- ingredients: shallot, garlic, star anise, coconut milk, cooked rice, goat meat, ghee, broth, black pepper, Coriandrum sativum, butter, Carum carvi, milk, rice
- has Wikipedia article: en

## DISH Q4205456
- name: Sangsang
- other names: {"zh": "薩克桑"}
- description: Indonesian dish
- countries: ID
- cuisines: main course, Indonesian cuisine, side dish
- kinds: type of food or dish, dish, human food, meal
- ingredients: Curcuma longa, table salt, Indonesian bay leaf, garlic, coriander seed, ginger, grated coconut, Cymbopogon, Andaliman, bay leaf, Alpinia officinarum, flavor enhancer, red onion, pork, Citrus × aurantiifolia, chili pepper, black pepper
- has Wikipedia article: en

## DISH Q4206002
- name: Urap
- description: Indonesian salad recipe
- countries: ID
- kinds: salad, dish
- ingredients: seedling, Asparagus bean, shrimp paste, water spinach, chili pepper, Spinacia oleracea, Tamarindus indica, Curcuma longa, Brassica oleracea var. capitata, Kaffir Lime Leaf, cassava root, garlic, coconut, bay leaf, table salt
- has Wikipedia article: en

## DISH Q420646
- name: Pho
- other names: {"zh": "越南粉"}
- description: Vietnamese noodle soup dish
- countries: VN
- kinds: food, dish, noodle soup, traditional food, beef dish
- ingredients: rice noodle
- has Wikipedia article: en, zh

## DISH Q4207282
- name: Pyeonyuk
- description: pressed boiled meat
- countries: (none)
- kinds: pork dish, beef dish
- has Wikipedia article: en

## DISH Q4208144
- name: Bakwan
- description: vegetable fritter
- countries: ID
- cuisines: fritter, Indonesian cuisine
- kinds: fritter, dish, human food, type of food or dish, jajan pasar
- ingredients: shallot, garlic, cabbage, mung bean sprout, wheat flour, scallion, carrot
- has Wikipedia article: en

## DISH Q4208154
- name: Mie aceh
- description: Indonesian curried spicy noodle dish
- countries: ID
- cuisines: Indonesian cuisine, Acehnese cuisine
- kinds: food, cuisine, human food, type of food or dish, noodle, dish, street food, jajan pasar
- ingredients: cabbage, mung bean sprout, peppercorn, kecap manis, wheat flour, leek, star anise, scallion, goat meat, Allium ascalonicum, noodle, chili pepper, acetic acid, black pepper, Curcuma longa, Brassica oleracea var. capitata, table salt, celery, garlic, caraway seeds, tomato, cardamom
- has Wikipedia article: en

## DISH Q4208242
- name: Sayur lodeh
- description: Indonesian vegetable soup originating from Java island
- countries: ID
- kinds: food, soup
- ingredients: shallot, bay leaf, coconut milk, Sechium edule, Allium sativum, Zea mays Saccharata Group, carrot
- has Wikipedia article: en

## DISH Q4208661
- name: Mie celor
- description: Indonesian noodle soup dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, Indonesian cuisine, human food, type of food or dish, noodle
- ingredients: noodle, egg noodle, shallot, Thick noodle, garlic, ginger, mung bean sprout, scallion, dried shrimp, Citrus × aurantiifolia, egg as food, Apium graveolens
- has Wikipedia article: en

## DISH Q4209872
- name: Jeok
- description: skewered food in Korean cuisine
- countries: (none)
- kinds: type of food or dish, dish
- has Wikipedia article: en

## DISH Q4213720
- name: Karađorđeva šnicla
- description: Serbian dish
- countries: RS
- cuisines: Serbian cuisine
- kinds: schnitzel, pork dish, veal dish
- ingredients: schnitzel, kaymak, egg as food, flour, table salt
- has Wikipedia article: en

## DISH Q4215683
- name: Eo-mandu
- description: fish dumpling
- countries: (none)
- kinds: mandu, fish dish
- ingredients: whitefish
- has Wikipedia article: en

## DISH Q4215727
- name: Jatjuk
- other names: {"zh": "松仁粥"}
- description: Korean porridge
- countries: (none)
- kinds: juk
- ingredients: pine nut
- has Wikipedia article: en

## DISH Q4216247
- name: Kartoplyanyky
- countries: UA
- cuisines: Ukrainian cuisine
- kinds: dish
- ingredients: flour, egg, potato

## DISH Q4216274
- name: Kartuliporss
- other names: {"et": "kartuliporss"}
- description: potato dish of possibly Estonian origin
- countries: EE
- kinds: potato dish
- ingredients: pork

## DISH Q4216301
- name: Karukan
- other names: {"zh": "輕羹"}
- description: Japanese confection from Kyushu
- countries: JP
- kinds: pastry, wagashi
- ingredients: Dioscorea japonica, Vigna angularis
- has Wikipedia article: en, zh

## DISH Q4216325
- name: Soup soy sauce
- other names: {"zh": "汤酱油"}
- description: type of Korean soy sauce
- countries: (none)
- kinds: soy sauce, by-product
- ingredients: brine, meju
- has Wikipedia article: en, zh

## DISH Q4217538
- name: Biberli ekmek
- other names: {"tr": "Biberli ekmek"}
- countries: (none)
- kinds: dish

## DISH Q4222435
- name: Kitakata ramen
- other names: {"zh": "喜多方拉麵"}
- description: Japanese food
- countries: JP
- kinds: ramen
- has Wikipedia article: en, zh

## DISH Q4222490
- name: Chitonoagă
- other names: {"ro": "chitonoagă"}
- countries: RO, MD
- cuisines: Romanian cuisine, Moldovan cuisine
- kinds: quince cheese

## DISH Q4225831
- name: Kovrizhka
- countries: (none)
- kinds: food, gingerbread confectionary, baking
- ingredients: flour, raisin, nut, sugar, honey, water

## DISH Q4229214
- name: Komanmelna
- description: variety of pancakes
- countries: (none)
- cuisines: Mari cuisine
- kinds: pancake, dish
- ingredients: flour

## DISH Q42348478
- name: Ilish macher paturi
- description: a dish made of Hilsa fish
- countries: (none)
- kinds: steamed curry, ilish dish, paturi

## DISH Q42363424
- name: Bhapa Ilish
- description: an item made of Hilsa fish
- countries: (none)
- kinds: ilish dish
- ingredients: ilish as food

## DISH Q42363635
- name: Mutton biryani
- description: a variety of biryani, with mutton added
- countries: (none)
- kinds: biryani, dish
- ingredients: sheep meat, rice

## DISH Q42366457
- name: Vegetable stock
- other names: {"zh": "蔬菜汤"}
- description: Vegetable-based food
- countries: FR
- cuisines: French cuisine
- kinds: soup, broth, convenience food, human food, food ingredient, vegetable dish
- ingredients: condiment, winter vegetable, bean, cereal

## DISH Q42369886
- name: Kolkata biryani
- description: a variety of biryani from Kolkata, India
- countries: (none)
- kinds: biryani, dish, type of food or dish
- ingredients: potato, chicken as food, goat meat, egg as food, rice
- has Wikipedia article: en

## DISH Q42373854
- name: Potato biryani
- description: form of biryani, generally vegetarian, with potato. It may contain chicken in certain variation as seen in Kolkata's famous potato biryani
- countries: IN
- kinds: biryani, rice dish, dish
- ingredients: potato, rice

## DISH Q42373871
- name: Digestive
- other names: {"de": "Digestive"}
- countries: (none)
- kinds: cookie

## DISH Q42378074
- name: Česnečka
- description: Garlic soup in Czech cuisine and Slovak cuisine
- countries: CZ
- kinds: garlic soup
- has Wikipedia article: en

## DISH Q42379629
- name: Beef biryani
- description: variety of biryani, with beef
- countries: (none)
- kinds: biryani, dish
- ingredients: beef, rice

## DISH Q42380699
- name: Egg biryani
- description: a variety of biryani, with egg
- countries: (none)
- kinds: biryani, rice dish, egg dish, dish
- ingredients: egg as food, rice

## DISH Q42381119
- name: Doi Ilish
- description: an item made of Hilsa fish
- countries: (none)
- kinds: ilish dish
- ingredients: ilish as food, curd

## DISH Q42381360
- name: Rui Machher Kalia
- description: dish made of rohu fish
- countries: (none)
- kinds: kaliya, fish dish
- ingredients: Rohu

## DISH Q42395119
- name: Malabar biryani
- description: variety of biryani
- countries: (none)
- kinds: biryani, rice dish, dish
- ingredients: chicken as food, rice

## DISH Q42395543
- name: Kalyani biryani
- description: variety of biryani, popular in Hyderabad, India
- countries: IN
- kinds: biryani, rice dish
- ingredients: beef, rice

## DISH Q42395976
- name: Dindigul biryani
- description: biryani from Dindigul, Tamil Nadu, India
- countries: (none)
- kinds: biryani, rice dish
- ingredients: lemon juice, chicken as food, goat meat, rice

## DISH Q42396244
- name: Delhi biryani
- description: variety of biryani, from Delhi, India
- countries: (none)
- kinds: biryani, rice dish, dish
- ingredients: chicken as food, goat meat, rice

## DISH Q42399449
- name: Narkel Naru
- description: a sweet from Bengal
- countries: IN
- kinds: food, dessert
- ingredients: coconut, sugar

## DISH Q42400563
- name: Rajbhog
- description: a sweet of Bengal
- countries: (none)
- kinds: confectionery
- ingredients: chhena, saffron, sugar, milk

## DISH Q42411090
- name: Block-milk
- description: solid sweet milk product
- countries: (none)
- kinds: dairy product, food product, evaporated milk, material, human food
- ingredients: sugar, milk

## DISH Q42417224
- name: Gallina Rellena
- description: non Vegetarian Nicaraguan Dish
- countries: (none)
- kinds: chicken dish
- has Wikipedia article: en

## DISH Q42417247
- name: Braciolone
- description: Italian meat dish
- countries: (none)
- kinds: roulade
- has Wikipedia article: en

## DISH Q42417413
- name: Ruby chocolate
- other names: {"zh": "紅寶石巧克力"}
- description: reddish, sour chocolate made with unfermented cocoa beans
- countries: BE
- kinds: chocolate, types of chocolate
- ingredients: chocolate liquor, cocoa butter, citric acid, sugar
- has Wikipedia article: en, zh

## DISH Q42417569
- name: Fanta Cake
- other names: {"zh": "芬达蛋糕"}
- description: German dessert
- countries: DE
- kinds: sponge cake
- ingredients: sugar
- has Wikipedia article: en, zh

## DISH Q42417761
- name: Aguadito de pollo
- description: Peruvian chicken soup
- countries: PE
- kinds: soup, meal
- ingredients: chicken offal, pea, maize, coriander seed, chicken as food
- has Wikipedia article: en

## DISH Q42417869
- name: Bustrengo
- description: cake dish in Sammarinese cuisine
- countries: IT
- kinds: dessert
- has Wikipedia article: en

## DISH Q42434444
- name: Memoni biryani
- description: variety of biryani, similar to Sindhi biryani
- countries: (none)
- kinds: biryani, rice dish, dish
- ingredients: goat meat, rice

## DISH Q42434706
- name: Bhatkali biryani
- description: varierty of biryani, from coastal Karnataka, India
- countries: (none)
- kinds: biryani, rice dish
- ingredients: chicken as food, goat meat, rice

## DISH Q42435036
- name: Beary biryani
- description: biryani from Dakshina Kannada, Karnataka, India
- countries: (none)
- kinds: biryani, rice dish
- ingredients: shrimp and prawn as food, chicken as food, fish as food, goat meat, beef, rice

## DISH Q4246304
- name: Yakisobapan
- other names: {"zh": "炒面面包"}
- description: Japanese food
- countries: (none)
- kinds: chōripan
- ingredients: Yakisoba, hot dog bun
- has Wikipedia article: en, zh

## DISH Q4246388
- name: Kullama
- description: type of soup from Tatarstan and Bashkortostan
- countries: (none)
- kinds: soup

## DISH Q4246421
- name: Kulolo
- description: Hawaiian dessert
- countries: US
- kinds: pudding, dessert, type of food or dish
- has Wikipedia article: en

## DISH Q4247469
- name: Korokkepan
- description: Japanese dish of a bun with Japanese croquet and sauce
- countries: (none)
- kinds: chōripan
- ingredients: korokke, bread

## DISH Q4247887
- name: Katsu sandwich
- other names: {"zh": "豬排三明治"}
- description: Japanese sandwich
- countries: JP
- kinds: sandwich, meat dish, food
- ingredients: katsu
- has Wikipedia article: en

## DISH Q4248147
- name: Amezaiku
- other names: {"zh": "糖人"}
- description: Japanese candy craft artistry
- countries: JP
- kinds: sugar sculpture, Japanese craft, candy making, ame
- ingredients: mizuame
- has Wikipedia article: en

## DISH Q4249417
- name: Qutab
- other names: {"zh": "阿塞拜疆卷"}
- description: Azerbaijani dough dish
- countries: AZ
- kinds: food, pie
- ingredients: beef
- has Wikipedia article: en

## DISH Q4250363
- name: Kuyrdak
- other names: {"zh": "传统肉盘"}
- description: Central Asian meat dish
- countries: KG, KZ
- cuisines: Karakalpak cuisine, Kazakh cuisine, Cuisine of Uzbekistan, Turkmen cuisine, Kyrgyz cuisine
- kinds: dish, lamb dish
- ingredients: onion, lamb meat
- has Wikipedia article: en, zh

## DISH Q4251295
- name: Kofte bozbash
- description: stew dish with meatballs
- countries: AZ
- kinds: kofta, stew, food
- ingredients: minced meat

## DISH Q4256352
- name: Levengi
- description: Azerbaijani dish
- countries: (none)
- cuisines: Azerbaijan
- kinds: dish
- has Wikipedia article: en

## DISH Q426103
- name: Johnnycake
- other names: {"zh": "約翰尼蛋糕"}
- description: cornmeal flatbread
- countries: US
- kinds: food, flatbread
- ingredients: cornmeal
- has Wikipedia article: en

## DISH Q4261477
- name: Mitsumame
- other names: {"zh": "蜜豆"}
- description: Japanese dessert
- countries: JP
- kinds: wagashi
- ingredients: pea, syrup, agar
- has Wikipedia article: en, zh

## DISH Q4262936
- name: Combro
- countries: ID
- cuisines: Indonesian cuisine
- kinds: fritter, dish, human food, type of food or dish
- ingredients: cassava root, oncom

## DISH Q4264051
- name: Geplak
- description: Southeast Asian sweet snack, originating from Bantul, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: sweet dish, dish, human food, type of food or dish
- ingredients: Cocos nucifera
- has Wikipedia article: en

## DISH Q4272202
- name: Tongseng
- description: Indonesian goat soup
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, soup, goat meat dish
- ingredients: goat meat, Alpinia galanga, beef, chili pepper, Brassica oleracea var. capitata, coconut milk, scallion, lamb meat, kecap, shallot, turmeric rhizome, coriander seed, tomato, ginger, bay leaf
- has Wikipedia article: en

## DISH Q4272221
- name: Papeda
- description: Indonesian traditional dish originating from East Indonesian region
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish, meal
- ingredients: broth, sago, table salt, water, garlic
- has Wikipedia article: en

## DISH Q427226
- name: Omurice
- other names: {"zh": "蛋包飯"}
- description: Yōshoku omelet with fried rice filling
- countries: JP
- kinds: food, dish
- ingredients: chicken egg, fried rice
- has Wikipedia article: en, zh

## DISH Q4273466
- name: Paupiette
- description: meat dish
- countries: FR
- kinds: roulade
- has Wikipedia article: en

## DISH Q42749778
- name: Pizza PAT
- other names: {"zh": "Pizza PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: food, pastry, focaccia, baked good, cuisine of the province of Modena, cuisine of Emilia-Romagna

## DISH Q4275510
- name: Makarony po-flotski
- description: Russian dish of pasta and ground meat
- countries: SU
- kinds: dish, pasta dish
- ingredients: meat, pasta
- has Wikipedia article: en

## DISH Q428392
- name: Slatko
- description: fruit preserve
- countries: RS
- kinds: dessert, fruit preserves, conserve
- ingredients: fruit
- has Wikipedia article: en

## DISH Q4285984
- name: Machanka
- description: Belarusian stew
- countries: BY
- kinds: stew

## DISH Q428621
- name: Újfehértói meggypálinka
- countries: HU
- kinds: Pálinka

## DISH Q42894275
- name: Macaron de Joyeuse
- other names: {"fr": "Macaron de Joyeuse"}
- countries: (none)
- kinds: macaron

## DISH Q42935277
- name: Jambon cru du Valais
- description: Swiss ham specialty
- countries: CH
- kinds: raw ham

## DISH Q4293923
- name: Mimosa salad
- other names: {"zh": "银荆花沙拉"}
- description: Eastern European layered cold composed salad of cheese, eggs, canned fish, onion, and mayonnaise
- countries: SU
- cuisines: Russian cuisine, Ukrainian cuisine, Soviet cuisine, Belarusian cuisine
- kinds: egg dish, salad, fish dish, dish
- ingredients: canned fish, onion, Thunnus, canning, herb, mayonnaise, egg as food, butter, potato, cheese
- has Wikipedia article: en, zh

## DISH Q429483
- name: English muffin
- other names: {"zh": "英式瑪芬"}
- description: small, round, flat yeast-leavened bread
- countries: GB
- cuisines: British cuisine
- kinds: yeast bread
- ingredients: wheat flour, yeast, butter, sugar, milk
- has Wikipedia article: en, zh

## DISH Q429518
- name: Cordon bleu
- description: meat and cheese dish
- countries: CH
- kinds: meat dish
- ingredients: Swiss cheeses, veal, chicken as food, pork
- has Wikipedia article: en

## DISH Q43013136
- name: Pâte d'olive de Nice
- other names: {"fr": "Pâte d'olive de Nice"}
- countries: (none)
- kinds: pâté

## DISH Q43013313
- name: Poularde de Bresse
- other names: {"fr": "Poularde de Bresse"}
- countries: (none)
- kinds: poularde

## DISH Q4302793
- name: Morkovcha
- other names: {"zh": "高麗胡蘿蔔菜"}
- description: Russo-Korean carrot salad
- countries: SU
- cuisines: Korean cuisine
- kinds: salad
- ingredients: garlic, Daucus carota subsp. sativus, vegetable oil, condiment, sunflower oil, Daucus, Allium sativum, carrot
- has Wikipedia article: en, zh

## DISH Q43038747
- name: Kaletez
- description: buckwheat pancake in Breton cuisine
- countries: FR
- kinds: buckwheat pancake
- ingredients: Fagopyrum tataricum
- has Wikipedia article: en

## DISH Q4304396
- name: Egg sandwich
- description: sandwich with some kind of egg filling
- countries: (none)
- kinds: sandwich, egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q4305242
- name: Йӳҫӗтнӗ панулми
- other names: {"cv": "Йӳҫӗтнӗ панулми"}
- countries: BY, RU, UA
- kinds: fermented food, dish

## DISH Q430583
- name: Kkakdugi
- other names: {"zh": "蘿蔔泡菜"}
- description: a variation of kimchi
- countries: (none)
- kinds: dish, radish kimchi
- ingredients: Korean radish
- has Wikipedia article: en, zh

## DISH Q4305901
- name: Muzhuzhi
- description: traditional Georgian dish of cold jellied pork
- countries: GE
- kinds: dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q4306732
- name: Муйыл-майы-беремэсе
- other names: {"ru": "Муйыл-майы-беремэсе"}
- countries: (none)
- kinds: Vatrushka

## DISH Q4308183
- name: Муромский калач
- other names: {"ru": "Муромский калач"}
- countries: (none)
- kinds: kalach

## DISH Q431264
- name: Oyster cracker
- other names: {"zh": "牡蠣餅"}
- description: food
- countries: US
- kinds: food, cracker
- has Wikipedia article: en

## DISH Q4313118
- name: Нардек
- other names: {"ru": "нардек"}
- countries: RU, UA
- cuisines: Russian cuisine, Ukrainian cuisine
- kinds: dish, syrup
- ingredients: sucrose, watermelon

## DISH Q431570
- name: Cepelinai
- other names: {"zh": "立陶宛饺子"}
- description: Lithuanian potato dish
- countries: LT
- kinds: national dish, potato pyzy, potato-dough dumpling
- ingredients: potato, minced meat
- has Wikipedia article: en, zh

## DISH Q431640
- name: Teppanyaki
- other names: {"zh": "鐵板燒"}
- description: dish
- countries: JP
- cuisines: Japanese cuisine
- kinds: yakimono
- has Wikipedia article: en, zh

## DISH Q432001
- name: Túró Rudi
- other names: {"zh": "乾酪起司棒"}
- description: curd cheese coated in chocolate
- countries: HU
- kinds: snack, chocolate bar, dairy
- has Wikipedia article: en, zh

## DISH Q4320515
- name: Oatmeal raisin cookie
- description: drop cookie with oatmeal and raisins mixed into the dough
- countries: (none)
- kinds: oatmeal cookie
- ingredients: rolled oats, raisin
- has Wikipedia article: en

## DISH Q432308
- name: Papa a la Hancaina
- other names: {"zh": "万卡约土豆"}
- description: Peruvian appetizer of boiled yellow potatoes in a spicy, creamy sauce
- countries: PE
- kinds: dish, potato dish
- has Wikipedia article: en, zh

## DISH Q43235009
- name: Matrosenfleisch
- other names: {"de": "Matrosenfleisch"}
- countries: (none)
- kinds: dish, beef dish

## DISH Q43250232
- name: Огуречник
- other names: {"ru": "огуречник"}
- description: Ukrainian cuisine
- countries: (none)
- kinds: soup
- ingredients: Salzgurke

## DISH Q43252617
- name: Τρίγωνο Πανοράματος
- other names: {"el": "Τρίγωνο Πανοράματος"}
- countries: GR
- kinds: confectionery
- ingredients: syrup, cream

## DISH Q43254013
- name: Χοντρομπίγουλη
- other names: {"el": "Χοντρομπίγουλη"}
- countries: GR
- kinds: soup, tomato soup

## DISH Q43359837
- name: Steirisches Backhendl
- other names: {"de": "Steirisches Backhendl"}
- countries: AT
- kinds: dish

## DISH Q43372008
- name: Totché
- description: A traditional cake from the Canton of Jura, in Switzerland
- countries: CH
- kinds: food, pie, tart
- ingredients: yeast bread, sour cream, egg as food
- has Wikipedia article: en

## DISH Q4337658
- name: Ossetian pies
- countries: (none)
- cuisines: Ossetian cuisine
- kinds: pie
- ingredients: dough
- has Wikipedia article: en

## DISH Q4337660
- name: Ossetian cheese
- description: type of cheese common in the North Caucasus
- countries: (none)
- cuisines: Ossetian cuisine
- kinds: cheese
- has Wikipedia article: en

## DISH Q43378784
- name: Nagoya curry udon
- countries: JP
- kinds: curry udon, noodle dish

## DISH Q4338177
- name: Seuter
- other names: {"nl": "seuter"}
- countries: (none)
- kinds: potato dish

## DISH Q43422
- name: St. Martin's Croissants
- other names: {"zh": "圣马丁羊角面包"}
- description: Polish sweetrolls
- countries: PL
- kinds: croissant
- has Wikipedia article: en

## DISH Q4345821
- name: Blodplättar
- other names: {"zh": "牛血鬆餅"}
- description: dish served in Finland, Estonia, Sweden and Norway
- countries: (none)
- kinds: pancake
- ingredients: rye flour, white sugar, wheat flour, clove, table salt, milk, blood
- has Wikipedia article: en

## DISH Q4346753
- name: Hiyayakko
- other names: {"zh": "奴豆腐"}
- description: Japanese tofu dish
- countries: JP
- kinds: tofu
- has Wikipedia article: en, zh

## DISH Q4348342
- name: Nicotine gum
- other names: {"zh": "尼古丁口香糖"}
- description: type of chewing gum that delivers nicotine to the body
- countries: (none)
- kinds: chewing gum
- has Wikipedia article: en, zh

## DISH Q435026
- name: Altbrot
- description: German term: bread that is left over in bakeries and in the trade and that is rejected as food
- countries: (none)
- kinds: concept, bread

## DISH Q4350424
- name: Fish amok
- other names: {"zh": "魚荷"}
- description: Cambodian steamed fish curry
- countries: KH
- kinds: steamed curry, fish curry
- ingredients: coconut cream, kroeung, egg as food, fish
- has Wikipedia article: en

## DISH Q4351446
- name: Pearl barley porridge
- description: a dish common in Russian cuisine
- countries: RU
- kinds: porridge
- ingredients: pearl barley

## DISH Q43580216
- name: Chhenabara
- description: Bengali confectionery
- countries: (none)
- kinds: confectionery
- ingredients: syrup, chhena
- has Wikipedia article: en

## DISH Q43635908
- name: Takomaki
- other names: {"de": "Takomaki"}
- description: dish
- countries: (none)
- kinds: dish

## DISH Q43668382
- name: Banana soy yogurts
- countries: (none)
- kinds: soy yogurt

## DISH Q43668566
- name: Banana jam
- description: jam made from bananas
- countries: (none)
- kinds: fruit jam
- ingredients: banana

## DISH Q43668658
- name: Strawberry biscuit
- countries: (none)
- kinds: biscuit

## DISH Q43668703
- name: Strawberry cheesecake
- countries: (none)
- kinds: cheesecake

## DISH Q43668757
- name: Strawberry compote
- countries: (none)
- kinds: compote

## DISH Q43668938
- name: Onion jam
- countries: (none)
- kinds: relish, confit, vegetable jam
- ingredients: onion

## DISH Q43669016
- name: Orange jam
- description: jam made from oranges
- countries: (none)
- kinds: fruit jam
- ingredients: orange

## DISH Q43669693
- name: Leek pie
- countries: (none)
- kinds: leek, pie

## DISH Q43670051
- name: Lemon jam
- description: jam made from lemons
- countries: (none)
- kinds: fruit jam

## DISH Q4367658
- name: Падкагыль
- other names: {"mrj": "Падкагыль"}
- countries: (none)
- cuisines: Mari cuisine
- kinds: stuffed pasta
- ingredients: porridge, dough, onion, meat

## DISH Q43683476
- name: Lavender honey
- countries: (none)
- kinds: honey

## DISH Q4368675
- name: Pozharsky cutlet
- description: Russian meat dish
- countries: RU
- cuisines: Russian cuisine
- kinds: patty, chicken dish, veal dish
- ingredients: white bread, chicken as food, butter, cream
- has Wikipedia article: en

## DISH Q43688521
- name: Lemon sorbet
- countries: (none)
- kinds: sorbet

## DISH Q436943
- name: Altenburger
- description: German soft cheese
- countries: DE
- kinds: goat cheese, white mold-rind cheese, cheese
- ingredients: goat milk

## DISH Q43731351
- name: Boiled dog meat
- other names: {"zh": "白切狗肉"}
- countries: (none)
- kinds: dish
- ingredients: dog meat

## DISH Q43731700
- name: Braised dog meat
- other names: {"zh": "走油狗肉"}
- countries: (none)
- kinds: dish
- ingredients: dog meat
