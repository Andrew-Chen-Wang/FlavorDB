# Review batch names-023

## DISH Q137581504
- name: History of pizza in Mexico
- countries: (none)

## DISH Q137587225
- name: 고추장찌개
- other names: {"ko": "고추장찌개"}
- countries: (none)
- kinds: jjigae

## DISH Q137593130
- name: Arròs de colls-i-punys
- other names: {"ca": "Arròs de colls-i-punys"}
- countries: (none)
- kinds: rice dish
- ingredients: rice as food, offal

## DISH Q137593679
- name: Chickpea wrap
- description: wrap made with chickpeas
- countries: (none)
- kinds: dish

## DISH Q137602246
- name: Overnight oats
- countries: (none)
- kinds: oatmeal porridge

## DISH Q137602787
- name: Lidded bowls with top design, overglaze enamels
- description: Pottery by Rosanjin
- countries: (none)
- kinds: tableware, Mukōzuke
- ingredients: ceramic glaze, porcelain

## DISH Q137602972
- name: Porcelain bowl with Chinese character, overglaze enamels
- description: Pottery by Rosanjin
- countries: (none)
- kinds: tableware, Mukōzuke
- ingredients: ceramic glaze, porcelain

## DISH Q137605428
- name: Halagknerken
- other names: {"frr": "Halagknerken"}
- countries: (none)
- kinds: cookie

## DISH Q137609355
- name: Pineapple shrimp balls
- other names: {"zh": "鳳梨蝦球"}
- description: Taiwanese dish
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: seafood dish, dish, human food
- ingredients: pineapple, shrimp and prawn as food, mayonnaise
- has Wikipedia article: en

## DISH Q1376161
- name: Topfenstrudel
- description: Austrian pastry
- countries: (none)
- kinds: pastry, dish
- ingredients: quark

## DISH Q137639668
- name: Pa foradat
- other names: {"ca": "pa foradat"}
- countries: (none)
- kinds: dish
- ingredients: spice, bread

## DISH Q137649856
- name: Xúp cua
- other names: {"mul": "Xúp cua"}
- description: Vietnamese crab soup
- countries: (none)
- kinds: soup, Vietnamese cuisine, seafood dish

## DISH Q137682750
- name: Bantal biu
- other names: {"ban": "Bantal biu"}
- countries: ID
- kinds: snack, human food

## DISH Q137690873
- name: Anishi
- description: Naga delicacy made of fermented leaves of the Colocasia genus
- countries: (none)
- kinds: dish
- ingredients: Colocasia, leaf
- has Wikipedia article: en

## DISH Q137691104
- name: Pumpum soup
- countries: TR
- cuisines: Turkish cuisine
- kinds: soup
- ingredients: maize flour, black pepper, kavurma, crushed red pepper, broth, butter, table salt

## DISH Q1376963
- name: Hortolans a la provençal
- other names: {"ca": "Hortolans a la provençal"}
- countries: (none)
- kinds: dish
- ingredients: Armagnac, Ortolan Bunting

## DISH Q137697985
- name: Sinabawan nin Agta
- other names: {"bcl": "Sinabawan nin Agta"}
- countries: (none)
- kinds: dish

## DISH Q137698162
- name: Som pa noy
- countries: LA
- kinds: human food

## DISH Q137708636
- name: Keripik kelakai
- other names: {"id": "Keripik kelakai"}
- countries: ID
- kinds: snack

## DISH Q137708647
- name: Juhu taya
- other names: {"id": "Juhu taya"}
- countries: (none)
- kinds: soup, food
- ingredients: leaf, fish

## DISH Q137708753
- name: Dange (kue)
- other names: {"id": "Dange (kue)"}
- countries: ID
- kinds: kue
- ingredients: glutinous rice flour, Cocos nucifera, sugar

## DISH Q137708759
- name: Tampi (kue)
- other names: {"id": "Tampi (kue)"}
- countries: ID
- kinds: kue
- ingredients: glutinous rice flour

## DISH Q137714277
- name: Biff Strindberg
- other names: {"sv": "Biff Strindberg"}
- countries: SE
- kinds: dish

## DISH Q137716237
- name: Kaluit
- other names: {"id": "Kaluit"}
- countries: ID
- kinds: kue
- ingredients: glutinous rice flour, palm sugar, Cocos nucifera

## DISH Q137729017
- name: Bakso solo
- other names: {"id": "Bakso solo"}
- countries: ID
- kinds: bakso, food, dish, street food, jajan pasar
- ingredients: beef, bakso, noodle, soup

## DISH Q137730537
- name: Jadah blondo
- description: traditional food from solo
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, type of food or dish
- ingredients: coconut milk, glutinous rice

## DISH Q137731959
- name: Shrimp kletek
- description: traditional food from Jambi, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q137732521
- name: Mica (salume)
- description: Piedmontese kind of salami
- countries: IT
- kinds: salume

## DISH Q137733867
- name: Rewadi
- description: Indian sweet from jaggery and sesame seeds
- countries: (none)
- kinds: sesame seed candy

## DISH Q137734212
- name: Cabbage pie
- description: type of pie filled with cabbage
- countries: (none)
- kinds: pie, appetizer
- ingredients: white cabbage

## DISH Q137734312
- name: Panspermia
- countries: (none)
- kinds: porridge, dish

## DISH Q137769736
- name: Hún-kué
- other names: {"zh": "粉粿 (臺灣)"}
- countries: TW
- cuisines: Taiwanese cuisine
- kinds: Category:Taiwanese desserts, food
- has Wikipedia article: zh

## DISH Q137778889
- name: Bread loaf
- description: western style style of bread prepared in oblong shape
- countries: (none)
- kinds: bread, loaf

## DISH Q137785263
- name: Frozen salad
- description: frozen dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q1377879
- name: Edamame
- other names: {"zh": "毛豆"}
- description: preparation of soybeans eaten in East Asian cuisines
- countries: JP
- kinds: dish, snack, soy bean
- ingredients: soy bean
- has Wikipedia article: en, zh

## DISH Q137792091
- name: Pempek Kapal Selam
- description: a variation of Pempek with egg inside
- countries: ID
- cuisines: Palembang cuisine, Indonesian cuisine
- kinds: fish dish, human food, traditional food, type of food or dish, food, dish
- ingredients: garlic, chicken egg, brown sugar, Spanish mackerel, cucumber, tapioca, bird's eye chili, Tamarindus indica, flour, water

## DISH Q137794382
- name: Galette des rois individuelle
- other names: {"fr": "galette des rois individuelle"}
- countries: (none)
- kinds: king cake
- ingredients: butter, puff pastry, sugar

## DISH Q137798679
- name: Furofuki fig
- description: Cuisine by fig
- countries: (none)
- kinds: fruit dish, recipe, Japanese cuisine
- ingredients: Shiromiso, yuzufruit, chicken egg, fig, mirin, sugar

## DISH Q137798950
- name: Tape ketan putih Karo
- other names: {"id": "tape ketan putih Karo"}
- countries: ID
- kinds: dish, human food, type of food or dish
- ingredients: fermentation starter, glutinous rice, sugar

## DISH Q137798967
- name: Bebek tumis Karo
- other names: {"id": "bebek tumis Karo"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: turmeric leaf, grated coconut, duck, coconut milk, Cinnamomum verum, Murraya koenigii, Cymbopogon citratus

## DISH Q137798978
- name: Gulai gundur manuk
- other names: {"id": "gulai gundur manuk"}
- countries: (none)
- kinds: traditional food, dish, Indonesian cuisine

## DISH Q137799027
- name: Nurung kerah
- other names: {"id": "nurung kerah"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: shallot, garlic, tomato, siling labuyo, Andaliman, Aleurites moluccanus, coconut milk, Cucurbita moschata, smoked fish, Curcuma longa, ginger, Welsh onion

## DISH Q137799044
- name: Tape ketan hitam khas Karo
- other names: {"id": "tape ketan hitam khas Karo"}
- countries: ID
- kinds: dish, human food, type of food or dish
- ingredients: fermentation starter, glutinous rice, sugar

## DISH Q137799057
- name: Gule Kuta-kuta
- other names: {"id": "Gule Kuta-kuta"}
- countries: ID
- kinds: dish, traditional food, Indonesian cuisine

## DISH Q137799075
- name: Cincang Bohan
- other names: {"id": "Cincang Bohan"}
- countries: ID
- kinds: traditional food, dish, Indonesian cuisine

## DISH Q137799082
- name: Cimpa daun singkut
- other names: {"id": "Cimpa daun singkut"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: Cimpa, dish

## DISH Q137799087
- name: Anyang pakis
- other names: {"id": "Anyang pakis"}
- countries: ID
- kinds: traditional food, dish

## DISH Q137799088
- name: Lemang-lemang chicken
- description: the name for the Karo tribe's typical chicken curry dish
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: Kaffir Lime Leaf, leek, chicken as food, coconut milk, Alpinia galanga, Cymbopogon citratus, table salt

## DISH Q137799116
- name: Cipera ayam kampung
- other names: {"id": "Cipera ayam kampung"}
- countries: (none)
- kinds: dish, Indonesian cuisine

## DISH Q137799123
- name: Lemang ketan hitam
- other names: {"id": "Lemang ketan hitam"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, human food, type of food or dish
- ingredients: glutinous rice

## DISH Q137799140
- name: Manuk getah
- other names: {"id": "manuk getah"}
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, cuisine, human food, type of food or dish
- ingredients: Kaffir Lime Leaf, grated coconut, Andaliman, bird's eye chili, Allium ascalonicum, Citrus × aurantiifolia, Cymbopogon citratus, blood, chicken

## DISH Q137799157
- name: White glutinous rice lemang
- description: Karo cuisine
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, human food, type of food or dish
- ingredients: coconut milk, glutinous rice, table salt

## DISH Q137799219
- name: Arsik nurung ikan mas
- other names: {"id": "Arsik nurung ikan mas"}
- countries: (none)
- kinds: dish

## DISH Q137800680
- name: Bolo-rainha
- description: Portuguese king cake without candied fruit
- countries: PT
- kinds: king cake, cake
- ingredients: dried fruit, egg as food, yeast, flour, sugar

## DISH Q137802518
- name: Assyrian Cookie
- description: Traditional spiced pastry from the Mardin region of Turkiye, associated with Assyrian culture.
- countries: (none)
- kinds: çörek

## DISH Q137803968
- name: Custard powder
- countries: (none)
- kinds: imitation custard
- has Wikipedia article: en

## DISH Q137804409
- name: Ladu Pariaman
- other names: {"id": "Ladu Pariaman"}
- countries: ID
- kinds: snack, local food

## DISH Q137804829
- name: Icebox cookie
- description: type of cookie
- countries: (none)
- kinds: food, cookies, biscuits, crackers
- ingredients: chicken egg, flour, butter, sugar
- has Wikipedia article: en

## DISH Q137805698
- name: Ciaurrina
- description: Pastries of Sicily
- countries: IT
- cuisines: Sicilian cuisine
- kinds: Cosi di ficu PAT, food, tradition, pastry

## DISH Q137807970
- name: Sautéed leek
- countries: (none)
- kinds: dish

## DISH Q137808644
- name: Tomme de Berry au pesto basilic
- other names: {"fr": "tomme de Berry au pesto basilic"}
- countries: FR
- kinds: cheese
- ingredients: cow's milk

## DISH Q137810203
- name: Ufaq as
- countries: (none)
- kinds: dish

## DISH Q137816339
- name: Cakalang santang
- description: traditional food from Manado
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q137816648
- name: Es brenebon
- description: traditional drink from Manado
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q137816671
- name: Perkedel nike
- description: traditional food from Manado
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q137822471
- name: Chao long
- description: Filipino noodle soup dish
- countries: (none)
- kinds: food, noodle soup
- has Wikipedia article: en

## DISH Q137824598
- name: Rokka
- other names: {"fi": "Rokka"}
- countries: (none)
- kinds: soup, food

## DISH Q137825795
- name: Poetoepap
- other names: {"af": "Poetoepap"}
- countries: ZA
- cuisines: South African cuisine
- kinds: human food

## DISH Q137826007
- name: Olutpaisti
- other names: {"fi": "Olutpaisti"}
- countries: (none)
- kinds: dish

## DISH Q137826008
- name: Palermon pasta
- other names: {"fi": "Palermon pasta"}
- countries: (none)
- kinds: dish

## DISH Q137826009
- name: Munavelli
- other names: {"fi": "Munavelli"}
- countries: (none)
- kinds: dish

## DISH Q137826010
- name: Bataattilaatikko
- other names: {"fi": "Bataattilaatikko"}
- countries: (none)
- kinds: dish

## DISH Q137826011
- name: Kaalisalaatti
- other names: {"fi": "Kaalisalaatti"}
- countries: (none)
- kinds: dish

## DISH Q137826012
- name: Sienisalaatti
- other names: {"fi": "Sienisalaatti"}
- countries: (none)
- kinds: dish

## DISH Q137826013
- name: Sienimuhennos
- other names: {"fi": "Sienimuhennos"}
- countries: (none)
- kinds: dish

## DISH Q137826014
- name: Korvasienikeitto
- other names: {"fi": "Korvasienikeitto"}
- countries: (none)
- kinds: dish

## DISH Q137826015
- name: Kantarellikeitto
- other names: {"fi": "Kantarellikeitto"}
- countries: (none)
- kinds: dish

## DISH Q137826016
- name: Palapaisti
- other names: {"fi": "Palapaisti"}
- countries: (none)
- kinds: dish

## DISH Q137826017
- name: Uunimakkara
- other names: {"fi": "Uunimakkara"}
- countries: (none)
- kinds: dish

## DISH Q137826019
- name: Uunilohi
- other names: {"fi": "Uunilohi"}
- countries: (none)
- kinds: dish

## DISH Q137826021
- name: Kebabkiusaus
- other names: {"fi": "Kebabkiusaus"}
- countries: (none)
- kinds: dish

## DISH Q137826023
- name: Herring à la Russe
- countries: (none)
- kinds: dish

## DISH Q137826026
- name: Havaijinleike
- other names: {"fi": "Havaijinleike"}
- countries: (none)
- kinds: dish

## DISH Q137826028
- name: Kinkkukiusaus
- other names: {"fi": "Kinkkukiusaus"}
- countries: (none)
- kinds: dish

## DISH Q137826226
- name: Fantasiakakku
- other names: {"fi": "Fantasiakakku"}
- countries: (none)
- kinds: cake

## DISH Q137826227
- name: Maustekakku
- other names: {"fi": "Maustekakku"}
- countries: (none)
- kinds: cake

## DISH Q137826228
- name: Piimäkakku
- other names: {"fi": "Piimäkakku"}
- countries: (none)
- kinds: cake

## DISH Q137826229
- name: Taatelikakku
- other names: {"fi": "Taatelikakku"}
- countries: (none)
- kinds: cake

## DISH Q137826230
- name: Britakakku
- other names: {"fi": "britakakku"}
- countries: SE
- kinds: cake

## DISH Q137826239
- name: Hakkoopiirakka
- other names: {"fi": "Hakkoopiirakka"}
- countries: (none)
- kinds: pie

## DISH Q137826241
- name: Rahkapiirakka
- other names: {"fi": "Rahkapiirakka"}
- countries: (none)
- kinds: pie

## DISH Q137826242
- name: Sienipiirakka
- other names: {"fi": "Sienipiirakka"}
- countries: (none)
- kinds: pie

## DISH Q137826250
- name: Kateleipä
- other names: {"fi": "Kateleipä"}
- countries: (none)
- kinds: bread

## DISH Q137826251
- name: Vuokaleipä
- other names: {"fi": "Vuokaleipä"}
- countries: (none)
- kinds: bread

## DISH Q137826252
- name: Ruisrevitty
- other names: {"fi": "Ruisrevitty"}
- countries: (none)
- kinds: bread

## DISH Q137834536
- name: Sambal rica iris
- description: traditional food from Manado
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q137834569
- name: Grilled oci fish
- description: traditional food from Manado
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q137834678
- name: Cakalang sous
- description: traditional food from Manado
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q137839452
- name: 두바이 쫀득 쿠키
- other names: {"ko": "두바이 쫀득 쿠키"}
- countries: KR
- kinds: dessert

## DISH Q137842186
- name: Miguelito Chilito
- other names: {"es": "Miguelito Chilito"}
- countries: MX
- kinds: confectionery
- ingredients: chamoy, chili powder

## DISH Q137844191
- name: Муравейник
- other names: {"ru": "муравейник"}
- countries: SU
- kinds: torte

## DISH Q137844616
- name: Bowls, underglaze cobalt and overglaze enamels
- description: Pottery by Rosanjin
- countries: (none)
- kinds: tableware, Mukōzuke
- ingredients: ceramic glaze, porcelain

## DISH Q137847309
- name: Le Chèvre de Wavreumont
- description: Belgian cheese
- countries: BE
- kinds: goat cheese, organic product, pasteurized milk cheese, cheese
- ingredients: goat milk

## DISH Q137856615
- name: Onion stick
- description: traditional food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q137856731
- name: Kuah asam
- description: traditional food from Manado
- countries: ID
- cuisines: Indonesian cuisine
- kinds: food, dish, traditional food

## DISH Q137862828
- name: Wikipedia Day NYC 2024 Spherical Wikicake
- description: Spherical Wikipedia logo cake created for Wikipedia Day NYC 2024
- countries: (none)
- kinds: cake, work of art

## DISH Q137883935
- name: La bouillie
- description: A Chadian breakfast porridge
- countries: TD
- kinds: breakfast, porridge, Chadian cuisine
- has Wikipedia article: en

## DISH Q137884965
- name: Moules farcies à la sétoise
- description: dish from Languedoc
- countries: FR
- kinds: dish
- ingredients: tomato sauce, sausage meat, Mytilus galloprovincialis, aioli, white wine

## DISH Q137905119
- name: Txu'ü
- other names: {"pt-br": "Txu'ü"}
- countries: BR
- kinds: indigenous cuisine of the Americas, human food

## DISH Q137908289
- name: Cream of crab soup
- description: A soup from the Eastern shore of Maryland
- countries: US
- kinds: soup, seafood
- has Wikipedia article: en

## DISH Q137908295
- name: Maryland crab soup
- description: A soup of tomatoes, vegetables, and blue crab meat
- countries: US
- kinds: soup, seafood
- has Wikipedia article: en

## DISH Q137915703
- name: Saus
- other names: {"es": "Saus"}
- countries: PA
- kinds: dish

## DISH Q137916343
- name: Bombay sandwich
- description: toasted sandwich
- countries: (none)
- kinds: sandwich, toasted sandwich
- ingredients: boiled potatoes, Green chutney, tomato, onion, grated cheese, sev, cucumber, white bread, Chaat masala, Capsicum, beet, butter
- has Wikipedia article: en

## DISH Q137921543
- name: Dundun
- description: fried yam dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q137921897
- name: Masa
- description: Nigerian food
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q137924780
- name: Kwon kal
- description: traditional staple food from Northern Uganda
- countries: UG
- kinds: food

## DISH Q137924936
- name: Ajabu ngwen
- description: traditional royal delicacy of the Acholi/Luo people
- countries: UG
- kinds: food

## DISH Q137927658
- name: Currant vla
- description: type of vla made with currants
- countries: (none)
- kinds: type of food or dish
- ingredients: currant, egg as food, sugar, milk

## DISH Q137944812
- name: Lanxi Beef Noodle
- other names: {"zh": "兰溪牛肉面"}
- description: noodle dish from Hangzhou, China
- countries: (none)
- kinds: noodle soup
- has Wikipedia article: zh

## DISH Q137946312
- name: Salmon Roe
- description: Menu in Akindo Sushiro
- countries: (none)
- kinds: sushi, product

## DISH Q137946342
- name: Triple Shrimp
- description: Menu in Akindo Sushiro
- countries: (none)
- kinds: sushi, product

## DISH Q137946445
- name: Triple Salmon
- description: Menu in Akindo Sushiro
- countries: (none)
- kinds: sushi, product

## DISH Q137946488
- name: Triple Tuna
- description: Menu in Akindo Sushiro
- countries: (none)
- kinds: sushi, product

## DISH Q137946493
- name: Broiled Fresh Salmon
- description: Menu in Akindo Sushiro
- countries: (none)
- kinds: sushi, product

## DISH Q137969108
- name: Japanese Egg Omelet
- description: Menu in Sushiro
- countries: (none)
- kinds: sushi, product

## DISH Q137971153
- name: Marguerita da Pizzaria Speranza
- other names: {"pt-br": "Marguerita da Pizzaria Speranza"}
- countries: (none)

## DISH Q137971167
- name: Beirute do Frevinho
- other names: {"pt-br": "beirute do Frevinho"}
- countries: BR
- kinds: sandwich

## DISH Q137971175
- name: Pão de queijo da Hadock Lobo
- other names: {"pt": "pão de queijo da Hadock Lobo"}
- countries: BR

## DISH Q137971184
- name: Polpettone do Jardim de Napoli
- other names: {"pt-br": "polpettone do Jardim de Napoli"}
- countries: BR

## DISH Q137971192
- name: Sanduíche de mortadela do Mercado Municipal Paulistano
- other names: {"pt": "sanduíche de mortadela do Mercado Municipal Paulistano"}
- countries: BR
- kinds: sandwich

## DISH Q137971251
- name: Bisteca do Sujinho
- other names: {"pt": "bisteca do Sujinho"}
- countries: (none)
- kinds: dish

## DISH Q137971298
- name: Kalvlever Anglais
- other names: {"sv": "Kalvlever Anglais"}
- countries: (none)
- kinds: meat dish

## DISH Q13798142
- name: Maagpepermunt
- other names: {"nl": "maagpepermunt"}
- countries: (none)
- kinds: candy, mint

## DISH Q13798201
- name: Maanzaadbrood
- other names: {"nl": "maanzaadbrood"}
- countries: (none)
- kinds: bread

## DISH Q137995719
- name: Kuddelfleck
- description: traditional Luxembourgish dish made of boiled tripe
- countries: LU
- kinds: dish
- ingredients: intestine

## DISH Q137998824
- name: Laup
- description: Norwegian bakery product
- countries: NO
- kinds: bun

## DISH Q138003779
- name: Maizenakoekje
- other names: {"nl": "maizenakoekje"}
- countries: SR
- kinds: cookie, type of food or dish
- ingredients: vanilla sugar, corn starch, nonpareils, egg as food, butter, sugar

## DISH Q138011108
- name: Baked beans pizza
- description: pizza topped with baked beans
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q138013674
- name: Bulle Cake
- description: Swiss chocolate-coated walnut-caramel pastry from Bulle, canton of Fribourg
- countries: CH
- cuisines: Swiss cuisine
- kinds: pastry

## DISH Q138024294
- name: Pickle pizza
- description: variety of pizza
- countries: (none)
- kinds: food, dish
- ingredients: pickled cucumber
- has Wikipedia article: en

## DISH Q138024534
- name: Café com mistura
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q138030970
- name: Ash-e abbasali
- description: Iranian dish from Kermanshah County
- countries: (none)
- kinds: Aush

## DISH Q1380492
- name: Gefillde
- description: potato dish
- countries: (none)
- kinds: potato dish
- has Wikipedia article: en

## DISH Q138076358
- name: Yaki-onigiri
- description: onigiri prepared by grilling
- countries: (none)
- kinds: dish, rice dish

## DISH Q138132161
- name: Chiriuchu
- other names: {"es": "Chiriuchu"}
- countries: (none)
- kinds: dish

## DISH Q138139796
- name: Plat à base de banane plantain
- other names: {"fr": "plat à base de banane plantain"}
- countries: (none)
- kinds: dish by ingredient, dish
- ingredients: cooking banana

## DISH Q13818254
- name: Mastel
- countries: BE
- kinds: pastry, regional product
- ingredients: flour, butter, cinnamon, sugar, milk

## DISH Q138213
- name: Freedom fries
- other names: {"zh": "自由薯條"}
- description: politically motivated renaming of French fries in the United States
- countries: (none)
- kinds: name change, fries
- has Wikipedia article: en, zh

## DISH Q138227720
- name: Sekahedelmäkeitto
- other names: {"fi": "Sekahedelmäkeitto"}
- countries: (none)
- kinds: dessert

## DISH Q138227722
- name: Marjamämmi
- other names: {"fi": "Marjamämmi"}
- countries: (none)
- kinds: dessert

## DISH Q138227991
- name: Sitruunapulla
- other names: {"fi": "Sitruunapulla"}
- countries: (none)
- kinds: pastry

## DISH Q138227993
- name: Kaneliässä
- other names: {"fi": "kaneliässä"}
- countries: (none)
- kinds: pastry

## DISH Q13824114
- name: Meelspijs
- other names: {"nl": "meelspijs"}
- countries: (none)
- kinds: dish

## DISH Q138298720
- name: Pantollo pamarrasan
- other names: {"id": "Pantollo pamarrasan"}
- countries: ID
- kinds: dish

## DISH Q138303664
- name: Ayimolou
- other names: {"fr": "Ayimolou"}
- countries: TG
- kinds: dish
- ingredients: bean, rice

## DISH Q138304105
- name: Yen Thongba
- description: Meitei method of cooking chicken
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q138306611
- name: Nga Thongba
- description: Meitei fish curry
- countries: (none)
- kinds: fish curry
- has Wikipedia article: en

## DISH Q138307180
- name: Sana Thongba
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q138314674
- name: Maribruni
- description: Traditional dessert from Cartagena, Spain
- countries: ES
- cuisines: cuisine of Cartagena, Spain
- kinds: dessert
- ingredients: puff pastry, jelly, Pasta di mandorle PAT, candied fruit, Cabell d'àngel

## DISH Q138315412
- name: Galilean balls
- description: Traditional dish from Pozo Estrecho (Cartagena, Spain), consisting of a stew with meatballs
- countries: ES
- cuisines: cuisine of Cartagena, Spain
- kinds: dish
- ingredients: meatball, guiso

## DISH Q138329556
- name: Tan Ngang
- description: traditional Meitei food
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q138329557
- name: Chamthong
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q138330528
- name: Mah Mee
- other names: {"de": "Mah Mee"}
- countries: (none)
- kinds: noodle dish

## DISH Q138337365
- name: Maroi Bori Thongba
- description: Lentil and chive curry from Manipur
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q138339454
- name: Beef gulai
- countries: ID
- cuisines: Indonesian cuisine, cuisine
- kinds: gulai, type of food or dish, food, dish
- ingredients: turmeric leaf, Kaffir Lime Leaf, garlic, clove, ginger, cardamom, star anise, Aleurites moluccanus, coconut milk, Alpinia galanga, Allium ascalonicum, beef, Curcuma longa, Cymbopogon citratus, Allium sativum

## DISH Q138384337
- name: Ordubad gayghanag
- description: Traditional dish of Ordubad
- countries: (none)
- kinds: dish

## DISH Q13840832
- name: Hard-boiled egg
- description: boiled egg with solidified white and yolk
- countries: (none)
- kinds: food, dish, boiled egg
- ingredients: chicken egg, egg as food

## DISH Q138413232
- name: Ajmokac
- description: traditional dish of Serbian and Vojvodina cuisine
- countries: (none)
- kinds: dish
- ingredients: flour, cream, milk
- has Wikipedia article: en

## DISH Q138413396
- name: Chicken with sesame
- description: one of the most popular Chinese-American dishes
- countries: CN, US
- kinds: dish
- ingredients: Sesamum indicum, chicken as food, oil painting

## DISH Q138413545
- name: Creamy porridge
- description: Montenegrin traditional dish
- countries: ME
- kinds: dish
- ingredients: kaymak, flour, table salt, potato, cheese

## DISH Q138465477
- name: Fisherman's soup from Baja
- description: type of fish soup from Baja, Hungary
- countries: (none)
- kinds: food, fisherman's soup
- ingredients: onion, paprika, Cascabel chili, noodle, Cyprinus carpio, table salt, water

## DISH Q138479165
- name: Soft-shelled taco
- description: corn or flour tortillas cooked to a softer state than a hard taco – usually by grilling or steaming
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q138498636
- name: Faschingskrapfen
- other names: {"de": "Faschingskrapfen"}
- countries: (none)
- kinds: Krapfen

## DISH Q138510907
- name: Μελιτζανόπιτα
- other names: {"el": "Μελιτζανόπιτα"}
- countries: GR
- kinds: food, pie

## DISH Q138528332
- name: Fried ramyeon
- countries: (none)
- kinds: fried noodle, ramyeon

## DISH Q138537728
- name: Eight Immortals Crossing the Sea Gamboling Around the Arhat
- description: Confucian cuisine seafood dish
- countries: (none)
- kinds: Shandong cuisine, Chinese aristocrat cuisine, seafood dish
- ingredients: Four sea delicacies, shrimp and prawn as food, Jinhua ham, chicken as food, shark cartilage
- has Wikipedia article: en

## DISH Q138541977
- name: Santa Clara pastry
- description: thin pastry sweet filled with an egg and almond cream
- countries: (none)
- kinds: dish

## DISH Q138542087
- name: Strawberry meringue
- description: layered dessert of meringue, cream, and fresh strawberries
- countries: (none)
- kinds: dish

## DISH Q138542172
- name: Pé de moça
- description: creamy peanut and condensed milk candy cut into tablets
- countries: (none)
- kinds: brittle

## DISH Q138542190
- name: Cheese and plum sweet
- description: traditional sweet combining cheese and plum in syrup
- countries: (none)
- kinds: dish

## DISH Q138542191
- name: Beija-me depressa
- description: small coconut and condensed milk sweet
- countries: (none)
- kinds: dish

## DISH Q138542192
- name: Cassava and coconut cake
- description: dense cake of grated cassava and coconut of quilombola origin
- countries: (none)
- kinds: dish

## DISH Q138542193
- name: Cassava cake
- description: moist and dense cake made from grated cassava
- countries: (none)
- kinds: dish

## DISH Q138542194
- name: Corn cake in the husk
- description: fresh corn batter baked or steamed in its own husk
- countries: (none)
- kinds: dish

## DISH Q138542196
- name: Taro leaf cake
- description: cake that uses dehydrated taro leaf in the batter
- countries: (none)
- kinds: dish

## DISH Q138542197
- name: Bons-bocados
- description: Portuguese baked sweet made of coconut, cheese, and eggs
- countries: (none)
- kinds: dish

## DISH Q138542198
- name: Cupuaçu cream
- description: sweet cream made with the pulp of the Amazonian fruit cupuaçu
- countries: (none)
- kinds: dish

## DISH Q138542199
- name: Forrumba
- description: coconut and rapadura candy of possible African origin
- countries: (none)
- kinds: dish

## DISH Q138542200
- name: Chunky guava paste
- description: guava paste sweet with chunks of fruit
- countries: (none)
- kinds: dish

## DISH Q138542201
- name: Cambuci mousse
- description: dessert made with the cambuci fruit native to the Atlantic Forest
- countries: (none)
- kinds: dish

## DISH Q138542202
- name: Sweet pamonha
- description: sweet corn paste steamed in its own husk
- countries: (none)
- kinds: dish

## DISH Q138542203
- name: Toasted sponge cake
- description: sliced sponge cake toasted in the oven, served as a biscuit
- countries: (none)
- kinds: dish

## DISH Q138542204
- name: Lard pastry
- description: old Portuguese sweet that includes lard in its preparation
- countries: (none)
- kinds: dish

## DISH Q138542205
- name: Fermented cassava cake
- description: cake of fermented cassava batter (puba) baked in leaves
- countries: (none)
- kinds: dish

## DISH Q138542206
- name: Cassava fritter
- description: fried cassava dough filled with dried meat or cheese
- countries: (none)
- kinds: dish

## DISH Q138542207
- name: Bean broth cup
- description: seasoned black bean broth served in small cups
- countries: (none)
- kinds: dish

## DISH Q138542208
- name: Brazilian churros
- description: cylindrical fried dough filled with dulce de leche
- countries: (none)
- kinds: dish

## DISH Q138542209
- name: Brazilian esfiha
- description: savory pastry of Arab origin adapted with a soft bread dough
- countries: (none)
- kinds: dish

## DISH Q138542210
- name: Stuffed potato bread
- description: soft potato dough bread usually filled with catupiry cheese
- countries: (none)
- kinds: dish

## DISH Q138542211
- name: Cooked pinhão
- description: araucaria seed boiled in salted water or roasted on a griddle
- countries: (none)
- kinds: dish
- ingredients: Araucaria angustifolia nut

## DISH Q138542212
- name: Grilled coalho cheese
- description: skewer of coalho cheese grilled over charcoal, usually with oregano
- countries: (none)
- kinds: dish

## DISH Q138542213
- name: Grilled pineapple
- description: pineapple slices sprinkled with cinnamon and grilled on a barbecue
- countries: (none)
- kinds: dish

## DISH Q138542214
- name: Pickled pearl potatoes
- description: small boiled potatoes preserved in vinegar, olive oil, and herbs
- countries: (none)
- kinds: dish

## DISH Q138542215
- name: Potato vinaigrette
- description: boiled potatoes in cubes and seasoned with a vinaigrette dressing
- countries: (none)
- kinds: dish

## DISH Q138542216
- name: Sautéed eggplant
- description: eggplant in cubes or strips sautéed with tomato and bell pepper
- countries: (none)
- kinds: dish

## DISH Q138542217
- name: Boiled beetroot
- description: boiled and sliced beetroot served cold as a salad
- countries: (none)
- kinds: dish

## DISH Q138542218
- name: Sautéed carrots
- description: carrots in cubes or slices sautéed with garlic and onion
- countries: (none)
- kinds: dish

## DISH Q138542219
- name: Sautéed chayote
- description: chayote in cubes sautéed with garlic, onion, and herbs
- countries: (none)
- kinds: dish

## DISH Q138542220
- name: Breaded cauliflower
- description: breaded and fried cauliflower florets
- countries: (none)
- kinds: dish

## DISH Q138542221
- name: Seasoned black-eyed peas
- description: cooked black-eyed peas seasoned with herbs and onion
- countries: (none)
- kinds: dish

## DISH Q138542222
- name: Vegetable mayonnaise
- description: cold salad of boiled potatoes and vegetables mixed with mayonnaise
- countries: (none)
- kinds: dish

## DISH Q138542223
- name: Hot sauce
- description: condiment made from chili peppers preserved in oil or vinegar
- countries: (none)
- kinds: dish

## DISH Q138542224
- name: Grilled bell pepper
- description: whole bell pepper grilled over charcoal until the skin wrinkles
- countries: (none)
- kinds: dish

## DISH Q138542225
- name: Creamy polenta
- description: soft version of polenta served as a purée with sauce
- countries: (none)
- kinds: dish

## DISH Q138542226
- name: Pumpkin purée
- description: cooked and mashed pumpkin served with dried meat
- countries: (none)
- kinds: dish

## DISH Q138542227
- name: Sautéed okra
- description: whole or chopped okra sautéed with garlic and onion
- countries: (none)
- kinds: dish

## DISH Q138542229
- name: Sautéed green beans
- description: chopped and sautéed green beans with garlic and onion
- countries: (none)
- kinds: dish

## DISH Q138542230
- name: Sirloin steak
- description: an Argentine cut of steak from the rear of the sirloin
- countries: (none)
- kinds: dish

## DISH Q138542231
- name: Mixed skewer
- description: skewer that alternates different types of meat with vegetables
- countries: (none)
- kinds: dish

## DISH Q138542232
- name: Tuscan sausage
- description: fresh and cured pork sausage served at barbecues
- countries: (none)
- kinds: dish

## DISH Q138542233
- name: Lamb shoulder
- description: the foreleg of the lamb slow-roasted over charcoal
- countries: (none)
- kinds: dish

## DISH Q138542234
- name: Rice with squid
- description: rice cooked with squid rings, usually in a tomato sauce
- countries: (none)
- kinds: dish

## DISH Q138542235
- name: Seafood rice
- description: rice cooked with a mixture of seafood such as shrimp and squid
- countries: (none)
- kinds: dish

## DISH Q138542236
- name: Seafood spaghetti
- description: spaghetti pasta sautéed with shrimp, squid, and octopus
- countries: (none)
- kinds: dish

## DISH Q138542237
- name: Seafood vinaigrette
- description: cooked and chilled seafood served in a vinaigrette sauce
- countries: (none)
- kinds: dish

## DISH Q138542238
- name: Steamed oysters
- description: fresh oysters cooked only by steaming, served with lemon
- countries: (none)
- kinds: dish, seafood-based food

## DISH Q138542239
- name: Fish with shrimp sauce
- description: grilled white fish fillet topped with a creamy shrimp sauce
- countries: (none)
- kinds: dish

## DISH Q138542240
- name: Seafood salad
- description: mixture of cooked seafood served cold with seasonings
- countries: (none)
- kinds: dish

## DISH Q138542241
- name: Canjicão
- description: creamy white corn sweet with ground peanuts and coconut milk
- countries: (none)
- kinds: dish

## DISH Q138542242
- name: Carolina
- description: choux pastry sweet filled with dulce de leche and covered in chocolate
- countries: (none)
- kinds: profiterole
- ingredients: dulce de leche, choux pastry, chocolate

## DISH Q138542243
- name: Manjar dos deuses
- description: Brazilian white pudding made of coconut milk served with a plum sauce
- countries: BR
- kinds: crème caramel

## DISH Q138545531
- name: Tharoi thongba
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q138567443
- name: Laku Tobe
- other names: {"id": "Laku Tobe"}
- countries: ID
- kinds: dish

## DISH Q138571900
- name: Jompo-jompo
- other names: {"id": "Jompo-jompo"}
- countries: ID
- kinds: dish

## DISH Q138576997
- name: Tutu à paulista
- description: Brazilian dish of puréed beans thickened with corn flour from São Paulo
- countries: BR
- kinds: tutu de feijão
- ingredients: maize flour, pinto bean

## DISH Q138577002
- name: Tutu à mineira
- description: Brazilian dish of puréed beans thickened with cassava flour from Minas Gerais
- countries: BR
- kinds: tutu de feijão
- ingredients: black turtle bean, cassava flour

## DISH Q138577316
- name: Chicken with okra
- description: Brazilian dish of stewed chicken with okra typical of Minas Gerais
- countries: BR
- kinds: chicken dish
- ingredients: sautéed okra, chicken as food

## DISH Q138579568
- name: Gotler
- other names: {"fi": "Gotler"}
- countries: (none)
- kinds: dish

## DISH Q138588666
- name: Homard à la parisienne
- other names: {"fr": "Homard à la parisienne"}
- description: French cuisine dish
- countries: FR
- kinds: seafood dish
- ingredients: vegetable mayonnaise, Nephropidae, mayonnaise

## DISH Q138663435
- name: Pernambuco arrumadinho
- description: version of arrumadinho typical of Pernambuco with green beans, sun-dried meat and farofa
- countries: BR
- kinds: arrumadinho

## DISH Q138663436
- name: Piauí arrumadinho
- description: version of arrumadinho typical of Piauí with maria isabel rice, paçoca and chicken cream
- countries: BR
- kinds: arrumadinho

## DISH Q138663438
- name: Ceará pratinho
- description: version of arrumadinho typical of Ceará served with rice, vatapá, paçoca and cream
- countries: BR
- kinds: arrumadinho

## DISH Q138677652
- name: Argentinian pizza
- description: cultural heritage and icon of Buenos Aires
- countries: AR
- kinds: dish
- ingredients: Capsicum, ham, Olea europaea, tomato, Allium sativum

## DISH Q138687802
- name: Abacha
- description: traditional Igbo food made from shredded cassava
- countries: (none)
- kinds: salad
- ingredients: cassava

## DISH Q1386897
- name: Töttchen
- other names: {"de": "Töttchen"}
- countries: (none)
- kinds: dish

## DISH Q138690836
- name: Explorador
- description: variant of the empanadilla originating from Cartagena, Spain
- countries: ES
- cuisines: cuisine of Cartagena, Spain
- kinds: Empanadilla, snack
- ingredients: lean meat, garlic, white pepper, olive oil, nutmeg, foie gras, puff pastry, Laurus nobilis, table salt

## DISH Q138690899
- name: Tuna and onion pizza
- description: Brazilian pizza topped with tuna and onion from São Paulo
- countries: BR

## DISH Q138690900
- name: Baiana pizza
- description: Brazilian pizza with ground calabresa sausage, eggs and chili
- countries: BR

## DISH Q138690901
- name: Broccoli and bacon pizza
- description: Brazilian pizza with broccoli, bacon and mozzarella
- countries: BR

## DISH Q138690902
- name: Calabresa sausage pizza
- description: Brazilian pizza topped with calabresa sausage and onions
- countries: BR

## DISH Q138690903
- name: Dried meat pizza
- description: Brazilian pizza with shredded dried meat and onions
- countries: BR

## DISH Q138690904
- name: Shrimp and catupiry pizza
- description: Brazilian pizza with shrimp and creamy catupiry cheese
- countries: BR

## DISH Q138690905
- name: Chicken and catupiry pizza
- description: Brazilian pizza with shredded chicken and creamy catupiry cheese
- countries: BR

## DISH Q138690906
- name: Canadian loin pizza
- description: Brazilian pizza topped with smoked pork loin
- countries: BR

## DISH Q138690908
- name: Corn and catupiry pizza
- description: Brazilian pizza with corn and creamy catupiry cheese
- countries: BR

## DISH Q138690909
- name: Palm heart pizza
- description: Brazilian pizza topped with heart of palm and mozzarella
- countries: BR

## DISH Q138690910
- name: Portuguese pizza
- description: Brazilian pizza with ham, eggs, onions and peas from São Paulo
- countries: BR

## DISH Q138690911
- name: Strogonoff pizza
- description: Brazilian pizza topped with beef or chicken stroganoff and potato sticks
- countries: BR

## DISH Q138690913
- name: Banana and cinnamon pizza
- description: sweet Brazilian pizza with banana, cinnamon and condensed milk
- countries: BR

## DISH Q138690914
- name: Brigadeiro pizza
- description: sweet Brazilian pizza topped with brigadeiro cream and chocolate sprinkles
- countries: BR

## DISH Q138690915
- name: Chocolate and strawberry pizza
- description: sweet Brazilian pizza with chocolate cream and sliced strawberries
- countries: BR

## DISH Q138690916
- name: Prestigio pizza
- description: sweet Brazilian pizza with chocolate and coconut inspired by the candy
- countries: BR

## DISH Q138690917
- name: Romeo and juliet pizza
- description: sweet Brazilian pizza with cheese and guava paste
- countries: BR

## DISH Q138690929
- name: Roasted kabocha squash
- description: side dish of seasoned and oven-roasted slices of kabocha squash
- countries: (none)
- kinds: dish

## DISH Q138690931
- name: Tucunaré fish stew
- description: Brazilian fish stew made with peacock bass typical of the Amazon region
- countries: BR
- kinds: dish

## DISH Q138690932
- name: Brazilian meat and vegetable stew
- description: traditional Brazilian stew of mixed meats, tubers, and vegetables
- countries: BR
- kinds: dish

## DISH Q138690933
- name: Panelada
- description: traditional Northeastern Brazilian stew made with cow's stomach and intestines
- countries: BR
- kinds: dish

## DISH Q138690934
- name: Vegetarian baião de dois
- description: meatless version of the traditional Brazilian rice and beans dish
- countries: BR
- kinds: dish

## DISH Q138690935
- name: Vegan bobó
- description: plant-based version of the Brazilian bobó dish replacing shrimp with vegetables
- countries: BR
- kinds: dish

## DISH Q138690942
- name: Damurida
- description: indigenous spicy broth made with tucupi, peppers, and fish from Roraima
- countries: BR
- kinds: dish

## DISH Q138690943
- name: Stuffed duck
- description: roasted duck stuffed with giblets typical of Santa Catarina
- countries: BR
- kinds: dish

## DISH Q138690944
- name: Pintado fish mojica
- description: Brazilian fish stew made with pintado and cassava from Mato Grosso
- countries: BR
- kinds: dish

## DISH Q138690945
- name: Pirarucu de casaca
- description: Amazonian dish of dried pirarucu layered with plantains and cassava flour
- countries: BR
- kinds: dish

## DISH Q138690952
- name: Eggplant lasagna
- description: Brazilian dish of layered eggplant replacing the pasta in a lasagna
- countries: BR
- kinds: dish

## DISH Q138702126
- name: Pan di Spagna
- description: type of cake
- countries: IT
- kinds: sponge cake
- has Wikipedia article: en

## DISH Q138705324
- name: Brazilian carrot cake
- description: Brazilian sweet cake made with blended carrots and chocolate glaze
- countries: BR
- kinds: cake
- ingredients: carrot

## DISH Q138714
- name: Fritto misto
- description: Italian dish
- countries: (none)
- kinds: fish dish
- has Wikipedia article: en

## DISH Q138715813
- name: Lendot
- description: traditional soup from Riau, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: soup, food, dish, human food
- ingredients: shallot, sago flour, black pepper, garlic, turmeric, shrimp paste, fern

## DISH Q138717527
- name: Joutsenon rieska
- description: Finnish sourdough bread
- countries: FI
- kinds: sourdough bread, rieska
- ingredients: barley flour, wheat flour, baker's yeast, table salt, milk, water

## DISH Q138722421
- name: Queso paria
- other names: {"es": "Queso paria"}
- countries: PE
- kinds: cheese

## DISH Q138757915
- name: Hamburská pečeně
- other names: {"cs": "Hamburská pečeně"}
- countries: (none)
- kinds: dish
- ingredients: pork

## DISH Q138771268
- name: Polentina di mandorle
- other names: {"it": "Polentina di mandorle"}
- countries: IT
- kinds: dessert

## DISH Q138782002
- name: Risotto alla ticinese
- description: Swiss dish
- countries: CH
- kinds: dish
- has Wikipedia article: en

## DISH Q138808636
- name: Kakegawa imojiru
- description: dish made by grating Japanese mountain yam and mixing it with mackerel broth and miso soup
- countries: JP
- kinds: dish
- ingredients: mackerel, Dioscorea japonica, miso

## DISH Q138811
- name: Licorice candy
- other names: {"zh": "甘草糖"}
- description: flavored with the extract of the roots of the licorice plant
- countries: (none)
- kinds: confectionery
- ingredients: Chinese liquorice, extract
- has Wikipedia article: en, zh

## DISH Q138835842
- name: Kiriyaki
- description: Japanese marinade
- countries: JP
- kinds: yakimono, food preparation technique
- ingredients: tare sauce, meat

## DISH Q138844724
- name: Montasù PAT
- other names: {"zh": "Montasù PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: yeast bread, baked good

## DISH Q138845947
- name: Chamuchos
- other names: {"mul": "Chamuchos"}
- countries: MX
- kinds: dessert

## DISH Q138849335
- name: Zucchini muffin
- description: type of baked product
- countries: (none)
- kinds: muffin, zucchini bread, baked good

## DISH Q138849361
- name: Poka-kara
- countries: (none)
- kinds: karaage, product
- ingredients: Bay-kara, teriyaki sauce, scrambled eggs

## DISH Q138849367
- name: Burano bussolai
- description: typical biscuit from Burano, Italy
- countries: IT
- kinds: biscuit

## DISH Q1388575
- name: Schlackwurst
- other names: {"de": "Schlackwurst"}
- countries: DE
- kinds: summer sausage, Rohwurst

## DISH Q138859462
- name: Ligurian pine nut pie
- countries: IT
- kinds: pie

## DISH Q138875275
- name: Tegernseer Kirschtorte
- other names: {"de": "Tegernseer Kirschtorte"}
- countries: (none)
- kinds: torte

## DISH Q138918853
- name: Tehane
- description: Moroccan food
- countries: MA
- cuisines: Moroccan cuisine, Mizrahi Jewish cuisine
- kinds: street food, offal dish, stuffed food, Eid food
- ingredients: spleen as food, kofta
- has Wikipedia article: en

## DISH Q138950054
- name: Hoagie
- description: dish usually consisting of a flour tortilla filled with fries and döner kebab meat
- countries: (none)
- kinds: wrap
- ingredients: wheat tortilla, meat, cheese

## DISH Q138950659
- name: Panoramic sugar egg
- description: Easter egg made from sugar and royal icing, containing small dioramas inside that can be viewed through a small window
- countries: (none)
- kinds: easter egg, candy, diorama, Easter traditions
- ingredients: royal icing, sugar

## DISH Q138951067
- name: Grassins
- description: Christmas cookies from Grisons
- countries: (none)
- kinds: Christmas cookies
- ingredients: shortcrust pastry, flour, butter, table salt, sugar

## DISH Q138979020
- name: Maccheroni bobbiesi PAT
- other names: {"zh": "Maccheroni bobbiesi PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: baked good, first course

## DISH Q138992
- name: Rheintaler Ribelmais
- description: maize-based food from Rhine valley
- countries: (none)
- kinds: dish
- ingredients: maize
- has Wikipedia article: en
