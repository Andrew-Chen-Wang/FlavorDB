# Review batch names-016

## DISH Q122960896
- name: Samun with suxhuk
- description: Samun, a kind of pita bread baked with slices of suxhuk sausage on top. Specialty from Gjakova
- countries: XK
- cuisines: Albanian cuisine
- kinds: baked good, food
- ingredients: sujuk

## DISH Q122960937
- name: Samun with gjiza
- description: Samun, a kind of pita bread baked with gjiza (ricotta like dairy) and herbs. Specialty from Prizren
- countries: XK
- cuisines: Albanian cuisine
- kinds: baked good, food
- ingredients: ricotta

## DISH Q122960943
- name: Panela de San Joaquín
- description: Pastry product from Venezuela
- countries: VE
- kinds: pastry

## DISH Q12296140
- name: Телешко варено
- other names: {"bg": "Телешко варено"}
- countries: (none)
- kinds: dish

## DISH Q122963715
- name: Obe ata
- description: Nigerian stew or sauce
- countries: NG
- kinds: dish, stew
- has Wikipedia article: en

## DISH Q122963852
- name: Mazë
- description: Thick dairy product made from milk cream and salt, similar to butter. Common in mountainous parts of north Albania.
- countries: AL
- cuisines: Albanian cuisine
- kinds: food

## DISH Q12297082
- name: Тутманик
- other names: {"bg": "Тутманик"}
- countries: BG
- kinds: pastry

## DISH Q1229737
- name: Ragusano PDO
- other names: {"zh": "Ragusano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: pasta filata, cow's-milk cheese, Italian cheese, cheese
- ingredients: cow's milk
- has Wikipedia article: en

## DISH Q12299271
- name: Чушки бюрек
- other names: {"bg": "Чушки бюрек"}
- countries: (none)
- kinds: dish

## DISH Q12299302
- name: Sharena sol
- description: vladis favorire spice
- countries: BG
- kinds: spice
- ingredients: Satureja, winter savory, summer savory
- has Wikipedia article: en

## DISH Q1230067
- name: Bayonne ham
- other names: {"zh": "巴约讷火腿"}
- description: French cured ham with protected designation of origin
- countries: FR
- cuisines: French cuisine
- kinds: raw ham
- ingredients: pork thigh
- has Wikipedia article: en

## DISH Q123009878
- name: 페이조아다
- other names: {"ko": "페이조아다"}
- countries: TL
- kinds: feijoada, dish

## DISH Q123015196
- name: Tagine malsouka
- description: Tunisian dish
- countries: TN
- kinds: food, dish
- ingredients: malsouka
- has Wikipedia article: en

## DISH Q123015526
- name: AnBataSan
- description: dessert from Otofuke, Hokkaido, Japan, consisting of anko and buttercream between sablé biscuits
- countries: (none)
- kinds: confectionery
- ingredients: Sablé, Vigna angularis, butter

## DISH Q123023254
- name: Potato sausage
- description: traditional food
- countries: FI, SE
- kinds: traditional food

## DISH Q12304464
- name: Brunsviger
- description: type of cake
- countries: (none)
- kinds: cake
- ingredients: syrup, white sugar, dried fruit, margarine

## DISH Q12305759
- name: Chokoladefrø
- other names: {"da": "Chokoladefrø"}
- countries: (none)
- kinds: candy
- ingredients: chocolate

## DISH Q123058225
- name: Asun
- description: spiced Nigerian ethnic Yoruba barbecue meat delicacy
- countries: NG
- kinds: food, dish
- has Wikipedia article: en

## DISH Q123090891
- name: Chicken sandwich
- description: type of sandwich
- countries: (none)
- kinds: sandwich, chicken dish
- ingredients: bread, chicken
- has Wikipedia article: en

## DISH Q123091140
- name: Piggy bun
- other names: {"zh": "豬仔包"}
- countries: (none)
- kinds: French roll
- has Wikipedia article: zh

## DISH Q123092826
- name: Papo seco
- countries: (none)
- kinds: bread roll

## DISH Q123093204
- name: Cheese stick
- description: food product of cheese or cheese product formed into a stick form
- countries: (none)
- kinds: cheese dish
- has Wikipedia article: en

## DISH Q1231078
- name: Bleu de Gex
- other names: {"zh": "热克斯蓝纹奶酪"}
- description: creamy, semi-soft blue cheese made from unpasteurized milk in the Jura region of France
- countries: FR
- kinds: blue cheese, raw-milk cheese, French cheese, cow's-milk cheese, dairy cheese
- ingredients: cow
- has Wikipedia article: en, zh

## DISH Q12311997
- name: Formad
- description: Danish meal
- countries: DK
- kinds: appetizer, meal

## DISH Q123124821
- name: Bannu Pulao
- description: Rice based dish from Bannu, Khyber Pakhtunkhwa, Pakistan
- countries: PK
- cuisines: Pakistani cuisine
- kinds: mixed rice dish, dish
- ingredients: spice, meat, rice
- has Wikipedia article: en

## DISH Q1231414
- name: Époisses
- other names: {"zh": "埃普瓦斯奶酪"}
- description: French cheese
- countries: FR
- kinds: French cheese, cow's-milk cheese, farmstead cheese, industrial cheese, washed-rind cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q123142484
- name: Goody good gum drops
- description: ice cream flavour in New Zealand
- countries: NZ
- kinds: ice cream
- ingredients: bubblegum ice cream, Gumdrop
- has Wikipedia article: en

## DISH Q123142525
- name: Cake salé
- other names: {"fr": "cake salé"}
- countries: FR
- kinds: cake

## DISH Q123143629
- name: 群来太郎丼
- other names: {"ja": "群来太郎丼"}
- countries: (none)
- kinds: donburi
- ingredients: herring, rice

## DISH Q123143631
- name: Egg-lemon sauce
- countries: (none)
- kinds: sauce, egg dish

## DISH Q12314775
- name: Friesentorte
- countries: (none)
- kinds: torte

## DISH Q123151632
- name: Domimyeon
- description: Korean fish hot pot
- countries: KR
- cuisines: Korean cuisine
- kinds: jeongol

## DISH Q123154136
- name: Cassata di Oplontis
- other names: {"it": "Cassata di Oplontis"}
- countries: IT
- kinds: dessert

## DISH Q123168373
- name: Hmong sausage
- description: herbed pork sausage from Hmong diaspora communities
- countries: LA, TH
- cuisines: Hmong cuisine
- kinds: sausage, dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q123171413
- name: Luwombo
- description: Ugandan stew that is prepared in wrapped in banana leaves
- countries: UG
- kinds: dish, stew
- ingredients: beef, mushroom, Allium, peanut, tomato, table salt, chicken, fish
- has Wikipedia article: en

## DISH Q123177512
- name: Солянка
- other names: {"ru": "солянка"}
- countries: RU
- cuisines: Russian cuisine
- kinds: ragout, dish
- ingredients: Salzgurke, offal, Brassica oleracea, meat, carrot

## DISH Q123181871
- name: Kababi
- other names: {"de": "Kababi"}
- countries: (none)
- kinds: dish

## DISH Q123194106
- name: Vary sosoa(riz mou)
- other names: {"fr": "vary sosoa(riz mou)"}
- countries: (none)
- kinds: dish, course, type of food or dish

## DISH Q123197340
- name: Pão francês
- description: Brazilian bread roll
- countries: BR
- kinds: bread
- has Wikipedia article: en

## DISH Q123199835
- name: Fourme d'Yssingeaux
- countries: FR
- kinds: cheese, blue cheese, French cheese, cow's-milk cheese
- ingredients: cow's milk

## DISH Q123201806
- name: French bread
- description: Type of bread
- countries: (none)
- kinds: bread

## DISH Q123204962
- name: Lamba
- description: Name of hausa traditional food
- countries: NG
- kinds: human food

## DISH Q12321295
- name: Karbonade
- description: Nordic dish
- countries: (none)
- kinds: frikadeller, meat dish

## DISH Q123221343
- name: Kōʻelepālau
- description: hawaiian sweet potato pudding
- countries: US
- kinds: pudding
- ingredients: coconut milk, Sweet potato
- has Wikipedia article: en

## DISH Q123245043
- name: Tagarninas o cardillos
- description: Scolymus hispanicus vegetable, used to prepare different dishes in Spain
- countries: ES
- kinds: dish
- ingredients: Scolymus hispanicus

## DISH Q1232535
- name: Kefalograviera
- description: Greek cheese
- countries: GR
- kinds: sheep milk cheese, Greek cheese, cheese
- ingredients: sheep milk
- has Wikipedia article: en

## DISH Q123256086
- name: Danish pastry dough
- description: laminated yeast-leavened dough
- countries: (none)
- kinds: laminated dough, dish

## DISH Q123256158
- name: Areias
- description: Portuguese sandie cake-like pastries
- countries: PT
- kinds: pastry, cake
- ingredients: Prunus amygdalus, egg yolk, sugar
- has Wikipedia article: en

## DISH Q1232663
- name: Perepechi
- countries: RU
- cuisines: Udmurt cuisine
- kinds: pastry

## DISH Q123271460
- name: Calaverita de azúcar
- other names: {"es": "Calaverita de azúcar"}
- description: typical Mexican candy offering on the Day of the Dead
- countries: (none)
- kinds: candy, votive offering
- ingredients: sugar

## DISH Q123272959
- name: Tawa tawa
- other names: {"es": "Tawa tawa"}
- countries: (none)
- kinds: confectionery

## DISH Q123277538
- name: Boiled / roasted corn
- other names: {"zh": "烤玉米"}
- description: corn on the cob prepared on the grill or boiled in salted water
- countries: (none)
- kinds: dish, corn on the cob
- has Wikipedia article: zh

## DISH Q12328281
- name: Napoleonshat
- countries: (none)
- kinds: cake

## DISH Q123298878
- name: Ají de lentejas
- description: Bolivian dish
- countries: BO
- kinds: meal, stew
- ingredients: meat

## DISH Q123302266
- name: Lagua de choclo
- description: Bolivian dish
- countries: BO
- kinds: meal, soup

## DISH Q12330513
- name: Othellokage
- other names: {"da": "Othellokage"}
- countries: DK
- kinds: cake

## DISH Q123310300
- name: Kibbeh safarjaliyeh
- description: dish of Syrian cuisine
- countries: SA, SY
- cuisines: Arab cuisine, Levantine cuisine, Syrian cuisine
- kinds: dish, kibbeh
- ingredients: pomegranate, stock, quince, kibbeh, lamb meat, beef
- has Wikipedia article: en

## DISH Q123314397
- name: Potato-dough dumpling
- countries: (none)
- kinds: dumpling, potato dish

## DISH Q1233145
- name: Pont-l'Évêque
- other names: {"zh": "庞特伊维克芝士"}
- description: uncooked, unpressed cow's-milk cheese, originally manufactured in the area around the commune of Pont-l'Évêque, in the Calvados département of Normandy
- countries: FR
- kinds: French cheese, cow's-milk cheese, farmstead cheese, industrial cheese, washed-rind cheese, dairy cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q123328796
- name: Prahok ktis
- description: Cambodian dipping sauce
- countries: KH
- kinds: dip
- ingredients: tamarind juice, Kaffir Lime Leaf, ground pork, palm sugar, coconut cream, Solanum torvum, kroeung, prahok
- has Wikipedia article: en

## DISH Q1233453
- name: Tavë Kosi
- other names: {"zh": "酸奶砂鍋"}
- description: The national dish of Albania, baked lamb dish in sour cream
- countries: AL
- cuisines: Albanian cuisine
- kinds: lamb dish
- ingredients: lamb meat, soured milk
- has Wikipedia article: en

## DISH Q123351949
- name: Castellano
- description: Spanish cheese
- countries: ES
- kinds: cheese

## DISH Q123353
- name: Kammerjunker
- description: biscuit
- countries: DK
- kinds: biscuit
- ingredients: flour
- has Wikipedia article: en

## DISH Q12336219
- name: Snirkel
- description: Type of Danish pastry
- countries: DK
- kinds: pastry, baked good

## DISH Q12336567
- name: Spandauer
- countries: (none)
- kinds: cake, Danish
- ingredients: whipped cream

## DISH Q12336720
- name: Sportskage
- other names: {"da": "sportskage"}
- countries: DK
- kinds: cake

## DISH Q123368017
- name: Rus
- other names: {"ca": "Rus"}
- countries: (none)
- cuisines: cuisine of La Bisbal d'Empordà
- kinds: culinary speciality

## DISH Q123377363
- name: Pisang aroma
- other names: {"id": "pisang aroma"}
- countries: ID
- kinds: street food
- ingredients: tapioca, banana

## DISH Q123383207
- name: Ruisleipä
- description: Finnish rye bread
- countries: (none)
- kinds: Finnish bread, rye bread
- has Wikipedia article: en

## DISH Q12338752
- name: Talkhan
- description: Afghan sweet
- countries: AF
- kinds: sweetmeat
- ingredients: walnut
- has Wikipedia article: en

## DISH Q12338859
- name: Tebirkes
- description: Danish pastry
- countries: (none)
- kinds: bread
- ingredients: poppy seed, puff pastry
- has Wikipedia article: en

## DISH Q123396435
- name: Reikäleipä
- countries: (none)
- kinds: Finnish bread

## DISH Q123398690
- name: Apam barenda
- description: traditional cake from Indonesia
- countries: ID
- kinds: snack, appam, kue, jajan pasar
- ingredients: grated coconut, palm sugar, coconut milk, cooking oil, flour

## DISH Q123398722
- name: Mi merah
- description: One of traditional dish from Banjarmasin
- countries: ID
- kinds: traditional food, type of food or dish, food
- ingredients: onion, wheat flour, food coloring, table salt, water

## DISH Q123398942
- name: Buras Banjar
- description: traditional dish originating from the Banjarmasin region of South Kalimantan, Indonesia
- countries: ID
- kinds: snack, food festival, jajan pasar, traditional food
- ingredients: peanut, banana leaf, chili pepper, table salt, rice

## DISH Q123398955
- name: Lidah sapi
- description: traditional cake from Kalimantan, Indonesia
- countries: ID
- kinds: kue, type of food or dish
- ingredients: wheat flour, palm sugar, cooking oil, sodium bicarbonate, water

## DISH Q123399027
- name: Lapis hula-hula
- description: Indonesian traditional cake
- countries: ID
- kinds: food, type of food or dish, kue, traditional food
- ingredients: condensed milk, wheat flour, coconut milk, Pandanus amaryllifolius, egg as food, table salt, sugar, chocolate

## DISH Q123399077
- name: Apam Benyiur
- description: Apam Banyiur is a type of apam which is a traditional cake from South Kalimantan
- countries: ID
- kinds: snack, kue, jajan pasar
- ingredients: grated coconut, palm sugar, rice flour, coconut milk

## DISH Q123400088
- name: Pizza carrée
- description: type of pizza of Algeria
- countries: DZ
- cuisines: Pied-noir cuisine
- kinds: dish

## DISH Q123411715
- name: Ulin-Ulin
- description: Ulin-ulin is a traditional cake from Banjarmasin, South Kalimantan
- countries: ID
- kinds: dish, snack, kue, jajan pasar, food
- ingredients: glutinous rice flour, grated coconut, white sugar, coconut milk

## DISH Q123411755
- name: Sticky rice with serundeng (roasted grated coconut)
- description: One of Indonesian cakes
- countries: ID
- kinds: snack, food, traditional food
- ingredients: Indonesian bay leaf, Kaffir Lime Leaf, turmeric rhizome, caraway seeds, onion, coconut, cooking oil, Alpinia galanga, Pandanus amaryllifolius, chili pepper, glutinous rice, black pepper, Cymbopogon citratus, table salt, sugar

## DISH Q12341730
- name: Yum yum
- description: convenience food
- countries: (none)
- kinds: instant noodles, convenience food, product
- ingredients: noodle

## DISH Q12341892
- name: Æggesnaps
- other names: {"da": "Æggesnaps"}
- countries: (none)
- kinds: dessert
- ingredients: egg yolk, sugar

## DISH Q123422106
- name: Camarão no Bafo
- description: Brazilian dish from Amapá
- countries: BR
- cuisines: Amapá
- kinds: dish
- ingredients: Melicertus kerathurus

## DISH Q123440105
- name: Baras Cake
- description: traditional food from Banjar
- countries: ID
- kinds: food, type of food or dish, traditional food
- ingredients: wheat flour, coconut milk, egg as food, table salt

## DISH Q123441
- name: Ahle Wurst
- description: kind of hard pork sausage made in northern Hesse, Germany
- countries: (none)
- kinds: Rohwurst, summer sausage, sausage, dish
- ingredients: pork
- has Wikipedia article: en

## DISH Q12344306
- name: Apple compote
- description: food
- countries: (none)
- kinds: apple sauce, compote
- ingredients: drinking water, apple

## DISH Q123456287
- name: Leberknödelsuppe
- other names: {"de": "Leberknödelsuppe"}
- countries: (none)
- kinds: soup
- ingredients: beef stock, Leberknödel

## DISH Q123457994
- name: Crompouce
- description: type of pastry in the Netherlands
- countries: (none)
- kinds: pastry, viennoiserie
- has Wikipedia article: en

## DISH Q123458338
- name: Han-namagashi
- other names: {"zh": "半生菓子"}
- description: type of wagashi between higashi and namagashi
- countries: JP
- kinds: confectionery
- has Wikipedia article: zh

## DISH Q123459652
- name: Petah Arab cake
- description: variations of typical Indonesian food
- countries: ID
- kinds: food
- ingredients: chicken egg, ginger, wheat flour, palm sugar, coconut milk, Alpinia galanga, Allium ascalonicum, beef, chili pepper, curry, Tamarindus indica, Cymbopogon citratus, Allium sativum, table salt, sugar

## DISH Q123461224
- name: Bread
- description: bread in the collection of the Swedish History Museum with object number 455021_HST
- countries: (none)
- kinds: bread, food, foundation deposit
- ingredients: organic matter

## DISH Q123464697
- name: Kacang Batampik
- description: Specialty cuisine of South Kalimantan
- countries: (none)
- cuisines: Banjar cuisine
- kinds: food, snack
- ingredients: wheat flour, tapioca, coconut milk, egg as food, peanut, table salt, sugar

## DISH Q123468944
- name: Dadar gunting
- description: Indonesian food
- countries: ID
- kinds: food, snack, dadar gulung
- ingredients: grated coconut, syrup, wheat flour, palm sugar, rice flour, coconut milk, food coloring, Pandanus amaryllifolius, water

## DISH Q123472349
- name: Hatuhūn sogi
- other names: {"zh": "哈吐浑索吉"}
- countries: CN
- kinds: dish
- has Wikipedia article: zh

## DISH Q123473916
- name: Bingka Kentang
- description: The traditional food of South Kalimantan.
- countries: ID
- kinds: food, cookie, snack, traditional food
- ingredients: grated coconut, coconut milk, egg as food, table salt, sugar, potato

## DISH Q123474083
- name: Talam Bawang
- description: traditional food from Indonesia
- countries: ID
- kinds: food, traditional food
- ingredients: wheat flour, coconut milk, scallion, Pandanus amaryllifolius, Allium ascalonicum, table salt, sugar, meat, carrot

## DISH Q123474241
- name: Asahikawa Soy Sauce Chow Mein
- countries: JP
- kinds: Yakisoba

## DISH Q123474581
- name: Encharcada
- description: Portuguese egg dessert
- countries: PT
- cuisines: Portuguese cuisine
- kinds: dessert, food
- ingredients: egg yolk, sugar
- has Wikipedia article: en

## DISH Q123478584
- name: Amaretti di Mombaruzzo
- countries: IT
- kinds: cookie

## DISH Q123480553
- name: Stick rice with inti (mix grated coconut and brown sugar)
- description: One of Indonesia cake, especially in Banjar
- countries: ID
- kinds: snack, food, traditional food
- ingredients: coconut, palm sugar, Pandanus amaryllifolius, glutinous rice, table salt

## DISH Q123487907
- name: Qəlyə
- other names: {"az": "Qəlyə"}
- countries: (none)
- kinds: dish
- ingredients: Cucurbita, Phaseolus

## DISH Q123492483
- name: Roasted Carp
- description: Roasted carp, Albanian specialty from Shkodra.
- countries: AL
- kinds: Albanian cuisine, human food

## DISH Q123503114
- name: Topi waja
- description: variations of typical Indonesian food
- countries: ID
- kinds: dish, type of food or dish, kue
- ingredients: brown sugar, wheat flour, rice flour, egg as food, yeast, table salt

## DISH Q123503171
- name: Bubur gunting
- description: variations of typical Indonesian food
- countries: ID
- kinds: dish, type of food or dish, congee
- ingredients: glutinous rice flour, palm sugar, coconut milk, Dracaena angustifolia, Pandanus amaryllifolius, table salt

## DISH Q123503313
- name: Balungan hayam
- description: variations of typical Banjarese food
- countries: ID
- kinds: dish, type of food or dish, street food, kue
- ingredients: glutinous rice flour, banana leaf, coconut, palm sugar, coconut milk, Dracaena angustifolia, Pandanus amaryllifolius, calcium carbonate, table salt, sugar

## DISH Q12350703
- name: KoToPo
- description: library
- countries: (none)
- kinds: library, fast food, bar, language school

## DISH Q123507458
- name: Bread salad
- description: salad made from bread
- countries: (none)
- kinds: salad, bread dish
- ingredients: bread

## DISH Q123510600
- name: Garigit
- description: variations of typical Banjarese food
- countries: ID
- kinds: dish, type of food or dish, kue
- ingredients: coconut, wheat flour, sugar, water

## DISH Q123510771
- name: Pais
- description: variations of typical Banjarese food
- countries: ID
- kinds: dish, type of food or dish, kue
- ingredients: cassava root, banana leaf, coconut, wheat flour, tapioca, sago, Cucurbita moschata, sugar, banana

## DISH Q123510827
- name: Kayu jabuk
- description: Banjarese food
- countries: ID
- kinds: dish, type of food or dish, kue
- ingredients: wheat flour, tapioca, cooking oil, table salt, sugar

## DISH Q123510977
- name: Randang porridge
- description: variations of typical Banjarese food
- countries: ID
- kinds: dish, type of food or dish, porridge
- ingredients: palm sugar, coconut milk, Pandanus amaryllifolius, sago, egg as food, table salt

## DISH Q123511003
- name: Sunduk lawang
- description: variations of typical Banjarese food
- countries: ID
- kinds: dish, type of food or dish, kue
- ingredients: palm sugar, rice flour, tapioca, coconut milk, calcium carbonate, table salt

## DISH Q123511576
- name: 納豆餅
- other names: {"ja": "納豆餅"}
- countries: JP
- kinds: mochi

## DISH Q123511586
- name: のうさば
- other names: {"ja": "のうさば"}
- countries: (none)
- kinds: fish dish

## DISH Q123511654
- name: Sago bread
- description: Banjarese food
- countries: ID
- kinds: dish, type of food or dish, kue
- ingredients: sago

## DISH Q123514652
- name: Katupat balamak
- description: Banjarese dish
- countries: ID
- kinds: dish, type of food or dish
- ingredients: shallot, garlic, Aleurites moluccanus, coconut milk, chili pepper, table salt, rice

## DISH Q123514659
- name: Putu ambung
- description: variations of typical Indonesia food
- countries: ID
- kinds: dish, type of food or dish, snack, kue
- ingredients: Pandanus amaryllifolius, glutinous rice flour, coconut, palm sugar

## DISH Q123514855
- name: Ketupat betumis
- description: Banjarese food
- countries: ID
- kinds: dish, type of food or dish, ketupat
- ingredients: asparagus bean, Kaffir Lime Leaf, ketupat, coconut milk, Vigna unguiculata, broth, Sweet potato, Cymbopogon citratus, table salt, sugar, carrot

## DISH Q123515210
- name: 仙台雑煮
- other names: {"ja": "仙台雑煮"}
- countries: JP
- kinds: zōni

## DISH Q123515252
- name: うちがえ雑煮
- other names: {"ja": "うちがえ雑煮"}
- countries: JP
- kinds: zōni

## DISH Q123515253
- name: はば雑煮
- other names: {"ja": "はば雑煮"}
- countries: (none)
- kinds: zōni
- ingredients: Petalonia binghamiae

## DISH Q123515615
- name: Tetal
- description: Indonesian food
- countries: ID
- kinds: dish, type of food or dish
- ingredients: asparagus bean, cassava root, coconut, corncob, Channa striata, glutinous rice, Carica papaya, Pisum sativum, maize, soybean

## DISH Q123515650
- name: Boiled jengkol
- description: variations of typical Banjarese food
- countries: ID
- kinds: dish, type of food or dish
- ingredients: Archidendron pauciflorum, corn starch, coconut, black pepper, calcium carbonate, table salt, sugar

## DISH Q123515682
- name: Jaring beras
- description: variations of typical Indonesia food
- countries: ID
- kinds: dish, type of food or dish, Petah
- ingredients: shallot, coconut, rice flour, coconut milk, table salt

## DISH Q123515778
- name: Barriga de freira
- description: Portuguese egg dessert
- countries: PT
- kinds: conventual sweets
- ingredients: Prunus amygdalus, egg yolk, sugar
- has Wikipedia article: en

## DISH Q123518001
- name: Cuore d'Abruzzo
- description: sweet typical of Abruzzo
- countries: IT
- kinds: dessert

## DISH Q123529232
- name: Budapester Salat
- other names: {"de": "Budapester Salat"}
- countries: (none)
- kinds: meat salad

## DISH Q123531411
- name: Micischia
- description: Abruzzo and Puglia agri-food product
- countries: IT
- kinds: meat

## DISH Q123537046
- name: Carmen salad
- description: Chicken salad
- countries: (none)
- kinds: salad

## DISH Q12353750
- name: Petatou
- description: French Touraine dish
- countries: FR
- kinds: dish
- ingredients: potato, olive, goat cheese, cream

## DISH Q123550994
- name: Sandnøtter
- description: Norwegian cookies
- countries: NO
- kinds: type of food or dish, cookie, dessert, snack
- ingredients: egg as food, butter, sugar

## DISH Q123561547
- name: Syrnitsa
- description: Belarusian salty cheese made from pressed curds & butter
- countries: BY
- kinds: food product, cheese analogue, dish
- ingredients: tvorog, butter, table salt

## DISH Q123578664
- name: Krentenwegge
- description: very large raisin bread, old dutch tradition
- countries: NL
- kinds: sweet bread
- ingredients: grain, raisin

## DISH Q123587721
- name: Pagnotta di San Martino
- countries: IT
- kinds: dessert

## DISH Q123600514
- name: Ottupathal
- description: Kerala snack made with rice powder
- countries: IN
- kinds: Pathiri, food, bread
- ingredients: rice flour

## DISH Q123616254
- name: Fefernuski kociewskie
- other names: {"pl": "Fefernuski kociewskie"}
- countries: (none)
- kinds: pryanik, cookie

## DISH Q1236200
- name: Eccles cake
- other names: {"zh": "葡萄干蛋糕"}
- description: small, round cake filled with currants
- countries: (none)
- kinds: food, cake
- ingredients: flaky pastry
- has Wikipedia article: en, zh

## DISH Q1236398
- name: Sfoglio PAT
- other names: {"zh": "Sfoglio PAT"}
- description: traditional Italian bakery product (PAT)
- countries: IT
- kinds: dessert, baked good
- ingredients: Tuma, sweetcrust pastry, Cinnamomum verum, chocolate

## DISH Q123663529
- name: Wild carrot
- description: taproot vegetable of plant known as a "wild carrot" For domesticated carrots use Q81
- countries: (none)
- kinds: carrot, taproot, vegetable, common name

## DISH Q12366986
- name: Kiluvõileib
- description: Estonian open-faced sprat sandwich
- countries: EE
- kinds: open sandwich, dish
- ingredients: sprat, rye bread

## DISH Q123691850
- name: Halua asam glugur
- other names: {"id": "halua asam glugur"}
- countries: ID
- kinds: candied fruit

## DISH Q123691851
- name: Halua Kedondong
- other names: {"id": "Halua Kedondong"}
- countries: (none)
- kinds: candied fruit

## DISH Q123691926
- name: Sahoaba
- countries: MG
- kinds: food, dish
- ingredients: cassava root, maize, yam, coconut milk, Colocasia esculenta, sugar, banana

## DISH Q123695547
- name: Měchura
- other names: {"cs": "měchura"}
- countries: (none)
- kinds: sweet pastry

## DISH Q123703069
- name: Pleśniak
- other names: {"pl": "pleśniak"}
- countries: PL
- cuisines: Polish cuisine
- kinds: cake

## DISH Q123703506
- name: Gemberbolus
- description: pastry
- countries: (none)
- kinds: pastry, viennoiserie

## DISH Q12370530
- name: Mulgipuder
- description: traditional dish that is consumed daily in the Mulgimaa region of Estonia
- countries: EE
- kinds: porridge
- ingredients: barley, potato
- has Wikipedia article: en

## DISH Q123737170
- name: Lorette potatoes
- countries: (none)
- kinds: dish

## DISH Q123753102
- name: Bantal kacang
- countries: ID
- kinds: human food

## DISH Q123753121
- name: Batun bedil
- countries: ID
- kinds: human food
- ingredients: tapioca starch, flour

## DISH Q123753178
- name: Sabun
- countries: ID
- kinds: human food
- ingredients: glutinous rice flour, rice flour, table salt

## DISH Q123753221
- name: Kaliadrem
- countries: ID
- kinds: human food
- ingredients: rice flour

## DISH Q123765095
- name: Corsican pomelo
- countries: FR
- kinds: fruit, citrus fruit

## DISH Q1238064
- name: Quartirolo Lombardo PDO
- other names: {"zh": "Quartirolo Lombardo DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: Italian cheese, cheese
- has Wikipedia article: en

## DISH Q1238105
- name: Murazzano PDO
- other names: {"zh": "Murazzano DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: sheep milk cheese, Italian cheese, cheese
- ingredients: sheep milk

## DISH Q123818587
- name: Fermented cassava bread
- description: a sort of cassava bread made out of fermented cassava beer
- countries: (none)
- kinds: Cassave bread, cazabe, cuisine, human food

## DISH Q123818932
- name: Cassava starch bread
- description: a sort of cassava bread made out of cassava starch
- countries: (none)
- kinds: Cassave bread, cazabe, cuisine, human food

## DISH Q123818960
- name: Quinhampira
- description: Fish broth with pepper, typical of the cuisine of the indigenous peoples of the northwest region of the Amazon rainforest
- countries: BR, CO, VE
- kinds: food, cuisine, broth

## DISH Q1238597
- name: Domoda
- description: Gambian peanut stew
- countries: GM, SN
- kinds: stew, peanut stew
- has Wikipedia article: en

## DISH Q12386330
- name: Colineta
- other names: {"gl": "Colineta"}
- countries: ES, FR
- cuisines: Basque cuisine, Asturian cuisine, Galician cuisine
- kinds: sponge cake, dish
- ingredients: chicken egg, almond, sugar

## DISH Q123907132
- name: Godamba roti
- countries: (none)
- kinds: Parotta, roti

## DISH Q123907368
- name: Peas with salo
- description: traditional Polish dish
- countries: PL
- kinds: dish
- ingredients: salo, Pisum sativum
- has Wikipedia article: en

## DISH Q123908111
- name: いただき
- other names: {"ja": "いただき"}
- countries: JP
- kinds: dish

## DISH Q123909944
- name: Gummekaka
- description: Christmas cake tradition in Torestorp and Älekulla in Västergötland
- countries: (none)
- kinds: cake

## DISH Q123909957
- name: Pea soup and pancakes on Thursdays
- description: tradition of serving pea soup and pancake on Thursdays
- countries: (none)
- kinds: dish

## DISH Q123910268
- name: Kentucky Cream Candy
- description: Confection from Kentucky, US
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q123913891
- name: Bún kèn
- description: Cambodian and Vietnamese noodle dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q123925175
- name: Bramborový knedlík
- description: potato dumplings in Czech cuisine
- countries: (none)
- kinds: potato-dough dumpling

## DISH Q123953040
- name: Szpekuchy
- other names: {"pl": "szpekuchy"}
- description: (Lithuanian-)Polish baked dumplings stuffed with bacon
- countries: PL, LT
- cuisines: Polish cuisine, Lithuanian cuisine
- kinds: bread roll, pastry, dumpling
- ingredients: salo, onion, yeast dough

## DISH Q12397045
- name: Bread of Cea
- description: Spanish traditional bread
- countries: ES
- kinds: bread
- ingredients: sourdough

## DISH Q12397046
- name: Pan de Neda
- other names: {"es": "Pan de Neda"}
- countries: ES
- kinds: bread

## DISH Q12397833
- name: Polbo á mugardesa
- other names: {"gl": "polbo á mugardesa"}
- countries: (none)
- cuisines: Galician cuisine
- kinds: octopus dish
- ingredients: garlic, potato, onion, bay leaf, Capsicum, olive oil, Octopoda

## DISH Q1239975
- name: Kipfel
- other names: {"de": "Kipfel"}
- countries: (none)
- kinds: baked good

## DISH Q123999838
- name: Guseonwangdo-go
- other names: {"zh": "九仙王道糕"}
- countries: (none)
- kinds: tteok

## DISH Q124007650
- name: Pierogi z suszonymi śliwkami
- other names: {"pl": "Pierogi z suszonymi śliwkami"}
- countries: (none)
- kinds: dish

## DISH Q12401202
- name: Torradas de crema
- other names: {"gl": "Torradas de crema"}
- countries: ES, FR
- cuisines: Basque cuisine
- kinds: pastry cream, dish
- ingredients: chicken egg, cow's milk, lard, flour, sugar

## DISH Q1240158
- name: Langres cheese
- other names: {"zh": "朗格勒奶酪"}
- description: French cheese from the plateau of Langres in the region of Champagne-Ardenne
- countries: FR
- kinds: French cheese, cow's-milk cheese, washed-rind cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q124025073
- name: Schrippe
- description: small, long bread
- countries: (none)
- kinds: bread roll

## DISH Q124030850
- name: Pani Popo
- description: Samoan coconut bread
- countries: WS
- kinds: type of food or dish, bread
- ingredients: coconut

## DISH Q124030874
- name: Zuccoto
- description: Italian dessert
- countries: IT
- cuisines: Italian cuisine
- kinds: type of food or dish, dessert

## DISH Q124032346
- name: Flesk og duppe
- other names: {"nb": "Flesk og duppe"}
- countries: NO
- kinds: dish
- ingredients: potato, béchamel, pork

## DISH Q124044180
- name: Gedao Rice
- other names: {"zh": "割稻飯"}
- description: "Gedao" is a word used in Mandarin Chinese to describe "割稻" that means "rice reaping". When it used for the name of the meal, the meaning of this word becomes "hearty meals are used to reward farmers' performances during the harvest season".
- countries: (none)
- kinds: dish

## DISH Q124048723
- name: Lampascioni
- other names: {"it": "Lampascioni"}
- countries: IT
- kinds: dish
- ingredients: Muscari comosum

## DISH Q12404884
- name: Gondi dumpling
- description: Persian Jewish dish
- countries: IR
- cuisines: Jewish cuisine, Mizrahi Jewish cuisine
- kinds: food
- ingredients: cardamom, meatball, onion, chicken as food, besan, lamb meat, turmeric
- has Wikipedia article: en

## DISH Q124053312
- name: Bazirou
- other names: {"zh": "把子肉"}
- description: pork dish of Shandong, China
- countries: (none)
- cuisines: Shandong cuisine
- kinds: dish, pork dish
- has Wikipedia article: en, zh

## DISH Q124060085
- name: ブリ雑煮
- other names: {"ja": "ブリ雑煮"}
- countries: JP
- kinds: zōni
- ingredients: Seriola quinqueradiata, mochi

## DISH Q124060435
- name: Hakhoning
- other names: {"nl": "hakhoning"}
- countries: (none)
- kinds: candy

## DISH Q124060793
- name: Verwurelter
- description: Luxembourgish pastry
- countries: LU
- kinds: pastry
- has Wikipedia article: en

## DISH Q124063944
- name: Avdiivka kasha
- description: festive and memorial kasha in Avdiivka in Donetsk Oblast
- countries: UA
- kinds: cuisine, porridge

## DISH Q124071892
- name: Rice in bamboo
- other names: {"zh": "竹筒饭"}
- countries: (none)
- kinds: rice dish

## DISH Q124071929
- name: Kralan
- description: Cambodian rice dish
- countries: (none)
- kinds: sticky rice in bamboo

## DISH Q124071932
- name: Khao lam
- description: Lao and Thai rice dish
- countries: (none)
- kinds: sticky rice in bamboo

## DISH Q12407548
- name: Khenagi
- countries: (none)
- kinds: dish

## DISH Q12408621
- name: Lobster Newberg
- description: American seafood dish
- countries: US
- kinds: seafood dish
- ingredients: lobster
- has Wikipedia article: en

## DISH Q12411608
- name: Devils on horseback
- description: English dish of bacon-wrapped dried fruit
- countries: GB
- kinds: food, savoury, zakuski, bacon-wrapped food
- ingredients: dried fruit, bacon
- has Wikipedia article: en

## DISH Q1241190
- name: Neufchâtel
- other names: {"zh": "紐沙特起司"}
- description: a soft, slightly crumbly, mold-ripened cheese made in the Neufchâtel-en-Bray, French region of Normandy
- countries: FR
- kinds: white mold-rind cheese, French cheese, cow's-milk cheese, farmstead cheese, dairy cheese
- ingredients: cow's milk
- has Wikipedia article: en, zh

## DISH Q12412201
- name: תרה
- other names: {"he": "תרה"}
- countries: (none)
- kinds: dish
- ingredients: Spinacia oleracea

## DISH Q124149715
- name: Quenelles sauce Nantua
- other names: {"fr": "quenelles sauce Nantua"}
- countries: FR
- kinds: culinary speciality
- ingredients: Nantua sauce, Quenelle

## DISH Q124151552
- name: Choucroute de la mer
- countries: FR
- kinds: culinary speciality
- ingredients: sauerkraut, fish

## DISH Q124168732
- name: Zurrukutun
- other names: {"eu": "Zurrukutun"}
- countries: ES
- kinds: soup
- ingredients: Zopako, garlic, cod, Choricero peppers, tomato sauce, fish sauce, Capsicum frutescens, egg, olive oil, water

## DISH Q12417662
- name: Kacchi Biryani
- description: One type of food
- countries: (none)
- kinds: dish

## DISH Q12417834
- name: Chicken karahi
- description: hallmark of Indian and Pakistani cuisine
- countries: (none)
- kinds: chicken dish
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q124216893
- name: کاچی
- other names: {"fa": "کاچی"}
- countries: (none)
- kinds: dessert, dish

## DISH Q12421702
- name: Crab Curry
- description: Indian seafood dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q124220537
- name: Поджарка
- other names: {"ru": "Поджарка"}
- countries: RU
- cuisines: Russian cuisine, Soviet cuisine
- kinds: dish
- ingredients: mutton, veal, beef, pork

## DISH Q1242466
- name: Ganache
- other names: {"zh": "甘纳许"}
- description: chocolate and cream sauce
- countries: FR
- kinds: chocolate
- ingredients: butter, cream, chocolate
- has Wikipedia article: en, zh

## DISH Q124256242
- name: Drammenskaker
- other names: {"nb": "Drammenskaker"}
- countries: NO
- kinds: cookie, dish

## DISH Q124257285
- name: Tefteli
- countries: RU, UA, BY
- cuisines: Russian cuisine, Ukrainian cuisine, Belarusian cuisine
- kinds: meat dish

## DISH Q124259998
- name: Dalpuri
- description: deep fried flatbread filled with lentils
- countries: IN
- kinds: puri, flatbread
- ingredients: lentil, wheat flour
- has Wikipedia article: en

## DISH Q124261314
- name: Stuffed brisket
- description: meat dish
- countries: FR, RU
- cuisines: French cuisine, Russian cuisine
- kinds: meat dish, stuffed food, dish
- ingredients: buckwheat porridge, mutton, veal

## DISH Q124261590
- name: Sundarban Honey
- description: type of honey
- countries: IN
- kinds: honey
- has Wikipedia article: en

## DISH Q124283282
- name: Al-Maltout
- description: Palestinian flatbread seasoned with olive oil
- countries: PS
- cuisines: Palestinian cuisine
- kinds: bread, flatbread, type of food or dish
- ingredients: turmeric, extra virgin olive oil, wheat flour, table salt, drinking water
- has Wikipedia article: en

## DISH Q124285478
- name: ಕಡ್ಲೆ ಬಜಿಲ್
- other names: {"tcy": "ಕಡ್ಲೆ ಬಜಿಲ್"}
- countries: IN
- cuisines: Indian cuisine
- kinds: dish

## DISH Q124290148
- name: Cassava salad
- description: one of Indonesian foods
- countries: ID
- kinds: food, traditional food, snack
- ingredients: cassava root, coconut, palm sugar, Pandanus amaryllifolius, table salt, sugar, water

## DISH Q124296664
- name: Letka khichri
- countries: (none)
- kinds: dish

## DISH Q124296686
- name: Foli machher bora
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q124296701
- name: Dimer korma
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q124296731
- name: Sheemer bichi diye chingri machh
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q124296761
- name: Kancha kola diye shingi machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q124300008
- name: Jaja matahari
- description: Balinese dish
- countries: ID
- kinds: dish

## DISH Q124300526
- name: Tengra machh alu korola diye jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q124301857
- name: Queijada de Sintra
- description: Traditional Portuguese sweet
- countries: PT
- cuisines: Portuguese cuisine
- kinds: dish

## DISH Q1243043
- name: Sandwich cookie
- other names: {"zh": "夹心饼干"}
- description: cookies kept by two thin cookies or biscuits with filling in between
- countries: (none)
- kinds: cookie
- has Wikipedia article: en, zh

## DISH Q124306322
- name: Fueskichelchen
- other names: {"lb": "Fueskichelchen"}
- countries: (none)
- kinds: pastry

## DISH Q124310690
- name: Balanzoni
- other names: {"it": "Balanzoni"}
- countries: IT
- kinds: stuffed pasta

## DISH Q124313304
- name: Boerewors roll
- description: boerewors in a hot dog bun
- countries: (none)
- kinds: hot dog, dish
- ingredients: hot dog bun, boerewors

## DISH Q124317263
- name: Tawa
- other names: {"fr": "tawa"}
- countries: AM
- kinds: dish
- ingredients: onion, peppercorn, biber salçası, bell pepper, lamb meat, tomato, table salt, zucchini

## DISH Q124317521
- name: Stuffed Turnips
- description: Traditional Palestinian dish
- countries: PS
- cuisines: Palestinian cuisine
- kinds: dish
- ingredients: turnip
- has Wikipedia article: en

## DISH Q124321728
- name: Bubuh injin
- countries: ID
- kinds: human food

## DISH Q124323070
- name: Sweetna
- description: snack from Kerala, India
- countries: IN
- kinds: snack

## DISH Q124324926
- name: Yaohon
- countries: (none)
- kinds: hot pot

## DISH Q124325367
- name: Mađarica
- description: traditional layered cake usually associated with festive occasions in Croatia
- countries: HR
- kinds: dessert

## DISH Q124332236
- name: Travesseiro de Sintra
- other names: {"pt": "Travesseiro de Sintra"}
- countries: (none)
- kinds: pastry
- ingredients: almond, egg yolk, puff pastry, cinnamon, sugar

## DISH Q124335811
- name: Koshian
- description: smooth red bean paste
- countries: (none)
- kinds: red bean paste

## DISH Q124335813
- name: Tsubuan
- description: chunky red bean paste
- countries: (none)
- kinds: red bean paste

## DISH Q124336363
- name: Anko and butter sandwich
- countries: JP
- kinds: sandwich
- ingredients: red bean paste, butter, bread

## DISH Q124342270
- name: Khoi
- countries: BD, IN
- kinds: snack

## DISH Q124343367
- name: Sili ice cream
- description: Filipino frozen dessert
- countries: PH
- kinds: dessert
- has Wikipedia article: en

## DISH Q124343491
- name: Kuchen de murta
- description: typical tart from southern Chile
- countries: CL
- kinds: tart, Kuchen, tartlet, meal
- ingredients: Ugni molinae

## DISH Q124347611
- name: Kochu diye musur daler ghonto
- countries: (none)
- kinds: dish

## DISH Q124351417
- name: Estofado de San Juan
- description: Chilean stew
- countries: CL
- kinds: stew, food

## DISH Q124351468
- name: Ensalada de digüeñes
- description: Chilean salad
- countries: CL
- kinds: salad, food
- ingredients: Cyttaria espinosae

## DISH Q124351584
- name: Conejos con crema pastelera
- description: Chilean sweet
- countries: CL
- kinds: candy, meal

## DISH Q124351850
- name: Frikandel sandwich
- description: common Dutch fried snack sandwich
- countries: (none)
- kinds: sandwich
- ingredients: special sauce, frikandel, bread roll

## DISH Q124355531
- name: Churrasco
- description: Chilean sandwich
- countries: CL
- kinds: sandwich, fast food
- ingredients: churrasco, bread

## DISH Q12435606
- name: Coconut ice
- description: type of confectionery
- countries: (none)
- kinds: confectionery
- ingredients: coconut, condensed milk, sugar
- has Wikipedia article: en

## DISH Q124356124
- name: Empanada de pino
- description: Chilean dish
- countries: CL
- kinds: empanada, food
- ingredients: minced meat

## DISH Q124356176
- name: Sémola con leche
- description: dessert
- countries: (none)
- kinds: food, dessert
- ingredients: semolina, milk

## DISH Q124356272
- name: Guatitas a la jardinera
- description: Chilean dish
- countries: CL
- kinds: beef dish, food
- ingredients: tripe

## DISH Q124357461
- name: Ghanta (dish)
- description: Multi vegetable and legume Odia dish
- countries: IN
- kinds: stew, vegetarian food
- ingredients: legume, spice, vegetable

## DISH Q124359049
- name: Drumstick
- description: vegetable
- countries: (none)
- kinds: vegetable

## DISH Q124360288
- name: Chupe de centolla
- description: Chilean crab soup
- countries: CL
- kinds: soup, Chupe, meal
- ingredients: Lithodes santolla

## DISH Q124369049
- name: Eggs Kejriwal
- description: Egg, cheese, and chili dish served on toast
- countries: IN
- kinds: egg dish, cheese dish, food
- ingredients: egg as food, cheese, bread
- has Wikipedia article: en

## DISH Q124370673
- name: Kuchen de quesillo
- description: typical tart from southern Chile
- countries: CL
- kinds: Kuchen
- ingredients: fresh cheese

## DISH Q124371370
- name: Taiwanese duck rice
- other names: {"zh": "鴨肉飯"}
- description: rice dish
- countries: (none)
- kinds: rice dish
- ingredients: crispy shallot, duck meat, cooked rice
- has Wikipedia article: zh

## DISH Q124372069
- name: Samhap
- description: class of Korean dishes incorporating three main ingredients
- countries: KR
- cuisines: Korean cuisine
- kinds: dish

## DISH Q124372640
- name: Takabb Anti-Cough Pill
- other names: {"zh": "五蜈蚣止咳丸"}
- description: Thai Chinese herbal throat lozenge
- countries: (none)
- kinds: cough drop
- has Wikipedia article: en

## DISH Q124378480
- name: Kroketbroodje
- description: puff pastry roll with a Dutch croquette inside
- countries: (none)
- kinds: snack
- ingredients: mustard, croquette, puff pastry

## DISH Q124378639
- name: Kroket sandwich
- description: common Dutch fried snack sandwich
- countries: (none)
- kinds: sandwich
- ingredients: mustard, croquette, bread roll

## DISH Q1243795
- name: Tuna pot
- description: Fish and potato stew
- countries: ES, FR
- cuisines: Cantabrian cuisine, Basque cuisine
- kinds: tuna dish, stew, dish
- ingredients: tomato, potato, onion, Capsicum, fish
- has Wikipedia article: en

## DISH Q124382030
- name: Uddamethi
- countries: (none)
- kinds: human food, curry

## DISH Q1243908
- name: Doretta
- other names: {"de": "Doretta"}
- countries: (none)
- kinds: domestic goose, roast goose

## DISH Q124390861
- name: Twisted carrots
- description: two or more carrots twisted together
- countries: (none)
- kinds: carrot, unusually shaped vegetable

## DISH Q124392501
- name: Flavorless candy
- description: Japanese candy
- countries: (none)
- kinds: candy
- has Wikipedia article: en

## DISH Q124394126
- name: Kaddo boddong
- description: variations of typical Indonesian food
- countries: (none)
- kinds: confectionery, jajan pasar
- ingredients: granulated sugar, grated coconut, coconut sugar, glutinous rice, drinking water

## DISH Q124394261
- name: Kue taripang
- other names: {"id": "kue taripang"}
- countries: (none)
- kinds: jajan pasar, dish, human food
- ingredients: table salt, glutinous rice flour, grated coconut, coconut sugar

## DISH Q124394289
- name: Sanggara belanda
- other names: {"id": "Sanggara belanda"}
- countries: ID
- kinds: confectionery, traditional food, dish
- ingredients: nut, butter, sugar, cheese, margarine, banana

## DISH Q124394324
- name: Bolu peca
- other names: {"id": "Bolu peca"}
- countries: ID
- kinds: confectionery, traditional food, dish
- ingredients: granulated sugar, glutinous rice flour, coconut sugar, wheat flour, egg as food, vanilla

## DISH Q124394376
- name: Cucuru bayao
- other names: {"id": "Cucuru bayao"}
- countries: (none)
- kinds: confectionery, traditional food, dish
- ingredients: granulated sugar, wheat flour, walnut, egg as food

## DISH Q124394389
- name: Bayao nibalu
- description: traditional confection of South Sulawesi, Indonesian
- countries: (none)
- kinds: confectionery, traditional food, dish
- ingredients: granulated sugar, durian, egg as food

## DISH Q124394424
- name: Doko-doko cangkuning
- description: Indonesian food
- countries: (none)
- kinds: confectionery, traditional food, jajan pasar, dish
- ingredients: grated coconut, coconut sugar, rice flour, coconut milk

## DISH Q124394478
- name: Doko-doko cangkuli
- description: Indonesian food
- countries: (none)
- kinds: traditional food, jajan pasar, dish
- ingredients: grated coconut, coconut sugar, coconut milk, mashed potato

## DISH Q124395886
- name: Manjarate
- description: Chilean dessert
- countries: CL
- kinds: dessert, mousse, meal

## DISH Q124396762
- name: Fleur de Sel de Camargue
- countries: FR
- kinds: fleur de sel

## DISH Q124396916
- name: Musur dal tomato dhone pata diye
- countries: (none)
- kinds: dish

## DISH Q124397359
- name: Balote
- other names: {"it": "Balote"}
- countries: IT
- kinds: dish

## DISH Q124397606
- name: Puya machher jhol
- countries: (none)
- kinds: fish dish

## DISH Q124397613
- name: Morich bharta
- description: Bengali cuisine
- countries: (none)
- kinds: Bhurta

## DISH Q124397666
- name: Lau diye shol machher jhol
- description: Bengali cuisine
- countries: (none)
- kinds: fish dish

## DISH Q124397684
- name: Cheypa sutki bhuna
- countries: (none)
- kinds: fish dish

## DISH Q124397728
- name: Notun alu tomato motorsuti diye rui machher jhol
- countries: (none)
- kinds: fish dish

## DISH Q124397748
- name: Kumro shaak bhaji
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q124405497
- name: Tapioca cake
- description: traditional cake of Brazil's North Region cuisine
- countries: (none)
- kinds: dish, food

## DISH Q124405934
- name: "Bull's eye" cookie
- description: traditional cookie of Brazil's North Region cuisine
- countries: (none)
- kinds: cookie, food

## DISH Q12440685
- name: Bara
- description: Indian dish
- countries: IN
- cuisines: Indian cuisine
- kinds: dish

## DISH Q124407151
- name: Pferfferckuckei
- other names: {"pt": "pferfferckuckei"}
- countries: (none)
- kinds: cookie, food

## DISH Q124407183
- name: Bombom de castanha
- other names: {"pt": "bombom de castanha"}
- countries: (none)
- kinds: sweetmeat, food
- ingredients: dulce de leche, Bertholletia excelsa, chocolate

## DISH Q124407394
- name: Bala baiana
- other names: {"pt": "bala baiana"}
- countries: (none)
- kinds: sweetmeat, food

## DISH Q124407401
- name: Bala de coco
- other names: {"pt": "bala de coco"}
- countries: (none)
- kinds: sweetmeat, food

## DISH Q124407403
- name: Brigadeirão
- other names: {"pt": "brigadeirão"}
- countries: (none)
- kinds: sweetmeat, food

## DISH Q124407523
- name: Sobá
- description: Brazilian noodle dish
- countries: BR
- cuisines: Brazilian cuisine
- kinds: soup, food, intangible cultural heritage
- has Wikipedia article: en

## DISH Q124411842
- name: Imitation chicken
- other names: {"zh": "素鸡"}
- description: Chinese chicken meat alternative made with tofu skin
- countries: CN
- cuisines: Chinese cuisine
- kinds: dish
- ingredients: tofu skin
- has Wikipedia article: zh

## DISH Q124414355
- name: Bombom de cupuaçu
- other names: {"pt": "bombom de cupuaçu"}
- countries: (none)
- kinds: bonbon
- ingredients: cupuaçu fruit, dulce de leche, chocolate

## DISH Q124414375
- name: Bombom de bacuri
- other names: {"pt": "bombom de bacuri"}
- countries: (none)
- kinds: sweetmeat, food

## DISH Q124414649
- name: Gboma Dessi
- other names: {"nl": "Gboma Dessi"}
- countries: (none)
- kinds: dish

## DISH Q124417321
- name: Thankuni patar bora
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q124417478
- name: Kancha peyaj bhorta
- description: bengali cuisine
- countries: (none)
- kinds: vegetable dish

## DISH Q124417583
- name: Dim bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: egg dish

## DISH Q124417637
- name: Kumror bhorta
- description: Bengali cuisine
- countries: (none)
- kinds: vegetable dish
