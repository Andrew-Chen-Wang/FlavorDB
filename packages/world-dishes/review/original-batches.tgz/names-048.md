# Review batch names-048

## DISH Q5768502
- name: Chumbeque
- countries: (none)
- kinds: meal, confectionery
- ingredients: egg as food, flour, honey

## DISH Q5768541
- name: Chupachús
- other names: {"es": "Chupachús"}
- countries: (none)
- kinds: caramel, lollipop

## DISH Q5770216
- name: Chenjeh kabab
- countries: (none)
- kinds: kebab

## DISH Q5775793
- name: Coc de Fraga
- other names: {"es": "Coc de Fraga"}
- countries: ES
- kinds: dessert

## DISH Q5775857
- name: Cochino frito
- other names: {"es": "Cochino frito"}
- countries: (none)
- kinds: culinary speciality

## DISH Q5779811
- name: Nargesi
- description: Iranian spinach omelette
- countries: (none)
- kinds: egg dish
- ingredients: Spinacia oleracea
- has Wikipedia article: en

## DISH Q5780954
- name: Concha
- other names: {"zh": "墨西哥包"}
- description: Mexican sweetbread
- countries: MX
- cuisines: Mexican cuisine
- kinds: pan dulce
- has Wikipedia article: en, zh

## DISH Q578365
- name: Peres de Lleida
- other names: {"ca": "peres de Lleida"}
- countries: (none)
- kinds: dessert
- ingredients: pear

## DISH Q57864243
- name: Ojingeo-sundae
- description: Korean dish of steamed stuffed squid
- countries: (none)
- kinds: sundae, squid dish, stuffed food
- ingredients: squid as food

## DISH Q5788351
- name: Cordero asado
- countries: (none)
- kinds: lamb dish

## DISH Q5788535
- name: Corico
- description: Mexican dessert
- countries: (none)
- kinds: dessert

## DISH Q5790855
- name: Crespillo
- countries: ES
- cuisines: cuisine of the Region of Murcia, cuisine of Cartagena, Spain
- kinds: cracker, snack
- ingredients: sweet paprika powder, wheat flour, egg as food, olive oil, lard, table salt, white wine

## DISH Q5793478
- name: Cubanito
- countries: MX
- kinds: confectionery

## DISH Q57935560
- name: 列日紫硬糖
- countries: BE
- kinds: confectionery

## DISH Q5795066
- name: Cushta
- description: Nicaraguan cuisine dish
- countries: NI
- kinds: dish
- ingredients: cocoa bean

## DISH Q5796448
- name: Mute
- description: Colombian soup
- countries: CO
- kinds: food, goat meat dish, soup
- has Wikipedia article: en

## DISH Q579671
- name: Yakimochi
- description: grilled or boiled mochi pound cake
- countries: JP
- kinds: mochi
- has Wikipedia article: en

## DISH Q57981532
- name: Jipang
- description: Indonesia traditional snack
- countries: ID
- cuisines: Indonesian cuisine
- kinds: brittle, dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q57981542
- name: Komo satay
- description: traditional food from Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: satay, dish, Indonesian cuisine, human food, type of food or dish
- ingredients: shallot, garlic, coconut milk, cattle

## DISH Q58034470
- name: Willisauer Ringli
- description: Swiss regional cookie specialty
- countries: CH
- kinds: cookie, annulus
- ingredients: lemon, honey

## DISH Q5803846
- name: Sopa de pata
- description: Salvadoran soup
- countries: SV
- kinds: food, soup
- has Wikipedia article: en

## DISH Q58090266
- name: Apang
- description: traditional cake from North Sulawesi
- countries: ID
- cuisines: Indonesian cuisine
- kinds: kue, dish, human food, type of food or dish
- ingredients: wheat flour, fermentation starter, rice flour, coconut milk

## DISH Q58090277
- name: Bikang
- description: traditional food made of rice flour, wheat flour, and tapioca
- countries: ID
- cuisines: Indonesian cuisine
- kinds: sweet dish, jajan pasar, dish, human food, type of food or dish
- ingredients: tapioca flour, chicken egg, wheat flour, rice flour, coconut milk, food coloring, Pandanus amaryllifolius, table salt

## DISH Q58090319
- name: Kelemben
- description: variations of typical Indonesia food
- countries: ID
- kinds: torte, dish, type of food or dish
- ingredients: wheat flour, Pandanus amaryllifolius, egg as food, vanilla, table salt, sugar, margarine

## DISH Q58090327
- name: Komoh
- description: traditional pork soup from Bali
- countries: ID
- cuisines: Indonesian cuisine
- kinds: meat dish, food, dish, human food, type of food or dish
- ingredients: black pepper, garlic, jackfruit, Aleurites moluccanus, Kaempferia galanga, coconut milk, galangal, red onion, Alpinia galanga, pork, chili pepper, Curcuma longa, ginger, pig

## DISH Q58090401
- name: Rusip
- description: a fermented fish dish traditional to the Bangka Belitung Islands and South Sumatra
- countries: ID
- cuisines: Indonesian cuisine
- kinds: human food, type of food or dish, dish, side dish
- ingredients: scorched rice, Mystacoleucus padangensis, sardine, Engraulidae, chili pepper, shallot, garlic

## DISH Q5812034
- name: Djej emshmel
- other names: {"es": "Djej emshmel"}
- description: Moroccan dish
- countries: MA
- kinds: dish

## DISH Q5814975
- name: Dulce de lechosa
- other names: {"zh": "木瓜糖"}
- description: traditional confection from Venezuela
- countries: VE
- kinds: traditional food, confectionery
- ingredients: papaya, panela
- has Wikipedia article: zh

## DISH Q5814982
- name: Mexican candies
- description: gastronomy of Mexico
- countries: MX
- cuisines: Mexican cuisine
- kinds: aspect in a geographic region, confectionery

## DISH Q581701
- name: Cocido lebaniego
- description: food
- countries: ES
- kinds: food, soup
- ingredients: chickpea
- has Wikipedia article: en

## DISH Q581884
- name: Rönttönen
- description: food
- countries: FI
- kinds: food, pie
- has Wikipedia article: en

## DISH Q58212664
- name: Spitzbuben
- description: Swiss christmas cookie
- countries: (none)
- kinds: Christmas cookies

## DISH Q58263
- name: Eggs Benedict
- other names: {"zh": "火腿蛋鬆餅"}
- description: American breakfast dish
- countries: FR, US
- kinds: breakfast, dish, open sandwich
- ingredients: back bacon, English muffin, egg as food, hollandaise sauce, bread
- has Wikipedia article: en, zh

## DISH Q5831610
- name: Empanada berciana
- other names: {"es": "Empanada berciana"}
- countries: (none)
- kinds: empanada

## DISH Q5831612
- name: Empanadico
- other names: {"an": "Empanadico"}
- countries: ES
- kinds: dessert

## DISH Q5831614
- name: Empanadilla de la vigilia
- other names: {"es": "Empanadilla de la vigilia"}
- countries: (none)
- kinds: Empanadilla

## DISH Q5831624
- name: Empedrao ceheginero
- other names: {"es": "Empedrao ceheginero"}
- countries: (none)
- kinds: rice dish

## DISH Q5831687
- name: Empolvado
- description: Chilean sweet
- countries: CL
- kinds: meal, alfajor
- ingredients: dulce de leche, powdered sugar, egg as food, flour

## DISH Q5832771
- name: Enfrijoladas
- description: Mexican dish
- countries: MX
- kinds: dish
- ingredients: wheat tortilla, Phaseolus vulgaris, cream, cheese
- has Wikipedia article: en

## DISH Q58339033
- name: Sate danguang-danguang
- description: traditional food from Minangkabau, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: satay, dish, Indonesian cuisine, human food, type of food or dish
- ingredients: shallot, garlic, ginger, grated coconut, skewer, Alpinia galanga, beef, chili pepper, Curcuma longa, Coriandrum sativum, Carum carvi

## DISH Q58339162
- name: Katupek pitalah
- other names: {"min": "Katupek pitalah"}
- description: traditional food from Minangkabau, Indonesia
- countries: ID
- cuisines: Indonesian cuisine
- kinds: dish, street food, jajan pasar, human food, type of food or dish
- ingredients: bamboo shoots, coconut milk, Artocarpus heterophyllus, rice

## DISH Q5834056
- name: Ensalada de cangrejo
- other names: {"es": "Ensalada de cangrejo"}
- countries: (none)
- kinds: salad

## DISH Q5834058
- name: Ensalada ilustrada
- other names: {"es": "Ensalada ilustrada"}
- countries: ES
- cuisines: Aragonese cuisine
- kinds: salad

## DISH Q5834310
- name: Entornao
- other names: {"es": "Entornao"}
- countries: ES
- kinds: dessert

## DISH Q5834964
- name: Marmalade
- other names: {"zh": "柑橘酱"}
- description: preserve made from the juice and peel of citrus fruits
- countries: PT
- kinds: spread, confectionery, fruit preserves
- ingredients: Seville orange, fruit, citrus fruit, agar, orange, vegetable, sugar
- has Wikipedia article: en, zh

## DISH Q583522
- name: Pirulín
- description: type of candy
- countries: (none)
- kinds: confectionery
- has Wikipedia article: en

## DISH Q58356585
- name: Toowoomba pasta
- description: Korean pasta dish
- countries: (none)
- kinds: pasta dish

## DISH Q5836776
- name: Reshteh polo
- description: type of iranian polo
- countries: (none)
- kinds: pilaf, dish

## DISH Q5837802
- name: Escudella de pagés
- description: Andorran soup
- countries: (none)
- kinds: soup

## DISH Q5840300
- name: Espineta amb caragolins
- countries: ES
- kinds: dish, stew, fish dish

## DISH Q584035
- name: Anelletti al forno
- description: baked pasta
- countries: IT
- kinds: pasta dish
- has Wikipedia article: en

## DISH Q58424037
- name: Marzipan
- description: Bulgarian surrogate chocolate
- countries: BG
- kinds: confectionery
- ingredients: cocoa bean, sugar

## DISH Q58431093
- name: Smoked Roa Fish Sauce
- description: Indonesian spicy sauce
- countries: ID
- cuisines: Indonesian cuisine
- kinds: sauce, dish, human food, type of food or dish

## DISH Q584324
- name: Serrano ham
- other names: {"zh": "塞拉诺火腿"}
- description: type of dry-cured Spanish ham
- countries: ES
- kinds: jamón
- ingredients: ham

## DISH Q5843433
- name: Nan-e Khormaie
- countries: (none)
- kinds: pastry

## DISH Q584564
- name: Spotted dick
- other names: {"zh": "斑點布丁"}
- description: British steamed pudding made with suet and dried fruit
- countries: GB
- cuisines: British cuisine
- kinds: pudding
- ingredients: suet
- has Wikipedia article: en, zh

## DISH Q5849978
- name: Caramel nougat
- other names: {"zh": "歐式黑麻糖"}
- description: Spanish almond and caramel brittle, typical of Aragon
- countries: ES
- kinds: dessert
- ingredients: almond, sugar

## DISH Q5851184
- name: Pataleh Polo
- countries: (none)
- kinds: dish, pilaf

## DISH Q5851361
- name: Mbaipy
- countries: PY
- kinds: dish

## DISH Q5853667
- name: Punjena paprika
- other names: {"zh": "乾辣椒包肉"}
- countries: (none)
- kinds: stuffed peppers

## DISH Q5854461
- name: Facturas
- description: Variety of sweet pastries in Argentina
- countries: (none)
- kinds: food, pastry, confectionery
- has Wikipedia article: en

## DISH Q5857706
- name: Madar Biscuit
- description: Iranian biscuit
- countries: IR
- kinds: biscuit

## DISH Q5858980
- name: Zereshk polow
- description: Barberry Rice and Saffron Chicken
- countries: (none)
- kinds: rice dish
- has Wikipedia article: en

## DISH Q58610
- name: Dal makhani
- other names: {"zh": "奶油扁豆咖哩"}
- description: dish originating from the Indian subcontinent
- countries: IN
- cuisines: Indian cuisine
- kinds: dish, Indian curry
- ingredients: Vigna mungo
- has Wikipedia article: en

## DISH Q58611926
- name: Mariscal
- description: Chilean dish
- countries: CL
- kinds: dish
- ingredients: garlic, onion, seafood, white wine

## DISH Q5862438
- name: Flan chino
- other names: {"es": "Flan chino"}
- countries: ES
- kinds: dessert

## DISH Q5862467
- name: Flauta
- description: typical Mexican dish
- countries: MX
- kinds: dish
- has Wikipedia article: en

## DISH Q586278
- name: Rosegons
- other names: {"ca": "rosegons"}
- countries: (none)
- kinds: cookie

## DISH Q586307
- name: Lokma
- description: Levantine dessert, common to the former Ottoman geography
- countries: EG, GR, IQ, SY, TR
- kinds: dish, food
- ingredients: dough, flour
- has Wikipedia article: en

## DISH Q5864774
- name: Tah Chin
- description: Iranian rice dish
- countries: IR
- kinds: dish, food
- ingredients: rice
- has Wikipedia article: en

## DISH Q586601
- name: Kalb-el-louz
- description: Algerian baked dessert
- countries: DZ
- kinds: dessert
- ingredients: almond meal, semolina
- has Wikipedia article: en

## DISH Q58667833
- name: Nasi punjung
- other names: {"id": "nasi punjung"}
- countries: ID
- kinds: rice dish

## DISH Q5869227
- name: Frejol colado
- countries: PE
- kinds: meal, dessert, confectionery
- ingredients: panela, Phaseolus vulgaris, sugar, milk

## DISH Q5869561
- name: Friche
- other names: {"es": "friche"}
- countries: CO
- cuisines: Colombian cuisine
- kinds: dish

## DISH Q5870874
- name: Kolompeh
- description: Iranian pastry
- countries: IR
- kinds: pastry
- has Wikipedia article: en

## DISH Q58717221
- name: Plat de relevé
- countries: (none)
- kinds: dish, course

## DISH Q5872280
- name: Eshkeneh
- description: persian onion soup
- countries: (none)
- kinds: soup

## DISH Q58730
- name: Snøfrisk
- description: Norwegian goat cheese
- countries: NO
- kinds: goat cheese, cheese
- has Wikipedia article: en

## DISH Q5873872
- name: Gachas dulces
- other names: {"es": "Gachas dulces"}
- countries: ES
- kinds: dessert

## DISH Q5873987
- name: Gajorro
- other names: {"es": "Gajorro"}
- countries: ES
- kinds: dessert

## DISH Q5874068
- name: Ho Hos
- description: American snack cake brand
- countries: (none)
- kinds: snack cake
- has Wikipedia article: en

## DISH Q5874625
- name: Hobak-tteok
- description: Korean rice cake
- countries: (none)
- kinds: tteok
- ingredients: rice flour
- has Wikipedia article: en

## DISH Q5875021
- name: Gambas con gabardina
- description: Spanish tapa
- countries: (none)
- kinds: finger food
- ingredients: shrimp and prawn as food
- has Wikipedia article: en

## DISH Q5875989
- name: Miche
- countries: FR
- kinds: cake, pastry
- ingredients: wheat, cornmeal

## DISH Q5876529
- name: Gañote
- other names: {"es": "gañote"}
- countries: ES
- cuisines: Spanish cuisine, cuisine of the province of Almería, cuisine of the province of Cádiz
- kinds: type of food or dish, dish

## DISH Q5876578
- name: Pork jelly
- description: typical Sicilian dish made with pork and jelly
- countries: IT
- kinds: pork dish, sulze
- ingredients: jelly, lemon, pork, black pepper

## DISH Q5877909
- name: Hojuela
- description: Spanish dessert
- countries: ES
- cuisines: Spanish cuisine
- kinds: type of food or dish, fritter
- ingredients: flour
- has Wikipedia article: en

## DISH Q5878001
- name: Hokey pokey
- description: iconic New Zealand flavour of ice cream
- countries: NZ
- kinds: ice cream flavor, ice cream
- ingredients: vanilla ice cream, honeycomb toffee
- has Wikipedia article: en

## DISH Q5878377
- name: Cabrito
- description: Spanish and Portuguese for roast goat kid
- countries: AR, BR, CL, ES, GR, IT, MX, PE, PT, UY, VE
- kinds: goat meat dish
- has Wikipedia article: en

## DISH Q58799170
- name: Strawberry
- description: hard candy
- countries: (none)
- kinds: hard candy

## DISH Q58799253
- name: Whirly Pop
- description: lollipop
- countries: (none)
- kinds: lollipop

## DISH Q5880655
- name: Holishkes
- description: Jewish dish of cabbage rolls
- countries: IL
- cuisines: Jewish cuisine
- kinds: cabbage roll
- has Wikipedia article: en

## DISH Q5882479
- name: Golmajería
- description: type of Spanish pastries
- countries: (none)
- kinds: pastry
- has Wikipedia article: en

## DISH Q588378
- name: Financier
- other names: {"zh": "費南雪"}
- description: small French almond cake
- countries: FR
- kinds: cake, small pastry
- ingredients: beurre noisette
- has Wikipedia article: en, zh

## DISH Q5884920
- name: Granizado de almendra
- other names: {"es": "Granizado de almendra"}
- countries: ES
- kinds: dessert

## DISH Q58853122
- name: Bolle
- description: nordic bakery product
- countries: (none)
- kinds: bun

## DISH Q588828
- name: Cochinillo de Segovia
- description: a food cataloged by the Junta de Castilla y León as a Guarantee Mark
- countries: ES
- cuisines: Spanish cuisine
- kinds: food, suckling pig, Marca de garantía

## DISH Q5889331
- name: Gurullos
- countries: ES
- kinds: dish
- ingredients: wheat flour

## DISH Q58898059
- name: Fedelini
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta
- has Wikipedia article: en

## DISH Q58898121
- name: Matriciani
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta

## DISH Q58898166
- name: Fazzoletti
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta

## DISH Q58898267
- name: Rombi
- description: type of pasta
- countries: (none)
- kinds: type of pasta, pasta

## DISH Q5890907
- name: Homity pie
- description: traditional British open vegetable pie
- countries: GB
- kinds: food, pie
- has Wikipedia article: en

## DISH Q5892267
- name: Harcha
- description: Moroccon semolina flatbread
- countries: (none)
- kinds: pancake
- has Wikipedia article: en

## DISH Q5892337
- name: Harinosas
- other names: {"es": "Harinosas"}
- countries: ES
- kinds: bun, dessert

## DISH Q590076
- name: Hawaiian pizza
- other names: {"zh": "夏威夷披萨"}
- description: pizza variety, usually topped with pineapple pieces and ham
- countries: CA
- kinds: dish, type of pizza
- ingredients: pineapple, pizza cheese, tomato sauce, prosciutto
- has Wikipedia article: en, zh

## DISH Q5900909
- name: Hojaldrinas
- countries: ES
- kinds: Christmas, pastry
- ingredients: wine, wheat flour, orange juice, lard, sugar

## DISH Q5904252
- name: Hueso de santo
- description: Spanish sweet
- countries: ES
- kinds: confectionery, food in religion

## DISH Q5904286
- name: Huevas aliñás
- description: hake roe salad
- countries: (none)
- kinds: salad

## DISH Q5904300
- name: Huevos a la mexicana
- description: Mexican breakfast dish
- countries: MX
- kinds: egg dish
- has Wikipedia article: en

## DISH Q5904313
- name: Huevos estrellados
- description: egg based dish
- countries: (none)
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q5905305
- name: Qovut
- countries: (none)
- kinds: pastry

## DISH Q5906095
- name: Horseshoe sandwich
- description: open-faced sandwich originating in Springfield, Illinois, U.S.; consists of thick-sliced toasted bread, a hamburger patty, French fries, and a cheese sauce
- countries: US
- kinds: food, sandwich
- ingredients: cheese sauce, fries, meat, bread
- has Wikipedia article: en

## DISH Q590686
- name: Chistorra
- other names: {"zh": "奇斯托拉"}
- description: Type of sausage from Spain
- countries: ES
- cuisines: Spanish cuisine, cuisine of Navarre, Aragonese cuisine
- kinds: dish
- ingredients: garlic, minced meat, paprika, pork, parsley, table salt
- has Wikipedia article: en

## DISH Q5907022
- name: Horumonyaki
- other names: {"zh": "内臟燒肉"}
- description: Japanese dish made from beef or pork offal
- countries: JP
- cuisines: Japanese cuisine
- kinds: pork dish, beef dish, offal dish
- has Wikipedia article: en, zh

## DISH Q590739
- name: Smažený sýr
- description: Czech and Slovak dish of cheese, about 1.5 cm thick, breaded with flour, egg, and bread crumbs and then fried, served with tartar sauce or mayonnaise and a side salad or potatoes
- countries: CZ
- kinds: farmstead cheese, pressed cooked cheese, fried cheese
- ingredients: cheese
- has Wikipedia article: en

## DISH Q5909392
- name: Hostess CupCake
- description: snack cake
- countries: (none)
- kinds: snack cake
- has Wikipedia article: en

## DISH Q5909823
- name: Hot Brown
- other names: {"zh": "熱布朗三明治"}
- description: open-faced hot sandwich
- countries: US
- kinds: sandwich
- ingredients: turkey meat, Mornay sauce, bacon, bread
- has Wikipedia article: en, zh

## DISH Q5910723
- name: Hot hamburger plate
- countries: US
- kinds: food, beef dish
- ingredients: fries
- has Wikipedia article: en

## DISH Q5911091
- name: Hotdish
- other names: {"zh": "熱盤"}
- description: type of casserole common to Minnesota and other Midwest American states
- countries: US
- kinds: type of food or dish, casserole
- has Wikipedia article: en

## DISH Q59134
- name: Kheer
- other names: {"zh": "梯兒"}
- description: rice dish
- countries: IN
- kinds: confectionery, rice dish
- ingredients: rice
- has Wikipedia article: en

## DISH Q59137506
- name: Salmon sandwich
- description: type of sandwich
- countries: (none)
- kinds: fish sandwich

## DISH Q59139
- name: Jalebi
- other names: {"zh": "炸糖漿甜麵圈"}
- description: sweet popular in countries of South Asia, West Asia, North Africa, and East Africa
- countries: EG, SD
- kinds: pastry, confectionery
- ingredients: pastry flour
- has Wikipedia article: en, zh

## DISH Q59187583
- name: Meatloaf Stephania
- description: type of meatloaf
- countries: HU
- kinds: meatloaf

## DISH Q591888
- name: Fartons
- description: confectionery sweets typical of the Valencian town of Alboraya, Spain
- countries: ES
- kinds: confectionery
- ingredients: flour
- has Wikipedia article: en

## DISH Q59208435
- name: Festival
- description: Jamaican fried dumpling
- countries: JM
- kinds: bread, dumpling
- ingredients: common wheat flour, cane sugar, cornmeal, baking powder, table salt
- has Wikipedia article: en

## DISH Q592173
- name: Pecorino Sardo PDO
- other names: {"zh": "Pecorino Sardo DOP"}
- description: Italian PDO cheese
- countries: IT
- kinds: cheese, pecorino, pressed half-cooked cheese
- ingredients: sheep milk
- has Wikipedia article: en

## DISH Q5922980
- name: Sweetmeat
- countries: (none)
- kinds: sweetmeat

## DISH Q592399
- name: Galician empanada
- countries: (none)
- cuisines: Galician cuisine
- kinds: dish, empanada
- ingredients: wheat flour, stuffing, butter, water

## DISH Q5925070
- name: Huai'an Pingqiao tofu
- description: Chinese dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q5925953
- name: Ham of Guijuelo
- description: Ham with the Designation of Origin, Guijuelo, Salamanca, Spain
- countries: ES
- kinds: jamón

## DISH Q5925956
- name: Jabugo ham
- countries: ES
- kinds: ham, jamón

## DISH Q5925980
- name: Jamón del país
- description: garlic-infused peppery ham
- countries: PE
- kinds: meal, ham

## DISH Q59260812
- name: Picada
- description: hors d'oeuvre from Argentinian and Uruguayan cuisine
- countries: AR, UY
- kinds: appetizer, dish
- has Wikipedia article: en

## DISH Q5927952
- name: Seattle roll
- description: sushi roll originating in Seattle, Washington, U.S
- countries: US
- kinds: uramakizushi
- has Wikipedia article: en

## DISH Q5928080
- name: Huckabuck
- description: homemade frozen dessert
- countries: US
- kinds: food, frozen dessert
- has Wikipedia article: en

## DISH Q5929327
- name: Huevos divorciados
- countries: MX
- kinds: egg dish
- ingredients: egg as food
- has Wikipedia article: en

## DISH Q5929345
- name: Huevos motuleños
- description: Yucatán breakfast dish
- countries: MX
- kinds: food, egg dish
- ingredients: corn tortilla, tomato sauce, ham, egg as food, Pisum sativum, cheese
- has Wikipedia article: en

## DISH Q59334084
- name: Amargo Chuncho
- description: bitters from Peru
- countries: PE
- kinds: bitters
- has Wikipedia article: en

## DISH Q5934858
- name: Basluq
- description: traditional Iranian confection
- countries: (none)
- kinds: pastry

## DISH Q5935553
- name: Hulatang
- other names: {"zh": "胡辣汤"}
- description: soup originated from Henan, China
- countries: CN
- kinds: food, soup
- has Wikipedia article: en, zh

## DISH Q59361662
- name: Serinakaker
- description: Norwegian butter cookie
- countries: (none)
- kinds: pastry, cookie
- has Wikipedia article: en

## DISH Q5940500
- name: Humbug
- description: peppermint flavoured boiled sweet
- countries: (none)
- kinds: hard candy
- has Wikipedia article: en

## DISH Q5941057
- name: Hummingbird cake
- other names: {"zh": "蜂鸟蛋糕"}
- description: Dessert
- countries: US
- kinds: spice cake
- ingredients: flour
- has Wikipedia article: en, zh

## DISH Q5942589
- name: Poleá
- description: chef
- countries: ES
- kinds: dessert
- has Wikipedia article: en

## DISH Q5942909
- name: Tava kebab
- countries: (none)
- kinds: meat dish, kebab

## DISH Q5946107
- name: Mexican rice
- description: rice dish with spices and red color from tomatoes
- countries: MX
- kinds: dish, side dish
- ingredients: garlic, tomato, onion, broth, rice
- has Wikipedia article: en

## DISH Q594675
- name: Fishcake
- other names: {"zh": "鱼蛋糕"}
- description: culinary dish consisting of filleted fish or other seafood minced or ground, mixed with a starchy ingredient
- countries: GB
- kinds: type of food or dish, fish dish, fishcake
- ingredients: fish
- has Wikipedia article: en, zh

## DISH Q5947112
- name: Kofteh berenj
- description: Iranian dish
- countries: (none)
- kinds: kofta

## DISH Q595261
- name: Caldume
- description: Italian stew
- countries: IT
- kinds: dish
- has Wikipedia article: en

## DISH Q59533377
- name: Mulhoe
- description: Korean cold soup made with raw fish
- countries: (none)
- kinds: hoe, cold sweet soup, raw fish dish

## DISH Q5953980
- name: Hyderabadi Marag
- description: spicy goat meat soup served as a starter in Hyderabad, India and part of Hyderabadi cuisine
- countries: IN
- kinds: food, soup
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q59542124
- name: Ayam kurma
- other names: {"id": "ayam kurma"}
- countries: ID
- kinds: gulai, food
- ingredients: chicken as food

## DISH Q595744
- name: Choklate ball
- other names: {"zh": "瑞典巧克力球"}
- description: sweet pastry with cocoa
- countries: DK, SE
- cuisines: Swedish cuisine
- kinds: pastry
- ingredients: grated coconut, rolled oats, cocoa powder, butter, sugar
- has Wikipedia article: en

## DISH Q5959435
- name: Khorovats
- description: meat dish traditional in Armenia
- countries: AM
- cuisines: Armenian cuisine
- kinds: meat dish
- has Wikipedia article: en

## DISH Q59629576
- name: Veal broth
- description: liquid food preparation with veal
- countries: (none)
- kinds: type of food or dish, food, broth, veal dish
- ingredients: veal

## DISH Q596409
- name: Bøfsandwich
- description: Danish hamburger
- countries: DK
- kinds: meal, hamburger
- has Wikipedia article: en

## DISH Q5964341
- name: Spring pancake
- other names: {"zh": "春饼"}
- description: Chinese dish
- countries: CN
- kinds: food, pancake
- has Wikipedia article: en, zh

## DISH Q59652608
- name: Blanc Manger
- description: historic concept of the modern blanc manger: savoury dish cooked with certain types of meat or fish
- countries: (none)
- kinds: dish, Biancomangiare PAT
- ingredients: chicken as food, rabbit

## DISH Q59707
- name: Paratha
- other names: {"zh": "印度油饼"}
- description: fried flatbread originating in the Indian subcontinent
- countries: (none)
- kinds: roti
- ingredients: atta
- has Wikipedia article: en, zh

## DISH Q597082
- name: Calia e simenza
- other names: {"es": "Calia e simenza"}
- countries: IT
- kinds: food

## DISH Q5971200
- name: Spam musubi
- other names: {"zh": "午餐肉饭团"}
- description: popular snack and lunch food in Hawaii
- countries: (none)
- kinds: dish, onigiri, apéritif, snack
- ingredients: Spam, cooked rice, nori
- has Wikipedia article: en

## DISH Q59713746
- name: Chunjang
- description: Korean-Chinese condiment
- countries: KR
- kinds: sauce

## DISH Q597159
- name: Canarian wrinkly potatoes
- description: Canarian potatoes
- countries: ES
- cuisines: Canarian cuisine
- kinds: potato dish
- ingredients: potato, table salt
- has Wikipedia article: en

## DISH Q5972737
- name: Lengua a la vinagreta
- description: cold marinated beef tongue dish
- countries: (none)
- kinds: beef dish
- ingredients: beef tongue

## DISH Q5975010
- name: Libum
- other names: {"es": "Libum"}
- description: cheesecake from classical antiquity
- countries: (none)
- kinds: focaccia
- has Wikipedia article: en

## DISH Q5977888
- name: Llunca de gallina
- other names: {"es": "llunca de gallina"}
- countries: (none)
- kinds: meal, soup

## DISH Q597836
- name: Bacalao a la vizcaína
- countries: ES
- kinds: fish dish
- ingredients: Biscayan sauce, Gadus morhua

## DISH Q5978632
- name: Lomito
- description: type of sandwich
- countries: (none)
- kinds: meal, sandwich
- ingredients: black pepper, loin, oil, table salt

## DISH Q5978645
- name: Lomo en adobo
- countries: (none)
- kinds: dish
- ingredients: oregano, garlic, pork loin, paprika, Adobo, vinegar, table salt

## DISH Q598113
- name: Karelian pasty
- other names: {"zh": "卡累利阿馅饼"}
- description: traditional pasties from Karelia
- countries: FI, RU
- cuisines: Russian cuisine, Karelian cuisine
- kinds: type of food or dish, pirog, potato dish
- ingredients: potato, rye flour, rye bread, pearl barley, wheat flour, Oryza, Hordeum, smetana, millet, rice pudding, Secale cereale, Hordeum vulgare, table salt, rice
- has Wikipedia article: en, zh

## DISH Q5984875
- name: Lunes de Quasimodo
- other names: {"es": "Lunes de Quasimodo"}
- countries: ES
- kinds: dessert

## DISH Q5985409
- name: Cornish ice cream
- description: ice cream made with Cornish clotted cream
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q5985600
- name: Icebox cake
- description: dessert
- countries: US
- cuisines: cuisine of the United States
- kinds: dessert
- ingredients: whipped cream, crust
- has Wikipedia article: en

## DISH Q5985621
- name: Iced bun
- description: viennoiserie
- countries: GB
- kinds: bread roll, viennoiserie
- ingredients: powdered sugar
- has Wikipedia article: en

## DISH Q5989305
- name: Madejas
- countries: ES
- kinds: offal, entrée, lamb dish

## DISH Q5990243
- name: Majarete
- description: corn pudding
- countries: (none)
- kinds: pudding
- ingredients: coconut milk, maize

## DISH Q5995340
- name: Ikameshi
- other names: {"zh": "烏賊飯"}
- description: squid rice
- countries: JP
- kinds: Japanese rice dish, squid dish
- has Wikipedia article: en, zh

## DISH Q5995345
- name: Ikan bakar
- other names: {"zh": "印尼烤鱼"}
- description: Indonesian and Malay grilled dish,
- countries: ID
- cuisines: Malay cuisine
- kinds: food, fish dish
- ingredients: shallot, banana leaf, fish as food, chili pepper, Cymbopogon citratus
- has Wikipedia article: en

## DISH Q599548
- name: Manjū
- other names: {"zh": "馒头"}
- description: Japanese confection
- countries: JP
- kinds: food, wagashi
- ingredients: red bean paste
- has Wikipedia article: en, zh

## DISH Q5996575
- name: Suimono
- description: Japanese clear soup
- countries: JP
- kinds: dish, soup

## DISH Q5997109
- name: Şambaba dessert
- countries: (none)
- kinds: dessert

## DISH Q599901
- name: Chocolate syrup
- other names: {"zh": "巧克力糖漿"}
- description: chocolate-flavored condiment
- countries: (none)
- kinds: chocolate, syrup
- ingredients: vanillin sugar, cocoa powder, whipped cream
- has Wikipedia article: en, zh

## DISH Q5999282
- name: Seafood platter
- other names: {"zh": "海鲜拼盘"}
- description: French seafood dish
- countries: (none)
- kinds: seafood dish, platter
- has Wikipedia article: en

## DISH Q5999895
- name: Kayseri yağlaması
- description: Turkish dish from Kayseri
- countries: TR
- kinds: food, bread dish
- ingredients: minced meat

## DISH Q6000077
- name: Tatar böreği
- description: Turkish foodstuffs
- countries: TR
- kinds: dish
- has Wikipedia article: en

## DISH Q6000956
- name: Khash-khash kebab
- countries: (none)
- kinds: kebab

## DISH Q6002018
- name: Islama köfte
- description: Turkish kofte (köfte) variant
- countries: TR
- kinds: food, dish, Köftes in the Turkish cuisine
- ingredients: meat
- has Wikipedia article: en

## DISH Q6002629
- name: Broken vermicelli
- description: thin vermicelli pasta that is broken or cut into short lengths
- countries: (none)
- kinds: type of pasta, vermicelli, şehriye

## DISH Q60030154
- name: Kkultteok
- description: Korean rice cake
- countries: (none)
- kinds: tteok, type of food or dish
- ingredients: rice flour, glutinous rice, honey

## DISH Q6004351
- name: Suji ka halwa
- description: Indian type of halvah made by toasting semolina (called suji, sooji, or rawa) in a fat like ghee or oil
- countries: (none)
- kinds: sweet dish, halva
- ingredients: semolina
- has Wikipedia article: en

## DISH Q6005710
- name: Imokilly Regato
- description: Irish cow milk cheese
- countries: IE
- kinds: cheese
- has Wikipedia article: en

## DISH Q6006053
- name: Manisa kebap
- description: Turkish cuisine meat dish
- countries: TR
- kinds: food, Köftes in the Turkish cuisine
- ingredients: minced meat, pide, tomato sauce

## DISH Q6006788
- name: Büryan
- description: lamb dish from Turkey, made in an underground oven (like a well)
- countries: TR
- kinds: food, meat dish, lamb dish
- ingredients: lamb meat

## DISH Q60071727
- name: Paila ice cream
- description: Ecuadorian and Colombian dessert
- countries: (none)
- kinds: ice cream
- has Wikipedia article: en

## DISH Q6007813
- name: Soto marzipan
- countries: ES
- kinds: marzipan

## DISH Q6008339
- name: Açık ekmek
- other names: {"tr": "Açık ekmek"}
- countries: (none)
- kinds: bread

## DISH Q6008497
- name: Circassian chicken
- description: chicken dish from the Turkish cuisine
- countries: TR
- kinds: food, chicken dish
- ingredients: chicken as food, walnut
- has Wikipedia article: en

## DISH Q6008643
- name: Medianoche
- other names: {"es": "medianoche"}
- countries: (none)
- kinds: viennoiserie

## DISH Q6009527
- name: Melcocha
- countries: ES
- kinds: confectionery
- ingredients: panela, lemon

## DISH Q6009729
- name: Kağıt kebabı
- description: Turkish dish
- countries: TR
- kinds: dish, kebab
- ingredients: tomato, minced meat, peppercorn
- has Wikipedia article: en

## DISH Q6009774
- name: Meloja (dulce)
- other names: {"es": "Meloja (dulce)"}
- countries: ES
- kinds: dessert

## DISH Q6010228
- name: Menestra
- description: Spanish dish
- countries: (none)
- kinds: type of food or dish, guiso

## DISH Q6011052
- name: Merengon
- description: Colombian dessert
- countries: (none)
- kinds: food, dessert

## DISH Q6011654
- name: Kalakay
- other names: {"tr": "Kalakay"}
- countries: (none)
- kinds: dish

## DISH Q6012372
- name: Kuzu fırın
- description: lamb dish from the cuisine of Turkey
- countries: TR
- kinds: food, lamb dish
- has Wikipedia article: en

## DISH Q60126666
- name: 雞肉沙拉
- countries: VE
- cuisines: Venezuelan cuisine
- kinds: dish

## DISH Q6013161
- name: Kandil simidi
- description: special circular bread with sesame or "çörekotu" made for certain religious days
- countries: TR
- kinds: food, bread, simit
- ingredients: Sesamum indicum, wheat flour, cooking oil, table salt, drinking water
- has Wikipedia article: en

## DISH Q6013354
- name: Toyga soup
- description: traditional yoghurt soup from Turkey
- countries: TR
- kinds: soup, dish
- ingredients: yogurt
- has Wikipedia article: en

## DISH Q6013649
- name: Chicken inasal
- description: roasted chicken dish from the Philippines
- countries: PH
- kinds: chicken dish, roast chicken
- ingredients: chicken as food
- has Wikipedia article: en

## DISH Q6013660
- name: Miel de Granada
- description: Spanish honey
- countries: (none)
- kinds: honey

## DISH Q6013663
- name: Miel de Tenerife
- description: Spanish honey
- countries: (none)
- kinds: honey

## DISH Q6013667
- name: Miel de La Alcarria
- description: Spanish honey
- countries: (none)
- kinds: honey

## DISH Q6013710
- name: Migas amb xocolata
- other names: {"ca": "Migas amb xocolata"}
- countries: (none)
- kinds: dish, Migas
- ingredients: chocolate

## DISH Q6013719
- name: Migas ruleras
- other names: {"es": "Migas ruleras"}
- countries: ES
- cuisines: Castilian-Manchego cuisine
- kinds: food
- ingredients: bread crumbs, chorizo, bacon

## DISH Q6015002
- name: Kadınbudu köfte
- description: "köfte" dish from the Turkish cuisine
- countries: (none)
- kinds: Köftes in the Turkish cuisine

## DISH Q60150397
- name: Funchoza
- description: Russo-Korean noodle salad
- countries: (none)
- cuisines: Koryo-saram cuisine
- kinds: pasta salad, dish
- ingredients: cellophane noodles
- has Wikipedia article: en

## DISH Q60162114
- name: Beef burger
- description: hamburgers made with beef meat
- countries: (none)
- kinds: hamburger
- ingredients: beef

## DISH Q6017615
- name: Dilber dudağı
- description: Turkish dessert
- countries: TR
- kinds: food, dessert
- has Wikipedia article: en

## DISH Q6017732
- name: Kaygana
- description: Turkish egg dish from the Black Sea region
- countries: TR
- kinds: egg dish

## DISH Q6018508
- name: Peynir helva
- description: cheese-based dessert from the Turkish cuisine
- countries: TR
- kinds: food

## DISH Q6018744
- name: Şambali
- description: dessert (literally "Damascus honey" in Turkish)
- countries: (none)
- kinds: dessert, street food
- ingredients: semolina
- has Wikipedia article: en

## DISH Q6018941
- name: Tapan
- description: regional bread in Turkey
- countries: (none)
- kinds: bread

## DISH Q60194193
- name: Gußzwieback
- countries: (none)
- kinds: rusk

## DISH Q6020696
- name: Beypazarı kurusu
- countries: (none)
- kinds: cookie

## DISH Q6020881
- name: Mole prieto
- other names: {"es": "Mole prieto"}
- countries: MX
- kinds: food
- ingredients: maize, pig

## DISH Q6020906
- name: Molinera
- description: grape variety
- countries: ES
- kinds: grape, grape variety

## DISH Q6021439
- name: Kerebiç
- countries: (none)
- kinds: dessert

## DISH Q6022454
- name: Şıllık
- description: traditional walnut and syrup dessert from Şanlıurfa, Turkey
- countries: TR
- cuisines: Turkish cuisine, Şanlıurfa cuisine
- kinds: type of food or dish, dessert
- ingredients: Urfa butter, walnut, flour, table salt, sugar, water
- has Wikipedia article: en

## DISH Q6022608
- name: Pumpkin dessert
- description: dessert from the Turkish cuisine, made with pumpkins.
- countries: TR
- kinds: food, dessert
- ingredients: pumpkin
- has Wikipedia article: en

## DISH Q6022671
- name: Indian omelette
- other names: {"zh": "印度奄列"}
- description: egg-based dish
- countries: IN
- kinds: omelette, egg dish
- ingredients: tomato, green chili, onion, egg as food
- has Wikipedia article: en, zh

## DISH Q6024261
- name: Morisqueta
- description: Mexican dish
- countries: MX, PH
- kinds: rice dish
- has Wikipedia article: en

## DISH Q6024500
- name: Morteruelo
- description: Spanish pâté
- countries: ES
- cuisines: Castilian-Manchego cuisine
- kinds: meal, pâté
- ingredients: garlic, game meat, pork liver, bread crumbs, oil, spice

## DISH Q6024923
- name: Pideli köfte
- description: "köfte" (meatball) dish from the Turkish cuisine
- countries: (none)
- kinds: Köftes in the Turkish cuisine
- has Wikipedia article: en

## DISH Q60253813
- name: Salinātā rudzu rupjmaize
- countries: (none)
- kinds: rupjmaize

## DISH Q6026652
- name: Flaouna
- description: Cypriot Easter food
- countries: CY
- kinds: food, dish
- ingredients: Spearmint, mahleb, mastic, nutmeg, flour, vanilla, raisin, table salt, cheese, milk, drinking water
- has Wikipedia article: en

## DISH Q6027429
- name: Hünkârbeğendi
- description: Meat dish with an eggplant-cheese pure, from the Turkish cuisine
- countries: TR
- kinds: dish, lamb dish
- has Wikipedia article: en

## DISH Q6027777
- name: Yayla çorbası
- description: soup from the cuisine of Turkey, known as "Yayla çorbası" in Turkish
- countries: TR
- cuisines: Turkish cuisine
- kinds: dish, soup
- ingredients: yogurt, rice
- has Wikipedia article: en

## DISH Q602810
- name: Rehrücken Baden-Baden
- other names: {"de": "Rehrücken Baden-Baden"}
- countries: (none)
- kinds: meat dish

## DISH Q60284253
- name: Zigeunerbraten
- other names: {"ca": "Zigeunerbraten"}
- description: meat dish
- countries: (none)
- kinds: dish

## DISH Q6029192
- name: Yuvalama
- description: soup from the cuisine of southern Turkey
- countries: TR
- kinds: food, soup, stew
- ingredients: chickpea, lamb meat, spice, yogurt

## DISH Q6029320
- name: Tahini roll
- description: Turkish sweet bun (çörek) with tahini
- countries: TR
- kinds: food, sweet roll, çörek
- ingredients: tehina, dough
- has Wikipedia article: en

## DISH Q6029514
- name: Kalehjoosh
- description: popular soup in Iran, Azerbaijan, and Southern Turkey
- countries: IR, TR
- kinds: food, soup, Eshkeneh
- has Wikipedia article: en

## DISH Q6030071
- name: Gavurdağı salatası
- description: Turkish salad
- countries: TR
- kinds: food, salad

## DISH Q60310981
- name: Chocolate pot
- description: culinary dish made from chocolate
- countries: (none)
- kinds: dish, chocolate dessert

## DISH Q60313138
- name: Poznański pumpernikel Adama
- other names: {"pl": "poznański pumpernikel Adama"}
- countries: (none)
- kinds: bread

## DISH Q6031877
- name: Rize kavurması
- countries: (none)
- kinds: kavurma

## DISH Q6031965
- name: Chickpea bread
- countries: AL, TR
- kinds: baked good, Turkish breads
- ingredients: chickpea
- has Wikipedia article: en

## DISH Q6032139
- name: Babuko
- description: Turkish dish
- countries: TR
- kinds: dish
- ingredients: garlic, peppercorn, baker's yeast, dough, cheese

## DISH Q6034013
- name: Inipit
- description: traditional pastry in the Philippines
- countries: PH
- kinds: food, pastry
- ingredients: flour
- has Wikipedia article: en

## DISH Q6034363
- name: Injipuli
- description: A dark brown sweet-sour&spicy Keralite curry made of ginger, tamarind, green chillies and jaggery
- countries: IN
- kinds: food, Indian curry
- ingredients: ginger
- has Wikipedia article: en

## DISH Q6035081
- name: Yalancı Dolma
- other names: {"tr": "Yalancı Dolma"}
- countries: (none)
- kinds: dish

## DISH Q6036443
- name: Ankara tava
- description: Turkish cuisine dish
- countries: TR
- kinds: food, dish
- ingredients: mutton, veal, lamb meat, rice

## DISH Q60375100
- name: Jinju-bibimbap
- countries: KR
- cuisines: South Korean cuisine
- kinds: bibimbap
- has Wikipedia article: en

## DISH Q60375170
- name: Jeonju-bibimbap
- countries: KR
- kinds: bibimbap
- has Wikipedia article: en

## DISH Q6037551
- name: Tepsi böreği
- other names: {"tr": "Tepsi böreği"}
- countries: (none)
- kinds: börek

## DISH Q6037556
- name: Naiboa
- description: dish in Venezuela
- countries: VE
- kinds: dish
- ingredients: panela, cazabe

## DISH Q6037894
- name: Bükme
- description: Turkish dish
- countries: (none)
- kinds: dish

## DISH Q6038708
- name: Instant-boiled mutton
- other names: {"zh": "涮羊肉"}
- description: hot pot originated from Beijing
- countries: (none)
- kinds: type of food or dish, hot pot, lamb dish
- ingredients: mutton, lamb meat
- has Wikipedia article: en, zh

## DISH Q6038754
- name: Gözleme with beef
- description: Gözleme filled with ground beef
- countries: (none)
- kinds: gözleme

## DISH Q6038836
- name: Elbasan tava
- description: Turkish dish
- countries: TR
- kinds: dish

## DISH Q6038850
- name: Instant rice
- other names: {"zh": "方便米飯"}
- description: precooked rice
- countries: (none)
- kinds: rice dish
- has Wikipedia article: en, zh

## DISH Q6038914
- name: Un helvası
- description: dessert from the Turkish cuisine
- countries: TR
- kinds: dessert

## DISH Q60398433
- name: Chhena Mudki
- description: Indian sweet
- countries: IN
- kinds: dessert
- ingredients: chhena, semolina, sugar

## DISH Q6041660
- name: Akhisar köfte
- other names: {"tr": "Akhisar köfte"}
- countries: TR
- kinds: dish, meatball

## DISH Q6042330
- name: Kuzu kapama
- description: traditional lamb dish from the Turkish cuisine
- countries: TR
- kinds: food, stew

## DISH Q60428660
- name: Erzurum kadaifi dolması
- description: dessert
- countries: (none)
- kinds: dessert, Kadayif

## DISH Q6042947
- name: Kol böreği
- description: Type of börek
- countries: TR
- kinds: börek, lamb dish
- ingredients: lamb meat
- has Wikipedia article: en

## DISH Q60429771
- name: Pickle relish
- description: condiment with cucumber (gherkin), onion, mustard seeds and peppers; relish made with gherkins
- countries: SE
- kinds: relish, pickled cucumber
- ingredients: onion, mustard seed, pickled cucumber, sugar

## DISH Q60457322
- name: Wespennest (Gebäck)
- other names: {"de": "Wespennest (Gebäck)"}
- countries: (none)
- kinds: cake

## DISH Q6047464
- name: Calla (yemek)
- other names: {"tr": "Calla (yemek)"}
- countries: TR
- kinds: dish

## DISH Q6049723
- name: Tokat kebabı
- description: lamb dish from the Turkish cuisine made in a black oven
- countries: TR
- kinds: food, kebab, meat dish
- ingredients: garlic, potato, eggplant, lamb meat

## DISH Q60499622
- name: Queso helado
- description: Peruvian ice cream dessert
- countries: PE
- kinds: dessert, meal
- ingredients: condensed milk, cinnamon, milk
- has Wikipedia article: en

## DISH Q6050131
- name: Olla de carne
- description: Costa Rican stew
- countries: CR
- kinds: stew
- ingredients: cassava root

## DISH Q6051251
- name: Testi kebabı
- description: lamb dish from the Turkish cuisine cooked inside an earthenware jug on an open fire
- countries: TR
- kinds: food
- ingredients: lamb meat

## DISH Q605277
- name: Kamby arro
- description: thick cream desert derived from cooking rice and cows milk together
- countries: PY
- kinds: pudding, dessert
- ingredients: cow's milk, rice
- has Wikipedia article: en

## DISH Q6052975
- name: Orrisa
- description: Stew of meat and barley
- countries: (none)
- kinds: region, stew
- ingredients: barley, meat

## DISH Q60544188
- name: Maschinrostbraten
- other names: {"de": "Maschinrostbraten"}
- countries: (none)
- kinds: dish

## DISH Q605444
- name: Romeritos
- description: typical Mexican dish
- countries: (none)
- kinds: dish
- has Wikipedia article: en

## DISH Q6056817
- name: Paciencias de Almazán
- countries: (none)
- kinds: dish, pastry

## DISH Q6057938
- name: Besmeç
- description: kind of Turkish köfte
- countries: (none)
- kinds: Köftes in the Turkish cuisine

## DISH Q6059372
- name: Pan de Ambato
- other names: {"es": "Pan de Ambato"}
- countries: (none)
- kinds: bread

## DISH Q6059375
- name: Pan de Calatrava
- other names: {"es": "Pan de Calatrava"}
- countries: ES
- kinds: dessert

## DISH Q6059378
- name: Pan de Cruz
- description: Spanish bread
- countries: (none)
- kinds: bread

## DISH Q6059380
- name: Pan de Cádiz
- description: Andalusian confection
- countries: ES
- kinds: food, confectionery
- ingredients: marzipan
- has Wikipedia article: en

## DISH Q6059387
- name: Pan dulce
- other names: {"zh": "甜面包"}
- description: variety of latinoamerican pastries
- countries: (none)
- kinds: pastry, Mexican bread, sweet bread
- has Wikipedia article: en

## DISH Q6059772
- name: Panqueque (crepe)
- description: South American pancake
- countries: (none)
- kinds: pancake

## DISH Q6059926
- name: Pantortilla
- other names: {"ca": "Pantortilla"}
- countries: ES
- kinds: dessert

## DISH Q6060064
- name: Papadzules
- description: Mexican tortilla dish
- countries: (none)
- kinds: egg dish
- has Wikipedia article: en

## DISH Q6060099
- name: Patatas aliñás
- description: potato salad, parsley and olive oil
- countries: (none)
- kinds: dish
- ingredients: parsley, potato, extra virgin olive oil, sherry vinegar, red onion

## DISH Q6060108
- name: Papas mayo
- other names: {"es": "Papas mayo"}
- countries: (none)
- kinds: salad

## DISH Q60615079
- name: Eierschmalz
- other names: {"de": "Eierschmalz"}
- countries: (none)
- kinds: dish, list of egg dishes

## DISH Q60620989
- name: Crab melt
- description: sandwich
- countries: US
- cuisines: cuisine of the United States
- kinds: melt sandwich, food
- ingredients: Brachyura

## DISH Q6066037
- name: Pastel cordobés
- other names: {"es": "Pastel cordobés"}
- countries: ES
- kinds: dessert

## DISH Q6066040
- name: Pastissets de moniato
- countries: ES
- kinds: dessert

## DISH Q6066241
- name: Patatas alioli
- countries: (none)
- kinds: potato dish

## DISH Q6066244
- name: Patatas a lo pobre
- description: Andalusian potato dish
- countries: ES
- cuisines: Spanish cuisine, cuisine of the province of Almería
- kinds: dish, side dish, potato dish
- has Wikipedia article: en

## DISH Q6066253
- name: Patatas en ajopollo
- other names: {"es": "patatas en ajopollo"}
- countries: (none)
- kinds: type of food or dish, potato dish

## DISH Q60669107
- name: Tandoori roti
- description: Roti baked in a Tandoor
- countries: IN, PK
- cuisines: Indian cuisine, Pakistani cuisine, South Asian cuisine
- kinds: roti
- has Wikipedia article: en

## DISH Q6067630
- name: Pavo trufado
- other names: {"es": "Pavo trufado"}
- countries: ES
- kinds: cold cut
- ingredients: Tuber, turkey meat
